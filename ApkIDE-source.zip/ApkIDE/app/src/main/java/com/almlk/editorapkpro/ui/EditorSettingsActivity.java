package com.almlk.editorapkpro.ui;

import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.ui.editor.EditorTheme;
import com.almlk.editorapkpro.ui.editor.EditorToolConfig;
import com.almlk.editorapkpro.ui.view.CodeEditorView;
import com.almlk.editorapkpro.util.Prefs;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** إعدادات المحرر: الثيم، الألوان، العرض، وترتيب مفاتيح IME المساعدة. */
public class EditorSettingsActivity extends AppCompatActivity {
    private CodeEditorView preview;
    private MaterialButton themeButton;
    private LinearLayout colorsContainer,toolsContainer;
    private TextView fontText,spacingText,tabText;
    private List<String> toolOrder=new ArrayList<>();

    @Override protected void onCreate(@Nullable Bundle state){
        super.onCreate(state);
        setContentView(R.layout.activity_editor_settings);
        MaterialToolbar toolbar=findViewById(R.id.editorSettingsToolbar);
        toolbar.setNavigationOnClickListener(v->finish());

        themeButton=findViewById(R.id.btnEditorTheme);
        preview=findViewById(R.id.editorPreview);
        colorsContainer=findViewById(R.id.editorColorContainer);
        toolsContainer=findViewById(R.id.editorToolOrderContainer);
        fontText=findViewById(R.id.txtEditorFontSize);
        spacingText=findViewById(R.id.txtEditorLineSpacing);
        tabText=findViewById(R.id.txtEditorTabSpaces);

        preview.setFocusable(false);preview.setClickable(false);preview.setCursorVisible(false);
        preview.setTextIsSelectable(false);preview.setKeyListener(null);
        preview.setSource("package com.example.editor;\n\n"+
                "// AIDE style syntax preview\n"+
                "@Override public String format(int count) {\n"+
                "    String title = \"Editor APK Pro\";\n"+
                "    return title + count;\n"+
                "}\n","Preview.java");

        MaterialSwitch lineNumbers=findViewById(R.id.swEditorLineNumbers);
        MaterialSwitch wordWrap=findViewById(R.id.swEditorWordWrap);
        MaterialSwitch currentLine=findViewById(R.id.swEditorCurrentLine);
        MaterialSwitch helper=findViewById(R.id.swEditorToolbar);
        MaterialSwitch complete=findViewById(R.id.swEditorComplete);
        MaterialSwitch autoClose=findViewById(R.id.swEditorAutoClose);
        lineNumbers.setChecked(Prefs.editorLineNumbers());wordWrap.setChecked(Prefs.editorWordWrap());
        currentLine.setChecked(Prefs.editorCurrentLine());helper.setChecked(Prefs.editorToolbarVisible());
        complete.setChecked(Prefs.autoComplete());autoClose.setChecked(Prefs.autoClose());
        lineNumbers.setOnCheckedChangeListener((b,v)->{Prefs.editorLineNumbers(v);refreshPreview();});
        wordWrap.setOnCheckedChangeListener((b,v)->{Prefs.editorWordWrap(v);refreshPreview();});
        currentLine.setOnCheckedChangeListener((b,v)->{Prefs.editorCurrentLine(v);refreshPreview();});
        helper.setOnCheckedChangeListener((b,v)->Prefs.editorToolbarVisible(v));
        complete.setOnCheckedChangeListener((b,v)->Prefs.autoComplete(v));
        autoClose.setOnCheckedChangeListener((b,v)->Prefs.autoClose(v));

        Slider font=findViewById(R.id.sliderEditorFontSize);
        Slider spacing=findViewById(R.id.sliderEditorLineSpacing);
        Slider tabs=findViewById(R.id.sliderEditorTabSpaces);
        font.setValue(clamp(Prefs.editorFontSize(),10,32));
        spacing.setValue(clamp(Prefs.editorLineSpacing(),0,8));
        tabs.setValue(clamp(Prefs.editorTabSpaces(),2,8));
        updateSliderLabels();
        font.addOnChangeListener((s,v,user)->{Prefs.editorFontSize(v);updateSliderLabels();refreshPreview();});
        spacing.addOnChangeListener((s,v,user)->{Prefs.editorLineSpacing(v);updateSliderLabels();refreshPreview();});
        tabs.addOnChangeListener((s,v,user)->{Prefs.editorTabSpaces((int)v);updateSliderLabels();});

        themeButton.setOnClickListener(v->chooseTheme());
        toolOrder=EditorToolConfig.order();
        refreshThemeButton();buildColorRows();buildToolRows();refreshPreview();

        findViewById(R.id.btnResetEditorSettings).setOnClickListener(v->
                new MaterialAlertDialogBuilder(this)
                        .setTitle("استعادة الإعدادات")
                        .setMessage("سيُعاد ثيم AIDE والترتيب والألوان والحجم إلى القيم الافتراضية.")
                        .setNegativeButton(R.string.cancel,null)
                        .setPositiveButton("استعادة",(d,w)->{Prefs.resetEditorSettings();recreate();})
                        .show());
    }

    private void chooseTheme(){
        String[] ids=EditorTheme.ids(),names=EditorTheme.names();
        int checked=0;for(int i=0;i<ids.length;i++)if(ids[i].equals(Prefs.editorTheme()))checked=i;
        new MaterialAlertDialogBuilder(this).setTitle("ثيم المحرر")
                .setSingleChoiceItems(names,checked,(dialog,which)->{
                    Prefs.editorTheme(ids[which]);
                    // اختيار preset جديد يعني البدء بألوانه، ثم يمكن تخصيصها أسفل الشاشة.
                    Prefs.clearEditorColors();dialog.dismiss();
                    refreshThemeButton();buildColorRows();refreshPreview();
                }).setNegativeButton(R.string.cancel,null).show();
    }

    private void refreshThemeButton(){
        themeButton.setText("الثيم: "+EditorTheme.preset(Prefs.editorTheme()).name);
    }

    private void refreshPreview(){
        preview.applyPreferences();preview.refreshHighlight();
    }

    private void updateSliderLabels(){
        fontText.setText("حجم خط المحرر: "+Math.round(Prefs.editorFontSize())+"sp");
        spacingText.setText("المسافة الإضافية بين الأسطر: "+Math.round(Prefs.editorLineSpacing())+"dp");
        tabText.setText("حجم Tab: "+Prefs.editorTabSpaces()+" مسافات");
    }

    private void buildColorRows(){
        colorsContainer.removeAllViews();
        EditorTheme theme=EditorTheme.current();
        for(String key:EditorTheme.COLOR_KEYS){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(8),dp(5),dp(8),dp(5));
            row.setMinimumHeight(dp(52));
            View swatch=new View(this);GradientDrawable shape=new GradientDrawable();
            shape.setColor(theme.color(key));shape.setCornerRadius(dp(7));
            shape.setStroke(dp(1),0xFF6E7681);swatch.setBackground(shape);
            row.addView(swatch,new LinearLayout.LayoutParams(dp(34),dp(34)));
            TextView label=new TextView(this);label.setText(EditorTheme.label(key));
            label.setTextColor(0xFFE6EDF3);label.setTextSize(14);label.setPadding(dp(12),0,dp(6),0);
            row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            TextView hex=new TextView(this);hex.setText(EditorTheme.toHex(theme.color(key)));
            hex.setTextColor(0xFF9AA7B4);hex.setTextSize(11);hex.setTypeface(android.graphics.Typeface.MONOSPACE);
            row.addView(hex,new LinearLayout.LayoutParams(-2,-2));
            row.setBackgroundResource(android.R.drawable.list_selector_background);
            row.setOnClickListener(v->editColor(key));colorsContainer.addView(row);
        }
    }

    private void editColor(String key){
        EditText input=new EditText(this);input.setSingleLine(true);
        input.setText(EditorTheme.toHex(EditorTheme.current().color(key)));
        input.setSelectAllOnFocus(true);input.setInputType(InputType.TYPE_CLASS_TEXT);
        int pad=dp(20);input.setPadding(pad,dp(8),pad,dp(8));
        AlertDialog dialog=new MaterialAlertDialogBuilder(this)
                .setTitle(EditorTheme.label(key))
                .setMessage("أدخل اللون بصيغة #RRGGBB أو #AARRGGBB")
                .setView(input).setNegativeButton(R.string.cancel,null)
                .setPositiveButton("تطبيق",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            Integer color=EditorTheme.parseColor(input.getText().toString());
            if(color==null){input.setError("قيمة اللون غير صحيحة");return;}
            Prefs.setEditorColor(key,color);dialog.dismiss();buildColorRows();refreshPreview();
        }));
        dialog.show();
    }

    private void buildToolRows(){
        toolsContainer.removeAllViews();
        for(int i=0;i<toolOrder.size();i++){
            final int index=i;String key=toolOrder.get(i);
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(4),dp(3),dp(4),dp(3));
            TextView label=new TextView(this);label.setText((i+1)+".  "+EditorToolConfig.label(key));
            label.setTextColor(0xFFE6EDF3);label.setTextSize(14);
            row.addView(label,new LinearLayout.LayoutParams(0,dp(48),1));
            TextView up=moveButton("↑",index>0);TextView down=moveButton("↓",index<toolOrder.size()-1);
            up.setOnClickListener(v->moveTool(index,-1));down.setOnClickListener(v->moveTool(index,1));
            row.addView(up);row.addView(down);
            MaterialSwitch enabled=new MaterialSwitch(this);enabled.setChecked(Prefs.editorToolEnabled(key));
            enabled.setContentDescription("إظهار "+EditorToolConfig.label(key));
            enabled.setOnCheckedChangeListener((b,value)->Prefs.editorToolEnabled(key,value));
            row.addView(enabled,new LinearLayout.LayoutParams(dp(54),dp(48)));
            toolsContainer.addView(row);
        }
    }

    private TextView moveButton(String text,boolean enabled){
        TextView button=new TextView(this);button.setText(text);button.setTextSize(22);
        button.setGravity(Gravity.CENTER);button.setEnabled(enabled);
        button.setTextColor(enabled?0xFF4FC3F7:0xFF4B5560);
        button.setBackgroundResource(android.R.drawable.list_selector_background);
        button.setLayoutParams(new LinearLayout.LayoutParams(dp(44),dp(44)));
        return button;
    }

    private void moveTool(int index,int delta){
        int other=index+delta;if(other<0||other>=toolOrder.size())return;
        Collections.swap(toolOrder,index,other);EditorToolConfig.saveOrder(toolOrder);buildToolRows();
    }

    private float clamp(float v,float min,float max){return Math.max(min,Math.min(max,v));}
    private int dp(int value){return(int)(value*getResources().getDisplayMetrics().density+.5f);}
}
