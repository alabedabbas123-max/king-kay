package com.almlk.editorapkpro.i18n;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.util.XmlUtil;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.File;
import java.util.*;

/**
 * مولّد اللغات: إضافة لغة جديدة بضغطة زر.
 * يقرأ values/strings.xml الأساسي وينشئ values-&lt;code&gt;/strings.xml
 * مع الحفاظ على كل المفاتيح والتنسيقات (%1$s …) وعلامة translatable=false.
 */
public class LocalizationGenerator {

    /** واجهة مزوّد ترجمة — يمكن ربطها بأي خدمة لاحقاً (افتراضياً: نسخ النص الأصلي). */
    public interface Translator {
        String translate(String text, String fromLang, String toLang) throws Exception;
    }

    public static final Translator IDENTITY = (t, f, to) -> t;

    private final Logger log;
    public LocalizationGenerator(Logger log) { this.log = log; }

    public static class Result {
        public String locale;
        public int    total, translated, skipped;
        public File   file;
    }

    /** قائمة مختصرة للغات الشائعة (code -> الاسم). */
    public static LinkedHashMap<String, String> commonLocales() {
        LinkedHashMap<String, String> m = new LinkedHashMap<>();
        m.put("ar", "العربية");        m.put("en", "English");
        m.put("fr", "Français");       m.put("es", "Español");
        m.put("de", "Deutsch");        m.put("tr", "Türkçe");
        m.put("ru", "Русский");        m.put("fa", "فارسی");
        m.put("ur", "اردو");           m.put("hi", "हिन्दी");
        m.put("id", "Indonesia");      m.put("pt", "Português");
        m.put("it", "Italiano");       m.put("zh", "中文");
        m.put("ja", "日本語");          m.put("ko", "한국어");
        m.put("ms", "Melayu");         m.put("bn", "বাংলা");
        return m;
    }

    /** اللغات الموجودة فعلاً في المشروع. */
    public static List<String> existingLocales(Project p) {
        List<String> out = new ArrayList<>();
        File[] dirs = p.resDir().listFiles(f -> f.isDirectory() && f.getName().startsWith("values-"));
        if (dirs != null) for (File d : dirs) {
            if (new File(d, "strings.xml").exists())
                out.add(d.getName().substring("values-".length()));
        }
        Collections.sort(out);
        return out;
    }

    public Result addLanguage(Project p, String locale, Translator translator, boolean overwrite)
            throws Exception {

        Result r = new Result();
        r.locale = locale;
        File base = new File(p.valuesDir(), "strings.xml");
        if (!base.exists()) throw new IllegalStateException("لا يوجد res/values/strings.xml في المشروع");

        File outDir = new File(p.resDir(), "values-" + locale);
        File out    = new File(outDir, "strings.xml");
        if (out.exists() && !overwrite) {
            log.w("i18n: " + locale + " موجودة مسبقاً — تم التخطي");
            r.file = out;
            return r;
        }

        Document src = XmlUtil.parse(base);
        Document dst = XmlUtil.blank("resources");

        NodeList strings = src.getElementsByTagName("string");
        for (int i = 0; i < strings.getLength(); i++) {
            Element e = (Element) strings.item(i);
            r.total++;
            if ("false".equals(e.getAttribute("translatable"))) { r.skipped++; continue; }
            String text = e.getTextContent();
            String tr;
            try { tr = translator == null ? text : translator.translate(text, "auto", locale); }
            catch (Exception ex) { tr = text; }
            if (tr != null && !tr.equals(text)) r.translated++;
            Element n = dst.createElement("string");
            n.setAttribute("name", e.getAttribute("name"));
            if (!e.getAttribute("formatted").isEmpty())
                n.setAttribute("formatted", e.getAttribute("formatted"));
            n.setTextContent(tr == null ? text : tr);
            dst.getDocumentElement().appendChild(n);
        }

        // نسخ string-array و plurals بنفس البنية
        copyBlocks(src, dst, "string-array", "item");
        copyBlocks(src, dst, "plurals", "item");

        XmlUtil.save(dst, out);
        r.file = out;
        log.i("i18n: أُنشئت values-" + locale + " بـ " + r.total + " مفتاح");
        return r;
    }

    private void copyBlocks(Document src, Document dst, String tag, String childTag) {
        NodeList list = src.getElementsByTagName(tag);
        for (int i = 0; i < list.getLength(); i++) {
            Element e = (Element) list.item(i);
            Element n = dst.createElement(tag);
            n.setAttribute("name", e.getAttribute("name"));
            NodeList kids = e.getElementsByTagName(childTag);
            for (int j = 0; j < kids.getLength(); j++) {
                Element c = dst.createElement(childTag);
                Element ok = (Element) kids.item(j);
                if (!ok.getAttribute("quantity").isEmpty())
                    c.setAttribute("quantity", ok.getAttribute("quantity"));
                c.setTextContent(ok.getTextContent());
                n.appendChild(c);
            }
            dst.getDocumentElement().appendChild(n);
        }
    }

    /** إضافة عدة لغات دفعة واحدة. */
    public List<Result> addLanguages(Project p, List<String> locales, Translator t, boolean overwrite) {
        List<Result> out = new ArrayList<>();
        for (String l : locales) {
            try { out.add(addLanguage(p, l, t, overwrite)); }
            catch (Exception e) { log.e("i18n: فشل " + l + " : " + e.getMessage()); }
        }
        return out;
    }

    /** يضيف android:supportsRtl إن أُضيفت لغة RTL. */
    public void ensureRtlSupport(Project p, String locale) throws Exception {
        if (!Arrays.asList("ar", "fa", "ur", "he", "iw").contains(locale)) return;
        File mf = p.manifest();
        if (!mf.exists()) return;
        Document d = XmlUtil.parse(mf);
        NodeList apps = d.getElementsByTagName("application");
        if (apps.getLength() == 0) return;
        Element app = (Element) apps.item(0);
        XmlUtil.setAttr(app, "supportsRtl", "true");
        XmlUtil.save(d, mf);
        log.i("i18n: تم تفعيل supportsRtl");
    }
}
