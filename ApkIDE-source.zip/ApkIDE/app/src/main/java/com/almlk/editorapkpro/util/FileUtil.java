package com.almlk.editorapkpro.util;

import android.content.ContentResolver;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.database.Cursor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public final class FileUtil {
    private FileUtil() {}

    public static String read(File f) throws IOException {
        return new String(readBytes(f), StandardCharsets.UTF_8);
    }

    public static byte[] readBytes(File f) throws IOException {
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) { return readAll(in); }
    }

    public static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream(Math.max(8192, in.available()));
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        return bos.toByteArray();
    }

    public static void write(File f, String text) throws IOException {
        write(f, text.getBytes(StandardCharsets.UTF_8));
    }

    public static void write(File f, byte[] data) throws IOException {
        File p = f.getParentFile();
        if (p != null && !p.exists()) p.mkdirs();
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(f))) { out.write(data); }
    }

    public static void copy(InputStream in, File dst) throws IOException {
        File p = dst.getParentFile();
        if (p != null && !p.exists()) p.mkdirs();
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(dst))) {
            byte[] buf = new byte[32768]; int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        }
    }

    public static void copyDir(File src, File dst) throws IOException {
        if (!src.exists()) return;
        if (src.isDirectory()) {
            dst.mkdirs();
            File[] kids = src.listFiles();
            if (kids != null) for (File k : kids) copyDir(k, new File(dst, k.getName()));
        } else {
            try (InputStream in = new FileInputStream(src)) { copy(in, dst); }
        }
    }

    public static void delete(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) delete(k);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    public static List<File> walk(File root, String... extensions) {
        List<File> out = new ArrayList<>();
        Deque<File> stack = new ArrayDeque<>();
        stack.push(root);
        Set<String> exts = new HashSet<>(Arrays.asList(extensions));
        while (!stack.isEmpty()) {
            File f = stack.pop();
            if (f.isDirectory()) {
                File[] kids = f.listFiles();
                if (kids != null) for (File k : kids) stack.push(k);
            } else if (exts.isEmpty() || exts.contains(ext(f.getName()))) {
                out.add(f);
            }
        }
        return out;
    }

    public static String ext(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? "" : name.substring(i + 1).toLowerCase(Locale.ROOT);
    }

    public static String nameNoExt(String name) {
        int i = name.lastIndexOf('.');
        return i < 0 ? name : name.substring(0, i);
    }

    public static String humanSize(long b) {
        if (b < 1024) return b + " B";
        int e = (int) (Math.log(b) / Math.log(1024));
        return String.format(Locale.US, "%.1f %sB", b / Math.pow(1024, e), "KMGTP".charAt(e - 1));
    }

    public static long sizeOf(File f) {
        if (f.isFile()) return f.length();
        long s = 0; File[] k = f.listFiles();
        if (k != null) for (File x : k) s += sizeOf(x);
        return s;
    }

    /** نسخ محتوى Uri (SAF) إلى ملف محلي. */
    public static File importUri(ContentResolver cr, Uri uri, File dstDir) throws IOException {
        String name = queryName(cr, uri);
        if (name == null) name = "imported_" + System.currentTimeMillis() + ".apk";
        File dst = new File(dstDir, name);
        try (InputStream in = cr.openInputStream(uri)) {
            if (in == null) throw new IOException("تعذّر فتح الملف المحدد");
            copy(in, dst);
        }
        return dst;
    }

    public static String queryName(ContentResolver cr, Uri uri) {
        if ("file".equals(uri.getScheme())) return new File(uri.getPath()).getName();
        try (Cursor c = cr.query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) return c.getString(i);
            }
        } catch (Exception ignored) {}
        return null;
    }

    /** تحديد ما إذا كان الملف نصياً (heuristic) لعرضه في المحرر. */
    public static boolean isProbablyText(File f) {
        String e = ext(f.getName());
        if (TEXT_EXT.contains(e)) return true;
        if (BINARY_EXT.contains(e)) return false;
        try (InputStream in = new FileInputStream(f)) {
            byte[] head = new byte[Math.min(4096, (int) f.length())];
            int n = in.read(head);
            int bad = 0;
            for (int i = 0; i < n; i++) {
                int b = head[i] & 0xFF;
                if (b == 0) return false;
                if (b < 9 || (b > 13 && b < 32)) bad++;
            }
            return n <= 0 || bad * 100 / Math.max(1, n) < 5;
        } catch (IOException e2) { return false; }
    }

    public static final Set<String> TEXT_EXT = new HashSet<>(Arrays.asList(
            "java","kt","kts","xml","smali","json","txt","md","gradle","pro","properties","cfg","ini",
            "yml","yaml","html","htm","css","js","ts","c","cpp","h","hpp","py","sh","bat","csv","sql",
            "lua","gitignore","version","mf","rs","go","php","toml","proto","graphql","svg"));

    public static final Set<String> BINARY_EXT = new HashSet<>(Arrays.asList(
            "png","jpg","jpeg","webp","gif","bmp","ico","mp3","wav","ogg","m4a","aac","flac","mid",
            "mp4","3gp","mkv","webm","avi","ttf","otf","woff","woff2","so","dex","arsc","apk","jar",
            "zip","aar","db","sqlite","bin","dat","pdf","obb","keystore","jks","bks"));
}
