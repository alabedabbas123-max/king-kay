package com.almlk.editorapkpro.engine.jadx;

import java.util.Collections;
import java.util.List;

import jadx.api.plugins.JadxPlugin;
import jadx.api.plugins.loader.JadxPluginLoader;
import jadx.plugins.input.dex.DexInputPlugin;

/**
 * محمّل إضافات حتمي لأندرويد. لا يستخدم ServiceLoader ولا يحمّل smali-input؛
 * APK وDEX يحتاجان DexInputPlugin فقط، بينما Apktool مسؤول عن ملفات smali.
 */
public final class AndroidJadxPluginLoader implements JadxPluginLoader {
    @Override public List<JadxPlugin> load() {
        return Collections.<JadxPlugin>singletonList(new DexInputPlugin());
    }

    @Override public void close() {
        // لا توجد ClassLoaders خارجية أو موارد تحتاج إغلاقاً.
    }
}
