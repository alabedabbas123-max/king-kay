package com.almlk.editorapkpro.ui;

import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.almlk.editorapkpro.engine.Engine;
import com.almlk.editorapkpro.engine.EngineService;
import com.almlk.editorapkpro.engine.TaskCallback;
import com.almlk.editorapkpro.model.Project;

import java.io.File;

/** يبدأ عملية الفك من أي شاشة ويعرض التقدّم ثم يفتح المشروع. */
public final class DecompileStarter {

    private DecompileStarter() {}

    public static void start(AppCompatActivity a, File apk, String name, int mode) {
        if(Engine.get().isBusy()){
            Ui.toast(a,"توجد عملية فك أو بناء جارية؛ انتظر اكتمالها");
            return;
        }
        String title = mode == Project.MODE_SOURCE
                ? "فك المشروع الهندسي الكامل" : "فك الموارد وملفات Smali";
        // قائمة التطبيقات كانت تحتفظ سابقاً بكل الأيقونات أثناء Jadx. حرر المرئي منها
        // والكاش قبل بدء العملية الثقيلة، وأعدها فقط إذا فشل الفك وبقيت الشاشة.
        if(a instanceof AppListActivity)((AppListActivity)a).releaseForHeavyWork();
        Ui.ActivityBusy topBusy=new Ui.ActivityBusy(a);
        topBusy.show(title+"…");
        Ui.Progress p = new Ui.Progress(a, title).show();
        EngineService.start(a, title, apk.getName());
        Engine.get().decompile(a, apk, name, mode, new TaskCallback<Project>() {
            @Override public void onProgress(String step, int percent) {
                topBusy.update(step); p.update(step, percent);
            }
            @Override public void onSuccess(Project project) {
                topBusy.hide(); p.dismiss();
                EngineService.stop(a);
                a.startActivity(new Intent(a, ProjectActivity.class).putExtra("dir", project.dir));
            }
            @Override public void onError(Throwable e) {
                topBusy.hide(); p.dismiss();
                EngineService.stop(a);
                if(a instanceof AppListActivity)((AppListActivity)a).restoreAfterHeavyWork();
                Ui.error(a, e);
            }
        });
    }
}
