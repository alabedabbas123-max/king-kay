package com.almlk.editorapkpro.setup;

import android.content.Context;

import com.almlk.editorapkpro.compiler.KeystoreManager;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.NativeTools;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.Prefs;
import com.almlk.editorapkpro.tools.ToolInstaller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * إعداد تلقائي لأول تشغيل:
 * - محركات الفك وaapt2 وبديل zipalign مدمجة لتعمل حتى دون إنترنت.
 * - android.jar الكبير لا يُحزم داخل APK؛ ينزله ToolInstaller بصورة متدفقة
 *   ويتحقق من SHA-256. فشل الشبكة لا يمنع الفك، وتُعاد المحاولة عند بناء المصدر.
 * - مفتاح التوقيع يُستخرج تلقائياً.
 */
public final class SetupManager {
    public interface Callback {
        void onStep(String message, int percent);
        void onReady(Report report);
        void onError(Throwable error);
    }

    public static class Report {
        public boolean jadx, apktool, ninePatch, lowMemorySmali, androidXml, apktoolFramework, apksig, ecj, d8, aapt2;
        public boolean zipalign, zipalignNative, androidJar, keystore;
        /** اكتمال إعداد كل ما يلزم للفك والبناء من المصدر، لا مجرد وجود كلاس. */
        public boolean complete() { return canBuildSource(); }
        public boolean canDecompile() { return jadx && apktool && ninePatch && lowMemorySmali && androidXml && apktoolFramework; }
        /** البناء السريع؛ zipalign الأصلي غير مطلوب لوجود JavaZipAligner. */
        public boolean canBuild() { return canDecompile() && apksig && aapt2 && zipalign && keystore; }
        public boolean canBuildSource() { return canBuild() && ecj && d8 && androidJar; }
        public String text() {
            return line("jadx",jadx)+line("apktool",apktool)+line("Nine-Patch Android",ninePatch)
                    +line("Smali Android منخفض الذاكرة",lowMemorySmali)
                    +line("Jadx XML Android",androidXml)
                    +line("Apktool framework 1.apk",apktoolFramework)
                    +line("apksig",apksig)+line("ECJ",ecj)+line("D8",d8)+line("aapt2",aapt2)
                    +"• zipalign : "+(zipalignNative?"جاهز (أصلي)":zipalign?"جاهز (بديل Java)":"مفقود")+"\n"
                    +line("android.jar API 34",androidJar)+line("مفتاح التوقيع",keystore);
        }
        private String line(String n, boolean ok){return "• "+n+" : "+(ok?"جاهز":"مفقود/غير صالح")+"\n";}
    }

    private static final ExecutorService worker=Executors.newSingleThreadExecutor();
    private static final List<Callback> callbacks=new ArrayList<>();
    private static boolean running;
    private static final Object installLock = new Object();
    private static volatile Report last;
    private SetupManager() {}

    public static boolean isReady(){return last!=null&&last.complete();}
    public static Report lastReport(){return last;}

    public static void ensure(Context context, Callback cb) {
        Context app=context.getApplicationContext();
        synchronized(SetupManager.class){
            if(last!=null&&last.complete()){cb.onReady(last);return;}
            callbacks.add(cb);
            if(running)return;
            running=true;
        }
        worker.execute(()->{
            try{
                Report r;
                synchronized (installLock) {
                    r = last != null && last.complete() ? last
                            : installBlocking(app,null,(s,p)->dispatchStep(s,p));
                }
                synchronized(SetupManager.class){last=r;running=false;Prefs.setupComplete(r.complete());}
                dispatchReady(r);
            }catch(Throwable t){synchronized(SetupManager.class){running=false;Prefs.setupComplete(false);}dispatchError(t);}
        });
    }

    /** متطلبات الفك فقط؛ لا يتوقف الفك بسبب aapt2 أو zipalign أو مترجم المصدر. */
    public static Report ensureForDecompile(Context c, Logger log) throws Exception {
        Report r=prepareBlocking(c,log);
        if(!r.canDecompile())throw new IllegalStateException("محركات الفك الأساسية غير جاهزة:\n"+r.text());
        return r;
    }

    /** متطلبات إعادة البناء السريع؛ zipalign له بديل Java دائم. */
    public static Report ensureForBuild(Context c, Logger log, boolean sourceMode) throws Exception {
        Report r=prepareBlocking(c,log);
        boolean ready=sourceMode?r.canBuildSource():r.canBuild();
        // قد يكون المستخدم ثبّت أداة من مدير الأدوات بعد فحص الإقلاع؛ أعد المسح مرة.
        if(!ready){
            synchronized(installLock){
                last=installBlocking(c.getApplicationContext(),log,null); r=last;
            }
            ready=sourceMode?r.canBuildSource():r.canBuild();
        }
        if(!ready)throw new IllegalStateException("أدوات البناء المطلوبة غير جاهزة:\n"+r.text());
        return r;
    }

    /** للتوافق مع الاستدعاءات القديمة: يكفي أن تكون محركات الفك جاهزة. */
    public static Report ensureBlocking(Context c, Logger log) throws Exception {
        return ensureForDecompile(c,log);
    }

    private static Report prepareBlocking(Context c,Logger log)throws Exception{
        synchronized(installLock){
            // إن كان التقرير صالحاً للفك نعيد الفحص فقط عند الحاجة لأداة بناء في المستدعي.
            if(last==null)last=installBlocking(c.getApplicationContext(),log,null);
            Prefs.setupComplete(last.complete());
            return last;
        }
    }

    private interface Progress {void step(String s,int p);}
    private static Report installBlocking(Context c,Logger log,Progress progress)throws Exception{
        Logger setupLog=log!=null?log:new Logger("setup");
        step(progress,"تهيئة بيئة Java الآمنة…",3);
        RuntimeBootstrap.install(c);RuntimeBootstrap.verify();

        step(progress,"فحص Apktool وNine-Patch الخاص بأندرويد…",8);
        Class.forName("brut.util.OSDetection");
        Object apktoolConfig=Class.forName("brut.androlib.Config")
                .getMethod("getDefaultConfig").invoke(null);
        if(apktoolConfig==null)throw new IllegalStateException("تعذّرت تهيئة Apktool Config");
        try {
            boolean apktoolPatched=Class.forName("brut.androlib.res.decoder.Res9patchStreamDecoder")
                    .getField("ANDROID_COMPATIBLE").getBoolean(null);
            boolean jadxPatched=Class.forName("jadx.core.utils.android.Res9patchStreamDecoder")
                    .getField("ANDROID_COMPATIBLE").getBoolean(null);
            boolean smaliPatched=Class.forName("brut.androlib.src.SmaliDecoder")
                    .getField("ANDROID_LOW_MEMORY").getBoolean(null);
            Class<?> xmlSecurity=Class.forName("jadx.core.xmlgen.XmlSecurity");
            boolean xmlPatched=xmlSecurity.getField("ANDROID_COMPATIBLE").getBoolean(null);
            Object dbf=xmlSecurity.getMethod("getDBF").invoke(null);
            boolean xmlBuilder=dbf instanceof javax.xml.parsers.DocumentBuilderFactory
                    && ((javax.xml.parsers.DocumentBuilderFactory)dbf).newDocumentBuilder()!=null;
            if(!apktoolPatched||!jadxPatched||!smaliPatched||!xmlPatched||!xmlBuilder)
                throw new IllegalStateException("Apktool/Jadx Android patches غير مفعلة");
        } catch(NoSuchFieldException desktopVersion) {
            throw new IllegalStateException(
                    "تم اكتشاف محرك مكتبي غير آمن لأندرويد؛ يلزم إصدار Android-patched",desktopVersion);
        }

        step(progress,"تجهيز مجلدات الأدوات…",12);
        Env.toolsDir().mkdirs();new File(Env.toolsDir(),"framework").mkdirs();

        ToolInstaller installer=new ToolInstaller(setupLog);
        File framework=new File(Env.toolsDir(),"framework/1.apk");
        if(!ToolchainVerifier.validApktoolFramework(framework)){
            step(progress,"تثبيت Android framework الخاص بـ Apktool…",15);
            try{
                installer.install(ToolInstaller.byId("apktool_framework"),null,
                        (message,percent)->step(progress,message,percent<0?18:15+(percent*14/100)));
            }catch(Exception networkError){
                setupLog.e("فشل التثبيت التلقائي لإطار Apktool",networkError);
            }
        }else step(progress,"Apktool framework مثبت ومتحقق منه",29);

        File androidJar=new File(Env.toolsDir(),"android.jar");
        if(!ToolchainVerifier.validAndroidJar(androidJar)){
            step(progress,"تثبيت android.jar API 34 عبر HTTPS…",30);
            try{
                installer.install(ToolInstaller.byId("android_jar"),null,
                        (message,percent)->step(progress,message,percent<0?34:30+(percent*49/100)));
            }catch(Exception networkError){
                setupLog.e("فشل التثبيت التلقائي لـ android.jar",networkError);
            }
        }else step(progress,"android.jar API 34 مثبت ومتحقق منه",79);

        // aapt2 الأساسي يبقى nativeLibrary لأن Android 10+ يمنع exec من filesDir.
        step(progress,"فحص aapt2 القابل للتنفيذ…",84);NativeTools.ensureInstalled(c);
        step(progress,"تجهيز مفتاح التوقيع…",90);KeystoreManager.ensureDebugKeystore(c);
        step(progress,"اختبار جميع محركات الفك والبناء فعلياً…",95);

        ToolchainVerifier.Snapshot s=ToolchainVerifier.inspect(c);
        Report r=new Report();
        r.jadx=s.jadx;r.apktool=s.apktool;r.ninePatch=s.androidNinePatch;
        r.lowMemorySmali=s.androidSmali;r.androidXml=s.androidXml;
        r.apktoolFramework=s.apktoolFramework;r.apksig=s.apksig;r.ecj=s.ecj;r.d8=s.d8;r.aapt2=s.aapt2;
        r.zipalignNative=s.zipalignNative;r.zipalign=s.zipalignNative||s.zipalignJava;
        r.androidJar=s.androidJar;r.keystore=s.keystore;
        setupLog.i("setup verifier:\n"+r.text().trim());
        if(!r.complete())setupLog.w("أدوات غير جاهزة: "+android.text.TextUtils.join(", ",s.missing()));
        step(progress,r.complete()?"اكتمل تثبيت وفحص جميع الأدوات":"اكتمل الفحص — توجد أدوات مفقودة",100);
        return r;
    }
    private static void step(Progress p,String s,int n){if(p!=null)p.step(s,n);}
    private static void dispatchStep(String s,int p){List<Callback>x; synchronized(SetupManager.class){x=new ArrayList<>(callbacks);}for(Callback c:x)c.onStep(s,p);}
    private static void dispatchReady(Report r){List<Callback>x; synchronized(SetupManager.class){x=new ArrayList<>(callbacks);callbacks.clear();}for(Callback c:x)c.onReady(r);}
    private static void dispatchError(Throwable t){List<Callback>x; synchronized(SetupManager.class){x=new ArrayList<>(callbacks);callbacks.clear();}for(Callback c:x)c.onError(t);}
}
