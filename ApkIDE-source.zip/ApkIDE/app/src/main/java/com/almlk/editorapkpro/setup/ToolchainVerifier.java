package com.almlk.editorapkpro.setup;

import android.content.Context;

import com.almlk.editorapkpro.compiler.D8Bridge;
import com.almlk.editorapkpro.compiler.JavaZipAligner;
import com.almlk.editorapkpro.engine.NativeTools;
import com.almlk.editorapkpro.engine.jadx.AndroidJadxPluginLoader;
import com.almlk.editorapkpro.util.Env;

import java.io.File;
import java.lang.reflect.Method;

import jadx.api.JadxArgs;
import jadx.api.JadxDecompiler;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipFile;

/**
 * فحص وظيفي مركزي لكل مكوّن مطلوب. لا يعتمد على وجود اسم ملف فقط:
 * يفحص Android Nine-Patch patch، بنية android.jar، وتشغيل aapt2 الحقيقي.
 */
public final class ToolchainVerifier {
    private ToolchainVerifier() {}

    public static final class Snapshot {
        public boolean jadx, apktool, androidNinePatch, androidSmali, androidXml, apksig, ecj, d8;
        public boolean aapt2, zipalignNative, zipalignJava, apktoolFramework, androidJar, keystore;

        public boolean canDecompile() { return jadx && apktool && androidNinePatch && androidSmali && androidXml && apktoolFramework; }
        public boolean canBuild() {
            return canDecompile() && apksig && aapt2 && zipalignJava && keystore;
        }
        public boolean canBuildSource() { return canBuild() && ecj && d8 && androidJar; }
        public boolean allRequired() { return canBuildSource(); }

        public List<String> missing() {
            List<String> m = new ArrayList<>();
            add(m, jadx, "jadx"); add(m, apktool, "apktool");
            add(m, androidNinePatch, "Android Nine-Patch");
            add(m, androidSmali, "Android low-memory Smali");
            add(m, androidXml, "Jadx XML Android");
            add(m, apktoolFramework, "Apktool framework 1.apk");
            add(m, apksig, "apksig"); add(m, ecj, "ECJ"); add(m, d8, "D8");
            add(m, aapt2, "aapt2 ARM64"); add(m, zipalignJava, "JavaZipAligner");
            add(m, androidJar, "android.jar API 34"); add(m, keystore, "مفتاح التوقيع");
            return m;
        }

        public String text() {
            return line("jadx",jadx)+line("apktool",apktool)
                    +line("Nine-Patch Android",androidNinePatch)
                    +line("Smali Android منخفض الذاكرة",androidSmali)
                    +line("Jadx XML Android",androidXml)+line("apksig",apksig)
                    +line("Apktool framework 1.apk",apktoolFramework)
                    +line("ECJ",ecj)+line("D8",d8)+line("aapt2",aapt2)
                    +"• zipalign : "+(zipalignNative?"جاهز (أصلي)":zipalignJava?"جاهز (Java)":"مفقود")+"\n"
                    +line("android.jar API 34",androidJar)+line("مفتاح التوقيع",keystore);
        }
        private static void add(List<String> out,boolean ok,String name){if(!ok)out.add(name);}
        private static String line(String name,boolean ok){return "• "+name+" : "+(ok?"جاهز":"مفقود/غير صالح")+"\n";}
    }

    public static Snapshot inspect(Context context) {
        Snapshot s = new Snapshot();
        s.jadx = jadxPluginsWork();
        s.apktool = apktoolConfigWorks();
        s.androidNinePatch = androidNinePatchWorks();
        s.androidSmali = androidSmaliWorks();
        s.androidXml = androidXmlWorks();
        s.apksig = present("com.android.apksig.ApkSigner");
        s.ecj = present("org.eclipse.jdt.internal.compiler.batch.Main");
        s.d8 = D8Bridge.available();
        s.aapt2 = executableWorks(NativeTools.tool(context, NativeTools.AAPT2), "version");
        s.zipalignNative = executableWorks(NativeTools.tool(context, NativeTools.ZIPALIGN), "-h");
        s.zipalignJava = present(JavaZipAligner.class.getName());
        s.apktoolFramework = validApktoolFramework(new File(Env.toolsDir(), "framework/1.apk"));
        s.androidJar = validAndroidJar(new File(Env.toolsDir(), "android.jar"));
        File key = new File(Env.keystoreDir(), "apkide-debug.p12");
        s.keystore = key.isFile() && key.length() > 0;
        return s;
    }

    public static boolean validApktoolFramework(File file) {
        if(file==null||!file.isFile()||file.length()<3L*1024*1024)return false;
        try(ZipFile zip=new ZipFile(file)){
            return zip.getEntry("resources.arsc")!=null&&zip.getEntry("AndroidManifest.xml")!=null;
        }catch(Exception e){return false;}
    }

    public static boolean validAndroidJar(File file) {
        if(file==null||!file.isFile()||file.length()<20L*1024*1024)return false;
        try(ZipFile zip=new ZipFile(file)){
            return zip.getEntry("android/app/Activity.class")!=null
                    && zip.getEntry("android/content/Context.class")!=null;
        }catch(Exception e){return false;}
    }

    /** يهيئ فعلياً PluginManager بنفس loader المستخدم أثناء الفك، دون تحميل APK كبير. */
    private static boolean jadxPluginsWork() {
        JadxArgs args=new JadxArgs();
        args.setPluginLoader(new AndroidJadxPluginLoader());
        try(JadxDecompiler decompiler=new JadxDecompiler(args)){
            Method loadPlugins=JadxDecompiler.class.getDeclaredMethod("loadPlugins");
            loadPlugins.setAccessible(true);
            loadPlugins.invoke(decompiler);
            return true;
        }catch(Throwable pluginError){return false;}
    }

    private static boolean apktoolConfigWorks() {
        try {
            RuntimeBootstrap.verify();
            Object config = Class.forName("brut.androlib.Config")
                    .getMethod("getDefaultConfig").invoke(null);
            return config != null;
        } catch (Throwable error) { return false; }
    }

    private static boolean androidNinePatchWorks() {
        try {
            Class<?> apktool=Class.forName("brut.androlib.res.decoder.Res9patchStreamDecoder");
            Class<?> jadx=Class.forName("jadx.core.utils.android.Res9patchStreamDecoder");
            return apktool.getField("ANDROID_COMPATIBLE").getBoolean(null)
                    && jadx.getField("ANDROID_COMPATIBLE").getBoolean(null);
        } catch (Throwable desktopDecoder) { return false; }
    }

    private static boolean androidSmaliWorks() {
        try {
            return Class.forName("brut.androlib.src.SmaliDecoder")
                    .getField("ANDROID_LOW_MEMORY").getBoolean(null);
        } catch(Throwable desktopSmali) { return false; }
    }

    /** يشغّل static initializer ويبني DocumentBuilder فعلياً على parser الخاص بالجهاز. */
    private static boolean androidXmlWorks() {
        try {
            Class<?> xml=Class.forName("jadx.core.xmlgen.XmlSecurity");
            if(!xml.getField("ANDROID_COMPATIBLE").getBoolean(null))return false;
            Object dbf=xml.getMethod("getDBF").invoke(null);
            return dbf instanceof javax.xml.parsers.DocumentBuilderFactory
                    && ((javax.xml.parsers.DocumentBuilderFactory)dbf).newDocumentBuilder()!=null;
        } catch(Throwable desktopXml) { return false; }
    }

    private static boolean present(String name){try{Class.forName(name);return true;}catch(Throwable t){return false;}}

    private static boolean executableWorks(File binary,String argument) {
        if(binary==null||!binary.isFile()||!binary.canExecute())return false;
        Process process=null;
        try {
            process=new ProcessBuilder(binary.getAbsolutePath(),argument).redirectErrorStream(true).start();
            // تفريغ المخرجات في خيط مستقل كي لا يمتلئ pipe ولا يتوقف الفحص.
            final Process running=process;
            Thread drain=new Thread(()->{try(InputStream in=running.getInputStream()){byte[]b=new byte[2048];while(in.read(b)!=-1){}}catch(Exception ignored){}},"tool-probe");
            drain.setDaemon(true);drain.start();
            boolean ended=process.waitFor(12,TimeUnit.SECONDS);
            if(!ended)process.destroyForcibly();
            return ended; // help/version قد يعيد كوداً غير صفري، لكن exec نفسه نجح.
        }catch(Throwable error){return false;}
        finally{if(process!=null)try{process.destroy();}catch(Exception ignored){}}
    }
}
