package com.almlk.editorapkpro.meta;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.TaskCallback;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.regex.Pattern;

/**
 * تغيير اسم الحزمة وتطبيقه على كامل المشروع:
 *  - AndroidManifest.xml  (package + أسماء المكوّنات النسبية + authorities)
 *  - كل ملفات .java / .kt (تصريح package و import و النصوص الحرفية)
 *  - كل ملفات .smali (المسارات Lcom/old/pkg/…)
 *  - بنية المجلدات: java/com/old/pkg -> java/com/new/pkg
 *  - build.gradle (namespace / applicationId) و res/xml (authorities)
 */
public final class PackageRenamer {

    private PackageRenamer() {}

    public static class Result {
        public int filesChanged, dirsMoved;
    }

    public static Result rename(Project p, String newPkg, Logger log, TaskCallback<?> cb)
            throws Exception {

        String oldPkg = p.packageName;
        if (oldPkg == null || oldPkg.equals(newPkg)) return new Result();
        if (!newPkg.matches("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z][a-zA-Z0-9_]*)+"))
            throw new IllegalArgumentException("اسم حزمة غير صالح: " + newPkg);

        log.i("rename: " + oldPkg + "  ->  " + newPkg);
        Result r = new Result();

        String oldSlash = oldPkg.replace('.', '/');
        String newSlash = newPkg.replace('.', '/');
        String oldSmali = "L" + oldSlash;
        String newSmali = "L" + newSlash;

        Pattern pDot   = Pattern.compile(Pattern.quote(oldPkg));
        Pattern pSlash = Pattern.compile(Pattern.quote(oldSlash));
        Pattern pSmali = Pattern.compile(Pattern.quote(oldSmali));

        /* 1) استبدال النصوص داخل كل الملفات النصية المعنية */
        List<File> files = FileUtil.walk(p.root(),
                "java", "kt", "smali", "xml", "gradle", "pro", "properties", "json", "txt");
        int i = 0;
        for (File f : files) {
            i++;
            if (cb != null && i % 200 == 0)
                cb.onProgress("تحديث الملفات " + i + "/" + files.size(),
                        (int) (i * 90L / files.size()));
            try {
                String txt = new String(FileUtil.readBytes(f), StandardCharsets.UTF_8);
                String mod = txt;
                if ("smali".equals(FileUtil.ext(f.getName()))) {
                    mod = pSmali.matcher(mod).replaceAll(newSmali);
                    mod = pDot.matcher(mod).replaceAll(newPkg);
                } else {
                    mod = pDot.matcher(mod).replaceAll(newPkg);
                    mod = pSlash.matcher(mod).replaceAll(newSlash);
                }
                if (!mod.equals(txt)) { FileUtil.write(f, mod); r.filesChanged++; }
            } catch (Exception ignored) {}
        }

        /* 2) نقل بنية المجلدات في مصادر Java/Kotlin و smali */
        r.dirsMoved += movePackageDir(p.javaDir(), oldSlash, newSlash);
        File rebuild = new File(p.metaDir(), "rebuild");
        if (rebuild.exists()) {
            File[] smaliRoots = rebuild.listFiles(
                    f -> f.isDirectory() && f.getName().startsWith("smali"));
            if (smaliRoots != null)
                for (File s : smaliRoots) r.dirsMoved += movePackageDir(s, oldSlash, newSlash);
        }

        p.packageName = newPkg;
        ProjectManager.save(p);
        log.i("rename: تم تعديل " + r.filesChanged + " ملف ونقل " + r.dirsMoved + " مجلد");
        if (cb != null) cb.onProgress("اكتمل", 100);
        return r;
    }

    private static int movePackageDir(File srcRoot, String oldSlash, String newSlash) throws Exception {
        File from = new File(srcRoot, oldSlash);
        if (!from.exists()) return 0;
        File to = new File(srcRoot, newSlash);
        to.getParentFile().mkdirs();
        if (!from.renameTo(to)) { FileUtil.copyDir(from, to); FileUtil.delete(from); }
        pruneEmpty(srcRoot);
        return 1;
    }

    private static void pruneEmpty(File dir) {
        File[] k = dir.listFiles();
        if (k == null) return;
        for (File f : k) if (f.isDirectory()) pruneEmpty(f);
        File[] after = dir.listFiles();
        if (after != null && after.length == 0) //noinspection ResultOfMethodCallIgnored
            dir.delete();
    }
}
