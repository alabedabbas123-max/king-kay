package com.almlk.editorapkpro.project;

import com.almlk.editorapkpro.util.XmlUtil;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.File;

/** قراءة القيم المهمة من AndroidManifest.xml المفكوك. */
public class ManifestReader {

    public String  packageName = "com.unknown.app";
    public String  versionName = "1.0";
    public int     versionCode = 1;
    public int     minSdk      = 21;
    public int     targetSdk   = 33;
    public String  appLabel;
    public String  launcherActivity;

    public static ManifestReader read(File manifest, File apktoolYml) {
        ManifestReader m = new ManifestReader();
        try {
            Document d = XmlUtil.parse(manifest);
            Element root = d.getDocumentElement();
            String pkg = root.getAttribute("package");
            if (pkg != null && !pkg.isEmpty()) m.packageName = pkg;
            String vc = XmlUtil.attr(root, "versionCode");
            String vn = XmlUtil.attr(root, "versionName");
            if (vc != null && vc.matches("\\d+")) m.versionCode = Integer.parseInt(vc);
            if (vn != null && !vn.isEmpty())      m.versionName = vn;

            NodeList uses = d.getElementsByTagName("uses-sdk");
            if (uses.getLength() > 0) {
                Element u = (Element) uses.item(0);
                String min = XmlUtil.attr(u, "minSdkVersion");
                String tgt = XmlUtil.attr(u, "targetSdkVersion");
                if (min != null && min.matches("\\d+")) m.minSdk    = Integer.parseInt(min);
                if (tgt != null && tgt.matches("\\d+")) m.targetSdk = Integer.parseInt(tgt);
            }
            NodeList apps = d.getElementsByTagName("application");
            if (apps.getLength() > 0) m.appLabel = XmlUtil.attr((Element) apps.item(0), "label");

            NodeList acts = d.getElementsByTagName("activity");
            outer:
            for (int i = 0; i < acts.getLength(); i++) {
                Element a = (Element) acts.item(i);
                NodeList f = a.getElementsByTagName("category");
                for (int j = 0; j < f.getLength(); j++) {
                    if ("android.intent.category.LAUNCHER"
                            .equals(XmlUtil.attr((Element) f.item(j), "name"))) {
                        m.launcherActivity = XmlUtil.attr(a, "name");
                        break outer;
                    }
                }
            }
        } catch (Exception ignored) {}

        // apktool.yml يحوي minSdk/targetSdk و versionInfo بدقة أكبر
        if (apktoolYml != null && apktoolYml.exists()) {
            try {
                String y = com.almlk.editorapkpro.util.FileUtil.read(apktoolYml);
                m.minSdk      = yamlInt(y, "minSdkVersion", m.minSdk);
                m.targetSdk   = yamlInt(y, "targetSdkVersion", m.targetSdk);
                m.versionCode = yamlInt(y, "versionCode", m.versionCode);
                String vn = yamlStr(y, "versionName");
                if (vn != null) m.versionName = vn;
            } catch (Exception ignored) {}
        }
        return m;
    }

    private static int yamlInt(String yaml, String key, int def) {
        String v = yamlStr(yaml, key);
        try { return v == null ? def : Integer.parseInt(v.trim()); } catch (Exception e) { return def; }
    }

    private static String yamlStr(String yaml, String key) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?m)^\\s*" + key + ":\\s*'?\"?([^'\"\\n]+)'?\"?\\s*$").matcher(yaml);
        return m.find() ? m.group(1).trim() : null;
    }
}
