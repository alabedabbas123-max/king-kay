package com.almlk.editorapkpro.util;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import com.almlk.editorapkpro.model.AppInfo;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** جلب قائمة التطبيقات المثبتة مع كل بيانات الحزمة. */
public final class AppScanner {

    private AppScanner() {}

    public static List<AppInfo> scan(Context c, boolean includeSystem) {
        PackageManager pm = c.getPackageManager();
        List<PackageInfo> pkgs = pm.getInstalledPackages(0);
        List<AppInfo> out = new ArrayList<>(pkgs.size());
        for (PackageInfo pi : pkgs) {
            ApplicationInfo ai = pi.applicationInfo;
            if (ai == null) continue;
            boolean sys = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
            if (sys && !includeSystem) continue;

            AppInfo a = new AppInfo();
            a.label       = String.valueOf(pm.getApplicationLabel(ai));
            a.packageName = pi.packageName;
            a.versionName = pi.versionName == null ? "-" : pi.versionName;
            a.versionCode = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            a.sourceApk   = ai.sourceDir;
            a.splitApks   = ai.splitSourceDirs;
            a.system      = sys;
            a.minSdk      = Build.VERSION.SDK_INT >= 24 ? ai.minSdkVersion : 0;
            a.targetSdk   = ai.targetSdkVersion;
            try { a.apkSize = new File(ai.sourceDir).length(); } catch (Exception ignored) {}
            a.buildHaystack();
            out.add(a);
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }

    public static Intent launchIntent(Context c, String pkg) {
        return c.getPackageManager().getLaunchIntentForPackage(pkg);
    }
}
