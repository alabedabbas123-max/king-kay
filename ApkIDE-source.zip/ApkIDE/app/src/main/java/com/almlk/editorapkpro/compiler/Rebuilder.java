package com.almlk.editorapkpro.compiler;

import android.content.Context;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.NativeTools;
import com.almlk.editorapkpro.engine.TaskCallback;
import com.almlk.editorapkpro.engine.apktool.ApktoolEngine;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.BuildArtifactCleaner;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.setup.SetupManager;
import java.io.File;

/** مسارا إعادة البناء: سريع من smali/موارد، أو من Java عبر ECJ + D8. */
public class Rebuilder {
    public enum Mode { FAST, SOURCE }
    private final Context ctx; private final Logger log;
    public Rebuilder(Context c, Logger l) { ctx=c; log=l; }

    public File rebuild(Project p, Mode mode, TaskCallback<File> cb) throws Exception {
        SetupManager.ensureForBuild(ctx, log, mode == Mode.SOURCE);
        cleanProjectBuildArtifacts(p);
        File stage = null;
        File work = null;
        try {
            stage = prepareStage(p, cb);
            cleanStageBuildArtifacts(stage);
            if (mode == Mode.SOURCE) {
                step(cb, "تصريف Java (ECJ)…", 22);
                File dex = new SourceCompiler(log).compile(p);
                try {
                    // احذف DEX الأصلية عند البناء من المصدر
                    File[] old = stage.listFiles((d,n)->n.matches("classes(\\d*)\\.dex"));
                    if (old != null) for (File f : old) FileUtil.delete(f);
                    FileUtil.copyDir(dex, new File(stage, "classes.dex"));
                } finally {
                    deleteOwningTemp(dex);
                }
            }
            File aapt2 = NativeTools.tool(ctx, NativeTools.AAPT2);
            if (aapt2 == null) throw new IllegalStateException(
                    "aapt2 غير مثبّت. افتح «الأدوات ولينكس» وثبّت نسخة "
                            + android.os.Build.SUPPORTED_ABIS[0]);
            System.setProperty("apkide.aapt2", aapt2.getAbsolutePath());
            work = Env.newTmp("rebuild");
            File unsigned = new File(work, "unsigned.apk");
            step(cb, "بناء الموارد وAPK (apktool/aapt2)…", 48);
            new ApktoolEngine(log).build(stage, unsigned, new File(Env.toolsDir(), "framework"));

            File aligned = new File(work, "aligned.apk");
            File za = NativeTools.tool(ctx, NativeTools.ZIPALIGN);
            boolean nativeAligned = false;
            if (za != null) {
                step(cb, "محاذاة APK (zipalign الأصلي)…", 78);
                try {
                    int code = NativeTools.exec(za, work, log, "-f", "4",
                            unsigned.getAbsolutePath(), aligned.getAbsolutePath());
                    nativeAligned = code == 0 && aligned.exists() && aligned.length() > 0;
                    if (!nativeAligned) log.w("zipalign الأصلي أعاد " + code + "؛ استخدام بديل Java تلقائياً");
                } catch (Throwable error) {
                    log.w("تعذّر تشغيل zipalign الأصلي: " + error.getMessage()
                            + " — استخدام بديل Java");
                }
            }
            if (!nativeAligned) {
                step(cb, "محاذاة APK (المحاذي الداخلي Java)…", 82);
                JavaZipAligner.align(unsigned, aligned, 4, log);
            }

            step(cb, "توقيع APK…", 90);
            File out = new File(Env.outputDir(), p.name + "_signed_" + System.currentTimeMillis() + ".apk");
            File ks = KeystoreManager.ensureDebugKeystore(ctx);
            ApkSignerTool.sign(aligned, out, ks, KeystoreManager.PASSWORD, KeystoreManager.ALIAS, log);
            step(cb, "اكتمل البناء وتنظيف جميع المخلفات", 100);
            return out;
        } finally {
            if (work != null) FileUtil.delete(work);
            if (stage != null) {
                cleanStageBuildArtifacts(stage);
                if(mode==Mode.SOURCE)deleteStageDexArtifacts(stage);
            }
            cleanProjectBuildArtifacts(p);
        }
    }

    private File prepareStage(Project p, TaskCallback<File> cb) throws Exception {
        step(cb, "مزامنة تعديلات المشروع…", 8);
        if (p.mode == Project.MODE_RESOURCES) return p.root();
        File stage = new File(p.metaDir(), "rebuild");
        if (!stage.exists()) throw new IllegalStateException(
                "نسخة إعادة البناء `.apkide/rebuild` غير موجودة؛ أعد فك التطبيق.");
        File main = p.mainDir();
        sync(new File(main,"res"), new File(stage,"res"));
        sync(new File(main,"assets"), new File(stage,"assets"));
        sync(new File(main,"jniLibs"), new File(stage,"lib"));
        FileUtil.copyDir(new File(main,"AndroidManifest.xml"), new File(stage,"AndroidManifest.xml"));
        return stage;
    }

    /** احذف النواتج والكاش والمجلدات الفارغة فقط، ولا تلمس ملفات المصدر الأصلية. */
    private void cleanProjectBuildArtifacts(Project p){
        try{
            BuildArtifactCleaner.clean(p,log,null);
        }catch(Exception error){
            // فشل التنظيف لا يحوّل مشروعاً صالحاً إلى فشل بناء؛ ستكتب الأدوات فوق نواتجها.
            log.w("تعذّر إكمال التنظيف الآمن: "+error.getMessage());
        }
    }

    /** Apktool يترك build/ وdist/ داخل نسخة إعادة البناء؛ احذفهما في النجاح والفشل. */
    private void cleanStageBuildArtifacts(File stage){
        if(stage==null)return;
        FileUtil.delete(new File(stage,"build"));
        FileUtil.delete(new File(stage,"dist"));
    }

    private void deleteStageDexArtifacts(File stage){
        File[] dex=stage.listFiles((d,n)->n.matches("classes(\\d*)?\\.dex"));
        if(dex!=null)for(File f:dex)FileUtil.delete(f);
    }

    /** احذف مجلد source_compile المؤقت بعد نسخ classes.dex فقط. */
    private void deleteOwningTemp(File file){
        if(file==null)return;
        try{
            File tmp=Env.tmpDir().getCanonicalFile();
            File cur=file.getCanonicalFile();
            while(cur.getParentFile()!=null&&!cur.getParentFile().equals(tmp))cur=cur.getParentFile();
            if(cur.getParentFile()!=null&&cur.getParentFile().equals(tmp))FileUtil.delete(cur);
        }catch(Exception ignored){}
    }

    private void sync(File src, File dst) throws Exception {
        FileUtil.delete(dst);
        if (src.exists()) FileUtil.copyDir(src,dst);
    }
    private void step(TaskCallback<?> cb,String s,int p){ log.i(s); if(cb!=null)cb.onProgress(s,p); }
}
