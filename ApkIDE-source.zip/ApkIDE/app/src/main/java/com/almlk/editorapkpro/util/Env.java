package com.almlk.editorapkpro.util;

import android.content.Context;
import java.io.File;

/** كل مسارات العمل في مكان واحد. */
public final class Env {

    private static File root, projects, tmp, tools, output, keystore, logs;

    private Env() {}

    public static void init(Context c) {
        File base = c.getExternalFilesDir(null);
        if (base == null) base = c.getFilesDir();
        root     = mk(new File(base, "ApkIDE"));
        projects = mk(new File(root, "projects"));
        output   = mk(new File(root, "output"));
        logs     = mk(new File(root, "logs"));
        keystore = mk(new File(root, "keystore"));
        tools    = mk(new File(c.getFilesDir(), "tools"));
        tmp      = mk(new File(c.getCacheDir(), "tmp"));
    }

    private static File mk(File f) { if (!f.exists()) f.mkdirs(); return f; }

    public static File rootDir()      { return root; }
    public static File projectsDir()  { return projects; }
    public static File outputDir()    { return output; }
    public static File logsDir()      { return logs; }
    public static File keystoreDir()  { return keystore; }
    public static File toolsDir()     { return tools; }
    public static File tmpDir()       { return mk(tmp); }

    public static File projectDir(String name) { return new File(projects, name); }

    /** مجلد فرعي مؤقت فريد. */
    public static File newTmp(String prefix) {
        return mk(new File(tmpDir(), prefix + "_" + System.currentTimeMillis()));
    }
}
