package com.almlk.editorapkpro.ui;

import android.os.Bundle;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.Prefs;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.slider.Slider;

public class SettingsActivity extends AppCompatActivity {

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_settings);

        MaterialSwitch night  = findViewById(R.id.swNight);
        MaterialSwitch deobf  = findViewById(R.id.swDeobf);
        MaterialSwitch clean  = findViewById(R.id.swClean);
        MaterialSwitch ids    = findViewById(R.id.swIds);
        MaterialSwitch kotlin = findViewById(R.id.swKotlin);
        MaterialSwitch comp   = findViewById(R.id.swComplete);
        MaterialSwitch close  = findViewById(R.id.swAutoClose);
        Slider threads        = findViewById(R.id.sliderThreads);
        TextView txtThreads   = findViewById(R.id.txtThreads);
        TextView txtPaths     = findViewById(R.id.txtPaths);

        night.setChecked(Prefs.nightMode() == AppCompatDelegate.MODE_NIGHT_YES);
        deobf.setChecked(Prefs.deobfuscation());
        clean.setChecked(Prefs.cleanProject());
        ids.setChecked(Prefs.keepResIds());
        kotlin.setChecked(Prefs.decompileKotlin());
        comp.setChecked(Prefs.autoComplete());
        close.setChecked(Prefs.autoClose());
        threads.setValue(Math.min(16, Math.max(1, Prefs.threads())));
        txtThreads.setText("عدد خيوط الفك: " + Prefs.threads());

        night.setOnCheckedChangeListener((b, c) -> {
            int m = c ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO;
            Prefs.nightMode(m);
            AppCompatDelegate.setDefaultNightMode(m);
        });
        deobf.setOnCheckedChangeListener((b, c)  -> Prefs.deobfuscation(c));
        clean.setOnCheckedChangeListener((b, c)  -> Prefs.cleanProject(c));
        ids.setOnCheckedChangeListener((b, c)    -> Prefs.keepResIds(c));
        kotlin.setOnCheckedChangeListener((b, c) -> Prefs.decompileKotlin(c));
        comp.setOnCheckedChangeListener((b, c)   -> Prefs.autoComplete(c));
        close.setOnCheckedChangeListener((b, c)  -> Prefs.autoClose(c));
        findViewById(R.id.btnEditorSettings).setOnClickListener(v->
                startActivity(new android.content.Intent(this,EditorSettingsActivity.class)));
        threads.addOnChangeListener((sl, v, u) -> {
            Prefs.threads((int) v);
            txtThreads.setText("عدد خيوط الفك: " + (int) v);
        });

        txtPaths.setText("المشاريع: " + Env.projectsDir().getAbsolutePath()
                + "\nالمخرجات: " + Env.outputDir().getAbsolutePath()
                + "\nالأدوات: " + Env.toolsDir().getAbsolutePath()
                + "\nمفاتيح التوقيع: " + Env.keystoreDir().getAbsolutePath()
                + "\nالسجلات: " + Env.logsDir().getAbsolutePath());
    }
}
