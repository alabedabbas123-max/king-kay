package com.almlk.editorapkpro.engine;

import android.content.Context;
import android.os.Build;

import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * إدارة أدوات ELF التي لا يمكن تنفيذها بثقة من التخزين القابل للكتابة في Android 10+.
 * aapt2 الضروري فقط مشحون كـ libaapt2.so داخل jniLibs ليضعه النظام في nativeLibraryDir.
 * zipalign الأصلي غير مشحون لتقليل الحجم؛ JavaZipAligner هو البديل الافتراضي الدائم.
 * تبقى الملفات الاختيارية التي يختارها المستخدم في filesDir مساراً ثانوياً للأجهزة التي تسمح به.
 */
public final class NativeTools {

    public static final String AAPT2    = "aapt2";
    public static final String ZIPALIGN = "zipalign";

    private static volatile boolean installed = false;
    private static String nativeLibDir;

    private NativeTools() {}

    public static synchronized void ensureInstalled(Context c) {
        if (installed) return;
        nativeLibDir = c.getApplicationInfo().nativeLibraryDir;
        try { extractFromAssets(c, AAPT2); } catch (IOException ignored) {}
        installed = true;
    }

    /** يعيد ملف الأداة القابل للتنفيذ أو null إن لم تكن متوفرة. */
    public static File tool(Context c, String name) {
        ensureInstalled(c);
        File jni = new File(nativeLibDir, "lib" + name + ".so");
        if (jni.exists() && jni.canExecute()) return jni;
        File ext = new File(Env.toolsDir(), name);
        if (ext.exists() && ext.canExecute()) return ext;
        return null;
    }

    public static boolean isAvailable(Context c, String name) { return tool(c, name) != null; }

    private static void extractFromAssets(Context c, String name) throws IOException {
        File out = new File(Env.toolsDir(), name);
        if (out.exists() && out.canExecute()) return;
        String abi = primaryAbi();
        String path = "tools/" + abi + "/" + name;
        try (InputStream in = c.getAssets().open(path)) {
            FileUtil.copy(in, out);
        } catch (IOException e) {
            return; // غير مشحونة لهذه المعمارية — سنستخدم مسار jniLibs
        }
        //noinspection ResultOfMethodCallIgnored
        out.setExecutable(true, false);
        //noinspection ResultOfMethodCallIgnored
        out.setReadable(true, false);
    }

    public static String primaryAbi() {
        String[] abis = Build.SUPPORTED_ABIS;
        return abis != null && abis.length > 0 ? abis[0] : "armeabi-v7a";
    }

    /** تنفيذ أداة أصلية وإرجاع كود الخروج مع دفع المخرجات إلى السجل. */
    public static int exec(File binary, List<String> args, File workDir, Logger log)
            throws IOException, InterruptedException {
        List<String> cmd = new ArrayList<>();
        cmd.add(binary.getAbsolutePath());
        cmd.addAll(args);
        log.i("$ " + String.join(" ", cmd));
        ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true);
        if (workDir != null) pb.directory(workDir);
        pb.environment().put("TMPDIR", Env.tmpDir().getAbsolutePath());
        Process p = pb.start();
        try (java.io.BufferedReader r = new java.io.BufferedReader(
                new java.io.InputStreamReader(p.getInputStream()))) {
            String l;
            while ((l = r.readLine()) != null) log.i("  " + l);
        }
        int code = p.waitFor();
        log.i("exit=" + code);
        return code;
    }

    public static int exec(File binary, File workDir, Logger log, String... args)
            throws IOException, InterruptedException {
        return exec(binary, Arrays.asList(args), workDir, log);
    }
}
