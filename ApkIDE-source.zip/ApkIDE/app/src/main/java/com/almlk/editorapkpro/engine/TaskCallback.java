package com.almlk.editorapkpro.engine;

/** واجهة موحّدة لكل العمليات الطويلة (فك، بناء، ضغط…). */
public interface TaskCallback<T> {
    default void onStart(String title) {}
    /** percent = -1 يعني تقدم غير محدد. */
    default void onProgress(String step, int percent) {}
    void onSuccess(T result);
    void onError(Throwable error);
}
