package com.almlk.editorapkpro.ui;

import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.libs.LibraryManager;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** واجهة تثبيت مكتبات Maven بكل إصداراتها أو ملفات AAR/JAR محلية. */
public class LibrariesActivity extends AppCompatActivity {

    private Project project;
    private LibraryManager manager;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private EditText coordinate;
    private Spinner versions;
    private TextView status, installed;
    private Ui.ActivityBusy topBusy;
    private MaterialButton install;
    private List<String> versionList = new ArrayList<>();

    private final ActivityResultLauncher<String[]> picker = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), this::pickedLocal);

    @Override protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        project = ProjectManager.load(new File(getIntent().getStringExtra("dir")));
        if (project == null) { finish(); return; }
        manager = new LibraryManager(new Logger("libraries"));
        setContentView(content());
        topBusy=new Ui.ActivityBusy(this);
        refreshInstalled();
    }

    private View content() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL); page.setBackgroundColor(0xFF0D1117);
        MaterialToolbar tb = new MaterialToolbar(this);
        tb.setNavigationIcon(R.drawable.ic_close); tb.setNavigationOnClickListener(v -> finish());
        tb.setTitle("مدير المكتبات"); tb.setSubtitle("كل الإصدارات • Maven / Google / JitPack");
        tb.setTitleTextColor(0xFFF0F3F6);tb.setSubtitleTextColor(0xFF9AA7B4);tb.setBackgroundColor(0xFF161B22);
        page.addView(tb, lp(-1, dp(60)));

        ScrollView sv = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(16),dp(12),dp(16),dp(32));
        sv.addView(box);

        box.addView(title("تثبيت من مستودع Maven"));
        TextView help = text("اكتب group:artifact (مثال: com.google.android.material:material)، ثم اختر أي إصدار متاح.", 12, 0xFF9AA7B4);
        box.addView(help);
        coordinate = new EditText(this); coordinate.setHint("group:artifact أو group:artifact:version");
        coordinate.setTextColor(0xFFF0F3F6);coordinate.setHintTextColor(0xFF6E7681);coordinate.setSingleLine(true);
        box.addView(coordinate, lp(-1,dp(52)));

        LinearLayout row = new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
        versions = new Spinner(this); setVersions(new ArrayList<>());
        row.addView(versions,new LinearLayout.LayoutParams(0,dp(52),1));
        MaterialButton query = button("جلب الإصدارات"); query.setOnClickListener(v->fetchVersions());
        row.addView(query,lp(dp(132),dp(48))); box.addView(row);

        install=button("تثبيت الإصدار المحدد");install.setEnabled(false);install.setOnClickListener(v->installMaven());
        box.addView(install,lp(-1,dp(48)));
        status=text("جاهز",12,0xFF79C0FF);status.setPadding(0,dp(8),0,dp(12));box.addView(status);

        LinearLayout localRow=new LinearLayout(this);localRow.setGravity(Gravity.CENTER_VERTICAL);
        MaterialButton local=button("إضافة AAR / JAR محلي");local.setOnClickListener(v->picker.launch(new String[]{"application/java-archive","application/zip","application/octet-stream"}));
        localRow.addView(local,new LinearLayout.LayoutParams(0,dp(48),1));
        MaterialButton popular=button("مكتبات شائعة");popular.setOnClickListener(v->showPopular());
        localRow.addView(popular,new LinearLayout.LayoutParams(0,dp(48),1)); box.addView(localRow);

        box.addView(title("المكتبات المثبتة"));
        installed=text("",12,0xFFD8DEE4);installed.setTypeface(android.graphics.Typeface.MONOSPACE);installed.setPadding(dp(8),dp(8),dp(8),dp(8));
        installed.setBackgroundColor(0xFF161B22);installed.setOnClickListener(v->manageInstalled());box.addView(installed,lp(-1,-2));
        TextView note=text("اضغط قائمة المكتبات لحذف ملف. ملفات AAR تُفك وتُدمج مواردها وassets وJNI تلقائياً، ويُضاف الاعتماد إلى app/build.gradle.",11,0xFF8B949E);
        note.setPadding(0,dp(8),0,0);box.addView(note);
        page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        return page;
    }

    private void fetchVersions() {
        String raw=coordinate.getText().toString().trim();
        if(raw.isEmpty()){coordinate.setError("أدخل اسم المكتبة");return;}
        LibraryManager.Coordinate c;
        try{c=LibraryManager.Coordinate.parse(raw);}catch(Exception e){coordinate.setError(e.getMessage());return;}
        if(c.version!=null&&!c.version.isEmpty()){
            versionList=new ArrayList<>();versionList.add(c.version);setVersions(versionList);install.setEnabled(true);status.setText("الإصدار محدد في الاسم");return;
        }
        status.setText("جارٍ الاتصال بالمستودعات…");install.setEnabled(false);
        topBusy.show("جلب إصدارات المكتبة…");
        worker.execute(()->{
            List<String> v=manager.fetchVersions(c);
            runOnUiThread(()->{
                topBusy.hide();versionList=v;setVersions(v);install.setEnabled(!v.isEmpty());
                status.setText(v.isEmpty()?"لم يُعثر على إصدارات":"تم العثور على "+v.size()+" إصدار — الأحدث أولاً");
            });
        });
    }

    private void installMaven() {
        if(versionList.isEmpty())return;
        LibraryManager.Coordinate c;
        try{c=LibraryManager.Coordinate.parse(coordinate.getText().toString());}catch(Exception e){Ui.error(this,e);return;}
        c.version=versionList.get(versions.getSelectedItemPosition());
        topBusy.show("تثبيت "+c.artifact+"…");
        Ui.Progress p=new Ui.Progress(this,"تثبيت "+c.artifact).show();
        worker.execute(()->{
            try{
                LibraryManager.InstallResult r=manager.install(project,c,(s,n)->runOnUiThread(()->{
                    topBusy.update(s);p.update(s,n);
                }));
                runOnUiThread(()->{
                    topBusy.hide();p.dismiss();status.setText("ثُبّتت "+r.gradleLine+" من "+r.repoUsed);
                    refreshInstalled();Ui.toast(this,"اكتمل تثبيت المكتبة");
                });
            }catch(Exception e){runOnUiThread(()->{topBusy.hide();p.dismiss();Ui.error(this,e);});}
        });
    }

    private void pickedLocal(Uri uri) {
        if(uri==null)return;
        topBusy.show("تثبيت مكتبة محلية…");
        Ui.Progress p=new Ui.Progress(this,"تثبيت مكتبة محلية").show();
        worker.execute(()->{
            try{
                File f=FileUtil.importUri(getContentResolver(),uri,Env.tmpDir());
                manager.installLocal(project,f,(s,n)->runOnUiThread(()->{
                    topBusy.update(s);p.update(s,n);
                }));
                FileUtil.delete(f);
                runOnUiThread(()->{topBusy.hide();p.dismiss();refreshInstalled();Ui.toast(this,"أُضيفت المكتبة");});
            }catch(Exception e){runOnUiThread(()->{topBusy.hide();p.dismiss();Ui.error(this,e);});}
        });
    }

    private void showPopular() {
        String[] names=new String[LibraryManager.POPULAR.length];
        for(int i=0;i<names.length;i++)names[i]=LibraryManager.POPULAR[i][0]+"\n"+LibraryManager.POPULAR[i][1];
        new MaterialAlertDialogBuilder(this).setTitle("مكتبات شائعة")
                .setItems(names,(d,w)->{coordinate.setText(LibraryManager.POPULAR[w][0]);fetchVersions();}).show();
    }

    private void refreshInstalled(){
        List<File> l=manager.installed(project);StringBuilder s=new StringBuilder();
        if(l.isEmpty())s.append("لا توجد مكتبات محلية");
        else for(File f:l)s.append("• ").append(f.getName()).append("   ").append(FileUtil.humanSize(f.length())).append('\n');
        if(installed!=null)installed.setText(s);
    }

    private void manageInstalled(){
        List<File> l=manager.installed(project);if(l.isEmpty())return;
        String[] n=new String[l.size()];for(int i=0;i<n.length;i++)n[i]=l.get(i).getName();
        new MaterialAlertDialogBuilder(this).setTitle("حذف مكتبة")
                .setItems(n,(d,w)->new MaterialAlertDialogBuilder(this).setTitle("حذف "+n[w]+"؟")
                        .setNegativeButton("إلغاء",null).setPositiveButton("حذف",(x,y)->{manager.remove(project,l.get(w));refreshInstalled();}).show()).show();
    }

    private void setVersions(List<String> v){versions.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,v.isEmpty()?new String[]{"اختر المكتبة أولاً"}:v.toArray(new String[0])));}
    private TextView title(String s){TextView t=text(s,18,0xFFF0F3F6);t.setTypeface(null,android.graphics.Typeface.BOLD);t.setPadding(0,dp(18),0,dp(8));return t;}
    private TextView text(String s,int z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private MaterialButton button(String s){MaterialButton b=new MaterialButton(this);b.setText(s);b.setTextSize(11);return b;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override protected void onDestroy(){worker.shutdownNow();super.onDestroy();}
}
