package com.almlk.editorapkpro.ui.adapter;

import android.graphics.Typeface;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.problems.Problem;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** محوّل لوحة الأخطاء: يجمع المشكلات حسب الملف مثل AIDE. */
public class ProblemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public interface Listener { void onProblem(Problem p); }
    private static class Row { String file; int count; Problem problem; }
    private static class Holder extends RecyclerView.ViewHolder{
        final TextView title,detail;
        Holder(LinearLayout box,TextView title,TextView detail){super(box);this.title=title;this.detail=detail;}
    }
    private final List<Row> rows=new ArrayList<>();
    private final Listener listener;
    public ProblemAdapter(Listener l){listener=l;}

    public void set(List<Problem> problems){
        rows.clear();Map<String,List<Problem>> grouped=new LinkedHashMap<>();
        for(Problem p:problems)grouped.computeIfAbsent(p.title(),k->new ArrayList<>()).add(p);
        for(Map.Entry<String,List<Problem>> e:grouped.entrySet()){
            Row h=new Row();h.file=e.getKey();h.count=e.getValue().size();rows.add(h);
            for(Problem p:e.getValue()){Row r=new Row();r.problem=p;rows.add(r);}
        }notifyDataSetChanged();
    }
    @Override public int getItemViewType(int p){return rows.get(p).problem==null?0:1;}
    @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent,int type){
        LinearLayout box=new LinearLayout(parent.getContext());box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(parent, type==0?14:38),dp(parent,type==0?9:7),dp(parent,12),dp(parent,type==0?7:8));
        box.setBackgroundColor(type==0?0xFF161B22:0xFF10151B);
        TextView a=new TextView(parent.getContext());a.setTextSize(type==0?15:13);a.setTextColor(type==0?0xFFE6EDF3:0xFFFF7B72);a.setTypeface(type==0?Typeface.DEFAULT_BOLD:Typeface.DEFAULT);box.addView(a);
        TextView b=new TextView(parent.getContext());b.setTextSize(11);b.setTextColor(0xFF9AA7B4);b.setPadding(0,dp(parent,2),0,0);box.addView(b);
        return new Holder(box,a,b);
    }
    @Override public void onBindViewHolder(RecyclerView.ViewHolder h,int pos){
        Row r=rows.get(pos);Holder holder=(Holder)h;TextView a=holder.title,b=holder.detail;
        if(r.problem==null){a.setText("▾  "+r.file);b.setText(r.count+" مشكلة");h.itemView.setOnClickListener(null);}
        else {Problem p=r.problem;a.setText((p.severity==Problem.ERROR?"✕  ":p.severity==Problem.WARNING?"⚠  ":"ⓘ  ")+p.message);a.setTextColor(p.color());b.setText((p.tool==null?"":p.tool)+(p.line>0?" • السطر "+p.line:"")+(p.file!=null?" • اضغط للانتقال":""));h.itemView.setOnClickListener(v->listener.onProblem(p));}
    }
    @Override public int getItemCount(){return rows.size();}
    private int dp(ViewGroup p,int x){return(int)(x*p.getResources().getDisplayMetrics().density+.5f);}
}
