package com.almlk.editorapkpro.ui;

import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.TaskCallback;
import com.almlk.editorapkpro.meta.MetadataEditor;
import com.almlk.editorapkpro.meta.PackageRenamer;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;

/** تعديل الهوية: اسم الحزمة، اسم التطبيق، رقم واسم الإصدار. */
public class MetaEditorActivity extends AppCompatActivity {

    private Project p;
    private TextInputEditText edtPackage, edtAppName, edtVerCode, edtVerName;
    private ProgressBar progress;
    private Ui.ActivityBusy topBusy;

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_meta_editor);
        p = ProjectManager.load(new File(getIntent().getStringExtra("dir")));
        if (p == null) { finish(); return; }

        edtPackage = findViewById(R.id.edtPackage);
        edtAppName = findViewById(R.id.edtAppName);
        edtVerCode = findViewById(R.id.edtVerCode);
        edtVerName = findViewById(R.id.edtVerName);
        progress   = findViewById(R.id.progress);
        topBusy    = new Ui.ActivityBusy(this);

        edtPackage.setText(p.packageName);
        edtAppName.setText(p.appName);
        edtVerCode.setText(String.valueOf(p.versionCode));
        edtVerName.setText(p.versionName);

        ((MaterialButton) findViewById(R.id.btnApply)).setOnClickListener(v -> apply());
    }

    private void apply() {
        final String newPkg  = str(edtPackage);
        final String newName = str(edtAppName);
        final String verName = str(edtVerName);
        int vc;
        try { vc = Integer.parseInt(str(edtVerCode)); }
        catch (Exception e) { Ui.toast(this, "رقم إصدار غير صالح"); return; }
        final int verCode = vc;

        topBusy.show("تطبيق معلومات الحزمة…");
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        Logger log = new Logger("meta");

        new Thread(() -> {
            try {
                MetadataEditor me = new MetadataEditor(log);
                if (!newName.isEmpty() && !newName.equals(p.appName)) me.setAppName(p, newName);
                me.setVersion(p, verCode, verName);
                if (!newPkg.isEmpty() && !newPkg.equals(p.packageName)) {
                    PackageRenamer.rename(p, newPkg, log, new TaskCallback<Object>() {
                        @Override public void onProgress(String step, int pct) {
                            runOnUiThread(() -> {
                                topBusy.update(step);
                                progress.setIndeterminate(false);
                                progress.setProgress(pct);
                            });
                        }
                        @Override public void onSuccess(Object r) {}
                        @Override public void onError(Throwable e) {}
                    });
                }
                runOnUiThread(() -> {
                    topBusy.hide(); progress.setVisibility(View.GONE);
                    Ui.toast(this, "تم تطبيق التعديلات على كامل المشروع");
                    finish();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    topBusy.hide(); progress.setVisibility(View.GONE); Ui.error(this, e);
                });
            }
        }).start();
    }

    private String str(TextInputEditText e) {
        return e.getText() == null ? "" : e.getText().toString().trim();
    }
}
