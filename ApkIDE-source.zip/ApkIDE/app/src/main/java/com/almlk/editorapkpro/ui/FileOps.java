package com.almlk.editorapkpro.ui;

import android.content.Context;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;

/** إنشاء ملف/مجلد جديد داخل المشروع مع قوالب جاهزة. */
public final class FileOps {

    public interface Done { void onCreated(File f); }

    private FileOps() {}

    /** أنواع الملفات المتاحة عند الإنشاء. */
    public static final String[] TYPES = {
            "ملف فارغ",
            "Java Class",
            "Java Activity",
            "Kotlin Class",
            "Kotlin Activity",
            "Layout XML",
            "Values XML (resources)",
            "Drawable XML (shape)",
            "Menu XML",
            "Smali",
            "نص / JSON"
    };

    private static final String[] EXT = {
            "", ".java", ".java", ".kt", ".kt", ".xml", ".xml", ".xml", ".xml", ".smali", ".txt"
    };

    /* ------------------------------------------------------------------ */

    public static void createFile(Context c, Project p, File dir, Done done) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (18 * c.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);

        TextView path = new TextView(c);
        path.setText("المسار: " + rel(p, dir));
        path.setTextSize(11);
        path.setTextColor(0xFF9AA7B4);
        box.addView(path);

        final EditText name = new EditText(c);
        name.setHint("اسم الملف");
        name.setSingleLine(true);
        name.setInputType(InputType.TYPE_CLASS_TEXT);
        box.addView(name);

        final Spinner type = new Spinner(c);
        ArrayAdapter<String> ad = new ArrayAdapter<>(c,
                android.R.layout.simple_spinner_dropdown_item, TYPES);
        type.setAdapter(ad);
        box.addView(type);

        new MaterialAlertDialogBuilder(c)
                .setTitle("ملف جديد")
                .setView(box)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إنشاء", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) { Ui.toast(c, "أدخل اسم الملف"); return; }
                    int t = type.getSelectedItemPosition();
                    if (!EXT[t].isEmpty() && !n.contains(".")) n += EXT[t];
                    File f = new File(dir, n);
                    if (f.exists()) { Ui.toast(c, "الملف موجود مسبقاً"); return; }
                    try {
                        FileUtil.write(f, template(t, p, dir, FileUtil.nameNoExt(n)));
                        Ui.toast(c, "أُنشئ: " + n);
                        if (done != null) done.onCreated(f);
                    } catch (Exception e) { Ui.error(c, e); }
                }).show();
    }

    public static void createFolder(Context c, Project p, File dir, Done done) {
        final EditText name = new EditText(c);
        name.setHint("اسم المجلد (يمكن استخدام a/b/c)");
        name.setSingleLine(true);
        int pad = (int) (18 * c.getResources().getDisplayMetrics().density);
        name.setPadding(pad, pad, pad, pad);

        new MaterialAlertDialogBuilder(c)
                .setTitle("مجلد جديد")
                .setMessage("داخل: " + rel(p, dir))
                .setView(name)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إنشاء", (d, w) -> {
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) { Ui.toast(c, "أدخل اسم المجلد"); return; }
                    File f = new File(dir, n);
                    if (f.exists()) { Ui.toast(c, "المجلد موجود مسبقاً"); return; }
                    if (f.mkdirs()) {
                        Ui.toast(c, "أُنشئ: " + n);
                        if (done != null) done.onCreated(f);
                    } else Ui.toast(c, "تعذّر الإنشاء");
                }).show();
    }

    public static void rename(Context c, File f, Done done) {
        final EditText name = new EditText(c);
        name.setText(f.getName());
        name.setSingleLine(true);
        new MaterialAlertDialogBuilder(c)
                .setTitle("إعادة تسمية")
                .setView(name)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("تطبيق", (d, w) -> {
                    File dst = new File(f.getParentFile(), name.getText().toString().trim());
                    if (f.renameTo(dst)) { if (done != null) done.onCreated(dst); }
                    else Ui.toast(c, "تعذّرت إعادة التسمية");
                }).show();
    }

    /* ------------------------------------------------------------------ */

    /** يستنتج اسم الحزمة من موقع المجلد داخل app/src/main/java. */
    public static String packageOf(Project p, File dir) {
        String javaRoot = p.javaDir().getAbsolutePath();
        String path = dir.getAbsolutePath();
        if (path.startsWith(javaRoot)) {
            String rest = path.substring(javaRoot.length()).replace(File.separatorChar, '.');
            while (rest.startsWith(".")) rest = rest.substring(1);
            if (!rest.isEmpty()) return rest;
        }
        return p.packageName == null ? "com.example.app" : p.packageName;
    }

    private static String template(int type, Project p, File dir, String base) {
        String pkg = packageOf(p, dir);
        switch (type) {
            case 1: return "package " + pkg + ";\n\npublic class " + base + " {\n\n    public "
                    + base + "() {\n    }\n}\n";
            case 2: return "package " + pkg + ";\n\n"
                    + "import android.os.Bundle;\n"
                    + "import androidx.annotation.Nullable;\n"
                    + "import androidx.appcompat.app.AppCompatActivity;\n\n"
                    + "public class " + base + " extends AppCompatActivity {\n\n"
                    + "    @Override\n"
                    + "    protected void onCreate(@Nullable Bundle savedInstanceState) {\n"
                    + "        super.onCreate(savedInstanceState);\n"
                    + "        // setContentView(R.layout.activity_main);\n"
                    + "    }\n}\n";
            case 3: return "package " + pkg + "\n\nclass " + base + " {\n\n}\n";
            case 4: return "package " + pkg + "\n\n"
                    + "import android.os.Bundle\n"
                    + "import androidx.appcompat.app.AppCompatActivity\n\n"
                    + "class " + base + " : AppCompatActivity() {\n\n"
                    + "    override fun onCreate(savedInstanceState: Bundle?) {\n"
                    + "        super.onCreate(savedInstanceState)\n"
                    + "        // setContentView(R.layout.activity_main)\n"
                    + "    }\n}\n";
            case 5: return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                    + "<LinearLayout xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                    + "    xmlns:app=\"http://schemas.android.com/apk/res-auto\"\n"
                    + "    android:layout_width=\"match_parent\"\n"
                    + "    android:layout_height=\"match_parent\"\n"
                    + "    android:orientation=\"vertical\">\n\n"
                    + "</LinearLayout>\n";
            case 6: return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n\n</resources>\n";
            case 7: return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                    + "<shape xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                    + "    android:shape=\"rectangle\">\n"
                    + "    <solid android:color=\"#FF2196F3\"/>\n"
                    + "    <corners android:radius=\"8dp\"/>\n"
                    + "</shape>\n";
            case 8: return "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n"
                    + "<menu xmlns:android=\"http://schemas.android.com/apk/res/android\"\n"
                    + "    xmlns:app=\"http://schemas.android.com/apk/res-auto\">\n\n"
                    + "</menu>\n";
            case 9: return ".class public L" + pkg.replace('.', '/') + "/" + base + ";\n"
                    + ".super Ljava/lang/Object;\n\n";
            default: return "";
        }
    }

    private static String rel(Project p, File f) {
        String r = p.root().getAbsolutePath();
        String a = f.getAbsolutePath();
        return a.startsWith(r) ? (a.length() > r.length() ? a.substring(r.length() + 1) : "/") : a;
    }
}
