package com.almlk.editorapkpro.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.i18n.LocalizationGenerator;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** إدارة اللغات: عرض الموجود + إضافة لغات جديدة وتوليد ملفات الترجمة. */
public class LanguagesActivity extends AppCompatActivity {

    private Project p;
    private Ui.ActivityBusy topBusy;
    private final List<String> selected = new ArrayList<>();

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_languages);
        topBusy = new Ui.ActivityBusy(this);
        p = ProjectManager.load(new File(getIntent().getStringExtra("dir")));
        if (p == null) { finish(); return; }

        List<String> existing = LocalizationGenerator.existingLocales(p);
        ((TextView) findViewById(R.id.txtExisting)).setText(
                existing.isEmpty() ? "لا توجد لغات إضافية حالياً"
                                   : "اللغات الموجودة: " + String.join("، ", existing));

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(new LocaleAdapter(LocalizationGenerator.commonLocales(), existing));

        ((MaterialButton) findViewById(R.id.btnGenerate)).setOnClickListener(v -> generate());
    }

    private void generate() {
        if (selected.isEmpty()) { Ui.toast(this, "اختر لغة واحدة على الأقل"); return; }
        topBusy.show("توليد ملفات الترجمة…");
        Ui.Progress pr = new Ui.Progress(this, "توليد ملفات الترجمة").show();
        Logger log = new Logger("i18n");
        new Thread(() -> {
            LocalizationGenerator g = new LocalizationGenerator(log);
            StringBuilder sb = new StringBuilder();
            for (String loc : new ArrayList<>(selected)) {
                runOnUiThread(() -> {
                    topBusy.update("توليد values-"+loc+"…");
                    pr.update("values-" + loc, -1);
                });
                try {
                    LocalizationGenerator.Result r =
                            g.addLanguage(p, loc, LocalizationGenerator.IDENTITY, false);
                    g.ensureRtlSupport(p, loc);
                    sb.append("values-").append(loc).append(" : ")
                      .append(r.total).append(" مفتاح\n");
                } catch (Exception e) {
                    sb.append("values-").append(loc).append(" : فشل — ").append(e.getMessage()).append('\n');
                }
            }
            runOnUiThread(() -> {
                topBusy.hide(); pr.dismiss();
                new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
                        .setTitle("اكتمل التوليد").setMessage(sb.toString())
                        .setPositiveButton("تم", (d, w) -> finish()).show();
            });
        }).start();
    }

    /* ------------------------------------------------------------ */

    private class LocaleAdapter extends RecyclerView.Adapter<LocaleAdapter.VH> {
        private final List<Map.Entry<String, String>> items;
        private final List<String> existing;

        LocaleAdapter(LinkedHashMap<String, String> map, List<String> existing) {
            this.items = new ArrayList<>(map.entrySet());
            this.existing = existing;
        }

        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int t) {
            return new VH(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_locale, parent, false));
        }

        @Override public void onBindViewHolder(@NonNull VH h, int i) {
            Map.Entry<String, String> e = items.get(i);
            h.name.setText(e.getValue());
            boolean has = existing.contains(e.getKey());
            h.code.setText("values-" + e.getKey() + (has ? "  (موجودة)" : ""));
            h.chk.setOnCheckedChangeListener(null);
            h.chk.setChecked(selected.contains(e.getKey()));
            h.chk.setOnCheckedChangeListener((b, c) -> {
                if (c) { if (!selected.contains(e.getKey())) selected.add(e.getKey()); }
                else selected.remove(e.getKey());
            });
            h.itemView.setOnClickListener(v -> h.chk.setChecked(!h.chk.isChecked()));
        }

        @Override public int getItemCount() { return items.size(); }

        class VH extends RecyclerView.ViewHolder {
            MaterialCheckBox chk; TextView name, code;
            VH(@NonNull View v) {
                super(v);
                chk  = v.findViewById(R.id.chk);
                name = v.findViewById(R.id.txtName);
                code = v.findViewById(R.id.txtCode);
            }
        }
    }
}
