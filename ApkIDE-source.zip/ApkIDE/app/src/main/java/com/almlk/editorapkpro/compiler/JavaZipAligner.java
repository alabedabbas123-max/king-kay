package com.almlk.editorapkpro.compiler;

import com.almlk.editorapkpro.engine.Logger;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

/**
 * بديل Java داخلي لـ zipalign.
 *
 * يعيد كتابة الأرشيف ويضيف Extra Field صالحاً قبل بيانات كل ملف STORED بحيث تبدأ
 * البيانات عند حد 4 بايت. لا يعتمد على ELF أو ABI، ولذلك يعمل على كل إصدارات Android.
 * يُستخدم تلقائياً إن كان zipalign الأصلي غائباً أو أعاد خطأ.
 */
public final class JavaZipAligner {
    private static final int LOCAL_HEADER_SIZE = 30;
    private static final int PADDING_HEADER_ID = 0xA11E;
    private JavaZipAligner() {}

    public static File align(File input, File output, int alignment, Logger log) throws IOException {
        if (alignment < 1 || (alignment & (alignment - 1)) != 0)
            throw new IllegalArgumentException("alignment must be a power of two");
        File parent=output.getParentFile(); if(parent!=null)parent.mkdirs();
        if(output.exists()&&!output.delete())throw new IOException("تعذّر حذف ملف المحاذاة القديم");

        int files=0, aligned=0;
        try (ZipFile src=new ZipFile(input);
             CountingOutputStream counted=new CountingOutputStream(new BufferedOutputStream(new FileOutputStream(output)));
             ZipOutputStream dst=new ZipOutputStream(counted, StandardCharsets.UTF_8)) {
            dst.setLevel(6);
            Enumeration<? extends ZipEntry> entries=src.entries();
            byte[] buffer=new byte[64*1024];
            while(entries.hasMoreElements()){
                ZipEntry old=entries.nextElement();
                if(isOldSignature(old.getName()))continue;
                ZipEntry entry=new ZipEntry(old.getName());
                if(old.getComment()!=null)entry.setComment(old.getComment());
                int method=old.isDirectory()?ZipEntry.STORED:old.getMethod();
                if(method!=ZipEntry.STORED&&method!=ZipEntry.DEFLATED)method=ZipEntry.DEFLATED;
                entry.setMethod(method);
                if(method==ZipEntry.STORED){
                    entry.setSize(old.getSize());entry.setCompressedSize(old.getSize());entry.setCrc(old.getCrc());
                    if(!old.isDirectory()){
                        int nameBytes=entry.getName().getBytes(StandardCharsets.UTF_8).length;
                        int totalPadding=paddingSize(counted.count()+LOCAL_HEADER_SIZE+nameBytes,alignment);
                        if(totalPadding>0)entry.setExtra(paddingExtra(totalPadding));
                    }
                }
                dst.putNextEntry(entry);
                if(method==ZipEntry.STORED&&!old.isDirectory()){
                    if(counted.count()%alignment!=0)
                        throw new IOException("فشل حساب محاذاة "+entry.getName()+" عند "+counted.count());
                    aligned++;
                }
                if(!old.isDirectory())try(InputStream in=new BufferedInputStream(src.getInputStream(old))){
                    int n;while((n=in.read(buffer))!=-1)dst.write(buffer,0,n);
                }
                dst.closeEntry();files++;
            }
        } catch (IOException e) {
            output.delete(); throw e;
        }
        // اختبار سلامة الـZIP الناتج وقراءة الـcentral directory.
        try(ZipFile verify=new ZipFile(output)){
            if(verify.size()==0)throw new IOException("أنتجت المحاذاة أرشيفاً فارغاً");
        }
        if(log!=null)log.i("zipalign(java): تمت محاذاة "+aligned+" ملف STORED ضمن "+files+" مدخل");
        return output;
    }

    /** إجمالي Extra Field، ويحافظ على نفس الباقي modulo alignment مع حد أدنى 4. */
    private static int paddingSize(long dataWithoutExtra,int alignment){
        int need=(int)((alignment-(dataWithoutExtra%alignment))%alignment);
        if(need==0)return 0;
        while(need<4)need+=alignment;
        return need;
    }

    /** Extra field: header-id(2) + data-size(2) + zero padding. */
    private static byte[] paddingExtra(int total){
        byte[] e=new byte[total];int data=total-4;
        e[0]=(byte)(PADDING_HEADER_ID&0xff);e[1]=(byte)((PADDING_HEADER_ID>>>8)&0xff);
        e[2]=(byte)(data&0xff);e[3]=(byte)((data>>>8)&0xff);
        return e;
    }

    private static boolean isOldSignature(String name){
        String n=name.toUpperCase(Locale.ROOT);
        if(!n.startsWith("META-INF/"))return false;
        return n.equals("META-INF/MANIFEST.MF")||n.endsWith(".SF")||n.endsWith(".RSA")
                ||n.endsWith(".DSA")||n.endsWith(".EC");
    }

    private static final class CountingOutputStream extends FilterOutputStream {
        private long count;
        CountingOutputStream(OutputStream out){super(out);}
        long count(){return count;}
        @Override public void write(int b)throws IOException{out.write(b);count++;}
        @Override public void write(byte[]b,int o,int n)throws IOException{out.write(b,o,n);count+=n;}
    }
}
