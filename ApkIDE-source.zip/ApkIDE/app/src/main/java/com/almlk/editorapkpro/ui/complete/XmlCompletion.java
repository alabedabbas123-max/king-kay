package com.almlk.editorapkpro.ui.complete;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * إكمال XML كامل السياق:
 *  - بعد "<"   ➜ أسماء الوسوم (Views و وسوم المانيفست والموارد)
 *  - داخل وسم ➜ خصائص android:* المناسبة
 *  - بعد "="  ➜ القيم الشائعة أو موارد المشروع (@string/… @id/… @drawable/…)
 *  - بعد "@"  ➜ أنواع الموارد ثم أسماؤها من فهرس المشروع
 *  - "</"      ➜ إغلاق الوسم المفتوح الحالي
 */
public class XmlCompletion implements CompletionProvider {

    private final ProjectIndex index;

    public XmlCompletion(ProjectIndex index) { this.index = index; }

    public static final String[] TAGS = {
        "LinearLayout","RelativeLayout","FrameLayout","ConstraintLayout","ScrollView",
        "HorizontalScrollView","TextView","EditText","Button","ImageButton","ImageView",
        "CheckBox","RadioButton","RadioGroup","Switch","SeekBar","ProgressBar","Spinner",
        "ListView","GridView","WebView","VideoView","Space","View","ViewStub","include",
        "merge","fragment","TableLayout","TableRow","SurfaceView","TextureView","Toolbar",
        "androidx.recyclerview.widget.RecyclerView","androidx.viewpager2.widget.ViewPager2",
        "androidx.constraintlayout.widget.ConstraintLayout","androidx.cardview.widget.CardView",
        "androidx.drawerlayout.widget.DrawerLayout","androidx.core.widget.NestedScrollView",
        "androidx.swiperefreshlayout.widget.SwipeRefreshLayout",
        "com.google.android.material.button.MaterialButton",
        "com.google.android.material.card.MaterialCardView",
        "com.google.android.material.textfield.TextInputLayout",
        "com.google.android.material.textfield.TextInputEditText",
        "com.google.android.material.floatingactionbutton.FloatingActionButton",
        "com.google.android.material.appbar.AppBarLayout",
        "com.google.android.material.appbar.MaterialToolbar",
        "com.google.android.material.tabs.TabLayout",
        "com.google.android.material.bottomnavigation.BottomNavigationView",
        "com.google.android.material.navigation.NavigationView",
        "com.google.android.material.chip.Chip","com.google.android.material.chip.ChipGroup",
        "com.google.android.material.switchmaterial.SwitchMaterial",
        "com.google.android.material.slider.Slider",
        // موارد
        "resources","string","string-array","plurals","item","color","dimen","style","integer",
        "bool","array","declare-styleable","attr","public",
        // drawable
        "shape","selector","layer-list","ripple","gradient","solid","stroke","corners","padding",
        "vector","path","group","clip-path","animated-vector","bitmap","inset","size",
        // manifest
        "manifest","application","activity","service","receiver","provider","intent-filter",
        "action","category","data","uses-permission","uses-feature","uses-sdk","meta-data",
        "permission","queries","supports-screens","uses-library","grant-uri-permission",
        // menu / xml
        "menu","group","preference","PreferenceScreen","SwitchPreferenceCompat","paths",
        "external-path","files-path","cache-path","external-files-path","network-security-config"
    };

    public static final String[] COMMON_ATTRS = {
        "layout_width","layout_height","layout_margin","layout_marginStart","layout_marginEnd",
        "layout_marginTop","layout_marginBottom","layout_marginHorizontal","layout_marginVertical",
        "layout_gravity","layout_weight","layout_alignParentStart","layout_alignParentEnd",
        "layout_alignParentTop","layout_alignParentBottom","layout_centerInParent",
        "layout_below","layout_above","layout_toStartOf","layout_toEndOf",
        "padding","paddingStart","paddingEnd","paddingTop","paddingBottom","paddingHorizontal",
        "paddingVertical","id","background","backgroundTint","foreground","visibility","gravity",
        "orientation","text","textSize","textColor","textStyle","textAlignment","textAllCaps",
        "hint","textColorHint","maxLines","minLines","lines","ellipsize","inputType","imeOptions",
        "src","srcCompat","scaleType","adjustViewBounds","contentDescription","tint",
        "enabled","clickable","focusable","checked","selected","alpha","rotation","elevation",
        "translationX","translationY","scaleX","scaleY","onClick","tag","theme","style",
        "fontFamily","typeface","lineSpacingExtra","letterSpacing","drawableStart","drawableEnd",
        "drawableTop","drawableBottom","drawablePadding","singleLine","maxLength","digits",
        "name","label","icon","exported","launchMode","screenOrientation","configChanges",
        "windowSoftInputMode","permission","authorities","value","resource","required",
        "allowBackup","supportsRtl","largeHeap","usesCleartextTraffic","networkSecurityConfig",
        "minSdkVersion","targetSdkVersion","versionCode","versionName","installLocation",
        "shape","color","width","height","radius","topLeftRadius","dashWidth","dashGap",
        "startColor","endColor","centerColor","angle","type","viewportWidth","viewportHeight",
        "pathData","fillColor","strokeColor","strokeWidth","state_pressed","state_checked",
        "state_selected","state_enabled","duration","fromXDelta","toXDelta","interpolator",
        "showAsAction","checkable","titleTextColor","subtitleTextColor","title","subtitle"
    };

    /** قيم مقترحة لكل خاصية. */
    private static String[] valuesFor(String attr) {
        switch (attr) {
            case "layout_width": case "layout_height":
                return new String[]{"match_parent","wrap_content","0dp","48dp","match_constraint"};
            case "visibility":     return new String[]{"visible","invisible","gone"};
            case "orientation":    return new String[]{"vertical","horizontal"};
            case "gravity": case "layout_gravity":
                return new String[]{"center","center_vertical","center_horizontal","start","end",
                        "top","bottom","center|start","fill"};
            case "textStyle":      return new String[]{"normal","bold","italic","bold|italic"};
            case "scaleType":      return new String[]{"centerCrop","centerInside","fitCenter",
                        "fitXY","center","fitStart","fitEnd"};
            case "inputType":      return new String[]{"text","textMultiLine","textPassword",
                        "number","numberDecimal","phone","textEmailAddress","textUri","none"};
            case "imeOptions":     return new String[]{"actionDone","actionSearch","actionSend",
                        "actionNext","actionGo"};
            case "ellipsize":      return new String[]{"end","middle","start","marquee"};
            case "shape":          return new String[]{"rectangle","oval","line","ring"};
            case "showAsAction":   return new String[]{"ifRoom","always","never","withText"};
            case "launchMode":     return new String[]{"standard","singleTop","singleTask","singleInstance"};
            case "screenOrientation": return new String[]{"portrait","landscape","sensor","unspecified"};
            case "windowSoftInputMode": return new String[]{"adjustResize","adjustPan","adjustNothing",
                        "stateHidden","stateVisible"};
            case "exported": case "enabled": case "clickable": case "focusable":
            case "checked": case "allowBackup": case "supportsRtl": case "largeHeap":
            case "singleLine": case "adjustViewBounds": case "required": case "checkable":
                return new String[]{"true","false"};
            case "textAlignment":  return new String[]{"center","textStart","textEnd","viewStart","viewEnd"};
            default: return null;
        }
    }

    private static final Pattern P_OPEN_TAG = Pattern.compile("<\\s*([\\w.]*)$");
    private static final Pattern P_CLOSE    = Pattern.compile("</\\s*([\\w.]*)$");
    private static final Pattern P_ATTR_VAL = Pattern.compile("([\\w:]+)\\s*=\\s*\"([^\"]*)$");
    private static final Pattern P_RES_REF  = Pattern.compile("[@?](\\+?)(\\w*)(/([\\w.]*))?$");
    private static final Pattern P_IN_TAG   = Pattern.compile("<\\s*([\\w.]+)(?:\\s[^<>]*)?$");

    @Override public List<Suggestion> complete(CharSequence text, int cursor, String prefix) {
        List<Suggestion> out = new ArrayList<>();
        String before = text.subSequence(0, cursor).toString();
        String tail = before.length() > 400 ? before.substring(before.length() - 400) : before;

        /* 1) إغلاق وسم: </  */
        Matcher mc = P_CLOSE.matcher(tail);
        if (mc.find()) {
            String openTag = findUnclosedTag(before);
            if (openTag != null)
                out.add(new Suggestion(openTag + ">", openTag + ">", "close tag", Suggestion.KIND_TAG));
            for (String t : TAGS) out.add(new Suggestion(t + ">", t + ">", null, Suggestion.KIND_TAG));
            return CompletionUtils.rank(out, mc.group(1), 40);
        }

        /* 2) داخل قيمة خاصية */
        Matcher mv = P_ATTR_VAL.matcher(tail);
        if (mv.find()) {
            String attr = mv.group(1).replace("android:", "").replace("app:", "");
            String typed = mv.group(2);

            Matcher mr = P_RES_REF.matcher(typed);
            if (mr.find()) {
                String type = mr.group(2);
                String namePart = mr.group(4);
                if (namePart == null) {           // ما زال يكتب نوع المورد
                    for (String t : new String[]{"string","id","drawable","mipmap","color","style",
                            "dimen","layout","array","menu","anim","font","integer","bool","attr"})
                        out.add(new Suggestion(t + "/", t + "/", "resource", Suggestion.KIND_RESOURCE));
                    return CompletionUtils.rank(out, type, 30);
                }
                if (index != null) {
                    for (String r : index.resourcesOfType(type))
                        out.add(new Suggestion(r, r, "@" + type, Suggestion.KIND_RESOURCE));
                }
                if ("android".equals(type) || out.isEmpty()) {
                    for (String v : new String[]{"color/white","color/black","color/transparent",
                            "drawable/ic_menu_add","string/ok","string/cancel","style/Widget"})
                        out.add(new Suggestion(v, v, "android", Suggestion.KIND_RESOURCE));
                }
                return CompletionUtils.rank(out, namePart, 60);
            }

            String[] vals = valuesFor(attr);
            if (vals != null)
                for (String v : vals) out.add(new Suggestion(v, v, attr, Suggestion.KIND_VALUE));
            out.add(new Suggestion("@string/", "@string/", "resource", Suggestion.KIND_RESOURCE));
            out.add(new Suggestion("@drawable/", "@drawable/", "resource", Suggestion.KIND_RESOURCE));
            out.add(new Suggestion("@color/", "@color/", "resource", Suggestion.KIND_RESOURCE));
            out.add(new Suggestion("@+id/", "@+id/", "new id", Suggestion.KIND_RESOURCE));
            return CompletionUtils.rank(out, typed, 40);
        }

        /* 3) بداية وسم جديد */
        Matcher mo = P_OPEN_TAG.matcher(tail);
        if (mo.find()) {
            for (String t : TAGS) {
                String simple = t.contains(".") ? t.substring(t.lastIndexOf('.') + 1) : t;
                Suggestion s = new Suggestion(t, t, simple, Suggestion.KIND_TAG);
                out.add(s);
            }
            return CompletionUtils.rank(out, mo.group(1), 50);
        }

        /* 4) داخل وسم مفتوح ➜ خصائص */
        Matcher mt = P_IN_TAG.matcher(tail);
        if (mt.find()) {
            boolean manifest = isManifestContext(before);
            for (String a : COMMON_ATTRS) {
                String full = (manifest ? "android:" : "android:") + a;
                out.add(new Suggestion(full, full + "=\"|\"", attrHint(a), Suggestion.KIND_ATTR));
            }
            out.add(new Suggestion("android:id", "android:id=\"@+id/|\"", "new id", Suggestion.KIND_ATTR));
            out.add(new Suggestion("xmlns:android",
                    "xmlns:android=\"http://schemas.android.com/apk/res/android\"", "ns", Suggestion.KIND_ATTR));
            out.add(new Suggestion("xmlns:app",
                    "xmlns:app=\"http://schemas.android.com/apk/res-auto\"", "ns", Suggestion.KIND_ATTR));
            out.add(new Suggestion("xmlns:tools",
                    "xmlns:tools=\"http://schemas.android.com/tools\"", "ns", Suggestion.KIND_ATTR));
            String p = prefix.startsWith("android:") ? prefix : prefix;
            return CompletionUtils.rank(out, p, 60);
        }

        /* 5) خارج أي وسم */
        for (String t : TAGS) out.add(new Suggestion("<" + t, "<" + t + " ", null, Suggestion.KIND_TAG));
        return CompletionUtils.rank(out, prefix.isEmpty() ? "" : prefix, 40);
    }

    private String attrHint(String a) {
        String[] v = valuesFor(a);
        return v == null ? "attribute" : v[0] + "…";
    }

    private boolean isManifestContext(String before) {
        return before.contains("<manifest");
    }

    /** يبحث عن آخر وسم مفتوح غير مغلق لإغلاقه تلقائياً. */
    public static String findUnclosedTag(String before) {
        java.util.ArrayDeque<String> stack = new java.util.ArrayDeque<>();
        Matcher m = Pattern.compile("<(/?)([\\w.]+)([^<>]*?)(/?)>").matcher(before);
        while (m.find()) {
            boolean closing = "/".equals(m.group(1));
            boolean self    = "/".equals(m.group(4));
            String name = m.group(2);
            if (self) continue;
            if (closing) { if (!stack.isEmpty() && stack.peek().equals(name)) stack.pop(); }
            else stack.push(name);
        }
        return stack.peek();
    }
}
