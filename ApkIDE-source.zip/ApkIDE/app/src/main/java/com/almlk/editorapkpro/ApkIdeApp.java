package com.almlk.editorapkpro;

import android.app.Application;
import android.content.Context;
import androidx.appcompat.app.AppCompatDelegate;
import com.almlk.editorapkpro.engine.NativeTools;
import com.almlk.editorapkpro.compiler.KeystoreManager;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.Prefs;
import com.almlk.editorapkpro.setup.RuntimeBootstrap;
import com.almlk.editorapkpro.setup.SetupManager;

/** نقطة تهيئة التطبيق: تجهيز مجلدات العمل واستخراج الأدوات الأصلية (aapt2/zipalign). */
public class ApkIdeApp extends Application {

    private static ApkIdeApp instance;

    public static ApkIdeApp get() { return instance; }

    @Override protected void attachBaseContext(Context base) {
        // يجب أن تسبق هذه الخطوة أي تحميل لـ brut.util.OSDetection.
        RuntimeBootstrap.install(base);
        super.attachBaseContext(base);
    }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        Prefs.init(this);
        Env.init(this);
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode());

        // تهيئة jadx/apktool: كلاهما يعتمد على مسار مؤقت قابل للكتابة
        System.setProperty("java.io.tmpdir", Env.tmpDir().getAbsolutePath());
        System.setProperty("jadx.skipResources", "false");

        // إعداد كل ما يلزم تلقائياً. MainActivity تعرض التقدم إن لم ينتهِ بعد.
        SetupManager.ensure(this, new SetupManager.Callback() {
            @Override public void onStep(String message, int percent) {}
            @Override public void onReady(SetupManager.Report report) {}
            @Override public void onError(Throwable error) {
                android.util.Log.e("EditorApkPro", "First-run setup failed", error);
            }
        });
    }
}
