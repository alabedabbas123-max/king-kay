package com.almlk.editorapkpro.compiler;

import com.almlk.editorapkpro.engine.Logger;
import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/** تشغيل D8 بالانعكاس بحيث يبقى r8.jar اختيارياً وقابلاً للتثبيت من مدير الأدوات. */
public final class D8Bridge {
    private D8Bridge() {}

    public static boolean available() {
        try { Class.forName("com.android.tools.r8.D8"); return true; }
        catch (Throwable e) {
            File external = new File(com.almlk.editorapkpro.util.Env.toolsDir(), "r8.jar");
            return external.exists() && external.length() > 0;
        }
    }

    public static void run(List<File> classFiles, List<File> libraries, File outDir,
                           int minApi, Logger log) throws Exception {
        if (!available()) throw new IllegalStateException(
                "D8 غير مثبّت. افتح «الأدوات ولينكس» وثبّت r8.jar أولاً.");
        outDir.mkdirs();
        // استخدام واجهة الأوامر ثابت بين إصدارات R8: D8.main(String[])
        List<String> a = new ArrayList<>();
        a.add("--release"); a.add("--min-api"); a.add(String.valueOf(minApi));
        a.add("--output"); a.add(outDir.getAbsolutePath());
        for (File l : libraries) { a.add("--lib"); a.add(l.getAbsolutePath()); }
        for (File f : classFiles) a.add(f.getAbsolutePath());
        log.i("d8: تحويل " + classFiles.size() + " ملف class");
        try {
            Class<?> d8 = Class.forName("com.android.tools.r8.D8");
            Method main = d8.getMethod("main", String[].class);
            try { main.invoke(null, (Object) a.toArray(new String[0])); }
            catch (java.lang.reflect.InvocationTargetException e) {
                Throwable c = e.getCause(); throw new Exception(c == null ? e : c);
            }
        } catch (ClassNotFoundException missing) {
            // نسخة Android-dex من r8.jar مثبّتة من مدير الأدوات: نشغّلها عبر dalvikvm.
            File jar = new File(com.almlk.editorapkpro.util.Env.toolsDir(), "r8.jar");
            List<String> cmd = new ArrayList<>();
            cmd.add("dalvikvm"); cmd.add("-Xmx512m"); cmd.add("-cp");
            cmd.add(jar.getAbsolutePath()); cmd.add("com.android.tools.r8.D8"); cmd.addAll(a);
            ProcessBuilder pb = new ProcessBuilder(cmd).redirectErrorStream(true);
            pb.environment().put("TMPDIR", com.almlk.editorapkpro.util.Env.tmpDir().getAbsolutePath());
            Process process = pb.start();
            try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()))) {
                String line; while ((line = r.readLine()) != null) log.i("d8: " + line);
            }
            int code = process.waitFor();
            if (code != 0) throw new IllegalStateException("فشل D8 الخارجي ("+code+"). ثبّت نسخة r8.jar مهيأة لأندرويد (dexified).");
        }
    }
}
