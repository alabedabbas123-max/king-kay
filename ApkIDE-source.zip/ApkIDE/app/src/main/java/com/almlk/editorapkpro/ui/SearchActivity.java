package com.almlk.editorapkpro.ui;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.BackgroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.search.SearchEngine;
import com.almlk.editorapkpro.util.FileUtil;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.PatternSyntaxException;

/** بحث واستبدال على مستوى المشروع مع الانتقال المباشر إلى النتيجة. */
public class SearchActivity extends AppCompatActivity {

    public static final String RESULT_FILE = "result_file";
    public static final String RESULT_LINE = "result_line";
    public static final String RESULT_OFFSET = "result_offset";

    private File root;
    private EditText find, replace;
    private CheckBox caseBox, wordBox, regexBox, backupBox;
    private Spinner filter;
    private TextView info;
    private Ui.ActivityBusy topBusy;
    private ResultsAdapter adapter;
    private final SearchEngine engine = new SearchEngine();
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private SearchEngine.Query lastQuery;
    private List<SearchEngine.FileResult> results = new ArrayList<>();

    @Override protected void onCreate(@Nullable Bundle b) {
        super.onCreate(b);
        String dir = getIntent().getStringExtra("dir");
        root = dir == null ? null : new File(dir);
        if (root == null || !root.exists()) { finish(); return; }
        setContentView(makeContent());
        topBusy=new Ui.ActivityBusy(this);
    }

    private View makeContent() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(0xFF0D1117);

        MaterialToolbar tb = new MaterialToolbar(this);
        tb.setNavigationIcon(R.drawable.ic_close);
        tb.setNavigationOnClickListener(v -> finish());
        tb.setTitle("البحث والاستبدال في المشروع");
        tb.setSubtitle(root.getName());
        tb.setTitleTextColor(0xFFF0F3F6);
        tb.setSubtitleTextColor(0xFF9AA7B4);
        tb.setBackgroundColor(0xFF161B22);
        page.addView(tb, lp(-1, dp(58)));

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(12), dp(8), dp(12), dp(6));
        form.setBackgroundColor(0xFF161B22);

        find = field("بحث عن…");
        replace = field("استبدال بـ…");
        form.addView(find, lp(-1, dp(46)));
        form.addView(replace, lp(-1, dp(46)));

        LinearLayout options = new LinearLayout(this);
        options.setOrientation(LinearLayout.HORIZONTAL);
        options.setGravity(Gravity.CENTER_VERTICAL);
        caseBox = check("Aa"); wordBox = check("كلمة"); regexBox = check("Regex"); backupBox = check("نسخة .bak");
        backupBox.setChecked(true);
        options.addView(caseBox); options.addView(wordBox); options.addView(regexBox); options.addView(backupBox);
        form.addView(options, lp(-1, -2));

        LinearLayout commands = new LinearLayout(this);
        commands.setGravity(Gravity.CENTER_VERTICAL);
        filter = new Spinner(this);
        filter.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"كل النصوص", "الشيفرة", "Java", "Kotlin", "XML", "Smali"}));
        commands.addView(filter, new LinearLayout.LayoutParams(0, dp(48), 1));
        MaterialButton go = button("بحث", 0xFF00A8E8);
        go.setOnClickListener(v -> startSearch());
        commands.addView(go, lp(dp(88), dp(44)));
        MaterialButton all = button("استبدال الكل", 0xFF27303A);
        all.setOnClickListener(v -> confirmReplaceAll());
        commands.addView(all, lp(dp(128), dp(44)));
        form.addView(commands, lp(-1, -2));
        page.addView(form, lp(-1, -2));

        info = new TextView(this);
        info.setText("اكتب عبارة ثم اضغط بحث");
        info.setTextColor(0xFF9AA7B4); info.setTextSize(12); info.setPadding(dp(14), dp(7), dp(14), dp(7));
        page.addView(info, lp(-1, -2));

        RecyclerView list = new RecyclerView(this);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ResultsAdapter(); list.setAdapter(adapter);
        page.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));

        find.setOnEditorActionListener((v, id, e) -> { startSearch(); return true; });
        return page;
    }

    private void startSearch() {
        String q = find.getText().toString();
        if (q.isEmpty()) { find.setError("أدخل نص البحث"); return; }
        engine.cancel();
        lastQuery = new SearchEngine.Query();
        lastQuery.text = q;
        lastQuery.replacement = replace.getText().toString();
        lastQuery.caseSensitive = caseBox.isChecked();
        lastQuery.wholeWord = wordBox.isChecked();
        lastQuery.regex = regexBox.isChecked();
        String preset = new String[]{"", "code", "java", "kotlin", "xml", "smali"}[filter.getSelectedItemPosition()];
        lastQuery.extensions = SearchEngine.presetExtensions(preset);
        info.setText("جارٍ البحث…");
        topBusy.show("البحث في ملفات المشروع…");
        results.clear(); adapter.set(results);
        worker.execute(() -> {
            try {
                engine.search(root, lastQuery, new SearchEngine.Listener() {
                    @Override public void onProgress(int n, int total, int hits) {
                        runOnUiThread(() -> {
                            topBusy.update("فحص "+n+"/"+total+"…");
                            info.setText("فحص " + n + "/" + total + " • " + hits + " نتيجة");
                        });
                    }
                    @Override public void onFinished(List<SearchEngine.FileResult> r, boolean cancelled) {
                        runOnUiThread(() -> {
                            topBusy.hide(); results = r; adapter.set(r);
                            int hits = 0; for (SearchEngine.FileResult x : r) hits += x.hits.size();
                            info.setText(cancelled ? "أُلغي البحث" : hits + " نتيجة في " + r.size() + " ملف");
                        });
                    }
                    @Override public void onError(Throwable t) {
                        runOnUiThread(() -> { topBusy.hide(); Ui.error(SearchActivity.this, t); });
                    }
                });
            } catch (PatternSyntaxException e) {
                runOnUiThread(() -> { topBusy.hide(); find.setError("Regex غير صحيح: " + e.getDescription()); });
            } catch (Throwable t) {
                runOnUiThread(() -> { topBusy.hide(); Ui.error(this, t); });
            }
        });
    }

    private void confirmReplaceAll() {
        if (results.isEmpty() || lastQuery == null) { Ui.toast(this, "نفّذ البحث أولاً"); return; }
        lastQuery.replacement = replace.getText().toString();
        int count = 0; for (SearchEngine.FileResult f : results) count += f.hits.size();
        final int n = count;
        new MaterialAlertDialogBuilder(this)
                .setTitle("استبدال " + n + " نتيجة؟")
                .setMessage("سيتم تعديل " + results.size() + " ملف."
                        + (backupBox.isChecked() ? "\nستُحفظ نسخة .bak من كل ملف." : ""))
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("استبدال", (d, w) -> {
                    topBusy.show("استبدال النتائج…");
                    worker.execute(() -> {
                        try {
                            int done = engine.replaceAll(root,lastQuery,results,backupBox.isChecked());
                            runOnUiThread(() -> {
                                Ui.toast(this,"تم استبدال "+done+" نتيجة");
                                startSearch();
                            });
                        } catch(Exception e) {
                            runOnUiThread(() -> { topBusy.hide(); Ui.error(this,e); });
                        }
                    });
                }).show();
    }

    private void open(SearchEngine.Hit h) {
        setResult(Activity.RESULT_OK, new Intent()
                .putExtra(RESULT_FILE, h.file.getAbsolutePath())
                .putExtra(RESULT_LINE, h.line)
                .putExtra(RESULT_OFFSET, h.start));
        finish();
    }

    private void replaceOne(SearchEngine.Hit h) {
        if (lastQuery == null) return;
        lastQuery.replacement = replace.getText().toString();
        topBusy.show("استبدال النتيجة…");
        worker.execute(() -> {
            try {
                engine.replaceOne(h, lastQuery, backupBox.isChecked());
                runOnUiThread(() -> { Ui.toast(this, "تم استبدال النتيجة"); startSearch(); });
            } catch (Exception e) {
                runOnUiThread(() -> { topBusy.hide(); Ui.error(this, e); });
            }
        });
    }

    /* ---------------- Adapter: عناوين ملفات + نتائج ---------------- */

    private class Row { SearchEngine.FileResult file; SearchEngine.Hit hit; }
    private class ResultsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private final List<Row> rows = new ArrayList<>();
        void set(List<SearchEngine.FileResult> data) {
            rows.clear();
            for (SearchEngine.FileResult f : data) {
                Row head = new Row(); head.file = f; rows.add(head);
                for (SearchEngine.Hit h : f.hits) { Row r = new Row(); r.hit = h; rows.add(r); }
            }
            notifyDataSetChanged();
        }
        @Override public int getItemViewType(int p) { return rows.get(p).hit == null ? 0 : 1; }
        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup p, int type) {
            TextView t = new TextView(SearchActivity.this);
            t.setTextColor(type == 0 ? 0xFF79C0FF : 0xFFD8DEE4);
            t.setTextSize(type == 0 ? 13 : 12);
            t.setTypeface(type == 0 ? Typeface.DEFAULT_BOLD : Typeface.MONOSPACE);
            t.setPadding(type == 0 ? dp(14) : dp(32), dp(type == 0 ? 12 : 7), dp(12), dp(type == 0 ? 8 : 7));
            t.setBackgroundColor(type == 0 ? 0xFF161B22 : 0xFF0D1117);
            return new RecyclerView.ViewHolder(t) {};
        }
        @Override public void onBindViewHolder(RecyclerView.ViewHolder h, int p) {
            TextView t = (TextView) h.itemView; Row r = rows.get(p);
            if (r.hit == null) {
                t.setText("▾  " + r.file.relativePath + "    (" + r.file.hits.size() + ")");
                t.setOnClickListener(null); t.setOnLongClickListener(null);
            } else {
                String raw = r.hit.line + "   " + r.hit.preview;
                SpannableString ss = new SpannableString(raw);
                int shift = String.valueOf(r.hit.line).length() + 3;
                int a = Math.min(ss.length(), shift + r.hit.previewStart);
                int b = Math.min(ss.length(), shift + r.hit.previewEnd);
                if (a < b) ss.setSpan(new BackgroundColorSpan(0xFF754B00), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                t.setText(ss);
                t.setOnClickListener(v -> open(r.hit));
                t.setOnLongClickListener(v -> { new MaterialAlertDialogBuilder(SearchActivity.this)
                        .setTitle("هذه النتيجة")
                        .setItems(new String[]{"فتح", "استبدال هذه فقط", "نسخ المسار"}, (d,w)->{
                            if(w==0)open(r.hit); else if(w==1)replaceOne(r.hit);
                            else { android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(android.content.ClipData.newPlainText("path",r.hit.file.getAbsolutePath())); }
                        }).show(); return true; });
            }
        }
        @Override public int getItemCount() { return rows.size(); }
    }

    private EditText field(String hint) { EditText e=new EditText(this);e.setHint(hint);e.setTextColor(0xFFF0F3F6);e.setHintTextColor(0xFF6E7681);e.setSingleLine(true);e.setPadding(dp(10),0,dp(10),0);return e; }
    private CheckBox check(String s) { CheckBox c=new CheckBox(this);c.setText(s);c.setTextColor(0xFFD8DEE4);c.setTextSize(11);c.setPadding(0,0,dp(6),0);return c; }
    private MaterialButton button(String s,int color){MaterialButton b=new MaterialButton(this);b.setText(s);b.setTextSize(11);b.setBackgroundColor(color);return b;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}

    @Override protected void onDestroy() { engine.cancel(); worker.shutdownNow(); super.onDestroy(); }
}
