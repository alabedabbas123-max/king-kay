package com.almlk.editorapkpro.ui.complete;

import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * فهرس خفيف للمشروع يُبنى في الخلفية:
 *  - أسماء الأصناف (من ملفات .java/.kt ومن الاستيرادات)
 *  - أسماء الدوال والحقول
 *  - موارد المشروع (R.id / R.layout / R.string / R.drawable …)
 * يُستخدم لتزويد قوائم الإكمال بمحتوى المشروع نفسه وليس بكلمات ثابتة فقط.
 */
public class ProjectIndex {

    private static final Pattern P_CLASS  = Pattern.compile(
            "(?m)^\\s*(?:public|private|protected|final|abstract|static|open|internal|data|sealed|\\s)*" +
            "(?:class|interface|enum|object)\\s+(\\w+)");
    private static final Pattern P_METHOD = Pattern.compile(
            "(?m)^\\s*(?:public|private|protected|static|final|native|synchronized|abstract|" +
            "override|open|suspend|inline|fun|\\s)*[\\w<>\\[\\].]+\\s+(\\w+)\\s*\\(([^)]*)\\)");
    private static final Pattern P_KT_FUN = Pattern.compile("(?m)\\bfun\\s+(\\w+)\\s*\\(([^)]*)\\)");
    private static final Pattern P_FIELD  = Pattern.compile(
            "(?m)^\\s*(?:public|private|protected|static|final|val|var)\\s+[\\w<>\\[\\].]+\\s+(\\w+)\\s*[=;]");
    private static final Pattern P_RES_NAME = Pattern.compile("name=\"([\\w.]+)\"");
    private static final Pattern P_ID       = Pattern.compile("@\\+?id/([\\w.]+)");

    private final Set<String> classes = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> methods = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> fields  = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> ids     = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> layouts = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> strings = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> drawables = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> colors  = Collections.synchronizedSet(new TreeSet<>());
    private final Set<String> styles  = Collections.synchronizedSet(new TreeSet<>());

    private volatile boolean ready = false;

    public boolean isReady() { return ready; }

    /** يُستدعى في خيط خلفي. */
    public void build(Project p) {
        try {
            indexSources(p);
            indexResources(p);
        } catch (Throwable ignored) {}
        ready = true;
    }

    private void indexSources(Project p) {
        List<File> src = new ArrayList<>();
        src.addAll(FileUtil.walk(p.javaDir(), "java", "kt"));
        if (src.isEmpty()) src.addAll(FileUtil.walk(p.root(), "java", "kt"));
        int budget = 0;
        for (File f : src) {
            if (++budget > 2500) break;
            try {
                String t = FileUtil.read(f);
                add(P_CLASS, t, classes, 1);
                add(P_METHOD, t, methods, 1);
                add(P_KT_FUN, t, methods, 1);
                add(P_FIELD, t, fields, 1);
            } catch (Exception ignored) {}
        }
    }

    private void indexResources(Project p) {
        File res = p.resDir();
        if (!res.exists()) return;
        for (File f : FileUtil.walk(res, "xml")) {
            String dir = f.getParentFile() == null ? "" : f.getParentFile().getName();
            String base = FileUtil.nameNoExt(f.getName());
            if (dir.startsWith("layout"))       layouts.add(base);
            else if (dir.startsWith("drawable") || dir.startsWith("mipmap")) drawables.add(base);
            try {
                String t = FileUtil.read(f);
                Matcher m = P_ID.matcher(t);
                while (m.find()) ids.add(m.group(1));
                if (dir.startsWith("values")) {
                    Matcher n = Pattern.compile("<(string|color|style|dimen|integer|bool|" +
                            "string-array|plurals)\\s+name=\"([\\w.]+)\"").matcher(t);
                    while (n.find()) {
                        switch (n.group(1)) {
                            case "string": case "string-array": case "plurals":
                                strings.add(n.group(2)); break;
                            case "color": colors.add(n.group(2)); break;
                            case "style": styles.add(n.group(2)); break;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        for (File f : FileUtil.walk(res, "png", "jpg", "webp", "gif"))
            drawables.add(FileUtil.nameNoExt(f.getName()));
    }

    private void add(Pattern p, String text, Set<String> out, int group) {
        Matcher m = p.matcher(text);
        int n = 0;
        while (m.find() && n++ < 4000) {
            String v = m.group(group);
            if (v != null && v.length() > 1 && !RESERVED.contains(v)) out.add(v);
        }
    }

    private static final Set<String> RESERVED = new HashSet<>(java.util.Arrays.asList(
            "if", "for", "while", "switch", "catch", "return", "new", "synchronized", "class"));

    /* -------- وصول -------- */
    public Set<String> classes()  { return classes; }
    public Set<String> methods()  { return methods; }
    public Set<String> fields()   { return fields; }
    public Set<String> ids()      { return ids; }
    public Set<String> layouts()  { return layouts; }
    public Set<String> strings()  { return strings; }
    public Set<String> drawables(){ return drawables; }
    public Set<String> colors()   { return colors; }
    public Set<String> styles()   { return styles; }

    public Set<String> resourcesOfType(String type) {
        switch (type) {
            case "id":       return ids;
            case "layout":   return layouts;
            case "string":   return strings;
            case "drawable": case "mipmap": return drawables;
            case "color":    return colors;
            case "style":    return styles;
            default:         return Collections.emptySet();
        }
    }
}
