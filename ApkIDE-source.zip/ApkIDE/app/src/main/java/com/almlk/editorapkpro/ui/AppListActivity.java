package com.almlk.editorapkpro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.EngineService;
import com.almlk.editorapkpro.model.AppInfo;
import com.almlk.editorapkpro.ui.adapter.AppAdapter;
import com.almlk.editorapkpro.util.AppScanner;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

/** قائمة التطبيقات المثبتة + بحث فوري + قائمة خيارات لكل تطبيق. */
public class AppListActivity extends AppCompatActivity {

    private AppAdapter adapter;
    private ProgressBar progress;
    private Ui.ActivityBusy topBusy;
    private TextView txtCount;
    private CheckBox chkSystem;
    private RecyclerView list;

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_app_list);

        MaterialToolbar tb = findViewById(R.id.toolbar);
        tb.setNavigationOnClickListener(v -> finish());

        progress  = findViewById(R.id.progress);
        topBusy   = new Ui.ActivityBusy(this);
        txtCount  = findViewById(R.id.txtCount);
        chkSystem = findViewById(R.id.chkSystem);

        list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        // لا نخزن أيقونات كل التطبيقات في الذاكرة؛ يحمّل المحوّل الأيقونات المرئية فقط.
        adapter = new AppAdapter(getPackageManager(),app -> AppOptionsSheet.show(this, app));
        list.setAdapter(adapter);

        EditText search = findViewById(R.id.edtSearch);
        View clear = findViewById(R.id.btnClear);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                adapter.filter(s.toString());
                clear.setVisibility(s.length() == 0 ? View.GONE : View.VISIBLE);
                updateCount();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        clear.setOnClickListener(v -> search.setText(""));
        chkSystem.setOnCheckedChangeListener((b, c) -> load());

        load();
        if(getIntent().getBooleanExtra(EngineService.EXTRA_SHOW_WORK,false))
            list.post(()->Ui.revealActiveProgress(this));
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        if(intent.getBooleanExtra(EngineService.EXTRA_SHOW_WORK,false))
            Ui.revealActiveProgress(this);
    }

    private void load() {
        topBusy.show("قراءة التطبيقات المثبتة…");
        progress.setVisibility(View.VISIBLE);
        boolean sys = chkSystem.isChecked();
        new Thread(() -> {
            final List<AppInfo> apps = AppScanner.scan(this, sys);
            runOnUiThread(() -> {
                topBusy.hide(); progress.setVisibility(View.GONE);
                adapter.submit(apps);
                updateCount();
            });
        }).start();
    }

    /** حرر Drawables وقائمة العرض قبل Apktool/Jadx كي تبدأ العملية بأكبر heap متاح. */
    public void releaseForHeavyWork() {
        if(list!=null){
            for(int i=0;i<list.getChildCount();i++){
                android.widget.ImageView icon=list.getChildAt(i).findViewById(R.id.icon);
                if(icon!=null)icon.setImageDrawable(null);
            }
            list.setItemViewCacheSize(0);
            list.getRecycledViewPool().clear();
        }
        try{getApplication().onTrimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL);}
        catch(Throwable ignored){}
        System.gc();System.runFinalization();
    }

    /** أعد ربط الأيقونات المرئية إذا فشلت العملية وعاد المستخدم إلى القائمة. */
    public void restoreAfterHeavyWork(){
        if(list!=null){list.setItemViewCacheSize(2);adapter.notifyDataSetChanged();}
    }

    private void updateCount() { txtCount.setText(adapter.shown() + " تطبيق"); }
}
