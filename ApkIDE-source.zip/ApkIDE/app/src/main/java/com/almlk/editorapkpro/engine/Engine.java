package com.almlk.editorapkpro.engine;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.os.Handler;
import android.os.Looper;

import com.almlk.editorapkpro.compiler.Rebuilder;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.DecompilePipeline;
import com.almlk.editorapkpro.project.BuildArtifactCleaner;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.ZipUtil;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.atomic.AtomicBoolean;

/** واجهة موحّدة لتشغيل كل العمليات الثقيلة خارج الخيط الرئيسي مع تقارير تقدّم. */
public class Engine {

    private static Engine instance;
    public static synchronized Engine get() {
        if (instance == null) instance = new Engine();
        return instance;
    }

    // عملية ثقيلة واحدة فقط: تشغيل Apktool/Jadx مرتين بالتوازي يضاعف heap وقد يجعل
    // Android يقتل العملية دون فرصة لعرض الاستثناء.
    private final ExecutorService pool = Executors.newSingleThreadExecutor(r -> {
        Thread t=new Thread(r,"apkide-engine");
        t.setPriority(Thread.NORM_PRIORITY-1);
        return t;
    });
    private final AtomicBoolean operationRunning = new AtomicBoolean(false);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private volatile Logger current;

    public Logger currentLog() { return current; }
    public boolean isBusy() { return operationRunning.get(); }

    /* ------------------------------------------------------------------ */

    public Future<?> decompile(Context ctx, File apk, String name, int mode,
                               TaskCallback<Project> cb) {
        Logger log = new Logger("decompile");
        logVersion(ctx,log);
        current = log;
        return submit(cb, log, () -> new DecompilePipeline(ctx.getApplicationContext(), log)
                .run(apk, name, mode, wrap(cb)));
    }

    public Future<?> rebuild(Context ctx, Project p, Rebuilder.Mode mode, TaskCallback<File> cb) {
        Logger log = new Logger("rebuild");
        logVersion(ctx,log);
        current = log;
        return submit(cb, log, () -> new Rebuilder(ctx.getApplicationContext(), log)
                .rebuild(p, mode, wrap(cb)));
    }

    public Future<?> exportZip(Project p, TaskCallback<File> cb) {
        Logger log = new Logger("zip");
        current = log;
        return submit(cb, log, () -> {
            // لا نضع build أو كاش Java/Python أو مجلدات الموارد الفارغة داخل ZIP المصدر.
            BuildArtifactCleaner.clean(p,log,(step,percent)->
                    post(()->cb.onProgress(step,percent<0?-1:percent*15/100)));
            File out = new File(Env.outputDir(), p.name + "_" + System.currentTimeMillis() + ".zip");
            log.i("ضغط المشروع النظيف: " + p.root().getAbsolutePath());
            ZipUtil.zipDirectory(p.root(), out, (n, done, total) -> {
                if (done % 25 == 0 || done == total)
                    post(() -> cb.onProgress(n, 15+(int) (done * 85L / Math.max(1, total))));
            });
            log.i("تم الإنتاج: " + out.getName() + " (" +
                    com.almlk.editorapkpro.util.FileUtil.humanSize(out.length()) + ")");
            return out;
        });
    }

    /** فحص تنظيف المشروع دون حذف، لإظهار معاينة آمنة للمستخدم. */
    public Future<?> inspectProjectCleanup(Project p,
            TaskCallback<BuildArtifactCleaner.Plan> cb) {
        Logger log=new Logger("clean_scan");
        current=log;
        return submit(cb,log,()->BuildArtifactCleaner.scan(p,log,
                (step,percent)->post(()->cb.onProgress(step,percent))));
    }

    /** تنفيذ خطة التنظيف التي وافق عليها المستخدم. */
    public Future<?> cleanProject(BuildArtifactCleaner.Plan plan,
            TaskCallback<BuildArtifactCleaner.Result> cb) {
        Logger log=new Logger("clean");
        current=log;
        return submit(cb,log,()->BuildArtifactCleaner.execute(plan,log,
                (step,percent)->post(()->cb.onProgress(step,percent))));
    }

    /* ------------------------------------------------------------------ */

    private interface Job<T> { T run() throws Exception; }

    private <T> Future<?> submit(TaskCallback<T> cb, Logger log, Job<T> job) {
        if(!operationRunning.compareAndSet(false,true)){
            IllegalStateException error=new IllegalStateException(
                    "توجد عملية فك أو بناء قيد التنفيذ. انتظر اكتمال الدائرة المتحركة ثم أعد المحاولة.");
            post(()->cb.onError(error));
            FutureTask<Void> done=new FutureTask<>(()->null);
            done.run();
            return done;
        }
        post(() -> cb.onStart("بدء التنفيذ"));
        return pool.submit(() -> {
            try {
                T r = job.run();
                post(() -> cb.onSuccess(r));
            } catch (OutOfMemoryError oom) {
                // إن بقيت العملية حية، حوّل OOM إلى رسالة واضحة بدلاً من إغلاق الواجهة.
                System.gc();
                IllegalStateException safe=new IllegalStateException(
                        "نفدت ذاكرة Android أثناء العملية. أُوقفت بأمان وحُذفت النتيجة الجزئية؛ "
                                +"أغلق التطبيقات الثقيلة وأعد المحاولة. يستخدم هذا الإصدار أيقونات مرئية فقط "
                                +"وSmali/Jadx بشظايا DEX صغيرة متسلسلة.",oom);
                try{log.e("أوقفت العملية بسبب نفاد الذاكرة",safe);}catch(Throwable ignored){}
                post(() -> cb.onError(safe));
            } catch (Throwable t) {
                log.e("فشلت العملية: " + t.getMessage(), t);
                post(() -> cb.onError(t));
            } finally {
                operationRunning.set(false);
            }
        });
    }

    /** يحوّل استدعاءات التقدم القادمة من خيوط الخلفية إلى الخيط الرئيسي. */
    private <T> TaskCallback<T> wrap(TaskCallback<T> cb) {
        return new TaskCallback<T>() {
            @Override public void onProgress(String step, int percent) {
                post(() -> cb.onProgress(step, percent));
            }
            @Override public void onSuccess(T result) { }
            @Override public void onError(Throwable e) { }
        };
    }

    private void logVersion(Context context,Logger log){
        try{
            PackageInfo p=context.getPackageManager().getPackageInfo(context.getPackageName(),0);
            long code=android.os.Build.VERSION.SDK_INT>=28?p.getLongVersionCode():p.versionCode;
            log.i("Editor APK Pro runtime: v"+p.versionName+" (code "+code+")");
        }catch(Exception ignored){}
    }

    private void post(Runnable r) { ui.post(r); }
}
