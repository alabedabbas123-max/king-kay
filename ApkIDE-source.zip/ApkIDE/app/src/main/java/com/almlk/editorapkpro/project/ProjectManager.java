package com.almlk.editorapkpro.project;

import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.IOException;
import java.util.*;

/** تخزين/قراءة بيانات المشاريع (.apkide/project.json). */
public final class ProjectManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private ProjectManager() {}

    public static void save(Project p) {
        try {
            File f = new File(p.metaDir(), "project.json");
            FileUtil.write(f, GSON.toJson(p));
        } catch (IOException ignored) {}
    }

    public static Project load(File projectDir) {
        File f = new File(new File(projectDir, ".apkide"), "project.json");
        if (!f.exists()) return null;
        try {
            Project p = GSON.fromJson(FileUtil.read(f), Project.class);
            if (p != null) p.dir = projectDir.getAbsolutePath();
            return p;
        } catch (Exception e) { return null; }
    }

    public static List<Project> all() {
        List<Project> out = new ArrayList<>();
        File[] kids = Env.projectsDir().listFiles(File::isDirectory);
        if (kids != null) for (File k : kids) {
            Project p = load(k);
            if (p != null) out.add(p);
        }
        out.sort((a, b) -> Long.compare(b.createdAt, a.createdAt));
        return out;
    }

    public static void delete(Project p) { FileUtil.delete(p.root()); }

    /** اسم مجلد فريد وآمن. */
    public static String uniqueName(String base) {
        String safe = base.replaceAll("[^a-zA-Z0-9._\\-\\u0600-\\u06FF ]", "_").trim();
        if (safe.isEmpty()) safe = "project";
        File f = Env.projectDir(safe);
        int i = 2;
        while (f.exists()) f = Env.projectDir(safe + "_" + i++);
        return f.getName();
    }
}
