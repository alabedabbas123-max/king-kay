package com.almlk.editorapkpro.compiler;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** تصريف Java عبر ECJ ثم D8. */
public class SourceCompiler {
    private final Logger log;
    public SourceCompiler(Logger log) { this.log = log; }

    public File compile(Project p) throws Exception {
        File androidJar = new File(Env.toolsDir(), "android.jar");
        if (!androidJar.exists()) throw new IllegalStateException(
                "android.jar غير مثبّت. ثبّته من شاشة «الأدوات ولينكس».");
        File work = Env.newTmp("source_compile");
        File classes = new File(work, "classes"); classes.mkdirs();
        List<File> src = FileUtil.walk(p.javaDir(), "java");
        if (src.isEmpty()) throw new IllegalStateException("لا توجد ملفات Java للتصريف");
        List<File> cp = new ArrayList<>(); cp.add(androidJar);
        File libs = new File(p.root(), "app/libs");
        cp.addAll(FileUtil.walk(libs, "jar"));

        List<String> args = new ArrayList<>();
        args.add("-17"); args.add("-encoding"); args.add("UTF-8");
        args.add("-proc:none"); args.add("-d"); args.add(classes.getAbsolutePath());
        args.add("-classpath");
        List<String> cps = new ArrayList<>(); for (File x : cp) cps.add(x.getAbsolutePath());
        args.add(String.join(File.pathSeparator, cps));
        for (File f : src) args.add(f.getAbsolutePath());
        log.i("ecj: تصريف " + src.size() + " ملف Java");
        org.eclipse.jdt.internal.compiler.batch.Main ecj =
                new org.eclipse.jdt.internal.compiler.batch.Main(
                        new java.io.PrintWriter(new LogWriter(log, false), true),
                        new java.io.PrintWriter(new LogWriter(log, true), true),
                        false, null, null);
        boolean ok = ecj.compile(args.toArray(new String[0]));
        if (!ok) throw new IllegalStateException("فشل تصريف Java — راجع لوحة الأخطاء");

        List<File> program = new ArrayList<>(FileUtil.walk(classes, "class"));
        // JAR المثبّتة هي مدخلات برنامج وليست --lib، حتى تُدمج أصنافها في classes.dex.
        program.addAll(FileUtil.walk(libs, "jar"));
        File dex = new File(work, "dex");
        D8Bridge.run(program, java.util.Collections.singletonList(androidJar), dex, 26, log);
        File out = new File(dex, "classes.dex");
        if (!out.exists()) throw new IllegalStateException("لم ينتج D8 ملف classes.dex");
        return out;
    }

    private static class LogWriter extends java.io.Writer {
        private final Logger log; private final boolean err; private final StringBuilder b = new StringBuilder();
        LogWriter(Logger l, boolean e) { log=l; err=e; }
        @Override public void write(char[] c, int o, int n) {
            for(int i=o;i<o+n;i++){ if(c[i]=='\n'){flushLine();}else b.append(c[i]); }
        }
        private void flushLine(){ if(b.length()>0){ if(err)log.e(b.toString());else log.i(b.toString()); b.setLength(0);} }
        @Override public void flush(){flushLine();} @Override public void close(){flushLine();}
    }
}
