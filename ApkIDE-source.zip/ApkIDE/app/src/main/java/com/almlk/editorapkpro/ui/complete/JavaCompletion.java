package com.almlk.editorapkpro.ui.complete;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** إكمال Java / Kotlin: كلمات مفتاحية، دوال أندرويد الشائعة، رموز المشروع، ومقاطع جاهزة. */
public class JavaCompletion implements CompletionProvider {

    private final ProjectIndex index;
    private final boolean kotlin;

    public JavaCompletion(ProjectIndex index, boolean kotlin) {
        this.index = index;
        this.kotlin = kotlin;
    }

    private static final String[] JAVA_KW = {
        "abstract","assert","boolean","break","byte","case","catch","char","class","continue",
        "default","do","double","else","enum","extends","final","finally","float","for","if",
        "implements","import","instanceof","int","interface","long","native","new","package",
        "private","protected","public","return","short","static","strictfp","super","switch",
        "synchronized","this","throw","throws","transient","try","void","volatile","while",
        "true","false","null","var","record"};

    private static final String[] KT_KW = {
        "fun","val","var","object","companion","data","sealed","when","is","in","as","by",
        "lateinit","init","override","open","internal","suspend","inline","reified","typealias",
        "constructor","operator","class","interface","package","import","return","if","else",
        "for","while","try","catch","finally","true","false","null","this","super","it",
        "private","protected","public","abstract","enum","vararg","crossinline","noinline"};

    /** دوال وأنماط أندرويد الأكثر استخداماً. */
    private static final String[][] ANDROID = {
        {"findViewById", "findViewById(R.id.|)", "View"},
        {"setContentView", "setContentView(R.layout.|)", "void"},
        {"setOnClickListener", "setOnClickListener(v -> {\n    |\n})", "void"},
        {"setOnLongClickListener", "setOnLongClickListener(v -> {\n    |\n    return true;\n})", "void"},
        {"getString", "getString(R.string.|)", "String"},
        {"getResources", "getResources()", "Resources"},
        {"getApplicationContext", "getApplicationContext()", "Context"},
        {"getSystemService", "getSystemService(|)", "Object"},
        {"getPackageManager", "getPackageManager()", "PackageManager"},
        {"getIntent", "getIntent()", "Intent"},
        {"startActivity", "startActivity(new Intent(this, |.class));", "void"},
        {"startService", "startService(|)", "ComponentName"},
        {"runOnUiThread", "runOnUiThread(() -> {\n    |\n});", "void"},
        {"onCreate", "onCreate(Bundle savedInstanceState) {\n    super.onCreate(savedInstanceState);\n    |\n}", "void"},
        {"onResume", "onResume() {\n    super.onResume();\n    |\n}", "void"},
        {"onPause", "onPause() {\n    super.onPause();\n    |\n}", "void"},
        {"onDestroy", "onDestroy() {\n    super.onDestroy();\n    |\n}", "void"},
        {"onBindViewHolder", "onBindViewHolder(VH holder, int position) {\n    |\n}", "void"},
        {"setText", "setText(|)", "void"},
        {"setVisibility", "setVisibility(View.|)", "void"},
        {"setAdapter", "setAdapter(|)", "void"},
        {"setLayoutManager", "setLayoutManager(new LinearLayoutManager(this))", "void"},
        {"notifyDataSetChanged", "notifyDataSetChanged()", "void"},
        {"getLayoutInflater", "getLayoutInflater()", "LayoutInflater"},
        {"inflate", "inflate(R.layout.|, parent, false)", "View"},
        {"putExtra", "putExtra(\"|\", )", "Intent"},
        {"getIntExtra", "getIntExtra(\"|\", 0)", "int"},
        {"getStringExtra", "getStringExtra(\"|\")", "String"},
        {"makeText", "Toast.makeText(this, \"|\", Toast.LENGTH_SHORT).show();", "void"},
        {"getSharedPreferences", "getSharedPreferences(\"|\", MODE_PRIVATE)", "SharedPreferences"},
        {"requestPermissions", "requestPermissions(new String[]{|}, 1)", "void"},
        {"registerReceiver", "registerReceiver(|, new IntentFilter())", "Intent"},
        {"getWindow", "getWindow()", "Window"},
        {"finish", "finish()", "void"},
        {"recreate", "recreate()", "void"},
    };

    private static final String[][] CLASSES = {
        {"Activity","android.app"},{"AppCompatActivity","androidx.appcompat.app"},
        {"Fragment","androidx.fragment.app"},{"Intent","android.content"},
        {"Context","android.content"},{"Bundle","android.os"},{"View","android.view"},
        {"TextView","android.widget"},{"Button","android.widget"},{"EditText","android.widget"},
        {"ImageView","android.widget"},{"RecyclerView","androidx.recyclerview.widget"},
        {"LinearLayout","android.widget"},{"FrameLayout","android.widget"},
        {"Toast","android.widget"},{"Handler","android.os"},{"Looper","android.os"},
        {"SharedPreferences","android.content"},{"String","java.lang"},{"Integer","java.lang"},
        {"List","java.util"},{"ArrayList","java.util"},{"Map","java.util"},{"HashMap","java.util"},
        {"File","java.io"},{"Log","android.util"},{"Uri","android.net"},
        {"AlertDialog","androidx.appcompat.app"},{"ViewGroup","android.view"},
        {"LayoutInflater","android.view"},{"Thread","java.lang"},{"Exception","java.lang"},
    };

    private static final String[][] SNIPPETS_JAVA = {
        {"sout", "System.out.println(|);", "print"},
        {"logd", "Log.d(TAG, \"|\");", "log debug"},
        {"loge", "Log.e(TAG, \"|\", e);", "log error"},
        {"toast", "Toast.makeText(this, \"|\", Toast.LENGTH_SHORT).show();", "toast"},
        {"fori", "for (int i = 0; i < |; i++) {\n    \n}", "for loop"},
        {"foreach", "for (Object o : |) {\n    \n}", "for-each"},
        {"trycatch", "try {\n    |\n} catch (Exception e) {\n    e.printStackTrace();\n}", "try/catch"},
        {"ifnull", "if (| == null) {\n    return;\n}", "null check"},
        {"psvm", "public static void main(String[] args) {\n    |\n}", "main"},
        {"newthread", "new Thread(() -> {\n    |\n}).start();", "thread"},
    };

    private static final String[][] SNIPPETS_KT = {
        {"println", "println(|)", "print"},
        {"logd", "Log.d(TAG, \"|\")", "log"},
        {"toast", "Toast.makeText(this, \"|\", Toast.LENGTH_SHORT).show()", "toast"},
        {"fori", "for (i in 0 until |) {\n    \n}", "for"},
        {"foreach", "|.forEach { \n    \n}", "forEach"},
        {"trycatch", "try {\n    |\n} catch (e: Exception) {\n    e.printStackTrace()\n}", "try/catch"},
        {"lazy", "by lazy { | }", "lazy"},
        {"datacls", "data class |(val id: Int)", "data class"},
        {"fun", "fun |() {\n    \n}", "function"},
    };

    private static final Pattern P_LOCAL_VAR = Pattern.compile(
            "\\b(?:int|long|float|double|boolean|char|byte|short|String|var|val|final\\s+\\w+|" +
            "[A-Z]\\w*(?:<[^>]*>)?)\\s+(\\w+)\\s*[=;)]");

    @Override public List<Suggestion> complete(CharSequence text, int cursor, String prefix) {
        List<Suggestion> out = new ArrayList<>();
        String before = text.subSequence(Math.max(0, cursor - 220), cursor).toString();

        /* ---- سياق موارد: R.id. / R.layout. / R.string. ---- */
        Matcher rm = Pattern.compile("R\\.(\\w+)\\.(\\w*)$").matcher(before);
        if (rm.find() && index != null) {
            String type = rm.group(1);
            for (String r : index.resourcesOfType(type))
                out.add(new Suggestion(r, r, "R." + type, Suggestion.KIND_RESOURCE));
            return CompletionUtils.rank(out, rm.group(2), 60);
        }
        if (before.endsWith("R.")) {
            for (String t : new String[]{"id","layout","string","drawable","color","style",
                    "dimen","mipmap","raw","array","menu","anim","font","integer","bool","xml"})
                out.add(new Suggestion(t, t, "resource type", Suggestion.KIND_FIELD));
            return out;
        }

        /* ---- بعد نقطة: اقترح دوال المشروع + دوال أندرويد ---- */
        boolean afterDot = before.matches("(?s).*[\\w\\)\\]]\\.\\w*$");

        if (!afterDot) {
            for (String k : (kotlin ? KT_KW : JAVA_KW))
                out.add(new Suggestion(k, k, "keyword", Suggestion.KIND_KEYWORD));
            for (String[] s : (kotlin ? SNIPPETS_KT : SNIPPETS_JAVA))
                out.add(new Suggestion(s[0], s[1], s[2], Suggestion.KIND_SNIPPET));
            for (String[] c : CLASSES)
                out.add(new Suggestion(c[0], c[0], c[1], Suggestion.KIND_CLASS));
            // متغيرات محلية ظاهرة في الملف
            Set<String> locals = new HashSet<>();
            Matcher lm = P_LOCAL_VAR.matcher(text.subSequence(0, cursor));
            while (lm.find()) locals.add(lm.group(1));
            for (String l : locals) out.add(new Suggestion(l, l, "local", Suggestion.KIND_LOCAL));
        }

        for (String[] a : ANDROID)
            out.add(new Suggestion(a[0], a[1], a[2], Suggestion.KIND_METHOD));

        if (index != null) {
            for (String m : index.methods())
                out.add(new Suggestion(m, m + "(|)", "project", Suggestion.KIND_METHOD));
            if (!afterDot) {
                for (String c : index.classes())
                    out.add(new Suggestion(c, c, "project", Suggestion.KIND_CLASS));
                for (String f : index.fields())
                    out.add(new Suggestion(f, f, "field", Suggestion.KIND_FIELD));
            }
        }

        // إزالة التكرار
        Set<String> seen = new HashSet<>();
        List<Suggestion> uniq = new ArrayList<>();
        for (Suggestion s : out) if (seen.add(s.label + "#" + s.kind)) uniq.add(s);

        return CompletionUtils.rank(uniq, prefix, 60);
    }

    public static boolean isKotlin(String fileName) {
        return fileName != null && fileName.toLowerCase().endsWith(".kt");
    }

    static { Arrays.sort(JAVA_KW); }
}
