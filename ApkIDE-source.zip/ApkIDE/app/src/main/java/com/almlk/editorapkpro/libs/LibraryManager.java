package com.almlk.editorapkpro.libs;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.util.ZipUtil;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * مدير المكتبات: تثبيت أي مكتبة (AAR / JAR) بأي إصدار داخل المشروع.
 *
 * • يجلب قائمة كل الإصدارات المتاحة من maven-metadata.xml عبر ثلاثة مستودعات:
 *   Maven Central، Google Maven، JitPack.
 * • ينزّل الملف ويضعه في app/libs.
 * • لملفات AAR: يفك classes.jar + res + assets + jni + R.txt ويدمجها في المشروع
 *   (لأن مشاريع الهندسة العكسية تُبنى عبر apktool وليس Gradle).
 * • يضيف السطر المقابل إلى app/build.gradle تلقائياً.
 */
public class LibraryManager {

    public static final String[] REPOS = {
            "https://repo1.maven.org/maven2",
            "https://dl.google.com/dl/android/maven2",
            "https://jitpack.io"
    };

    public static final String[] REPO_NAMES = {"Maven Central", "Google Maven", "JitPack"};

    private final Logger log;

    public LibraryManager(Logger log) { this.log = log; }

    /* ------------------------------ النماذج ------------------------------ */

    public static class Coordinate {
        public String group, artifact, version, packaging = "aar";

        public Coordinate(String g, String a, String v) { group = g; artifact = a; version = v; }

        /** يحلّل "com.google.android.material:material:1.12.0" */
        public static Coordinate parse(String s) {
            String[] p = s.trim().split(":");
            if (p.length < 2) throw new IllegalArgumentException(
                    "صيغة غير صحيحة. استخدم group:artifact:version");
            return new Coordinate(p[0], p[1], p.length > 2 ? p[2] : null);
        }

        public String path(String repo) {
            return repo + "/" + group.replace('.', '/') + "/" + artifact + "/" + version
                    + "/" + artifact + "-" + version + "." + packaging;
        }

        public String metadataUrl(String repo) {
            return repo + "/" + group.replace('.', '/') + "/" + artifact + "/maven-metadata.xml";
        }

        public String gradleLine() { return group + ":" + artifact + ":" + version; }

        public String fileName() { return artifact + "-" + version + "." + packaging; }

        @Override public String toString() { return gradleLine(); }
    }

    public static class InstallResult {
        public File   jar;
        public int    resFiles, assetFiles, soFiles;
        public String gradleLine;
        public String repoUsed;
    }

    public interface Progress { void step(String msg, int percent); }

    /* --------------------------- جلب الإصدارات --------------------------- */

    /** يعيد كل الإصدارات المتاحة للمكتبة من كل المستودعات (الأحدث أولاً). */
    public List<String> fetchVersions(Coordinate c) {
        List<String> all = new ArrayList<>();
        for (String repo : REPOS) {
            try {
                byte[] data = download(c.metadataUrl(repo), null);
                if (data == null) continue;
                Document d = javax.xml.parsers.DocumentBuilderFactory.newInstance()
                        .newDocumentBuilder()
                        .parse(new java.io.ByteArrayInputStream(data));
                NodeList vs = d.getElementsByTagName("version");
                for (int i = 0; i < vs.getLength(); i++) {
                    String v = vs.item(i).getTextContent().trim();
                    if (!v.isEmpty() && !all.contains(v)) all.add(v);
                }
                if (!all.isEmpty()) break;
            } catch (Exception ignored) {}
        }
        Collections.reverse(all);   // الأحدث أولاً
        return all;
    }

    /* ------------------------------ التثبيت ------------------------------ */

    public InstallResult install(Project p, Coordinate c, Progress pr) throws Exception {
        InstallResult r = new InstallResult();
        File libsDir = new File(p.root(), "app/libs");
        libsDir.mkdirs();

        byte[] data = null;
        String used = null;
        String[] packagings = {"aar", "jar"};

        outer:
        for (String pack : packagings) {
            c.packaging = pack;
            for (int i = 0; i < REPOS.length; i++) {
                String url = c.path(REPOS[i]);
                if (pr != null) pr.step("تجربة " + REPO_NAMES[i] + " (" + pack + ")…", -1);
                data = download(url, pr);
                if (data != null) { used = REPO_NAMES[i]; break outer; }
            }
        }
        if (data == null)
            throw new IllegalStateException("لم يُعثر على المكتبة في أي مستودع: " + c.gradleLine());

        r.repoUsed = used;
        log.i("lib: نُزّلت " + c.fileName() + " من " + used + " (" +
                FileUtil.humanSize(data.length) + ")");

        File out = new File(libsDir, c.fileName());
        FileUtil.write(out, data);

        if ("aar".equals(c.packaging)) {
            if (pr != null) pr.step("فك محتويات AAR ودمجه بالمشروع…", 70);
            r = explodeAar(p, out, r);
        } else {
            r.jar = out;
        }

        if (pr != null) pr.step("تحديث build.gradle…", 90);
        r.gradleLine = c.gradleLine();
        addGradleDependency(p, c.gradleLine());
        log.i("lib: تم تثبيت " + c.gradleLine());
        return r;
    }

    /** تثبيت ملف محلي اختاره المستخدم (aar/jar). */
    public InstallResult installLocal(Project p, File file, Progress pr) throws Exception {
        InstallResult r = new InstallResult();
        File libsDir = new File(p.root(), "app/libs");
        libsDir.mkdirs();
        File dst = new File(libsDir, file.getName());
        FileUtil.copyDir(file, dst);
        if (file.getName().toLowerCase().endsWith(".aar")) r = explodeAar(p, dst, r);
        else r.jar = dst;
        addGradleFileTree(p);
        log.i("lib: أُضيفت مكتبة محلية " + file.getName());
        return r;
    }

    /** يفك AAR: classes.jar + res + assets + jni + proguard إلى المشروع. */
    private InstallResult explodeAar(Project p, File aar, InstallResult r) throws Exception {
        File work = new File(aar.getParentFile(), FileUtil.nameNoExt(aar.getName()) + "_aar");
        FileUtil.delete(work);
        ZipUtil.unzip(aar, work);

        File classes = new File(work, "classes.jar");
        if (classes.exists()) {
            File jar = new File(aar.getParentFile(),
                    FileUtil.nameNoExt(aar.getName()) + ".jar");
            FileUtil.copyDir(classes, jar);
            r.jar = jar;
        }

        File res = new File(work, "res");
        if (res.exists() && p.resDir().exists()) {
            List<File> files = FileUtil.walk(res);
            for (File f : files) {
                String rel = f.getAbsolutePath().substring(res.getAbsolutePath().length() + 1);
                File dst = new File(p.resDir(), rel);
                if (!dst.exists()) { FileUtil.copyDir(f, dst); r.resFiles++; }
            }
        }

        File assets = new File(work, "assets");
        if (assets.exists()) {
            for (File f : FileUtil.walk(assets)) {
                String rel = f.getAbsolutePath().substring(assets.getAbsolutePath().length() + 1);
                File dst = new File(p.assetsDir(), rel);
                if (!dst.exists()) { FileUtil.copyDir(f, dst); r.assetFiles++; }
            }
        }

        File jni = new File(work, "jni");
        File jniDst = new File(p.mainDir(), "jniLibs");
        if (jni.exists()) {
            for (File f : FileUtil.walk(jni)) {
                String rel = f.getAbsolutePath().substring(jni.getAbsolutePath().length() + 1);
                File dst = new File(jniDst, rel);
                if (!dst.exists()) { FileUtil.copyDir(f, dst); r.soFiles++; }
            }
        }
        log.i("lib: من AAR ➜ " + r.resFiles + " مورد، " + r.assetFiles + " أصل، "
                + r.soFiles + " مكتبة أصلية");
        FileUtil.delete(work);
        return r;
    }

    /* --------------------------- تعديل build.gradle --------------------------- */

    public void addGradleDependency(Project p, String line) throws Exception {
        File g = new File(p.root(), "app/build.gradle");
        if (!g.exists()) return;
        String s = FileUtil.read(g);
        if (s.contains(line)) return;
        Matcher m = Pattern.compile("dependencies\\s*\\{").matcher(s);
        if (m.find()) {
            s = s.substring(0, m.end()) + "\n    implementation '" + line + "'"
                    + s.substring(m.end());
        } else {
            s += "\n\ndependencies {\n    implementation '" + line + "'\n}\n";
        }
        FileUtil.write(g, s);
    }

    public void addGradleFileTree(Project p) throws Exception {
        File g = new File(p.root(), "app/build.gradle");
        if (!g.exists()) return;
        String s = FileUtil.read(g);
        String line = "implementation fileTree(dir: 'libs', include: ['*.jar'])";
        if (s.contains(line)) return;
        Matcher m = Pattern.compile("dependencies\\s*\\{").matcher(s);
        if (m.find()) s = s.substring(0, m.end()) + "\n    " + line + s.substring(m.end());
        FileUtil.write(g, s);
    }

    /** قائمة المكتبات المثبتة حالياً في المشروع. */
    public List<File> installed(Project p) {
        File libs = new File(p.root(), "app/libs");
        File[] f = libs.listFiles((d, n) -> {
            String x = n.toLowerCase();
            return x.endsWith(".jar") || x.endsWith(".aar");
        });
        List<File> out = f == null ? new ArrayList<>() : new ArrayList<>(Arrays.asList(f));
        out.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return out;
    }

    public void remove(Project p, File lib) {
        FileUtil.delete(lib);
        log.i("lib: حُذفت " + lib.getName());
    }

    /* ------------------------------ التنزيل ------------------------------ */

    private byte[] download(String url, Progress pr) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(url).openConnection();
            con.setConnectTimeout(15000);
            con.setReadTimeout(60000);
            con.setInstanceFollowRedirects(true);
            con.setRequestProperty("User-Agent", "EditorApkPro/1.0");
            int code = con.getResponseCode();
            if (code != 200) return null;
            int len = con.getContentLength();
            try (InputStream in = con.getInputStream()) {
                java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                byte[] buf = new byte[32768];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    bos.write(buf, 0, n);
                    total += n;
                    if (pr != null && len > 0)
                        pr.step("تنزيل… " + FileUtil.humanSize(total), total * 60 / len);
                }
                return bos.toByteArray();
            }
        } catch (Exception e) {
            return null;
        } finally { if (con != null) con.disconnect(); }
    }

    /* --------------------------- مكتبات شائعة جاهزة --------------------------- */

    public static final String[][] POPULAR = {
        {"androidx.appcompat:appcompat",                 "واجهات متوافقة مع الإصدارات القديمة"},
        {"com.google.android.material:material",         "Material Design 3"},
        {"androidx.constraintlayout:constraintlayout",   "تخطيط القيود"},
        {"androidx.recyclerview:recyclerview",           "قوائم عالية الأداء"},
        {"androidx.cardview:cardview",                   "بطاقات"},
        {"androidx.core:core",                           "مكتبة أندرويد الأساسية"},
        {"androidx.fragment:fragment",                   "الأجزاء"},
        {"androidx.viewpager2:viewpager2",               "تمرير الصفحات"},
        {"androidx.lifecycle:lifecycle-runtime",         "دورة الحياة"},
        {"androidx.room:room-runtime",                   "قاعدة بيانات Room"},
        {"androidx.work:work-runtime",                   "مهام الخلفية"},
        {"androidx.navigation:navigation-fragment",      "التنقل"},
        {"androidx.multidex:multidex",                   "دعم تعدد DEX"},
        {"com.squareup.okhttp3:okhttp",                  "عميل HTTP"},
        {"com.squareup.retrofit2:retrofit",              "REST API"},
        {"com.google.code.gson:gson",                    "JSON"},
        {"com.github.bumptech.glide:glide",              "تحميل الصور"},
        {"com.squareup.picasso:picasso",                 "تحميل الصور"},
        {"io.reactivex.rxjava3:rxjava",                  "البرمجة التفاعلية"},
        {"org.jetbrains.kotlin:kotlin-stdlib",           "مكتبة Kotlin القياسية"},
        {"org.jetbrains.kotlinx:kotlinx-coroutines-android", "الكوروتينات"},
        {"com.google.dagger:dagger",                     "حقن الاعتماديات"},
        {"com.google.android.gms:play-services-ads",     "إعلانات AdMob"},
        {"com.google.firebase:firebase-analytics",       "Firebase"},
        {"org.apache.commons:commons-lang3",             "أدوات Java"},
        {"commons-io:commons-io",                        "أدوات الملفات"},
    };
}
