package com.almlk.editorapkpro.ui.adapter;

import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.model.AppInfo;
import com.almlk.editorapkpro.util.FileUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** محوّل قائمة التطبيقات مع فلترة فورية بالاسم أو الحزمة. */
public class AppAdapter extends RecyclerView.Adapter<AppAdapter.VH> {

    public interface OnClick { void onApp(AppInfo a); }

    private final List<AppInfo> all      = new ArrayList<>();
    private final List<AppInfo> filtered = new ArrayList<>();
    private final OnClick click;
    private final PackageManager packages;
    private String query = "";

    public AppAdapter(PackageManager packages,OnClick c) {
        this.packages=packages;this.click = c;
    }

    public void submit(List<AppInfo> data) {
        all.clear(); all.addAll(data);
        filter(query);
    }

    /** فلترة لحظية (يُستدعى عند كل حرف). */
    public void filter(String q) {
        query = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        filtered.clear();
        if (query.isEmpty()) filtered.addAll(all);
        else for (AppInfo a : all) if (a.haystack != null && a.haystack.contains(query)) filtered.add(a);
        notifyDataSetChanged();
    }

    public int shown() { return filtered.size(); }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int t) {
        return new VH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int i) {
        AppInfo a = filtered.get(i);
        h.name.setText(a.label);
        h.pkg.setText(a.packageName);
        h.meta.setText("v" + a.versionName + "  •  " + FileUtil.humanSize(a.apkSize)
                + (a.system ? "  •  نظام" : ""));
        // حمّل الأيقونة لحامل الصف المرئي فقط؛ تخزين مئات Drawables كان يبقي عشرات
        // الميغابايت حية أثناء الفك ويتسبب في OOM عند حد heap البالغ 512MB.
        h.icon.setImageResource(R.drawable.ic_apps);
        try { h.icon.setImageDrawable(packages.getApplicationIcon(a.packageName)); }
        catch (Exception ignored) {}
        h.itemView.setOnClickListener(v -> click.onApp(a));
    }

    @Override public void onViewRecycled(@NonNull VH holder){
        holder.icon.setImageDrawable(null);
        super.onViewRecycled(holder);
    }

    @Override public int getItemCount() { return filtered.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView icon; TextView name, pkg, meta;
        VH(@NonNull View v) {
            super(v);
            icon = v.findViewById(R.id.icon);
            name = v.findViewById(R.id.txtName);
            pkg  = v.findViewById(R.id.txtPkg);
            meta = v.findViewById(R.id.txtMeta);
        }
    }
}
