package com.almlk.editorapkpro.model;

public class AppInfo {
    public String  label;
    public String  packageName;
    public String  versionName;
    public long    versionCode;
    public String  sourceApk;      // مسار base.apk
    public String[] splitApks;     // مسارات split apks إن وجدت
    public long    apkSize;
    public boolean system;
    public int     minSdk, targetSdk;

    /** نص البحث المدمج (الاسم + الحزمة) لتسريع الفلترة الفورية. */
    public String haystack;

    public void buildHaystack() {
        haystack = ((label == null ? "" : label) + " " +
                    (packageName == null ? "" : packageName)).toLowerCase();
    }
}
