package com.almlk.editorapkpro.compiler;

import android.content.Context;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import java.io.File;
import java.io.InputStream;

/** استخراج مفتاح PKCS12 الافتراضي المشحون داخل التطبيق. */
public final class KeystoreManager {
    public static final String PASSWORD = "apkide";
    public static final String ALIAS = "apkide";
    private KeystoreManager() {}

    public static File ensureDebugKeystore(Context c) {
        File out = new File(Env.keystoreDir(), "apkide-debug.p12");
        if (out.exists() && out.length() > 0) return out;
        try (InputStream in = c.getAssets().open("keystore/apkide-debug.p12")) {
            FileUtil.copy(in, out);
        } catch (Exception ignored) {}
        return out;
    }
}
