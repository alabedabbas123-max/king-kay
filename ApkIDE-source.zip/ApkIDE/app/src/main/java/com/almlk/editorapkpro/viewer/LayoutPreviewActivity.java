package com.almlk.editorapkpro.viewer;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.TypedValue;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.ui.Ui;
import com.google.android.material.appbar.MaterialToolbar;

import org.xmlpull.v1.XmlPullParser;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Locale;
import java.util.Set;

/**
 * معاينة خفيفة وآمنة لملفات res/layout الخام.
 *
 * لا يمكن لـ LayoutInflater تحميل XML مشروع خارجي غير مُصرّف لأن معرفات موارده ليست
 * في resources.arsc الخاص بالمحرر. لذلك يبني هذا العارض شجرة Android حقيقية من
 * XmlPullParser، ويحل النصوص والألوان والأبعاد وصور bitmap من مجلد res. العناصر
 * المخصصة وConstraintLayout تُعرض تقريبياً بدلاً من تشغيل كود غير موثوق من المشروع.
 */
@SuppressWarnings("deprecation")
public class LayoutPreviewActivity extends AppCompatActivity {
    public static final String EXTRA_FILE="layout_file";
    public static final String EXTRA_RES="res_dir";

    private static final String ANDROID="http://schemas.android.com/apk/res/android";
    private static final String TOOLS="http://schemas.android.com/tools";

    private File source,resDir;
    private FrameLayout phone;
    private TextView info;
    private final Map<String,String> values=new HashMap<>();
    private final Set<String> includeStack=new HashSet<>();

    @Override protected void onCreate(@Nullable Bundle state){
        super.onCreate(state);
        String file=getIntent().getStringExtra(EXTRA_FILE);
        String res=getIntent().getStringExtra(EXTRA_RES);
        if(file==null||res==null){finish();return;}
        source=new File(file);resDir=new File(res);
        setContentView(createPage());
        loadValues();
        render();
    }

    private View createPage(){
        LinearLayout page=new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(0xFF0D1117);

        MaterialToolbar toolbar=new MaterialToolbar(this);
        toolbar.setNavigationIcon(R.drawable.ic_close);
        toolbar.setNavigationOnClickListener(v->finish());
        toolbar.setTitle(source.getName());
        toolbar.setSubtitle("معاينة تصميم XML");
        toolbar.setTitleTextColor(0xFFF0F3F6);toolbar.setSubtitleTextColor(0xFF9AA7B4);
        toolbar.setBackgroundColor(0xFF161B22);
        toolbar.getMenu().add("تحديث").setIcon(R.drawable.ic_layout_preview)
                .setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS);
        toolbar.setOnMenuItemClickListener(item->{render();return true;});
        page.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(60)));

        ScrollView vertical=new ScrollView(this);
        vertical.setFillViewport(true);vertical.setBackgroundColor(0xFF20262E);
        HorizontalScrollView horizontal=new HorizontalScrollView(this);
        horizontal.setFillViewport(true);
        LinearLayout stage=new LinearLayout(this);
        stage.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        stage.setPadding(dp(18),dp(18),dp(18),dp(18));
        stage.setBackgroundColor(0xFF20262E);

        phone=new FrameLayout(this);
        phone.setBackgroundColor(0xFFFAFAFA);phone.setClipToPadding(true);
        phone.setElevation(dp(8));
        LinearLayout.LayoutParams phoneLp=new LinearLayout.LayoutParams(dp(360),dp(640));
        stage.addView(phone,phoneLp);
        horizontal.addView(stage,new HorizontalScrollView.LayoutParams(-1,-2));
        vertical.addView(horizontal,new ScrollView.LayoutParams(-1,-2));
        page.addView(vertical,new LinearLayout.LayoutParams(-1,0,1f));

        info=new TextView(this);
        info.setTextColor(0xFF9AA7B4);info.setTextSize(11);info.setGravity(Gravity.CENTER_VERTICAL);
        info.setPadding(dp(12),0,dp(12),0);info.setSingleLine(true);
        info.setEllipsize(TextUtils.TruncateAt.END);info.setBackgroundColor(0xFF161B22);
        page.addView(info,new LinearLayout.LayoutParams(-1,dp(38)));
        return page;
    }

    private void render(){
        phone.removeAllViews();includeStack.clear();
        try{
            View root=renderFile(source,0);
            if(root==null)throw new IllegalArgumentException("ملف التخطيط فارغ");
            LayoutSpec spec=spec(root);
            int w=spec.width==ViewGroup.LayoutParams.WRAP_CONTENT?ViewGroup.LayoutParams.MATCH_PARENT:spec.width;
            int h=spec.height==ViewGroup.LayoutParams.WRAP_CONTENT?ViewGroup.LayoutParams.MATCH_PARENT:spec.height;
            if(w==0)w=ViewGroup.LayoutParams.MATCH_PARENT;if(h==0)h=ViewGroup.LayoutParams.MATCH_PARENT;
            phone.addView(root,new FrameLayout.LayoutParams(w,h));
            info.setText("360 × 640 dp  •  معاينة آمنة تقريبية  •  "+relative(source));
        }catch(Throwable error){
            TextView message=textView("تعذرت معاينة التخطيط\n\n"+
                    (error.getMessage()==null?error.toString():error.getMessage()),14,0xFFFF7B72);
            message.setGravity(Gravity.CENTER);message.setPadding(dp(24),dp(24),dp(24),dp(24));
            phone.addView(message,new FrameLayout.LayoutParams(-1,-1));
            info.setText("تحقق من صحة XML ثم اضغط تحديث");
        }
    }

    private View renderFile(File file,int depth)throws Exception{
        if(depth>12)throw new IllegalArgumentException("تداخل include أعمق من الحد الآمن");
        String canonical=file.getCanonicalPath();
        if(!includeStack.add(canonical))throw new IllegalArgumentException("حلقة include: "+file.getName());
        try(InputStream in=new FileInputStream(file)){
            XmlPullParser parser=Xml.newPullParser();
            parser.setInput(in,"UTF-8");
            int event;
            do{event=parser.next();}while(event!=XmlPullParser.START_TAG&&event!=XmlPullParser.END_DOCUMENT);
            if(event!=XmlPullParser.START_TAG)return null;
            return readNode(parser,depth);
        }finally{includeStack.remove(canonical);}
    }

    /** يقرأ عقدة كاملة؛ عند الرجوع يكون parser واقفاً على END_TAG الخاص بها. */
    private View readNode(XmlPullParser parser,int depth)throws Exception{
        String tag=parser.getName();
        if("include".equals(tag)){
            LayoutSpec includeSpec=readSpec(parser);
            String ref=attr(parser,"layout");
            View included=null;
            if(ref!=null&&ref.startsWith("@layout/")){
                File f=findLayout(ref.substring("@layout/".length()));
                if(f!=null)included=renderFile(f,depth+1);
            }
            skipTag(parser);
            if(included==null)included=placeholder("include "+String.valueOf(ref));
            mergeSpec(spec(included),includeSpec);
            return included;
        }

        View view=createView(tag,parser);
        int ownDepth=parser.getDepth();
        while(true){
            int event=parser.next();
            if(event==XmlPullParser.END_DOCUMENT)break;
            if(event==XmlPullParser.START_TAG&&parser.getDepth()==ownDepth+1){
                View child=readNode(parser,depth+1);
                if(child!=null&&view instanceof ViewGroup)addChild((ViewGroup)view,child);
            }else if(event==XmlPullParser.END_TAG&&parser.getDepth()==ownDepth)break;
        }
        return view;
    }

    private void skipTag(XmlPullParser parser)throws Exception{
        int depth=parser.getDepth();
        while(!(parser.getEventType()==XmlPullParser.END_TAG&&parser.getDepth()==depth)
                &&parser.getEventType()!=XmlPullParser.END_DOCUMENT)parser.next();
    }

    private View createView(String full,XmlPullParser parser){
        String name=full.substring(full.lastIndexOf('.')+1);
        View view;
        if(name.contains("HorizontalScrollView")){
            HorizontalScrollView x=new HorizontalScrollView(this);x.setFillViewport(true);view=x;
        }else if(name.contains("ScrollView")||name.contains("NestedScrollView")){
            ScrollView x=new ScrollView(this);x.setFillViewport(true);view=x;
        }else if(name.contains("LinearLayout")||"merge".equals(name)){
            LinearLayout x=new LinearLayout(this);
            x.setOrientation("horizontal".equals(attr(parser,"orientation"))
                    ?LinearLayout.HORIZONTAL:LinearLayout.VERTICAL);view=x;
        }else if(name.contains("FrameLayout")){
            view=new FrameLayout(this);
        }else if(name.contains("ConstraintLayout")||name.contains("RelativeLayout")
                ||name.contains("CoordinatorLayout")||name.contains("DrawerLayout")
                ||name.contains("AppBarLayout")||name.contains("CollapsingToolbarLayout")){
            // نعرض كل الأبناء بوضوح؛ تشغيل محرك constraints الخارجي يتطلب مكتبات المشروع.
            LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);view=x;
        }else if(name.contains("RecyclerView")||name.contains("ListView")||name.contains("GridView")){
            view=placeholder(name+"\n────────────\nعنصر 1\n────────────\nعنصر 2");
        }else if(name.contains("ImageView")||name.contains("ImageButton")){
            String src=first(attr(parser,"src"),attr(parser,"srcCompat"));
            TextView image=placeholder("▧\n"+(src==null?name:src));image.setGravity(Gravity.CENTER);view=image;
        }else if(name.contains("EditText")||name.contains("TextInputEditText")){
            EditText edit=new EditText(this);
            edit.setSingleLine("true".equals(attr(parser,"singleLine"))
                    ||parseInt(attr(parser,"maxLines"),-1)==1);
            edit.setText(resolveText(attr(parser,"text")));
            edit.setHint(resolveText(first(attr(parser,"hint"),"إدخال نص")));view=edit;
        }else if(name.contains("Button")&&!name.contains("Radio")){
            Button button=new Button(this);button.setText(resolveText(first(attr(parser,"text"),"Button")));view=button;
        }else if(name.contains("CheckBox")){
            CheckBox box=new CheckBox(this);box.setText(resolveText(first(attr(parser,"text"),"CheckBox")));
            box.setChecked("true".equals(attr(parser,"checked")));view=box;
        }else if(name.contains("RadioButton")){
            RadioButton radio=new RadioButton(this);radio.setText(resolveText(first(attr(parser,"text"),"Radio")));
            radio.setChecked("true".equals(attr(parser,"checked")));view=radio;
        }else if(name.contains("Switch")){
            SwitchCompat sw=new SwitchCompat(this);sw.setText(resolveText(first(attr(parser,"text"),"Switch")));
            sw.setChecked("true".equals(attr(parser,"checked")));view=sw;
        }else if(name.contains("ProgressBar")){
            view=new ProgressBar(this);
        }else if(name.contains("TextView")||name.contains("Toolbar")||name.contains("Chip")){
            TextView text=textView(resolveText(first(attr(parser,"text"),name.contains("Toolbar")?"Toolbar":"Text")),
                    parseSp(attr(parser,"textSize"),14),0xFF202124);view=text;
            if(name.contains("Toolbar")){text.setTypeface(Typeface.DEFAULT,Typeface.BOLD);text.setGravity(Gravity.CENTER_VERTICAL);}
        }else if("View".equals(name)||"Space".equals(name)){
            view=new View(this);view.setBackgroundColor(0x222196F3);
        }else if(looksLikeLayout(name)){
            LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);view=x;
        }else{
            view=placeholder("<"+name+">");
        }

        view.setTag(readSpec(parser));
        applyCommon(view,parser);
        return view;
    }

    private boolean looksLikeLayout(String name){
        return name.endsWith("Layout")||name.endsWith("Group")||name.endsWith("Container");
    }

    private void applyCommon(View view,XmlPullParser parser){
        String visibility=attr(parser,"visibility");
        if("gone".equals(visibility))view.setVisibility(View.GONE);
        else if("invisible".equals(visibility))view.setVisibility(View.INVISIBLE);
        String alpha=attr(parser,"alpha");
        if(alpha!=null)try{view.setAlpha(Float.parseFloat(alpha));}catch(Exception ignored){}

        int all=dimension(attr(parser,"padding"),0);
        int left=dimension(first(attr(parser,"paddingStart"),attr(parser,"paddingLeft")),all);
        int right=dimension(first(attr(parser,"paddingEnd"),attr(parser,"paddingRight")),all);
        int top=dimension(attr(parser,"paddingTop"),all);
        int bottom=dimension(attr(parser,"paddingBottom"),all);
        view.setPadding(left,top,right,bottom);

        String background=attr(parser,"background");
        Integer bg=resolveColor(background);
        if(bg!=null)view.setBackgroundColor(bg);
        else if(background!=null&&background.startsWith("@drawable/"))view.setBackground(box(0xFFF3F4F6,0xFF9AA7B4));

        if(view instanceof TextView){
            TextView text=(TextView)view;
            Integer color=resolveColor(attr(parser,"textColor"));if(color!=null)text.setTextColor(color);
            String size=attr(parser,"textSize");if(size!=null)text.setTextSize(TypedValue.COMPLEX_UNIT_SP,parseSp(size,14));
            String gravity=attr(parser,"gravity");if(gravity!=null)text.setGravity(parseGravity(gravity));
            int lines=parseInt(attr(parser,"maxLines"),-1);if(lines>0)text.setMaxLines(lines);
            if("true".equals(attr(parser,"textAllCaps")))text.setAllCaps(true);
        }
        String gravity=attr(parser,"gravity");
        if(view instanceof LinearLayout&&gravity!=null)((LinearLayout)view).setGravity(parseGravity(gravity));
    }

    private LayoutSpec readSpec(XmlPullParser parser){
        LayoutSpec out=new LayoutSpec();
        out.width=layoutDimension(attr(parser,"layout_width"),ViewGroup.LayoutParams.WRAP_CONTENT);
        out.height=layoutDimension(attr(parser,"layout_height"),ViewGroup.LayoutParams.WRAP_CONTENT);
        out.weight=parseFloat(attr(parser,"layout_weight"),0f);
        int all=dimension(attr(parser,"layout_margin"),0);
        out.left=dimension(first(attr(parser,"layout_marginStart"),attr(parser,"layout_marginLeft")),all);
        out.right=dimension(first(attr(parser,"layout_marginEnd"),attr(parser,"layout_marginRight")),all);
        out.top=dimension(attr(parser,"layout_marginTop"),all);
        out.bottom=dimension(attr(parser,"layout_marginBottom"),all);
        out.gravity=parseGravity(attr(parser,"layout_gravity"));
        return out;
    }

    private void addChild(ViewGroup parent,View child){
        LayoutSpec s=spec(child);
        try{
            if((parent instanceof ScrollView||parent instanceof HorizontalScrollView)&&parent.getChildCount()>0){
                // XML غير صالح أو عارض مبسّط: اجمع الأبناء بدلاً من رمي IllegalStateException.
                View old=parent.getChildAt(0);parent.removeView(old);
                LinearLayout group=new LinearLayout(this);group.setOrientation(LinearLayout.VERTICAL);
                group.addView(old);group.addView(child);parent.addView(group,new FrameLayout.LayoutParams(-1,-2));return;
            }
            if(parent instanceof LinearLayout){
                // match_constraint (0dp) يحتاج محرك ConstraintLayout غير المحمّل هنا؛
                // اجعله مرئياً في المعاينة بدلاً من إنتاج عنصر عرضه/ارتفاعه صفر.
                int width=s.width==0&&s.weight==0?ViewGroup.LayoutParams.MATCH_PARENT:s.width;
                int height=s.height==0&&s.weight==0?ViewGroup.LayoutParams.WRAP_CONTENT:s.height;
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(width,height,s.weight);
                lp.setMargins(s.left,s.top,s.right,s.bottom);lp.gravity=s.gravity;parent.addView(child,lp);
            }else{
                FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(s.width,s.height,s.gravity);
                lp.setMargins(s.left,s.top,s.right,s.bottom);parent.addView(child,lp);
            }
        }catch(Exception ignored){parent.addView(child,new ViewGroup.LayoutParams(-1,-2));}
    }

    private LayoutSpec spec(View view){
        Object tag=view.getTag();return tag instanceof LayoutSpec?(LayoutSpec)tag:new LayoutSpec();
    }

    private void mergeSpec(LayoutSpec base,LayoutSpec override){
        if(override.width!=ViewGroup.LayoutParams.WRAP_CONTENT)base.width=override.width;
        if(override.height!=ViewGroup.LayoutParams.WRAP_CONTENT)base.height=override.height;
        if(override.weight!=0)base.weight=override.weight;
        if(override.left+override.right+override.top+override.bottom!=0){
            base.left=override.left;base.right=override.right;base.top=override.top;base.bottom=override.bottom;
        }
    }

    private static class LayoutSpec{
        int width=ViewGroup.LayoutParams.WRAP_CONTENT,height=ViewGroup.LayoutParams.WRAP_CONTENT;
        int left,right,top,bottom,gravity=Gravity.NO_GRAVITY;float weight;
    }

    /* ------------------------- موارد المشروع ------------------------- */

    private void loadValues(){
        values.clear();File[] dirs=resDir.listFiles(f->f.isDirectory()&&f.getName().startsWith("values"));
        if(dirs==null)return;
        // القيم الأساسية أولاً، ثم أي qualifier متاح كاحتياط.
        java.util.Arrays.sort(dirs,(a,b)->a.getName().length()-b.getName().length());
        for(File dir:dirs){
            File[] files=dir.listFiles(f->f.isFile()&&f.getName().endsWith(".xml"));if(files==null)continue;
            for(File file:files)readValuesFile(file);
        }
    }

    private void readValuesFile(File file){
        try(InputStream in=new FileInputStream(file)){
            XmlPullParser p=Xml.newPullParser();p.setInput(in,"UTF-8");
            while(p.next()!=XmlPullParser.END_DOCUMENT){
                if(p.getEventType()!=XmlPullParser.START_TAG)continue;
                String type=p.getName(),name=p.getAttributeValue(null,"name");
                if("item".equals(type))type=p.getAttributeValue(null,"type");
                if(name==null||!("string".equals(type)||"color".equals(type)||"dimen".equals(type)))continue;
                int depth=p.getDepth();StringBuilder text=new StringBuilder();
                while(p.next()!=XmlPullParser.END_DOCUMENT){
                    if(p.getEventType()==XmlPullParser.TEXT)text.append(p.getText());
                    else if(p.getEventType()==XmlPullParser.END_TAG&&p.getDepth()==depth)break;
                }
                values.putIfAbsent(type+"/"+name,text.toString().trim());
            }
        }catch(Exception ignored){}
    }

    private String resolveText(String raw){
        if(raw==null)return "";
        if(raw.startsWith("@string/"))return first(values.get("string/"+raw.substring(8)),raw.substring(8));
        if(raw.startsWith("@android:string/"))return raw.substring(raw.lastIndexOf('/')+1).replace('_',' ');
        if("@null".equals(raw))return "";
        return raw.replace("\\n","\n");
    }

    private Integer resolveColor(String raw){
        if(raw==null)return null;
        for(int i=0;i<4&&raw!=null&&raw.startsWith("@color/");i++)
            raw=values.get("color/"+raw.substring(7));
        if(raw==null)return null;
        if(raw.startsWith("?"))return 0xFF4C8DFF;
        if("@android:color/transparent".equals(raw))return Color.TRANSPARENT;
        if(raw.startsWith("@android:color/")){
            String n=raw.substring(raw.lastIndexOf('/')+1);
            if("white".equals(n))return Color.WHITE;if("black".equals(n))return Color.BLACK;
            if("darker_gray".equals(n))return Color.DKGRAY;if("transparent".equals(n))return Color.TRANSPARENT;
        }
        try{return Color.parseColor(raw.trim());}catch(Exception ignored){return null;}
    }

    private int layoutDimension(String raw,int fallback){
        if(raw==null)return fallback;
        if("match_parent".equals(raw)||"fill_parent".equals(raw))return ViewGroup.LayoutParams.MATCH_PARENT;
        if("wrap_content".equals(raw))return ViewGroup.LayoutParams.WRAP_CONTENT;
        if(raw.startsWith("@dimen/"))raw=values.get("dimen/"+raw.substring(7));
        if(raw!=null&&raw.startsWith("?attr/"))return raw.toLowerCase().contains("actionbar")?dp(56):fallback;
        return dimension(raw,fallback);
    }

    private int dimension(String raw,int fallback){
        if(raw==null)return fallback;
        if(raw.startsWith("@dimen/"))raw=values.get("dimen/"+raw.substring(7));
        if(raw==null)return fallback;
        try{
            String x=raw.trim().toLowerCase(Locale.ROOT);
            if(x.endsWith("dip"))x=x.substring(0,x.length()-3);
            else if(x.endsWith("dp")||x.endsWith("sp")||x.endsWith("px"))x=x.substring(0,x.length()-2);
            float n=Float.parseFloat(x);return raw.toLowerCase(Locale.ROOT).endsWith("px")?(int)n:dp(n);
        }catch(Exception ignored){return fallback;}
    }

    private float parseSp(String raw,float fallback){
        if(raw==null)return fallback;
        if(raw.startsWith("@dimen/"))raw=values.get("dimen/"+raw.substring(7));
        if(raw==null)return fallback;
        try{return Float.parseFloat(raw.replaceAll("(?i)(sp|dp|dip|px)$",""));}
        catch(Exception ignored){return fallback;}
    }

    private int parseGravity(String raw){
        if(raw==null)return Gravity.NO_GRAVITY;int out=0;
        for(String p:raw.split("\\|")){
            if("center".equals(p))out|=Gravity.CENTER;else if("center_horizontal".equals(p))out|=Gravity.CENTER_HORIZONTAL;
            else if("center_vertical".equals(p))out|=Gravity.CENTER_VERTICAL;else if("start".equals(p)||"left".equals(p))out|=Gravity.START;
            else if("end".equals(p)||"right".equals(p))out|=Gravity.END;else if("top".equals(p))out|=Gravity.TOP;
            else if("bottom".equals(p))out|=Gravity.BOTTOM;
        }
        return out;
    }

    private File findLayout(String name){
        File[] dirs=resDir.listFiles(f->f.isDirectory()&&f.getName().startsWith("layout"));if(dirs==null)return null;
        for(File dir:dirs){File f=new File(dir,name+".xml");if(f.isFile())return f;}return null;
    }

    private String attr(XmlPullParser parser,String name){
        String value=parser.getAttributeValue(ANDROID,name);
        if(value==null)value=parser.getAttributeValue(null,name);
        if(value==null)value=parser.getAttributeValue(TOOLS,name);
        if(value==null){
            for(int i=0;i<parser.getAttributeCount();i++)
                if(name.equals(parser.getAttributeName(i))){value=parser.getAttributeValue(i);break;}
        }
        return value;
    }

    private TextView placeholder(String label){
        TextView t=textView(label,12,0xFF5F6368);t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8),dp(8),dp(8),dp(8));t.setBackground(box(0xFFF1F3F4,0xFF9AA0A6));
        t.setMinHeight(dp(48));return t;
    }

    private TextView textView(String value,float size,int color){
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);return t;
    }

    private GradientDrawable box(int fill,int stroke){
        GradientDrawable d=new GradientDrawable();d.setColor(fill);d.setStroke(dp(1),stroke);d.setCornerRadius(dp(3));return d;
    }

    private String relative(File file){
        try{return file.getCanonicalPath().replace(resDir.getCanonicalPath()+File.separator,"res/");}
        catch(Exception ignored){return file.getName();}
    }

    private String first(String a,String b){return a==null||a.isEmpty()?b:a;}
    private int parseInt(String value,int fallback){try{return Integer.parseInt(value);}catch(Exception e){return fallback;}}
    private float parseFloat(String value,float fallback){try{return Float.parseFloat(value);}catch(Exception e){return fallback;}}
    private int dp(float value){return(int)(value*getResources().getDisplayMetrics().density+.5f);}
}
