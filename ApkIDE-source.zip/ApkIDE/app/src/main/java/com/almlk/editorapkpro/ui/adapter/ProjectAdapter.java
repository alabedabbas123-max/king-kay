package com.almlk.editorapkpro.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.VH> {

    public interface Listener { void onOpen(Project p); void onLong(Project p); }

    private final List<Project> data = new ArrayList<>();
    private final Listener listener;

    public ProjectAdapter(Listener l) { listener = l; }

    public void submit(List<Project> p) { data.clear(); data.addAll(p); notifyDataSetChanged(); }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int t) {
        return new VH(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_project, parent, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int i) {
        Project p = data.get(i);
        h.name.setText(p.appName == null ? p.name : p.appName);
        h.pkg.setText(p.packageName);
        h.meta.setText((p.mode == Project.MODE_SOURCE ? "مشروع مصدر كامل" : "موارد + smali")
                + "  •  v" + p.versionName
                + "  •  " + FileUtil.humanSize(FileUtil.sizeOf(p.root()))
                + "  •  " + new SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
                        .format(new Date(p.createdAt)));
        h.itemView.setOnClickListener(v -> listener.onOpen(p));
        h.itemView.setOnLongClickListener(v -> { listener.onLong(p); return true; });
    }

    @Override public int getItemCount() { return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView name, pkg, meta;
        VH(@NonNull View v) {
            super(v);
            name = v.findViewById(R.id.txtName);
            pkg  = v.findViewById(R.id.txtPkg);
            meta = v.findViewById(R.id.txtMeta);
        }
    }
}
