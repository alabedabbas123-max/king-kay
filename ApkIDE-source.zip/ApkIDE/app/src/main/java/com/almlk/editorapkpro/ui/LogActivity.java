package com.almlk.editorapkpro.ui;

import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.Engine;
import com.almlk.editorapkpro.engine.Logger;

/** عرض حي لسجل آخر عملية. */
public class LogActivity extends AppCompatActivity implements Logger.Sink {

    private TextView txt;
    private ScrollView scroll;
    private Logger log;

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_log);
        txt = findViewById(R.id.txtLog);
        scroll = findViewById(R.id.scroll);
        log = Engine.get().currentLog();
        if (log == null) txt.setText("لا يوجد سجل بعد. ابدأ عملية فك أو بناء.");
        else log.addSink(this);
    }

    @Override public void onLine(String line) {
        runOnUiThread(() -> {
            txt.append(line + "\n");
            scroll.post(() -> scroll.fullScroll(ScrollView.FOCUS_DOWN));
        });
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (log != null) log.removeSink(this);
    }
}
