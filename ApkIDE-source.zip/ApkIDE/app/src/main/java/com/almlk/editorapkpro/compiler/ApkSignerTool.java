package com.almlk.editorapkpro.compiler;

import com.almlk.editorapkpro.engine.Logger;
import com.android.apksig.ApkSigner;
import java.io.File;
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

/** توقيع APK فعلياً عبر apksig مع v1/v2/v3. */
public final class ApkSignerTool {
    private ApkSignerTool() {}

    public static File sign(File input, File output, File store, String password,
                            String alias, Logger log) throws Exception {
        KeyStore ks = KeyStore.getInstance(store.getName().toLowerCase().endsWith(".p12")
                ? "PKCS12" : KeyStore.getDefaultType());
        try (FileInputStream in = new FileInputStream(store)) {
            ks.load(in, password.toCharArray());
        }
        if (alias == null || !ks.containsAlias(alias)) {
            Enumeration<String> e = ks.aliases();
            if (!e.hasMoreElements()) throw new IllegalStateException("لا يحتوي المفتاح على alias صالح");
            alias = e.nextElement();
        }
        PrivateKey key = (PrivateKey) ks.getKey(alias, password.toCharArray());
        if (key == null) throw new IllegalStateException("تعذّر قراءة المفتاح الخاص");
        List<X509Certificate> certs = new ArrayList<>();
        java.security.cert.Certificate[] chain = ks.getCertificateChain(alias);
        if (chain != null) for (java.security.cert.Certificate c : chain)
            certs.add((X509Certificate) c);
        if (certs.isEmpty()) certs.add((X509Certificate) ks.getCertificate(alias));

        ApkSigner.SignerConfig sc = new ApkSigner.SignerConfig.Builder(alias, key, certs).build();
        new ApkSigner.Builder(Collections.singletonList(sc))
                .setInputApk(input).setOutputApk(output)
                .setV1SigningEnabled(true).setV2SigningEnabled(true).setV3SigningEnabled(true)
                .build().sign();
        log.i("sign: تم توقيع " + output.getName() + " (v1/v2/v3)");
        return output;
    }
}
