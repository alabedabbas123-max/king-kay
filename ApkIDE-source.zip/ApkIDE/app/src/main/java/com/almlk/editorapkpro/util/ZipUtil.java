package com.almlk.editorapkpro.util;

import java.io.*;
import java.util.*;
import java.util.zip.*;

/** ضغط/فك ضغط بدون اعتماديات خارجية (يُستخدم لتصدير المشروع ZIP وفك الـ APK). */
public final class ZipUtil {
    private ZipUtil() {}

    public interface Progress { void onEntry(String name, int done, int total); }

    public static File zipDirectory(File dir, File outZip, Progress p) throws IOException {
        List<File> files = new ArrayList<>();
        collect(dir, files);
        int total = files.size(), i = 0;
        File parent = outZip.getParentFile();
        if (parent != null) parent.mkdirs();
        try (ZipOutputStream zos = new ZipOutputStream(
                new BufferedOutputStream(new FileOutputStream(outZip)))) {
            zos.setLevel(Deflater.BEST_COMPRESSION);
            byte[] buf = new byte[32768];
            for (File f : files) {
                String rel = relative(dir, f);
                zos.putNextEntry(new ZipEntry(rel));
                try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
                    int n; while ((n = in.read(buf)) > 0) zos.write(buf, 0, n);
                }
                zos.closeEntry();
                if (p != null) p.onEntry(rel, ++i, total);
            }
        }
        return outZip;
    }

    public static void unzip(File zip, File dstDir) throws IOException {
        dstDir.mkdirs();
        try (ZipInputStream zis = new ZipInputStream(
                new BufferedInputStream(new FileInputStream(zip)))) {
            ZipEntry e;
            byte[] buf = new byte[32768];
            while ((e = zis.getNextEntry()) != null) {
                File out = safeChild(dstDir, e.getName());
                if (e.isDirectory()) { out.mkdirs(); continue; }
                File p = out.getParentFile();
                if (p != null) p.mkdirs();
                try (OutputStream os = new BufferedOutputStream(new FileOutputStream(out))) {
                    int n; while ((n = zis.read(buf)) > 0) os.write(buf, 0, n);
                }
            }
        }
    }

    /** استخراج مدخل واحد من أرشيف (للاستعراض السريع لملفات assets). */
    public static byte[] readEntry(File zip, String entryName) throws IOException {
        try (ZipFile zf = new ZipFile(zip)) {
            ZipEntry e = zf.getEntry(entryName);
            if (e == null) return null;
            try (InputStream in = zf.getInputStream(e)) { return FileUtil.readAll(in); }
        }
    }

    public static List<String> list(File zip) throws IOException {
        List<String> out = new ArrayList<>();
        try (ZipFile zf = new ZipFile(zip)) {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) out.add(en.nextElement().getName());
        }
        Collections.sort(out);
        return out;
    }

    /** حماية من ثغرة Zip Slip. */
    private static File safeChild(File dir, String name) throws IOException {
        File f = new File(dir, name);
        String base = dir.getCanonicalPath();
        if (!f.getCanonicalPath().startsWith(base + File.separator)
                && !f.getCanonicalPath().equals(base))
            throw new IOException("مدخل غير آمن في الأرشيف: " + name);
        return f;
    }

    private static void collect(File dir, List<File> out) {
        File[] k = dir.listFiles();
        if (k == null) return;
        for (File f : k) { if (f.isDirectory()) collect(f, out); else out.add(f); }
    }

    private static String relative(File base, File f) {
        return f.getAbsolutePath().substring(base.getAbsolutePath().length() + 1)
                .replace(File.separatorChar, '/');
    }
}
