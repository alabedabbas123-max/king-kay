package com.almlk.editorapkpro.ui.complete;

/** اقتراح إكمال واحد. */
public class Suggestion implements Comparable<Suggestion> {

    public static final int KIND_KEYWORD   = 0;
    public static final int KIND_METHOD    = 1;
    public static final int KIND_CLASS     = 2;
    public static final int KIND_FIELD     = 3;
    public static final int KIND_TAG       = 4;
    public static final int KIND_ATTR      = 5;
    public static final int KIND_VALUE     = 6;
    public static final int KIND_RESOURCE  = 7;
    public static final int KIND_SNIPPET   = 8;
    public static final int KIND_LOCAL     = 9;

    /** النص الظاهر في القائمة. */
    public String label;
    /** النص الذي يُدرج فعلياً (قد يحوي | لتحديد موضع المؤشر). */
    public String insert;
    /** وصف مختصر يظهر على اليمين. */
    public String detail;
    public int    kind;
    public int    score;

    public Suggestion(String label, String insert, String detail, int kind) {
        this.label  = label;
        this.insert = insert == null ? label : insert;
        this.detail = detail;
        this.kind   = kind;
    }

    public static Suggestion of(String label, int kind) { return new Suggestion(label, label, null, kind); }

    public String icon() {
        switch (kind) {
            case KIND_METHOD:   return "m";
            case KIND_CLASS:    return "C";
            case KIND_FIELD:    return "f";
            case KIND_TAG:      return "<>";
            case KIND_ATTR:     return "a";
            case KIND_VALUE:    return "v";
            case KIND_RESOURCE: return "@";
            case KIND_SNIPPET:  return "{}";
            case KIND_LOCAL:    return "l";
            default:            return "k";
        }
    }

    public int color() {
        switch (kind) {
            case KIND_METHOD:   return 0xFFD2A8FF;
            case KIND_CLASS:    return 0xFF7EE787;
            case KIND_FIELD:    return 0xFF79C0FF;
            case KIND_TAG:      return 0xFF7EE787;
            case KIND_ATTR:     return 0xFFD2A8FF;
            case KIND_RESOURCE: return 0xFFFFB020;
            case KIND_SNIPPET:  return 0xFF00E5A0;
            default:            return 0xFFFF7B72;
        }
    }

    @Override public int compareTo(Suggestion o) {
        if (o.score != score) return o.score - score;
        return label.compareToIgnoreCase(o.label);
    }
}
