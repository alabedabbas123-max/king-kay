package com.almlk.editorapkpro.engine;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.almlk.editorapkpro.R;

/** خدمة أمامية تُبقي عمليات الفك/البناء الطويلة حيّة عند مغادرة الشاشة. */
public class EngineService extends Service {

    private static final String CH = "apkide_engine";
    private static final int ID = 4711;
    private static final String EXTRA_CONTENT_INTENT = "content_intent";
    public static final String EXTRA_SHOW_WORK = "com.almlk.editorapkpro.SHOW_WORK";

    public static void start(Context c, String title, String text) {
        // إشعار قابل للضغط يعيد نفس شاشة العمل إلى المقدمة، لا إشعاراً ميتاً.
        Intent open;
        if(c instanceof Activity){
            Activity a=(Activity)c;
            open=new Intent(a.getIntent());
            open.setClass(a,a.getClass());
        }else{
            open=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
            if(open==null)open=new Intent();
        }
        open.putExtra(EXTRA_SHOW_WORK,true);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content=PendingIntent.getActivity(c,ID,open,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent i = new Intent(c, EngineService.class)
                .putExtra("title", title).putExtra("text", text)
                .putExtra(EXTRA_CONTENT_INTENT,content);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) c.startForegroundService(i);
        else c.startService(i);
    }

    public static void stop(Context c) { c.stopService(new Intent(c, EngineService.class)); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String title = intent == null ? getString(R.string.working) : intent.getStringExtra("title");
        String text  = intent == null ? "" : intent.getStringExtra("text");
        PendingIntent content=null;
        if(intent!=null){
            if(Build.VERSION.SDK_INT>=33)
                content=intent.getParcelableExtra(EXTRA_CONTENT_INTENT,PendingIntent.class);
            else //noinspection deprecation
                content=intent.getParcelableExtra(EXTRA_CONTENT_INTENT);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm.getNotificationChannel(CH) == null) {
                nm.createNotificationChannel(new NotificationChannel(
                        CH, "APK IDE Engine", NotificationManager.IMPORTANCE_LOW));
            }
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_build)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setProgress(0, 0, true);
        if(content!=null)builder.setContentIntent(content);
        Notification n = builder.build();
        startForeground(ID, n);
        return START_NOT_STICKY;
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
