package com.almlk.editorapkpro.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.Engine;
import com.almlk.editorapkpro.engine.EngineService;
import com.almlk.editorapkpro.engine.NativeTools;
import com.almlk.editorapkpro.engine.TaskCallback;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.util.Prefs;
import com.almlk.editorapkpro.setup.SetupManager;
import com.almlk.editorapkpro.compiler.D8Bridge;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;

/** الواجهة الرئيسية (Dashboard). */
public class MainActivity extends AppCompatActivity {

    private TextView txtProjectsCount, txtToolsStatus;
    private Ui.ActivityBusy topBusy;
    private Intent pendingIntent;
    private boolean setupContinued;

    private final ActivityResultLauncher<String[]> pickApk =
            registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
                if (uri != null) importApk(uri);
            });

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);

        txtProjectsCount = findViewById(R.id.txtProjectsCount);
        txtToolsStatus   = findViewById(R.id.txtToolsStatus);
        topBusy = new Ui.ActivityBusy(this);
        try {
            String v=getPackageManager().getPackageInfo(getPackageName(),0).versionName;
            ((TextView)findViewById(R.id.txtAppVersion)).setText(
                    getString(R.string.dashboard_subtitle)+" • v"+v);
        } catch(Exception ignored) {}

        findViewById(R.id.cardApps).setOnClickListener(v ->
                startActivity(new Intent(this, AppListActivity.class)));
        findViewById(R.id.cardImport).setOnClickListener(v ->
                pickApk.launch(new String[]{"application/vnd.android.package-archive",
                        "application/octet-stream", "application/zip", "*/*"}));
        findViewById(R.id.cardProjects).setOnClickListener(v ->
                startActivity(new Intent(this, ProjectListActivity.class)));
        findViewById(R.id.cardLog).setOnClickListener(v ->
                startActivity(new Intent(this, LogActivity.class)));
        findViewById(R.id.btnSettings).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        pendingIntent = getIntent();
        if(getIntent().getBooleanExtra(EngineService.EXTRA_SHOW_WORK,false))
            findViewById(android.R.id.content).post(()->Ui.revealActiveProgress(this));
        beginAutomaticSetup();
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if(intent.getBooleanExtra(EngineService.EXTRA_SHOW_WORK,false)){
            Ui.revealActiveProgress(this);
            return;
        }
        pendingIntent = intent;
        if (SetupManager.isReady()) { handleIncoming(intent); pendingIntent = null; }
    }

    /** أول تشغيل: يثبت ويفحص كل الأدوات قبل السماح ببدء الفك. */
    private void beginAutomaticSetup() {
        final Ui.Progress progress = Prefs.setupComplete() ? null
                : new Ui.Progress(this, "إعداد بيئة التطوير لأول تشغيل").show();
        topBusy.show("فحص وتجهيز الأدوات…");
        if (progress != null) progress.update("فحص الأدوات المدمجة…", 0);
        SetupManager.ensure(this, new SetupManager.Callback() {
            @Override public void onStep(String message, int percent) {
                runOnUiThread(() -> {
                    topBusy.update(message);
                    if (progress != null) progress.update(message, percent);
                });
            }
            @Override public void onReady(SetupManager.Report report) {
                runOnUiThread(() -> {
                    topBusy.hide();
                    if (progress != null) progress.dismiss(); txtToolsStatus.setText(toolsStatus());
                    if (report.complete()) continueAfterSetup();
                    else showSetupProblem(new IllegalStateException("أدوات مفقودة:\n" + report.text()));
                });
            }
            @Override public void onError(Throwable error) {
                runOnUiThread(() -> {
                    topBusy.hide();
                    if (progress != null) progress.dismiss();
                    showSetupProblem(error);
                });
            }
        });
    }

    private void continueAfterSetup() {
        if (setupContinued) return;
        setupContinued = true;
        Ui.toast(this, "بيئة الفك والبناء جاهزة");
        requestStorage();
        if (pendingIntent != null) { handleIncoming(pendingIntent); pendingIntent = null; }
    }

    private void showSetupProblem(Throwable error) {
        Throwable root = error;
        while (root.getCause() != null) root = root.getCause();
        String msg = root.getMessage() == null ? root.toString() : root.getMessage();
        new MaterialAlertDialogBuilder(this)
                .setTitle("تعذّر إعداد الأدوات")
                .setMessage(msg + "\n\nيمكن إعادة المحاولة أو فتح مدير الأدوات للتشخيص.")
                .setCancelable(false)
                .setNeutralButton("مدير الأدوات", (d,w) -> startActivity(new Intent(this, ToolsActivity.class)))
                .setNegativeButton("إغلاق", null)
                .setPositiveButton("إعادة المحاولة", (d,w) -> beginAutomaticSetup())
                .show();
    }

    private void handleIncoming(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null)
            importApk(i.getData());
    }

    @Override protected void onResume() {
        super.onResume();
        int n = ProjectManager.all().size();
        txtProjectsCount.setText(n == 0 ? "لا توجد مشاريع بعد" : n + " مشروع");
        txtToolsStatus.setText(toolsStatus());
    }

    private String toolsStatus() {
        SetupManager.Report r = SetupManager.lastReport();
        StringBuilder sb = new StringBuilder("حالة الأدوات المدمجة:\n");
        if (r != null) sb.append(r.text());
        else {
            sb.append("• jadx : ").append(classPresent("jadx.api.JadxDecompiler") ? "جاهز" : "مفقود").append('\n');
            sb.append("• apktool : ").append(classPresent("brut.androlib.ApkDecoder") ? "جاهز" : "مفقود").append('\n');
            sb.append("• apksig : ").append(classPresent("com.android.apksig.ApkSigner") ? "جاهز" : "مفقود").append('\n');
            sb.append("• ecj : ").append(classPresent("org.eclipse.jdt.internal.compiler.batch.Main") ? "جاهز" : "مفقود").append('\n');
            sb.append("• d8 : ").append(D8Bridge.available() ? "جاهز" : "اختياري").append('\n');
            sb.append("• aapt2 : ").append(NativeTools.isAvailable(this, NativeTools.AAPT2) ? "جاهز" : "جارٍ الإعداد").append('\n');
            sb.append("• zipalign : ").append(NativeTools.isAvailable(this, NativeTools.ZIPALIGN) ? "جاهز" : "جارٍ الإعداد").append('\n');
        }
        sb.append("\nمجلد العمل: ").append(Env.rootDir().getAbsolutePath());
        return sb.toString();
    }

    private boolean classPresent(String name) {
        try { Class.forName(name); return true; } catch (Throwable t) { return false; }
    }

    private void importApk(Uri uri) {
        topBusy.show("استيراد ملف APK…");
        Ui.Progress p = new Ui.Progress(this, "استيراد الملف…").show();
        new Thread(() -> {
            try {
                File dst = FileUtil.importUri(getContentResolver(), uri, Env.newTmp("import"));
                runOnUiThread(() -> { topBusy.hide(); p.dismiss(); askMode(dst); });
            } catch (Exception e) {
                runOnUiThread(() -> { topBusy.hide(); p.dismiss(); Ui.error(this, e); });
            }
        }).start();
    }

    /** اختيار وضع الفك للملف المستورد. */
    void askMode(File apk) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(apk.getName())
                .setItems(new String[]{
                        getString(R.string.edit_mid),
                        getString(R.string.full_decompile)}, (d, which) ->
                        startDecompile(apk, which == 0 ? Project.MODE_RESOURCES : Project.MODE_SOURCE))
                .show();
    }

    void startDecompile(File apk, int mode) {
        if(Engine.get().isBusy()){
            Ui.toast(this,"توجد عملية جارية بالفعل؛ انتظر اكتمالها");
            return;
        }
        String title=mode == Project.MODE_SOURCE
                ? "فك المشروع الهندسي الكامل" : "فك الموارد وSmali";
        topBusy.show(title+"…");
        Ui.Progress p = new Ui.Progress(this,title).show();
        EngineService.start(this,title,apk.getName());
        Engine.get().decompile(this, apk, FileUtil.nameNoExt(apk.getName()), mode,
                new TaskCallback<Project>() {
                    @Override public void onProgress(String step, int percent) {
                        topBusy.update(step); p.update(step, percent);
                    }
                    @Override public void onSuccess(Project project) {
                        topBusy.hide(); p.dismiss(); EngineService.stop(MainActivity.this);
                        startActivity(new Intent(MainActivity.this, ProjectActivity.class)
                                .putExtra("dir", project.dir));
                    }
                    @Override public void onError(Throwable e) {
                        topBusy.hide(); p.dismiss(); EngineService.stop(MainActivity.this);
                        Ui.error(MainActivity.this, e);
                    }
                });
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {}
            }
        } else {
            ActivityCompat.requestPermissions(this, new String[]{
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 11);
        }
        if (Build.VERSION.SDK_INT >= 33)
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 12);
    }
}
