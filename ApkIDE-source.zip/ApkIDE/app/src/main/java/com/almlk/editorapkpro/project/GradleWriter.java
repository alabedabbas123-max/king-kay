package com.almlk.editorapkpro.project;

import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.TreeSet;

/** توليد بنية مشروع Gradle قياسية قابلة للفتح مباشرة في Android Studio. */
public final class GradleWriter {

    private GradleWriter() {}

    public static void write(Project p, int minSdk, int targetSdk, int compileSdk,
                             Set<String> detectedDeps, boolean hasKotlin) throws IOException {

        File root = p.root();

        FileUtil.write(new File(root, "settings.gradle"),
                "pluginManagement {\n" +
                "    repositories { google(); mavenCentral(); gradlePluginPortal() }\n" +
                "}\n" +
                "dependencyResolutionManagement {\n" +
                "    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)\n" +
                "    repositories { google(); mavenCentral(); maven { url 'https://jitpack.io' } }\n" +
                "}\n" +
                "rootProject.name = \"" + esc(p.appName == null ? p.name : p.appName) + "\"\n" +
                "include ':app'\n");

        FileUtil.write(new File(root, "build.gradle"),
                "// أُنشئ بواسطة Advanced APK IDE\n" +
                "plugins {\n" +
                "    id 'com.android.application' version '8.5.2' apply false\n" +
                (hasKotlin ? "    id 'org.jetbrains.kotlin.android' version '1.9.24' apply false\n" : "") +
                "}\n" +
                "tasks.register('clean', Delete) { delete rootProject.buildDir }\n");

        FileUtil.write(new File(root, "gradle.properties"),
                "org.gradle.jvmargs=-Xmx3072m\n" +
                "android.useAndroidX=true\n" +
                "android.nonTransitiveRClass=false\n" +
                "android.enableJetifier=false\n" +
                "android.nonFinalResIds=false\n");   // مهم: يبقي R.id ثوابت نهائية كما في الأصل

        StringBuilder deps = new StringBuilder();
        for (String d : new TreeSet<>(detectedDeps)) deps.append("    implementation '").append(d).append("'\n");

        FileUtil.write(new File(root, "app/build.gradle"),
                "plugins {\n" +
                "    id 'com.android.application'\n" +
                (hasKotlin ? "    id 'org.jetbrains.kotlin.android'\n" : "") +
                "}\n\n" +
                "android {\n" +
                "    namespace '" + p.packageName + "'\n" +
                "    compileSdk " + compileSdk + "\n\n" +
                "    defaultConfig {\n" +
                "        applicationId \"" + p.packageName + "\"\n" +
                "        minSdk " + minSdk + "\n" +
                "        targetSdk " + targetSdk + "\n" +
                "        versionCode " + Math.max(1, p.versionCode) + "\n" +
                "        versionName \"" + esc(p.versionName == null ? "1.0" : p.versionName) + "\"\n" +
                "    }\n\n" +
                "    buildTypes {\n" +
                "        release {\n" +
                "            minifyEnabled false\n" +
                "            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'\n" +
                "        }\n" +
                "    }\n\n" +
                "    // الحفاظ على معرّفات الموارد الأصلية عند إعادة البناء\n" +
                "    androidResources {\n" +
                "        additionalParameters '--stable-ids', file('stable-ids.txt').absolutePath\n" +
                "        noCompress 'arsc'\n" +
                "    }\n\n" +
                "    compileOptions {\n" +
                "        sourceCompatibility JavaVersion.VERSION_17\n" +
                "        targetCompatibility JavaVersion.VERSION_17\n" +
                "    }\n" +
                (hasKotlin ? "    kotlinOptions { jvmTarget = '17' }\n" : "") +
                "    packagingOptions { resources { excludes += ['META-INF/*'] } }\n" +
                "    lint {\n        abortOnError false\n        checkReleaseBuilds false\n    }\n" +
                "}\n\n" +
                "dependencies {\n" + deps + "}\n");

        FileUtil.write(new File(root, "app/proguard-rules.pro"),
                "# قواعد مستخرجة من التطبيق الأصلي\n" +
                "-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod\n" +
                "-dontwarn **\n");

        File gradleWrapperProps = new File(root, "gradle/wrapper/gradle-wrapper.properties");
        FileUtil.write(gradleWrapperProps,
                "distributionBase=GRADLE_USER_HOME\n" +
                "distributionPath=wrapper/dists\n" +
                "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip\n" +
                "zipStoreBase=GRADLE_USER_HOME\n" +
                "zipStorePath=wrapper/dists\n");

        FileUtil.write(new File(root, ".gitignore"),
                "*.iml\n.gradle\n/local.properties\n/.idea\n/build\n/app/build\n/captures\n");
    }

    private static String esc(String s) { return s == null ? "" : s.replace("\"", "\\\""); }
}
