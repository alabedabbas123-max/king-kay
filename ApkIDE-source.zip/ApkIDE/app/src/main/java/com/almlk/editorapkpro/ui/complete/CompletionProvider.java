package com.almlk.editorapkpro.ui.complete;

import java.util.List;

/** مزوّد اقتراحات حسب اللغة. */
public interface CompletionProvider {
    /**
     * @param text     كامل نص المحرر
     * @param cursor   موضع المؤشر
     * @param prefix   البادئة المكتوبة حالياً
     */
    List<Suggestion> complete(CharSequence text, int cursor, String prefix);
}
