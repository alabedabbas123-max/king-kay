package com.almlk.editorapkpro.engine.apktool;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.jadx.DexShardSplitter;
import com.almlk.editorapkpro.setup.RuntimeBootstrap;
import com.almlk.editorapkpro.util.FileUtil;

import brut.androlib.ApkBuilder;
import brut.androlib.ApkDecoder;
import brut.androlib.Config;
import brut.androlib.src.SmaliDecoder;
import brut.directory.ExtFile;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * الطبقة الحقيقية فوق apktool-lib بنسخة Android منخفضة الذاكرة.
 * الموارد تُفك أولاً، ثم كل classes*.dex إلى Smali بخيط واحد وبالتتابع.
 */
public class ApktoolEngine {

    private static final long MIB = 1024L * 1024L;
    private final Logger log;

    public ApktoolEngine(Logger log) { this.log = log; }

    public interface Progress {
        void onDex(String dexName, int done, int total);
    }

    private Config base(File frameworkDir) {
        RuntimeBootstrap.verify();
        try {
            boolean imageOk=Class.forName("brut.androlib.res.decoder.Res9patchStreamDecoder")
                    .getField("ANDROID_COMPATIBLE").getBoolean(null);
            boolean smaliOk=Class.forName("brut.androlib.src.SmaliDecoder")
                    .getField("ANDROID_LOW_MEMORY").getBoolean(null);
            if(!imageOk||!smaliOk)throw new IllegalStateException("Apktool Android patches غير مفعلة");
        } catch(ReflectiveOperationException desktopApktool) {
            throw new IllegalStateException(
                    "نسخة Apktool المكتبية غير صالحة على Android؛ ثبّت آخر تحديث للتطبيق.",
                    desktopApktool);
        }
        File framework=new File(frameworkDir,"1.apk");
        if(!com.almlk.editorapkpro.setup.ToolchainVerifier.validApktoolFramework(framework))
            throw new IllegalStateException("Apktool framework (1.apk) مفقود أو تالف؛ أعد تشغيل الإعداد التلقائي أو ثبّته من مدير الأدوات.");
        Config c = Config.getDefaultConfig();
        c.frameworkDirectory = frameworkDir.getAbsolutePath();
        c.forceDelete   = true;
        c.verbose       = false;
        c.useAapt2      = true;
        return c;
    }

    /** فك كامل مستقر: موارد/أصول أولاً، ثم DEX واحد في كل مرة إلى smali. */
    public void decodeAll(File apk, File outDir, File frameworkDir) throws Exception {
        decodeAll(apk, outDir, frameworkDir, null);
    }

    public void decodeAll(File apk, File outDir, File frameworkDir, Progress progress)
            throws Exception {
        ensureSpace(apk, outDir);
        log.i("apktool: فك كامل منخفض الذاكرة لـ " + apk.getName());
        decodeResourcesOnly(apk, outDir, frameworkDir);
        decodeSmaliInPlace(outDir, progress);
        log.i("apktool: اكتمل فك الموارد وملفات smali إلى " + outDir.getName());
    }

    /**
     * يحوّل ملفات DEX الخام التي وضعها decodeResourcesOnly في جذر المشروع إلى Smali.
     * لا تُحمّل ملفات DEX متعددة معاً، وتُحذف النسخة الخام فور نجاح كل ملف.
     */
    public void decodeSmaliInPlace(File outDir, Progress progress) throws Exception {
        File[] dexFiles=outDir.listFiles((dir,name)->name.matches("classes(\\d*)?\\.dex"));
        if(dexFiles==null||dexFiles.length==0){
            log.w("apktool: لا توجد ملفات DEX لفكها");
            return;
        }
        Arrays.sort(dexFiles, Comparator.comparingInt(ApktoolEngine::dexIndex));
        log.i("apktool: بدء Baksmali المتسلسل منخفض الذاكرة ("+dexFiles.length+" DEX، خيط واحد)");
        for(int i=0;i<dexFiles.length;i++){
            File dex=dexFiles[i];
            String base=dex.getName().substring(0,dex.getName().length()-4);
            File smali=new File(outDir,base.equals("classes")?"smali":"smali_"+base);
            FileUtil.delete(smali);
            if(progress!=null)progress.onDex(dex.getName(),i,dexFiles.length);
            log.i("baksmali: "+dex.getName()+" ("+(i+1)+"/"+dexFiles.length+")");
            long heap=Runtime.getRuntime().maxMemory();
            boolean shard=dex.length()>=4L*MIB&&heap<=768L*MIB;
            File shardDir=null;
            List<File> units=Collections.singletonList(dex);
            if(shard){
                shardDir=new File(outDir,".smali-shards-"+dex.getName());
                int limit=heap<=576L*MIB?420:700;
                units=DexShardSplitter.split(dex,shardDir,limit,log);
                log.i("baksmali: فك "+dex.getName()+" عبر "+units.size()+
                        " شظايا متسلسلة منخفضة الذاكرة");
                System.gc();System.runFinalization();
            }
            try{
                for(int u=0;u<units.size();u++){
                    File unit=units.get(u);
                    if(units.size()>1)log.i("baksmali: شظية "+(u+1)+"/"+units.size());
                    SmaliDecoder.decode(unit,smali,unit.getName(),false,0);
                    System.gc();System.runFinalization();
                }
            }finally{
                if(shardDir!=null)FileUtil.delete(shardDir);
            }
            if(!smali.isDirectory())
                throw new IllegalStateException("لم ينشئ Baksmali مجلد "+dex.getName());
            if(!dex.delete())throw new IllegalStateException("تعذّر حذف DEX الخام بعد فكه: "+dex.getName());
            if(progress!=null)progress.onDex(dex.getName(),i+1,dexFiles.length);
            // حرّر mmap وجداول dexlib قبل فتح DEX التالي على الهواتف محدودة الذاكرة.
            System.gc();
            System.runFinalization();
        }
        log.i("apktool: اكتمل Baksmali لكل ملفات DEX");
    }

    /** فك الموارد فقط؛ يحتفظ Apktool بملفات classes*.dex الخام في الجذر للمرحلة التالية. */
    public void decodeResourcesOnly(File apk, File outDir, File frameworkDir) throws Exception {
        ensureSpace(apk, outDir);
        log.i("apktool: فك الموارد فقط لـ " + apk.getName());
        Config c = base(frameworkDir);
        c.decodeSources    = Config.DECODE_SOURCES_NONE;
        c.decodeResources  = Config.DECODE_RESOURCES_FULL;
        c.decodeAssets     = Config.DECODE_ASSETS_FULL;
        c.keepBrokenResources = true;
        new ApkDecoder(c, apk).decode(outDir);
        // اترك المرحلة التالية تبدأ بعد تحرير جداول resources.arsc الكبيرة.
        System.gc();System.runFinalization();
        log.i("apktool: اكتملت الموارد وتحرير ذاكرة جداولها");
    }

    /** إعادة البناء السريعة: مشروع apktool -> APK غير موقّع. */
    public File build(File projectDir, File outApk, File frameworkDir) throws Exception {
        log.i("apktool: إعادة البناء من " + projectDir.getName());
        Config c = base(frameworkDir);
        c.forceBuildAll  = false;
        c.copyOriginalFiles = false;
        c.aaptPath       = System.getProperty("apkide.aapt2", "");
        new ApkBuilder(c, new ExtFile(projectDir)).build(outApk);
        log.i("apktool: تم إنتاج " + outApk.getName() + " (" + outApk.length() / 1024 + " KB)");
        return outApk;
    }

    private void ensureSpace(File apk, File outDir) {
        File disk=outDir.getAbsoluteFile().getParentFile();
        if(disk==null)disk=outDir.getAbsoluteFile();
        long usable=disk.getUsableSpace();
        long required=Math.max(320L*MIB,apk.length()*8L);
        if(usable>0&&usable<required){
            throw new IllegalStateException("المساحة غير كافية للفك. المتاح "
                    +FileUtil.humanSize(usable)+"، والمطلوب تقريباً "
                    +FileUtil.humanSize(required)+" لملفات الموارد وSmali.");
        }
    }

    private static int dexIndex(File f){
        String n=f.getName();
        if(n.equals("classes.dex"))return 1;
        try{return Integer.parseInt(n.substring(7,n.length()-4));}
        catch(Exception ignored){return Integer.MAX_VALUE;}
    }

}
