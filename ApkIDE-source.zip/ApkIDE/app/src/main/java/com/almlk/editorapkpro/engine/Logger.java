package com.almlk.editorapkpro.engine;

import android.util.Log;
import com.almlk.editorapkpro.util.Env;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/** سجل موحّد يُعرض في شاشة "سجل البناء" ويُكتب على القرص. */
public class Logger {
    public interface Sink { void onLine(String line); }

    private static final SimpleDateFormat TS = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private final List<String> lines = Collections.synchronizedList(new ArrayList<>());
    private final List<Sink> sinks   = new CopyOnWriteList();
    private final File file;

    public Logger(String tag) {
        file = new File(Env.logsDir(), tag + "_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".log");
    }

    public void addSink(Sink s)    { sinks.add(s); for (String l : snapshot()) s.onLine(l); }
    public void removeSink(Sink s) { sinks.remove(s); }

    public void i(String msg) { line("I", msg); }
    public void w(String msg) { line("W", msg); }
    public void e(String msg) { line("E", msg); }
    public void e(String msg, Throwable t) {
        line("E", msg);
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        line("E", sw.toString());
    }

    private void line(String lvl, String msg) {
        String l = "[" + TS.format(new Date()) + "] " + lvl + "/ " + msg;
        lines.add(l);
        try{Log.println("E".equals(lvl) ? Log.ERROR : Log.INFO, "ApkIDE", msg);}
        catch(Throwable ignored){} // يسمح باختبارات JVM؛ Android يكتب إلى Logcat طبيعياً.
        for (Sink s : sinks) s.onLine(l);
        append(l);
    }

    private synchronized void append(String l) {
        try (Writer w = new FileWriter(file, true)) { w.write(l); w.write('\n'); }
        catch (IOException ignored) {}
    }

    public List<String> snapshot() { synchronized (lines) { return new ArrayList<>(lines); } }
    public String text()           { return String.join("\n", snapshot()); }
    public File logFile()          { return file; }

    /** قائمة بسيطة آمنة للتعديل أثناء التكرار. */
    private static class CopyOnWriteList extends AbstractList<Sink> {
        private volatile List<Sink> d = new ArrayList<>();
        @Override public synchronized boolean add(Sink s) {
            List<Sink> n = new ArrayList<>(d); n.add(s); d = n; return true; }
        @Override public synchronized boolean remove(Object s) {
            List<Sink> n = new ArrayList<>(d); boolean r = n.remove(s); d = n; return r; }
        @Override public Sink get(int i) { return d.get(i); }
        @Override public int size()      { return d.size(); }
        @Override public Iterator<Sink> iterator() { return d.iterator(); }
    }
}
