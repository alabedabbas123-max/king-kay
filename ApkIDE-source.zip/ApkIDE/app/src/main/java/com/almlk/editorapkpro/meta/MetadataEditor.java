package com.almlk.editorapkpro.meta;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.util.XmlUtil;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.File;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** تعديل اسم التطبيق ورقم/اسم الإصدار وتطبيقها على المانيفست و apktool.yml و build.gradle. */
public class MetadataEditor {

    private final Logger log;
    public MetadataEditor(Logger log) { this.log = log; }

    public void setAppName(Project p, String newName) throws Exception {
        // 1) إن كان label مرجعاً لمورد (@string/app_name) نعدّل المورد نفسه
        String labelRef = null;
        File mf = p.manifest();
        if (mf.exists()) {
            Document d = XmlUtil.parse(mf);
            NodeList apps = d.getElementsByTagName("application");
            if (apps.getLength() > 0) {
                Element app = (Element) apps.item(0);
                String label = XmlUtil.attr(app, "label");
                if (label != null && label.startsWith("@string/")) {
                    labelRef = label.substring("@string/".length());
                } else {
                    XmlUtil.setAttr(app, "label", newName);
                    XmlUtil.save(d, mf);
                }
            }
        }
        if (labelRef != null) setStringResource(p, labelRef, newName);
        p.appName = newName;
        ProjectManager.save(p);
        log.i("meta: اسم التطبيق -> " + newName);
    }

    /** يعدّل (أو يضيف) مورد نص في كل ملفات values*/
    public void setStringResource(Project p, String name, String value) throws Exception {
        File strings = new File(p.valuesDir(), "strings.xml");
        if (!strings.exists()) {
            FileUtil.write(strings,
                    "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n</resources>\n");
        }
        Document d = XmlUtil.parse(strings);
        NodeList list = d.getElementsByTagName("string");
        for (int i = 0; i < list.getLength(); i++) {
            Element e = (Element) list.item(i);
            if (name.equals(e.getAttribute("name"))) {
                e.setTextContent(value);
                XmlUtil.save(d, strings);
                return;
            }
        }
        Element e = d.createElement("string");
        e.setAttribute("name", name);
        e.setTextContent(value);
        d.getDocumentElement().appendChild(e);
        XmlUtil.save(d, strings);
    }

    public void setVersion(Project p, int versionCode, String versionName) throws Exception {
        File mf = p.manifest();
        if (mf.exists()) {
            Document d = XmlUtil.parse(mf);
            Element root = d.getDocumentElement();
            XmlUtil.setAttr(root, "versionCode", String.valueOf(versionCode));
            XmlUtil.setAttr(root, "versionName", versionName);
            XmlUtil.save(d, mf);
        }
        // apktool.yml
        File yml = new File(p.metaDir(), "apktool.yml");
        if (!yml.exists()) yml = new File(p.root(), "apktool.yml");
        if (yml.exists()) {
            String y = FileUtil.read(yml);
            y = replaceYaml(y, "versionCode", "'" + versionCode + "'");
            y = replaceYaml(y, "versionName", versionName);
            FileUtil.write(yml, y);
        }
        File rebuildYml = new File(p.metaDir(), "rebuild/apktool.yml");
        if (rebuildYml.exists()) {
            String y = FileUtil.read(rebuildYml);
            y = replaceYaml(y, "versionCode", "'" + versionCode + "'");
            y = replaceYaml(y, "versionName", versionName);
            FileUtil.write(rebuildYml, y);
        }
        // build.gradle
        File g = new File(p.root(), "app/build.gradle");
        if (g.exists()) {
            String s = FileUtil.read(g);
            s = s.replaceAll("versionCode\\s+\\d+", "versionCode " + versionCode);
            s = s.replaceAll("versionName\\s+\"[^\"]*\"", "versionName \"" + versionName + "\"");
            FileUtil.write(g, s);
        }
        p.versionCode = versionCode;
        p.versionName = versionName;
        ProjectManager.save(p);
        log.i("meta: الإصدار -> " + versionName + " (" + versionCode + ")");
    }

    private String replaceYaml(String yaml, String key, String value) {
        Pattern pt = Pattern.compile("(?m)^(\\s*" + key + ":\\s*).*$");
        Matcher m = pt.matcher(yaml);
        return m.find() ? m.replaceFirst("$1" + Matcher.quoteReplacement(value)) : yaml;
    }
}
