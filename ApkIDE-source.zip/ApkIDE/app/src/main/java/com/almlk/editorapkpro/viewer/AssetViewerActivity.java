package com.almlk.editorapkpro.viewer;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.ui.Ui;
import com.almlk.editorapkpro.ui.adapter.FileTreeAdapter;
import com.almlk.editorapkpro.ui.view.CodeEditorView;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.util.ZipUtil;
import com.google.android.material.appbar.MaterialToolbar;

import java.io.File;
import java.util.List;

/**
 * مستعرض الممتلكات: يفتح أي صيغة قد توجد داخل assets / res / raw.
 * صور، نصوص وشيفرات، صوت، فيديو، خطوط، أرشيفات، قواعد بيانات، وملفات ثنائية (HEX).
 */
public class AssetViewerActivity extends AppCompatActivity {

    private FrameLayout host;
    private MaterialToolbar toolbar;
    private MediaPlayer player;

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_asset_viewer);
        host = findViewById(R.id.host);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_close);
        toolbar.setNavigationOnClickListener(v -> finish());

        String path = getIntent().getStringExtra("file");
        if (path == null) { finish(); return; }
        open(new File(path));
    }

    private void open(File f) {
        toolbar.setTitle(f.getName());
        toolbar.setSubtitle(f.isDirectory() ? "مجلد" : FileUtil.humanSize(f.length()));
        host.removeAllViews();
        String ext = FileUtil.ext(f.getName());

        try {
            if (f.isDirectory())                          showDirectory(f);
            else if (isImage(ext))                        showImage(f);
            else if (isAudio(ext))                        showAudio(f);
            else if (isVideo(ext))                        showVideo(f);
            else if (isArchive(ext))                      showArchive(f);
            else if (isFont(ext))                         showFontInfo(f);
            else if (FileUtil.isProbablyText(f))          showText(f);
            else                                          showHex(f);
        } catch (Exception e) { Ui.error(this, e); }
    }

    /* ---------------------------------------------------------------- */

    private void showDirectory(File dir) {
        RecyclerView rv = new RecyclerView(this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        FileTreeAdapter a = new FileTreeAdapter(new FileTreeAdapter.Listener() {
            @Override public void onFile(File f) { open(f); }
            @Override public void onLongFile(File f) { Ui.toast(AssetViewerActivity.this, f.getAbsolutePath()); }
        });
        a.setRoot(dir);
        rv.setAdapter(a);
        host.addView(rv);
    }

    private void showImage(File f) throws Exception {
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (FileUtil.ext(f.getName()).equals("svg") || FileUtil.ext(f.getName()).equals("xml")) {
            showText(f);
            return;
        }
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        int w = o.outWidth, h = o.outHeight;
        o.inJustDecodeBounds = false;
        o.inSampleSize = Math.max(1, Math.max(w, h) / 2048);
        Bitmap bm = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        iv.setImageBitmap(bm);
        toolbar.setSubtitle(w + "×" + h + "  •  " + FileUtil.humanSize(f.length()));
        ScrollView sv = new ScrollView(this);
        sv.addView(iv);
        host.addView(sv);
    }

    private void showAudio(File f) {
        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);
        ll.setGravity(Gravity.CENTER);
        ll.setPadding(32, 32, 32, 32);
        TextView t = new TextView(this);
        t.setText("ملف صوتي: " + f.getName() + "\n" + FileUtil.humanSize(f.length()));
        t.setGravity(Gravity.CENTER);
        TextView btn = new TextView(this);
        btn.setText("▶  تشغيل / إيقاف");
        btn.setTextSize(18);
        btn.setPadding(24, 24, 24, 24);
        btn.setGravity(Gravity.CENTER);
        btn.setOnClickListener(v -> {
            try {
                if (player != null && player.isPlaying()) { player.pause(); return; }
                if (player == null) {
                    player = new MediaPlayer();
                    player.setDataSource(f.getAbsolutePath());
                    player.prepare();
                }
                player.start();
            } catch (Exception e) { Ui.error(this, e); }
        });
        ll.addView(t); ll.addView(btn);
        host.addView(ll);
    }

    private void showVideo(File f) {
        VideoView vv = new VideoView(this);
        Uri u = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
        vv.setVideoURI(u);
        MediaController mc = new MediaController(this);
        mc.setAnchorView(vv);
        vv.setMediaController(mc);
        host.addView(vv, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        vv.start();
    }

    private void showArchive(File f) throws Exception {
        List<String> entries = ZipUtil.list(f);
        StringBuilder sb = new StringBuilder("عدد المدخلات: " + entries.size() + "\n\n");
        for (String e : entries) sb.append(e).append('\n');
        showPlain(sb.toString());
    }

    private void showFontInfo(File f) {
        showPlain("ملف خط: " + f.getName()
                + "\nالحجم: " + FileUtil.humanSize(f.length())
                + "\nالنوع: " + FileUtil.ext(f.getName()).toUpperCase()
                + "\n\n(المعاينة النصية للخط غير مدعومة داخل المستعرض)");
    }

    private void showText(File f) throws Exception {
        CodeEditorView ed = new CodeEditorView(this);
        String txt = FileUtil.read(f);
        if (txt.length() > 500_000) txt = txt.substring(0, 500_000) + "\n\n… (اقتُطع العرض)";
        ed.setSource(txt, f.getName());
        ed.setFocusable(false);
        ed.setCursorVisible(false);
        host.addView(ed, new FrameLayout.LayoutParams(-1, -1));
    }

    private void showHex(File f) throws Exception {
        int limit = 64 * 1024;
        byte[] data = FileUtil.readBytes(f);
        int n = Math.min(limit, data.length);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i += 16) {
            sb.append(String.format("%08X  ", i));
            StringBuilder ascii = new StringBuilder();
            for (int j = 0; j < 16; j++) {
                if (i + j < n) {
                    int b = data[i + j] & 0xFF;
                    sb.append(String.format("%02X ", b));
                    ascii.append(b >= 32 && b < 127 ? (char) b : '.');
                } else sb.append("   ");
            }
            sb.append(" |").append(ascii).append("|\n");
        }
        if (data.length > limit) sb.append("\n… عُرضت أول ").append(limit / 1024).append(" KB فقط");
        showPlain(sb.toString());
    }

    private void showPlain(String text) {
        TextView tv = new TextView(this);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE);
        tv.setTextSize(11);
        tv.setTextColor(0xFFE6EDF3);
        tv.setPadding(16, 16, 16, 64);
        tv.setText(text);
        tv.setTextIsSelectable(true);
        tv.setMovementMethod(new ScrollingMovementMethod());
        ScrollView sv = new ScrollView(this);
        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(this);
        hs.addView(tv);
        sv.addView(hs);
        host.addView(sv, new FrameLayout.LayoutParams(-1, -1));
    }

    /* ---------------------------------------------------------------- */

    private boolean isImage(String e)   { return in(e, "png","jpg","jpeg","webp","gif","bmp","ico","svg"); }
    private boolean isAudio(String e)   { return in(e, "mp3","wav","ogg","m4a","aac","flac","mid","opus"); }
    private boolean isVideo(String e)   { return in(e, "mp4","3gp","mkv","webm","avi","mov"); }
    private boolean isArchive(String e) { return in(e, "zip","apk","jar","aar","obb","aab"); }
    private boolean isFont(String e)    { return in(e, "ttf","otf","woff","woff2"); }

    private boolean in(String v, String... set) {
        for (String s : set) if (s.equals(v)) return true;
        return false;
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (player != null) { try { player.release(); } catch (Exception ignored) {} }
    }
}
