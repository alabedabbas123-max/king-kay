package com.almlk.editorapkpro.ui.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.Layout;
import android.text.Spannable;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListPopupWindow;
import android.widget.OverScroller;
import android.widget.TextView;

import androidx.appcompat.widget.AppCompatEditText;

import com.almlk.editorapkpro.ui.complete.CompletionProvider;
import com.almlk.editorapkpro.ui.complete.CompletionUtils;
import com.almlk.editorapkpro.ui.complete.JavaCompletion;
import com.almlk.editorapkpro.ui.complete.ProjectIndex;
import com.almlk.editorapkpro.ui.complete.Suggestion;
import com.almlk.editorapkpro.ui.complete.XmlCompletion;
import com.almlk.editorapkpro.ui.editor.EditorTheme;
import com.almlk.editorapkpro.util.Prefs;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * محرر كود مستقل يدعم:
 *  • أرقام أسطر وتلوين نحوي (Java / Kotlin / XML / Smali)
 *  • الإغلاق التلقائي للأقواس والاقتباسات مع «التخطّي» عند كتابة القوس المغلق
 *  • الإغلاق التلقائي لوسوم XML عند كتابة ">" وعند كتابة "</"
 *  • الإزاحة التلقائية للأسطر داخل الكتل
 *  • قائمة إكمال ذكية تظهر أثناء الكتابة (وسوم، خصائص، موارد، دوال، كلمات مفتاحية، مقاطع)
 */
public class CodeEditorView extends AppCompatEditText {

    public enum Lang { JAVA, KOTLIN, XML, SMALI, PLAIN }

    /* ---------------- ألوان قابلة للتغيير من إعدادات المحرر ---------------- */
    private EditorTheme theme;
    private int cKeyword,cString,cComment,cNumber,cAnnotation,cTag,cType,cMethod,cResource;
    private boolean showLineNumbers=true,highlightCurrentLine=true;

    /* ---------------- أنماط التلوين ---------------- */
    private static final Pattern P_JAVA_KW = Pattern.compile(
            "\\b(abstract|assert|boolean|break|byte|case|catch|char|class|const|continue|default|" +
            "do|double|else|enum|extends|final|finally|float|for|goto|if|implements|import|" +
            "instanceof|int|interface|long|native|new|package|private|protected|public|return|" +
            "short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|" +
            "void|volatile|while|true|false|null|var|record|sealed|yield)\\b");
    private static final Pattern P_KT_KW = Pattern.compile(
            "\\b(fun|val|var|object|companion|data|sealed|when|is|in|as|by|lateinit|init|" +
            "override|open|internal|suspend|inline|reified|typealias|constructor|operator|" +
            "class|interface|package|import|return|if|else|for|while|try|catch|finally|" +
            "true|false|null|this|super|it)\\b");
    private static final Pattern P_SMALI_KW = Pattern.compile(
            "(\\.\\w+)|\\b(invoke-\\w+|const(-\\w+)?|move(-\\w+)?|return(-\\w+)?|iget(-\\w+)?|" +
            "iput(-\\w+)?|sget(-\\w+)?|sput(-\\w+)?|new-instance|goto|if-\\w+|check-cast)\\b");
    private static final Pattern P_STRING  = Pattern.compile("\"(\\\\.|[^\"\\\\])*\"|'(\\\\.|[^'\\\\])*'");
    private static final Pattern P_CODE_COMMENT = Pattern.compile("//[^\\n]*|/\\*(?s:.)*?\\*/");
    private static final Pattern P_XML_COMMENT  = Pattern.compile("<!--(?s:.)*?-->");
    private static final Pattern P_SMALI_COMMENT= Pattern.compile("#[^\\n]*");
    private static final Pattern P_NUMBER  = Pattern.compile("\\b(0x[0-9a-fA-F]+|\\d+(\\.\\d+)?[fFlLdD]?)\\b");
    private static final Pattern P_ANNOT   = Pattern.compile("@\\w+");
    private static final Pattern P_TYPE    = Pattern.compile("\\b[A-Z][A-Za-z0-9_]*\\b");
    private static final Pattern P_METHOD  = Pattern.compile("\\b[A-Za-z_][A-Za-z0-9_]*(?=\\s*\\()");
    private static final Pattern P_QUALIFIED_NAME = Pattern.compile(
            "\\b(?:package|import)\\s+([A-Za-z_$][A-Za-z0-9_$.]*(?:\\*)?)");
    private static final Pattern P_XML_TAG = Pattern.compile("</?[\\w:.-]+|/?>");
    private static final Pattern P_XML_ATT = Pattern.compile("[\\w:.-]+(?=\\s*=)");
    private static final Pattern P_XML_RESOURCE = Pattern.compile("@[+*]?[A-Za-z0-9_.]+/[A-Za-z0-9_.-]+");

    // يلوّن المحرر النافذة المرئية فقط؛ لا يعيد تحليل ملف كامل عند كل حرف.
    private static final int HIGHLIGHT_MARGIN_LINES = 16;

    /* ---------------- الحالة ---------------- */
    private final Paint gutterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gutterBg    = new Paint();
    private final Paint currentLinePaint = new Paint();
    private final Rect  lineRect    = new Rect();

    private Lang lang = Lang.PLAIN;
    private String fileName = "";
    private boolean internalEdit = false;
    private boolean autoClose = true;
    private boolean autoComplete = true;

    private final Runnable highlightTask = this::highlight;
    private final Runnable completeTask  = this::showCompletion;

    private CompletionProvider provider;
    private ProjectIndex index;
    private ListPopupWindow popup;
    private CompletionAdapter popupAdapter;
    private final List<Suggestion> current = new ArrayList<>();
    private final ScaleGestureDetector scaleDetector;
    private final OverScroller horizontalScroller;
    private final int touchSlop,minFlingVelocity,maxFlingVelocity;
    private VelocityTracker velocityTracker;
    private boolean scaling,userTouching,horizontalDragging,pinchGesture;
    private float pinchFontSize,touchDownX,touchDownY,lastTouchX;
    private int horizontalRange=-1;

    /* ================================================================= */

    public CodeEditorView(Context c) { this(c, null); }

    public CodeEditorView(Context c, AttributeSet a) {
        super(c, a);
        setTypeface(Typeface.MONOSPACE);
        setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
        setHorizontallyScrolling(true);
        setHorizontalScrollBarEnabled(true);
        setVerticalScrollBarEnabled(true);
        setScrollBarStyle(SCROLLBARS_INSIDE_OVERLAY);
        setOverScrollMode(OVER_SCROLL_ALWAYS);
        setNestedScrollingEnabled(true);
        setTextDirection(TEXT_DIRECTION_LTR);
        // لا نترك فراغاً وهمياً بحجم لوحة المفاتيح؛ adjustResize وشريط IME الخارجي
        // يتوليان ذلك، فيبقى الكلاس مالئاً كامل مساحة المحرر.
        setPadding(dp(48), dp(8), dp(14), dp(18));
        setLineSpacing(dp(1),1.05f);
        setSingleLine(false);
        setMaxLines(Integer.MAX_VALUE);
        setTextIsSelectable(true);
        setLongClickable(true);
        setSelectAllOnFocus(false);
        setCursorVisible(true);
        setImeOptions(android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
                | android.view.inputmethod.EditorInfo.IME_ACTION_NONE);
        setInputType(android.text.InputType.TYPE_CLASS_TEXT
                | android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                | android.text.InputType.TYPE_TEXT_FLAG_IME_MULTI_LINE);
        setScrollContainer(true);

        ViewConfiguration vc=ViewConfiguration.get(c);
        touchSlop=vc.getScaledTouchSlop();
        minFlingVelocity=vc.getScaledMinimumFlingVelocity();
        maxFlingVelocity=vc.getScaledMaximumFlingVelocity();
        horizontalScroller=new OverScroller(c);

        gutterPaint.setTextSize(dp(10));
        gutterPaint.setTypeface(Typeface.MONOSPACE);
        scaleDetector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override public boolean onScaleBegin(ScaleGestureDetector detector){
                scaling=true;dismissPopup();
                pinchFontSize=getTextSize()/getResources().getDisplayMetrics().scaledDensity;
                return true;
            }
            @Override public boolean onScale(ScaleGestureDetector detector){
                pinchFontSize=Math.max(10f,Math.min(32f,
                        pinchFontSize*detector.getScaleFactor()));
                setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,pinchFontSize);
                gutterPaint.setTextSize(android.util.TypedValue.applyDimension(
                        android.util.TypedValue.COMPLEX_UNIT_SP,
                        Math.max(8f,pinchFontSize*.72f),getResources().getDisplayMetrics()));
                horizontalRange=-1;
                requestLayout();invalidate();
                return true;
            }
            @Override public void onScaleEnd(ScaleGestureDetector detector){
                Prefs.editorFontSize(pinchFontSize);scaling=false;
                removeCallbacks(highlightTask);postDelayed(highlightTask,180);
            }
        });
        scaleDetector.setQuickScaleEnabled(false);

        addTextChangedListener(new Watcher());
        applyPreferences();
    }

    /* ---------------- إعداد ---------------- */

    public void setProjectIndex(ProjectIndex idx) {
        this.index = idx;
        rebuildProvider();
    }

    public void setAutoClose(boolean v)    { autoClose = v; }
    public void setAutoComplete(boolean v) { autoComplete = v; if (!v) dismissPopup(); }

    /** يطبّق الثيم والحجم والالتفاف وأرقام الأسطر فور العودة من شاشة الإعدادات. */
    public void applyPreferences(){
        theme=EditorTheme.current();
        cKeyword=theme.keyword;cString=theme.string;cComment=theme.comment;
        cNumber=theme.number;cAnnotation=theme.annotation;cTag=theme.xmlTag;
        cType=theme.type;cMethod=theme.method;cResource=theme.resource;
        showLineNumbers=Prefs.editorLineNumbers();
        highlightCurrentLine=Prefs.editorCurrentLine();
        boolean wrap=Prefs.editorWordWrap();
        setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,Prefs.editorFontSize());
        gutterPaint.setTextSize(android.util.TypedValue.applyDimension(
                android.util.TypedValue.COMPLEX_UNIT_SP,
                Math.max(8f,Prefs.editorFontSize()*.72f),getResources().getDisplayMetrics()));
        setTextColor(theme.text);setHintTextColor(theme.comment);
        setBackgroundColor(theme.background);setHighlightColor(theme.selection);
        gutterPaint.setColor(theme.lineNumber);gutterBg.setColor(theme.gutterBackground);
        currentLinePaint.setColor(theme.currentLine);
        setHorizontallyScrolling(!wrap);setHorizontalScrollBarEnabled(!wrap);
        setPadding(dp(showLineNumbers?48:12),dp(8),dp(14),dp(18));
        setLineSpacing(dp(Prefs.editorLineSpacing()),1f);
        horizontalRange=-1;
        if(wrap&&getScrollX()!=0)scrollTo(0,getScrollY());
        setAutoComplete(Prefs.autoComplete());setAutoClose(Prefs.autoClose());
        if(popup!=null)popup.setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(theme.toolbar));
        refreshHighlight();invalidate();
    }

    public void setLanguageFor(String name) {
        fileName = name == null ? "" : name;
        String n = fileName.toLowerCase();
        if (n.endsWith(".java"))        lang = Lang.JAVA;
        else if (n.endsWith(".kt") || n.endsWith(".kts")) lang = Lang.KOTLIN;
        else if (n.endsWith(".xml") || n.endsWith(".svg") || n.endsWith(".html")) lang = Lang.XML;
        else if (n.endsWith(".smali"))  lang = Lang.SMALI;
        else if (n.endsWith(".gradle")) lang = Lang.JAVA;
        else lang = Lang.PLAIN;
        rebuildProvider();
    }

    private void rebuildProvider() {
        switch (lang) {
            case XML:    provider = new XmlCompletion(index); break;
            case JAVA:   provider = new JavaCompletion(index, false); break;
            case KOTLIN: provider = new JavaCompletion(index, true);  break;
            default:     provider = null;
        }
    }

    public void setSource(String text, String name) {
        setLanguageFor(name);
        internalEdit = true;
        setText(text);
        internalEdit = false;
        horizontalRange=-1;
        post(this::highlight);
    }

    /* ================= الإغلاق التلقائي والإزاحة ================= */

    private class Watcher implements TextWatcher {
        private String inserted;
        private int    insertAt;

        @Override public void beforeTextChanged(CharSequence s, int st, int cnt, int after) {}

        @Override public void onTextChanged(CharSequence s, int st, int before, int count) {
            inserted = (before == 0 && count > 0) ? s.subSequence(st, st + count).toString() : null;
            insertAt = st;
        }

        @Override public void afterTextChanged(Editable e) {
            if (internalEdit) return;
            horizontalRange=-1;

            if (inserted != null && inserted.length() == 1 && autoClose) {
                internalEdit = true;
                try { handleAutoInsert(e, inserted.charAt(0), insertAt); }
                catch (Exception ignored) {}
                internalEdit = false;
            }

            removeCallbacks(highlightTask);
            postDelayed(highlightTask, 420);

            if (autoComplete) {
                removeCallbacks(completeTask);
                postDelayed(completeTask, 240);
            }
        }
    }

    /** يطبّق: أقواس/اقتباسات مزدوجة، تخطّي الإغلاق، إغلاق وسوم XML، الإزاحة التلقائية. */
    private void handleAutoInsert(Editable e, char c, int pos) {
        int cursor = pos + 1;

        /* --- تخطّي القوس المغلق إن كان مكتوباً بالفعل --- */
        if (isCloser(c) && cursor < e.length() && e.charAt(cursor) == c) {
            e.delete(pos, cursor);
            setSelection(cursor);
            return;
        }

        /* --- إدراج القوس المقابل --- */
        String pair = pairFor(c);
        if (pair != null && !(isQuote(c) && insideWord(e, cursor))) {
            e.insert(cursor, pair);
            setSelection(cursor);
            return;
        }

        /* --- XML: إغلاق الوسم عند كتابة '>' --- */
        if (c == '>' && lang == Lang.XML) {
            String before = e.subSequence(0, cursor).toString();
            Matcher m = Pattern.compile("<\\s*([\\w.:-]+)(?:\\s[^<>]*)?>$").matcher(before);
            if (m.find() && !before.endsWith("/>") && !before.matches("(?s).*</\\s*[\\w.:-]+>$")) {
                String tag = m.group(1);
                if (!isVoidTag(tag)) {
                    e.insert(cursor, "</" + tag + ">");
                    setSelection(cursor);
                }
            }
            return;
        }

        /* --- XML: إكمال "</" تلقائياً إلى أقرب وسم مفتوح --- */
        if (c == '/' && lang == Lang.XML && cursor >= 2 && e.charAt(cursor - 2) == '<') {
            String open = XmlCompletion.findUnclosedTag(e.subSequence(0, cursor - 2).toString());
            if (open != null) {
                e.insert(cursor, open + ">");
                setSelection(cursor + open.length() + 1);
            }
            return;
        }

        /* --- إزاحة تلقائية بعد سطر جديد --- */
        if (c == '\n') {
            int lineStart = e.toString().lastIndexOf('\n', Math.max(0, pos - 1)) + 1;
            String prevLine = e.subSequence(lineStart, pos).toString();
            StringBuilder indent = new StringBuilder();
            for (int i = 0; i < prevLine.length(); i++) {
                char ch = prevLine.charAt(i);
                if (ch == ' ' || ch == '\t') indent.append(ch); else break;
            }
            String trimmed = prevLine.trim();
            boolean opensBlock = trimmed.endsWith("{") || trimmed.endsWith("(")
                    || (lang == Lang.XML && trimmed.endsWith(">") && !trimmed.startsWith("</")
                        && !trimmed.endsWith("/>"));
            String add = opensBlock ? "    " : "";
            String ins = indent + add;
            if (!ins.isEmpty()) {
                e.insert(cursor, ins);
                cursor += ins.length();
            }
            // ضع قوس الإغلاق في سطر مستقل
            if (trimmed.endsWith("{") && cursor < e.length() && e.charAt(cursor) == '}') {
                e.insert(cursor, "\n" + indent);
            }
            setSelection(cursor);
        }
    }

    private boolean isVoidTag(String t) {
        return t.equals("br") || t.equals("img") || t.equals("input") || t.equals("meta")
                || t.startsWith("?") || t.startsWith("!");
    }

    private boolean isCloser(char c) { return c == ')' || c == ']' || c == '}' || c == '"' || c == '\''; }
    private boolean isQuote(char c)  { return c == '"' || c == '\''; }

    private String pairFor(char c) {
        switch (c) {
            case '(':  return ")";
            case '[':  return "]";
            case '{':  return "}";
            case '"':  return "\"";
            case '\'': return "'";
            default:   return null;
        }
    }

    private boolean insideWord(Editable e, int cursor) {
        return cursor < e.length() && Character.isLetterOrDigit(e.charAt(cursor));
    }

    /* ===================== قائمة الإكمال ===================== */

    private void showCompletion() {
        if (!autoComplete || provider == null || getText() == null) { dismissPopup(); return; }
        int cursor = getSelectionStart();
        if (cursor < 0 || cursor != getSelectionEnd()) { dismissPopup(); return; }

        Editable text = getText();
        String extra = lang == Lang.XML ? ":@+/._-" : "._";
        String prefix = CompletionUtils.prefixAt(text, cursor, extra);

        // لا تفتح القائمة بلا سبب في النص العادي
        char prev = cursor > 0 ? text.charAt(cursor - 1) : ' ';
        boolean trigger = prefix.length() >= 2 || prev == '<' || prev == '.' || prev == '@'
                || (lang == Lang.XML && (prev == '/' || prev == ':'));
        if (!trigger) { dismissPopup(); return; }

        List<Suggestion> res;
        try { res = provider.complete(text, cursor, prefix); }
        catch (Throwable t) { dismissPopup(); return; }

        if (res == null || res.isEmpty()) { dismissPopup(); return; }

        current.clear();
        current.addAll(res.subList(0,Math.min(5,res.size())));
        ensurePopup();
        popup.setHeight(dp(Math.min(164,Math.max(40,current.size()*39))));
        popupAdapter.notifyDataSetChanged();
        positionPopup(cursor);
        if (!popup.isShowing()) popup.show();
        if (popup.getListView() != null) popup.getListView().setSelection(0);
    }

    private void ensurePopup() {
        if (popup != null) return;
        popup = new ListPopupWindow(getContext());
        popupAdapter = new CompletionAdapter();
        popup.setAdapter(popupAdapter);
        popup.setAnchorView(this);
        popup.setWidth(dp(242));
        popup.setHeight(dp(164));
        popup.setModal(false);
        popup.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(
                theme==null?0xFF161B22:theme.toolbar));
        popup.setOnItemClickListener((parent, view, position, id) -> applySuggestion(position));
    }

    private void positionPopup(int cursor) {
        Layout l = getLayout();
        if (l == null) return;
        int line = l.getLineForOffset(cursor);
        int x = (int) l.getPrimaryHorizontal(cursor);
        int y = l.getLineBottom(line);
        int[] loc = new int[2];
        getLocationInWindow(loc);

        int maxX = Math.max(0, getWidth() - dp(285));
        popup.setHorizontalOffset(Math.min(Math.max(0, x - getScrollX()), maxX));

        int below = getHeight() - (y - getScrollY());
        int popupHeight=Math.max(dp(44),popup.getHeight());
        int off = y - getScrollY() - getHeight() + dp(4);
        if (below < popupHeight+dp(8))
            off = y-getScrollY()-getHeight()-popupHeight-getLineHeight();
        popup.setVerticalOffset(off);
    }

    public void dismissPopup() {
        if (popup != null && popup.isShowing()) popup.dismiss();
    }

    /** إدراج الاقتراح مع دعم علامة | لموضع المؤشر. */
    private void applySuggestion(int position) {
        if (position < 0 || position >= current.size()) return;
        Suggestion s = current.get(position);
        Editable e = getText();
        if (e == null) return;

        int cursor = getSelectionStart();
        String extra = lang == Lang.XML ? ":@+/._-" : "._";
        String prefix = CompletionUtils.prefixAt(e, cursor, extra);
        int start = cursor - prefix.length();

        String ins = s.insert;
        int caret = ins.indexOf('|');
        if (caret >= 0) ins = ins.substring(0, caret) + ins.substring(caret + 1);

        internalEdit = true;
        e.replace(start, cursor, ins);
        internalEdit = false;

        int newCursor = caret >= 0 ? start + caret : start + ins.length();
        setSelection(Math.min(newCursor, e.length()));
        dismissPopup();

        // إغلاق وسم XML تلقائياً بعد اختيار اسم وسم
        if (lang == Lang.XML && s.kind == Suggestion.KIND_TAG && !ins.endsWith(">")
                && !ins.startsWith("</")) {
            // يُغلق لاحقاً عند كتابة '>'
        }
        removeCallbacks(highlightTask);
        postDelayed(highlightTask, 200);
    }

    /** إظهار القائمة يدوياً (زر في شريط الأدوات مثلاً). */
    public void triggerCompletion() { showCompletion(); }

    /** أعد تلوين الجزء الظاهر عند فتح الملف أو تبديل التبويب. */
    public void refreshHighlight(){removeCallbacks(highlightTask);post(highlightTask);}

    /** أبقِ المؤشر ظاهراً بعد تقلص مساحة المحرر عند فتح لوحة المفاتيح وشريط الأدوات. */
    public void ensureCursorVisible(){
        int cursor=Math.max(0,getSelectionStart());
        post(()->{bringPointIntoView(cursor);Layout l=getLayout();
            if(l!=null){int line=l.getLineForOffset(Math.min(cursor,length()));
                int bottom=l.getLineBottom(line)+getTotalPaddingBottom();
                int visible=getScrollY()+getHeight()-getTotalPaddingBottom();
                if(bottom>visible)scrollTo(getScrollX(),Math.max(0,bottom-getHeight()+getTotalPaddingBottom()));
            }});
    }

    /** انتقال دقيق إلى إزاحة وإظهارها في منتصف الشاشة. */
    public void goToOffset(int offset) {
        Editable e=getText(); if(e==null)return;
        int p=Math.max(0,Math.min(offset,e.length())); setSelection(p); requestFocus();
        post(() -> { Layout l=getLayout(); if(l!=null){int line=l.getLineForOffset(p);int y=Math.max(0,l.getLineTop(line)-getHeight()/3);scrollTo(getScrollX(),y);} });
    }

    /** انتقال إلى سطر (ترقيم يبدأ من 1). */
    public void goToLine(int line) {
        Editable e=getText(); if(e==null)return; int wanted=Math.max(1,line),n=1,p=0;
        while(p<e.length()&&n<wanted){if(e.charAt(p++)=='\n')n++;} goToOffset(p);
    }

    public void undo(){onTextContextMenuItem(android.R.id.undo);requestFocus();}
    public void redo(){onTextContextMenuItem(android.R.id.redo);requestFocus();}

    /** يحدد الوسم XML الحالي أو المعرّف/الكلمة عند المؤشر لسهولة حذفها. */
    public void selectTokenAtCursor(){
        Editable e=getText();if(e==null||e.length()==0)return;
        int p=Math.max(0,Math.min(getSelectionStart(),e.length()));
        if(lang==Lang.XML){
            int a=e.toString().lastIndexOf('<',Math.max(0,p-1));
            int b=e.toString().indexOf('>',p);
            if(a>=0&&b>=p){setSelection(a,b+1);return;}
        }
        int a=p,b=p;
        while(a>0&&tokenChar(e.charAt(a-1)))a--;
        while(b<e.length()&&tokenChar(e.charAt(b)))b++;
        if(a<b)setSelection(a,b);
    }

    public void deleteSelectionOrPrevious(){
        Editable e=getText();if(e==null)return;
        int a=Math.max(0,getSelectionStart()),b=Math.max(0,getSelectionEnd());
        if(a>b){int x=a;a=b;b=x;}
        if(a<b)e.delete(a,b);else if(a>0)e.delete(a-1,a);
        requestFocus();
    }

    public void insertAtCursor(String value){
        Editable e=getText();if(e==null)return;
        int a=Math.max(0,getSelectionStart()),b=Math.max(0,getSelectionEnd());
        if(a>b){int x=a;a=b;b=x;}
        e.replace(a,b,value);setSelection(a+value.length());requestFocus();
    }

    public void hideKeyboard(){
        android.view.inputmethod.InputMethodManager im=(android.view.inputmethod.InputMethodManager)
                getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if(im!=null)im.hideSoftInputFromWindow(getWindowToken(),0);
        clearFocus();dismissPopup();
    }

    private boolean tokenChar(char c){
        return Character.isLetterOrDigit(c)||c=='_'||c==':'||c=='.'||c=='-'||c=='@';
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (popup != null && popup.isShowing()) {
            switch (keyCode) {
                case KeyEvent.KEYCODE_ESCAPE:
                    dismissPopup(); return true;
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_TAB:
                    int sel = popup.getListView() == null ? 0
                            : Math.max(0, popup.getListView().getSelectedItemPosition());
                    applySuggestion(sel == android.widget.AdapterView.INVALID_POSITION ? 0 : sel);
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                case KeyEvent.KEYCODE_DPAD_UP:
                    if (popup.getListView() != null) return popup.getListView().onKeyDown(keyCode, event);
                    break;
                default: break;
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onSelectionChanged(int start, int end) {
        super.onSelectionChanged(start, end);
        if (start != end) dismissPopup();
        if(highlightCurrentLine)invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent event){
        scaleDetector.onTouchEvent(event);
        int action=event.getActionMasked();

        if(action==MotionEvent.ACTION_DOWN){
            userTouching=true;horizontalDragging=false;pinchGesture=false;
            touchDownX=lastTouchX=event.getX();touchDownY=event.getY();
            if(!horizontalScroller.isFinished())horizontalScroller.abortAnimation();
            recycleVelocityTracker();velocityTracker=VelocityTracker.obtain();
            velocityTracker.addMovement(event);
            if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(true);
            return super.onTouchEvent(event);
        }

        if(velocityTracker!=null)velocityTracker.addMovement(event);
        boolean zooming=scaling||scaleDetector.isInProgress()||event.getPointerCount()>1||pinchGesture;
        if(action==MotionEvent.ACTION_POINTER_DOWN){
            pinchGesture=true;cancelNativeTouch(event);
            horizontalDragging=false;dismissPopup();
            return true;
        }

        if(action==MotionEvent.ACTION_MOVE&&!zooming){
            float x=event.getX(),dx=x-lastTouchX;
            if(!horizontalDragging){
                float totalX=x-touchDownX,totalY=event.getY()-touchDownY;
                // EditText/ArrowKeyMovementMethod لا يضمن سحباً أفقياً جيداً بعد
                // تقلص النافذة بالـIME. نتولى المحور الأفقي فقط ونترك العمودي
                // والتنقيح/التحديد للنظام كي يبقيا طبيعيين وسريعين.
                if(Math.abs(totalX)>touchSlop&&Math.abs(totalX)>Math.abs(totalY)*1.08f
                        &&horizontalScrollRange()>0){
                    horizontalDragging=true;dismissPopup();cancelNativeTouch(event);
                }
            }
            lastTouchX=x;
            if(horizontalDragging){
                scrollHorizontallyBy(-dx);return true;
            }
            return super.onTouchEvent(event);
        }

        if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL){
            boolean consumed=horizontalDragging||pinchGesture;
            if(horizontalDragging&&action==MotionEvent.ACTION_UP&&velocityTracker!=null){
                velocityTracker.computeCurrentVelocity(1000,maxFlingVelocity);
                float vx=velocityTracker.getXVelocity();
                if(Math.abs(vx)>=minFlingVelocity){
                    int range=horizontalScrollRange();
                    horizontalScroller.fling(getScrollX(),0,(int)-vx,0,0,range,0,0);
                    postInvalidateOnAnimation();
                }
            }
            if(!consumed&&!zooming)consumed=super.onTouchEvent(event);
            horizontalDragging=false;pinchGesture=false;userTouching=false;recycleVelocityTracker();
            if(getParent()!=null)getParent().requestDisallowInterceptTouchEvent(false);
            removeCallbacks(highlightTask);postDelayed(highlightTask,180);
            return consumed||zooming;
        }

        if(action==MotionEvent.ACTION_MOVE&&horizontalDragging)return true;
        if(zooming)return true;
        return super.onTouchEvent(event);
    }

    private void cancelNativeTouch(MotionEvent source){
        MotionEvent cancel=MotionEvent.obtain(source);
        cancel.setAction(MotionEvent.ACTION_CANCEL);
        super.onTouchEvent(cancel);cancel.recycle();
    }

    private void recycleVelocityTracker(){
        if(velocityTracker!=null){velocityTracker.recycle();velocityTracker=null;}
    }

    private void scrollHorizontallyBy(float distance){
        int range=horizontalScrollRange();
        int x=Math.max(0,Math.min(range,Math.round(getScrollX()+distance)));
        if(x!=getScrollX()){scrollTo(x,getScrollY());awakenScrollBars();}
    }

    /** أقصى عرض فعلي لسطر؛ يُحسب مرة لكل تغيير بدلاً من حسابه في كل frame. */
    private int horizontalScrollRange(){
        if(Prefs.editorWordWrap())return 0;
        if(horizontalRange>=0)return horizontalRange;
        Layout l=getLayout();
        if(l==null)return 0;
        float widest=0f;
        for(int i=0,n=l.getLineCount();i<n;i++)widest=Math.max(widest,l.getLineWidth(i));
        horizontalRange=Math.max(0,(int)Math.ceil(widest)+getTotalPaddingLeft()
                +getTotalPaddingRight()-getWidth());
        return horizontalRange;
    }

    @Override public void computeScroll(){
        super.computeScroll();
        if(horizontalScroller.computeScrollOffset()){
            int x=Math.max(0,Math.min(horizontalScrollRange(),horizontalScroller.getCurrX()));
            scrollTo(x,getScrollY());postInvalidateOnAnimation();
        }
    }

    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh){
        super.onSizeChanged(w,h,oldw,oldh);horizontalRange=-1;
        post(()->{int max=horizontalScrollRange();if(getScrollX()>max)scrollTo(max,getScrollY());});
    }

    @Override protected void onScrollChanged(int l,int t,int oldl,int oldt){
        super.onScrollChanged(l,t,oldl,oldt);
        if(Math.abs(t-oldt)>getLineHeight()*2){
            // لوّن بعد توقف السحب/الـfling فقط؛ إعادة spans أثناء كل frame كانت تعلق المحرر.
            removeCallbacks(highlightTask);
            if(!userTouching&&!scaling)postDelayed(highlightTask,180);
        }
    }

    @Override protected void onDetachedFromWindow() {
        dismissPopup();
        super.onDetachedFromWindow();
    }

    /* ---------------- محوّل القائمة ---------------- */

    private class CompletionAdapter extends BaseAdapter {
        @Override public int getCount() { return current.size(); }
        @Override public Object getItem(int i) { return current.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int i, View convert, ViewGroup parent) {
            LinearLayout row;
            if (convert instanceof LinearLayout) row = (LinearLayout) convert;
            else {
                row = new LinearLayout(getContext());
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(dp(8),dp(3),dp(8),dp(3));
                row.setMinimumHeight(dp(38));
                row.setGravity(android.view.Gravity.CENTER_VERTICAL);

                TextView icon = new TextView(getContext());
                icon.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
                icon.setTextSize(11);
                icon.setWidth(dp(22));
                row.addView(icon);

                TextView label = new TextView(getContext());
                label.setTextSize(12);
                label.setTextColor(theme==null?0xFFE6EDF3:theme.text);
                label.setSingleLine(true);
                label.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
                row.addView(label, new LinearLayout.LayoutParams(0,
                        ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

                TextView detail = new TextView(getContext());
                detail.setTextSize(9);
                detail.setTextColor(theme==null?0xFF8B949E:theme.comment);
                detail.setSingleLine(true);
                detail.setMaxWidth(dp(76));
                detail.setEllipsize(android.text.TextUtils.TruncateAt.END);
                row.addView(detail);
                row.setTag(new TextView[]{icon,label,detail});
            }
            Suggestion s = current.get(i);
            TextView[] views=(TextView[])row.getTag();
            TextView icon=views[0],label=views[1],detail=views[2];
            icon.setText(s.icon());
            icon.setTextColor(s.color());
            label.setTextColor(theme==null?0xFFE6EDF3:theme.text);
            detail.setTextColor(theme==null?0xFF8B949E:theme.comment);
            label.setText(s.label);
            detail.setText(s.detail == null ? "" : s.detail);
            return row;
        }
    }

    /* ===================== التلوين ===================== */

    private void highlight() {
        // لا نغيّر spans أثناء السحب/التكبير؛ ذلك كان يعيد تخطيط EditText وسط الحركة
        // ويظهر كتعليق أو اختفاء مؤقت للأسطر على الملفات الكبيرة.
        if(userTouching||scaling)return;
        Editable e=getText();Layout layout=getLayout();
        if(e==null||layout==null||lang==Lang.PLAIN||e.length()==0)return;
        int first=Math.max(0,layout.getLineForVertical(getScrollY())-HIGHLIGHT_MARGIN_LINES);
        int last=Math.min(layout.getLineCount()-1,
                layout.getLineForVertical(getScrollY()+getHeight())+HIGHLIGHT_MARGIN_LINES);
        int start=layout.getLineStart(first);
        int end=layout.getLineEnd(last);
        internalEdit=true;
        try{
            for(ForegroundColorSpan s:e.getSpans(start,end,ForegroundColorSpan.class))e.removeSpan(s);
            for(StyleSpan s:e.getSpans(start,end,StyleSpan.class))e.removeSpan(s);
            switch(lang){
                case JAVA:
                    apply(e,P_JAVA_KW,cKeyword,start,end);apply(e,P_ANNOT,cAnnotation,start,end);
                    applyGroup(e,P_QUALIFIED_NAME,1,cResource,start,end);
                    apply(e,P_TYPE,cType,start,end);apply(e,P_METHOD,cMethod,start,end);
                    apply(e,P_NUMBER,cNumber,start,end);break;
                case KOTLIN:
                    apply(e,P_KT_KW,cKeyword,start,end);apply(e,P_ANNOT,cAnnotation,start,end);
                    applyGroup(e,P_QUALIFIED_NAME,1,cResource,start,end);
                    apply(e,P_TYPE,cType,start,end);apply(e,P_METHOD,cMethod,start,end);
                    apply(e,P_NUMBER,cNumber,start,end);break;
                case SMALI:
                    apply(e,P_SMALI_KW,cKeyword,start,end);apply(e,P_NUMBER,cNumber,start,end);break;
                case XML:
                    apply(e,P_XML_TAG,cTag,start,end);apply(e,P_XML_ATT,cAnnotation,start,end);break;
                default:break;
            }
            apply(e,P_STRING,cString,start,end);
            if(lang==Lang.XML){
                apply(e,P_XML_RESOURCE,cResource,start,end);
                apply(e,P_XML_COMMENT,cComment,start,end);
            }else if(lang==Lang.SMALI){
                apply(e,P_SMALI_COMMENT,cComment,start,end);
            }else{
                apply(e,P_CODE_COMMENT,cComment,start,end);
            }
        }catch(Exception ignored){}finally{internalEdit=false;}
    }

    private void apply(Editable e,Pattern pattern,int color,int start,int end){
        Matcher m=pattern.matcher(e.subSequence(start,end));
        while(m.find())e.setSpan(new ForegroundColorSpan(color),start+m.start(),start+m.end(),
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    /** يلوّن مجموعة محددة فقط، مثل اسم الحزمة بعد package/import على نمط AIDE. */
    private void applyGroup(Editable e,Pattern pattern,int group,int color,int start,int end){
        Matcher m=pattern.matcher(e.subSequence(start,end));
        while(m.find()&&m.start(group)>=0)e.setSpan(new ForegroundColorSpan(color),
                start+m.start(group),start+m.end(group),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    /* ===================== الهامش ===================== */

    @Override protected void onDraw(Canvas canvas) {
        int left=getScrollX(),top=getScrollY();
        Layout layout=getLayout();
        if(layout!=null&&layout.getLineCount()>0&&highlightCurrentLine
                &&getSelectionStart()==getSelectionEnd()){
            int cursor=Math.max(0,Math.min(getSelectionStart(),length()));
            int line=layout.getLineForOffset(cursor);
            canvas.drawRect(left+(showLineNumbers?dp(43):0),layout.getLineTop(line),
                    left+getWidth(),layout.getLineBottom(line),currentLinePaint);
        }
        if(showLineNumbers){
            canvas.drawRect(left,top,left+dp(42),top+getHeight(),gutterBg);
            if(layout!=null&&layout.getLineCount()>0){
                int first=Math.max(0,layout.getLineForVertical(top)-1);
                int last=Math.min(layout.getLineCount()-1,
                        layout.getLineForVertical(top+getHeight())+1);
                for(int i=first;i<=last;i++){
                    int baseline=getLineBounds(i,lineRect);
                    canvas.drawText(String.valueOf(i+1),left+dp(5),baseline,gutterPaint);
                }
            }
            canvas.drawLine(left+dp(42),top,left+dp(42),top+getHeight(),gutterPaint);
        }
        super.onDraw(canvas);
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density); }
}
