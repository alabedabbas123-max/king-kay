package com.almlk.editorapkpro.project;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * منظف آمن لمخلفات البناء.
 *
 * القاعدة الأساسية: لا يُحذف ملف مصدر أو مورد من app/src/main لمجرد أن اسمه غير
 * مستخدم. مجلدات res/color وres/animator وما شابه تُحذف فقط عندما تكون فارغة.
 * أما build/.gradle/dist وكاش Python والملفات pyc/pyo فهي نواتج قابلة لإعادة التوليد.
 */
public final class BuildArtifactCleaner {
    private BuildArtifactCleaner() {}

    public interface Progress {
        void onProgress(String step, int percent);
    }

    private enum Kind { GENERATED, EMPTY }

    private static final Set<String> CACHE_DIR_NAMES = new HashSet<>();
    private static final Set<String> SKIP_DIR_NAMES = new HashSet<>();
    static {
        Collections.addAll(CACHE_DIR_NAMES,
                ".gradle", ".cxx", ".externalNativeBuild", ".kotlin",
                "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache",
                ".hypothesis", ".tox", ".nox", "htmlcov");
        Collections.addAll(SKIP_DIR_NAMES, ".git", ".svn", ".hg");
    }

    private static final String[] FIXED_GENERATED_PATHS = {
            "build", ".gradle", "dist", "out", "bin",
            "app/build", "app/.gradle", "app/.cxx", "app/.externalNativeBuild",
            "app/out", "app/dist", "app/bin",
            ".apkide/rebuild/build", ".apkide/rebuild/dist"
    };

    /**
     * مجلدات تشظية DEX/Smali المؤقتة (Jadx/Apktool/DexShardSplitter). تُحذف
     * عادة تلقائياً في finally عند نجاح الفك، لكن OOM حقيقي أو إغلاق قسري
     * للتطبيق أثناء الفك قد يوقف الخيط قبل تنفيذ finally فتبقى عالقة. هي ليست
     * جزءاً من شيفرة المشروع بأي حال، فتُعامل كمخلفات أينما وُجدت، بما فيها
     * داخل .apkide الذي لا يخضع لتنظيف "المجلد الفارغ" العام.
     */
    private static final java.util.regex.Pattern TRANSIENT_SHARD_DIR = java.util.regex.Pattern.compile(
            "^(?:\\.smali-shards-|dex-shards-|oom-retry-\\d+-).*");

    /** ملف DEX خام لم يُحذف بعد فكه بسبب توقف العملية قسراً في المنتصف. */
    private static final java.util.regex.Pattern STRAY_DEX_FILE =
            java.util.regex.Pattern.compile("^classes\\d*\\.dex$");

    private static final class Target {
        final File file;
        final Kind kind;
        Target(File file, Kind kind) { this.file=file; this.kind=kind; }
    }

    /** نتيجة الفحص قبل الحذف؛ لا تنفذ الخطة إلا عبر execute. */
    public static final class Plan {
        private final File root;
        private final Project project;
        private final List<Target> targets = new ArrayList<>();
        public int generatedEntries;
        public int emptyDirectories;
        public int containedFiles;
        public int containedDirectories;
        public long bytes;

        private Plan(Project project, File root) { this.project=project; this.root=root; }
        public boolean isEmpty() { return targets.isEmpty(); }
        public int targetCount() { return targets.size(); }
        public String rootPath() { return root.getAbsolutePath(); }

        /** أمثلة لمسارات ستُحذف كي يراجعها المستخدم قبل التأكيد. */
        public List<String> samples(int max) {
            List<String> out=new ArrayList<>();
            for(Target t:targets){
                if(out.size()>=max)break;
                out.add(relative(root,t.file));
            }
            return out;
        }
    }

    public static final class Result {
        public int deletedFiles;
        public int deletedDirectories;
        public int failed;
        public long freedBytes;

        public int totalDeleted() { return deletedFiles+deletedDirectories; }
    }

    private static final class State {
        final Plan plan;
        final Map<String,Target> targetMap=new LinkedHashMap<>();
        final Set<String> anchors=new HashSet<>();
        final Logger log;
        final Progress progress;
        int visited;
        State(Plan plan,Logger log,Progress progress){
            this.plan=plan;this.log=log;this.progress=progress;
        }
    }

    /** يفحص فقط ولا يحذف شيئاً، ويُستخدم لبناء شاشة المعاينة. */
    public static Plan scan(Project project, Logger log, Progress progress) throws IOException {
        if(project==null||project.root()==null)throw new IOException("المشروع غير صالح");
        File root=project.root().getCanonicalFile();
        if(!root.isDirectory())throw new IOException("مجلد المشروع غير موجود: "+root);
        Plan plan=new Plan(project,root);
        State state=new State(plan,log,progress);
        addAnchors(state,project,root);

        if(progress!=null)progress.onProgress("فحص مجلدات البناء والكاش…",-1);
        // هذه المسارات ثابتة، وبعضها داخل .apkide التي لا نجتازها حفاظاً على نسخة Smali.
        for(String rel:FIXED_GENERATED_PATHS){
            File f=new File(root,rel);
            if(f.exists())addTarget(state,f,Kind.GENERATED);
        }
        scanDirectory(root,state);

        plan.targets.addAll(state.targetMap.values());
        // اعرض مسارات المخلفات أولاً، ثم المجلدات الفارغة.
        plan.targets.sort((a,b)->{
            int kind=Integer.compare(a.kind.ordinal(),b.kind.ordinal());
            if(kind!=0)return kind;
            return relative(root,a.file).compareToIgnoreCase(relative(root,b.file));
        });
        for(Target target:plan.targets){
            Stats stats=measureNoFollow(target.file);
            plan.containedFiles+=stats.files;
            plan.containedDirectories+=stats.directories;
            plan.bytes+=stats.bytes;
            if(target.kind==Kind.GENERATED)plan.generatedEntries++;
            else plan.emptyDirectories++;
        }
        if(log!=null)log.i("clean-scan: "+plan.targetCount()+" أهداف، "+
                plan.containedFiles+" ملف، "+FileUtil.humanSize(plan.bytes));
        return plan;
    }

    /** ينفذ خطة سبق عرضها؛ يعيد التحقق من الحدود ومن فراغ المجلدات قبل كل حذف. */
    public static Result execute(Plan plan, Logger log, Progress progress) throws IOException {
        if(plan==null)throw new IOException("خطة التنظيف غير موجودة");
        File root=plan.root.getCanonicalFile();
        Result result=new Result();
        List<Target> targets=new ArrayList<>(plan.targets);
        // نواتج البناء أولاً، ثم المجلدات الفارغة من الأعمق إلى الأعلى.
        targets.sort((a,b)->{
            if(a.kind!=b.kind)return a.kind==Kind.GENERATED?-1:1;
            return Integer.compare(depth(b.file),depth(a.file));
        });
        int done=0,total=Math.max(1,targets.size());
        for(Target target:targets){
            done++;
            File f=target.file;
            if(progress!=null)progress.onProgress("تنظيف "+relative(root,f),
                    Math.min(99,done*100/total));
            try{
                File canonical=f.getCanonicalFile();
                if(!inside(root,canonical)||canonical.equals(root)){result.failed++;continue;}
                if(!f.exists())continue;
                if(target.kind==Kind.EMPTY){
                    if(isLink(f)||!f.isDirectory())continue;
                    File[] kids=f.listFiles();
                    if(kids==null||kids.length!=0)continue; // أضيف ملف بعد الفحص: نحافظ عليه.
                }else if(!isStillGenerated(plan.project,root,f)){
                    result.failed++;continue;
                }
                Stats before=measureNoFollow(f);
                if(deleteNoFollow(f)){
                    result.deletedFiles+=before.files;
                    result.deletedDirectories+=before.directories;
                    result.freedBytes+=before.bytes;
                }else result.failed++;
            }catch(Exception e){
                result.failed++;
                if(log!=null)log.w("تعذّر تنظيف "+f.getAbsolutePath()+": "+e.getMessage());
            }
        }
        if(progress!=null)progress.onProgress("اكتمل التنظيف الآمن",100);
        if(log!=null)log.i("clean-safe: حُذف "+result.deletedFiles+" ملف و"+
                result.deletedDirectories+" مجلد ("+FileUtil.humanSize(result.freedBytes)+")"+
                (result.failed>0?"، تعذر "+result.failed:""));
        return result;
    }

    /** مسار مختصر للتنظيف التلقائي بعد الفك. */
    public static Result clean(Project project, Logger log, Progress progress) throws IOException {
        return execute(scan(project,log,progress),log,progress);
    }

    private static boolean scanDirectory(File dir,State state) throws IOException {
        if(isLink(dir))return false;
        File canonical=dir.getCanonicalFile();
        if(!inside(state.plan.root,canonical))return false;
        String key=canonical.getAbsolutePath();
        if(!canonical.equals(state.plan.root)&&isGeneratedDirectory(
                state.plan.project,state.plan.root,canonical)){
            addTarget(state,canonical,Kind.GENERATED);
            return true;
        }
        String name=canonical.getName();
        if(".apkide".equals(name)){
            // لا نطبّق تنظيف "المجلد الفارغ" العام هنا حفاظاً على نسخة Smali
            // السريعة (.apkide/rebuild)، لكن نمسح مخلفات تشظية DEX/Smali
            // العالقة من عملية فك تعطلت في المنتصف (OOM/إغلاق قسري) أينما
            // وُجدت داخله؛ هذه المجلدات المؤقتة ليست جزءاً من مصدر المشروع.
            sweepTransientShards(canonical,state);
            return false;
        }
        if(SKIP_DIR_NAMES.contains(name))return false;

        boolean emptyAfter=true;
        File[] kids=canonical.listFiles();
        if(kids==null)return false; // صلاحية غير كافية: لا نعتبره فارغاً.
        for(File kid:kids){
            state.visited++;
            if(state.progress!=null&&state.visited%250==0)
                state.progress.onProgress("فحص "+state.visited+" ملفاً ومجلداً…",-1);
            if(kid.isDirectory()&&!isLink(kid)){
                if(!scanDirectory(kid,state))emptyAfter=false;
            }else if(isGeneratedFile(kid)){
                addTarget(state,kid,Kind.GENERATED);
            }else emptyAfter=false;
        }
        if(emptyAfter&&!state.anchors.contains(key)&&!canonical.equals(state.plan.root)){
            addTarget(state,canonical,Kind.EMPTY);
            return true;
        }
        return false;
    }

    /** يبحث فقط عن مجلدات/ملفات تشظية DEX/Smali المؤقتة العالقة داخل .apkide. */
    private static void sweepTransientShards(File dir,State state) throws IOException {
        File[] kids=dir.listFiles();
        if(kids==null)return;
        for(File kid:kids){
            if(isLink(kid))continue;
            String kidName=kid.getName();
            if(kid.isDirectory()){
                if(TRANSIENT_SHARD_DIR.matcher(kidName).matches())
                    addTarget(state,kid.getCanonicalFile(),Kind.GENERATED);
                else
                    sweepTransientShards(kid,state);
            }else if(STRAY_DEX_FILE.matcher(kidName).matches()){
                addTarget(state,kid.getCanonicalFile(),Kind.GENERATED);
            }
        }
    }

    private static void addAnchors(State state,Project p,File root) throws IOException {
        addAnchor(state,root);
        addAnchor(state,p.appModule());
        addAnchor(state,p.mainDir());
        addAnchor(state,p.javaDir());
        addAnchor(state,p.resDir());
        addAnchor(state,p.assetsDir());
        addAnchor(state,new File(p.mainDir(),"kotlin"));
        addAnchor(state,new File(p.mainDir(),"python"));
        addAnchor(state,new File(p.mainDir(),"jniLibs"));
        addAnchor(state,new File(root,"app"));
        addAnchor(state,new File(root,"app/src"));
        addAnchor(state,p.metaDir());
        addAnchor(state,new File(p.metaDir(),"rebuild"));
    }

    private static void addAnchor(State state,File file) throws IOException {
        state.anchors.add(file.getCanonicalPath());
    }

    private static void addTarget(State state,File file,Kind kind) throws IOException {
        File canonical=file.getCanonicalFile();
        if(!inside(state.plan.root,canonical)||canonical.equals(state.plan.root))return;
        String key=canonical.getAbsolutePath();
        Target old=state.targetMap.get(key);
        // GENERATED أقوى من EMPTY ولا يحتاج إعادة الإضافة.
        if(old==null||(old.kind==Kind.EMPTY&&kind==Kind.GENERATED))
            state.targetMap.put(key,new Target(file,kind));
    }

    private static boolean isStillGenerated(Project p,File root,File f) throws IOException {
        if(isGeneratedFile(f))return true;
        return f.isDirectory()&&isGeneratedDirectory(p,root,f.getCanonicalFile());
    }

    private static boolean isGeneratedDirectory(Project p,File root,File dir) throws IOException {
        String name=dir.getName();
        String rel=relative(root,dir).replace(File.separatorChar,'/');
        if(TRANSIENT_SHARD_DIR.matcher(name).matches())return true;
        if(CACHE_DIR_NAMES.contains(name))return true;
        for(String fixed:FIXED_GENERATED_PATHS)
            if(fixed.equals(rel))return true;
        File parent=dir.getParentFile();
        boolean rootOrModule=parent!=null&&(parent.getCanonicalFile().equals(root)
                ||new File(parent,"build.gradle").isFile()
                ||new File(parent,"build.gradle.kts").isFile());
        if(rootOrModule&&("build".equals(name)||"dist".equals(name)
                ||"out".equals(name)||"bin".equals(name)))return true;
        return false;
    }

    private static boolean isGeneratedFile(File f){
        if(STRAY_DEX_FILE.matcher(f.getName()).matches())return true;
        String name=f.getName().toLowerCase(Locale.ROOT);
        return name.endsWith(".pyc")||name.endsWith(".pyo")
                ||name.equals(".coverage")||name.startsWith(".coverage.");
    }

    private static boolean inside(File root,File child){
        String rp=root.getAbsolutePath();
        String cp=child.getAbsolutePath();
        return cp.equals(rp)||cp.startsWith(rp+File.separator);
    }

    private static boolean isLink(File file){
        try{return Files.isSymbolicLink(file.toPath());}
        catch(Throwable ignored){return false;}
    }

    /** حذف لا يتبع الروابط الرمزية خارج المشروع. */
    private static boolean deleteNoFollow(File file){
        try{
            if(isLink(file))return Files.deleteIfExists(file.toPath());
            if(file.isDirectory()){
                File[] kids=file.listFiles();
                if(kids==null)return false;
                for(File kid:kids)if(!deleteNoFollow(kid))return false;
            }
            return Files.deleteIfExists(file.toPath())||!file.exists();
        }catch(Exception e){return false;}
    }

    private static final class Stats { int files,directories; long bytes; }

    private static Stats measureNoFollow(File start){
        Stats s=new Stats();
        if(start==null||!start.exists())return s;
        Deque<File> stack=new ArrayDeque<>();
        stack.push(start);
        while(!stack.isEmpty()){
            File f=stack.pop();
            if(isLink(f)){s.files++;s.bytes+=Math.max(0,f.length());continue;}
            if(f.isDirectory()){
                s.directories++;
                File[] kids=f.listFiles();
                if(kids!=null)for(File kid:kids)stack.push(kid);
            }else{s.files++;s.bytes+=Math.max(0,f.length());}
        }
        return s;
    }

    private static int depth(File file){
        int n=0;for(File f=file;f!=null;f=f.getParentFile())n++;return n;
    }

    private static String relative(File root,File file){
        String rp=root.getAbsolutePath(),fp=file.getAbsolutePath();
        if(fp.equals(rp))return root.getName();
        return fp.startsWith(rp+File.separator)?fp.substring(rp.length()+1):fp;
    }
}
