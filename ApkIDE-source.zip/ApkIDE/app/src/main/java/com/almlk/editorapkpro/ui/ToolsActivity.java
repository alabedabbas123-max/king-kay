package com.almlk.editorapkpro.ui;

import android.net.Uri;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.tools.Shell;
import com.almlk.editorapkpro.tools.ToolInstaller;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** مثبّت الأدوات + طرفية Linux مدمجة. */
public class ToolsActivity extends AppCompatActivity {
    public static final String EXTRA_COMMAND="command";
    public static final String EXTRA_WORK_DIR="work_dir";

    private ToolInstaller installer;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Shell shell=new Shell();
    private LinearLayout toolList;
    private Ui.ActivityBusy topBusy;
    private TextView console;
    private EditText command;
    private ToolInstaller.Tool pickTarget;
    private final ActivityResultLauncher<String[]> picker=registerForActivityResult(
            new ActivityResultContracts.OpenDocument(),this::picked);

    @Override protected void onCreate(@Nullable Bundle b){
        super.onCreate(b);
        installer=new ToolInstaller(new Logger("tools"));
        setContentView(content());
        topBusy=new Ui.ActivityBusy(this);
        startShell();
    }

    private View content(){
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setBackgroundColor(0xFF0D1117);
        MaterialToolbar tb=new MaterialToolbar(this);tb.setNavigationIcon(R.drawable.ic_close);tb.setNavigationOnClickListener(v->finish());
        tb.setTitle("الأدوات وبيئة Linux");tb.setSubtitle(android.os.Build.SUPPORTED_ABIS[0]+" • Android "+android.os.Build.VERSION.SDK_INT);
        tb.setTitleTextColor(0xFFF0F3F6);tb.setSubtitleTextColor(0xFF9AA7B4);tb.setBackgroundColor(0xFF161B22);page.addView(tb,lp(-1,dp(60)));

        ScrollView toolsScroll=new ScrollView(this);toolList=new LinearLayout(this);toolList.setOrientation(LinearLayout.VERTICAL);toolList.setPadding(dp(12),dp(8),dp(12),dp(8));toolsScroll.addView(toolList);renderTools();
        page.addView(toolsScroll,new LinearLayout.LayoutParams(-1,0,0.52f));

        TextView termTitle=new TextView(this);termTitle.setText("  طرفية Linux — /system/bin/sh");termTitle.setTextColor(0xFF7EE787);termTitle.setTypeface(android.graphics.Typeface.MONOSPACE,android.graphics.Typeface.BOLD);termTitle.setGravity(Gravity.CENTER_VERTICAL);termTitle.setBackgroundColor(0xFF161B22);page.addView(termTitle,lp(-1,dp(35)));
        console=new TextView(this);console.setTextColor(0xFFB7F5C5);console.setTextSize(11);console.setTypeface(android.graphics.Typeface.MONOSPACE);console.setBackgroundColor(0xFF050807);console.setPadding(dp(8),dp(6),dp(8),dp(6));console.setMovementMethod(new ScrollingMovementMethod());console.setTextIsSelectable(true);
        page.addView(console,new LinearLayout.LayoutParams(-1,0,0.48f));
        LinearLayout input=new LinearLayout(this);input.setGravity(Gravity.CENTER_VERTICAL);input.setBackgroundColor(0xFF161B22);
        TextView dollar=new TextView(this);dollar.setText(" $ ");dollar.setTextColor(0xFF00E5A0);dollar.setTextSize(16);input.addView(dollar);
        command=new EditText(this);command.setSingleLine(true);command.setTextColor(0xFFF0F3F6);command.setHintTextColor(0xFF6E7681);command.setHint("اكتب أمر Linux…");command.setTypeface(android.graphics.Typeface.MONOSPACE);
        command.setOnEditorActionListener((v,id,e)->{send();return true;});input.addView(command,new LinearLayout.LayoutParams(0,dp(48),1));
        MaterialButton send=button("تنفيذ");send.setOnClickListener(v->send());input.addView(send,lp(dp(82),dp(44)));page.addView(input,lp(-1,dp(50)));
        return page;
    }

    private void renderTools(){
        toolList.removeAllViews();
        TextView intro=text("تنزيل HTTPS متدفق وآمن دون الحاجة إلى curl/wget، ثم تثبيت وفحص عبر /system/bin/sh. ملفات ELF يجب أن تطابق "+android.os.Build.SUPPORTED_ABIS[0]+".",12,0xFF9AA7B4);intro.setPadding(dp(4),0,dp(4),dp(8));toolList.addView(intro);
        MaterialButton net=button("فحص INTERNET + DNS + HTTPS");net.setOnClickListener(v->diagnoseNetwork());toolList.addView(net,lp(-1,dp(46)));
        for(ToolInstaller.Tool t:ToolInstaller.catalog()){
            LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(12),dp(8),dp(12),dp(8));row.setBackgroundColor(0xFF161B22);
            TextView name=text((installer.isInstalled(t)?"✓  ":"＋  ")+t.title,14,installer.isInstalled(t)?0xFF7EE787:0xFFF0F3F6);name.setTypeface(null,android.graphics.Typeface.BOLD);row.addView(name);
            TextView desc=text(t.description+"\n"+installer.status(t),11,0xFF8B949E);row.addView(desc);
            row.setOnClickListener(v->toolMenu(t));LinearLayout.LayoutParams rp=lp(-1,-2);rp.setMargins(0,0,0,dp(6));toolList.addView(row,rp);
        }
        MaterialButton custom=button("تثبيت أداة مخصّصة / فتح ملف");custom.setOnClickListener(v->customTool());toolList.addView(custom,lp(-1,dp(48)));
    }

    private void toolMenu(ToolInstaller.Tool t){
        new MaterialAlertDialogBuilder(this).setTitle(t.title).setMessage(t.description+"\n\n"+installer.status(t))
                .setItems(new String[]{"تثبيت من الرابط الافتراضي","تثبيت من رابط آخر","اختيار ملف من الجهاز","حذف"},(d,w)->{
                    if(w==0)installUrl(t,null);else if(w==1)askUrl(t);else if(w==2){pickTarget=t;picker.launch(new String[]{"*/*"});}else{installer.remove(t);renderTools();}
                }).show();
    }
    private void askUrl(ToolInstaller.Tool t){EditText e=new EditText(this);e.setHint("https://… رابط تنزيل مباشر");e.setText(t.url);new MaterialAlertDialogBuilder(this).setTitle("رابط "+t.title).setView(e).setNegativeButton("إلغاء",null).setPositiveButton("تنزيل",(d,w)->installUrl(t,e.getText().toString())).show();}
    private void customTool(){
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(20),0,dp(20),0);EditText name=new EditText(this);name.setHint("اسم الملف: tool أو tool.jar");EditText url=new EditText(this);url.setHint("رابط التنزيل المباشر");b.addView(name);b.addView(url);
        new MaterialAlertDialogBuilder(this).setTitle("أداة مخصّصة").setView(b).setNegativeButton("إلغاء",null).setNeutralButton("ملف محلي",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty())n="custom-tool";pickTarget=new ToolInstaller.Tool(n,n,"أداة مخصّصة","",n,!n.endsWith(".jar"));picker.launch(new String[]{"*/*"});}).setPositiveButton("تنزيل",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty()){Ui.toast(this,"أدخل اسم الملف");return;}installUrl(new ToolInstaller.Tool(n,n,"أداة مخصّصة",url.getText().toString(),n,!n.endsWith(".jar")),url.getText().toString());}).show();
    }
    private void installUrl(ToolInstaller.Tool t,String url){
        topBusy.show("تثبيت "+t.title+"…");
        Ui.Progress p=new Ui.Progress(this,"تثبيت "+t.title).show();
        worker.execute(()->{
            try{
                File f=installer.install(t,url,(s,n)->runOnUiThread(()->{
                    topBusy.update(s); p.update(s,n);
                }));
                runOnUiThread(()->{
                    topBusy.hide();p.dismiss();renderTools();append("installed: "+f.getAbsolutePath());
                });
            }catch(Exception e){
                runOnUiThread(()->{topBusy.hide();p.dismiss();Ui.error(this,e);});
            }
        });
    }
    private void diagnoseNetwork(){
        topBusy.show("تشخيص الإنترنت…");
        Ui.Progress p=new Ui.Progress(this,"تشخيص الإنترنت").show();
        p.update("فحص الصلاحية والشبكة وDNS وTLS…",-1);
        worker.execute(()->{
            String result=installer.diagnoseNetwork(this);
            runOnUiThread(()->{
                topBusy.hide();p.dismiss();append("network: "+result);
                new MaterialAlertDialogBuilder(this).setTitle("نتيجة فحص الإنترنت")
                        .setMessage(result+"\n\nصلاحية INTERNET عادية ولا تحتاج طلباً من المستخدم وقت التشغيل.")
                        .setPositiveButton("حسناً",null).show();
            });
        });
    }
    private void picked(Uri uri){
        if(uri==null||pickTarget==null)return;
        topBusy.show("نسخ وفحص الأداة…");
        Ui.Progress p=new Ui.Progress(this,"نسخ الأداة").show();
        worker.execute(()->{
            try{
                File tmp=FileUtil.importUri(getContentResolver(),uri,Env.tmpDir());
                File f=installer.installLocal(pickTarget,tmp);FileUtil.delete(tmp);
                runOnUiThread(()->{
                    topBusy.hide();p.dismiss();renderTools();append("installed: "+f.getAbsolutePath());
                });
            }catch(Exception e){
                runOnUiThread(()->{topBusy.hide();p.dismiss();Ui.error(this,e);});
            }
        });
    }

    private void startShell(){
        try{
            String requested=getIntent().getStringExtra(EXTRA_WORK_DIR);
            File work=requested==null?Env.rootDir():new File(requested);
            if(!work.isDirectory())work=Env.rootDir();
            shell.startInteractive(work,new Shell.Output(){
                @Override public void onLine(String s){runOnUiThread(()->append(s));}
                @Override public void onExit(int c){runOnUiThread(()->append("[shell exited: "+c+"]"));}
            });
            Map<String,String> env=Shell.environmentInfo();
            append("Editor APK Pro Linux shell");
            append("Work="+work.getAbsolutePath());
            for(Map.Entry<String,String> e:env.entrySet())append(e.getKey()+"="+e.getValue());
            append("استخدم: ls, cp, mv, chmod, unzip, tar, grep, sed …");
            String run=getIntent().getStringExtra(EXTRA_COMMAND);
            if(run!=null&&!run.trim().isEmpty()){
                append("$ "+run);shell.send(run);
            }
        }catch(Exception e){append("تعذر تشغيل shell: "+e.getMessage());}
    }
    private void send(){String c=command.getText().toString().trim();if(c.isEmpty())return;append("$ "+c);shell.send(c);command.setText("");}
    private void append(String s){console.append(s+"\n");int n=console.getText().length();if(n>80000)console.setText(console.getText().subSequence(n-60000,n));console.post(()->{android.text.Layout l=console.getLayout();if(l!=null){int y=l.getLineTop(console.getLineCount())-console.getHeight();if(y>0)console.scrollTo(0,y);}});}
    private TextView text(String s,int z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    private MaterialButton button(String s){MaterialButton b=new MaterialButton(this);b.setText(s);b.setTextSize(11);return b;}
    private LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}
    @Override protected void onDestroy(){shell.stop();worker.shutdownNow();super.onDestroy();}
}
