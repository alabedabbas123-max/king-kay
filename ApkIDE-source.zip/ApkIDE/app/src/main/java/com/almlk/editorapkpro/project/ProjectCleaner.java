package com.almlk.editorapkpro.project;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.util.*;

/**
 * تنظيف المشروع بعد الفك:
 *  - حذف حزم المكتبات المعروفة التي فُكّت مع التطبيق (androidx, kotlin, okhttp, gms …)
 *    واستبدالها باعتماديات Gradle حقيقية => مشروع أصغر وقابل للبناء فعلاً.
 *  - حذف مخلفات jadx (تعليقات الأخطاء الفارغة، الملفات الصفرية، المجلدات الفارغة).
 */
public final class ProjectCleaner {

    private ProjectCleaner() {}

    /** حزمة مفكوكة -> اعتمادية Gradle البديلة. */
    private static final LinkedHashMap<String, String> LIB_MAP = new LinkedHashMap<>();
    static {
        LIB_MAP.put("androidx/appcompat",            "androidx.appcompat:appcompat:1.7.0");
        LIB_MAP.put("androidx/core",                 "androidx.core:core:1.13.1");
        LIB_MAP.put("androidx/recyclerview",         "androidx.recyclerview:recyclerview:1.3.2");
        LIB_MAP.put("androidx/constraintlayout",     "androidx.constraintlayout:constraintlayout:2.1.4");
        LIB_MAP.put("androidx/fragment",             "androidx.fragment:fragment:1.8.2");
        LIB_MAP.put("androidx/lifecycle",            "androidx.lifecycle:lifecycle-runtime:2.8.4");
        LIB_MAP.put("androidx/room",                 "androidx.room:room-runtime:2.6.1");
        LIB_MAP.put("androidx/work",                 "androidx.work:work-runtime:2.9.0");
        LIB_MAP.put("androidx/navigation",           "androidx.navigation:navigation-fragment:2.7.7");
        LIB_MAP.put("androidx/viewpager2",           "androidx.viewpager2:viewpager2:1.1.0");
        LIB_MAP.put("androidx/multidex",             "androidx.multidex:multidex:2.0.1");
        LIB_MAP.put("androidx",                      "androidx.appcompat:appcompat:1.7.0");
        LIB_MAP.put("android/support",               "androidx.legacy:legacy-support-v4:1.0.0");
        LIB_MAP.put("com/google/android/material",   "com.google.android.material:material:1.12.0");
        LIB_MAP.put("com/google/android/gms",        "com.google.android.gms:play-services-base:18.5.0");
        LIB_MAP.put("com/google/firebase",           "com.google.firebase:firebase-common:21.0.0");
        LIB_MAP.put("com/google/gson",               "com.google.code.gson:gson:2.11.0");
        LIB_MAP.put("com/google/common",             "com.google.guava:guava:33.2.1-android");
        LIB_MAP.put("com/squareup/okhttp3",          "com.squareup.okhttp3:okhttp:4.12.0");
        LIB_MAP.put("okhttp3",                       "com.squareup.okhttp3:okhttp:4.12.0");
        LIB_MAP.put("okio",                          "com.squareup.okio:okio:3.9.0");
        LIB_MAP.put("retrofit2",                     "com.squareup.retrofit2:retrofit:2.11.0");
        LIB_MAP.put("com/squareup/picasso",          "com.squareup.picasso:picasso:2.8");
        LIB_MAP.put("com/bumptech/glide",            "com.github.bumptech.glide:glide:4.16.0");
        LIB_MAP.put("io/reactivex",                  "io.reactivex.rxjava3:rxjava:3.1.8");
        LIB_MAP.put("kotlin",                        "org.jetbrains.kotlin:kotlin-stdlib:1.9.24");
        LIB_MAP.put("kotlinx/coroutines",            "org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1");
        LIB_MAP.put("org/apache/commons",            "org.apache.commons:commons-lang3:3.14.0");
        LIB_MAP.put("butterknife",                   "com.jakewharton:butterknife:10.2.3");
        LIB_MAP.put("dagger",                        "com.google.dagger:dagger:2.51.1");
        LIB_MAP.put("javax/inject",                  "javax.inject:javax.inject:1");
        LIB_MAP.put("org/json",                      "");   // موجودة في الـ SDK
        LIB_MAP.put("org/intellij/lang/annotations",  "org.jetbrains:annotations:24.1.0");
        LIB_MAP.put("org/jetbrains/annotations",      "org.jetbrains:annotations:24.1.0");
    }

    public static class Report {
        public Set<String> dependencies = new LinkedHashSet<>();
        public int removedDirs, removedFiles;
        public long freedBytes;
        public boolean kotlinDetected;
    }

    public static Report clean(File javaDir, String appPackage, boolean removeLibs, Logger log) {
        Report r = new Report();
        if (!javaDir.exists()) return r;

        String appPath = appPackage == null ? "" : appPackage.replace('.', '/');

        for (Map.Entry<String, String> e : LIB_MAP.entrySet()) {
            File dir = new File(javaDir, e.getKey());
            if (!dir.isDirectory()) continue;
            // لا نحذف حزمة تقع داخل حزمة التطبيق نفسه
            if (!appPath.isEmpty() && e.getKey().startsWith(appPath)) continue;
            if (e.getKey().startsWith("kotlin")) r.kotlinDetected = true;
            if (!e.getValue().isEmpty()) r.dependencies.add(e.getValue());
            if (removeLibs) {
                r.freedBytes += FileUtil.sizeOf(dir);
                r.removedFiles += FileUtil.walk(dir, "java").size();
                FileUtil.delete(dir);
                r.removedDirs++;
            }
        }

        // كشف Kotlin من وجود ملفات .kt أو توقيعات Metadata
        if (!r.kotlinDetected) {
            for (File f : FileUtil.walk(javaDir, "kt")) { r.kotlinDetected = true; break; }
        }

        // حذف الملفات الفارغة والمجلدات الفارغة
        for (File f : FileUtil.walk(javaDir)) {
            if (f.length() == 0) { FileUtil.delete(f); r.removedFiles++; }
        }
        pruneEmptyDirs(javaDir);

        r.dependencies.add("androidx.appcompat:appcompat:1.7.0");
        log.i("clean: أُزيلت " + r.removedDirs + " حزمة مكتبات (" +
              FileUtil.humanSize(r.freedBytes) + ") واستُبدلت بـ " + r.dependencies.size() + " اعتمادية Gradle");
        return r;
    }

    private static boolean pruneEmptyDirs(File dir) {
        File[] kids = dir.listFiles();
        if (kids == null) return false;
        boolean empty = true;
        for (File k : kids) {
            if (k.isDirectory()) { if (!pruneEmptyDirs(k)) empty = false; }
            else empty = false;
        }
        if (empty) { //noinspection ResultOfMethodCallIgnored
            dir.delete(); }
        return empty;
    }
}
