package com.almlk.editorapkpro.problems;

import java.io.File;

/** خطأ أو تحذير مستخرج من مخرجات البناء. */
public class Problem {

    public static final int ERROR   = 0;
    public static final int WARNING = 1;
    public static final int INFO    = 2;

    public int    severity = ERROR;
    public String fileName;     // اسم الملف المعروض (public.xml …)
    public File   file;         // الملف الفعلي إن أمكن تحديده
    public int    line = -1;
    public int    column = -1;
    public String message;
    public String tool;         // aapt / apktool / javac / smali / jadx

    public Problem(int severity, String fileName, String message, String tool) {
        this.severity = severity;
        this.fileName = fileName;
        this.message  = message;
        this.tool     = tool;
    }

    public String title() {
        return fileName == null ? (tool == null ? "build" : tool) : fileName;
    }

    public String subtitle() {
        StringBuilder sb = new StringBuilder();
        if (tool != null) sb.append(tool).append(": ");
        sb.append(message);
        if (line > 0) sb.append("  (سطر ").append(line).append(')');
        return sb.toString();
    }

    public int color() {
        switch (severity) {
            case WARNING: return 0xFFFFB020;
            case INFO:    return 0xFF79C0FF;
            default:      return 0xFFFF5C5C;
        }
    }
}
