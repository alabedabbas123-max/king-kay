package com.almlk.editorapkpro.ui.complete;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public final class CompletionUtils {

    private CompletionUtils() {}

    /** استخراج البادئة التي يكتبها المستخدم قبل المؤشر. */
    public static String prefixAt(CharSequence s, int cursor, String extraChars) {
        int i = cursor;
        while (i > 0) {
            char c = s.charAt(i - 1);
            if (Character.isLetterOrDigit(c) || c == '_' || extraChars.indexOf(c) >= 0) i--;
            else break;
        }
        return s.subSequence(i, cursor).toString();
    }

    /** مطابقة ضبابية: بادئة، ثم احتواء، ثم مطابقة أحرف كبيرة (camelCase). */
    public static int match(String candidate, String prefix) {
        if (prefix.isEmpty()) return 1;
        String c = candidate.toLowerCase(Locale.ROOT);
        String p = prefix.toLowerCase(Locale.ROOT);
        if (c.startsWith(p)) return 1000 - candidate.length();
        int idx = c.indexOf(p);
        if (idx >= 0) return 500 - idx;
        // camelCase: "sOCL" -> setOnClickListener
        int ci = 0;
        for (int i = 0; i < p.length(); i++) {
            ci = c.indexOf(p.charAt(i), ci);
            if (ci < 0) return -1;
            ci++;
        }
        return 200 - candidate.length();
    }

    public static List<Suggestion> rank(List<Suggestion> all, String prefix, int limit) {
        List<Suggestion> out = new ArrayList<>();
        for (Suggestion s : all) {
            int m = match(s.label, prefix);
            if (m < 0) continue;
            s.score = m;
            out.add(s);
        }
        Collections.sort(out);
        return out.size() > limit ? out.subList(0, limit) : out;
    }
}
