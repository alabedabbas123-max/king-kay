package com.almlk.editorapkpro.ui.adapter;

import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Space;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.widget.ImageViewCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * مستعرض ملفات بمجلد واحد في كل شاشة. فتح مجلد يستبدل القائمة بمحتواه المباشر
 * بدلاً من توسيع شجرة طويلة تغطي المجلدات المجاورة.
 */
public class FileTreeAdapter extends RecyclerView.Adapter<FileTreeAdapter.VH> {

    public interface Listener {
        void onFile(File f);
        void onLongFile(File f);
        default void onDir(File d) {}
    }

    public static class Node {
        final File file;
        final boolean parent;
        Node(File f) { this(f,false); }
        Node(File f,boolean isParent) { file=f;parent=isParent; }
    }

    private final List<Node> visible=new ArrayList<>();
    private final Listener listener;
    private File root,currentDir;
    private String filter="";

    public FileTreeAdapter(Listener l){listener=l;}

    public void setRoot(File r){
        root=r;
        currentDir=r;
        filter="";
        rebuild();
    }

    /** افتح مجلداً واجعله القائمة الحالية إن كان داخل جذر المشروع. */
    public boolean showDirectory(File dir){
        if(dir==null||!dir.isDirectory()||!insideRoot(dir))return false;
        currentDir=dir;
        rebuild();
        return true;
    }

    /** رجوع مستوى واحد؛ يعيد false عند جذر المشروع. */
    public boolean goUp(){
        if(currentDir==null||root==null||same(currentDir,root))return false;
        File parent=currentDir.getParentFile();
        if(parent==null||!insideRoot(parent))parent=root;
        currentDir=parent;
        filter="";
        rebuild();
        return true;
    }

    public File currentDirectory(){return currentDir;}

    public void setFilter(String q){
        filter=q==null?"":q.toLowerCase(Locale.ROOT).trim();
        rebuild();
    }

    public void refresh(){
        if(currentDir==null||!currentDir.isDirectory())currentDir=root;
        rebuild();
    }

    private void rebuild(){
        visible.clear();
        if(currentDir!=null){
            if(filter.isEmpty()){
                // عنصر مجلد واضح مثل مديري الملفات: الضغط على «..» يرجع مستوى واحداً.
                if(root!=null&&!same(currentDir,root)){
                    File parent=currentDir.getParentFile();
                    if(parent==null||!insideRoot(parent))parent=root;
                    visible.add(new Node(parent,true));
                }
                addDirectChildren(currentDir);
            }else addMatches(currentDir);
        }
        notifyDataSetChanged();
    }

    /** الوضع العادي: أبناء المجلد الحالي فقط، بلا أي توسيع متداخل. */
    private void addDirectChildren(File dir){
        File[] kids=sorted(dir);
        if(kids==null)return;
        for(File k:kids){
            if(isInternalOrGenerated(k))continue;
            visible.add(new Node(k));
        }
    }

    /** البحث داخل المجلد الحالي وفروعه ويشمل أسماء المجلدات نفسها. */
    private void addMatches(File dir){
        File[] kids=sorted(dir);
        if(kids==null)return;
        for(File k:kids){
            if(isInternalOrGenerated(k))continue;
            if(k.getName().toLowerCase(Locale.ROOT).contains(filter))visible.add(new Node(k));
            if(k.isDirectory())addMatches(k);
            if(visible.size()>=600)return;
        }
    }

    private File[] sorted(File dir){
        File[] kids=dir.listFiles();
        if(kids==null)return null;
        Arrays.sort(kids,(a,b)->a.isDirectory()!=b.isDirectory()
                ?(a.isDirectory()?-1:1):a.getName().compareToIgnoreCase(b.getName()));
        return kids;
    }

    private boolean insideRoot(File f){
        try{
            String base=root.getCanonicalPath();
            String path=f.getCanonicalPath();
            return path.equals(base)||path.startsWith(base+File.separator);
        }catch(Exception e){return false;}
    }

    private boolean same(File a,File b){
        try{return a.getCanonicalFile().equals(b.getCanonicalFile());}
        catch(Exception e){return a.equals(b);}
    }

    private static boolean isInternalOrGenerated(File f){
        String n=f.getName();
        return n.equals(".apkide")||n.equals(".gradle")||n.equals(".idea")
                ||n.equals("build")||n.equals("dist")||n.equals("out")||n.equals("bin")
                ||n.equals(".cxx")||n.equals(".externalNativeBuild")||n.equals(".kotlin")
                ||n.equals("__pycache__")||n.equals(".pytest_cache")||n.equals(".mypy_cache")
                ||n.equals(".ruff_cache")||n.equals(".tox")||n.equals(".nox");
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p,int t){
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_file,p,false));
    }

    @Override public void onBindViewHolder(@NonNull VH h,int i){
        Node n=visible.get(i);
        boolean dir=n.file.isDirectory();
        h.name.setText(n.parent?"..":n.file.getName());
        // قائمة نظيفة مثل AIDE: رمز المجلد و«..» فقط دون نص زائد.
        h.size.setText("");
        h.icon.setImageResource(dir?R.drawable.ic_folder:iconFor(n.file.getName()));
        int color=dir?0xFFFF9800:fileColor(n.file.getName());
        ImageViewCompat.setImageTintList(h.icon,ColorStateList.valueOf(color));
        h.name.setTextColor(dir?0xFFF4F7FA:0xFFE6EDF3);
        h.name.setTypeface(Typeface.DEFAULT,dir?Typeface.BOLD:Typeface.NORMAL);
        h.indent.getLayoutParams().width=0;
        h.itemView.setContentDescription(n.parent?"الرجوع إلى المجلد السابق":n.file.getName());
        h.itemView.setOnClickListener(v->{
            if(n.parent){
                if(goUp())listener.onDir(currentDir);
            }else if(dir){
                currentDir=n.file;
                filter="";
                rebuild();
                listener.onDir(n.file);
            }else listener.onFile(n.file);
        });
        h.itemView.setOnLongClickListener(v->{
            if(n.parent)return false;
            listener.onLongFile(n.file);return true;
        });
    }

    private int iconFor(String name){
        String e=FileUtil.ext(name);
        if(e.equals("java")||e.equals("kt")||e.equals("smali"))return R.drawable.ic_code;
        return R.drawable.ic_file;
    }

    private int fileColor(String name){
        String e=FileUtil.ext(name);
        if(e.equals("java"))return 0xFF4FC3F7;
        if(e.equals("kt")||e.equals("kts"))return 0xFFB388FF;
        if(e.equals("xml"))return 0xFF00BCD4;
        if(e.equals("gradle")||e.equals("properties"))return 0xFF66BB6A;
        if(e.equals("png")||e.equals("jpg")||e.equals("jpeg")||e.equals("webp"))return 0xFFFF5DA2;
        if(e.equals("json")||e.equals("yml")||e.equals("yaml"))return 0xFFFFCA28;
        if(e.equals("smali")||e.equals("dex"))return 0xFFFF7043;
        if(e.equals("apk")||e.equals("zip")||e.equals("jar"))return 0xFF26A69A;
        return 0xFF90A4AE;
    }

    @Override public int getItemCount(){return visible.size();}

    static class VH extends RecyclerView.ViewHolder{
        Space indent;ImageView icon;TextView name,size;
        VH(@NonNull View v){
            super(v);
            indent=v.findViewById(R.id.indent);
            icon=v.findViewById(R.id.icon);
            name=v.findViewById(R.id.txtName);
            size=v.findViewById(R.id.txtSize);
        }
    }
}
