package com.almlk.editorapkpro.util;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;

public final class XmlUtil {
    private XmlUtil() {}

    public static Document parse(File f) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        return dbf.newDocumentBuilder().parse(f);
    }

    public static Document blank(String rootTag) throws Exception {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        dbf.setNamespaceAware(true);
        Document d = dbf.newDocumentBuilder().newDocument();
        d.appendChild(d.createElement(rootTag));
        return d;
    }

    public static void save(Document doc, File out) throws Exception {
        File p = out.getParentFile();
        if (p != null) p.mkdirs();
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.INDENT, "yes");
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(out), "UTF-8")) {
            t.transform(new DOMSource(doc), new StreamResult(w));
        }
    }

    public static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";

    public static String attr(Element e, String name) {
        String v = e.getAttributeNS(ANDROID_NS, name);
        return v == null || v.isEmpty() ? e.getAttribute(name) : v;
    }

    public static void setAttr(Element e, String name, String value) {
        e.setAttributeNS(ANDROID_NS, "android:" + name, value);
    }
}
