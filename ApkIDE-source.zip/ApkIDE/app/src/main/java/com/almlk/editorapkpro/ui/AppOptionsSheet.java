package com.almlk.editorapkpro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.model.AppInfo;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.AppScanner;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import com.google.android.material.bottomsheet.BottomSheetDialogFragment;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;

/** قائمة الخيارات التفاعلية التي تظهر عند الضغط على أي تطبيق. */
public class AppOptionsSheet extends BottomSheetDialogFragment {

    private static AppInfo current;

    public static void show(AppCompatActivity a, AppInfo app) {
        current = app;
        new AppOptionsSheet().show(a.getSupportFragmentManager(), "opts");
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup c, @Nullable Bundle s) {
        View v = inf.inflate(R.layout.sheet_app_options, c, false);
        AppInfo app = current;
        if (app == null) { dismiss(); return v; }

        ((TextView) v.findViewById(R.id.txtName)).setText(app.label);
        ((TextView) v.findViewById(R.id.txtPkg)).setText(app.packageName);
        ImageView icon=v.findViewById(R.id.icon);
        try{icon.setImageDrawable(requireContext().getPackageManager()
                .getApplicationIcon(app.packageName));}
        catch(Exception ignored){icon.setImageResource(R.drawable.ic_apps);}

        v.findViewById(R.id.optOpen).setOnClickListener(x -> {
            Intent i = AppScanner.launchIntent(requireContext(), app.packageName);
            if (i != null) startActivity(i);
            else Ui.toast(requireContext(), "لا يمكن تشغيل هذا التطبيق");
            dismiss();
        });

        v.findViewById(R.id.optEdit).setOnClickListener(x -> {
            decompile(app, Project.MODE_RESOURCES); dismiss();
        });

        v.findViewById(R.id.optSource).setOnClickListener(x -> {
            decompile(app, Project.MODE_SOURCE); dismiss();
        });

        v.findViewById(R.id.optExtract).setOnClickListener(x -> { extract(app); dismiss(); });

        v.findViewById(R.id.optInfo).setOnClickListener(x -> { info(app); dismiss(); });
        return v;
    }

    private void decompile(AppInfo app, int mode) {
        File apk = new File(app.sourceApk);
        if (!apk.exists()) { Ui.toast(requireContext(), "ملف APK غير متاح"); return; }
        DecompileStarter.start((AppCompatActivity) requireActivity(), apk,
                app.label + "_" + app.versionName, mode);
    }

    private void extract(AppInfo app) {
        try {
            File out = new File(Env.outputDir(),
                    app.packageName + "_" + app.versionName + ".apk");
            FileUtil.copyDir(new File(app.sourceApk), out);
            Ui.toast(requireContext(), "تم الاستخراج إلى: " + out.getAbsolutePath());
            share(out);
        } catch (Exception e) { Ui.error(requireContext(), e); }
    }

    private void share(File f) {
        try {
            android.net.Uri uri = FileProvider.getUriForFile(requireContext(),
                    requireContext().getPackageName() + ".fileprovider", f);
            startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND)
                    .setType("application/vnd.android.package-archive")
                    .putExtra(Intent.EXTRA_STREAM, uri)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "مشاركة"));
        } catch (Exception ignored) {}
    }

    @Override public void onDestroyView(){
        View view=getView();
        if(view!=null){ImageView icon=view.findViewById(R.id.icon);if(icon!=null)icon.setImageDrawable(null);}
        current=null;
        super.onDestroyView();
    }

    private void info(AppInfo a) {
        String msg = "الحزمة: " + a.packageName
                + "\nالإصدار: " + a.versionName + " (" + a.versionCode + ")"
                + "\nminSdk: " + a.minSdk + "   targetSdk: " + a.targetSdk
                + "\nالحجم: " + FileUtil.humanSize(a.apkSize)
                + "\nالمسار: " + a.sourceApk
                + (a.splitApks != null ? "\nsplits: " + a.splitApks.length : "");
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(a.label).setMessage(msg).setPositiveButton("إغلاق", null).show();
    }
}
