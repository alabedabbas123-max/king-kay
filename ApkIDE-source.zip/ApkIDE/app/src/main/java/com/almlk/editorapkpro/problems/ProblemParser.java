package com.almlk.editorapkpro.problems;

import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * يحوّل مخرجات أدوات البناء إلى قائمة أخطاء منظّمة تُعرض في لوحة الأخطاء
 * (مثل: "2 errors ➜ public.xml ➜ aapt: invalid symbol 'default'").
 */
public class ProblemParser {

    /** aapt2: /path/res/values/public.xml:12:5: error: invalid symbol 'default'. */
    private static final Pattern P_AAPT = Pattern.compile(
            "(?:^|\\s)([^\\s:]+\\.(?:xml|png|jpg|webp))(?::(\\d+))?(?::(\\d+))?:?\\s*" +
            "(?:error|Error)\\s*:?\\s*(.+)");

    /** aapt2 بصيغة أخرى: error: resource ... (at 'id' with value '@android:id/actionSend'). */
    private static final Pattern P_AAPT2_PLAIN = Pattern.compile(
            "(?:^|\\s)(?:E|error|ERROR)[:/]\\s*(.+)");

    /** javac / ecj: /path/File.java:34: error: cannot find symbol */
    private static final Pattern P_JAVA = Pattern.compile(
            "([^\\s:]+\\.(?:java|kt)):(\\d+):\\s*(?:error|ERROR)\\s*:?\\s*(.+)");

    /** apktool / brut: [Exception] brut.androlib.AndrolibException: message */
    private static final Pattern P_APKTOOL = Pattern.compile(
            "(?:brut\\.[\\w.]*Exception|AndrolibException|Exception in thread)\\s*:?\\s*(.+)");

    /** smali: Error occurred while compiling file path/X.smali */
    private static final Pattern P_SMALI = Pattern.compile(
            "[Ee]rror.*?([^\\s]+\\.smali)(?::(\\d+))?");

    private static final Pattern P_WARNING = Pattern.compile(
            "(?:^|\\s)(?:W|warning|WARNING)[:/]\\s*(.+)");

    /** يحلّل سجل البناء كاملاً. */
    public static List<Problem> parse(List<String> logLines, Project project) {
        Map<String, Problem> unique = new LinkedHashMap<>();
        for (String raw : logLines) {
            String line = strip(raw);
            if (line.isEmpty()) continue;
            Problem p = parseLine(line, project);
            if (p == null) continue;
            String key = p.severity + "|" + p.fileName + "|" + p.message + "|" + p.line;
            unique.putIfAbsent(key, p);
        }
        return new ArrayList<>(unique.values());
    }

    public static Problem parseLine(String line, Project project) {
        Matcher m;

        m = P_JAVA.matcher(line);
        if (m.find()) {
            Problem p = new Problem(Problem.ERROR, nameOf(m.group(1)), m.group(3), "javac");
            p.line = intOf(m.group(2));
            p.file = resolve(project, m.group(1));
            return p;
        }

        m = P_AAPT.matcher(line);
        if (m.find()) {
            Problem p = new Problem(Problem.ERROR, nameOf(m.group(1)), m.group(4), "aapt");
            p.line   = intOf(m.group(2));
            p.column = intOf(m.group(3));
            p.file   = resolve(project, m.group(1));
            return p;
        }

        m = P_SMALI.matcher(line);
        if (m.find()) {
            Problem p = new Problem(Problem.ERROR, nameOf(m.group(1)), line, "smali");
            p.line = intOf(m.group(2));
            p.file = resolve(project, m.group(1));
            return p;
        }

        m = P_APKTOOL.matcher(line);
        if (m.find())
            return new Problem(Problem.ERROR, null, m.group(1), "apktool");

        if (line.contains("error:") || line.contains("Error:") || line.startsWith("E/")) {
            m = P_AAPT2_PLAIN.matcher(line);
            String msg = m.find() ? m.group(1) : line;
            Problem p = new Problem(Problem.ERROR, guessFile(line), msg, "build");
            p.file = p.fileName == null ? null : resolve(project, p.fileName);
            return p;
        }

        m = P_WARNING.matcher(line);
        if (m.find() && line.length() < 300)
            return new Problem(Problem.WARNING, guessFile(line), m.group(1), "build");

        return null;
    }

    /* ------------------------------------------------------------------ */

    private static String strip(String s) {
        // يزيل طابع الوقت الذي يضيفه Logger: [12:00:00.000] I/ msg
        return s.replaceFirst("^\\[\\d{2}:\\d{2}:\\d{2}\\.\\d{3}\\]\\s*[IWE]/\\s*", "").trim();
    }

    private static String nameOf(String path) {
        if (path == null) return null;
        int i = Math.max(path.lastIndexOf('/'), path.lastIndexOf('\\'));
        return i >= 0 ? path.substring(i + 1) : path;
    }

    private static String guessFile(String line) {
        Matcher m = Pattern.compile("([\\w./\\\\-]+\\.(?:xml|java|kt|smali|png|jpg))").matcher(line);
        return m.find() ? nameOf(m.group(1)) : null;
    }

    private static int intOf(String s) {
        try { return s == null ? -1 : Integer.parseInt(s); } catch (Exception e) { return -1; }
    }

    /** يحاول إيجاد الملف الحقيقي داخل المشروع للانتقال إليه عند النقر. */
    private static File resolve(Project project, String pathOrName) {
        if (project == null || pathOrName == null) return null;
        File direct = new File(pathOrName);
        if (direct.isAbsolute() && direct.exists()) return direct;
        String name = nameOf(pathOrName);
        for (File f : FileUtil.walk(project.root(), FileUtil.ext(name)))
            if (f.getName().equals(name)) return f;
        return null;
    }
}
