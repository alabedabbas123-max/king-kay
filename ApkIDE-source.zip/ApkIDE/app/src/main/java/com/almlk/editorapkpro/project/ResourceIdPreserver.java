package com.almlk.editorapkpro.project;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.util.FileUtil;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

/**
 * الحفاظ التام على معرّفات العناصر وروابطها (R.id.* ، R.layout.* ، R.string.* …).
 *
 * كيف يعمل:
 *  1) apktool ينتج res/values/public.xml يحوي كل مورد مع معرّفه الأصلي (0x7f0a0012 …).
 *  2) نحوّله إلى ملف stable-ids.txt بصيغة aapt2 : package:type/name = 0xID
 *  3) نمرّره في build.gradle عبر additionalParameters '--stable-ids'
 *     => أي إعادة بناء تُنتج نفس الأرقام تماماً، فتبقى كل الإشارات R.id.* صالحة،
 *        وتبقى المكتبات التي تستخدم أرقاماً ثابتة (reflection/getIdentifier) تعمل.
 *  4) نحذف ملفات R.java التي ولّدها jadx لأن AGP سيولّد R الحقيقي بنفس القيم.
 */
public final class ResourceIdPreserver {

    private ResourceIdPreserver() {}

    public static class Result {
        public int    count;
        public File   stableIdsFile;
        public File   publicXml;
        public Map<String, String> idMap = new LinkedHashMap<>(); // "type/name" -> "0x7f0a0012"
    }

    public static Result apply(File projectRoot, File resDir, String packageName, Logger log) {
        Result r = new Result();
        File publicXml = new File(resDir, "values/public.xml");
        if (!publicXml.exists()) {
            log.w("res-ids: لا يوجد public.xml — سيُعتمد ترقيم AGP الافتراضي");
            return r;
        }
        r.publicXml = publicXml;
        try {
            StringBuilder sb = new StringBuilder();
            // Streaming بدلاً من DOM: public.xml في التطبيقات الكبيرة قد يحتوي عشرات
            // آلاف العناصر، وبناء شجرة DOM كاملة كان يحتفظ بعشرات MB بلا حاجة.
            forEachPublic(publicXml,(type,name,id)->{
                if(type.isEmpty()||name.isEmpty()||id.isEmpty())return;
                sb.append(packageName).append(':').append(type).append('/')
                        .append(name).append(" = ").append(id).append('\n');
                r.idMap.put(type+"/"+name,id);
            });
            r.count = r.idMap.size();
            r.stableIdsFile = new File(projectRoot, "app/stable-ids.txt");
            FileUtil.write(r.stableIdsFile, sb.toString());
            log.i("res-ids: تم تثبيت " + r.count + " معرّف مورد (stable-ids.txt)");
        } catch (Exception e) {
            log.e("res-ids: فشل توليد stable-ids", e);
        }
        return r;
    }

    /**
     * عند فك DEX منفرداً لا يحمّل Jadx resources.arsc كي تبقى الذاكرة منخفضة؛
     * أعد هنا ربط الثوابت الرقمية المعروفة من public.xml إلى R.type.name.
     */
    public static int restoreReferences(File javaDir,String packageName,Result ids,Logger log){
        if(ids==null||ids.idMap.isEmpty())return 0;
        Map<String,String> byValue=new HashMap<>();
        for(Map.Entry<String,String> e:ids.idMap.entrySet()){
            String hex=e.getValue().toLowerCase(Locale.ROOT);
            String[] key=e.getKey().split("/",2);
            if(key.length!=2)continue;
            String field=key[1].replace('.','_').replace('-','_');
            String ref=(packageName==null||packageName.isEmpty()?"":packageName+".")
                    +"R."+key[0]+"."+field;
            byValue.put(hex,ref);
            try{byValue.put(Long.toString(Long.decode(hex)),ref);}catch(Exception ignored){}
        }
        // لم تعد الخريطة الأصلية لازمة بعد قلبها؛ تحريرها قبل قراءة آلاف ملفات Java.
        ids.idMap.clear();
        java.util.regex.Pattern literal=java.util.regex.Pattern.compile(
                "(?<![A-Za-z0-9_])(0x[0-9a-fA-F]{8}|[0-9]{7,10})(?![A-Za-z0-9_])");
        int changed=0;
        for(File f:FileUtil.walk(javaDir,"java","kt")){
            try{
                String text=FileUtil.read(f);
                java.util.regex.Matcher m=literal.matcher(text);
                StringBuffer out=new StringBuffer();boolean hit=false;
                while(m.find()){
                    String raw=m.group(1);
                    String ref=byValue.get(raw.toLowerCase(Locale.ROOT));
                    if(ref==null)continue;
                    m.appendReplacement(out,java.util.regex.Matcher.quoteReplacement(ref));
                    changed++;hit=true;
                }
                if(hit){m.appendTail(out);FileUtil.write(f,out.toString());}
            }catch(Exception ignored){}
        }
        if(changed>0)log.i("res-ids: أُعيد ربط "+changed+" ثابتاً رقمياً إلى R.type.name");
        return changed;
    }

    /**
     * عند فك DEX الخام قد يسمي Jadx صنف الموارد C0097R ونحصل على
     * C0097R.id.name. وحّد كل هذه الأسماء إلى R قبل حذف الصنف المولّد؛
     * بعدها يولّد AGP صنف R الصحيح من res/public.xml.
     */
    public static int normalizeRClassAliases(File javaDir,Logger log){
        java.util.regex.Pattern alias=java.util.regex.Pattern.compile("\\bC\\d{3,}R\\b");
        int changed=0;
        for(File f:FileUtil.walk(javaDir,"java","kt")){
            try{
                String text=FileUtil.read(f);
                java.util.regex.Matcher m=alias.matcher(text);
                StringBuffer out=new StringBuffer();int local=0;
                while(m.find()){
                    m.appendReplacement(out,"R");local++;
                }
                if(local>0){
                    m.appendTail(out);FileUtil.write(f,out.toString());changed+=local;
                }
            }catch(Exception ignored){}
        }
        if(changed>0&&log!=null)log.i("res-ids: صُحّح "+changed+" مرجعاً من C####R إلى R");
        return changed;
    }

    /** حذف R.java / BuildConfig.java المولّدة من jadx لتفادي التعارض مع AGP. */
    public static int removeGeneratedRClasses(File javaDir, Logger log) {
        int n = 0;
        for (File f : FileUtil.walk(javaDir, "java")) {
            String name = f.getName();
            if (name.equals("R.java") || name.startsWith("R$")
                    || name.matches("C\\d{3,}R(\\$.*)?\\.java")
                    || name.equals("BuildConfig.java") || name.equals("Manifest.java")) {
                FileUtil.delete(f);
                n++;
            }
        }
        if (n > 0) log.i("clean: حُذف " + n + " ملف R/BuildConfig مولّد (سيعيد Gradle توليدها بنفس القيم)");
        return n;
    }

    /**
     * يستخرج ids المستخدمة في التخطيطات ويولّد values/ids.xml لأي معرّف مفقود،
     * كي لا ينكسر أي R.id.* يشير إلى عنصر عُرّف ديناميكياً.
     */
    private interface PublicConsumer { void accept(String type,String name,String id)throws Exception; }

    private static void forEachPublic(File xml,PublicConsumer consumer)throws Exception{
        XmlPullParser parser=XmlPullParserFactory.newInstance().newPullParser();
        try(InputStream in=new FileInputStream(xml)){
            parser.setInput(in,"UTF-8");
            int event=parser.getEventType();
            while(event!=XmlPullParser.END_DOCUMENT){
                if(event==XmlPullParser.START_TAG&&"public".equals(parser.getName())){
                    String type=parser.getAttributeValue(null,"type");
                    String name=parser.getAttributeValue(null,"name");
                    String id=parser.getAttributeValue(null,"id");
                    consumer.accept(type==null?"":type,name==null?"":name,id==null?"":id);
                }
                event=parser.next();
            }
        }
    }

    private static final java.util.regex.Pattern DUMMY_NAME =
            java.util.regex.Pattern.compile("(?i)apktool_dummy");

    /** عنصر مورد وهمي بسيط ينشئه Apktool (keepBrokenResources) لأي id لم يُحل:
     *  <public.../> أو <item name="APKTOOL_DUMMY_xxx" .../> أو
     *  <type name="APKTOOL_DUMMY_xxx">value</type>. هذه العناصر مسطّحة دوماً
     *  (بلا أبناء من نفس الوسم)، لذا مطابقة الوسم الواحد آمنة هنا. */
    private static final java.util.regex.Pattern DUMMY_ELEMENT = java.util.regex.Pattern.compile(
            "\\s*<([A-Za-z_][\\w.:-]*)\\b[^>]*\\bname\\s*=\\s*\"(?i:apktool_dummy)[^\"]*\"[^>]*?"
                    + "(?:/>|>.*?</\\1\\s*>)\\s*", java.util.regex.Pattern.DOTALL);

    /**
     * تنظيف نهائي بعد تثبيت معرّفات الموارد: يحذف res/values/public.xml (ملف
     * محاسبة داخلي لـ Apktool، لا معنى له خارج إعادة بناء Apktool نفسها؛ AGP
     * يولّد R الحقيقي من ملفات res الفعلية بعد stable-ids.txt) ويزيل أي عنصر
     * أو ملف APKTOOL_DUMMY_* أبقاه خيار keepBrokenResources لموارد تعذّر حلّها،
     * كي لا يبقى المشروع الناتج محمّلاً بمخلفات فك ثنائية لا تخص الشيفرة الأصلية.
     */
    public static void cleanApktoolResidue(File resDir, Logger log) {
        if (resDir == null || !resDir.isDirectory()) return;
        int strippedEntries = 0, removedFiles = 0;
        for (File xml : FileUtil.walk(resDir, "xml")) {
            try {
                String text = FileUtil.read(xml);
                if (text.toLowerCase(Locale.ROOT).contains("apktool_dummy")) {
                    String cleaned = DUMMY_ELEMENT.matcher(text).replaceAll("\n");
                    if (!cleaned.equals(text)) {
                        FileUtil.write(xml, cleaned);
                        strippedEntries++;
                    }
                }
            } catch (Exception ignored) { /* لا نوقف التنظيف لملف واحد تالف */ }
        }
        for (File f : FileUtil.walk(resDir)) {
            if (DUMMY_NAME.matcher(f.getName()).find()) {
                FileUtil.delete(f);
                removedFiles++;
            }
        }
        File publicXml = new File(resDir, "values/public.xml");
        if (publicXml.isFile()) {
            FileUtil.delete(publicXml);
            removedFiles++;
        }
        if (log != null && (strippedEntries > 0 || removedFiles > 0))
            log.i("res-clean: أُزيلت " + strippedEntries + " عنصر APKTOOL_DUMMY وحُذف "
                    + removedFiles + " ملف مخلّف من Apktool (بينها public.xml بعد تثبيت المعرّفات)");
    }

    public static int ensureIdsDeclared(File resDir, Logger log) {
        Set<String> declared = new HashSet<>();
        Set<String> used     = new HashSet<>();
        try {
            File publicXml = new File(resDir, "values/public.xml");
            if (publicXml.exists()) {
                forEachPublic(publicXml,(type,name,id)->{
                    if("id".equals(type))declared.add(name);
                });
            }
            for (File xml : FileUtil.walk(resDir, "xml")) {
                String txt = FileUtil.read(xml);
                java.util.regex.Matcher m = java.util.regex.Pattern
                        .compile("@\\+?id/([A-Za-z0-9_.]+)").matcher(txt);
                while (m.find()) used.add(m.group(1));
            }
            used.removeAll(declared);
            if (used.isEmpty()) return 0;
            StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n");
            for (String id : new TreeSet<>(used))
                sb.append("    <item name=\"").append(id).append("\" type=\"id\"/>\n");
            sb.append("</resources>\n");
            FileUtil.write(new File(resDir, "values/apkide_ids.xml"), sb.toString());
            log.i("res-ids: أُضيف " + used.size() + " معرّف ناقص إلى values/apkide_ids.xml");
            return used.size();
        } catch (Exception e) {
            log.w("res-ids: تعذّر فحص المعرّفات: " + e.getMessage());
            return 0;
        }
    }
}
