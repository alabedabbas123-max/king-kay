package com.almlk.editorapkpro.setup;

import android.content.Context;
import android.os.Build;

import com.almlk.editorapkpro.util.Env;

import java.io.File;

/**
 * تهيئة خصائص JVM الناقصة على Android قبل تحميل Apktool.
 * brut.util.OSDetection في Apktool 2.9.3 يستدعي os.name وsun.arch.data.model
 * ثم toLowerCase() بلا فحص null؛ Android لا يضمن وجودهما.
 */
public final class RuntimeBootstrap {
    private static volatile boolean done;
    private RuntimeBootstrap() {}

    public static synchronized void install(Context context) {
        if (done) return;
        String abi = Build.SUPPORTED_ABIS != null && Build.SUPPORTED_ABIS.length > 0
                ? Build.SUPPORTED_ABIS[0] : "arm64-v8a";
        boolean bit64 = abi.contains("64");

        setIfMissing("os.name", "Linux");
        setIfMissing("os.arch", abi.startsWith("arm64") ? "aarch64"
                : abi.startsWith("armeabi") ? "arm" : abi);
        setIfMissing("sun.arch.data.model", bit64 ? "64" : "32");
        setIfMissing("java.vendor", "Android");
        setIfMissing("file.encoding", "UTF-8");
        setIfMissing("line.separator", "\n");

        File files = context.getFilesDir();
        File cache = context.getCacheDir();
        // user.home قد يكون null أيضاً في Android ويستخدمه Config لتحديد framework.
        setIfMissing("user.home", files.getAbsolutePath());
        System.setProperty("java.io.tmpdir", cache.getAbsolutePath());
        System.setProperty("apktool.framework.dir",
                new File(files, "tools/framework").getAbsolutePath());
        done = true;
    }

    private static void setIfMissing(String key, String value) {
        String current = System.getProperty(key);
        if (current == null || current.trim().isEmpty()) System.setProperty(key, value);
    }

    /** فحص صريح يمنع عودة خطأ OSDetection بصمت. */
    public static void verify() {
        require("os.name"); require("sun.arch.data.model"); require("user.home");
    }

    private static void require(String key) {
        if (System.getProperty(key) == null)
            throw new IllegalStateException("خاصية بيئة Java مفقودة: " + key);
    }
}
