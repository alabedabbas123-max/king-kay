package com.almlk.editorapkpro.ui.editor;

import com.almlk.editorapkpro.util.Prefs;

import java.util.LinkedHashMap;
import java.util.Locale;

/** لوحات ألوان محرر احترافية مع إمكانية تخصيص كل عنصر على حدة. */
public final class EditorTheme {
    public static final String BACKGROUND="background";
    public static final String TEXT="text";
    public static final String GUTTER_BACKGROUND="gutter_background";
    public static final String LINE_NUMBER="line_number";
    public static final String CURRENT_LINE="current_line";
    public static final String SELECTION="selection";
    public static final String KEYWORD="keyword";
    public static final String TYPE="type";
    public static final String METHOD="method";
    public static final String STRING="string";
    public static final String COMMENT="comment";
    public static final String NUMBER="number";
    public static final String ANNOTATION="annotation";
    public static final String XML_TAG="xml_tag";
    public static final String RESOURCE="resource";
    public static final String TOOLBAR="toolbar";

    public static final String[] COLOR_KEYS={BACKGROUND,TEXT,GUTTER_BACKGROUND,LINE_NUMBER,
            CURRENT_LINE,SELECTION,KEYWORD,TYPE,METHOD,STRING,COMMENT,NUMBER,ANNOTATION,
            XML_TAG,RESOURCE,TOOLBAR};

    private static final LinkedHashMap<String,EditorTheme> THEMES=new LinkedHashMap<>();
    static {
        // محاكاة لوحة AIDE الكلاسيكية الظاهرة في المرجع: خلفية سوداء وكلمات حمراء
        // وأنواع/دوال سماوية وسلاسل وردية وتعليقات خضراء وأرقام أسطر سماوية.
        add(new EditorTheme("aide","AIDE Classic",
                0xFF000000,0xFFECEFF1,0xFF000000,0xFF19B5E5,0xFF07131A,0xFF224A62,
                0xFFFF5A65,0xFF18B9DD,0xFF4FC3E8,0xFFE78383,0xFF59B963,0xFFE6C36A,
                0xFF35BDE8,0xFFFF5A65,0xFFE6C36A,0xFF212121));
        // نسخة داكنة حديثة لمن يفضّل درجات AIDE/IntelliJ الأقل حدّة.
        add(new EditorTheme("aide_modern","AIDE Modern",
                0xFF101419,0xFFE7E9EC,0xFF0B0E12,0xFF59636E,0xFF171D24,0xFF34526F,
                0xFFCC7832,0xFF4FC3F7,0xFFFFC66D,0xFF6A8759,0xFF808080,0xFF6897BB,
                0xFFBBB529,0xFFE8BF6A,0xFF9876AA,0xFF171C22));
        add(new EditorTheme("midnight","Midnight GitHub",
                0xFF0B0F14,0xFFE6EDF3,0xFF0D1117,0xFF5A6673,0xFF111820,0xFF264F78,
                0xFFFF7B72,0xFF79C0FF,0xFFD2A8FF,0xFFA5D6FF,0xFF8B949E,0xFF79C0FF,
                0xFFD2A8FF,0xFFFF7B72,0xFFFFB86C,0xFF161B22));
        add(new EditorTheme("dracula","Dracula",
                0xFF282A36,0xFFF8F8F2,0xFF21222C,0xFF6272A4,0xFF303341,0xFF44475A,
                0xFFFF79C6,0xFF8BE9FD,0xFF50FA7B,0xFFF1FA8C,0xFF6272A4,0xFFBD93F9,
                0xFFFFB86C,0xFFFF79C6,0xFFFFB86C,0xFF21222C));
        add(new EditorTheme("monokai","Monokai Pro",
                0xFF272822,0xFFF8F8F2,0xFF1F201B,0xFF75715E,0xFF30312B,0xFF49483E,
                0xFFF92672,0xFF66D9EF,0xFFA6E22E,0xFFE6DB74,0xFF75715E,0xFFAE81FF,
                0xFFFD971F,0xFFF92672,0xFFFD971F,0xFF20211C));
        add(new EditorTheme("solarized","Solarized Light",
                0xFFFDF6E3,0xFF586E75,0xFFEEE8D5,0xFF93A1A1,0xFFF5EEDB,0xFFD7E5EA,
                0xFF859900,0xFF268BD2,0xFFB58900,0xFF2AA198,0xFF93A1A1,0xFFD33682,
                0xFFCB4B16,0xFF6C71C4,0xFFDC322F,0xFFEEE8D5));
    }

    public final String id,name;
    public final int background,text,gutterBackground,lineNumber,currentLine,selection;
    public final int keyword,type,method,string,comment,number,annotation,xmlTag,resource,toolbar;

    private EditorTheme(String id,String name,int background,int text,int gutterBackground,
            int lineNumber,int currentLine,int selection,int keyword,int type,int method,
            int string,int comment,int number,int annotation,int xmlTag,int resource,int toolbar){
        this.id=id;this.name=name;this.background=background;this.text=text;
        this.gutterBackground=gutterBackground;this.lineNumber=lineNumber;
        this.currentLine=currentLine;this.selection=selection;this.keyword=keyword;
        this.type=type;this.method=method;this.string=string;this.comment=comment;
        this.number=number;this.annotation=annotation;this.xmlTag=xmlTag;
        this.resource=resource;this.toolbar=toolbar;
    }

    private static void add(EditorTheme t){THEMES.put(t.id,t);}

    public static EditorTheme preset(String id){
        EditorTheme t=THEMES.get(id);
        return t==null?THEMES.get("aide"):t;
    }

    public static String[] ids(){return THEMES.keySet().toArray(new String[0]);}
    public static String[] names(){
        String[] out=new String[THEMES.size()];int i=0;
        for(EditorTheme t:THEMES.values())out[i++]=t.name;
        return out;
    }

    /** النسخة الفعلية: الثيم المختار ثم أي ألوان خصصها المستخدم. */
    public static EditorTheme current(){
        EditorTheme b=preset(Prefs.editorTheme());
        return new EditorTheme(b.id,b.name,
                color(BACKGROUND,b.background),color(TEXT,b.text),
                color(GUTTER_BACKGROUND,b.gutterBackground),color(LINE_NUMBER,b.lineNumber),
                color(CURRENT_LINE,b.currentLine),color(SELECTION,b.selection),
                color(KEYWORD,b.keyword),color(TYPE,b.type),color(METHOD,b.method),
                color(STRING,b.string),color(COMMENT,b.comment),color(NUMBER,b.number),
                color(ANNOTATION,b.annotation),color(XML_TAG,b.xmlTag),
                color(RESOURCE,b.resource),color(TOOLBAR,b.toolbar));
    }

    private static int color(String key,int fallback){return Prefs.editorColor(key,fallback);}

    public int color(String key){
        switch(key){
            case BACKGROUND:return background;case TEXT:return text;
            case GUTTER_BACKGROUND:return gutterBackground;case LINE_NUMBER:return lineNumber;
            case CURRENT_LINE:return currentLine;case SELECTION:return selection;
            case KEYWORD:return keyword;case TYPE:return type;case METHOD:return method;
            case STRING:return string;case COMMENT:return comment;case NUMBER:return number;
            case ANNOTATION:return annotation;case XML_TAG:return xmlTag;
            case RESOURCE:return resource;case TOOLBAR:return toolbar;
            default:return text;
        }
    }

    public static String label(String key){
        switch(key){
            case BACKGROUND:return "خلفية المحرر";case TEXT:return "النص العادي";
            case GUTTER_BACKGROUND:return "خلفية أرقام الأسطر";case LINE_NUMBER:return "أرقام الأسطر";
            case CURRENT_LINE:return "السطر الحالي";case SELECTION:return "التحديد";
            case KEYWORD:return "الكلمات المفتاحية";case TYPE:return "الكلاسات والأنواع";
            case METHOD:return "الدوال والاستدعاءات";case STRING:return "السلاسل النصية";
            case COMMENT:return "التعليقات";case NUMBER:return "الأرقام";
            case ANNOTATION:return "الخصائص وAnnotations";case XML_TAG:return "وسوم XML";
            case RESOURCE:return "مراجع الموارد";case TOOLBAR:return "شريط مفاتيح الأكواد";
            default:return key;
        }
    }

    public static String toHex(int color){return String.format(Locale.US,"#%08X",color);}

    public static Integer parseColor(String text){
        if(text==null)return null;
        String s=text.trim();if(!s.startsWith("#"))s="#"+s;
        try{
            long value=Long.parseLong(s.substring(1),16);
            if(s.length()==7)value|=0xFF000000L;
            else if(s.length()!=9)return null;
            return (int)value;
        }catch(Exception ignored){return null;}
    }
}
