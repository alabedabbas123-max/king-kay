package com.almlk.editorapkpro.tools;

import com.almlk.editorapkpro.util.Env;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

/**
 * تنفيذ أوامر لينكس داخل الجهاز (shell حقيقي عبر /system/bin/sh).
 * يُستخدم للطرفية المدمجة ولتثبيت الأدوات (chmod، tar، unzip، mv …).
 */
public class Shell {

    public interface Output {
        void onLine(String line);
        void onExit(int code);
    }

    private Process process;
    private Writer stdin;
    private volatile boolean running;

    public boolean isRunning() { return running; }

    /** جلسة تفاعلية مستمرة (طرفية). */
    public void startInteractive(File workDir, Output out) throws Exception {
        ProcessBuilder pb = new ProcessBuilder("/system/bin/sh");
        pb.redirectErrorStream(true);
        pb.directory(workDir != null && workDir.exists() ? workDir : Env.rootDir());
        Map<String, String> env = pb.environment();
        env.put("HOME", Env.rootDir().getAbsolutePath());
        env.put("TMPDIR", Env.tmpDir().getAbsolutePath());
        env.put("PATH", Env.toolsDir().getAbsolutePath() + ":"
                + "/system/bin:/system/xbin:/vendor/bin");
        env.put("APKIDE_TOOLS", Env.toolsDir().getAbsolutePath());
        env.put("TERM", "dumb");

        process = pb.start();
        running = true;
        stdin = new OutputStreamWriter(process.getOutputStream());

        Thread reader = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) out.onLine(l);
            } catch (Exception ignored) {
            } finally {
                running = false;
                int code = 0;
                try { code = process.waitFor(); } catch (Exception ignored) {}
                out.onExit(code);
            }
        }, "shell-reader");
        reader.setDaemon(true);
        reader.start();
    }

    public void send(String command) {
        try {
            if (stdin == null) return;
            stdin.write(command);
            stdin.write("\n");
            stdin.flush();
        } catch (Exception ignored) {}
    }

    public void stop() {
        try { send("exit"); } catch (Exception ignored) {}
        try { if (process != null) process.destroy(); } catch (Exception ignored) {}
        running = false;
    }

    /** تنفيذ أمر واحد وانتظار نتيجته. */
    public static int exec(String command, File workDir, Output out) {
        try {
            ProcessBuilder pb = new ProcessBuilder("/system/bin/sh", "-c", command);
            pb.redirectErrorStream(true);
            if (workDir != null && workDir.exists()) pb.directory(workDir);
            Map<String, String> env = pb.environment();
            env.put("PATH", Env.toolsDir().getAbsolutePath()
                    + ":/system/bin:/system/xbin:/vendor/bin");
            env.put("TMPDIR", Env.tmpDir().getAbsolutePath());
            Process p = pb.start();
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(p.getInputStream()))) {
                String l;
                while ((l = r.readLine()) != null) if (out != null) out.onLine(l);
            }
            int code = p.waitFor();
            if (out != null) out.onExit(code);
            return code;
        } catch (Exception e) {
            if (out != null) { out.onLine("خطأ: " + e.getMessage()); out.onExit(-1); }
            return -1;
        }
    }

    /** معلومات بيئة الجهاز المفيدة للتشخيص. */
    public static Map<String, String> environmentInfo() {
        Map<String, String> m = new HashMap<>();
        m.put("ABI", android.os.Build.SUPPORTED_ABIS[0]);
        m.put("SDK", String.valueOf(android.os.Build.VERSION.SDK_INT));
        m.put("Device", android.os.Build.MODEL);
        m.put("Tools", Env.toolsDir().getAbsolutePath());
        m.put("Work", Env.rootDir().getAbsolutePath());
        return m;
    }
}
