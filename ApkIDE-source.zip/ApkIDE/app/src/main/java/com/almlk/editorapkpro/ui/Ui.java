package com.almlk.editorapkpro.ui;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.almlk.editorapkpro.R;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

/** أدوات واجهة مشتركة: حوار تقدّم، تنبيهات، رسائل. */
public final class Ui {

    private static java.lang.ref.WeakReference<Progress> activeProgress=
            new java.lang.ref.WeakReference<>(null);
    private static String workTitle="جارٍ العمل…",workDetail="";
    private static int workPercent=-1;
    private static boolean workVisible=false;

    private Ui() {}

    public static void toast(Context c, String m) {
        Toast.makeText(c, m, Toast.LENGTH_SHORT).show();
    }

    public static void error(Context c, Throwable t) {
        Throwable root=t;
        java.util.HashSet<Throwable> seen=new java.util.HashSet<>();
        while(root!=null&&seen.add(root)){
            Throwable next=root.getCause();
            if(next==null&&root instanceof ExceptionInInitializerError)
                next=((ExceptionInInitializerError)root).getException();
            if(next==null)break;
            root=next;
        }
        boolean oom=false;
        for(Throwable x=t;x!=null;x=x.getCause())if(x instanceof OutOfMemoryError){oom=true;break;}
        String msg;
        if(oom){
            long heap=Runtime.getRuntime().maxMemory()/1024/1024;
            msg="أُوقفت العملية بأمان بسبب ضغط الذاكرة (heap "+heap+"MB). "
                    +"حُذف المشروع الجزئي ومخلفات المرحلة الفاشلة. يستخدم هذا الإصدار "
                    +"تفريغ أيقونات التطبيقات وتقسيم DEX إلى شظايا صغيرة متسلسلة؛ "
                    +"أغلق التطبيقات الثقيلة ثم أعد المحاولة.";
        }else{
            msg=root==null?"خطأ غير معروف":root.getMessage();
            if(msg==null||msg.trim().isEmpty())msg=root.toString();
            else msg=root.getClass().getSimpleName()+": "+msg;
        }
        new MaterialAlertDialogBuilder(c)
                .setTitle("تعذّرت العملية")
                .setMessage(msg)
                .setPositiveButton("حسناً", null)
                .show();
    }

    /**
     * دائرة عمل عائمة فوق شريط الأدوات. لا تحجب الشاشة وتبقى متحركة طوال العملية،
     * حتى يفهم المستخدم أن التطبيق يعمل وليس عالقاً.
     */
    public static final class ActivityBusy {
        private final Activity activity;
        private final LinearLayout pill;
        private final TextView message;

        public ActivityBusy(Activity activity) {
            this.activity=activity;
            pill=new LinearLayout(activity);
            pill.setOrientation(LinearLayout.HORIZONTAL);
            pill.setGravity(Gravity.CENTER_VERTICAL);
            int p=dp(activity,10);
            pill.setPadding(p,dp(activity,6),p,dp(activity,6));
            GradientDrawable bg=new GradientDrawable();
            bg.setColor(0xF2161B22);
            bg.setCornerRadius(dp(activity,24));
            bg.setStroke(dp(activity,1),0xFF2F81F7);
            pill.setBackground(bg);
            pill.setElevation(dp(activity,12));
            pill.setVisibility(View.GONE);
            pill.setClickable(false);
            pill.setFocusable(false);

            ProgressBar circle=new ProgressBar(activity,null,android.R.attr.progressBarStyleSmall);
            circle.setIndeterminate(true);
            circle.setIndeterminateTintList(ColorStateList.valueOf(0xFF00E5A0));
            pill.addView(circle,new LinearLayout.LayoutParams(dp(activity,24),dp(activity,24)));

            message=new TextView(activity);
            message.setTextColor(0xFFF0F3F6);
            message.setTextSize(12);
            message.setSingleLine(true);
            message.setMaxWidth(dp(activity,245));
            LinearLayout.LayoutParams textLp=new LinearLayout.LayoutParams(-2,-2);
            textLp.setMarginStart(dp(activity,8));
            pill.addView(message,textLp);

            ViewGroup decor=(ViewGroup)activity.getWindow().getDecorView();
            FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(-2,-2,
                    Gravity.TOP|Gravity.CENTER_HORIZONTAL);
            lp.topMargin=statusBarHeight(activity)+dp(activity,7);
            decor.addView(pill,lp);
        }

        public void show(String text) {
            activity.runOnUiThread(()->{
                if(activity.isFinishing())return;
                message.setText(text==null||text.isEmpty()?"جارٍ العمل…":text);
                pill.setVisibility(View.VISIBLE);
                pill.bringToFront();
                pill.announceForAccessibility(message.getText());
            });
        }

        public void update(String text){show(text);}

        public void hide(){
            activity.runOnUiThread(()->pill.setVisibility(View.GONE));
        }

        public boolean isShowing(){return pill.getVisibility()==View.VISIBLE;}
    }

    private static int dp(Context c,int n){
        return(int)(n*c.getResources().getDisplayMetrics().density+.5f);
    }
    private static int statusBarHeight(Context c){
        int id=c.getResources().getIdentifier("status_bar_height","dimen","android");
        return id>0?c.getResources().getDimensionPixelSize(id):0;
    }

    /** يعيد نافذة العملية إلى الواجهة عند الضغط على إشعار الخدمة. */
    public static void revealActiveProgress(Activity activity){
        if(!workVisible||activity==null||activity.isFinishing())return;
        Progress p=activeProgress.get();
        if(p!=null&&p.owner==activity){p.show();return;}
        Progress restored=new Progress(activity,workTitle).show();
        restored.applyUpdate(workDetail,workPercent);
    }

    public static class Progress {
        private final Dialog dialog;
        private final Context owner;
        private final TextView step, detail, percentText;
        private final ProgressBar bar;

        public Progress(Context c, String title) {
            owner=c;
            View v = LayoutInflater.from(c).inflate(R.layout.dialog_progress, null);
            step   = v.findViewById(R.id.txtStep);
            detail = v.findViewById(R.id.txtDetail);
            percentText = v.findViewById(R.id.txtPercent);
            bar    = v.findViewById(R.id.bar);
            bar.setMax(100);
            step.setText(title);
            dialog = new MaterialAlertDialogBuilder(c).setView(v).setCancelable(false).create();
        }

        public Progress show() {
            try{if(!dialog.isShowing())dialog.show();}catch(Exception ignored){}
            activeProgress=new java.lang.ref.WeakReference<>(this);
            workTitle=step.getText().toString();workVisible=true;
            return this;
        }

        public void update(String text, int percent) {
            workDetail=text==null?"":text;workPercent=percent;
            applyUpdate(workDetail,workPercent);
            Progress visible=activeProgress.get();
            if(visible!=null&&visible!=this)visible.applyUpdate(workDetail,workPercent);
        }

        private void applyUpdate(String text,int percent){
            detail.setText(text);
            if (percent < 0) {
                bar.setIndeterminate(true);percentText.setText("…");
            } else {
                int value=Math.max(0,Math.min(100,percent));
                bar.setIndeterminate(false);bar.setProgress(value);percentText.setText(value+"%");
            }
        }

        public void title(String t) { step.setText(t);workTitle=t; }
        public void dismiss() {
            workVisible=false;
            Progress visible=activeProgress.get();
            try { dialog.dismiss(); } catch (Exception ignored) {}
            if(visible!=null&&visible!=this){try{visible.dialog.dismiss();}catch(Exception ignored){}}
            activeProgress=new java.lang.ref.WeakReference<>(null);
        }
    }
}
