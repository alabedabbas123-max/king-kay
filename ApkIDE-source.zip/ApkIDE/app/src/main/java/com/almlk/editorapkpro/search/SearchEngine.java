package com.almlk.editorapkpro.search;

import com.almlk.editorapkpro.util.FileUtil;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * البحث والاستبدال في كل ملفات المشروع.
 * يعمل في خيط خلفي، يدعم: حساسية الأحرف، الكلمة الكاملة، التعابير النمطية،
 * تصفية الامتدادات، الاستبدال في نتيجة واحدة أو في الكل مع نسخ احتياطية.
 */
public class SearchEngine {

    /* ------------------------- النماذج ------------------------- */

    public static class Query {
        public String  text = "";
        public String  replacement = "";
        public boolean caseSensitive = false;
        public boolean wholeWord = false;
        public boolean regex = false;
        /** امتدادات مسموحة، فارغة = كل الملفات النصية. */
        public Set<String> extensions = new HashSet<>();
        public int maxResults = 5000;
        public long maxFileSize = 4L * 1024 * 1024;
    }

    public static class Hit {
        public File   file;
        public int    line;        // يبدأ من 1
        public int    start, end;  // إزاحة داخل الملف كاملاً
        public String preview;     // نص السطر
        public int    previewStart, previewEnd; // إزاحة داخل السطر للتظليل
    }

    public static class FileResult {
        public File file;
        public String relativePath;
        public List<Hit> hits = new ArrayList<>();
    }

    public interface Listener {
        void onProgress(int filesScanned, int totalFiles, int hits);
        void onFinished(List<FileResult> results, boolean cancelled);
        void onError(Throwable t);
    }

    /* ------------------------- الحالة ------------------------- */

    private final AtomicBoolean cancelled = new AtomicBoolean(false);

    public void cancel() { cancelled.set(true); }
    public boolean isCancelled() { return cancelled.get(); }

    /* ------------------------- البحث ------------------------- */

    public List<FileResult> search(File root, Query q, Listener l) {
        cancelled.set(false);
        List<FileResult> out = new ArrayList<>();
        if (q.text == null || q.text.isEmpty()) return out;

        Pattern pattern = buildPattern(q);
        List<File> files = collect(root, q);
        int total = files.size(), scanned = 0, hitCount = 0;

        for (File f : files) {
            if (cancelled.get()) break;
            scanned++;
            try {
                if (f.length() > q.maxFileSize) continue;
                String content = new String(FileUtil.readBytes(f), StandardCharsets.UTF_8);
                Matcher m = pattern.matcher(content);
                FileResult fr = null;
                while (m.find()) {
                    if (hitCount >= q.maxResults) break;
                    if (fr == null) {
                        fr = new FileResult();
                        fr.file = f;
                        fr.relativePath = relative(root, f);
                    }
                    fr.hits.add(makeHit(f, content, m.start(), m.end()));
                    hitCount++;
                }
                if (fr != null) out.add(fr);
            } catch (Throwable ignored) {}
            if (l != null && (scanned % 20 == 0 || scanned == total))
                l.onProgress(scanned, total, hitCount);
            if (hitCount >= q.maxResults) break;
        }
        if (l != null) l.onFinished(out, cancelled.get());
        return out;
    }

    /* ------------------------- الاستبدال ------------------------- */

    /** استبدال كل النتائج في كل الملفات. يعيد عدد الاستبدالات. */
    public int replaceAll(File root, Query q, List<FileResult> results, boolean backup) throws Exception {
        Pattern pattern = buildPattern(q);
        String rep = q.regex ? q.replacement : Matcher.quoteReplacement(q.replacement);
        int n = 0;
        for (FileResult fr : results) {
            if (cancelled.get()) break;
            String content = new String(FileUtil.readBytes(fr.file), StandardCharsets.UTF_8);
            Matcher m = pattern.matcher(content);
            StringBuffer sb = new StringBuffer();
            int c = 0;
            while (m.find()) { m.appendReplacement(sb, rep); c++; }
            m.appendTail(sb);
            if (c > 0) {
                if (backup) writeBackup(fr.file, content);
                FileUtil.write(fr.file, sb.toString());
                n += c;
            }
        }
        return n;
    }

    /** استبدال نتيجة واحدة فقط. */
    public boolean replaceOne(Hit hit, Query q, boolean backup) throws Exception {
        String content = new String(FileUtil.readBytes(hit.file), StandardCharsets.UTF_8);
        if (hit.end > content.length()) return false;
        String rep = q.regex
                ? Pattern.compile(pat(q)).matcher(content.substring(hit.start, hit.end))
                        .replaceFirst(q.replacement)
                : q.replacement;
        if (backup) writeBackup(hit.file, content);
        String result = content.substring(0, hit.start) + rep + content.substring(hit.end);
        FileUtil.write(hit.file, result);
        return true;
    }

    private void writeBackup(File f, String original) throws Exception {
        File bak = new File(f.getParentFile(), f.getName() + ".bak");
        if (!bak.exists()) FileUtil.write(bak, original);
    }

    /* ------------------------- أدوات ------------------------- */

    private String pat(Query q) {
        String p = q.regex ? q.text : Pattern.quote(q.text);
        if (q.wholeWord && !q.regex) p = "\\b" + p + "\\b";
        return p;
    }

    private Pattern buildPattern(Query q) {
        int flags = Pattern.MULTILINE;
        if (!q.caseSensitive) flags |= Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE;
        return Pattern.compile(pat(q), flags);
    }

    private Hit makeHit(File f, String content, int start, int end) {
        Hit h = new Hit();
        h.file = f;
        h.start = start;
        h.end = end;
        int ls = content.lastIndexOf('\n', Math.max(0, start - 1)) + 1;
        int le = content.indexOf('\n', end);
        if (le < 0) le = content.length();
        h.line = countLines(content, start);
        String raw = content.substring(ls, le);
        // قص الأسطر الطويلة حول المطابقة
        int relStart = start - ls, relEnd = end - ls;
        if (raw.length() > 200) {
            int from = Math.max(0, relStart - 60);
            int to = Math.min(raw.length(), relEnd + 100);
            raw = (from > 0 ? "…" : "") + raw.substring(from, to) + (to < raw.length() ? "…" : "");
            int shift = from - (from > 0 ? 1 : 0);
            relStart -= shift; relEnd -= shift;
        }
        h.preview = raw.trim().isEmpty() ? raw : raw;
        int lead = raw.length() - raw.replaceAll("^\\s+", "").length();
        h.preview = raw.substring(Math.min(lead, raw.length()));
        h.previewStart = Math.max(0, relStart - lead);
        h.previewEnd   = Math.max(h.previewStart, relEnd - lead);
        return h;
    }

    private int countLines(String s, int offset) {
        int n = 1;
        for (int i = 0; i < offset && i < s.length(); i++) if (s.charAt(i) == '\n') n++;
        return n;
    }

    private static final Set<String> SKIP_DIRS = new HashSet<>(Arrays.asList(
            "build", ".gradle", ".idea", ".git", "node_modules", ".apkide"));

    private List<File> collect(File root, Query q) {
        List<File> out = new ArrayList<>();
        java.util.Deque<File> stack = new java.util.ArrayDeque<>();
        stack.push(root);
        while (!stack.isEmpty()) {
            File f = stack.pop();
            if (f.isDirectory()) {
                if (SKIP_DIRS.contains(f.getName())) continue;
                File[] kids = f.listFiles();
                if (kids != null) for (File k : kids) stack.push(k);
            } else {
                String ext = FileUtil.ext(f.getName());
                if (!q.extensions.isEmpty()) {
                    if (!q.extensions.contains(ext)) continue;
                } else if (!FileUtil.TEXT_EXT.contains(ext)) continue;
                out.add(f);
            }
        }
        out.sort((a, b) -> a.getAbsolutePath().compareToIgnoreCase(b.getAbsolutePath()));
        return out;
    }

    public static String relative(File root, File f) {
        String r = root.getAbsolutePath(), a = f.getAbsolutePath();
        return a.startsWith(r) && a.length() > r.length() ? a.substring(r.length() + 1) : a;
    }

    /** مجموعات امتدادات جاهزة لواجهة التصفية. */
    public static Set<String> presetExtensions(String preset) {
        switch (preset.toLowerCase(Locale.ROOT)) {
            case "java":  return new HashSet<>(Arrays.asList("java"));
            case "kotlin":return new HashSet<>(Arrays.asList("kt", "kts"));
            case "xml":   return new HashSet<>(Arrays.asList("xml"));
            case "smali": return new HashSet<>(Arrays.asList("smali"));
            case "code":  return new HashSet<>(Arrays.asList("java","kt","kts","xml","smali","gradle"));
            default:      return new HashSet<>();
        }
    }
}
