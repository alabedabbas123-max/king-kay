package com.almlk.editorapkpro.tools;

import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

import com.almlk.editorapkpro.ApkIdeApp;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.NativeTools;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * مثبّت أدوات موثوق يعمل دون curl/wget:
 * - INTERNET وACCESS_NETWORK_STATE وفحص اتصال/DNS/HTTPS.
 * - تنزيل streaming إلى .part (لا يحمل 60MB في RAM) مع redirects واستئناف ومحاولات.
 * - عدة مرايا لكل أداة، تحقق الحجم وSHA-256 وبنية JAR/ELF.
 * - استخراج مدخل محدد من ZIP، استبدال ذري، ثم chmod عبر /system/bin/sh.
 */
public class ToolInstaller {

    public static class Tool {
        public String id, title, description, target;
        /** أول رابط يُعرض في الواجهة، urls تشمل المرايا بالترتيب. */
        public String url;
        public String[] urls;
        public boolean executable;
        public String archiveEntry;
        public long minBytes;
        public String sha256;

        public Tool(String id,String title,String desc,String url,String target,boolean exec){
            this.id=id;this.title=title;this.description=desc;this.url=url;this.target=target;
            this.executable=exec;this.urls=url==null||url.isEmpty()?new String[0]:new String[]{url};
        }
        public Tool mirrors(String... v){urls=v;url=v.length==0?"":v[0];return this;}
        public Tool min(long n){minBytes=n;return this;}
        public Tool sha(String s){sha256=s;return this;}
        public Tool entry(String s){archiveEntry=s;return this;}
    }

    public interface Progress { void step(String msg,int percent); }
    private final Logger log;
    public ToolInstaller(Logger log){this.log=log;}

    /* ----------------------------- الكتالوج ----------------------------- */

    public static List<Tool> catalog(){
        List<Tool> t=new ArrayList<>();String abi=Build.SUPPORTED_ABIS[0];
        String aaptUrl="https://github.com/ReVanced/aapt2/releases/download/v1.1.0/aapt2-"+abi;
        t.add(new Tool("aapt2","aapt2 ("+abi+")","مترجم الموارد؛ نسخة ARM64 مدمجة أصلاً",
                aaptUrl,"aapt2",true).min(1024*1024));
        t.add(new Tool("zipalign","zipalign","اختياري؛ يوجد محاذٍ Java داخلي دائم",
                "","zipalign",true).min(100*1024));
        t.add(new Tool("r8","r8.jar (D8)","تحويل .class إلى DEX للبناء من المصدر",
                "https://dl.google.com/dl/android/maven2/com/android/tools/r8/8.5.35/r8-8.5.35.jar",
                "r8.jar",false).min(5L*1024*1024));
        t.add(new Tool("apktool_framework","Android framework لـ Apktool","الإطار 1.apk اللازم لفك الموارد؛ يُنزّل بدلاً من زيادة APK بنحو 4MB",
                "https://raw.githubusercontent.com/iBotPeaches/Apktool/v2.9.3/brut.apktool/apktool-lib/src/main/resources/brut/androlib/android-framework.jar",
                "framework/1.apk",false).min(3L*1024*1024)
                .sha("6dffc77137c7d3f8946a1e2931ed3ecdd2ab0b7d9fce263feacece50e313a779"));
        t.add(new Tool("android_jar","android.jar (API 34)","واجهات Android اللازمة لتصريف Java؛ تُنزّل عند أول تشغيل بدلاً من تضخيم APK",
                "https://raw.githubusercontent.com/Sable/android-platforms/master/android-34/android.jar",
                "android.jar",false)
                .mirrors("https://raw.githubusercontent.com/Sable/android-platforms/master/android-34/android.jar",
                        "https://dl.google.com/android/repository/platform-34-ext7_r03.zip")
                .entry("android-14/android.jar").min(20L*1024*1024)
                .sha("6cea1df3efb77103ac3e2beb9bf4718964b0e0869ab16d39d29d5cbae1c147ad"));
        t.add(new Tool("apktool","apktool-lib.jar (نسخة طرفية احتياطية)","المحرك الأساسي مدمج؛ هذا الملف لاستخدام الطرفية",
                "https://repo1.maven.org/maven2/org/apktool/apktool-lib/2.9.3/apktool-lib-2.9.3.jar",
                "apktool-lib.jar",false).min(1024*1024));
        return t;
    }

    public static Tool byId(String id){for(Tool t:catalog())if(t.id.equals(id))return t;return null;}

    /* ----------------------------- التثبيت ----------------------------- */

    public File install(Tool tool,String overrideUrl,Progress progress)throws Exception{
        if(tool==null)throw new IllegalArgumentException("الأداة غير معروفة");
        String[] candidates=(overrideUrl!=null&&!overrideUrl.trim().isEmpty())
                ?new String[]{overrideUrl.trim()}:tool.urls;
        if(candidates==null||candidates.length==0)
            throw new IllegalStateException("هذه الأداة مدمجة أو لها بديل داخلي ولا تحتاج تنزيلاً. استخدم «رابط آخر» إن أردت استبدالها.");

        Context context=ApkIdeApp.get();
        String net=networkProblem(context);
        if(net!=null)throw new IllegalStateException(net);

        File part=new File(Env.tmpDir(),tool.id+".download.part");
        Exception last=null;String used=null;
        for(int mirror=0;mirror<candidates.length;mirror++){
            String u=candidates[mirror];
            for(int attempt=1;attempt<=3;attempt++){
                try{
                    if(progress!=null)progress.step("اتصال بالمصدر "+(mirror+1)+"/"+candidates.length+" — محاولة "+attempt+"/3",-1);
                    downloadTo(u,part,progress);
                    used=u;last=null;break;
                }catch(Exception e){
                    last=e;log.w("download: "+u+" — "+e.getMessage());
                    if(attempt<3)try{Thread.sleep(700L*attempt);}catch(InterruptedException x){Thread.currentThread().interrupt();throw x;}
                }
            }
            if(last==null)break;
            // لا تستأنف ملفاً من مرآة مختلفة.
            FileUtil.delete(part);
        }
        if(last!=null)throw new IllegalStateException("فشل تنزيل "+tool.title+" من كل المصادر. آخر خطأ: "+last.getMessage(),last);

        File prepared=part;
        boolean zip=used.toLowerCase(Locale.ROOT).contains(".zip");
        if(zip&&tool.archiveEntry!=null){
            if(progress!=null)progress.step("استخراج "+tool.archiveEntry+"…",88);
            File extracted=new File(Env.tmpDir(),tool.id+".extracted.tmp");
            extractEntry(part,tool.archiveEntry,extracted);prepared=extracted;
        }
        validate(tool,prepared);

        File dst=new File(Env.toolsDir(),tool.target);
        File staged=new File(Env.toolsDir(),tool.target+".new");
        FileUtil.delete(staged);copy(prepared,staged);validate(tool,staged);
        if(tool.executable){
            if(progress!=null)progress.step("Linux: chmod 755 والتحقق من التنفيذ…",94);
            chmodExec(staged);
        }
        atomicReplace(staged,dst);
        FileUtil.delete(part);if(prepared!=part)FileUtil.delete(prepared);

        // تحقق عبر shell نفسه الذي سيستخدم الأداة.
        int shellCode=Shell.exec("test -s "+quote(dst.getAbsolutePath()),Env.toolsDir(),new Shell.Output(){
            @Override public void onLine(String line){log.i("linux: "+line);}
            @Override public void onExit(int code){log.i("linux: verify exit="+code);}
        });
        if(shellCode!=0)throw new IllegalStateException("ثُبّت الملف لكن فشل فحص Linux له: "+dst);
        log.i("tool: installed "+dst+" size="+FileUtil.humanSize(dst.length())+" source="+used);
        if(progress!=null)progress.step("تم التثبيت والتحقق",100);
        return dst;
    }

    public File installLocal(Tool tool,File src)throws Exception{
        validate(tool,src);File dst=new File(Env.toolsDir(),tool.target),tmp=new File(Env.toolsDir(),tool.target+".new");
        FileUtil.delete(tmp);copy(src,tmp);if(tool.executable)chmodExec(tmp);
        atomicReplace(tmp,dst);validate(tool,dst);return dst;
    }

    /* ----------------------------- الشبكة ----------------------------- */

    /** null = الاتصال متاح، وإلا رسالة تشخيص عربية. INTERNET صلاحية عادية لا تطلب وقت التشغيل. */
    public static String networkProblem(Context c){
        if(c==null)return "تعذّر الوصول إلى Context التطبيق";
        if(c.checkCallingOrSelfPermission(android.Manifest.permission.INTERNET)!=PackageManager.PERMISSION_GRANTED)
            return "صلاحية INTERNET غير موجودة في AndroidManifest";
        try{
            ConnectivityManager cm=(ConnectivityManager)c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if(cm!=null){
                boolean connected;
                if(Build.VERSION.SDK_INT>=23){
                    android.net.Network n=cm.getActiveNetwork();NetworkCapabilities cap=n==null?null:cm.getNetworkCapabilities(n);
                    connected=cap!=null&&cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
                }else{
                    NetworkInfo i=cm.getActiveNetworkInfo();connected=i!=null&&i.isConnected();
                }
                if(!connected)return "لا يوجد اتصال إنترنت نشط. فعّل Wi‑Fi أو بيانات الهاتف ثم أعد المحاولة.";
            }
            InetAddress.getByName("dl.google.com");
            return null;
        }catch(SecurityException e){return "صلاحية ACCESS_NETWORK_STATE غير متاحة: "+e.getMessage();}
        catch(Exception e){return "فشل DNS/الشبكة: "+e.getMessage();}
    }

    /** فحص HTTPS حقيقي يُستخدم من زر التشخيص. */
    public String diagnoseNetwork(Context c){
        String p=networkProblem(c);if(p!=null)return p;
        HttpURLConnection con=null;
        try{
            con=openFollowingRedirects("https://dl.google.com/android/repository/repository2-1.xml",0,8);
            int code=con.getResponseCode();return code>=200&&code<300
                    ?"الإنترنت وDNS وHTTPS تعمل — HTTP "+code
                    :"وصل الإنترنت لكن الخادم أعاد HTTP "+code;
        }catch(Exception e){return "فشل HTTPS: "+e.getClass().getSimpleName()+": "+e.getMessage();}
        finally{if(con!=null)con.disconnect();}
    }

    /* ----------------------------- التنزيل ----------------------------- */

    private void downloadTo(String address,File part,Progress pr)throws Exception{
        long existing=part.exists()?part.length():0;
        HttpURLConnection con=openFollowingRedirects(address,existing,8);
        int code=con.getResponseCode();
        // إذا كان .part مكتملاً من محاولة سابقة فقد يجيب الخادم 416؛ التحقق اللاحق يحسم صلاحيته.
        if(code==416&&existing>0){con.disconnect();return;}
        if(code!=200&&code!=206)throw new java.io.IOException("HTTP "+code+" "+con.getResponseMessage());
        boolean append=code==206&&existing>0;
        if(!append)existing=0;
        long body=con.getContentLengthLong();long expected=body>0?existing+body:-1;
        File parent=part.getParentFile();if(parent!=null)parent.mkdirs();
        try(InputStream in=new BufferedInputStream(con.getInputStream(),64*1024);
            OutputStream out=new BufferedOutputStream(new FileOutputStream(part,append),64*1024)){
            byte[] buf=new byte[64*1024];int n;long total=existing,lastUpdate=0;
            while((n=in.read(buf))!=-1){
                out.write(buf,0,n);total+=n;
                if(pr!=null&&(total-lastUpdate>512*1024||total==expected)){
                    int pct=expected>0?(int)Math.min(85,total*85/expected):-1;
                    pr.step("تنزيل "+FileUtil.humanSize(total)+(expected>0?" / "+FileUtil.humanSize(expected):""),pct);lastUpdate=total;
                }
            }
        }finally{con.disconnect();}
        if(expected>0&&part.length()!=expected)throw new java.io.IOException("تنزيل ناقص: "+part.length()+" / "+expected);
    }

    private static HttpURLConnection openFollowingRedirects(String address,long range,int maxRedirects)throws Exception{
        URL url=new URL(address);
        for(int i=0;;i++){
            HttpURLConnection c=(HttpURLConnection)url.openConnection();c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);c.setReadTimeout(120000);c.setUseCaches(false);
            c.setRequestProperty("User-Agent","EditorApkPro/1.2 (Android "+Build.VERSION.SDK_INT+")");
            c.setRequestProperty("Accept","*/*");c.setRequestProperty("Accept-Encoding","identity");
            if(range>0)c.setRequestProperty("Range","bytes="+range+"-");
            int code=c.getResponseCode();
            if(code==301||code==302||code==303||code==307||code==308){
                if(i>=maxRedirects){c.disconnect();throw new java.io.IOException("redirects كثيرة");}
                String loc=c.getHeaderField("Location");if(loc==null){c.disconnect();throw new java.io.IOException("redirect بلا Location");}
                url=new URL(url,loc);c.disconnect();continue;
            }
            return c;
        }
    }

    /* ----------------------------- التحقق ----------------------------- */

    private void validate(Tool t,File f)throws Exception{
        if(!f.exists()||f.length()<Math.max(1,t.minBytes))throw new java.io.IOException("الملف أصغر من المتوقع: "+FileUtil.humanSize(f.length()));
        if(t.sha256!=null&&!t.sha256.isEmpty()){
            String actual=sha256(f);if(!t.sha256.equalsIgnoreCase(actual))
                throw new SecurityException("SHA-256 غير مطابق. المتوقع "+t.sha256+" الفعلي "+actual);
        }
        if(t.executable){
            try(InputStream in=new FileInputStream(f)){
                byte[] h=new byte[4];if(in.read(h)!=4||h[0]!=0x7f||h[1]!='E'||h[2]!='L'||h[3]!='F')
                    throw new java.io.IOException("الملف ليس ELF صالحاً");
            }
        }else if(t.target.endsWith(".jar")||t.target.endsWith(".apk")){
            try(ZipFile z=new ZipFile(f)){
                if(z.size()==0)throw new java.io.IOException("الأرشيف فارغ");
                if("android_jar".equals(t.id)&&z.getEntry("android/app/Activity.class")==null)
                    throw new java.io.IOException("ليس android.jar صالحاً");
                if("r8".equals(t.id)&&z.getEntry("com/android/tools/r8/D8.class")==null)
                    throw new java.io.IOException("لا يحتوي D8");
                if("apktool_framework".equals(t.id)
                        &&(z.getEntry("resources.arsc")==null||z.getEntry("AndroidManifest.xml")==null))
                    throw new java.io.IOException("ليس إطار Android صالحاً لـ Apktool");
            }
        }
    }

    private static void extractEntry(File zip,String wanted,File out)throws Exception{
        try(ZipFile z=new ZipFile(zip)){
            ZipEntry e=z.getEntry(wanted);
            if(e==null){
                // بعض المنصات تغيّر اسم المجلد؛ طابق النهاية.
                java.util.Enumeration<? extends ZipEntry> all=z.entries();
                while(all.hasMoreElements()){ZipEntry x=all.nextElement();if(x.getName().endsWith("/android.jar")){e=x;break;}}
            }
            if(e==null)throw new java.io.IOException("لم يُعثر على "+wanted+" داخل ZIP");
            try(InputStream in=z.getInputStream(e);OutputStream o=new BufferedOutputStream(new FileOutputStream(out))){byte[]b=new byte[64*1024];int n;while((n=in.read(b))!=-1)o.write(b,0,n);}
        }
    }
    private static void atomicReplace(File staged,File dst)throws Exception{
        try{
            java.nio.file.Files.move(staged.toPath(),dst.toPath(),
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
        }catch(Exception atomicUnsupported){
            // filesDir عادة على filesystem واحد، لكن احتفظ بمسار آمن للأجهزة القديمة/الغريبة.
            File backup=new File(dst.getParentFile(),dst.getName()+".old");FileUtil.delete(backup);
            if(dst.exists()&&!dst.renameTo(backup))throw new java.io.IOException("تعذّر استبدال "+dst,atomicUnsupported);
            if(!staged.renameTo(dst)){
                try{copy(staged,dst);FileUtil.delete(staged);}catch(Exception e){FileUtil.delete(dst);backup.renameTo(dst);throw e;}
            }
            FileUtil.delete(backup);
        }
    }
    private static String sha256(File f)throws Exception{MessageDigest d=MessageDigest.getInstance("SHA-256");try(InputStream in=new FileInputStream(f)){byte[]b=new byte[64*1024];int n;while((n=in.read(b))!=-1)d.update(b,0,n);}StringBuilder s=new StringBuilder();for(byte x:d.digest())s.append(String.format(Locale.US,"%02x",x));return s.toString();}
    private static void copy(File a,File b)throws Exception{File p=b.getParentFile();if(p!=null)p.mkdirs();try(InputStream in=new FileInputStream(a);OutputStream out=new BufferedOutputStream(new FileOutputStream(b))){byte[]x=new byte[64*1024];int n;while((n=in.read(x))!=-1)out.write(x,0,n);}}

    public boolean chmodExec(File f){
        f.setReadable(true,false);f.setExecutable(true,false);
        int code=Shell.exec("chmod 755 "+quote(f.getAbsolutePath()),Env.toolsDir(),new Shell.Output(){@Override public void onLine(String x){log.i("linux: "+x);}@Override public void onExit(int c){log.i("linux: chmod exit="+c);}});
        return code==0&&f.canExecute();
    }
    public boolean isInstalled(Tool t){
        if("r8".equals(t.id)&&com.almlk.editorapkpro.compiler.D8Bridge.available())return true;
        if("apktool".equals(t.id)){try{Class.forName("brut.androlib.ApkDecoder");return true;}catch(Throwable ignored){}}
        if(("aapt2".equals(t.id)||"zipalign".equals(t.id))&&ApkIdeApp.get()!=null){
            if(NativeTools.isAvailable(ApkIdeApp.get(),t.id))return true;
            if("zipalign".equals(t.id))return true; // JavaZipAligner
        }
        File f=new File(Env.toolsDir(),t.target);
        try{validate(t,f);return true;}catch(Exception invalid){return false;}
    }
    public String status(Tool t){
        if("zipalign".equals(t.id)&&ApkIdeApp.get()!=null&&NativeTools.tool(ApkIdeApp.get(),t.id)==null)return "جاهزة — بديل Java داخلي";
        if(("r8".equals(t.id)||"apktool".equals(t.id))&&isInstalled(t))return "مدمجة وجاهزة";
        if(("aapt2".equals(t.id)||"zipalign".equals(t.id))&&ApkIdeApp.get()!=null){File n=NativeTools.tool(ApkIdeApp.get(),t.id);if(n!=null)return "مدمجة وجاهزة ("+FileUtil.humanSize(n.length())+")";}
        File f=new File(Env.toolsDir(),t.target);
        if(f.exists())return isInstalled(t)?"مثبّتة ومتحقق منها ("+FileUtil.humanSize(f.length())+")":"ملف موجود لكنه تالف/غير مطابق — أعد التثبيت";
        return "غير مثبّتة — اضغط للتنزيل";
    }
    public void remove(Tool t){FileUtil.delete(new File(Env.toolsDir(),t.target));}
    private static String quote(String s){return "\""+s.replace("\"","\\\"")+"\"";}
}
