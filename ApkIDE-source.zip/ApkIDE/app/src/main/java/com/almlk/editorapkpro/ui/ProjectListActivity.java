package com.almlk.editorapkpro.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.almlk.editorapkpro.ui.adapter.ProjectAdapter;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.List;

public class ProjectListActivity extends AppCompatActivity {

    private ProjectAdapter adapter;
    private TextView empty;

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_project_list);
        MaterialToolbar tb = findViewById(R.id.toolbar);
        tb.setNavigationOnClickListener(v -> finish());
        empty = findViewById(R.id.txtEmpty);

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProjectAdapter(new ProjectAdapter.Listener() {
            @Override public void onOpen(Project p) {
                startActivity(new Intent(ProjectListActivity.this, ProjectActivity.class)
                        .putExtra("dir", p.dir));
            }
            @Override public void onLong(Project p) { confirmDelete(p); }
        });
        list.setAdapter(adapter);
    }

    @Override protected void onResume() {
        super.onResume();
        List<Project> all = ProjectManager.all();
        adapter.submit(all);
        empty.setVisibility(all.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void confirmDelete(Project p) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("حذف المشروع")
                .setMessage("سيُحذف " + p.name + " نهائياً.")
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton("حذف", (d, w) -> {
                    ProjectManager.delete(p);
                    adapter.submit(ProjectManager.all());
                }).show();
    }
}
