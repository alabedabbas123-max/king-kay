package com.almlk.editorapkpro.ui;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.engine.Engine;
import com.almlk.editorapkpro.engine.EngineService;
import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.TaskCallback;
import com.almlk.editorapkpro.compiler.Rebuilder;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.project.ProjectManager;
import com.almlk.editorapkpro.project.BuildArtifactCleaner;
import com.almlk.editorapkpro.ui.adapter.FileTreeAdapter;
import com.almlk.editorapkpro.ui.adapter.ProblemAdapter;
import com.almlk.editorapkpro.problems.Problem;
import com.almlk.editorapkpro.problems.ProblemParser;
import com.almlk.editorapkpro.ui.complete.ProjectIndex;
import com.almlk.editorapkpro.ui.editor.EditorTheme;
import com.almlk.editorapkpro.ui.editor.EditorToolConfig;
import com.almlk.editorapkpro.ui.view.CodeEditorView;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.viewer.AssetViewerActivity;
import com.almlk.editorapkpro.viewer.LayoutPreviewActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.tabs.TabLayout;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** شاشة المشروع: شجرة ملفات + تبويبات + محرر كود + أوامر البناء. */
public class ProjectActivity extends AppCompatActivity {

    private Project project;
    private DrawerLayout drawer;
    private TabLayout tabs;
    private FrameLayout host;
    private MaterialToolbar toolbar;
    private View editorTools;
    private android.widget.LinearLayout editorToolsRow;
    private final Map<String,View> editorToolViews=new LinkedHashMap<>();
    private TextView status;
    private final Runnable restorePathTask=this::updatePathBar;
    private ProgressBar busy;
    private Ui.ActivityBusy topBusy;
    private FileTreeAdapter tree;
    private TextView treeTitle;
    private EditText fileSearch;
    private View problemsPanel;
    private TextView problemCount;
    private ProblemAdapter problemAdapter;
    private final List<Problem> problems = new ArrayList<>();
    private final Set<String> dirty = new HashSet<>();
    private Logger currentBuildLog;
    private Logger.Sink buildSink;
    private static final int REQ_SEARCH = 501;

    private final Map<String, CodeEditorView> open = new LinkedHashMap<>();
    private final List<File> openFiles = new ArrayList<>();
    private File active;
    /** المجلد الذي يُنشأ فيه الملف/المجلد الجديد (آخر مجلد لمسه المستخدم). */
    private File currentDir;
    /** فهرس رموز المشروع لتغذية الإكمال التلقائي. */
    private final ProjectIndex index = new ProjectIndex();

    @Override protected void onCreate(@Nullable Bundle s) {
        super.onCreate(s);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                |android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        setContentView(R.layout.activity_project);

        String dir = getIntent().getStringExtra("dir");
        project = ProjectManager.load(new File(dir));
        if (project == null) { Ui.toast(this, "تعذّر فتح المشروع"); finish(); return; }

        drawer = findViewById(R.id.drawer);
        tabs   = findViewById(R.id.tabs);
        host   = findViewById(R.id.editorHost);
        editorTools = findViewById(R.id.editorTools);
        editorToolsRow = findViewById(R.id.editorToolsRow);
        status = findViewById(R.id.txtStatus);
        busy   = findViewById(R.id.busy);
        topBusy = new Ui.ActivityBusy(this);
        problemsPanel = findViewById(R.id.problemsPanel);
        problemCount = findViewById(R.id.txtProblemCount);
        RecyclerView problemList = findViewById(R.id.problemsList);
        problemList.setLayoutManager(new LinearLayoutManager(this));
        problemAdapter = new ProblemAdapter(this::openProblem);
        problemList.setAdapter(problemAdapter);
        findViewById(R.id.btnCloseProblems).setOnClickListener(v -> hideProblems());
        findViewById(R.id.btnClearProblems).setOnClickListener(v -> {
            problems.clear(); problemAdapter.set(problems); updateProblemCount();
        });

        toolbar = findViewById(R.id.toolbar);
        // اسم مجلد المشروع ظاهر دائماً كما في واجهات IDE، والاسم التطبيقي تحته.
        toolbar.setTitle(project.name);
        toolbar.setSubtitle(projectTitleDetail(null));
        // مستعرض الملفات ثابت في الجهة اليسرى حتى مع الواجهة العربية RTL.
        toolbar.setNavigationOnClickListener(v -> drawer.openDrawer(android.view.Gravity.LEFT));
        toolbar.inflateMenu(R.menu.menu_project);
        toolbar.setOnMenuItemClickListener(this::onMenu);
        updateContextActions(null);

        // زر حفظ دائم في شريط الحالة، إضافة إلى زر الحفظ داخل شريط لوحة المفاتيح.
        findViewById(R.id.btnStatusSave).setOnClickListener(v->saveActive());
        findViewById(R.id.btnEditSave).setOnClickListener(v->saveActive());
        findViewById(R.id.btnEditUndo).setOnClickListener(v->{CodeEditorView e=activeEditor();if(e!=null)e.undo();});
        findViewById(R.id.btnEditRedo).setOnClickListener(v->{CodeEditorView e=activeEditor();if(e!=null)e.redo();});
        findViewById(R.id.btnEditSelect).setOnClickListener(v->{CodeEditorView e=activeEditor();if(e!=null)e.selectTokenAtCursor();});
        findViewById(R.id.btnEditDelete).setOnClickListener(v->{CodeEditorView e=activeEditor();if(e!=null)e.deleteSelectionOrPrevious();});
        findViewById(R.id.btnEditComplete).setOnClickListener(v->{CodeEditorView e=activeEditor();if(e!=null)e.triggerCompletion();});
        findViewById(R.id.btnEditTab).setOnClickListener(v->{
            CodeEditorView e=activeEditor();if(e!=null)e.insertAtCursor(spaces(com.almlk.editorapkpro.util.Prefs.editorTabSpaces()));
        });
        findViewById(R.id.btnEditHide).setOnClickListener(v->{CodeEditorView e=activeEditor();if(e!=null)e.hideKeyboard();});
        bindCodeKey(R.id.btnCodeLt,"<");bindCodeKey(R.id.btnCodeGt,">");
        bindCodeKey(R.id.btnCodeSlash,"/");bindCodeKey(R.id.btnCodeEquals,"=");
        bindCodeKey(R.id.btnCodeQuote,"\"");bindCodeKey(R.id.btnCodeApostrophe,"'");
        bindCodeKey(R.id.btnCodeColon,":");bindCodeKey(R.id.btnCodeSemicolon,";");
        bindCodeKey(R.id.btnCodeAt,"@");bindCodeKey(R.id.btnCodePlus,"+");
        bindCodeKey(R.id.btnCodeMinus,"-");bindCodeKey(R.id.btnCodeOpenParen,"(");
        bindCodeKey(R.id.btnCodeCloseParen,")");bindCodeKey(R.id.btnCodeOpenBrace,"{");
        bindCodeKey(R.id.btnCodeCloseBrace,"}");bindCodeKey(R.id.btnCodeOpenBracket,"[");
        bindCodeKey(R.id.btnCodeCloseBracket,"]");
        cacheEditorToolViews();
        applyEditorPreferences();

        // WindowInsets هو المسار الأساسي، وقياس النافذة احتياط للهواتف القديمة.
        ViewCompat.setOnApplyWindowInsetsListener(drawer,(v,insets)->{
            boolean ime=insets.isVisible(WindowInsetsCompat.Type.ime());
            updateEditorToolsVisibility(ime);
            if(ime){CodeEditorView editor=active==null?null:open.get(active.getAbsolutePath());
                if(editor!=null)editor.postDelayed(editor::ensureCursorVisible,90);}
            return insets;
        });
        drawer.getViewTreeObserver().addOnGlobalLayoutListener(()->{
            Rect visible=new Rect();drawer.getWindowVisibleDisplayFrame(visible);
            int hidden=drawer.getRootView().getHeight()-visible.bottom;
            boolean keyboard=hidden>drawer.getRootView().getHeight()/6;
            updateEditorToolsVisibility(keyboard);
        });
        ViewCompat.requestApplyInsets(drawer);

        treeTitle = findViewById(R.id.txtTreeTitle);
        fileSearch = findViewById(R.id.edtFileSearch);
        currentDir = project.mainDir().exists() ? project.mainDir() : project.root();
        RecyclerView rv = findViewById(R.id.tree);
        rv.setLayoutManager(new LinearLayoutManager(this));
        tree = new FileTreeAdapter(new FileTreeAdapter.Listener() {
            @Override public void onFile(File f) { openFile(f); }
            @Override public void onLongFile(File f) { fileMenu(f); }
            @Override public void onDir(File d) {
                currentDir=d;
                if(fileSearch.getText().length()>0)fileSearch.setText("");
                updateTreeHeader();
            }
        });
        rv.setAdapter(tree);
        tree.setRoot(project.root());
        tree.showDirectory(currentDir);
        updateTreeHeader();
        findViewById(R.id.btnTreeBack).setOnClickListener(v->{
            if(fileSearch.getText().length()>0){fileSearch.setText("");return;}
            if(tree.goUp()){
                currentDir=tree.currentDirectory();
                updateTreeHeader();
            }else drawer.closeDrawers();
        });

        fileSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {
                tree.setFilter(s.toString());
            }
            @Override public void afterTextChanged(Editable e) {}
        });

        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab t) {
                Object tag = t.getTag();
                if (tag instanceof File) showEditor((File) tag);
                updateTabSelectionStyles();
            }
            @Override public void onTabUnselected(TabLayout.Tab t) { updateTabSelectionStyles(); }
            @Override public void onTabReselected(TabLayout.Tab t) {
                if(t.getTag() instanceof File)showEditor((File)t.getTag());
                updateTabSelectionStyles();
            }
        });

        updatePathBar();
        // فهرسة رموز المشروع في الخلفية لتغذية الإكمال التلقائي
        topBusy.show("فهرسة رموز المشروع…");
        new Thread(() -> {
            index.build(project);
            runOnUiThread(() -> {
                topBusy.hide();
                flashStatus("اكتملت الفهرسة: "
                    + index.classes().size() + " صنف، "
                    + index.methods().size() + " دالة، "
                    + index.ids().size() + " معرّف مورد");
            });
        }, "apkide-index").start();
        drawer.openDrawer(android.view.Gravity.LEFT);
        if(getIntent().getBooleanExtra(EngineService.EXTRA_SHOW_WORK,false))
            drawer.post(()->Ui.revealActiveProgress(this));
    }

    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);
        setIntent(intent);
        if(intent.getBooleanExtra(EngineService.EXTRA_SHOW_WORK,false))
            Ui.revealActiveProgress(this);
    }

    /* ------------------------- الملفات والمحرر ------------------------- */

    private void openFile(File f) {
        drawer.closeDrawers();
        if (f.getParentFile() != null) {
            currentDir=f.getParentFile();
            if(fileSearch!=null&&fileSearch.getText().length()>0)fileSearch.setText("");
            if(tree!=null)tree.showDirectory(currentDir);
            updateTreeHeader();
        }
        if (!FileUtil.isProbablyText(f)) {
            startActivity(new Intent(this, AssetViewerActivity.class)
                    .putExtra("file", f.getAbsolutePath()));
            return;
        }
        if (f.length() > 3 * 1024 * 1024) {
            Ui.toast(this, "الملف كبير جداً للتحرير (" + FileUtil.humanSize(f.length()) + ")");
            return;
        }
        String key = f.getAbsolutePath();
        if (!open.containsKey(key)) {
            try {
                CodeEditorView ed = new CodeEditorView(this);
                ed.setProjectIndex(index);
                ed.setAutoComplete(com.almlk.editorapkpro.util.Prefs.autoComplete());
                ed.setAutoClose(com.almlk.editorapkpro.util.Prefs.autoClose());
                ed.setOnFocusChangeListener((v,hasFocus)->{
                    boolean show=hasFocus&&editorToolsRow.getChildCount()>0
                            &&com.almlk.editorapkpro.util.Prefs.editorToolbarVisible();
                    editorTools.setVisibility(show?View.VISIBLE:View.GONE);
                    if(show)ed.postDelayed(ed::ensureCursorVisible,240);
                    ViewCompat.requestApplyInsets(drawer);
                });
                ed.setSource(FileUtil.read(f), f.getName());
                ed.addTextChangedListener(new TextWatcher() {
                    @Override public void beforeTextChanged(CharSequence x, int a, int b, int c) {}
                    @Override public void onTextChanged(CharSequence x, int a, int b, int c) {
                        dirty.add(key); updateTabTitle(f);
                    }
                    @Override public void afterTextChanged(Editable x) {}
                });
                open.put(key, ed);
                openFiles.add(f);
                TabLayout.Tab tab = tabs.newTab();
                tab.setTag(f);
                tab.setCustomView(makeTabView(tab, f));
                tabs.addTab(tab, true);
            } catch (Exception e) { Ui.error(this, e); return; }
        } else {
            for (int i = 0; i < tabs.getTabCount(); i++) {
                TabLayout.Tab t = tabs.getTabAt(i);
                if (t != null && f.equals(t.getTag())) { t.select(); break; }
            }
        }
        showEditor(f);
    }

    private void showEditor(File f) {
        CodeEditorView ed = open.get(f.getAbsolutePath());
        if (ed == null) return;
        active = f;
        drawer.closeDrawers();
        host.removeAllViews();
        host.addView(ed, new FrameLayout.LayoutParams(-1, -1));
        ed.refreshHighlight();
        status.removeCallbacks(restorePathTask);
        updatePathBar();
        toolbar.setTitle(project.name);
        toolbar.setSubtitle(projectTitleDetail(f));
        updateContextActions(f);
        ViewCompat.requestApplyInsets(drawer);
    }

    private void closePrompt(File f) {
        if (f == null) return;
        new MaterialAlertDialogBuilder(this)
                .setTitle(f.getName())
                .setItems(new String[]{"حفظ", "إغلاق التبويب", "عرض المسار"}, (d, w) -> {
                    if (w == 0) saveActive();
                    else if (w == 1) closeTab(f);
                    else Ui.toast(this, f.getAbsolutePath());
                }).show();
    }

    private void closeTab(File f) {
        boolean wasActive = f.equals(active);
        open.remove(f.getAbsolutePath());
        openFiles.remove(f);
        dirty.remove(f.getAbsolutePath());
        if (wasActive) { host.removeAllViews(); active = null; updateContextActions(null); }
        for (int i = 0; i < tabs.getTabCount(); i++) {
            TabLayout.Tab t = tabs.getTabAt(i);
            if (t != null && f.equals(t.getTag())) { tabs.removeTabAt(i); break; }
        }
        // TabLayout قد يرسل callback قبل اكتمال الإزالة؛ أعد إظهار المحدد صراحة.
        if (wasActive && tabs.getTabCount() > 0) {
            int p = Math.max(0, tabs.getSelectedTabPosition());
            TabLayout.Tab next = tabs.getTabAt(p);
            if (next != null && next.getTag() instanceof File) showEditor((File) next.getTag());
        } else if (active == null) {
            toolbar.setTitle(project.name);
            toolbar.setSubtitle(projectTitleDetail(null));
            updatePathBar();
        }
    }

    private void bindCodeKey(int id,String value){
        findViewById(id).setOnClickListener(v->{
            CodeEditorView e=activeEditor();
            if(e!=null)e.insertAtCursor(value);
        });
    }

    private void cacheEditorToolViews(){
        editorToolViews.clear();
        for(String key:EditorToolConfig.DEFAULT_ORDER){
            View view=findViewById(EditorToolConfig.viewId(key));
            if(view!=null)editorToolViews.put(key,view);
        }
    }

    /** يطبق ترتيب مفاتيح IME والثيم على كل المحررات المفتوحة دون إعادة إنشائها. */
    private void applyEditorPreferences(){
        EditorTheme palette=EditorTheme.current();
        host.setBackgroundColor(palette.background);
        editorTools.setBackgroundColor(palette.toolbar);
        editorToolsRow.setBackgroundColor(palette.toolbar);
        editorToolsRow.removeAllViews();
        for(String key:EditorToolConfig.order()){
            View view=editorToolViews.get(key);
            if(view==null||!com.almlk.editorapkpro.util.Prefs.editorToolEnabled(key))continue;
            if(view instanceof TextView){
                int color=palette.text;
                if("delete".equals(key))color=palette.keyword;
                else if("hide".equals(key))color=palette.comment;
                else if("tab".equals(key)||"save".equals(key)||"select".equals(key)
                        ||"complete".equals(key))color=palette.type;
                ((TextView)view).setTextColor(color);
            }
            editorToolsRow.addView(view);
        }
        for(CodeEditorView editor:open.values())editor.applyPreferences();
        if(!com.almlk.editorapkpro.util.Prefs.editorToolbarVisible()
                ||editorToolsRow.getChildCount()==0)editorTools.setVisibility(View.GONE);
        else{
            CodeEditorView editor=active==null?null:open.get(active.getAbsolutePath());
            if(editor!=null&&editor.hasFocus())editorTools.setVisibility(View.VISIBLE);
        }
    }

    private String spaces(int count){
        StringBuilder out=new StringBuilder();
        for(int i=0;i<Math.max(1,count);i++)out.append(' ');
        return out.toString();
    }

    private void updateEditorToolsVisibility(boolean keyboardVisible){
        CodeEditorView e=active==null?null:open.get(active.getAbsolutePath());
        if(e==null||!e.hasFocus()||editorToolsRow.getChildCount()==0
                ||!com.almlk.editorapkpro.util.Prefs.editorToolbarVisible())
            editorTools.setVisibility(View.GONE);
        else if(keyboardVisible)editorTools.setVisibility(View.VISIBLE);
        // عند عدم موثوقية IME insets لا نخفي الشريط ما دام المحرر نفسه يملك التركيز.
    }

    private CodeEditorView activeEditor() {
        if (active == null) { Ui.toast(this, "لا يوجد ملف مفتوح"); return null; }
        return open.get(active.getAbsolutePath());
    }

    private void saveActive() {
        if (active == null) { Ui.toast(this, "لا يوجد ملف مفتوح"); return; }
        CodeEditorView ed = open.get(active.getAbsolutePath());
        if (ed == null) return;
        try {
            FileUtil.write(active, ed.getText() == null ? "" : ed.getText().toString());
            dirty.remove(active.getAbsolutePath()); updateTabTitle(active);
            flashStatus("✓ تم الحفظ — " + relative(active));
            Ui.toast(this, "تم حفظ " + active.getName());
        } catch (Exception e) { Ui.error(this, e); }
    }

    private void saveAll() {
        for (File f : new ArrayList<>(openFiles)) {
            CodeEditorView ed = open.get(f.getAbsolutePath());
            if (ed == null) continue;
            try { FileUtil.write(f, ed.getText() == null ? "" : ed.getText().toString()); dirty.remove(f.getAbsolutePath()); updateTabTitle(f); }
            catch (Exception ignored) {}
        }
    }

    private void fileMenu(File f) {
        final File dir = f.isDirectory() ? f : f.getParentFile();
        currentDir = dir;
        String[] items = f.isDirectory()
                ? new String[]{"ملف جديد هنا", "مجلد جديد هنا", "إعادة تسمية", "حذف", "المسار الكامل"}
                : new String[]{"فتح في المستعرض", "ملف جديد بجواره", "إعادة تسمية", "حذف", "المسار الكامل"};
        new MaterialAlertDialogBuilder(this)
                .setTitle(f.getName())
                .setItems(items, (d, w) -> {
                    switch (w) {
                        case 0:
                            if (f.isDirectory())
                                FileOps.createFile(this, project, dir, this::afterCreate);
                            else startActivity(new Intent(this, AssetViewerActivity.class)
                                    .putExtra("file", f.getAbsolutePath()));
                            break;
                        case 1:
                            if (f.isDirectory())
                                FileOps.createFolder(this, project, dir, this::afterCreate);
                            else FileOps.createFile(this, project, dir, this::afterCreate);
                            break;
                        case 2: FileOps.rename(this, f, this::afterCreate); break;
                        case 3:
                            FileUtil.delete(f); tree.refresh(); Ui.toast(this, "حُذف"); break;
                        default: Ui.toast(this, f.getAbsolutePath());
                    }
                }).show();
    }

    /** بعد إنشاء/تسمية ملف: حدّث الشجرة وافتحه إن كان نصياً. */
    private void afterCreate(File f) {
        tree.refresh();
        if (f.isFile()) openFile(f);
        else {
            currentDir=f;
            tree.showDirectory(f);
            if(fileSearch.getText().length()>0)fileSearch.setText("");
            updateTreeHeader();
            Ui.toast(this,"المجلد الحالي: "+f.getName());
        }
    }

    /** تبويب مخصص: اسم الملف + زر إغلاق، مع علامة • للملف المعدّل. */
    private View makeTabView(TabLayout.Tab tab, File f) {
        android.widget.LinearLayout row = new android.widget.LinearLayout(this);
        row.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row.setGravity(android.view.Gravity.CENTER_VERTICAL);
        row.setPadding(dp(10), 0, dp(2), 0);
        TextView name = new TextView(this);
        name.setTextColor(0xFFE6EDF3); name.setTextSize(13); name.setSingleLine(true);
        name.setText(f.getName());
        row.addView(name, new android.widget.LinearLayout.LayoutParams(-2, dp(44)));
        View.OnClickListener selectTab=v->{
            tab.select();
            showEditor(f);
        };
        row.setOnClickListener(selectTab);
        name.setOnClickListener(selectTab);
        android.widget.ImageButton close = new android.widget.ImageButton(this);
        close.setImageResource(com.almlk.editorapkpro.R.drawable.ic_close_small);
        close.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        close.setPadding(dp(8), dp(8), dp(8), dp(8));
        close.setContentDescription("إغلاق " + f.getName());
        close.setOnClickListener(v -> {
            if (dirty.contains(f.getAbsolutePath())) closePrompt(f); else closeTab(f);
        });
        row.setOnLongClickListener(v -> { closePrompt(f); return true; });
        row.addView(close, new android.widget.LinearLayout.LayoutParams(dp(34), dp(44)));
        return row;
    }

    private void updateTabTitle(File f) {
        for (int i=0;i<tabs.getTabCount();i++) {
            TabLayout.Tab t=tabs.getTabAt(i);
            if(t!=null && f.equals(t.getTag()) && t.getCustomView() instanceof android.widget.LinearLayout) {
                android.widget.LinearLayout row=(android.widget.LinearLayout)t.getCustomView();
                if(row.getChildCount()>0 && row.getChildAt(0) instanceof TextView)
                    ((TextView)row.getChildAt(0)).setText((dirty.contains(f.getAbsolutePath()) ? "• " : "") + f.getName());
            }
        }
    }

    private void updateTabSelectionStyles(){
        for(int i=0;i<tabs.getTabCount();i++){
            TabLayout.Tab t=tabs.getTabAt(i);
            if(t==null||!(t.getCustomView() instanceof android.widget.LinearLayout))continue;
            android.widget.LinearLayout row=(android.widget.LinearLayout)t.getCustomView();
            if(row.getChildCount()==0||!(row.getChildAt(0) instanceof TextView))continue;
            TextView name=(TextView)row.getChildAt(0);
            boolean selected=t.isSelected();
            name.setTextColor(selected?0xFFF0F3F6:0xFF9AA7B4);
            name.setTypeface(android.graphics.Typeface.DEFAULT,
                    selected?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL);
        }
    }

    /** انتقال سريع بين التبويبات المفتوحة. */
    private void switchTab(int delta) {
        int n=tabs.getTabCount(); if(n==0)return;
        int p=tabs.getSelectedTabPosition(); if(p<0)p=0;
        TabLayout.Tab t=tabs.getTabAt((p+delta+n)%n); if(t!=null)t.select();
    }

    /** فتح ملف والانتقال إلى سطر/إزاحة، يُستخدم من البحث ولوحة الأخطاء. */
    private void openFileAt(File f, int line, int offset) {
        if(f==null || !f.exists()){Ui.toast(this,"تعذّر العثور على الملف");return;}
        openFile(f);
        CodeEditorView ed=open.get(f.getAbsolutePath());
        if(ed==null)return;
        if(offset>=0)ed.goToOffset(offset); else if(line>0)ed.goToLine(line);
        ed.requestFocus();
    }

    private void openProblem(Problem p) {
        if(p.file!=null) { hideProblems(); openFileAt(p.file,p.line,-1); }
        else Ui.toast(this,p.message);
    }

    private void showProblems() {
        android.view.ViewGroup.LayoutParams x=problemsPanel.getLayoutParams();
        x.height=dp(285); problemsPanel.setLayoutParams(x); problemsPanel.setVisibility(View.VISIBLE);
    }
    private void hideProblems() {
        android.view.ViewGroup.LayoutParams x=problemsPanel.getLayoutParams();
        x.height=0; problemsPanel.setLayoutParams(x); problemsPanel.setVisibility(View.GONE);
    }
    private void updateProblemCount() {
        int errors=0,warnings=0;
        for(Problem p:problems){if(p.severity==Problem.ERROR)errors++;else if(p.severity==Problem.WARNING)warnings++;}
        problemCount.setText(errors+" errors"+(warnings>0?"  •  "+warnings+" warnings":""));
    }
    private void addProblem(Problem p) {
        String key=p.title()+"|"+p.message+"|"+p.line;
        for(Problem x:problems)if((x.title()+"|"+x.message+"|"+x.line).equals(key))return;
        problems.add(p);problemAdapter.set(problems);updateProblemCount();
        if(p.severity==Problem.ERROR)showProblems();
    }

    private int dp(int n){return(int)(n*getResources().getDisplayMetrics().density+.5f);}

    private void updateTreeHeader(){
        treeTitle.setText(relative(currentDir));
        if(active==null)updatePathBar();
    }

    /** الشريط الصغير أسفل التبويبات مخصص لمسار الملف، لا ليظل رسالة حالة كبيرة. */
    private void updatePathBar(){
        if(status==null||project==null)return;
        File shown=active!=null?active:(currentDir!=null?currentDir:project.root());
        String path=relative(shown);
        status.setText(path);
        status.setContentDescription("المسار: "+path);
    }

    /** اعرض نتيجة العملية لوقت قصير ثم أعد المسار تلقائياً. */
    private void flashStatus(String message){
        if(status==null)return;
        status.removeCallbacks(restorePathTask);
        status.setText(message);
        status.postDelayed(restorePathTask,2200);
    }

    private String relative(File f) {
        String r = project.root().getAbsolutePath();
        String a = f.getAbsolutePath();
        if(a.equals(r))return project.root().getName();
        return a.startsWith(r+File.separator)?a.substring(r.length()+1):a;
    }

    private String projectTitleDetail(File file){
        String app=(project.appName==null||project.appName.trim().isEmpty())
                ?project.packageName:project.appName;
        if(file!=null)return app+"  •  "+file.getName();
        return app+"  •  "+project.packageName;
    }

    /** يضيف زر معاينة التصميم فقط لملفات res/layout*.xml ويكيّف زر التشغيل. */
    private void updateContextActions(File file){
        if(toolbar==null)return;
        MenuItem preview=toolbar.getMenu().findItem(R.id.action_layout_preview);
        if(preview!=null)preview.setVisible(isLayoutXml(file));
        MenuItem run=toolbar.getMenu().findItem(R.id.action_build);
        if(run!=null)run.setTitle(file!=null&&file.getName().toLowerCase(Locale.ROOT).endsWith(".py")
                ?"تشغيل Python":"بناء المشروع");
    }

    private boolean isLayoutXml(File file){
        if(file==null||!file.isFile()||!file.getName().toLowerCase(Locale.ROOT).endsWith(".xml"))return false;
        File dir=file.getParentFile();
        return dir!=null&&dir.getName().startsWith("layout")
                &&dir.getParentFile()!=null&&"res".equals(dir.getParentFile().getName());
    }

    private void previewLayout(){
        if(!isLayoutXml(active)){
            Ui.toast(this,"المعاينة المرئية متاحة لملفات res/layout XML");return;
        }
        saveActive();
        startActivity(new Intent(this,LayoutPreviewActivity.class)
                .putExtra(LayoutPreviewActivity.EXTRA_FILE,active.getAbsolutePath())
                .putExtra(LayoutPreviewActivity.EXTRA_RES,project.resDir().getAbsolutePath()));
    }

    /** زر ▶ يبني مشروع Android، أو يشغّل ملف Python داخل الطرفية عند توفر المفسر. */
    private void buildOrRun(){
        if(active!=null&&active.getName().toLowerCase(Locale.ROOT).endsWith(".py")){
            saveActive();
            String q=shellQuote(active.getAbsolutePath());
            String command="if command -v python3 >/dev/null 2>&1; then python3 "+q+
                    "; elif command -v python >/dev/null 2>&1; then python "+q+
                    "; else echo 'Python غير مثبت. ثبّت python3 من مدير الأدوات ثم أعد التشغيل.'; fi";
            startActivity(new Intent(this,ToolsActivity.class)
                    .putExtra(ToolsActivity.EXTRA_COMMAND,command)
                    .putExtra(ToolsActivity.EXTRA_WORK_DIR,active.getParent()));
        }else rebuild();
    }

    private String shellQuote(String value){
        return "'"+value.replace("'","'\\''")+"'";
    }

    /* ------------------------- القائمة ------------------------- */

    private boolean onMenu(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_save)   { saveActive(); return true; }
        if (id == R.id.action_build)  { buildOrRun(); return true; }
        if (id == R.id.action_layout_preview) { previewLayout(); return true; }
        if (id == R.id.action_editor_settings) {
            startActivity(new Intent(this,EditorSettingsActivity.class));return true;
        }
        if (id == R.id.action_search_all) { saveAll(); startActivityForResult(new Intent(this, SearchActivity.class).putExtra("dir", project.dir), REQ_SEARCH); return true; }
        if (id == R.id.action_prev_file) { switchTab(-1); return true; }
        if (id == R.id.action_next_file) { switchTab(1); return true; }
        if (id == R.id.action_problems) { showProblems(); return true; }
        if (id == R.id.action_libraries) { startActivity(new Intent(this, LibrariesActivity.class).putExtra("dir", project.dir)); return true; }
        if (id == R.id.action_tools) { startActivity(new Intent(this, ToolsActivity.class)); return true; }
        if (id == R.id.action_clean_build) { inspectProjectCleanup(); return true; }
        if (id == R.id.action_zip)    { exportZip(); return true; }
        if (id == R.id.action_new_file) {
            FileOps.createFile(this, project, targetDir(), this::afterCreate); return true;
        }
        if (id == R.id.action_new_folder) {
            FileOps.createFolder(this, project, targetDir(), this::afterCreate); return true;
        }
        if (id == R.id.action_complete) {
            if (active != null) {
                CodeEditorView ed = open.get(active.getAbsolutePath());
                if (ed != null) { ed.requestFocus(); ed.triggerCompletion(); }
            } else Ui.toast(this, "افتح ملفاً أولاً");
            return true;
        }
        if (id == R.id.action_meta)   {
            startActivity(new Intent(this, MetaEditorActivity.class).putExtra("dir", project.dir));
            return true;
        }
        if (id == R.id.action_langs)  {
            startActivity(new Intent(this, LanguagesActivity.class).putExtra("dir", project.dir));
            return true;
        }
        if (id == R.id.action_assets) {
            File a = project.assetsDir().exists() ? project.assetsDir() : project.resDir();
            startActivity(new Intent(this, AssetViewerActivity.class)
                    .putExtra("file", a.getAbsolutePath()));
            return true;
        }
        if (id == R.id.action_log)    { startActivity(new Intent(this, LogActivity.class)); return true; }
        return false;
    }

    /** المجلد الهدف لعمليات الإنشاء. */
    private File targetDir() {
        if (currentDir != null && currentDir.isDirectory()) return currentDir;
        return project.mainDir().exists() ? project.mainDir() : project.root();
    }

    /** يفحص مخلفات البناء أولاً ثم يعرض عدداً ومسارات نموذجية قبل أي حذف. */
    private void inspectProjectCleanup() {
        if(Engine.get().isBusy()){
            Ui.toast(this,"توجد عملية جارية؛ انتظر اكتمالها");
            return;
        }
        saveAll();
        topBusy.show("فحص مخلفات البناء…");
        Ui.Progress progress=new Ui.Progress(this,"فحص التنظيف الآمن").show();
        Engine.get().inspectProjectCleanup(project,new TaskCallback<BuildArtifactCleaner.Plan>() {
            @Override public void onProgress(String step,int percent){
                topBusy.update(step);progress.update(step,percent);
            }
            @Override public void onSuccess(BuildArtifactCleaner.Plan plan){
                topBusy.hide();progress.dismiss();
                if(plan.isEmpty()){
                    new MaterialAlertDialogBuilder(ProjectActivity.this)
                            .setTitle("المشروع نظيف")
                            .setMessage("لا توجد مجلدات بناء أو كاش أو ملفات Python مترجمة أو مجلدات فارغة قابلة للحذف.")
                            .setPositiveButton("حسناً",null).show();
                    return;
                }
                StringBuilder message=new StringBuilder();
                message.append("عُثر على:\n")
                        .append("• ").append(plan.generatedEntries).append(" مسار بناء/كاش مولّد\n")
                        .append("• ").append(plan.emptyDirectories).append(" مجلد فارغ\n")
                        .append("• ").append(plan.containedFiles).append(" ملف داخل المخلفات\n")
                        .append("• المساحة: ").append(FileUtil.humanSize(plan.bytes)).append("\n\n")
                        .append("لن تُحذف ملفات XML أو Java أو Kotlin أو Python الأصلية. ")
                        .append("مجلدات color وanimator وغيرها تُحذف فقط إذا كانت فارغة.\n\n")
                        .append("أمثلة:\n");
                for(String path:plan.samples(8))message.append("• ").append(path).append('\n');
                if(plan.targetCount()>8)message.append("• … و")
                        .append(plan.targetCount()-8).append(" مسار آخر\n");
                new MaterialAlertDialogBuilder(ProjectActivity.this)
                        .setTitle(R.string.clean_build_artifacts)
                        .setMessage(message.toString().trim())
                        .setNegativeButton(R.string.cancel,null)
                        .setPositiveButton("تنظيف الآن",(dialog,which)->executeProjectCleanup(plan))
                        .show();
            }
            @Override public void onError(Throwable error){
                topBusy.hide();progress.dismiss();Ui.error(ProjectActivity.this,error);
            }
        });
    }

    private void executeProjectCleanup(BuildArtifactCleaner.Plan plan) {
        if(Engine.get().isBusy()){
            Ui.toast(this,"توجد عملية جارية؛ انتظر اكتمالها");
            return;
        }
        topBusy.show("تنظيف مخلفات البناء…");
        Ui.Progress progress=new Ui.Progress(this,"تنظيف مخلفات البناء").show();
        EngineService.start(this,"تنظيف المشروع",project.name);
        Engine.get().cleanProject(plan,new TaskCallback<BuildArtifactCleaner.Result>() {
            @Override public void onProgress(String step,int percent){
                topBusy.update(step);progress.update(step,percent);
            }
            @Override public void onSuccess(BuildArtifactCleaner.Result result){
                topBusy.hide();progress.dismiss();EngineService.stop(ProjectActivity.this);
                // أغلق فقط أي تبويب كان يعرض ملفاً مولداً حُذف، ولا تمس التبويبات المصدرية.
                for(File file:new ArrayList<>(openFiles))if(!file.exists())closeTab(file);
                File root=project.root();
                while(currentDir!=null&&!currentDir.exists()&&!currentDir.equals(root))
                    currentDir=currentDir.getParentFile();
                if(currentDir==null||!currentDir.exists())currentDir=root;
                tree.showDirectory(currentDir);updateTreeHeader();
                flashStatus("اكتمل التنظيف — تم توفير "+FileUtil.humanSize(result.freedBytes));
                String text="حُذف "+result.deletedFiles+" ملف و"+
                        result.deletedDirectories+" مجلد.\nالمساحة المحررة: "+
                        FileUtil.humanSize(result.freedBytes)+
                        (result.failed>0?"\nتعذر حذف "+result.failed+" عنصر قيد الاستخدام.":"")+
                        "\n\nبقيت جميع ملفات المصدر والموارد الأصلية كما هي.";
                new MaterialAlertDialogBuilder(ProjectActivity.this)
                        .setTitle("اكتمل التنظيف الآمن")
                        .setMessage(text)
                        .setPositiveButton("حسناً",null).show();
            }
            @Override public void onError(Throwable error){
                topBusy.hide();progress.dismiss();EngineService.stop(ProjectActivity.this);
                Ui.error(ProjectActivity.this,error);
            }
        });
    }

    private void rebuild() {
        saveAll();
        String[] modes = {"بناء سريع (موارد + smali) — موصى به",
                          "بناء من شيفرة المصدر (ecj + d8)"};
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.rebuild)
                .setItems(modes, (d, w) -> doRebuild(w == 0 ? Rebuilder.Mode.FAST : Rebuilder.Mode.SOURCE))
                .show();
    }

    private void doRebuild(Rebuilder.Mode mode) {
        if(Engine.get().isBusy()){
            Ui.toast(this,"توجد عملية فك أو بناء جارية؛ انتظر اكتمالها");
            return;
        }
        problems.clear(); problemAdapter.set(problems); updateProblemCount(); hideProblems();
        topBusy.show("إعادة بناء التطبيق…");
        Ui.Progress p = new Ui.Progress(this, "إعادة بناء التطبيق").show();
        EngineService.start(this, "إعادة البناء", project.name);
        busy.setVisibility(View.VISIBLE);
        Engine.get().rebuild(this, project, mode, new TaskCallback<File>() {
            @Override public void onProgress(String step, int pct) {
                topBusy.update(step); p.update(step, pct);
            }
            @Override public void onSuccess(File apk) {
                detachBuildSink();
                topBusy.hide(); p.dismiss(); busy.setVisibility(View.GONE);
                EngineService.stop(ProjectActivity.this);
                flashStatus("✓ تم البناء: " + apk.getName());
                offerInstall(apk);
            }
            @Override public void onError(Throwable e) {
                // أضف رسالة الاستثناء إن لم تنتج الأداة سطراً قابلاً للتحليل.
                if (problems.isEmpty())
                    addProblem(new Problem(Problem.ERROR, null,
                            e.getMessage() == null ? e.toString() : e.getMessage(), "build"));
                detachBuildSink();
                topBusy.hide(); p.dismiss(); busy.setVisibility(View.GONE);
                EngineService.stop(ProjectActivity.this);
                flashStatus("فشل البناء — " + problems.size() + " مشكلة");
                showProblems();
                Ui.toast(ProjectActivity.this, "فشل البناء — اضغط المشكلة للانتقال إلى الملف");
            }
        });
        // Engine ينشئ Logger قبل إعادة Future؛ التقط كل سطر وحوّله فورياً إلى مشكلة منظمة.
        currentBuildLog = Engine.get().currentLog();
        if (currentBuildLog != null) {
            buildSink = line -> {
                Problem found = ProblemParser.parseLine(line, project);
                if (found != null) runOnUiThread(() -> addProblem(found));
            };
            currentBuildLog.addSink(buildSink);
        }
    }

    private void detachBuildSink() {
        if (currentBuildLog != null && buildSink != null) currentBuildLog.removeSink(buildSink);
        currentBuildLog = null; buildSink = null;
    }

    private void offerInstall(File apk) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("اكتمل البناء")
                .setMessage(apk.getAbsolutePath() + "\n" + FileUtil.humanSize(apk.length()))
                .setNegativeButton("إغلاق", null)
                .setNeutralButton("مشاركة", (d, w) -> share(apk, "application/vnd.android.package-archive"))
                .setPositiveButton("تثبيت", (d, w) -> {
                    try {
                        android.net.Uri u = FileProvider.getUriForFile(this,
                                getPackageName() + ".fileprovider", apk);
                        startActivity(new Intent(Intent.ACTION_VIEW)
                                .setDataAndType(u, "application/vnd.android.package-archive")
                                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                                        | Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e) { Ui.error(this, e); }
                }).show();
    }

    private void exportZip() {
        if(Engine.get().isBusy()){
            Ui.toast(this,"توجد عملية جارية؛ انتظر اكتمالها"); return;
        }
        saveAll();
        topBusy.show("ضغط المشروع…");
        Ui.Progress p = new Ui.Progress(this, "ضغط المشروع").show();
        Engine.get().exportZip(project, new TaskCallback<File>() {
            @Override public void onProgress(String step, int pct) {
                topBusy.update(step); p.update(step, pct);
            }
            @Override public void onSuccess(File zip) {
                topBusy.hide(); p.dismiss();
                new MaterialAlertDialogBuilder(ProjectActivity.this)
                        .setTitle("تم إنشاء الأرشيف")
                        .setMessage(zip.getAbsolutePath() + "\n" + FileUtil.humanSize(zip.length()))
                        .setPositiveButton("مشاركة", (d, w) -> share(zip, "application/zip"))
                        .setNegativeButton("إغلاق", null).show();
            }
            @Override public void onError(Throwable e) {
                topBusy.hide(); p.dismiss(); Ui.error(ProjectActivity.this, e);
            }
        });
    }

    private void share(File f, String mime) {
        try {
            android.net.Uri u = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", f);
            startActivity(Intent.createChooser(new Intent(Intent.ACTION_SEND)
                    .setType(mime).putExtra(Intent.EXTRA_STREAM, u)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "مشاركة"));
        } catch (Exception e) { Ui.error(this, e); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQ_SEARCH && resultCode==RESULT_OK && data!=null) {
            String path=data.getStringExtra(SearchActivity.RESULT_FILE);
            openFileAt(path==null?null:new File(path), data.getIntExtra(SearchActivity.RESULT_LINE,-1), data.getIntExtra(SearchActivity.RESULT_OFFSET,-1));
            tree.refresh();
        }
    }

    @Override public boolean onCreateOptionsMenu(Menu m) { return true; }

    @Override protected void onResume() {
        super.onResume();
        project = ProjectManager.load(project.root());
        applyEditorPreferences();
        tree.refresh();
    }

    @Override public void onBackPressed() {
        if(drawer.isDrawerOpen(android.view.Gravity.LEFT)){
            if(fileSearch!=null&&fileSearch.getText().length()>0){
                fileSearch.setText("");
            }else if(tree!=null&&tree.goUp()){
                currentDir=tree.currentDirectory();
                updateTreeHeader();
            }else drawer.closeDrawers();
        }else{
            saveAll();
            super.onBackPressed();
        }
    }
}
