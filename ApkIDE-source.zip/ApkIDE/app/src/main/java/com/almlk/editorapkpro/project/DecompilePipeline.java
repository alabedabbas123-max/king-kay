package com.almlk.editorapkpro.project;

import android.content.Context;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.engine.NativeTools;
import com.almlk.editorapkpro.engine.TaskCallback;
import com.almlk.editorapkpro.engine.apktool.ApktoolEngine;
import com.almlk.editorapkpro.engine.jadx.JadxEngine;
import com.almlk.editorapkpro.model.Project;
import com.almlk.editorapkpro.util.Env;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.setup.SetupManager;

import java.io.File;
import java.util.Set;

/**
 * خط الإنتاج الكامل لتحويل APK إلى مشروع.
 *
 * الوضع MODE_RESOURCES (تحرير متوسط):
 *      apktool decodeAll  ->  res/ + smali/ + AndroidManifest + assets
 *
 * الوضع MODE_SOURCE (فك المشروع الهندسي الكامل):
 *      1) apktool: موارد XML حقيقية + manifest + assets + jniLibs + public.xml
 *      2) jadx  : DEX -> Java (مع De-obfuscation و Kotlin metadata)
 *      3) دمجهما في بنية Gradle قياسية app/src/main/...
 *      4) تثبيت معرّفات الموارد (stable-ids) وحذف R.java المولّد
 *      5) تنظيف مخلفات الفك وحزم المكتبات + توليد اعتماديات Gradle
 *      6) الاحتفاظ بنسخة smali في .apkide/ من أجل إعادة البناء السريعة
 */
public class DecompilePipeline {

    private final Context ctx;
    private final Logger  log;

    public DecompilePipeline(Context ctx, Logger log) { this.ctx = ctx; this.log = log; }

    public Project run(File apk, String projectName, int mode, TaskCallback<Project> cb)
            throws Exception {

        // يمنع بدء الفك قبل اكتمال تثبيت الأدوات وتهيئة خصائص Apktool.
        SetupManager.ensureForDecompile(ctx, log);
        cleanPreviousTemporaryWork(apk);
        File projectRoot = Env.projectDir(ProjectManager.uniqueName(projectName));
        projectRoot.mkdirs();
        File meta = new File(projectRoot, ".apkide");
        meta.mkdirs();
        File frameworkDir = new File(Env.toolsDir(), "framework");
        frameworkDir.mkdirs();

        // نمرر مسار aapt2 الأصلي إلى apktool
        File aapt2 = NativeTools.tool(ctx, NativeTools.AAPT2);
        if (aapt2 != null) System.setProperty("apkide.aapt2", aapt2.getAbsolutePath());

        Project p = new Project();
        p.name        = projectRoot.getName();
        p.mode        = mode;
        p.dir         = projectRoot.getAbsolutePath();
        p.createdAt   = System.currentTimeMillis();
        p.originalApk = apk.getAbsolutePath();

        try {
        ApktoolEngine apktool = new ApktoolEngine(log);

        if (mode == Project.MODE_RESOURCES) {
            step(cb, "فك الموارد أولاً…", 5);
            apktool.decodeAll(apk, projectRoot, frameworkDir, (dex, done, total) -> {
                int pct=total>0?20+(done*70/total):-1;
                step(cb,"فك Smali: "+dex+" ("+done+"/"+total+")",pct);
            });

            ManifestReader mr = ManifestReader.read(new File(projectRoot, "AndroidManifest.xml"),
                    new File(projectRoot, "apktool.yml"));
            fill(p, mr);
            step(cb, "إنهاء وفحص ملفات Smali…", 95);

        } else {
            /* ---------- 1) الموارد عبر apktool ---------- */
            step(cb, "فك الموارد الثنائية (apktool)…", 5);
            File resStage = Env.newTmp("res");
            apktool.decodeResourcesOnly(apk, resStage, frameworkDir);

            ManifestReader mr = ManifestReader.read(new File(resStage, "AndroidManifest.xml"),
                    new File(resStage, "apktool.yml"));
            fill(p, mr);

            /* أنشئ نسخة البناء من نفس فك الموارد، ثم حوّل DEX إلى Smali بالتتابع.
               هذا يلغي فك Apktool الكامل الثاني الذي كان يضاعف الذاكرة والعمل. */
            File smaliStage = new File(meta, "rebuild");
            step(cb, "تجهيز نسخة إعادة البناء…", 15);
            FileUtil.copyDir(resStage, smaliStage);
            apktool.decodeSmaliInPlace(smaliStage, (dex, done, total) -> {
                int pct=total>0?17+(done*14/total):-1;
                step(cb,"فك Smali منخفض الذاكرة: "+dex+" ("+done+"/"+total+")",pct);
            });
            System.gc();

            File main = new File(projectRoot, "app/src/main");
            main.mkdirs();
            step(cb, "تجهيز بنية المشروع القياسية…", 32);
            move(new File(resStage, "res"),      new File(main, "res"));
            move(new File(resStage, "assets"),   new File(main, "assets"));
            move(new File(resStage, "lib"),      new File(main, "jniLibs"));
            move(new File(resStage, "unknown"),  new File(meta, "unknown"));
            move(new File(resStage, "kotlin"),   new File(meta, "kotlin"));
            copy(new File(resStage, "AndroidManifest.xml"), new File(main, "AndroidManifest.xml"));
            copy(new File(resStage, "apktool.yml"),         new File(meta, "apktool.yml"));
            // حافظ دائماً على تخطيط Android Studio القياسي حتى لو لم يحوِ APK assets أو res.
            new File(main,"assets").mkdirs();
            new File(main,"res").mkdirs();
            new File(main,"java").mkdirs();

            /* ---------- 2) الشيفرة عبر jadx ---------- */
            step(cb, "فك ملفات DEX إلى Java (jadx)…", 35);
            File javaDir = new File(main, "java");
            javaDir.mkdirs();
            JadxEngine.Options opt = new JadxEngine.Options();
            File mapping = new File(meta, "unknown/mapping.txt");
            if (mapping.exists()) opt.deobfMapFile = mapping;
            // لا تمرر APK الكبير إلى Jadx: ملفات DEX الخام موجودة في resStage،
            // وتُفك بالتتابع كي لا تمتلئ heap برسوم استخدام كل الأصناف مرة واحدة.
            new JadxEngine(log).decompileDexDirectory(resStage, javaDir,
                    new File(meta, "jadx-res"), opt, (done, total) -> {
                        int pct = total > 0 ? (int) (35 + (done * 40 / total)) : -1;
                        step(cb, "فك الأصناف " + done + "/" + total, pct);
                    });

            /* ---------- 3) تثبيت معرّفات الموارد ---------- */
            step(cb, "تثبيت معرّفات الموارد (R.id …)…", 78);
            ResourceIdPreserver.Result preserved=ResourceIdPreserver.apply(
                    projectRoot,new File(main,"res"),p.packageName,log);
            ResourceIdPreserver.restoreReferences(javaDir,p.packageName,preserved,log);
            ResourceIdPreserver.normalizeRClassAliases(javaDir,log);
            ResourceIdPreserver.ensureIdsDeclared(new File(main, "res"), log);
            ResourceIdPreserver.removeGeneratedRClasses(javaDir, log);
            // public.xml/APKTOOL_DUMMY_* هي دفاتر محاسبة داخلية لـ Apktool فقط؛
            // بعد أن استخرجنا منها stable-ids.txt أعلاه لا حاجة لها في مشروع
            // Gradle نهائي، وإبقاؤها هو ما يظهر كـ"مخلفات" داخل res الحقيقي.
            ResourceIdPreserver.cleanApktoolResidue(new File(main, "res"), log);
            // لا نحتفظ بخريطة عشرات آلاف الموارد خلال تنظيف Java/Gradle اللاحق.
            preserved.idMap.clear();
            System.gc();

            /* ---------- 4) التنظيف ---------- */
            step(cb, "تنظيف المشروع من مخلفات الفك والمكتبات…", 85);
            ProjectCleaner.Report rep = ProjectCleaner.clean(javaDir, p.packageName,
                    com.almlk.editorapkpro.util.Prefs.cleanProject(), log);

            /* ---------- 5) ملفات البناء ---------- */
            step(cb, "توليد ملفات Gradle…", 92);
            Set<String> deps = rep.dependencies;
            GradleWriter.write(p, mr.minSdk, mr.targetSdk,
                    Math.max(34, mr.targetSdk), deps, rep.kotlinDetected);
            cleanGeneratedArtifacts(projectRoot,meta,main);
            log.i("layout: app/src/main/{assets,res,java,AndroidManifest.xml} وملفات Gradle فقط");

            /* ---------- 6) نسخة Smali جُهزت مسبقاً دون إعادة فك الموارد ---------- */
            step(cb, "فحص مسار إعادة البناء السريع…", 96);
            if (!smaliStage.isDirectory())
                throw new IllegalStateException("تعذّر تجهيز نسخة Smali لإعادة البناء");
            log.i("rebuild: نسخة Smali منخفضة الذاكرة جاهزة في .apkide/rebuild");

            FileUtil.delete(resStage);
        }

        // احذف نواتج Apktool/Gradle وكاش Python والمجلدات الفارغة فقط.
        // لا تُحذف ملفات XML/Java/Kotlin/Python الأصلية ولا مجلدات الموارد المحتوية.
        step(cb,"تنظيف مخلفات البناء والمجلدات الفارغة بأمان…",98);
        BuildArtifactCleaner.clean(p,log,
                (message,percent)->step(cb,message,percent<0?-1:98+percent/50));

        ProjectManager.save(p);
        log.i("اكتمل إنشاء المشروع: " + p.name);
        return p;
        } catch(OutOfMemoryError oom) {
            // OOM ليس Exception؛ التقطه صراحة كي لا يبقى مشروع نصف مفكوك بعد Jadx/Apktool.
            log.w("ضغط ذاكرة: تنظيف المشروع الجزئي قبل إعادة الخطأ إلى الواجهة");
            try { FileUtil.delete(projectRoot); } catch(Throwable ignored) {}
            try { cleanPreviousTemporaryWork(apk); } catch(Throwable ignored) {}
            System.gc();
            throw oom;
        } catch(Exception failure) {
            // لا تترك مشروعاً ناقصاً يستهلك المساحة أو يبدو صالحاً بعد فشل الفك.
            log.w("تنظيف المشروع الجزئي بعد فشل العملية: "+projectRoot.getName());
            try { FileUtil.delete(projectRoot); } catch(Throwable ignored) {}
            throw failure;
        }
    }

    private void fill(Project p, ManifestReader mr) {
        p.packageName = mr.packageName;
        p.versionCode = mr.versionCode;
        p.versionName = mr.versionName;
        p.appName     = mr.appLabel == null || mr.appLabel.startsWith("@")
                ? p.name : mr.appLabel;
    }

    private void step(TaskCallback<?> cb, String s, int pct) {
        log.i(s);
        if (cb != null) cb.onProgress(s, pct);
    }

    /** امسح أعمال العمليات القديمة مع إبقاء مجلد APK الجاري إن كان ملفاً مستورداً. */
    private void cleanPreviousTemporaryWork(File input){
        try{
            File keep=input.getCanonicalFile();
            File[] old=Env.tmpDir().listFiles();
            if(old==null)return;
            long bytes=0;
            for(File f:old){
                String base=f.getCanonicalPath()+File.separator;
                if(keep.getCanonicalPath().equals(f.getCanonicalPath())
                        ||keep.getCanonicalPath().startsWith(base))continue;
                bytes+=FileUtil.sizeOf(f);FileUtil.delete(f);
            }
            if(bytes>0)log.i("clean-decompile: حُذفت مخلفات عمليات سابقة بحجم "+FileUtil.humanSize(bytes));
        }catch(Exception ignored){}
    }

    /** يحذف مخلفات Gradle/Jadx السابقة دون لمس ملفات المصدر الأصلية. */
    private static void cleanGeneratedArtifacts(File root,File meta,File main){
        FileUtil.delete(new File(root,"build"));
        FileUtil.delete(new File(root,".gradle"));
        FileUtil.delete(new File(root,"dist"));
        FileUtil.delete(new File(root,"app/build"));
        FileUtil.delete(new File(root,"app/.cxx"));
        FileUtil.delete(new File(root,"app/.externalNativeBuild"));
        FileUtil.delete(new File(meta,"jadx-res"));
        new File(main,"assets").mkdirs();
        new File(main,"res").mkdirs();
        new File(main,"java").mkdirs();
    }

    private static void move(File src, File dst) throws Exception {
        if (!src.exists()) return;
        File parent = dst.getParentFile();
        if (parent != null) parent.mkdirs();
        if (!src.renameTo(dst)) { FileUtil.copyDir(src, dst); FileUtil.delete(src); }
    }

    private static void copy(File src, File dst) throws Exception {
        if (src.exists()) FileUtil.copyDir(src, dst);
    }
}
