package com.almlk.editorapkpro.model;

import java.io.File;
import java.io.Serializable;

/** نموذج مشروع مفكوك على القرص. */
public class Project implements Serializable {

    public static final int MODE_RESOURCES = 0;  // res + smali (تحرير متوسط)
    public static final int MODE_SOURCE    = 1;  // مشروع Gradle كامل بشيفرة Java/Kotlin

    public String name;
    public String packageName;
    public String appName;
    public String versionName;
    public int    versionCode;
    public int    mode;
    public long   createdAt;
    public String originalApk;
    public String dir;

    public File root()        { return new File(dir); }
    public File appModule()   { return mode == MODE_SOURCE ? new File(dir, "app") : new File(dir); }
    public File mainDir()     { return mode == MODE_SOURCE
                                    ? new File(dir, "app/src/main") : new File(dir); }
    public File javaDir()     { return new File(dir, "app/src/main/java"); }
    public File resDir()      { return new File(mainDir(), "res"); }
    public File assetsDir()   { return new File(mainDir(), "assets"); }
    public File manifest()    { return new File(mainDir(), "AndroidManifest.xml"); }
    public File smaliDir()    { return new File(metaDir(), "smali"); }
    public File metaDir()     { return new File(dir, ".apkide"); }
    public File valuesDir()   { return new File(resDir(), "values"); }
}
