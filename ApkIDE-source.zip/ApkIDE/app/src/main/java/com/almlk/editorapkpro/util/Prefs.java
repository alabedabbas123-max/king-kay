package com.almlk.editorapkpro.util;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;

public final class Prefs {
    private static SharedPreferences sp;
    private Prefs() {}

    public static void init(Context c) { sp = c.getSharedPreferences("apkide", Context.MODE_PRIVATE); }
    public static SharedPreferences raw() { return sp; }

    public static int  nightMode()          { return sp.getInt("night", AppCompatDelegate.MODE_NIGHT_YES); }
    public static void nightMode(int m)     { sp.edit().putInt("night", m).apply(); }

    public static boolean deobfuscation()   { return sp.getBoolean("deobf", true); }
    public static void deobfuscation(boolean v) { sp.edit().putBoolean("deobf", v).apply(); }

    public static boolean cleanProject()    { return sp.getBoolean("clean", true); }
    public static void cleanProject(boolean v) { sp.edit().putBoolean("clean", v).apply(); }

    public static boolean keepResIds()      { return sp.getBoolean("keepids", true); }
    public static void keepResIds(boolean v){ sp.edit().putBoolean("keepids", v).apply(); }

    public static boolean decompileKotlin() { return sp.getBoolean("kotlin", true); }
    public static void decompileKotlin(boolean v){ sp.edit().putBoolean("kotlin", v).apply(); }

    public static boolean autoClose()       { return sp.getBoolean("autoclose", true); }
    public static void autoClose(boolean v) { sp.edit().putBoolean("autoclose", v).apply(); }

    public static boolean autoComplete()    { return sp.getBoolean("autocomplete", true); }
    public static void autoComplete(boolean v) { sp.edit().putBoolean("autocomplete", v).apply(); }

    /* ---------------- إعدادات المحرر والثيم ---------------- */
    public static String editorTheme() { return sp.getString("editor_theme", "aide"); }
    public static void editorTheme(String id) { sp.edit().putString("editor_theme", id).apply(); }
    public static float editorFontSize() { return sp.getFloat("editor_font_size", 14f); }
    public static void editorFontSize(float v) { sp.edit().putFloat("editor_font_size", v).apply(); }
    public static float editorLineSpacing() { return sp.getFloat("editor_line_spacing", 1f); }
    public static void editorLineSpacing(float v) { sp.edit().putFloat("editor_line_spacing", v).apply(); }
    public static int editorTabSpaces() { return sp.getInt("editor_tab_spaces", 4); }
    public static void editorTabSpaces(int v) { sp.edit().putInt("editor_tab_spaces", v).apply(); }
    public static boolean editorLineNumbers() { return sp.getBoolean("editor_line_numbers", true); }
    public static void editorLineNumbers(boolean v) { sp.edit().putBoolean("editor_line_numbers", v).apply(); }
    public static boolean editorWordWrap() { return sp.getBoolean("editor_word_wrap", false); }
    public static void editorWordWrap(boolean v) { sp.edit().putBoolean("editor_word_wrap", v).apply(); }
    public static boolean editorCurrentLine() { return sp.getBoolean("editor_current_line", true); }
    public static void editorCurrentLine(boolean v) { sp.edit().putBoolean("editor_current_line", v).apply(); }
    public static boolean editorToolbarVisible() { return sp.getBoolean("editor_toolbar_visible", true); }
    public static void editorToolbarVisible(boolean v) { sp.edit().putBoolean("editor_toolbar_visible", v).apply(); }

    public static int editorColor(String key,int fallback) {
        return sp.getInt("editor_color_"+key,fallback);
    }
    public static void setEditorColor(String key,int value) {
        sp.edit().putInt("editor_color_"+key,value).apply();
    }
    public static void clearEditorColors() {
        android.content.SharedPreferences.Editor e=sp.edit();
        for(String key:com.almlk.editorapkpro.ui.editor.EditorTheme.COLOR_KEYS)
            e.remove("editor_color_"+key);
        e.apply();
    }

    public static String editorToolOrder() { return sp.getString("editor_tool_order", ""); }
    public static void editorToolOrder(String order) { sp.edit().putString("editor_tool_order",order).apply(); }
    public static boolean editorToolEnabled(String key) {
        return sp.getBoolean("editor_tool_enabled_"+key,true);
    }
    public static void editorToolEnabled(String key,boolean enabled) {
        sp.edit().putBoolean("editor_tool_enabled_"+key,enabled).apply();
    }
    public static void resetEditorSettings() {
        android.content.SharedPreferences.Editor e=sp.edit()
                .remove("editor_theme").remove("editor_font_size").remove("editor_line_spacing")
                .remove("editor_tab_spaces").remove("editor_line_numbers").remove("editor_word_wrap")
                .remove("editor_current_line").remove("editor_toolbar_visible")
                .remove("editor_tool_order");
        for(String key:com.almlk.editorapkpro.ui.editor.EditorTheme.COLOR_KEYS)
            e.remove("editor_color_"+key);
        for(String key:com.almlk.editorapkpro.ui.editor.EditorToolConfig.DEFAULT_ORDER)
            e.remove("editor_tool_enabled_"+key);
        e.apply();
    }

    // v10 يعيد الفحص بعد تحديث محرك Jadx منخفض الذاكرة وتنظيف بيئة البناء.
    public static boolean setupComplete() { return sp.getBoolean("setup_v10_complete", false); }
    public static void setupComplete(boolean v) { sp.edit().putBoolean("setup_v10_complete", v).apply(); }

    public static int threads()             { return sp.getInt("threads",
            Math.max(1, Runtime.getRuntime().availableProcessors() - 1)); }
    public static void threads(int v)       { sp.edit().putInt("threads", v).apply(); }
}
