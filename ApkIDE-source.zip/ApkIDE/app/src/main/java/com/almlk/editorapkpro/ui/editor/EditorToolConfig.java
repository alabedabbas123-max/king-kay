package com.almlk.editorapkpro.ui.editor;

import com.almlk.editorapkpro.R;
import com.almlk.editorapkpro.util.Prefs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** مفاتيح شريط الكتابة السريعة وترتيبها المحفوظ. */
public final class EditorToolConfig {
    private EditorToolConfig() {}

    public static final String[] DEFAULT_ORDER={
            // أدوات التحديد والحذف والتراجع ظاهرة أولاً، ثم الرموز مثل مرجع AIDE.
            "tab","select","delete","undo","redo","complete","lt","gt","slash","equals",
            "quote","apostrophe","colon","semicolon","at","plus","minus","open_paren",
            "close_paren","open_brace","close_brace","open_bracket","close_bracket","save","hide"
    };

    public static List<String> order(){
        List<String> out=new ArrayList<>();
        Set<String> valid=new HashSet<>();
        java.util.Collections.addAll(valid,DEFAULT_ORDER);
        String saved=Prefs.editorToolOrder();
        if(saved!=null&&!saved.trim().isEmpty()){
            for(String key:saved.split(","))if(valid.contains(key)&&!out.contains(key))out.add(key);
        }
        for(String key:DEFAULT_ORDER)if(!out.contains(key))out.add(key);
        return out;
    }

    public static void saveOrder(List<String> order){
        StringBuilder text=new StringBuilder();
        for(String key:order){if(text.length()>0)text.append(',');text.append(key);}
        Prefs.editorToolOrder(text.toString());
    }

    public static int viewId(String key){
        switch(key){
            case "tab":return R.id.btnEditTab;case "lt":return R.id.btnCodeLt;
            case "gt":return R.id.btnCodeGt;case "slash":return R.id.btnCodeSlash;
            case "equals":return R.id.btnCodeEquals;case "quote":return R.id.btnCodeQuote;
            case "apostrophe":return R.id.btnCodeApostrophe;case "colon":return R.id.btnCodeColon;
            case "semicolon":return R.id.btnCodeSemicolon;case "at":return R.id.btnCodeAt;
            case "plus":return R.id.btnCodePlus;case "minus":return R.id.btnCodeMinus;
            case "open_paren":return R.id.btnCodeOpenParen;case "close_paren":return R.id.btnCodeCloseParen;
            case "open_brace":return R.id.btnCodeOpenBrace;case "close_brace":return R.id.btnCodeCloseBrace;
            case "open_bracket":return R.id.btnCodeOpenBracket;case "close_bracket":return R.id.btnCodeCloseBracket;
            case "delete":return R.id.btnEditDelete;case "undo":return R.id.btnEditUndo;
            case "redo":return R.id.btnEditRedo;case "save":return R.id.btnEditSave;
            case "select":return R.id.btnEditSelect;case "complete":return R.id.btnEditComplete;
            case "hide":return R.id.btnEditHide;default:return 0;
        }
    }

    public static String label(String key){
        switch(key){
            case "tab":return "Tab / إزاحة";case "lt":return "<";case "gt":return ">";
            case "slash":return "/";case "equals":return "=";case "quote":return "علامة اقتباس مزدوجة";
            case "apostrophe":return "علامة اقتباس مفردة";case "colon":return ":";
            case "semicolon":return ";";case "at":return "@";case "plus":return "+";
            case "minus":return "−";case "open_paren":return "(";case "close_paren":return ")";
            case "open_brace":return "{";case "close_brace":return "}";
            case "open_bracket":return "[";case "close_bracket":return "]";
            case "delete":return "حذف";case "undo":return "تراجع";case "redo":return "إعادة";
            case "save":return "حفظ";case "select":return "تحديد";case "complete":return "اقتراح";
            case "hide":return "إخفاء لوحة المفاتيح";default:return key;
        }
    }
}
