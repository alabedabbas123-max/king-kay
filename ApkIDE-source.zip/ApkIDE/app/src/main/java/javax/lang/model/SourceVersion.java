package javax.lang.model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Android لا يشحن وحدة java.compiler، بينما ECJ batch يشير إلى SourceVersion حتى مع
 * تعطيل annotation processing. هذه النسخة المتوافقة توفر واجهة JDK التي يحتاجها ECJ
 * وتمنع NoClassDefFoundError على الجهاز من دون إدخال Java Desktop كاملة في APK.
 */
public enum SourceVersion {
    RELEASE_0, RELEASE_1, RELEASE_2, RELEASE_3, RELEASE_4,
    RELEASE_5, RELEASE_6, RELEASE_7, RELEASE_8, RELEASE_9,
    RELEASE_10, RELEASE_11, RELEASE_12, RELEASE_13, RELEASE_14,
    RELEASE_15, RELEASE_16, RELEASE_17, RELEASE_18, RELEASE_19, RELEASE_20;

    private static final Set<String> BASE_KEYWORDS = new HashSet<>(Arrays.asList(
            "abstract","assert","boolean","break","byte","case","catch","char","class",
            "const","continue","default","do","double","else","enum","extends","final",
            "finally","float","for","goto","if","implements","import","instanceof","int",
            "interface","long","native","new","package","private","protected","public",
            "return","short","static","strictfp","super","switch","synchronized","this",
            "throw","throws","transient","try","void","volatile","while","true","false","null",
            "_"));

    /** التطبيق يصرّف Java 17 عبر ECJ، لذلك نعلن نفس المستوى بثبات على كل إصدارات Android. */
    public static SourceVersion latest() { return RELEASE_17; }
    public static SourceVersion latestSupported() { return RELEASE_17; }

    public static boolean isIdentifier(CharSequence name) {
        if (name == null || name.length() == 0) return false;
        int first = Character.codePointAt(name, 0);
        if (!Character.isJavaIdentifierStart(first)) return false;
        for (int i = Character.charCount(first); i < name.length();) {
            int cp = Character.codePointAt(name, i);
            if (!Character.isJavaIdentifierPart(cp)) return false;
            i += Character.charCount(cp);
        }
        return true;
    }

    public static boolean isName(CharSequence name) { return isName(name, latest()); }

    public static boolean isName(CharSequence name, SourceVersion version) {
        if (name == null || name.length() == 0) return false;
        String value = name.toString();
        int start = 0;
        while (start <= value.length()) {
            int dot = value.indexOf('.', start);
            int end = dot < 0 ? value.length() : dot;
            String part = value.substring(start, end);
            if (!isIdentifier(part) || isKeyword(part, version)) return false;
            if (dot < 0) return true;
            start = dot + 1;
        }
        return false;
    }

    public static boolean isKeyword(CharSequence value) { return isKeyword(value, latest()); }

    public static boolean isKeyword(CharSequence value, SourceVersion version) {
        if (value == null) return false;
        String word = value.toString();
        if (BASE_KEYWORDS.contains(word)) return true;
        int release = version == null ? latest().ordinal() : version.ordinal();
        if (release >= RELEASE_10.ordinal() && "var".equals(word)) return true;
        if (release >= RELEASE_14.ordinal() && "yield".equals(word)) return true;
        if (release >= RELEASE_16.ordinal() && "record".equals(word)) return true;
        if (release >= RELEASE_17.ordinal()
                && ("sealed".equals(word) || "permits".equals(word)
                || "non-sealed".equals(word))) return true;
        return false;
    }
}
