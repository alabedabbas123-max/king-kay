package brut.androlib.src;

import brut.androlib.exceptions.AndrolibException;

import com.android.tools.smali.baksmali.Baksmali;
import com.android.tools.smali.baksmali.BaksmaliOptions;
import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.analysis.InlineMethodResolver;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedOdexFile;
import com.android.tools.smali.dexlib2.iface.DexFile;
import com.android.tools.smali.dexlib2.iface.MultiDexContainer;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * بديل Android منخفض الذاكرة لـ Apktool SmaliDecoder.
 *
 * الإصدار المكتبي يشغّل حتى ستة خيوط Baksmali في الوقت نفسه، وهذا يرفع الذاكرة بشدة
 * وقد يجعل Android يقتل العملية بلا استثناء يمكن عرضه. هذا التنفيذ يفك كل DEX بخيط
 * واحد، بينما يتولى ApktoolEngine ملفات classes*.dex بالتتابع ويحذف كل ملف خام بعده.
 */
public final class SmaliDecoder {
    public static final boolean ANDROID_LOW_MEMORY = true;
    private static final int ANDROID_SMALI_THREADS = 1;

    private SmaliDecoder() {}

    public static DexFile decode(File input, File outDir, String dexName,
                                 boolean debugInfo, int apiLevel)
            throws AndrolibException {
        try {
            DexBackedDexFile dex = load(input, dexName, apiLevel);
            if (dex.supportsOptimizedOpcodes()) {
                throw new AndrolibException(
                        "لا يمكن فك ODEX محسّن مباشرة دون deodex: " + dexName);
            }

            BaksmaliOptions options = new BaksmaliOptions();
            options.deodex = false;
            options.implicitReferences = false;
            options.parameterRegisters = true;
            options.localsDirective = true;
            options.sequentialLabels = true;
            options.debugInfo = debugInfo;
            options.codeOffsets = false;
            options.accessorComments = false;
            options.registerInfo = 0;
            if (dex instanceof DexBackedOdexFile) {
                options.inlineResolver = InlineMethodResolver.createInlineMethodResolver(
                        ((DexBackedOdexFile) dex).getOdexVersion());
            }

            if (!outDir.isDirectory() && !outDir.mkdirs()) {
                throw new AndrolibException("تعذّر إنشاء مجلد smali: " + outDir);
            }
            boolean ok = Baksmali.disassembleDexFile(
                    dex, outDir, ANDROID_SMALI_THREADS, options);
            if (!ok) {
                throw new AndrolibException("فشل Baksmali في فك " + dexName);
            }
            return dex;
        } catch (IOException io) {
            throw new AndrolibException(io);
        }
    }

    private static DexBackedDexFile load(File input, String dexName, int apiLevel)
            throws IOException, AndrolibException {
        Opcodes opcodes = apiLevel > 0 ? Opcodes.forApi(apiLevel) : null;
        if (input.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".dex")) {
            return DexFileFactory.loadDexFile(input, opcodes);
        }

        MultiDexContainer<? extends DexBackedDexFile> container =
                DexFileFactory.loadDexContainer(input, opcodes);
        List<String> names = container.getDexEntryNames();
        MultiDexContainer.DexEntry<? extends DexBackedDexFile> entry =
                container.getEntry(dexName);
        if (entry == null && names.size() == 1) entry = container.getEntry(names.get(0));
        if (entry == null) {
            throw new AndrolibException("DEX غير موجود داخل الحزمة: " + dexName);
        }
        return entry.getDexFile();
    }
}
