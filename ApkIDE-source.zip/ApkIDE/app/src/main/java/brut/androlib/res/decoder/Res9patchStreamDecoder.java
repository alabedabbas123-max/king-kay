/*
 * Android-compatible replacement for Apktool 2.9.3 Res9patchStreamDecoder.
 * Original algorithm: Apache-2.0, Apktool project.
 */
package brut.androlib.res.decoder;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;

import brut.androlib.exceptions.AndrolibException;
import brut.androlib.exceptions.CantFind9PatchChunkException;
import brut.androlib.res.data.ninepatch.NinePatchData;
import brut.androlib.res.data.ninepatch.OpticalInset;
import brut.util.ExtDataInput;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInput;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * يفك Nine-Patch المترجم باستعمال android.graphics بدلاً من java.awt/ImageIO
 * غير الموجودين على Android. اسم الحزمة مطابق لكلاس Apktool عمداً؛ مهمة Gradle
 * patchApktoolForAndroid تحذف الكلاس المكتبي من JAR قبل DEX لمنع التعارض.
 */
public class Res9patchStreamDecoder implements ResStreamDecoder {
    /** يفحصه ToolchainVerifier كي لا يقبل نسخة Apktool المكتبية بالخطأ. */
    public static final boolean ANDROID_COMPATIBLE = true;

    @Override
    public void decode(InputStream in, OutputStream out) throws AndrolibException {
        Bitmap source = null;
        Bitmap bordered = null;
        try {
            byte[] data = readAll(in);
            if (data.length == 0) return;

            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inScaled = false;
            options.inPreferredConfig = Bitmap.Config.ARGB_8888;
            source = BitmapFactory.decodeByteArray(data, 0, data.length, options);
            if (source == null) throw new IOException("Android BitmapFactory رفض ملف PNG");

            int w = source.getWidth(), h = source.getHeight();
            if (w <= 0 || h <= 0) throw new IOException("أبعاد PNG غير صالحة: " + w + "x" + h);
            bordered = Bitmap.createBitmap(w + 2, h + 2, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bordered);
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            paint.setDither(false);
            canvas.drawBitmap(source, 1f, 1f, paint);

            NinePatchData np = getNinePatch(data);
            drawHLine(bordered, h + 1, np.padLeft + 1, w - np.padRight, NP_COLOR);
            drawVLine(bordered, w + 1, np.padTop + 1, h - np.padBottom, NP_COLOR);

            int[] xDivs = np.xDivs;
            if (xDivs.length == 0) {
                drawHLine(bordered, 0, 1, w, NP_COLOR);
            } else {
                validatePairs(xDivs, w, "xDivs");
                for (int i = 0; i < xDivs.length; i += 2)
                    drawHLine(bordered, 0, xDivs[i] + 1, xDivs[i + 1], NP_COLOR);
            }

            int[] yDivs = np.yDivs;
            if (yDivs.length == 0) {
                drawVLine(bordered, 0, 1, h, NP_COLOR);
            } else {
                validatePairs(yDivs, h, "yDivs");
                for (int i = 0; i < yDivs.length; i += 2)
                    drawVLine(bordered, 0, yDivs[i] + 1, yDivs[i + 1], NP_COLOR);
            }

            try {
                OpticalInset oi = getOpticalInset(data);
                for (int i = 0; i < clamp(oi.layoutBoundsLeft, w); i++)
                    bordered.setPixel(1 + i, h + 1, OI_COLOR);
                for (int i = 0; i < clamp(oi.layoutBoundsRight, w); i++)
                    bordered.setPixel(w - i, h + 1, OI_COLOR);
                for (int i = 0; i < clamp(oi.layoutBoundsTop, h); i++)
                    bordered.setPixel(w + 1, 1 + i, OI_COLOR);
                for (int i = 0; i < clamp(oi.layoutBoundsBottom, h); i++)
                    bordered.setPixel(w + 1, h - i, OI_COLOR);
            } catch (CantFind9PatchChunkException ignored) {
                // npLb اختياري.
            }

            if (!bordered.compress(Bitmap.CompressFormat.PNG, 100, out))
                throw new IOException("فشل Android PNG encoder");
            out.flush();
        } catch (IOException | NullPointerException | IllegalArgumentException ex) {
            throw new AndrolibException("فشل فك Nine-Patch عبر Android: " + ex.getMessage(), ex);
        } finally {
            if (source != null && !source.isRecycled()) source.recycle();
            if (bordered != null && !bordered.isRecycled()) bordered.recycle();
        }
    }

    private static byte[] readAll(InputStream in) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(32 * 1024);
        byte[] buffer = new byte[32 * 1024];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        return out.toByteArray();
    }

    private NinePatchData getNinePatch(byte[] data) throws AndrolibException, IOException {
        ExtDataInput input = new ExtDataInput(new ByteArrayInputStream(data));
        findChunk(input, NP_CHUNK_TYPE);
        return NinePatchData.decode(input);
    }

    private OpticalInset getOpticalInset(byte[] data) throws AndrolibException, IOException {
        ExtDataInput input = new ExtDataInput(new ByteArrayInputStream(data));
        findChunk(input, OI_CHUNK_TYPE);
        return OpticalInset.decode(input);
    }

    /** ينتقل إلى أول بايت من بيانات chunk بعد length/type وفق تنسيق PNG. */
    private void findChunk(DataInput input, int magic) throws AndrolibException, IOException {
        input.skipBytes(8); // PNG signature
        while (true) {
            int size;
            try {
                size = input.readInt();
            } catch (IOException e) {
                throw new CantFind9PatchChunkException("لا توجد بيانات Nine-Patch مترجمة", e);
            }
            if (size < 0 || size > MAX_CHUNK)
                throw new AndrolibException("حجم PNG chunk غير آمن: " + size);
            int type = input.readInt();
            if (type == magic) return;
            skipFully(input, size + 4); // data + CRC
        }
    }

    private static void skipFully(DataInput in, int count) throws IOException {
        int remaining = count;
        while (remaining > 0) {
            int skipped = in.skipBytes(remaining);
            if (skipped <= 0) throw new IOException("PNG chunk مبتور");
            remaining -= skipped;
        }
    }

    private static void validatePairs(int[] values, int max, String name) throws AndrolibException {
        if ((values.length & 1) != 0) throw new AndrolibException(name + " يجب أن يحوي أزواجاً");
        for (int v : values) if (v < 0 || v > max)
            throw new AndrolibException(name + " خارج أبعاد الصورة: " + v + "/" + max);
    }

    private static int clamp(int value, int max) { return Math.max(0, Math.min(value, max)); }

    private static void drawHLine(Bitmap image, int y, int x1, int x2, int color) {
        int from = Math.max(0, x1), to = Math.min(image.getWidth() - 1, x2);
        if (y < 0 || y >= image.getHeight()) return;
        for (int x = from; x <= to; x++) image.setPixel(x, y, color);
    }

    private static void drawVLine(Bitmap image, int x, int y1, int y2, int color) {
        int from = Math.max(0, y1), to = Math.min(image.getHeight() - 1, y2);
        if (x < 0 || x >= image.getWidth()) return;
        for (int y = from; y <= to; y++) image.setPixel(x, y, color);
    }

    private static final int NP_CHUNK_TYPE = 0x6e705463; // npTc
    private static final int OI_CHUNK_TYPE = 0x6e704c62; // npLb
    private static final int NP_COLOR = 0xff000000;
    private static final int OI_COLOR = 0xffff0000;
    private static final int MAX_CHUNK = 64 * 1024 * 1024;
}
