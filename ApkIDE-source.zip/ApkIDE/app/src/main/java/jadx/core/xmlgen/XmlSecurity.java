package jadx.core.xmlgen;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;

import jadx.core.deobf.NameMapper;
import jadx.core.utils.Utils;

/**
 * بديل Jadx متوافق مع Android لـ XmlSecurity.
 *
 * تطبيق Android (Apache Harmony) لا يدعم خصائص Xerces المكتبية كلها، ومنها
 * disallow-doctype-decl. Jadx الأصلي يجمع ضبط الخصائص في try واحد ثم يرمي من
 * static initializer عند أول خاصية غير مدعومة، فتفشل عملية الفك كلها. هنا تُطبق
 * كل حماية مدعومة بصورة مستقلة، ولا تصبح خاصية اختيارية سبباً لتعطيل Jadx.
 */
public final class XmlSecurity {
    public static final boolean ANDROID_COMPATIBLE = true;

    private static final boolean DISABLE_CHECKS =
            Utils.getEnvVarBool("JADX_DISABLE_XML_SECURITY", false);
    private static final DocumentBuilderFactory DBF_INSTANCE = buildDBF();

    private XmlSecurity() {}

    public static DocumentBuilderFactory getDBF() {
        return DBF_INSTANCE;
    }

    public static String verifyAppPackage(String appPackage) {
        if (DISABLE_CHECKS || NameMapper.isValidFullIdentifier(appPackage)) {
            return appPackage;
        }
        return "INVALID_PACKAGE";
    }

    private static DocumentBuilderFactory buildDBF() {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        if (DISABLE_CHECKS) return dbf;

        // Android يدعم مجموعة تختلف حسب إصدار النظام؛ لا تجعل عدم دعم خاصية
        // واحدة يلغي الخصائص الأخرى أو يفجّر <clinit> بـ ExceptionInInitializerError.
        feature(dbf, XMLConstants.FEATURE_SECURE_PROCESSING, true);
        feature(dbf, "http://apache.org/xml/features/disallow-doctype-decl", true);
        feature(dbf, "http://apache.org/xml/features/nonvalidating/load-external-dtd", false);
        feature(dbf, "http://xml.org/sax/features/external-general-entities", false);
        feature(dbf, "http://xml.org/sax/features/external-parameter-entities", false);
        feature(dbf, "http://apache.org/xml/features/dom/create-entity-ref-nodes", false);
        attribute(dbf, "http://javax.xml.XMLConstants/property/accessExternalDTD", "");
        attribute(dbf, "http://javax.xml.XMLConstants/property/accessExternalSchema", "");
        try { dbf.setXIncludeAware(false); } catch (Throwable ignored) {}
        try { dbf.setExpandEntityReferences(false); } catch (Throwable ignored) {}
        return dbf;
    }

    private static void feature(DocumentBuilderFactory dbf, String name, boolean value) {
        try { dbf.setFeature(name, value); } catch (Throwable ignored) {}
    }

    private static void attribute(DocumentBuilderFactory dbf, String name, Object value) {
        try { dbf.setAttribute(name, value); } catch (Throwable ignored) {}
    }
}
