package jadx.core.utils.android;

import java.io.InputStream;
import java.io.OutputStream;

import brut.androlib.exceptions.AndrolibException;
import brut.androlib.exceptions.CantFind9PatchChunkException;
import jadx.core.utils.exceptions.JadxRuntimeException;

/** بديل Android لنسخة Jadx التي تعتمد java.awt وjavax.imageio. */
public class Res9patchStreamDecoder {
    public static final boolean ANDROID_COMPATIBLE = true;

    public boolean decode(InputStream in, OutputStream out) {
        try {
            new brut.androlib.res.decoder.Res9patchStreamDecoder().decode(in, out);
            return true;
        } catch (CantFind9PatchChunkException notNinePatch) {
            return false;
        } catch (AndrolibException error) {
            throw new JadxRuntimeException("Android 9patch image decode error", error);
        }
    }
}
