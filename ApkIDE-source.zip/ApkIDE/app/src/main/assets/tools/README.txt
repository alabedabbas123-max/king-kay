هذا المجلد مخصص فقط لأدوات ELF اختيارية يضيفها المطوّر.

في Android 10+ قد يمنع النظام تنفيذ الملفات من filesDir حتى بعد chmod.
لذلك يعتمد الإصدار 1.2.1 على:
- jniLibs/arm64-v8a/libaapt2.so للأداة الأصلية الضرورية.
- JavaZipAligner الداخلي بدلاً من شحن libzipalign.so.
- ToolInstaller لتنزيل android.jar وملفات JAR غير التنفيذية إلى مساحة التطبيق.
