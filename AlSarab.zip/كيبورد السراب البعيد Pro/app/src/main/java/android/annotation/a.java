package android.annotation;

/* JADX INFO: compiled from:   mAutoCorrectOn= */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: ARITH (r9 I:long) = (r9 I:long) / (r4 I:long), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String a() {
        /*
            r1 = this;
            long r9 = r9 / r4
            float r15 = r15 % r9
            float r12 = r12 + r14
        */
        throw new UnsupportedOperationException("Method not decompiled: android.annotation.a.a():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: ARITH (r12 I:??[int, boolean]) = (r0 I:??[int, boolean, short, byte, char]) | (23158(0x5a76, float:3.2451E-41) ??[int, float, short, byte, char]), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int b() {
        /*
            r1 = this;
            r12 = r0 | 23158(0x5a76, float:3.2451E-41)
            int r2 = 0 - r13
        */
        throw new UnsupportedOperationException("Method not decompiled: android.annotation.a.b():int");
    }
}
