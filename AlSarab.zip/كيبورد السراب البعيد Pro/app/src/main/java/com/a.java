package com;

/* JADX INFO: compiled from: Buy */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: IF  (r0 I:??[int, byte, short, char]) > (r5 I:??[int, byte, short, char])  -> ?, expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String a() {
        /*
            r1 = this;
            if (r0 > r5) goto LB_55f8
            int r13 = r13 << r12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.a.a():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: CMP_G (r227 I:int) = (r139 I:float), (r85 I:float), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int b() {
        /*
            r1 = this;
            int r227 = (r139 > r85 ? 1 : (r139 == r85 ? 0 : -1))
            long r1 = (long) r5
        */
        throw new UnsupportedOperationException("Method not decompiled: com.a.b():int");
    }
}
