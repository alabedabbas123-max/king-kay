package com.android.inputmethod.latin.spellcheck;

import com.android.inputmethod.latin.Dictionary;
import com.android.inputmethod.latin.ProximityInfo;

/* JADX INFO: loaded from: classes.dex */
public class DictAndProximity {
    public final Dictionary mDictionary;
    public final ProximityInfo mProximityInfo;

    public DictAndProximity(Dictionary dictionary, ProximityInfo proximityInfo) {
        this.mDictionary = dictionary;
        this.mProximityInfo = proximityInfo;
    }
}
