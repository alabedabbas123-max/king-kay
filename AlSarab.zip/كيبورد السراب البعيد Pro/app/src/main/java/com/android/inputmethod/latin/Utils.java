package com.android.inputmethod.latin;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.inputmethodservice.InputMethodService;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.text.TextUtils;
import android.util.Log;
import android.view.inputmethod.EditorInfo;
import com.android.inputmethod.voice.VoiceInput;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import inputmethod.latin.perfectkeyboard.R;
/* JADX INFO: loaded from: classes.dex */
public class Utils {
    private static final int FULL_WORD_MULTIPLIER = 2;
    private static final int MAX_INITIAL_SCORE = 255;
    private static final int MINIMUM_SAFETY_NET_CHAR_LENGTH = 4;
    private static final int S_INT_MAX = Integer.MAX_VALUE;
    private static final int TYPED_LETTER_MULTIPLIER = 2;
    private static final String TAG = Utils.class.getSimpleName();
    private static boolean DBG = DictionaryEditor.DEBUG;
    private static boolean DBG_EDIT_DISTANCE = false;

    private Utils() {
    }

    public static void cancelTask(AsyncTask<?, ?, ?> task, boolean mayInterruptIfRunning) {
        if (task != null && task.getStatus() != AsyncTask.Status.FINISHED) {
            task.cancel(mayInterruptIfRunning);
        }
    }

    public static class GCUtils {
        private static final long GC_INTERVAL = 1000;
        public static final int GC_TRY_COUNT = 2;
        public static final int GC_TRY_LOOP_MAX = 5;
        private int mGCTryCount = 0;
        private static final String GC_TAG = GCUtils.class.getSimpleName();
        private static GCUtils sInstance = new GCUtils();

        public static GCUtils getInstance() {
            return sInstance;
        }

        public void reset() {
            this.mGCTryCount = 0;
        }

        public boolean tryGCOrWait(String metaData, Throwable t) {
            if (this.mGCTryCount == 0) {
                System.gc();
            }
            int i = this.mGCTryCount + 1;
            this.mGCTryCount = i;
            if (i > 2) {
                LatinImeLogger.logOnException(metaData, t);
                return false;
            }
            try {
                Thread.sleep(GC_INTERVAL);
                return true;
            } catch (InterruptedException e) {
                Log.e(GC_TAG, "Sleep was interrupted.");
                LatinImeLogger.logOnException(metaData, t);
                return false;
            }
        }
    }

    static class RingCharBuffer {
        static final int BUFSIZE = 20;
        private static final int INVALID_COORDINATE = -2;
        private static final char PLACEHOLDER_DELIMITER_CHAR = 65532;
        private static RingCharBuffer sRingCharBuffer = new RingCharBuffer();
        private InputMethodService mContext;
        private boolean mEnabled = false;
        private boolean mUsabilityStudy = false;
        private int mEnd = 0;
        int mLength = 0;
        private char[] mCharBuf = new char[20];
        private int[] mXBuf = new int[20];
        private int[] mYBuf = new int[20];

        private RingCharBuffer() {
        }

        public static RingCharBuffer getInstance() {
            return sRingCharBuffer;
        }

        public static RingCharBuffer init(InputMethodService context, boolean enabled, boolean usabilityStudy) {
            sRingCharBuffer.mContext = context;
            sRingCharBuffer.mEnabled = enabled || usabilityStudy;
            sRingCharBuffer.mUsabilityStudy = usabilityStudy;
            UsabilityStudyLogUtils.getInstance().init(context);
            return sRingCharBuffer;
        }

        private int normalize(int in) {
            int ret = in % 20;
            return ret < 0 ? ret + 20 : ret;
        }

        public void push(char c, int x, int y) {
            if (this.mEnabled) {
                if (this.mUsabilityStudy) {
                    UsabilityStudyLogUtils.getInstance().writeChar(c, x, y);
                }
                this.mCharBuf[this.mEnd] = c;
                this.mXBuf[this.mEnd] = x;
                this.mYBuf[this.mEnd] = y;
                this.mEnd = normalize(this.mEnd + 1);
                if (this.mLength < 20) {
                    this.mLength++;
                }
            }
        }

        public char pop() {
            if (this.mLength < 1) {
                return PLACEHOLDER_DELIMITER_CHAR;
            }
            this.mEnd = normalize(this.mEnd - 1);
            this.mLength--;
            return this.mCharBuf[this.mEnd];
        }

        public char getBackwardNthChar(int n) {
            return (this.mLength <= n || n < 0) ? PLACEHOLDER_DELIMITER_CHAR : this.mCharBuf[normalize((this.mEnd - n) - 1)];
        }

        public int getPreviousX(char c, int back) {
            int index = normalize((this.mEnd + INVALID_COORDINATE) - back);
            return (this.mLength <= back || Character.toLowerCase(c) != Character.toLowerCase(this.mCharBuf[index])) ? INVALID_COORDINATE : this.mXBuf[index];
        }

        public int getPreviousY(char c, int back) {
            int index = normalize((this.mEnd + INVALID_COORDINATE) - back);
            return (this.mLength <= back || Character.toLowerCase(c) != Character.toLowerCase(this.mCharBuf[index])) ? INVALID_COORDINATE : this.mYBuf[index];
        }

        public String getLastWord(int ignoreCharCount) {
            StringBuilder sb = new StringBuilder();
            int i = ignoreCharCount;
            while (i < this.mLength) {
                if (!((DictionaryEditor) this.mContext).isWordSeparator(this.mCharBuf[normalize((this.mEnd - 1) - i)])) {
                    break;
                }
                i++;
            }
            while (i < this.mLength) {
                char c = this.mCharBuf[normalize((this.mEnd - 1) - i)];
                if (((DictionaryEditor) this.mContext).isWordSeparator(c)) {
                    break;
                }
                sb.append(c);
                i++;
            }
            return sb.reverse().toString();
        }

        public void reset() {
            this.mLength = 0;
        }
    }

    public static int editDistance(CharSequence s, CharSequence t) {
        if (s == null || t == null) {
            throw new IllegalArgumentException("editDistance: Arguments should not be null.");
        }
        int sl = s.length();
        int tl = t.length();
        int[][] dp = (int[][]) Array.newInstance((Class<?>) Integer.TYPE, sl + 1, tl + 1);
        for (int i = 0; i <= sl; i++) {
            dp[i][0] = i;
        }
        for (int j = 0; j <= tl; j++) {
            dp[0][j] = j;
        }
        for (int i2 = 0; i2 < sl; i2++) {
            for (int j2 = 0; j2 < tl; j2++) {
                char sc = Character.toLowerCase(s.charAt(i2));
                char tc = Character.toLowerCase(t.charAt(j2));
                int cost = sc == tc ? 0 : 1;
                dp[i2 + 1][j2 + 1] = Math.min(dp[i2][j2 + 1] + 1, Math.min(dp[i2 + 1][j2] + 1, dp[i2][j2] + cost));
                if (i2 > 0 && j2 > 0 && sc == Character.toLowerCase(t.charAt(j2 - 1)) && tc == Character.toLowerCase(s.charAt(i2 - 1))) {
                    dp[i2 + 1][j2 + 1] = Math.min(dp[i2 + 1][j2 + 1], dp[i2 - 1][j2 - 1] + cost);
                }
            }
        }
        if (DBG_EDIT_DISTANCE) {
            Log.d(TAG, "editDistance:" + ((Object) s) + "," + ((Object) t));
            for (int i3 = 0; i3 < dp.length; i3++) {
                StringBuffer sb = new StringBuffer();
                for (int j3 = 0; j3 < dp[i3].length; j3++) {
                    sb.append(dp[i3][j3]).append(',');
                }
                Log.d(TAG, String.valueOf(i3) + VoiceInput.AlternatesBundleKeys.SPAN_KEY_DELIMITER + sb.toString());
            }
        }
        return dp[sl][tl];
    }

    public static String getStackTrace() {
        StringBuilder sb = new StringBuilder();
        try {
            throw new RuntimeException();
        } catch (RuntimeException e) {
            StackTraceElement[] frames = e.getStackTrace();
            for (int j = 1; j < frames.length; j++) {
                sb.append(String.valueOf(frames[j].toString()) + "\n");
            }
            return sb.toString();
        }
    }

    public static double calcNormalizedScore(CharSequence before, CharSequence after, int score) {
        int beforeLength = before.length();
        int afterLength = after.length();
        if (beforeLength == 0 || afterLength == 0) {
            return 0.0d;
        }
        int distance = editDistance(before, after);
        int spaceCount = 0;
        for (int i = 0; i < afterLength; i++) {
            if (after.charAt(i) == ' ') {
                spaceCount++;
            }
        }
        if (spaceCount == afterLength) {
            return 0.0d;
        }
        double maximumScore = score == S_INT_MAX ? 2.147483647E9d : 255.0d * Math.pow(2.0d, Math.min(beforeLength, afterLength - spaceCount)) * 2.0d;
        double weight = 1.0d - (((double) distance) / ((double) afterLength));
        return (((double) score) / maximumScore) * weight;
    }

    public static class UsabilityStudyLogUtils {
        private static final String FILENAME = "log.txt";
        private static final String USABILITY_TAG = UsabilityStudyLogUtils.class.getSimpleName();
        private static final UsabilityStudyLogUtils sInstance = new UsabilityStudyLogUtils();
        private final Date mDate = new Date();
        private final SimpleDateFormat mDateFormat = new SimpleDateFormat("dd MMM HH:mm:ss.SSS");
        private File mDirectory;
        private File mFile;
        private InputMethodService mIms;
        private final Handler mLoggingHandler;
        private PrintWriter mWriter;

        private UsabilityStudyLogUtils() {
            HandlerThread handlerThread = new HandlerThread("UsabilityStudyLogUtils logging task", 10);
            handlerThread.start();
            this.mLoggingHandler = new Handler(handlerThread.getLooper());
        }

        public static UsabilityStudyLogUtils getInstance() {
            return sInstance;
        }

        public void init(InputMethodService ims) {
            this.mIms = ims;
            this.mDirectory = ims.getFilesDir();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void createLogFileIfNotExist() {
            if ((this.mFile == null || !this.mFile.exists()) && this.mDirectory != null && this.mDirectory.exists()) {
                try {
                    this.mWriter = getPrintWriter(this.mDirectory, FILENAME, false);
                } catch (IOException e) {
                    Log.e(USABILITY_TAG, "Can't create log file.");
                }
            }
        }

        public void writeBackSpace() {
            getInstance().write("<backspace>\t0\t0");
        }

        public void writeChar(char c, int x, int y) {
            String inputChar = String.valueOf(c);
            switch (c) {
                case '\t':
                    inputChar = "<tab>";
                    break;
                case '\n':
                    inputChar = "<enter>";
                    break;
                case Suggest.APPROX_MAX_WORD_LENGTH /* 32 */:
                    inputChar = "<space>";
                    break;
            }
            getInstance().write(String.valueOf(inputChar) + "\t" + x + "\t" + y);
        }

        public void write(final String log) {
            this.mLoggingHandler.post(new Runnable() { // from class: com.android.inputmethod.latin.Utils.UsabilityStudyLogUtils.1
                @Override // java.lang.Runnable
                public void run() {
                    UsabilityStudyLogUtils.this.createLogFileIfNotExist();
                    long currentTime = System.currentTimeMillis();
                    UsabilityStudyLogUtils.this.mDate.setTime(currentTime);
                    String printString = String.format("%s\t%d\t%s\n", UsabilityStudyLogUtils.this.mDateFormat.format(UsabilityStudyLogUtils.this.mDate), Long.valueOf(currentTime), log);
                    if (DictionaryEditor.DEBUG) {
                        Log.d(UsabilityStudyLogUtils.USABILITY_TAG, "Write: " + log);
                    }
                    UsabilityStudyLogUtils.this.mWriter.print(printString);
                }
            });
        }

        public void printAll() {
            this.mLoggingHandler.post(new Runnable() { // from class: com.android.inputmethod.latin.Utils.UsabilityStudyLogUtils.2
                @Override // java.lang.Runnable
                public void run() {
                    UsabilityStudyLogUtils.this.mWriter.flush();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader br = UsabilityStudyLogUtils.this.getBufferedReader();
                    while (true) {
                        try {
                            try {
                                String line = br.readLine();
                                if (line == null) {
                                    break;
                                }
                                sb.append('\n');
                                sb.append(line);
                            } catch (IOException e) {
                                Log.e(UsabilityStudyLogUtils.USABILITY_TAG, "Can't read log file.");
                                if (DictionaryEditor.DEBUG) {
                                    Log.d(UsabilityStudyLogUtils.USABILITY_TAG, "output all logs\n" + sb.toString());
                                }
                                UsabilityStudyLogUtils.this.mIms.getCurrentInputConnection().commitText(sb.toString(), 0);
                                try {
                                    br.close();
                                    return;
                                } catch (IOException e2) {
                                    return;
                                }
                            }
                        } finally {
                            if (DictionaryEditor.DEBUG) {
                                Log.d(UsabilityStudyLogUtils.USABILITY_TAG, "output all logs\n" + sb.toString());
                            }
                            UsabilityStudyLogUtils.this.mIms.getCurrentInputConnection().commitText(sb.toString(), 0);
                            try {
                                br.close();
                            } catch (IOException e3) {
                            }
                        }
                    }
                }
            });
        }

        public void clearAll() {
            this.mLoggingHandler.post(new Runnable() { // from class: com.android.inputmethod.latin.Utils.UsabilityStudyLogUtils.3
                @Override // java.lang.Runnable
                public void run() {
                    if (UsabilityStudyLogUtils.this.mFile != null && UsabilityStudyLogUtils.this.mFile.exists()) {
                        if (DictionaryEditor.DEBUG) {
                            Log.d(UsabilityStudyLogUtils.USABILITY_TAG, "Delete log file.");
                        }
                        UsabilityStudyLogUtils.this.mFile.delete();
                        UsabilityStudyLogUtils.this.mWriter.close();
                    }
                }
            });
        }

        /* JADX INFO: Access modifiers changed from: private */
        public BufferedReader getBufferedReader() {
            createLogFileIfNotExist();
            try {
                return new BufferedReader(new FileReader(this.mFile));
            } catch (FileNotFoundException e) {
                return null;
            }
        }

        private PrintWriter getPrintWriter(File dir, String filename, boolean renew) throws IOException {
            this.mFile = new File(dir, filename);
            if (this.mFile.exists() && renew) {
                this.mFile.delete();
            }
            return new PrintWriter((OutputStream) new FileOutputStream(this.mFile), true);
        }
    }

    public static boolean containsInCsv(String key, String csv) {
        if (csv == null) {
            return false;
        }
        for (String option : csv.split(",")) {
            if (option.equals(key)) {
                return true;
            }
        }
        return false;
    }

    public static boolean inPrivateImeOptions(String packageName, String key, EditorInfo editorInfo) {
        if (editorInfo == null) {
            return false;
        }
        if (packageName != null) {
            key = String.valueOf(packageName) + "." + key;
        }
        return containsInCsv(key, editorInfo.privateImeOptions);
    }

    public static int getMainDictionaryResourceId(Resources res) {
        return res.getIdentifier("main", "raw", DictionaryEditor.PackageName);
    }
    
    public static void loadNativeLibrary() {
        try {
            System.loadLibrary("jni_latinime_moded");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Could not load native library jni_latinime_moded");
        }
    }

    public static AssetFileDescriptor openRawResourceFd(Resources res, int fallbackResId) {
        try {
            AssetFileDescriptor fd = res.openRawResourceFd(fallbackResId);
            return fd;
        } catch (Resources.NotFoundException e) {
            Log.e(TAG, "Could not load resourecesFD");
            return null;
        }
    }

    public static boolean equalsIgnoreCase(char a, char b) {
        return a == b || Character.toLowerCase(a) == Character.toLowerCase(b) || Character.toUpperCase(a) == Character.toUpperCase(b);
    }

    public static boolean equalsIgnoreCase(CharSequence a, CharSequence b) {
        if (a == b) {
            return true;
        }
        if (a == null || b == null) {
            return false;
        }
        int length = a.length();
        if (length != b.length()) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (!equalsIgnoreCase(a.charAt(i), b.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static boolean equalsIgnoreCase(CharSequence a, char[] b, int offset, int length) {
        if (offset < 0 || length < 0 || length > b.length - offset) {
            throw new IndexOutOfBoundsException("array.length=" + b.length + " offset=" + offset + " length=" + length);
        }
        if (a == null) {
            return length == 0;
        }
        if (a.length() != length) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (!equalsIgnoreCase(a.charAt(i), b[offset + i])) {
                return false;
            }
        }
        return true;
    }

    public static float getDipScale(Context context) {
        float scale = context.getResources().getDisplayMetrics().density;
        return scale;
    }

    public static int dipToPixel(float scale, int dip) {
        return (int) (((double) (dip * scale)) + 0.5d);
    }

    public static void removeDupes(ArrayList<CharSequence> suggestions) {
        if (suggestions.size() >= 2) {
            int i = 1;
            while (i < suggestions.size()) {
                CharSequence cur = suggestions.get(i);
                int j = 0;
                while (true) {
                    if (j >= i) {
                        break;
                    }
                    CharSequence previous = suggestions.get(j);
                    if (!TextUtils.equals(cur, previous)) {
                        j++;
                    } else {
                        removeFromSuggestions(suggestions, i);
                        i--;
                        break;
                    }
                }
                i++;
            }
        }
    }

    private static void removeFromSuggestions(ArrayList<CharSequence> suggestions, int index) {
        CharSequence garbage = suggestions.remove(index);
        if (garbage instanceof StringBuilder) {
            StringBuilderPool.recycle((StringBuilder) garbage);
        }
    }

    public static String getShortDisplayLanguage(Locale locale) {
        return toTitleCase(locale.getLanguage(), locale);
    }

    public static String toTitleCase(String s, Locale locale) {
        return s.length() <= 1 ? s : String.valueOf(s.toUpperCase(locale).charAt(0)) + s.substring(1);
    }
}
