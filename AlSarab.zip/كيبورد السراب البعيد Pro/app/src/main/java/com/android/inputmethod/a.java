package com.android.inputmethod;

/* JADX INFO: compiled from: CLASS_SuggestionSpan */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: ARITH (r4 I:long) = (r4 I:long) ^ (r5 I:long), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String a() {
        /*
            r1 = this;
            long r4 = r4 ^ r5
            int r202 = r216 >>> (-65)
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.inputmethod.a.a():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: MOVE (r6 I:??[long, double]) = (r11 I:??[long, double]), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int b() {
        /*
            r1 = this;
            r6 = r11
            int r113 = r147 >>> (-124)
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.inputmethod.a.b():int");
    }
}
