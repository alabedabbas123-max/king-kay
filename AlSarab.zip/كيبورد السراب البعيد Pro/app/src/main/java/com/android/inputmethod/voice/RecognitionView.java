package com.android.inputmethod.voice;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathEffect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.android.inputmethod.latin.DictionaryEditor;
import inputmethod.latin.perfectkeyboard.R;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public class RecognitionView {
    private static final int INIT = 0;
    private static final int LISTENING = 1;
    private static final int READY = 3;
    private static final String TAG = "RecognitionView";
    private static final int WORKING = 2;
    private Button mButton;
    private Context mContext;
    private Drawable mError;
    private final Drawable mErrorBorder;
    private ImageView mImage;
    private Drawable mInitializing;
    private TextView mLanguage;
    private final Drawable mListeningBorder;
    private final View mPopupLayout;
    private View mProgress;
    private SoundIndicator mSoundIndicator;
    private TextView mText;
    private View mView;
    private final Drawable mWorkingBorder;
    private int mState = 0;
    private Handler mUiHandler = new Handler();

    public RecognitionView(Context context, View.OnClickListener clickListener) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.mView = inflater.inflate(R.layout.recognition_status, (ViewGroup) null);
        this.mPopupLayout = this.mView.findViewById(R.id.popup_layout);
        Resources r = context.getResources();
        this.mListeningBorder = r.getDrawable(R.drawable.vs_dialog_red);
        this.mWorkingBorder = r.getDrawable(R.drawable.vs_dialog_blue);
        this.mErrorBorder = r.getDrawable(R.drawable.vs_dialog_yellow);
        this.mInitializing = r.getDrawable(R.drawable.mic_slash);
        this.mError = r.getDrawable(R.drawable.caution);
        this.mImage = (ImageView) this.mView.findViewById(R.id.image);
        this.mProgress = this.mView.findViewById(R.id.progress);
        this.mSoundIndicator = (SoundIndicator) this.mView.findViewById(R.id.sound_indicator);
        this.mButton = (Button) this.mView.findViewById(R.id.button);
        this.mButton.setOnClickListener(clickListener);
        this.mText = (TextView) this.mView.findViewById(R.id.text);
        this.mLanguage = (TextView) this.mView.findViewById(R.id.language);
        this.mContext = context;
    }

    public View getView() {
        return this.mView;
    }

    public void restoreState() {
        this.mUiHandler.post(new Runnable() { // from class: com.android.inputmethod.voice.RecognitionView.1
            @Override // java.lang.Runnable
            public void run() {
                if (RecognitionView.this.mState == 2) {
                    ((ProgressBar) RecognitionView.this.mProgress).setIndeterminate(false);
                    ((ProgressBar) RecognitionView.this.mProgress).setIndeterminate(true);
                }
            }
        });
    }

    public void showInitializing() {
        this.mUiHandler.post(new Runnable() { // from class: com.android.inputmethod.voice.RecognitionView.2
            @Override // java.lang.Runnable
            public void run() {
                RecognitionView.this.mState = 0;
                RecognitionView.this.prepareDialog(RecognitionView.this.mContext.getText(R.string.voice_initializing), RecognitionView.this.mInitializing, RecognitionView.this.mContext.getText(R.string.cancel));
            }
        });
    }

    public void showListening() {
        if (DictionaryEditor.DEBUG) {
            Log.d(TAG, "#showListening");
        }
        this.mUiHandler.post(new Runnable() { // from class: com.android.inputmethod.voice.RecognitionView.3
            @Override // java.lang.Runnable
            public void run() {
                RecognitionView.this.mState = 1;
                RecognitionView.this.prepareDialog(RecognitionView.this.mContext.getText(R.string.voice_listening), null, RecognitionView.this.mContext.getText(R.string.cancel));
            }
        });
    }

    public void updateVoiceMeter(float rmsdB) {
        this.mSoundIndicator.setRmsdB(rmsdB);
    }

    public void showError(final String message) {
        this.mUiHandler.post(new Runnable() { // from class: com.android.inputmethod.voice.RecognitionView.4
            @Override // java.lang.Runnable
            public void run() {
                RecognitionView.this.mState = 3;
                RecognitionView.this.prepareDialog(message, RecognitionView.this.mError, RecognitionView.this.mContext.getText(R.string.ok));
            }
        });
    }

    public void showWorking(final ByteArrayOutputStream waveBuffer, final int speechStartPosition, final int speechEndPosition) {
        this.mUiHandler.post(new Runnable() { // from class: com.android.inputmethod.voice.RecognitionView.5
            @Override // java.lang.Runnable
            public void run() {
                RecognitionView.this.mState = 2;
                RecognitionView.this.prepareDialog(RecognitionView.this.mContext.getText(R.string.voice_working), null, RecognitionView.this.mContext.getText(R.string.cancel));
                ShortBuffer buf = ByteBuffer.wrap(waveBuffer.toByteArray()).order(ByteOrder.nativeOrder()).asShortBuffer();
                buf.position(0);
                waveBuffer.reset();
                RecognitionView.this.showWave(buf, speechStartPosition / 2, speechEndPosition / 2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void prepareDialog(CharSequence text, Drawable image, CharSequence btnTxt) {
        switch (this.mState) {
            case 0:
                this.mText.setVisibility(4);
                this.mProgress.setVisibility(8);
                this.mImage.setVisibility(0);
                this.mImage.setImageResource(R.drawable.mic_slash);
                this.mSoundIndicator.setVisibility(8);
                this.mSoundIndicator.stop();
                this.mLanguage.setVisibility(4);
                this.mPopupLayout.setBackgroundDrawable(this.mListeningBorder);
                break;
            case 1:
                this.mText.setVisibility(0);
                this.mText.setText(text);
                this.mProgress.setVisibility(8);
                this.mImage.setVisibility(8);
                this.mSoundIndicator.setVisibility(0);
                this.mSoundIndicator.start();
                this.mLanguage.setVisibility(0);
                Locale locale = new Locale(DictionaryEditor.mInputLocale);
                this.mLanguage.setText(locale.getDisplayName(locale));
                this.mPopupLayout.setBackgroundDrawable(this.mListeningBorder);
                break;
            case 2:
                this.mText.setVisibility(0);
                this.mText.setText(text);
                this.mProgress.setVisibility(0);
                this.mImage.setVisibility(0);
                this.mSoundIndicator.setVisibility(8);
                this.mSoundIndicator.stop();
                this.mLanguage.setVisibility(8);
                this.mPopupLayout.setBackgroundDrawable(this.mWorkingBorder);
                break;
            case 3:
                this.mText.setVisibility(0);
                this.mText.setText(text);
                this.mProgress.setVisibility(8);
                this.mImage.setVisibility(0);
                this.mImage.setImageResource(R.drawable.caution);
                this.mSoundIndicator.setVisibility(8);
                this.mSoundIndicator.stop();
                this.mLanguage.setVisibility(8);
                this.mPopupLayout.setBackgroundDrawable(this.mErrorBorder);
                break;
            default:
                Log.w(TAG, "Unknown state " + this.mState);
                break;
        }
        this.mPopupLayout.requestLayout();
        this.mButton.setText(btnTxt);
    }

    private static int getAverageAbs(ShortBuffer buffer, int start, int i, int npw) {
        int from = start + (i * npw);
        int end = from + npw;
        int total = 0;
        for (int x = from; x < end; x++) {
            total += Math.abs((int) buffer.get(x));
        }
        return total / npw;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showWave(ShortBuffer waveBuffer, int startPosition, int endPosition) {
        int endIndex;
        int w = ((View) this.mImage.getParent()).getWidth();
        int h = ((View) this.mImage.getParent()).getHeight();
        if (w > 0 && h > 0) {
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            Paint paint = new Paint();
            paint.setColor(-1);
            paint.setAntiAlias(true);
            paint.setStyle(Paint.Style.STROKE);
            paint.setAlpha(80);
            PathEffect effect = new CornerPathEffect(3.0f);
            paint.setPathEffect(effect);
            int numSamples = waveBuffer.remaining();
            if (endPosition == 0) {
                endIndex = numSamples;
            } else {
                endIndex = Math.min(endPosition, numSamples);
            }
            int startIndex = startPosition - 2000;
            if (startIndex < 0) {
                startIndex = 0;
            }
            int count = (endIndex - startIndex) / 200;
            float deltaX = (1.0f * w) / count;
            int yMax = h / 2;
            Path path = new Path();
            c.translate(0.0f, yMax);
            float x = 0.0f;
            path.moveTo(0.0f, 0.0f);
            for (int i = 0; i < count; i++) {
                int avabs = getAverageAbs(waveBuffer, startIndex, i, 200);
                int sign = (i & 1) == 0 ? -1 : 1;
                float y = Math.min(yMax, avabs * h * 1.5258789E-4f) * sign;
                path.lineTo(x, y);
                x += deltaX;
                path.lineTo(x, y);
            }
            if (deltaX > 4.0f) {
                paint.setStrokeWidth(2.0f);
            } else {
                paint.setStrokeWidth(Math.max(0, (int) (((double) deltaX) - 0.05d)));
            }
            c.drawPath(path, paint);
            this.mImage.setImageBitmap(b);
        }
    }

    public void finish() {
        this.mUiHandler.post(new Runnable() { // from class: com.android.inputmethod.voice.RecognitionView.6
            @Override // java.lang.Runnable
            public void run() {
                RecognitionView.this.mSoundIndicator.stop();
            }
        });
    }
}
