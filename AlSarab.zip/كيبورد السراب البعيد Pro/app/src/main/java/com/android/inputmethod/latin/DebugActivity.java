package com.android.inputmethod.latin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class DebugActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        String errMsg = "";

        // جلب نص الخطأ الكامل مباشرة بدون أي فلترة أو تعديل
        if (intent != null) {
            String rawError = intent.getStringExtra("error");
            if (rawError != null && !rawError.isEmpty()) {
                errMsg = rawError;
            } else {
                errMsg = "No error details available.";
            }
        }

        final String finalErrorToCopy = errMsg;

        AlertDialog.Builder bld = new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert);

        bld.setTitle("An error occurred");
        bld.setMessage(finalErrorToCopy);
        bld.setCancelable(false);

        // زر نسخ الخطأ: ينقله للحافظة ويبقى في نفس الصفحة دون إغلاق
        bld.setPositiveButton("Copy Error", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    try {
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("Crash Log", finalErrorToCopy);
                        if (clipboard != null) {
                            clipboard.setPrimaryClip(clip);
                            Toast.makeText(DebugActivity.this, "Error text copied to clipboard!", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(DebugActivity.this, "Failed to copy text", Toast.LENGTH_SHORT).show();
                    }
                    // تم إزالة finish() من هنا لمنع إغلاق الشاشة بعد النسخ
                }
            });

        // زر إنهاء التطبيق عند رغبة المستخدم
        bld.setNegativeButton("End Application", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });

        AlertDialog dialog = bld.create();
        dialog.show();
    }
}


/*
import android.app.Activity;
import android.os.Bundle;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import java.io.InputStream;

public class DebugActivity extends Activity {
    String[] exceptionType = {
        "StringIndexOutOfBoundsException",
        "IndexOutOfBoundsException",
        "ArithmeticException",
        "NumberFormatException",
        "ActivityNotFoundException"
    };
    String[] errMessage= {
        "Invalid string operation\n",
        "Invalid list operation\n",
        "Invalid arithmetical operation\n",
        "Invalid toNumber block operation\n",
        "Invalid intent operation"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String errMsg = "";
        String madeErrMsg = "";
        if(intent != null){
            errMsg = intent.getStringExtra("error");
            String[] spilt = errMsg.split("\n");
            //errMsg = spilt[0];
            try {
                for (int j = 0; j < exceptionType.length; j++) {
                    if (spilt[0].contains(exceptionType[j])) {
                        madeErrMsg = errMessage[j];
                        int addIndex = spilt[0].indexOf(exceptionType[j]) + exceptionType[j].length();
                        madeErrMsg += spilt[0].substring(addIndex, spilt[0].length());
                        break;
                    }
                }
                if(madeErrMsg.isEmpty()) madeErrMsg = errMsg;
            }catch(Exception e){}
        }
        AlertDialog.Builder bld = new AlertDialog.Builder(this);
        bld.setTitle("An error occured");
        bld.setMessage( madeErrMsg );
        bld.setNeutralButton("End Application", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
        bld.create().show();
    }
}*/
