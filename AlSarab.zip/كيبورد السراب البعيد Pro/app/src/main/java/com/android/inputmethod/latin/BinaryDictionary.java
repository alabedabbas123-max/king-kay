package com.android.inputmethod.latin;

import android.content.Context;
import android.util.Log;
import com.android.inputmethod.latin.Dictionary;
import inputmethod.latin.perfectkeyboard.R;
import java.util.Arrays;
import java.nio.ByteBuffer;
import java.io.InputStream;
import java.io.InputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Channels;
import java.util.Arrays;

import android.content.Context;
import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class BinaryDictionary extends Dictionary {
    public static final String DICTIONARY_PACK_AUTHORITY = "com.android.inputmethod.latin.dictionarypack";
    /**
     * There is difference between what java and native code can handle.
     * This value should only be used in BinaryDictionary.java
     * It is necessary to keep it at this value because some languages e.g. German have
     * really long words.
     */
    protected static final int MAX_WORD_LENGTH = 48;

    private static final String TAG = "BinaryDictionary";
    private static final int MAX_ALTERNATIVES = 16;
    private static final int MAX_WORDS = 18;
    private static final int MAX_BIGRAMS = 60;

    private static final int TYPED_LETTER_MULTIPLIER = 2;

    private int mDicTypeId;
    private int mNativeDict;
    private int mDictLength;
    private int[] mInputCodes = new int[MAX_WORD_LENGTH * MAX_ALTERNATIVES];
    private char[] mOutputChars = new char[MAX_WORD_LENGTH * MAX_WORDS];
    private char[] mOutputChars_bigrams = new char[MAX_WORD_LENGTH * MAX_BIGRAMS];
    private int[] mFrequencies = new int[MAX_WORDS];
    private int[] mFrequencies_bigrams = new int[MAX_BIGRAMS];
    // Keep a reference to the native dict direct buffer in Java to avoid
    // unexpected deallocation of the direct buffer.
    private ByteBuffer mNativeDictDirectBuffer;

    private int mFlags;
    public static final Flag FLAG_REQUIRES_GERMAN_UMLAUT_PROCESSING = new Flag(R.bool.config_require_umlaut_processing, 1);
    public static final Flag FLAG_USE_FULL_EDIT_DISTANCE = new Flag(2);
    public static final Flag FLAG_HEBREW_PROCESSING = new Flag(R.bool.config_require_hebrew_processing, 4);
    public static final Flag FLAG_T9MODE_PROCESSING = new Flag(8);
    public static final Flag FLAG_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER = new Flag(22);
    public static final Flag[] ALL_CONFIG_FLAGS = {FLAG_REQUIRES_GERMAN_UMLAUT_PROCESSING, FLAG_HEBREW_PROCESSING};

    
    //TODO CURRENTLY NOT LOADING IT


    /**
     * Create a dictionary from a raw resource file
     * @param context application context for reading resources
     * @param resId the resource containing the raw binary dictionary
     */
    public BinaryDictionary(Context context, int[] resId, int dicTypeId) {
        if (resId != null && resId.length > 0 && resId[0] != 0)
            loadDictionary(context, resId);

        mDicTypeId = dicTypeId;
    }
    public BinaryDictionary(Context context, String filename, long offset, long length, Flag[] flagArray) {
        this.mFlags = 0;
        this.mFlags = Flag.initFlags(flagArray == null ? ALL_CONFIG_FLAGS : flagArray, context);
        //loadDictionary(filename, offset, length);
    }
    /**
     * Create a dictionary from a byte buffer. This is used for testing.
     * @param context application context for reading resources
     * @param byteBuffer a ByteBuffer containing the binary dictionary
     */
    public BinaryDictionary(Context context, ByteBuffer byteBuffer, int dicTypeId) {
        if (byteBuffer != null) {
            if (byteBuffer.isDirect())
                mNativeDictDirectBuffer = byteBuffer;
            else {
                mNativeDictDirectBuffer = ByteBuffer.allocateDirect(byteBuffer.capacity());
                byteBuffer.rewind();
                mNativeDictDirectBuffer.put(byteBuffer);
            }

            mDictLength = byteBuffer.capacity();
            mNativeDict = openNative(mNativeDictDirectBuffer,
                                     TYPED_LETTER_MULTIPLIER, FULL_WORD_FREQ_MULTIPLIER);
        }
        mDicTypeId = dicTypeId;
    }

    

    private  int openNative(ByteBuffer bb, int typedLetterMultiplier, int fullWordMultiplier) {return 0;
    }
    private  void closeNative(int dict){}
    private  boolean isValidWordNative(int nativeData, char[] word, int wordLength) {
        if(word !=null){
            return true;
        }else{
            return false;
        }
    }
    private  int getSuggestionsNative(int dict, int[] inputCodes, int codesSize, 
                                      char[] outputChars, int[] frequencies, int maxWordLength, int maxWords,
                                      int maxAlternatives, int skipPos, int[] nextLettersFrequencies, int nextLettersSize) {return 0;
    }
    private  int getBigramsNative(int dict, char[] prevWord, int prevWordLength,
                                  int[] inputCodes, int inputCodesLength, char[] outputChars, int[] frequencies,
                                  int maxWordLength, int maxBigrams, int maxAlternatives) {return 0;
    }

    private void loadDictionary(Context context, int[] resId) {
        InputStream[] is = null;
        try {
            // merging separated dictionary into one if dictionary is separated
            int total = 0;
            is = new InputStream[resId.length];
            for (int i = 0; i < resId.length; i++) {
                is[i] = context.getResources().openRawResource(resId[i]);
                total += is[i].available();
            }

            mNativeDictDirectBuffer = ByteBuffer.allocateDirect(total).order(ByteOrder.nativeOrder());
            int got = 0;

            for (int i = 0; i < resId.length; i++)
                got += Channels.newChannel(is[i]).read(mNativeDictDirectBuffer);

            if (got == total) {
                mNativeDict = openNative(mNativeDictDirectBuffer, TYPED_LETTER_MULTIPLIER,
                                         FULL_WORD_FREQ_MULTIPLIER);
                mDictLength = total;
            }
        } catch (IOException e) {
            Log.w(TAG, "No available memory for binary dictionary");
        } finally {
            try {
                if (is != null)
                    for (int i = 0; i < is.length; i++)
                        is[i].close();
            } catch (IOException e) {
                Log.w(TAG, "Failed to close input stream");
            }
        }
    }


    @Override
    public void getBigrams(final WordComposer codes, final CharSequence previousWord,
                           final WordCallback callback, int[] nextLettersFrequencies) {

        char[] chars = previousWord.toString().toCharArray();
        Arrays.fill(mOutputChars_bigrams, (char) 0);
        Arrays.fill(mFrequencies_bigrams, 0);

        int codesSize = codes.size();
        Arrays.fill(mInputCodes, -1);
        int[] alternatives = codes.getCodesAt(0);
        System.arraycopy(alternatives, 0, mInputCodes, 0,
                         Math.min(alternatives.length, MAX_ALTERNATIVES));

        int count = getBigramsNative(mNativeDict, chars, chars.length, mInputCodes, codesSize,
                                     mOutputChars_bigrams, mFrequencies_bigrams, MAX_WORD_LENGTH, MAX_BIGRAMS,
                                     MAX_ALTERNATIVES);

        for (int j = 0; j < count; j++) {
            if (mFrequencies_bigrams[j] < 1) break;
            int start = j * MAX_WORD_LENGTH;
            int len = 0;
            while (mOutputChars_bigrams[start + len] != 0) {
                len++;
            }

            if (len > 0)
                callback.addWord(mOutputChars_bigrams, start, len, mFrequencies_bigrams[j],
                                 mDicTypeId, DataType.BIGRAM);
        }
    }

    @Override
    public void getWords(final WordComposer codes, final WordCallback callback,
                         int[] nextLettersFrequencies) {
        final int codesSize = codes.size();
        // Won't deal with really long words.
        if (codesSize > MAX_WORD_LENGTH - 1)
            return;

        Arrays.fill(mInputCodes, -1);
        for (int i = 0; i < codesSize; i++) {
            int[] alternatives = codes.getCodesAt(i);
            System.arraycopy(alternatives, 0, mInputCodes, i * MAX_ALTERNATIVES,
                             Math.min(alternatives.length, MAX_ALTERNATIVES));
        }

        Arrays.fill(mOutputChars, (char) 0);
        Arrays.fill(mFrequencies, 0);

        int count = getSuggestionsNative(mNativeDict, mInputCodes, codesSize,
                                         mOutputChars, mFrequencies,
                                         MAX_WORD_LENGTH, MAX_WORDS, MAX_ALTERNATIVES, -1,
                                         nextLettersFrequencies,
                                         nextLettersFrequencies != null ? nextLettersFrequencies.length : 0);

        // If there aren't sufficient suggestions, search for words by allowing wild cards at
        // the different character positions. This feature is not ready for prime-time as we need
        // to figure out the best ranking for such words compared to proximity corrections and
        // completions.
        if (count < 5) {
            for (int skip = 0; skip < codesSize; skip++) {
                int tempCount = getSuggestionsNative(mNativeDict, mInputCodes, codesSize,
                                                     mOutputChars, mFrequencies,
                                                     MAX_WORD_LENGTH, MAX_WORDS, MAX_ALTERNATIVES, skip,
                                                     null, 0);
                count = Math.max(count, tempCount);
                if (tempCount > 0) break;
            }
        }

        for (int j = 0; j < count; j++) {
            if (mFrequencies[j] < 1) break;
            int start = j * MAX_WORD_LENGTH;
            int len = 0;
            while (mOutputChars[start + len] != 0) {
                len++;
            }
            if (len > 0) {
                callback.addWord(mOutputChars, start, len, mFrequencies[j], mDicTypeId,
                                 DataType.UNIGRAM);
            }
        }
    }
    public boolean isValidDictionary() {
        return this.mNativeDict != 0;
    }
    @Override
    public boolean isValidWord(CharSequence word) {
        if (word == null) return false;
        char[] chars = word.toString().toCharArray();
        return isValidWordNative(mNativeDict, chars, chars.length);
    }

    public int getSize() {
        return mDictLength; // This value is initialized on the call to openNative()
    }

    @Override
    public synchronized void close() {
        if (mNativeDict != 0) {
            closeNative(mNativeDict);
            mNativeDict = 0;
        }
    }

    @Override
    protected void finalize() throws Throwable {
        close();
        super.finalize();
    }
}


/*
public class BinaryDictionary extends Dictionary {
    public static final String DICTIONARY_PACK_AUTHORITY = "com.android.inputmethod.latin.dictionarypack";
    private static final int MAX_BIGRAMS = 60;
    private static final int MAX_PROXIMITY_CHARS_SIZE = 16;
    public static final int MAX_WORDS = 18;
    public static final int MAX_WORD_LENGTH = 48;
    private static final String TAG = "BinaryDictionary";
    private static final int TYPED_LETTER_MULTIPLIER = 2;
    private int mFlags;
    private int mNativeDict;
    public static final Flag FLAG_REQUIRES_GERMAN_UMLAUT_PROCESSING = new Flag(R.bool.config_require_umlaut_processing, 1);
    public static final Flag FLAG_USE_FULL_EDIT_DISTANCE = new Flag(2);
    public static final Flag FLAG_HEBREW_PROCESSING = new Flag(R.bool.config_require_hebrew_processing, 4);
    public static final Flag FLAG_T9MODE_PROCESSING = new Flag(8);
    public static final Flag FLAG_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER = new Flag(22);
    public static final Flag[] ALL_CONFIG_FLAGS = {FLAG_REQUIRES_GERMAN_UMLAUT_PROCESSING, FLAG_HEBREW_PROCESSING};
    private final int[] mInputCodes = new int[768];
    private final char[] mOutputChars = new char[864];
    private final char[] mOutputChars_bigrams = new char[2880];
    private final int[] mScores = new int[18];
    private final int[] mBigramScores = new int[MAX_BIGRAMS];
    private int mDicTypeId = 1;

    private native void closeNative(int i);

    private native int getBigramsNative(int i, char[] cArr, int i2, int[] iArr, int i3, char[] cArr2, int[] iArr2, int i4, int i5, int i6);

    private native int getSuggestionsNative(int i, int i2, int[] iArr, int[] iArr2, int[] iArr3, int i3, int i4, char[] cArr, int[] iArr4);

    private native boolean isValidWordNative(int i, char[] cArr, int i2);

    private native int openNative(String str, long j, long j2, int i, int i2, int i3, int i4, int i5);

    static {
        try {
            System.loadLibrary("jni_latinime_pt2_new");
        } catch (UnsatisfiedLinkError e) {
            Log.e(TAG, "Could not load native library jni_latinime");
        }
    }

    public BinaryDictionary(Context context, String filename, long offset, long length, Flag[] flagArray) {
        this.mFlags = 0;
        this.mFlags = Flag.initFlags(flagArray == null ? ALL_CONFIG_FLAGS : flagArray, context);
        loadDictionary(filename, offset, length);
    }

    private final void loadDictionary(String path, long startOffset, long length) {
        this.mNativeDict = openNative(path, startOffset, length, 2, 2, 48, 18, 16);
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public void getBigrams(WordComposer codes, CharSequence previousWord, Dictionary.WordCallback callback) {
        if (this.mNativeDict != 0) {
            char[] chars = previousWord.toString().toCharArray();
            Arrays.fill(this.mOutputChars_bigrams, (char) 0);
            Arrays.fill(this.mBigramScores, 0);
            int codesSize = codes.size();
            if (codesSize > 0) {
                Arrays.fill(this.mInputCodes, -1);
                int[] alternatives = codes.getCodesAt(0);
                System.arraycopy(alternatives, 0, this.mInputCodes, 0, Math.min(alternatives.length, 16));
                int count = getBigramsNative(this.mNativeDict, chars, chars.length, this.mInputCodes, codesSize, this.mOutputChars_bigrams, this.mBigramScores, 48, MAX_BIGRAMS, 16);
                for (int j = 0; j < count && this.mBigramScores[j] >= 1; j++) {
                    int start = j * 48;
                    int len = 0;
                    while (len < 48 && this.mOutputChars_bigrams[start + len] != 0) {
                        len++;
                    }
                    if (len > 0) {
                        callback.addWord(this.mOutputChars_bigrams, start, len, this.mBigramScores[j], this.mDicTypeId, Dictionary.DataType.BIGRAM);
                    }
                }
            }
        }
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public void getWords(WordComposer codes, Dictionary.WordCallback callback, ProximityInfo proximityInfo) {
        int count = getSuggestions(codes, proximityInfo, this.mOutputChars, this.mScores);
        for (int j = 0; j < count && this.mScores[j] >= 1; j++) {
            int start = j * 48;
            int len = 0;
            while (len < 48 && this.mOutputChars[start + len] != 0) {
                len++;
            }
            if (len > 0) {
                callback.addWord(this.mOutputChars, start, len, this.mScores[j], this.mDicTypeId, Dictionary.DataType.UNIGRAM);
            }
        }
    }

    boolean isValidDictionary() {
        return this.mNativeDict != 0;
    }

    int getSuggestions(WordComposer codes, ProximityInfo proximityInfo, char[] outputChars, int[] scores) {
        int codesSize;
        if (!isValidDictionary() || (codesSize = codes.size()) > 47) {
            return -1;
        }
        Arrays.fill(this.mInputCodes, -1);
        for (int i = 0; i < codesSize; i++) {
            int[] alternatives = codes.getCodesAt(i);
            System.arraycopy(alternatives, 0, this.mInputCodes, i * 16, Math.min(alternatives.length, 16));
        }
        Arrays.fill(outputChars, (char) 0);
        Arrays.fill(scores, 0);
        int flags = DictionaryEditor.isT9Mode() ? this.mFlags | FLAG_T9MODE_PROCESSING.mMask : this.mFlags;
        if (DictionaryEditor.mSuggestWordsMissingSpace) {
            flags |= FLAG_SUGGEST_WORDS_WITH_MISSING_SPACE_CHARACTER.mMask;
        }
        return getSuggestionsNative(this.mNativeDict, proximityInfo.getNativeProximityInfo(), codes.getXCoordinates(), codes.getYCoordinates(), this.mInputCodes, codesSize, flags, outputChars, scores);
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public boolean isValidWord(CharSequence word) {
        if (word == null) {
            return false;
        }
        char[] chars = word.toString().toCharArray();
        return isValidWordNative(this.mNativeDict, chars, chars.length);
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public synchronized void close() {
        closeInternal();
    }

    private void closeInternal() {
        if (this.mNativeDict != 0) {
            closeNative(this.mNativeDict);
            this.mNativeDict = 0;
        }
    }

    protected void finalize() throws Throwable {
        try {
            closeInternal();
        } finally {
            super.finalize();
        }
    }
}*/
