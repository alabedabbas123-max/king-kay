package com.android.inputmethod.latin.spellcheck;

import android.content.Intent;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;
import com.android.inputmethod.latin.BinaryDictionary;
import com.android.inputmethod.latin.Dictionary;
import com.android.inputmethod.latin.DictionaryCollection;
import com.android.inputmethod.latin.DictionaryFactory;
import com.android.inputmethod.latin.Flag;
import com.android.inputmethod.latin.LocaleUtils;
import com.android.inputmethod.latin.ProximityInfo;
import com.android.inputmethod.latin.UserDictionary;
import com.android.inputmethod.latin.Utils;
import com.android.inputmethod.latin.WordComposer;
import inputmethod.latin.perfectkeyboard.R;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
public class AndroidSpellCheckerService extends SpellCheckerService {
    private static final int CAPITALIZE_ALL = 2;
    private static final int CAPITALIZE_FIRST = 1;
    private static final int CAPITALIZE_NONE = 0;
    private static final boolean DBG = false;
    private static final int POOL_SIZE = 2;
    private double mLikelyThreshold;
    private double mSuggestionThreshold;
    private static final String TAG = AndroidSpellCheckerService.class.getSimpleName();
    private static final String[] EMPTY_STRING_ARRAY = new String[0];
    private static final SuggestionsInfo NOT_IN_DICT_EMPTY_SUGGESTIONS = new SuggestionsInfo(0, EMPTY_STRING_ARRAY);
    private static final SuggestionsInfo IN_DICT_EMPTY_SUGGESTIONS = new SuggestionsInfo(1, EMPTY_STRING_ARRAY);
    private static final Flag[] USE_FULL_EDIT_DISTANCE_FLAG_ARRAY = (Flag[]) resizeArray(BinaryDictionary.ALL_CONFIG_FLAGS, BinaryDictionary.ALL_CONFIG_FLAGS.length + 1);
    private Map<String, DictionaryPool> mDictionaryPools = Collections.synchronizedMap(new TreeMap());
    private Map<String, Dictionary> mUserDictionaries = Collections.synchronizedMap(new TreeMap());
    private Map<String, Dictionary> mWhitelistDictionaries = Collections.synchronizedMap(new TreeMap());

    static {
        USE_FULL_EDIT_DISTANCE_FLAG_ARRAY[BinaryDictionary.ALL_CONFIG_FLAGS.length] = BinaryDictionary.FLAG_USE_FULL_EDIT_DISTANCE;
    }

    @Override // android.app.Service
    public void onCreate() {
        this.mSuggestionThreshold = Double.parseDouble(getString(R.string.spellchecker_suggestion_threshold_value));
        this.mLikelyThreshold = Double.parseDouble(getString(R.string.spellchecker_likely_threshold_value));
    }

    @Override // com.android.inputmethod.latin.spellcheck.SpellCheckerService
    public Session createSession() {
        return new AndroidSpellCheckerSession(this);
    }

    private static class SuggestionsGatherer implements Dictionary.WordCallback {
        private final double mLikelyThreshold;
        private final int mMaxLength;
        private final String mOriginalText;
        private final int[] mScores;
        private final double mSuggestionThreshold;
        private final ArrayList<CharSequence> mSuggestions;
        private int mLength = 0;
        private String mBestSuggestion = null;
        private int mBestScore = Integer.MIN_VALUE;

        public static class Result {
            public final boolean mHasLikelySuggestions;
            public final String[] mSuggestions;

            public Result(String[] gatheredSuggestions, boolean hasLikelySuggestions) {
                this.mSuggestions = gatheredSuggestions;
                this.mHasLikelySuggestions = hasLikelySuggestions;
            }
        }

        SuggestionsGatherer(String originalText, double suggestionThreshold, double likelyThreshold, int maxLength) {
            this.mOriginalText = originalText;
            this.mSuggestionThreshold = suggestionThreshold;
            this.mLikelyThreshold = likelyThreshold;
            this.mMaxLength = maxLength;
            this.mSuggestions = new ArrayList<>(maxLength + 1);
            this.mScores = new int[this.mMaxLength];
        }

        @Override // com.android.inputmethod.latin.Dictionary.WordCallback
        public synchronized boolean addWord(char[] word, int wordOffset, int wordLength, int score, int dicTypeId, Dictionary.DataType dataType) {
            boolean z;
            int positionIndex = ArraysCompatUtils.binarySearch(this.mScores, 0, this.mLength, score);
            int insertIndex = positionIndex >= 0 ? positionIndex : (-positionIndex) - 1;
            if ((insertIndex == 0 && this.mLength >= this.mMaxLength) || insertIndex >= this.mMaxLength) {
                z = true;
            } else {
                String wordString = new String(word, wordOffset, wordLength);
                double normalizedScore = Utils.calcNormalizedScore(this.mOriginalText, wordString, score);
                if (normalizedScore < this.mSuggestionThreshold) {
                    z = true;
                } else {
                    if (this.mLength < this.mMaxLength) {
                        int copyLen = this.mLength - insertIndex;
                        this.mLength++;
                        System.arraycopy(this.mScores, insertIndex, this.mScores, insertIndex + 1, copyLen);
                        this.mSuggestions.add(insertIndex, wordString);
                    } else {
                        System.arraycopy(this.mScores, 1, this.mScores, 0, insertIndex);
                        this.mSuggestions.add(insertIndex, wordString);
                        this.mSuggestions.remove(0);
                    }
                    this.mScores[insertIndex] = score;
                    z = true;
                }
            }
            return z;
        }

        public Result getResults(int capitalizeType, Locale locale) {
            String[] gatheredSuggestions;
            boolean hasLikelySuggestions = true;
            if (this.mLength == 0) {
                if (this.mBestSuggestion != null) {
                    gatheredSuggestions = AndroidSpellCheckerService.EMPTY_STRING_ARRAY;
                    double normalizedScore = Utils.calcNormalizedScore(this.mOriginalText, this.mBestSuggestion, this.mBestScore);
                    if (normalizedScore <= this.mLikelyThreshold) {
                        hasLikelySuggestions = false;
                    }
                } else {
                    gatheredSuggestions = null;
                    hasLikelySuggestions = AndroidSpellCheckerService.DBG;
                }
            } else {
                Collections.reverse(this.mSuggestions);
                Utils.removeDupes(this.mSuggestions);
                if (2 == capitalizeType) {
                    for (int i = 0; i < this.mSuggestions.size(); i++) {
                        this.mSuggestions.set(i, this.mSuggestions.get(i).toString().toUpperCase(locale));
                    }
                } else if (1 == capitalizeType) {
                    for (int i2 = 0; i2 < this.mSuggestions.size(); i2++) {
                        this.mSuggestions.set(i2, Utils.toTitleCase(this.mSuggestions.get(i2).toString(), locale));
                    }
                }
                gatheredSuggestions = (String[]) this.mSuggestions.toArray(AndroidSpellCheckerService.EMPTY_STRING_ARRAY);
                int bestScore = this.mScores[this.mLength - 1];
                CharSequence bestSuggestion = this.mSuggestions.get(0);
                double normalizedScore2 = Utils.calcNormalizedScore(this.mOriginalText, bestSuggestion, bestScore);
                if (normalizedScore2 <= this.mLikelyThreshold) {
                    hasLikelySuggestions = false;
                }
            }
            return new Result(gatheredSuggestions, hasLikelySuggestions);
        }
    }

    @Override // android.app.Service
    public boolean onUnbind(Intent intent) {
        Map<String, DictionaryPool> oldPools = this.mDictionaryPools;
        this.mDictionaryPools = Collections.synchronizedMap(new TreeMap());
        Map<String, Dictionary> oldUserDictionaries = this.mUserDictionaries;
        this.mUserDictionaries = Collections.synchronizedMap(new TreeMap());
        Map<String, Dictionary> oldWhitelistDictionaries = this.mWhitelistDictionaries;
        this.mWhitelistDictionaries = Collections.synchronizedMap(new TreeMap());
        for (DictionaryPool pool : oldPools.values()) {
            pool.close();
        }
        for (Dictionary dict : oldUserDictionaries.values()) {
            dict.close();
        }
        for (Dictionary dict2 : oldWhitelistDictionaries.values()) {
            dict2.close();
        }
        return DBG;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public DictionaryPool getDictionaryPool(String locale) {
        DictionaryPool pool = this.mDictionaryPools.get(locale);
        if (pool == null) {
            Locale localeObject = LocaleUtils.constructLocaleFromString(locale);
            DictionaryPool pool2 = new DictionaryPool(2, this, localeObject);
            this.mDictionaryPools.put(locale, pool2);
            return pool2;
        }
        return pool;
    }

    public DictAndProximity createDictAndProximity(Locale locale) throws Throwable {
        ProximityInfo proximityInfo = ProximityInfo.createSpellCheckerProximityInfo();
        Resources resources = getResources();
        int fallbackResourceId = Utils.getMainDictionaryResourceId(resources);
        DictionaryCollection dictionaryCollection = DictionaryFactory.createDictionaryFromManager(this, locale, fallbackResourceId, USE_FULL_EDIT_DISTANCE_FLAG_ARRAY);
        String localeStr = locale.toString();
        Dictionary userDictionary = this.mUserDictionaries.get(localeStr);
        if (userDictionary == null) {
            userDictionary = new UserDictionary(this, localeStr);
            this.mUserDictionaries.put(localeStr, userDictionary);
        }
        dictionaryCollection.addDictionary(userDictionary);
        this.mWhitelistDictionaries.get(localeStr);
        return new DictAndProximity(dictionaryCollection, proximityInfo);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int getCapitalizationType(String text) {
        if (!Character.isUpperCase(text.codePointAt(0))) {
            return 0;
        }
        int len = text.codePointCount(0, text.length());
        int capsCount = 1;
        for (int i = 1; i < len && (1 == capsCount || i == capsCount); i++) {
            if (Character.isUpperCase(text.codePointAt(i))) {
                capsCount++;
            }
        }
        if (1 == capsCount) {
            return 1;
        }
        return len == capsCount ? 2 : 0;
    }

    private static class AndroidSpellCheckerSession extends Session {
        private DictionaryPool mDictionaryPool;
        private Locale mLocale;
        private final AndroidSpellCheckerService mService;

        AndroidSpellCheckerSession(AndroidSpellCheckerService service) {
            this.mService = service;
        }

        public void onCreate() {
            this.mDictionaryPool = this.mService.getDictionaryPool("en");
            this.mLocale = LocaleUtils.constructLocaleFromString("en");
        }

        private boolean shouldFilterOut(String text) {
            if (TextUtils.isEmpty(text) || text.length() <= 1) {
                return true;
            }
            int firstCodePoint = text.codePointAt(0);
            if (!Character.isLetter(firstCodePoint) && 39 != firstCodePoint) {
                return true;
            }
            int length = text.length();
            int letterCount = 0;
            for (int i = 0; i < length; i++) {
                int codePoint = text.codePointAt(i);
                if (64 == codePoint || 47 == codePoint) {
                    return true;
                }
                if (Character.isLetter(codePoint)) {
                    letterCount++;
                }
            }
            if (letterCount * 4 >= length * 3) {
                return AndroidSpellCheckerService.DBG;
            }
            return true;
        }

        public SuggestionsInfo onGetSuggestions(TextInfo textInfo, int suggestionsLimit) {
            int[] proximities;
            SuggestionsInfo suggestionsInfo;
            try {
                String text = textInfo.getText();
                if (shouldFilterOut(text)) {
                    DictAndProximity dictInfo = null;
                    try {
                        dictInfo = this.mDictionaryPool.takeOrGetNull();
                        if (dictInfo == null) {
                            SuggestionsInfo suggestionsInfo2 = AndroidSpellCheckerService.NOT_IN_DICT_EMPTY_SUGGESTIONS;
                            return suggestionsInfo2;
                        }
                        if (!dictInfo.mDictionary.isValidWord(text)) {
                            suggestionsInfo = AndroidSpellCheckerService.NOT_IN_DICT_EMPTY_SUGGESTIONS;
                        } else {
                            suggestionsInfo = AndroidSpellCheckerService.IN_DICT_EMPTY_SUGGESTIONS;
                        }
                        if (dictInfo != null && !this.mDictionaryPool.offer(dictInfo)) {
                            Log.e(AndroidSpellCheckerService.TAG, "Can't re-insert a dictionary into its pool");
                            return suggestionsInfo;
                        }
                        return suggestionsInfo;
                    } finally {
                        if (dictInfo != null && !this.mDictionaryPool.offer(dictInfo)) {
                            Log.e(AndroidSpellCheckerService.TAG, "Can't re-insert a dictionary into its pool");
                        }
                    }
                }
                SuggestionsGatherer suggestionsGatherer = new SuggestionsGatherer(text, this.mService.mSuggestionThreshold, this.mService.mLikelyThreshold, suggestionsLimit);
                WordComposer composer = new WordComposer();
                int length = text.length();
                for (int i = 0; i < length; i++) {
                    int character = text.codePointAt(i);
                    int proximityIndex = SpellCheckerProximityInfo.getIndexOf(character);
                    if (-1 == proximityIndex) {
                        proximities = new int[]{character};
                    } else {
                        proximities = (int[]) AndroidSpellCheckerService.resizeArrayRange(SpellCheckerProximityInfo.PROXIMITY, proximityIndex, proximityIndex + 16);
                    }
                    composer.add(character, proximities, -1, -1);
                }
                int capitalizeType = AndroidSpellCheckerService.getCapitalizationType(text);
                DictAndProximity dictInfo2 = null;
                try {
                    DictAndProximity dictInfo3 = this.mDictionaryPool.takeOrGetNull();
                    if (dictInfo3 == null) {
                        SuggestionsInfo suggestionsInfo3 = AndroidSpellCheckerService.NOT_IN_DICT_EMPTY_SUGGESTIONS;
                        if (dictInfo3 != null && !this.mDictionaryPool.offer(dictInfo3)) {
                            Log.e(AndroidSpellCheckerService.TAG, "Can't re-insert a dictionary into its pool");
                            return suggestionsInfo3;
                        }
                        return suggestionsInfo3;
                    }
                    dictInfo3.mDictionary.getWords(composer, suggestionsGatherer, dictInfo3.mProximityInfo);
                    boolean isInDict = dictInfo3.mDictionary.isValidWord(text);
                    if (!isInDict && capitalizeType != 0) {
                        isInDict = dictInfo3.mDictionary.isValidWord(text.toLowerCase(this.mLocale));
                    }
                    if (dictInfo3 != null && !this.mDictionaryPool.offer(dictInfo3)) {
                        Log.e(AndroidSpellCheckerService.TAG, "Can't re-insert a dictionary into its pool");
                    }
                    SuggestionsGatherer.Result result = suggestionsGatherer.getResults(capitalizeType, this.mLocale);
                    int flags = isInDict ? 1 : 2;
                    return new SuggestionsInfo(flags, result.mSuggestions);
                } finally {
                    if (dictInfo2 != null && !this.mDictionaryPool.offer(dictInfo2)) {
                        Log.e(AndroidSpellCheckerService.TAG, "Can't re-insert a dictionary into its pool");
                    }
                }
            } catch (RuntimeException e) {
                Log.e(AndroidSpellCheckerService.TAG, "Exception while spellcheking: " + e);
                return AndroidSpellCheckerService.NOT_IN_DICT_EMPTY_SUGGESTIONS;
            }
          //  Log.e(AndroidSpellCheckerService.TAG, "Exception while spellcheking: " + e);
            
        }
    }

    private static Object resizeArray(Object oldArray, int newSize) {
        int oldSize = Array.getLength(oldArray);
        Object newArray = Array.newInstance(oldArray.getClass().getComponentType(), newSize);
        int preserveLength = Math.min(oldSize, newSize);
        if (preserveLength > 0) {
            System.arraycopy(oldArray, 0, newArray, 0, preserveLength);
        }
        return newArray;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static Object resizeArrayRange(Object oldArray, int start, int end) {
        int oldSize = Array.getLength(oldArray);
        Object newArray = Array.newInstance(oldArray.getClass().getComponentType(), end - start);
        int preserveLength = Math.min(oldSize, end - start);
        if (preserveLength > 0) {
            System.arraycopy(oldArray, start, newArray, 0, preserveLength);
        }
        return newArray;
    }

    @Override // com.android.inputmethod.latin.spellcheck.SpellCheckerService
    public SuggestionsInfo onGetSuggestions(TextInfo textInfo, int suggestionsLimit) {
        return null;
    }
}
