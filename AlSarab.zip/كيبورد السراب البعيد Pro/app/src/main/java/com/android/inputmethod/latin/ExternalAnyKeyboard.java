package com.android.inputmethod.latin;

import android.content.Context;
import android.inputmethodservice.Keyboard;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.KeyEvent;
import com.android.common.speech.LoggingEvents;
import com.android.inputmethod.latin.LatinKeyboard;
import inputmethod.latin.perfectkeyboard.R;
import org.xmlpull.v1.XmlPullParser;

/* JADX INFO: loaded from: classes.dex */
public class ExternalAnyKeyboard extends LatinKeyboard implements LatinKeyboard.HardKeyboardTranslator {
    private static final String TAG = "ASK - EAK";
    private static final String XML_ALT_ATTRIBUTE = "altModifier";
    private static final String XML_KEYS_ATTRIBUTE = "keySequence";
    private static final String XML_QWERTY_ATTRIBUTE = "QwertyTranslation";
    private static final String XML_SEQUENCE_TAG = "SequenceMapping";
    private static final String XML_SHIFT_ATTRIBUTE = "shiftModifier";
    private static final String XML_TARGET_ATTRIBUTE = "targetChar";
    private static final String XML_TARGET_CHAR_CODE_ATTRIBUTE = "targetCharCode";
    private static final String XML_TRANSLATION_TAG = "PhysicalTranslation";
    private final String mAdditionalIsLetterExceptions;
    private Context mContext;
    private final String mDefaultDictionary;
    private final HardKeyboardSequenceHandler mHardKeyboardTranslator;
    private final int mIconId;
    private final int mNameResId;
    private final String mPrefId;

    public ExternalAnyKeyboard(Context context, int xmlLayoutResId, int xmlLandscapeResId, String prefId, int nameResId, int iconResId, int qwertyTranslationId, String defaultDictionary, String additionalIsLetterExceptions, int mode) {
        super(context, getKeyboardId(context.getApplicationContext(), xmlLayoutResId, xmlLandscapeResId), mode);
        this.mPrefId = prefId;
        this.mNameResId = nameResId;
        this.mIconId = iconResId;
        this.mDefaultDictionary = defaultDictionary;
        if (qwertyTranslationId != -1) {
            if (DictionaryEditor.DEBUG) {
                Log.d(TAG, "Creating qwerty mapping:" + qwertyTranslationId);
            }
            this.mHardKeyboardTranslator = createPhysicalTranslatorFromResourceId(context, qwertyTranslationId);
        } else {
            this.mHardKeyboardTranslator = null;
        }
        this.mAdditionalIsLetterExceptions = additionalIsLetterExceptions;
    }

    private HardKeyboardSequenceHandler createPhysicalTranslatorFromResourceId(Context context, int qwertyTranslationId) {
        String target;
        HardKeyboardSequenceHandler translator = new HardKeyboardSequenceHandler();
        XmlPullParser parser = context.getResources().getXml(qwertyTranslationId);
        boolean inTranslations = false;
        while (true) {
            try {
                int event = parser.next();
                if (event == 1) {
                    break;
                }
                String tag = parser.getName();
                if (event == 2) {
                    if (XML_TRANSLATION_TAG.equals(tag)) {
                        inTranslations = true;
                        String qwerty = Xml.asAttributeSet(parser).getAttributeValue(null, XML_QWERTY_ATTRIBUTE);
                        translator.addQwertyTranslation(qwerty);
                    } else if (inTranslations && XML_SEQUENCE_TAG.equals(tag)) {
                        AttributeSet attrs = Xml.asAttributeSet(parser);
                        int[] keyCodes = getKeyCodesFromPhysicalSequence(attrs.getAttributeValue(null, XML_KEYS_ATTRIBUTE));
                        boolean isAlt = attrs.getAttributeBooleanValue(null, XML_ALT_ATTRIBUTE, false);
                        boolean isShift = attrs.getAttributeBooleanValue(null, XML_SHIFT_ATTRIBUTE, false);
                        String targetChar = attrs.getAttributeValue(null, XML_TARGET_ATTRIBUTE);
                        String targetCharCode = attrs.getAttributeValue(null, XML_TARGET_CHAR_CODE_ATTRIBUTE);
                        if (targetChar == null) {
                            target = Character.toString((char) Integer.parseInt(targetCharCode));
                        } else {
                            target = targetChar;
                        }
                        if (keyCodes == null || keyCodes.length == 0 || target == null) {
                            Log.e("ASK Hard Translation Parser", "Physical translator sequence does not include mandatory fields keySequence or targetChar");
                        } else if (!isAlt && !isShift) {
                            translator.addSequence(keyCodes, target.charAt(0));
                        } else if (isAlt) {
                            int keyCode = keyCodes[0];
                            translator.addAltMapping(keyCode, target.charAt(0));
                        } else if (isShift) {
                            int keyCode2 = keyCodes[0];
                            translator.addShiftMapping(keyCode2, target.charAt(0));
                        }
                    }
                } else if (event != 3) {
                    continue;
                } else {
                    if (XML_TRANSLATION_TAG.equals(tag)) {
                        break;
                    }
                    if (inTranslations) {
                        XML_SEQUENCE_TAG.equals(tag);
                    }
                }
            } catch (Exception e) {
                Log.e("ASK Hard Translation Parser", "Parse error:" + e);
                e.printStackTrace();
            }
        }
        return translator;
    }

    private String printInts(int[] keyCodes) {
        String r = LoggingEvents.EXTRA_CALLING_APP_NAME;
        for (int code : keyCodes) {
            r = String.valueOf(r) + Integer.toString(code) + ",";
        }
        return r;
    }

    private int[] getKeyCodesFromPhysicalSequence(String keyCodesArray) {
        String[] splitted = keyCodesArray.split(",");
        int[] keyCodes = new int[splitted.length];
        for (int i = 0; i < keyCodes.length; i++) {
            try {
                keyCodes[i] = Integer.parseInt(splitted[i]);
            } catch (NumberFormatException e) {
                String v = splitted[i];
                try {
                    keyCodes[i] = KeyEvent.class.getField(v).getInt(null);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        }
        return keyCodes;
    }

    private static int getKeyboardId(Context context, int portraitId, int landscapeId) {
        boolean inPortraitMode = context.getResources().getConfiguration().orientation == 1;
        return inPortraitMode ? portraitId : landscapeId;
    }

    @Override // com.android.inputmethod.latin.LatinKeyboard.HardKeyboardTranslator
    public void translatePhysicalCharacter(LatinKeyboard.HardKeyboardAction action, DictionaryEditor ime) {
        char translated;
        if (this.mHardKeyboardTranslator != null) {
            if (action.isAltActive()) {
                translated = this.mHardKeyboardTranslator.getAltCharacter(action.getKeyCode());
            } else if (action.isShiftActive()) {
                char shiftTranslation = this.mHardKeyboardTranslator.getShiftCharacter(action.getKeyCode());
                if (shiftTranslation <= 0) {
                    shiftTranslation = Character.toUpperCase(this.mHardKeyboardTranslator.getSequenceCharacter(action.getKeyCode(), ime));
                }
                translated = shiftTranslation;
            } else {
                translated = this.mHardKeyboardTranslator.getSequenceCharacter(action.getKeyCode(), ime);
            }
            if (translated != 0) {
                action.setNewKeyCode(translated);
            }
        }
    }

    @Override // com.android.inputmethod.latin.LatinKeyboard
    protected void setPopupKeyChars(Keyboard.Key aKey) {
        if (aKey.popupResId <= 0) {
            if (aKey.popupCharacters != null) {
                if (aKey.popupCharacters.length() > 0) {
                    aKey.popupResId = R.xml.kbd_popup_template;
                    return;
                }
                return;
            }
            if (aKey.codes != null && aKey.codes.length > 0) {
                switch ((char) aKey.codes[0]) {
                    case 'a':
                        aKey.popupCharacters = "àáâãäåæą";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'b':
                    case 'f':
                    case 'k':
                    case 'm':
                    case 'p':
                    case 'q':
                    case 'r':
                    case 't':
                    case 'v':
                    case 'w':
                    case 'x':
                    default:
                        super.setPopupKeyChars(aKey);
                        break;
                    case 'c':
                        aKey.popupCharacters = "çćĉč";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'd':
                        aKey.popupCharacters = "đ";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'e':
                        aKey.popupCharacters = "èéêëę€";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'g':
                        aKey.popupCharacters = "ĝ";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'h':
                        aKey.popupCharacters = "ĥ";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'i':
                        aKey.popupCharacters = "ìíîïł";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'j':
                        aKey.popupCharacters = "ĵ";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'l':
                        aKey.popupCharacters = "ł";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'n':
                        aKey.popupCharacters = "ñ";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'o':
                        aKey.popupCharacters = "òóôõöøőœ";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 's':
                        aKey.popupCharacters = "§ßśŝš";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'u':
                        aKey.popupCharacters = "ùúûüŭű";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'y':
                        aKey.popupCharacters = "ýÿ";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                    case 'z':
                        aKey.popupCharacters = "żžź";
                        aKey.popupResId = R.xml.kbd_popup_template;
                        break;
                }
            }
        }
    }
}
