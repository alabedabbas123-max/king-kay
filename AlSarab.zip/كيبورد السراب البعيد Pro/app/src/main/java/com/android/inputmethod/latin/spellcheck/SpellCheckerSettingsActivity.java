package com.android.inputmethod.latin.spellcheck;

import android.content.Intent;
import android.os.Bundle;
import android.preference.PreferenceActivity;

/* JADX INFO: loaded from: classes.dex */
public class SpellCheckerSettingsActivity extends PreferenceActivity {
    @Override // android.preference.PreferenceActivity, android.app.Activity
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override // android.app.Activity
    public Intent getIntent() {
        Intent modIntent = new Intent(super.getIntent());
        return modIntent;
    }
}
