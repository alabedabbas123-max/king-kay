package com.android.inputmethod.latin;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupWindow;
import android.widget.TextView;
import inputmethod.latin.perfectkeyboard.R;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class CandidateView extends View {
    private static final int MAX_SUGGESTIONS = 32;
    private static final int OUT_OF_BOUNDS_WORD_INDEX = -1;
    private static final int OUT_OF_BOUNDS_X_COORD = -1;
    private static final int SCROLL_PIXELS = 20;
    private static final int X_GAP = 10;
    private static int mColorNormal;
    private static int mColorOther;
    public static int mColorRecommended;
    static int mDefaultCandidateColor;
    public static boolean reverse_rtl;
    private CharSequence mAddToDictionaryHint;
    private Rect mBgPadding;
    public int mCurrentRecommendedWord;
    private int mCurrentWordIndex;
    private final int mDescent;
    private Drawable mDivider;
    private final GestureDetector mGestureDetector;
    private boolean mHaveMinimalSuggestion;
    private final int mMinTouchableWidth;
    private final Paint mPaint;
    private int mPopupPreviewX;
    private int mPopupPreviewY;
    private final PopupWindow mPreviewPopup;
    private final TextView mPreviewText;
    private boolean mScrolled;
    private int mSelectedIndex;
    private CharSequence mSelectedString;
    private final Drawable mSelectionHighlight;
    private DictionaryEditor mService;
    private boolean mShowingAddToDictionary;
    private boolean mShowingCompletions;
    private final ArrayList<CharSequence> mSuggestions;
    private int mTargetScrollX;
    private int mTotalWidth;
    private int mTouchX;
    private boolean mTypedWordValid;
    private final int[] mWordWidth;
    private final int[] mWordX;

    private View getview;

    

    public static void setRTL(boolean rtl) {
        reverse_rtl = rtl;
    }

    public static void setColor(int color) {
        mColorRecommended = color;
        mColorOther = color;
    }

    public static int getColor() {
        if (!DictionaryEditor.mUseCustomSuggestionColors && DictionaryEditor.mUseExternalSkin && DictionaryEditor.skinData.suggestion_color != 0) {
            return DictionaryEditor.skinData.suggestion_color;
        }
        if (DictionaryEditor.mUseCustomSuggestionColors) {
            return mColorRecommended;
        }
        return mDefaultCandidateColor;
    }

    public CandidateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mSuggestions = new ArrayList<>();
        this.mTouchX = -1;
        this.mWordWidth = new int[32];
        this.mWordX = new int[32];
        this.mSelectionHighlight = context.getResources().getDrawable(R.drawable.list_selector_background_pressed);
        LayoutInflater inflate = (LayoutInflater) context.getSystemService("layout_inflater");
        Resources res = context.getResources();
        mDefaultCandidateColor = res.getColor(R.color.candidate_recommended);
        this.mPreviewPopup = new PopupWindow(context);
        this.mPreviewText = (TextView) inflate.inflate(R.layout.candidate_preview, (ViewGroup) null);
        getview=(View) mPreviewText;
        this.mPreviewPopup.setWindowLayoutMode(-2, -2);
        this.mPreviewPopup.setContentView(this.mPreviewText);
        this.mPreviewPopup.setBackgroundDrawable(null);
        this.mPreviewPopup.setAnimationStyle(R.style.KeyPreviewAnimation);
        mColorNormal = res.getColor(R.color.candidate_normal);
        this.mDivider = res.getDrawable(R.drawable.keyboard_suggest_strip_divider);
        this.mAddToDictionaryHint = res.getString(R.string.hint_add_to_dictionary);
        this.mPaint = new Paint();
        this.mPaint.setColor(mColorNormal);
        this.mPaint.setAntiAlias(true);
        int textMultiplier = DictionaryEditor.suggestionSizeBig ? 2 : 1;
        this.mPaint.setTextSize(this.mPreviewText.getTextSize() * textMultiplier);
        this.mPaint.setStrokeWidth(0.0f);
        this.mPaint.setTextAlign(Paint.Align.CENTER);
        this.mDescent = (int) this.mPaint.descent();
        this.mMinTouchableWidth = (int) res.getDimension(R.dimen.candidate_min_touchable_width);
        this.mGestureDetector = new GestureDetector(new CandidateStripGestureListener(this.mMinTouchableWidth));
        setWillNotDraw(false);
        setHorizontalScrollBarEnabled(false);
        setVerticalScrollBarEnabled(false);
        scrollTo(0, getScrollY());
    }
    public View getView() {
        return getview;
    }
    private class CandidateStripGestureListener extends GestureDetector.SimpleOnGestureListener {
        private final int mTouchSlopSquare;

        public CandidateStripGestureListener(int touchSlop) {
            this.mTouchSlopSquare = touchSlop * touchSlop;
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public void onLongPress(MotionEvent me) {
            if (CandidateView.this.mSuggestions.size() <= 0 || me.getX() + CandidateView.this.getScrollX() >= CandidateView.this.mWordWidth[0] || CandidateView.this.getScrollX() >= 10) {
                return;
            }
            CandidateView.this.longPressFirstWord();
        }

        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        public boolean onDown(MotionEvent e) {
            CandidateView.this.mScrolled = false;
            return false;
        }

        /* JADX WARN: Removed duplicated region for block: B:10:0x0042  */
        @Override // android.view.GestureDetector.SimpleOnGestureListener, android.view.GestureDetector.OnGestureListener
        /*
            Code decompiled incorrectly, please refer to instructions dump.
        */
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
            int scrollX;
            if (!CandidateView.this.mScrolled) {
                int deltaX = (int) (e2.getX() - e1.getX());
                int deltaY = (int) (e2.getY() - e1.getY());
                int distance = (deltaX * deltaX) + (deltaY * deltaY);
                if (distance >= this.mTouchSlopSquare) {
                    CandidateView.this.mScrolled = true;
                    int width = CandidateView.this.getWidth();
                    CandidateView.this.mScrolled = true;
                    scrollX = CandidateView.this.getScrollX() + ((int) distanceX);
                    if (scrollX < 0) {
                        scrollX = 0;
                    }
                    if (distanceX > 0.0f && scrollX + width > CandidateView.this.mTotalWidth) {
                        scrollX -= (int) distanceX;
                    }
                    CandidateView.this.mTargetScrollX = scrollX;
                    CandidateView.this.scrollTo(scrollX, CandidateView.this.getScrollY());
                    CandidateView.this.hidePreview();
                    CandidateView.this.invalidate();
                }
            } else {
                int width2 = CandidateView.this.getWidth();
                CandidateView.this.mScrolled = true;
                scrollX = CandidateView.this.getScrollX() + ((int) distanceX);
                if (scrollX < 0) {
                }
                if (distanceX > 0.0f) {
                    scrollX -= (int) distanceX;
                }
                CandidateView.this.mTargetScrollX = scrollX;
                CandidateView.this.scrollTo(scrollX, CandidateView.this.getScrollY());
                CandidateView.this.hidePreview();
                CandidateView.this.invalidate();
            }
            return true;
        }
    }
    public View getsView(){
        return getview;
    }
    public void setService(DictionaryEditor listener) {
        this.mService = listener;
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        return this.mTotalWidth;
    }

    @Override // android.view.View
    protected void onDraw(Canvas canvas) {
        if (canvas != null) {
            super.onDraw(canvas);
        }
        this.mTotalWidth = 0;
        int height = getHeight();
        if (this.mBgPadding == null) {
            this.mBgPadding = new Rect(0, 0, 0, 0);
            if (getBackground() != null) {
                getBackground().getPadding(this.mBgPadding);
            }
            int textMultiplier = 1;
            if (DictionaryEditor.suggestionSizeBig) {
                textMultiplier = 2;
            }
            this.mDivider.setBounds(0, 0, this.mDivider.getIntrinsicWidth(), this.mDivider.getIntrinsicHeight() * textMultiplier);
        }
        int count = this.mSuggestions.size();
        Rect bgPadding = this.mBgPadding;
        Paint paint = this.mPaint;
        int touchX = this.mTouchX;
        int scrollX = getScrollX();
        boolean scrolled = this.mScrolled;
        boolean typedWordValid = this.mTypedWordValid;
        int y = ((int) ((height + this.mPaint.getTextSize()) - this.mDescent)) / 2;
        boolean mIsSuggestPuncList = false;
        if (DictionaryEditor.mSuggestPuncList != null && DictionaryEditor.mSuggestPuncList.equals(this.mSuggestions)) {
            mIsSuggestPuncList = true;
        }
        boolean existsAutoCompletion = false;
        int x = 0;
        for (int i = 0; i < count; i++) {
            CharSequence suggestion = this.mSuggestions.get(i);
            if (suggestion != null) {
                int wordLength = suggestion.length();
                paint.setColor(mColorNormal);
                if ((this.mHaveMinimalSuggestion && ((i == 1 && !typedWordValid) || (i == 0 && typedWordValid))) || (!mIsSuggestPuncList && this.mCurrentRecommendedWord == i && i != 1)) {
                    paint.setTypeface(Typeface.DEFAULT_BOLD);
                    paint.setUnderlineText(true);
                    paint.setColor(getColor());
                    existsAutoCompletion = true;
                } else if (i != 0 || (wordLength == 1 && count > 1)) {
                    paint.setColor(getColor());
                }
                int wordWidth = this.mWordWidth[i];
                if (wordWidth == 0) {
                    float textWidth = paint.measureText(suggestion, 0, wordLength);
                    wordWidth = Math.max(this.mMinTouchableWidth, ((int) textWidth) + 20);
                    this.mWordWidth[i] = wordWidth;
                }
                this.mWordX[i] = x;
                if (touchX != -1 && !scrolled && touchX + scrollX >= x && touchX + scrollX < x + wordWidth) {
                    if (canvas != null && !this.mShowingAddToDictionary) {
                        canvas.translate(x, 0.0f);
                        this.mSelectionHighlight.setBounds(0, bgPadding.top, wordWidth, height);
                        this.mSelectionHighlight.setColorFilter(getColor(), PorterDuff.Mode.MULTIPLY);
                        this.mSelectionHighlight.draw(canvas);
                        canvas.translate(-x, 0.0f);
                    }
                    this.mSelectedString = suggestion;
                    this.mSelectedIndex = i;
                }
                if (canvas != null) {
                    String suggestionStr = suggestion.toString();
                    char[] suggestionChar = suggestionStr.toCharArray();
                    int isRTL = 0;
                    int sizeofSuggestion = suggestionStr.length();
                    int index = 0;
                    while (true) {
                        if (index >= sizeofSuggestion) {
                            break;
                        }
                        if (suggestionChar[index] <= 1280 || suggestionChar[index] >= 1536 || suggestionChar[index] == 1515) {
                            index++;
                        } else {
                            isRTL = 1;
                            break;
                        }
                    }
                    if (isRTL == 1) {
                        for (int index2 = 0; index2 < sizeofSuggestion / 2; index2++) {
                            if (reverse_rtl) {
                                char temp = suggestionChar[index2];
                                suggestionChar[index2] = suggestionChar[(sizeofSuggestion - 1) - index2];
                                suggestionChar[(sizeofSuggestion - 1) - index2] = temp;
                            }
                        }
                        canvas.drawText(suggestionChar, 0, wordLength, (wordWidth / 2) + x, y, paint);
                    } else {
                        canvas.drawText(suggestion, 0, wordLength, (wordWidth / 2) + x, y, paint);
                    }
                    paint.setColor(mColorOther);
                    canvas.translate(x + wordWidth, 0.0f);
                    if (!this.mShowingAddToDictionary || i != 1) {
                        this.mDivider.draw(canvas);
                    }
                    canvas.translate((-x) - wordWidth, 0.0f);
                }
                paint.setUnderlineText(false);
                paint.setTypeface(Typeface.DEFAULT);
                x += wordWidth;
            }
        }
        this.mService.onAutoCompletionStateChanged(existsAutoCompletion);
        this.mTotalWidth = x;
        if (this.mTargetScrollX != scrollX) {
            scrollToTarget();
        }
    }

    private void scrollToTarget() {
        int scrollX = getScrollX();
        if (this.mTargetScrollX > scrollX) {
            int scrollX2 = scrollX + 20;
            if (scrollX2 >= this.mTargetScrollX) {
                scrollTo(this.mTargetScrollX, getScrollY());
                requestLayout();
            } else {
                scrollTo(scrollX2, getScrollY());
            }
        } else {
            int scrollX3 = scrollX - 20;
            if (scrollX3 <= this.mTargetScrollX) {
                scrollTo(this.mTargetScrollX, getScrollY());
                requestLayout();
            } else {
                scrollTo(scrollX3, getScrollY());
            }
        }
        invalidate();
    }

    public void moveToNextSuggestion() {
        if (this.mSuggestions != null && this.mSuggestions.size() > 0) {
            this.mCurrentRecommendedWord++;
            this.mCurrentRecommendedWord %= this.mSuggestions.size();
            updateScrollPosition(this.mWordX[this.mCurrentRecommendedWord] - 20);
        }
    }

    private void updateScrollPosition(int newPos) {
        if (newPos != getScrollX()) {
            this.mTargetScrollX = newPos;
            requestLayout();
            invalidate();
            this.mScrolled = true;
        }
    }

    public void setSuggestions(List<CharSequence> suggestions, boolean completions, boolean typedWordValid, boolean haveMinimalSuggestion) {
        clear();
        if (suggestions != null) {
            int insertCount = Math.min(suggestions.size(), 32);
            for (CharSequence suggestion : suggestions) {
                this.mSuggestions.add(suggestion);
                insertCount--;
                if (insertCount == 0) {
                    break;
                }
            }
        }
        this.mShowingCompletions = completions;
        this.mTypedWordValid = typedWordValid;
        scrollTo(0, getScrollY());
        this.mTargetScrollX = 0;
        this.mHaveMinimalSuggestion = haveMinimalSuggestion;
        onDraw(null);
        invalidate();
        requestLayout();
    }

    public boolean isShowingAddToDictionaryHint() {
        return this.mShowingAddToDictionary;
    }

    public void showAddToDictionaryHint(CharSequence word) {
        ArrayList<CharSequence> suggestions = new ArrayList<>();
        suggestions.add(word);
        suggestions.add(this.mAddToDictionaryHint);
        setSuggestions(suggestions, false, false, false);
        this.mShowingAddToDictionary = true;
    }

    public boolean dismissAddToDictionaryHint() {
        if (!this.mShowingAddToDictionary) {
            return false;
        }
        clear();
        return true;
    }

    List<CharSequence> getSuggestions() {
        return this.mSuggestions;
    }

    public void clear() {
        this.mCurrentRecommendedWord = 1;
        this.mSuggestions.clear();
        this.mTouchX = -1;
        this.mSelectedString = null;
        this.mSelectedIndex = -1;
        this.mShowingAddToDictionary = false;
        invalidate();
        Arrays.fill(this.mWordWidth, 0);
        Arrays.fill(this.mWordX, 0);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent me) {
        if (!this.mGestureDetector.onTouchEvent(me)) {
            int action = me.getAction();
            int x = (int) me.getX();
            int y = (int) me.getY();
            this.mTouchX = x;
            switch (action) {
                case 0:
                    invalidate();
                    break;
                case 1:
                    if (!this.mScrolled && this.mSelectedString != null) {
                        if (this.mShowingAddToDictionary) {
                            longPressFirstWord();
                            clear();
                        } else {
                            if (!this.mShowingCompletions) {
                                TextEntryState.acceptedSuggestion(this.mSuggestions.get(0), this.mSelectedString);
                            }
                            this.mService.pickSuggestionManually(this.mSelectedIndex, this.mSelectedString);
                        }
                    }
                    this.mSelectedString = null;
                    this.mSelectedIndex = -1;
                    requestLayout();
                    hidePreview();
                    invalidate();
                    break;
                case 2:
                    if (y <= 0 && this.mSelectedString != null) {
                        if (!this.mShowingCompletions) {
                            TextEntryState.acceptedSuggestion(this.mSuggestions.get(0), this.mSelectedString);
                        }
                        this.mService.pickSuggestionManually(this.mSelectedIndex, this.mSelectedString);
                        this.mSelectedString = null;
                        this.mSelectedIndex = -1;
                    }
                    break;
            }
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void hidePreview() {
        this.mTouchX = -1;
        this.mCurrentWordIndex = -1;
        this.mPreviewPopup.dismiss();
    }

    private void showPreview(int wordIndex, String altText) {
        int oldWordIndex = this.mCurrentWordIndex;
        this.mCurrentWordIndex = wordIndex;
        if (oldWordIndex != this.mCurrentWordIndex || altText != null) {
            if (wordIndex == -1) {
                hidePreview();
                return;
            }
            CharSequence word = altText != null ? altText : this.mSuggestions.get(wordIndex);
            this.mPreviewText.setText(word);
            this.mPreviewText.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
            int wordWidth = (int) (this.mPaint.measureText(word, 0, word.length()) + 20.0f);
            int popupWidth = this.mPreviewText.getPaddingLeft() + wordWidth + this.mPreviewText.getPaddingRight();
            int popupHeight = this.mPreviewText.getMeasuredHeight();
            this.mPopupPreviewX = ((this.mWordX[wordIndex] - this.mPreviewText.getPaddingLeft()) - getScrollX()) + ((this.mWordWidth[wordIndex] - wordWidth) / 2);
            this.mPopupPreviewY = -popupHeight;
            int[] offsetInWindow = new int[2];
            getLocationInWindow(offsetInWindow);
            if (this.mPreviewPopup.isShowing()) {
                this.mPreviewPopup.update(this.mPopupPreviewX, this.mPopupPreviewY + offsetInWindow[1], popupWidth, popupHeight);
            } else {
                this.mPreviewPopup.setWidth(popupWidth);
                this.mPreviewPopup.setHeight(popupHeight);
                this.mPreviewPopup.showAtLocation(this, 0, this.mPopupPreviewX, this.mPopupPreviewY + offsetInWindow[1]);
            }
            this.mPreviewText.setVisibility(0);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void longPressFirstWord() {
        CharSequence word = this.mSuggestions.get(0);
        if (word.length() >= 1 && this.mService.addWordToDictionary(word.toString())) {
            showPreview(0, getContext().getResources().getString(R.string.added_word, word));
        }
    }

    @Override // android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        hidePreview();
    }
}
