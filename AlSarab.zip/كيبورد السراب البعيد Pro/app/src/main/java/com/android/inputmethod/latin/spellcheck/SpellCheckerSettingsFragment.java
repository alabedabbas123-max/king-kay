package com.android.inputmethod.latin.spellcheck;

import android.preference.PreferenceActivity;

/* JADX INFO: loaded from: classes.dex */
public class SpellCheckerSettingsFragment extends PreferenceActivity {
}
