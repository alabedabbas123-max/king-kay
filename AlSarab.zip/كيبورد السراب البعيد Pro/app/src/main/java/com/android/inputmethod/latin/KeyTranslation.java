package com.android.inputmethod.latin;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.KeyEvent;
import org.xmlpull.v1.XmlPullParser;

/* JADX INFO: loaded from: classes.dex */
public class KeyTranslation {
    private static final String XML_ALT_ATTRIBUTE = "altModifier";
    private static final String XML_KEYS_ATTRIBUTE = "keySequence";
    private static final String XML_QWERTY_ATTRIBUTE = "QwertyTranslation";
    private static final String XML_SEQUENCE_TAG = "SequenceMapping";
    private static final String XML_SHIFT_ATTRIBUTE = "shiftModifier";
    private static final String XML_TARGET_ATTRIBUTE = "targetChar";
    private static final String XML_TARGET_CHAR_CODE_ATTRIBUTE = "targetCharCode";
    private static final String XML_TRANSLATION_TAG = "PhysicalTranslation";

    public HardKeyboardSequenceHandler createPhysicalTranslatorFromResourceId(Context context, int qwertyTranslationId) {
        String target;
        HardKeyboardSequenceHandler translator = new HardKeyboardSequenceHandler();
        XmlPullParser parser = context.getResources().getXml(qwertyTranslationId);
        boolean inTranslations = false;
        while (true) {
            try {
                int event = parser.next();
                if (event == 1) {
                    break;
                }
                String tag = parser.getName();
                if (event == 2) {
                    if (XML_TRANSLATION_TAG.equals(tag)) {
                        inTranslations = true;
                        String qwerty = Xml.asAttributeSet(parser).getAttributeValue(null, XML_QWERTY_ATTRIBUTE);
                        translator.addQwertyTranslation(qwerty);
                    } else if (inTranslations && XML_SEQUENCE_TAG.equals(tag)) {
                        AttributeSet attrs = Xml.asAttributeSet(parser);
                        int[] keyCodes = getKeyCodesFromPhysicalSequence(attrs.getAttributeValue(null, XML_KEYS_ATTRIBUTE));
                        boolean isAlt = attrs.getAttributeBooleanValue(null, XML_ALT_ATTRIBUTE, false);
                        boolean isShift = attrs.getAttributeBooleanValue(null, XML_SHIFT_ATTRIBUTE, false);
                        String targetChar = attrs.getAttributeValue(null, XML_TARGET_ATTRIBUTE);
                        String targetCharCode = attrs.getAttributeValue(null, XML_TARGET_CHAR_CODE_ATTRIBUTE);
                        if (targetChar == null) {
                            target = Character.toString((char) Integer.parseInt(targetCharCode));
                        } else {
                            target = targetChar;
                        }
                        if (keyCodes == null || keyCodes.length == 0 || target == null) {
                            Log.e("ASK Hard Translation Parser", "Physical translator sequence does not include mandatory fields keySequence or targetChar");
                        } else if (!isAlt && !isShift) {
                            translator.addSequence(keyCodes, target.charAt(0));
                        } else if (isAlt) {
                            int keyCode = keyCodes[0];
                            translator.addAltMapping(keyCode, target.charAt(0));
                        } else if (isShift) {
                            int keyCode2 = keyCodes[0];
                            translator.addShiftMapping(keyCode2, target.charAt(0));
                        }
                    }
                } else if (event != 3) {
                    continue;
                } else {
                    if (XML_TRANSLATION_TAG.equals(tag)) {
                        break;
                    }
                    if (inTranslations) {
                        XML_SEQUENCE_TAG.equals(tag);
                    }
                }
            } catch (Exception e) {
                Log.e("ASK Hard Translation Parser", "Parse error:" + e);
                e.printStackTrace();
            }
        }
        return translator;
    }

    private int[] getKeyCodesFromPhysicalSequence(String keyCodesArray) {
        String[] splitted = keyCodesArray.split(",");
        int[] keyCodes = new int[splitted.length];
        for (int i = 0; i < keyCodes.length; i++) {
            try {
                keyCodes[i] = Integer.parseInt(splitted[i]);
            } catch (NumberFormatException e) {
                String v = splitted[i];
                try {
                    keyCodes[i] = KeyEvent.class.getField(v).getInt(null);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        }
        return keyCodes;
    }
}
