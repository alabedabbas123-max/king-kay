package com.android.inputmethod.latin;

import android.content.Context;
import android.widget.Toast;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import inputmethod.latin.perfectkeyboard.R;
public class Toasts{

    Context context;

    //قم بتغيير R.layout.toast_message إلى id layout الخاص بك

    public  Toasts(Context context){
        this.context = context;
        setContext(context);
    }
    public Toasts(Context context,String str){
        this.context = context;
        setContext(context);
        toast(str);
    }
    public void setContext(Context context) {
        this.context = context;
    }

    public Context getContext() {
        return context;
    }
    public void toast(String str) {
        //Toasts toasts = new Toasts(getContext());
        this.show(str,Toast.LENGTH_SHORT, R.drawable.ic_application);
    }
    public void show(String message,int duration, int icon){

        Toast toast = new Toast(context);
        toast.setDuration(duration);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.toast, null);

        //قم بتغيير R.id.toast_icon و R.id.toast_message إلى id الخاص بك
        ImageView toast_icon = view.findViewById(R.id.image);
        toast_icon.setVisibility(View.GONE);
        TextView toast_message = view.findViewById(R.id.text);

        toast_icon.setImageResource(icon);
        toast_message.setText(message);

        toast.setView(view);
        toast.show();
    }
}
