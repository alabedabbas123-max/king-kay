package com.android.inputmethod.latin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.os.AsyncTask;
import android.util.Log;
import java.util.HashMap;
import java.util.HashSet;
import com.android.inputmethod.latin.Dictionary.WordCallback;

/* JADX INFO: loaded from: classes.dex */
public class UserBigramDictionary extends ExpandableDictionary {

    @Override
    public void getWords(WordComposer composer, Dictionary.WordCallback callback, int[] nextLettersFrequencies) {
    }

    private static final String DATABASE_NAME = "userbigram_dict.db";
    private static final int DATABASE_VERSION = 1;
    private static final int FREQUENCY_FOR_TYPED = 2;
    private static final int FREQUENCY_MAX = 127;
    private static final String FREQ_COLUMN_FREQUENCY = "freq";
    private static final String FREQ_COLUMN_ID = "_id";
    private static final String FREQ_COLUMN_PAIR_ID = "pair_id";
    private static final String FREQ_TABLE_NAME = "frequency";
    private static final String MAIN_COLUMN_ID = "_id";
    private static final String MAIN_COLUMN_LOCALE = "locale";
    private static final String MAIN_COLUMN_WORD1 = "word1";
    private static final String MAIN_COLUMN_WORD2 = "word2";
    private static final String MAIN_TABLE_NAME = "main";
    protected static final int SUGGEST_THRESHOLD = 4;
    private static final String TAG = "UserBigramDictionary";
    private static DatabaseHelper sOpenHelper;
    private final DictionaryEditor mIme;
    private String mLocale;
    private HashSet<Bigram> mPendingWrites;
    private final Object mPendingWritesLock;
    private static int sMaxUserBigrams = 10000;
    private static int sDeleteUserBigrams = 1000;
    private static volatile boolean sUpdatingDB = false;
    private static final HashMap<String, String> sDictProjectionMap = new HashMap<>();

    static {
        sDictProjectionMap.put("_id", "_id");
        sDictProjectionMap.put(MAIN_COLUMN_WORD1, MAIN_COLUMN_WORD1);
        sDictProjectionMap.put(MAIN_COLUMN_WORD2, MAIN_COLUMN_WORD2);
        sDictProjectionMap.put("locale", "locale");
        sDictProjectionMap.put("_id", "_id");
        sDictProjectionMap.put(FREQ_COLUMN_PAIR_ID, FREQ_COLUMN_PAIR_ID);
        sDictProjectionMap.put(FREQ_COLUMN_FREQUENCY, FREQ_COLUMN_FREQUENCY);
        sOpenHelper = null;
    }

    private static class Bigram {
        int frequency;
        String word1;
        String word2;

        Bigram(String word1, String word2, int frequency) {
            this.word1 = word1;
            this.word2 = word2;
            this.frequency = frequency;
        }

        public boolean equals(Object bigram) {
            Bigram bigram2 = (Bigram) bigram;
            return this.word1.equals(bigram2.word1) && this.word2.equals(bigram2.word2);
        }

        public int hashCode() {
            return (String.valueOf(this.word1) + " " + this.word2).hashCode();
        }
    }

    public void setDatabaseMax(int maxUserBigram) {
        sMaxUserBigrams = maxUserBigram;
    }

    public void setDatabaseDelete(int deleteUserBigram) {
        sDeleteUserBigrams = deleteUserBigram;
    }

    public UserBigramDictionary(Context context, DictionaryEditor ime, String locale, int dicTypeId) {
        super(context, dicTypeId);
        this.mPendingWrites = new HashSet<>();
        this.mPendingWritesLock = new Object();
        this.mIme = ime;
        this.mLocale = locale;
        if (sOpenHelper == null) {
            sOpenHelper = new DatabaseHelper(getContext());
        }
        if (this.mLocale != null && this.mLocale.length() > 1) {
            loadDictionary();
        }
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public void close() {
        flushPendingWrites();
        super.close();
    }

    public int addBigrams(String word1, String word2) {
        int freq = 0;
        int length = Math.max(word2.length(), word2.length());
        if (length <= getMaxWordLength()) {
            if (this.mIme != null && this.mIme.getCurrentWord().isAutoCapitalized()) {
                word2 = String.valueOf(Character.toLowerCase(word2.charAt(0))) + word2.substring(1);
            }
            freq = super.addBigram(word1, word2, 2);
            if (freq > 127) {
                freq = 127;
            }
            synchronized (this.mPendingWritesLock) {
                if (freq != 2) {
                    if (!this.mPendingWrites.isEmpty()) {
                        Bigram bi = new Bigram(word1, word2, freq);
                        this.mPendingWrites.remove(bi);
                        this.mPendingWrites.add(bi);
                    }
                }
                this.mPendingWrites.add(new Bigram(word1, word2, freq));
            }
        }
        return freq;
    }

    public void flushPendingWrites() {
        synchronized (this.mPendingWritesLock) {
            if (!this.mPendingWrites.isEmpty()) {
                new UpdateDbTask(getContext(), sOpenHelper, this.mPendingWrites, this.mLocale).execute(new Void[0]);
                this.mPendingWrites = new HashSet<>();
            }
        }
    }

    void waitUntilUpdateDBDone() {
        synchronized (this.mPendingWritesLock) {
            while (sUpdatingDB) {
                try {
                    Thread.sleep(100L);
                } catch (InterruptedException e) {
                }
            }
        }
    }

    @Override // com.android.inputmethod.latin.ExpandableDictionary
    public void loadDictionaryAsync() {
        Cursor cursor = query("locale=?", new String[]{this.mLocale});
        try {
            if (cursor.moveToFirst()) {
                int word1Index = cursor.getColumnIndex(MAIN_COLUMN_WORD1);
                int word2Index = cursor.getColumnIndex(MAIN_COLUMN_WORD2);
                int frequencyIndex = cursor.getColumnIndex(FREQ_COLUMN_FREQUENCY);
                while (!cursor.isAfterLast()) {
                    String word1 = cursor.getString(word1Index);
                    String word2 = cursor.getString(word2Index);
                    int frequency = cursor.getInt(frequencyIndex);
                    if (word1.length() < 32 && word2.length() < 32) {
                        super.setBigram(word1, word2, frequency);
                    }
                    cursor.moveToNext();
                }
            }
        } finally {
            cursor.close();
        }
    }

    private Cursor query(String selection, String[] selectionArgs) {
        SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
        qb.setTables("main INNER JOIN frequency ON (main._id=frequency.pair_id)");
        qb.setProjectionMap(sDictProjectionMap);
        SQLiteDatabase db = sOpenHelper.getReadableDatabase();
        Cursor c = qb.query(db, new String[]{MAIN_COLUMN_WORD1, MAIN_COLUMN_WORD2, FREQ_COLUMN_FREQUENCY}, selection, selectionArgs, null, null, null);
        return c;
    }

    private static class DatabaseHelper extends SQLiteOpenHelper {
        DatabaseHelper(Context context) {
            super(context, UserBigramDictionary.DATABASE_NAME, (SQLiteDatabase.CursorFactory) null, 1);
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("PRAGMA foreign_keys = ON;");
            db.execSQL("CREATE TABLE main (_id INTEGER PRIMARY KEY,word1 TEXT,word2 TEXT,locale TEXT);");
            db.execSQL("CREATE TABLE frequency (_id INTEGER PRIMARY KEY,pair_id INTEGER,freq INTEGER,FOREIGN KEY(pair_id) REFERENCES main(_id) ON DELETE CASCADE);");
        }

        @Override // android.database.sqlite.SQLiteOpenHelper
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(UserBigramDictionary.TAG, "Upgrading database from version " + oldVersion + " to " + newVersion + ", which will destroy all old data");
            db.execSQL("DROP TABLE IF EXISTS main");
            db.execSQL("DROP TABLE IF EXISTS frequency");
            onCreate(db);
        }
    }

    private static class UpdateDbTask extends AsyncTask<Void, Void, Void> {
        private final DatabaseHelper mDbHelper;
        private final String mLocale;
        private final HashSet<Bigram> mMap;

        public UpdateDbTask(Context context, DatabaseHelper openHelper, HashSet<Bigram> pendingWrites, String locale) {
            this.mMap = pendingWrites;
            this.mLocale = locale;
            this.mDbHelper = openHelper;
        }

        private void checkPruneData(SQLiteDatabase db) {
            db.execSQL("PRAGMA foreign_keys = ON;");
            Cursor c = db.query(UserBigramDictionary.FREQ_TABLE_NAME, new String[]{UserBigramDictionary.FREQ_COLUMN_PAIR_ID}, null, null, null, null, null);
            try {
                int totalRowCount = c.getCount();
                if (totalRowCount > UserBigramDictionary.sMaxUserBigrams) {
                    int numDeleteRows = (totalRowCount - UserBigramDictionary.sMaxUserBigrams) + UserBigramDictionary.sDeleteUserBigrams;
                    int pairIdColumnId = c.getColumnIndex(UserBigramDictionary.FREQ_COLUMN_PAIR_ID);
                    c.moveToFirst();
                    for (int count = 0; count < numDeleteRows; count++) {
                        if (c.isAfterLast()) {
                            break;
                        }
                        String pairId = c.getString(pairIdColumnId);
                        db.delete(UserBigramDictionary.MAIN_TABLE_NAME, "_id=?", new String[]{pairId});
                        c.moveToNext();
                    }
                }
            } finally {
                c.close();
            }
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            UserBigramDictionary.sUpdatingDB = true;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... v) {
            int pairId;
            SQLiteDatabase db = this.mDbHelper.getWritableDatabase();
            db.execSQL("PRAGMA foreign_keys = ON;");
            for (Bigram bi : this.mMap) {
                Cursor c = db.query(UserBigramDictionary.MAIN_TABLE_NAME, new String[]{"_id"}, "word1=? AND word2=? AND locale=?", new String[]{bi.word1, bi.word2, this.mLocale}, null, null, null);
                if (c.moveToFirst()) {
                    pairId = c.getInt(c.getColumnIndex("_id"));
                    db.delete(UserBigramDictionary.FREQ_TABLE_NAME, "pair_id=?", new String[]{Integer.toString(pairId)});
                } else {
                    Long pairIdLong = Long.valueOf(db.insert(UserBigramDictionary.MAIN_TABLE_NAME, null, getContentValues(bi.word1, bi.word2, this.mLocale)));
                    pairId = pairIdLong.intValue();
                }
                c.close();
                db.insert(UserBigramDictionary.FREQ_TABLE_NAME, null, getFrequencyContentValues(pairId, bi.frequency));
            }
            checkPruneData(db);
            UserBigramDictionary.sUpdatingDB = false;
            return null;
        }

        private ContentValues getContentValues(String word1, String word2, String locale) {
            ContentValues values = new ContentValues(3);
            values.put(UserBigramDictionary.MAIN_COLUMN_WORD1, word1);
            values.put(UserBigramDictionary.MAIN_COLUMN_WORD2, word2);
            values.put("locale", locale);
            return values;
        }

        private ContentValues getFrequencyContentValues(int pairId, int frequency) {
            ContentValues values = new ContentValues(2);
            values.put(UserBigramDictionary.FREQ_COLUMN_PAIR_ID, Integer.valueOf(pairId));
            values.put(UserBigramDictionary.FREQ_COLUMN_FREQUENCY, Integer.valueOf(frequency));
            return values;
        }
    }
}
