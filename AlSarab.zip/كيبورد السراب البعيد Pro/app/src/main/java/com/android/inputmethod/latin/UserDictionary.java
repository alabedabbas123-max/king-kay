package com.android.inputmethod.latin;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.provider.UserDictionary;
import com.android.common.speech.LoggingEvents;
import com.android.inputmethod.latin.Dictionary;

/* JADX INFO: loaded from: classes.dex */
public class UserDictionary extends ExpandableDictionary {
    private static final int INDEX_FREQUENCY = 2;
    private static final int INDEX_WORD = 1;
    private static final String[] PROJECTION = {"_id", "word", "frequency"};
    private String mLocale;
    private ContentObserver mObserver;

    public UserDictionary(Context context, String locale) {
        super(context, 2);
        this.mLocale = locale;
        ContentResolver cres = context.getContentResolver();
        Uri uri = UserDictionary.Words.CONTENT_URI;
        ContentObserver contentObserver = new ContentObserver(null) { // from class: com.android.inputmethod.latin.UserDictionary.1
            @Override // android.database.ContentObserver
            public void onChange(boolean self) {
                setRequiresReload(true);
            }
        };
        this.mObserver = contentObserver;
        cres.registerContentObserver(uri, true, contentObserver);
        loadDictionary();
    }

    @Override // com.android.inputmethod.latin.Dictionary
    public synchronized void close() {
        if (this.mObserver != null) {
            getContext().getContentResolver().unregisterContentObserver(this.mObserver);
            this.mObserver = null;
        }
        super.close();
    }

    @Override // com.android.inputmethod.latin.ExpandableDictionary
    public void loadDictionaryAsync() {
        Cursor cursor = getContext().getContentResolver().query(UserDictionary.Words.CONTENT_URI, PROJECTION, "(locale IS NULL) or (locale=?) or (locale like '" + this.mLocale + "%')", new String[]{this.mLocale}, null);
        if (cursor != null) {
            addWords(cursor);
        }
    }

    /* JADX WARN: Type inference failed for: r2v9, types: [com.android.inputmethod.latin.UserDictionary$2] */
    @Override // com.android.inputmethod.latin.ExpandableDictionary
    public synchronized void addWord(String word, int frequency) {
        if (getRequiresReload()) {
            loadDictionaryAsync();
        }
        if (word.length() < getMaxWordLength()) {
            super.addWord(word, frequency);
            final ContentValues values = new ContentValues(5);
            values.put("word", word);
            values.put("frequency", Integer.valueOf(frequency));
            values.put(LoggingEvents.VoiceIme.EXTRA_START_LOCALE, this.mLocale);
            values.put("appid", (Integer) 0);
            final ContentResolver contentResolver = getContext().getContentResolver();
            new Thread("addWord") { // from class: com.android.inputmethod.latin.UserDictionary.2
                @Override // java.lang.Thread, java.lang.Runnable
                public void run() {
                    contentResolver.insert(UserDictionary.Words.CONTENT_URI, values);
                }
            }.start();
            setRequiresReload(false);
        }
    }

    @Override // com.android.inputmethod.latin.ExpandableDictionary, com.android.inputmethod.latin.Dictionary
    public synchronized void getWords(WordComposer codes, Dictionary.WordCallback callback, ProximityInfo proximityInfo) {
        super.getWords(codes, callback, proximityInfo);
    }

    @Override // com.android.inputmethod.latin.ExpandableDictionary, com.android.inputmethod.latin.Dictionary
    public synchronized boolean isValidWord(CharSequence word) {
        return super.isValidWord(word);
    }

    private void addWords(Cursor cursor) {
        clearDictionary();
        int maxWordLength = getMaxWordLength();
        if (cursor.moveToFirst()) {
            while (!cursor.isAfterLast()) {
                String word = cursor.getString(1);
                int frequency = cursor.getInt(2);
                if (word.length() < maxWordLength && word.length() > 0) {
                    super.addWord(word, frequency);
                }
                cursor.moveToNext();
            }
        }
        cursor.close();
    }
}
