package com.android.inputmethod.latin;

import android.inputmethodservice.Keyboard;
import android.util.Log;
import com.android.inputmethod.latin.LatinKeyboard;
import com.android.inputmethod.latin.spellcheck.SpellCheckerProximityInfo;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;

import android.util.Log;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ProximityInfo {
    public static final int MAX_PROXIMITY_CHARS_SIZE = 16;
    private final int mCellHeight;
    private final int mCellWidth;
    private final int mGridHeight;
    private final int[][] mGridNeighbors;
    private final int mGridSize;
    private final int mGridWidth;
    private final int mKeyHeight;
    private final int mKeyboardHeight;
    private final int mKeyboardMinWidth;
    private int mNativeProximityInfo = 0;
    private static float SEARCH_DISTANCE = 1.2f;
    private static final int[] EMPTY_INT_ARRAY = new int[0];

    // متغيّر لمعرفة هل تم تحميل مكتبة C/C++ بنجاح أم لا
    private static boolean sIsNativeLoaded = false;

    private native void releaseProximityInfoNative(int i);

    private native int setProximityInfoNative(int i, int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2, int[] iArr3, int[] iArr4, int[] iArr5, int[] iArr6, float[] fArr, float[] fArr2, float[] fArr3);

    static {
        try {
            System.loadLibrary("jni_latinime_pt2_new");
            sIsNativeLoaded = true;
        } catch (UnsatisfiedLinkError e) {
            Log.e("ProximityInfo", "Could not load native library jni_latinime_pt2_new", e);
            sIsNativeLoaded = false;
        }
    }

    ProximityInfo(int gridWidth, int gridHeight, int minWidth, int height, int keyWidth, int keyHeight, List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection) {
        this.mGridWidth = gridWidth;
        this.mGridHeight = gridHeight;
        this.mGridSize = this.mGridWidth * this.mGridHeight;
        this.mCellWidth = ((this.mGridWidth + minWidth) - 1) / this.mGridWidth;
        this.mCellHeight = ((this.mGridHeight + height) - 1) / this.mGridHeight;
        this.mKeyboardMinWidth = minWidth;
        this.mKeyboardHeight = height;
        this.mKeyHeight = keyHeight;
        this.mGridNeighbors = new int[this.mGridSize][];
        if (minWidth != 0 && height != 0 && keys != null) {
            computeNearestNeighbors(keyWidth, keys, touchPositionCorrection);
        }
    }

    public static ProximityInfo createDummyProximityInfo() {
        List<Keyboard.Key> keys = new ArrayList<Keyboard.Key>();
        return new ProximityInfo(1, 1, 1, 1, 1, 1, keys, null);
    }

    public static ProximityInfo createSpellCheckerProximityInfo() {
        ProximityInfo spellCheckerProximityInfo = createDummyProximityInfo();
        // الحماية عند استدعاء الـ Native في التدقيق اللغوي
        if (sIsNativeLoaded) {
            try {
                spellCheckerProximityInfo.mNativeProximityInfo = spellCheckerProximityInfo.setProximityInfoNative(
                    16, 480, 300, 10, 3, 
                    SpellCheckerProximityInfo.PROXIMITY, 0, 
                    null, null, null, null, null, null, null, null);
            } catch (UnsatisfiedLinkError e) {
                Log.e("ProximityInfo", "Failed to set native spell checker info", e);
            }
        }
        return spellCheckerProximityInfo;
    }

    private final void setProximityInfo(int[][] gridNeighborKeyIndexes, int keyboardWidth, int keyboardHeight, List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection) {
        int[] proximityCharsArray = new int[this.mGridSize * 16];
        Arrays.fill(proximityCharsArray, -1);
        for (int i = 0; i < this.mGridSize; i++) {
            if (gridNeighborKeyIndexes[i] == null) continue;
            int proximityCharsLength = gridNeighborKeyIndexes[i].length;
            for (int j = 0; j < proximityCharsLength; j++) {
                proximityCharsArray[(i * 16) + j] = keys.get(gridNeighborKeyIndexes[i][j]).codes[0];
            }
        }
        int keyCount = keys.size();
        int[] keyXCoordinates = new int[keyCount];
        int[] keyYCoordinates = new int[keyCount];
        int[] keyWidths = new int[keyCount];
        int[] keyHeights = new int[keyCount];
        int[] keyCharCodes = new int[keyCount];
        for (int i2 = 0; i2 < keyCount; i2++) {
            Keyboard.Key key = keys.get(i2);
            keyXCoordinates[i2] = key.x + (key.gap / 2);
            keyYCoordinates[i2] = key.y;
            keyWidths[i2] = key.width;
            keyHeights[i2] = key.height;
            keyCharCodes[i2] = key.codes[0];
        }
        float[] sweetSpotCenterXs = null;
        float[] sweetSpotCenterYs = null;
        float[] sweetSpotRadii = null;
        if (touchPositionCorrection != null && touchPositionCorrection.isValid()) {
            sweetSpotCenterXs = new float[keyCount];
            sweetSpotCenterYs = new float[keyCount];
            sweetSpotRadii = new float[keyCount];
            calculateSweetSpot(keys, touchPositionCorrection, sweetSpotCenterXs, sweetSpotCenterYs, sweetSpotRadii);
        }

        // الحماية الرئيسية: عدم استدعاء دالة Native إلا إذا تم تحميل المكتبة بنجاح
        if (sIsNativeLoaded) {
            try {
                this.mNativeProximityInfo = setProximityInfoNative(
                    16, keyboardWidth, keyboardHeight, this.mGridWidth, this.mGridHeight, 
                    proximityCharsArray, keyCount, keyXCoordinates, keyYCoordinates, 
                    keyWidths, keyHeights, keyCharCodes, sweetSpotCenterXs, sweetSpotCenterYs, sweetSpotRadii);
            } catch (UnsatisfiedLinkError e) {
                Log.e("ProximityInfo", "Failed to set native proximity info", e);
                this.mNativeProximityInfo = 0;
            }
        } else {
            this.mNativeProximityInfo = 0;
        }
    }

    private void calculateSweetSpot(List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection, float[] sweetSpotCenterXs, float[] sweetSpotCenterYs, float[] sweetSpotRadii) {
        int keyCount = keys.size();
        float[] xs = touchPositionCorrection.mXs;
        float[] ys = touchPositionCorrection.mYs;
        float[] radii = touchPositionCorrection.mRadii;
        for (int i = 0; i < keyCount; i++) {
            Keyboard.Key key = keys.get(i);
            if (this.mKeyHeight == 0) continue;
            int row = key.x / this.mKeyHeight;
            if (row < radii.length) {
                float hitBoxCenterX = (key.width + 1) * 0.5f;
                float hitBoxCenterY = key.height * 0.5f;
                float hitBoxWidth = key.width + 1;
                float hitBoxHeight = key.height;
                float x = xs[row];
                float y = ys[row];
                float radius = radii[row];
                sweetSpotCenterXs[i] = (x * hitBoxWidth) + hitBoxCenterX;
                sweetSpotCenterYs[i] = (y * hitBoxHeight) + hitBoxCenterY;
                sweetSpotRadii[i] = ((float) Math.sqrt((hitBoxWidth * hitBoxWidth) + (hitBoxHeight * hitBoxHeight))) * radius;
            }
        }
    }

    public int getNativeProximityInfo() {
        return this.mNativeProximityInfo;
    }

    @Override
    protected void finalize() throws Throwable {
        try {
            if (sIsNativeLoaded && this.mNativeProximityInfo != 0) {
                try {
                    releaseProximityInfoNative(this.mNativeProximityInfo);
                } catch (UnsatisfiedLinkError e) {
                    Log.e("ProximityInfo", "Failed to release native memory", e);
                }
                this.mNativeProximityInfo = 0;
            }
        } finally {
            super.finalize();
        }
    }

    private void computeNearestNeighbors(int defaultWidth, List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection) {
        int thresholdBase = (int) (defaultWidth * SEARCH_DISTANCE);
        int threshold = thresholdBase * thresholdBase;
        int[] indices = new int[keys.size()];
        int gridWidth = this.mGridWidth * this.mCellWidth;
        int gridHeight = this.mGridHeight * this.mCellHeight;
        int x = 0;
        while (x < gridWidth) {
            int y = 0;
            while (y < gridHeight) {
                int centerX = x + (this.mCellWidth / 2);
                int centerY = y + (this.mCellHeight / 2);
                int count = 0;
                for (int i = 0; i < keys.size(); i++) {
                    Keyboard.Key key = keys.get(i);
                    if (key.codes[0] == 32) {
                        // مسافة
                    }
                    if (key.squaredDistanceFrom(centerX, centerY) < threshold) {
                        indices[count] = i;
                        count++;
                    }
                }
                int[] cell = new int[count];
                System.arraycopy(indices, 0, cell, 0, count);
                int index = ((y / this.mCellHeight) * this.mGridWidth) + (x / this.mCellWidth);
                if (index < this.mGridNeighbors.length) {
                    this.mGridNeighbors[index] = cell;
                }
                y += this.mCellHeight;
            }
            x += this.mCellWidth;
        }
        setProximityInfo(this.mGridNeighbors, this.mKeyboardMinWidth, this.mKeyboardHeight, keys, touchPositionCorrection);
    }

    int getStartIndexFromCoordinates(int x, int y) {
        return (((y / this.mCellHeight) * this.mGridWidth) + (x / this.mCellWidth)) * 16;
    }

    public int[] getNearestKeys(int x, int y) {
        int index;
        if (this.mGridNeighbors == null || this.mCellWidth == 0 || this.mCellHeight == 0) {
            return EMPTY_INT_ARRAY;
        }
        if (x >= 0 && x < this.mKeyboardMinWidth && y >= 0 && y < this.mKeyboardHeight && (index = ((y / this.mCellHeight) * this.mGridWidth) + (x / this.mCellWidth)) < this.mGridSize) {
            return this.mGridNeighbors[index];
        }
        return EMPTY_INT_ARRAY;
    }
}

/*
/* JADX INFO: loaded from: classes.dex */
/*
public class ProximityInfo {
    public static final int MAX_PROXIMITY_CHARS_SIZE = 16;
    private final int mCellHeight;
    private final int mCellWidth;
    private final int mGridHeight;
    private final int[][] mGridNeighbors;
    private final int mGridSize;
    private final int mGridWidth;
    private final int mKeyHeight;
    private final int mKeyboardHeight;
    private final int mKeyboardMinWidth;
    private int mNativeProximityInfo;
    private static float SEARCH_DISTANCE = 1.2f;
    private static final int[] EMPTY_INT_ARRAY = new int[0];

    private native void releaseProximityInfoNative(int i);

    private native int setProximityInfoNative(int i, int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2, int[] iArr3, int[] iArr4, int[] iArr5, int[] iArr6, float[] fArr, float[] fArr2, float[] fArr3);

    static {
        try {
            System.loadLibrary("jni_latinime_pt2_new");
        } catch (UnsatisfiedLinkError e) {
            Log.e("ProximityInfo", "Could not load native library jni_latinime_pt2_new");
        }
    }

    ProximityInfo(int gridWidth, int gridHeight, int minWidth, int height, int keyWidth, int keyHeight, List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection) {
        this.mGridWidth = gridWidth;
        this.mGridHeight = gridHeight;
        this.mGridSize = this.mGridWidth * this.mGridHeight;
        this.mCellWidth = ((this.mGridWidth + minWidth) - 1) / this.mGridWidth;
        this.mCellHeight = ((this.mGridHeight + height) - 1) / this.mGridHeight;
        this.mKeyboardMinWidth = minWidth;
        this.mKeyboardHeight = height;
        this.mKeyHeight = keyHeight;
        this.mGridNeighbors = new int[this.mGridSize][];
        if (minWidth != 0 && height != 0) {
            computeNearestNeighbors(keyWidth, keys, touchPositionCorrection);
        }
    }

    public static ProximityInfo createDummyProximityInfo() {
        List<Keyboard.Key> keys=new ArrayList<Keyboard.Key>();
        return new ProximityInfo(1, 1, 1, 1, 1, 1, keys, null);
    }

    public static ProximityInfo createSpellCheckerProximityInfo() {
        ProximityInfo spellCheckerProximityInfo = createDummyProximityInfo();
        spellCheckerProximityInfo.mNativeProximityInfo = spellCheckerProximityInfo.setProximityInfoNative(16, 480, 300, 10, 3, SpellCheckerProximityInfo.PROXIMITY, 0, null, null, null, null, null, null, null, null);
        return spellCheckerProximityInfo;
    }

    private final void setProximityInfo(int[][] gridNeighborKeyIndexes, int keyboardWidth, int keyboardHeight, List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection) {
        int[] proximityCharsArray = new int[this.mGridSize * 16];
        Arrays.fill(proximityCharsArray, -1);
        for (int i = 0; i < this.mGridSize; i++) {
            int proximityCharsLength = gridNeighborKeyIndexes[i].length;
            for (int j = 0; j < proximityCharsLength; j++) {
                proximityCharsArray[(i * 16) + j] = keys.get(gridNeighborKeyIndexes[i][j]).codes[0];
            }
        }
        int keyCount = keys.size();
        int[] keyXCoordinates = new int[keyCount];
        int[] keyYCoordinates = new int[keyCount];
        int[] keyWidths = new int[keyCount];
        int[] keyHeights = new int[keyCount];
        int[] keyCharCodes = new int[keyCount];
        for (int i2 = 0; i2 < keyCount; i2++) {
            Keyboard.Key key = keys.get(i2);
            keyXCoordinates[i2] = key.x + (key.gap / 2);
            keyYCoordinates[i2] = key.y;
            keyWidths[i2] = key.width;
            keyHeights[i2] = key.height;
            keyCharCodes[i2] = key.codes[0];
        }
        float[] sweetSpotCenterXs = null;
        float[] sweetSpotCenterYs = null;
        float[] sweetSpotRadii = null;
        if (touchPositionCorrection != null && touchPositionCorrection.isValid()) {
            sweetSpotCenterXs = new float[keyCount];
            sweetSpotCenterYs = new float[keyCount];
            sweetSpotRadii = new float[keyCount];
            calculateSweetSpot(keys, touchPositionCorrection, sweetSpotCenterXs, sweetSpotCenterYs, sweetSpotRadii);
        }
        this.mNativeProximityInfo = setProximityInfoNative(16, keyboardWidth, keyboardHeight, this.mGridWidth, this.mGridHeight, proximityCharsArray, keyCount, keyXCoordinates, keyYCoordinates, keyWidths, keyHeights, keyCharCodes, sweetSpotCenterXs, sweetSpotCenterYs, sweetSpotRadii);
    }

    private void calculateSweetSpot(List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection, float[] sweetSpotCenterXs, float[] sweetSpotCenterYs, float[] sweetSpotRadii) {
        int keyCount = keys.size();
        float[] xs = touchPositionCorrection.mXs;
        float[] ys = touchPositionCorrection.mYs;
        float[] radii = touchPositionCorrection.mRadii;
        for (int i = 0; i < keyCount; i++) {
            Keyboard.Key key = keys.get(i);
            int row = key.x / this.mKeyHeight;
            if (row < radii.length) {
                float hitBoxCenterX = (key.width + 1) * 0.5f;
                float hitBoxCenterY = key.height * 0.5f;
                float hitBoxWidth = key.width + 1;
                float hitBoxHeight = key.height;
                float x = xs[row];
                float y = ys[row];
                float radius = radii[row];
                sweetSpotCenterXs[i] = (x * hitBoxWidth) + hitBoxCenterX;
                sweetSpotCenterYs[i] = (y * hitBoxHeight) + hitBoxCenterY;
                sweetSpotRadii[i] = ((float) Math.sqrt((hitBoxWidth * hitBoxWidth) + (hitBoxHeight * hitBoxHeight))) * radius;
            }
        }
    }

    public int getNativeProximityInfo() {
        return this.mNativeProximityInfo;
    }

    protected void finalize() throws Throwable {
        try {
            if (this.mNativeProximityInfo != 0) {
                releaseProximityInfoNative(this.mNativeProximityInfo);
                this.mNativeProximityInfo = 0;
            }
        } finally {
            super.finalize();
        }
    }

    private void computeNearestNeighbors(int defaultWidth, List<Keyboard.Key> keys, LatinKeyboard.TouchPositionCorrection touchPositionCorrection) {
        int thresholdBase = (int) (defaultWidth * SEARCH_DISTANCE);
        int threshold = thresholdBase * thresholdBase;
        int[] indices = new int[keys.size()];
        int gridWidth = this.mGridWidth * this.mCellWidth;
        int gridHeight = this.mGridHeight * this.mCellHeight;
        int x = 0;
        while (x < gridWidth) {
            int y = 0;
            while (y < gridHeight) {
                int centerX = x + (this.mCellWidth / 2);
                int centerY = y + (this.mCellHeight / 2);
                int count = 0;
                for (int i = 0; i < keys.size(); i++) {
                    Keyboard.Key key = keys.get(i);
                    if (key.codes[0] == 32) {
                    }
                    if (key.squaredDistanceFrom(centerX, centerY) < threshold) {
                        indices[count] = i;
                        count++;
                    }
                }
                int[] cell = new int[count];
                System.arraycopy(indices, 0, cell, 0, count);
                this.mGridNeighbors[((y / this.mCellHeight) * this.mGridWidth) + (x / this.mCellWidth)] = cell;
                y += this.mCellHeight;
            }
            x += this.mCellWidth;
        }
        setProximityInfo(this.mGridNeighbors, this.mKeyboardMinWidth, this.mKeyboardHeight, keys, touchPositionCorrection);
    }

    int getStartIndexFromCoordinates(int x, int y) {
        return (((y / this.mCellHeight) * this.mGridWidth) + (x / this.mCellWidth)) * 16;
    }

    public int[] getNearestKeys(int x, int y) {
        int index;
        if (this.mGridNeighbors == null) {
            return EMPTY_INT_ARRAY;
        }
        if (x >= 0 && x < this.mKeyboardMinWidth && y >= 0 && y < this.mKeyboardHeight && (index = ((y / this.mCellHeight) * this.mGridWidth) + (x / this.mCellWidth)) < this.mGridSize) {
            return this.mGridNeighbors[index];
        }
        return EMPTY_INT_ARRAY;
    }
}*/
