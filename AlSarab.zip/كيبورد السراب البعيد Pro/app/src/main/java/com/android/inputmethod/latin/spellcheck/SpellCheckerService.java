package com.android.inputmethod.latin.spellcheck;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/* JADX INFO: loaded from: classes.dex */
public abstract class SpellCheckerService extends Service {
    private static final boolean DBG = false;
    public static final String SERVICE_INTERFACE = "android.service.textservice.SpellCheckerService";
    private static final String TAG = SpellCheckerService.class.getSimpleName();
    private final IBinder mBinder = null;

    public abstract Session createSession();

    public abstract SuggestionsInfo onGetSuggestions(TextInfo textInfo, int i);

    @Override // android.app.Service
    public final IBinder onBind(Intent intent) {
        return this.mBinder;
    }

    public SuggestionsInfo[] onGetSuggestionsMultiple(TextInfo[] textInfos, int suggestionsLimit, boolean sequentialWords) {
        int length = textInfos.length;
        SuggestionsInfo[] retval = new SuggestionsInfo[length];
        for (int i = 0; i < length; i++) {
            retval[i] = onGetSuggestions(textInfos[i], suggestionsLimit);
        }
        return retval;
    }

    public void onCancel() {
    }

    public String getLocale() {
        return "en";
    }
}
