package com.android.inputmethod.latin;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import com.android.common.speech.LoggingEvents;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public class LanguageSwitcher {
    private String mDefaultInputLanguage;
    private Locale mDefaultInputLocale;
    private DictionaryEditor mIme;
    private String[] mSelectedLanguageArray;
    private String mSelectedLanguages;
    private Locale mSystemLocale;
    private String mDefaultInputLayout = "qwerty";
    private int mCurrentIndex = 0;
    private Locale[] mLocales = new Locale[0];

    public LanguageSwitcher(DictionaryEditor ime) {
        this.mIme = ime;
    }

    public Locale[] getLocales() {
        return this.mLocales;
    }

    public int getLocaleCount() {
        return this.mLocales.length;
    }

    public boolean loadLocales(SharedPreferences sp) {
        String selectedLanguages = sp.getString(DictionaryEditor.PREF_SELECTED_LANGUAGES, "ar,en,ar_dvorak,en_dvorak,ar_azerty");
        String currentLanguage = sp.getString(DictionaryEditor.PREF_INPUT_LANGUAGE, LoggingEvents.EXTRA_CALLING_APP_NAME);
        if (selectedLanguages == null || selectedLanguages.length() < 1) {
            loadDefaults();
            if (this.mLocales.length == 0) {
                return false;
            }
            this.mLocales = new Locale[0];
            return true;
        }
        if (selectedLanguages.equals(this.mSelectedLanguages)) {
            return false;
        }
        this.mSelectedLanguageArray = selectedLanguages.split(",");
        this.mSelectedLanguages = selectedLanguages;
        constructLocales();
        this.mCurrentIndex = 0;
        if (currentLanguage != null) {
            this.mCurrentIndex = 0;
            int i = 0;
            while (true) {
                if (i >= this.mLocales.length) {
                    break;
                }
                if (!this.mSelectedLanguageArray[i].equals(currentLanguage)) {
                    i++;
                } else {
                    this.mCurrentIndex = i;
                    break;
                }
            }
        }
        return true;
    }

    private void loadDefaults() {
        this.mDefaultInputLocale = this.mIme.getResources().getConfiguration().locale;
        String country = this.mDefaultInputLocale.getCountry();
        this.mDefaultInputLanguage = String.valueOf(this.mDefaultInputLocale.getLanguage()) + (TextUtils.isEmpty(country) ? LoggingEvents.EXTRA_CALLING_APP_NAME : "_" + country);
    }

    private void constructLocales() {
        this.mLocales = new Locale[this.mSelectedLanguageArray.length];
        for (int i = 0; i < this.mLocales.length; i++) {
            String lang = this.mSelectedLanguageArray[i];
            this.mLocales[i] = new Locale(lang.substring(0, 2), LoggingEvents.EXTRA_CALLING_APP_NAME);
        }
    }

    public String getInputLanguage() {
        return getLocaleCount() == 0 ? this.mDefaultInputLanguage : this.mSelectedLanguageArray[this.mCurrentIndex].substring(0, 2);
    }

    public String getInputLayout() {
        if (getLocaleCount() == 0) {
            return this.mDefaultInputLayout;
        }
        if (this.mSelectedLanguageArray[this.mCurrentIndex].contains("_")) {
            return this.mSelectedLanguageArray[this.mCurrentIndex].substring(3, this.mSelectedLanguageArray[this.mCurrentIndex].length());
        }
        return this.mDefaultInputLayout;
    }

    public String[] getEnabledLanguages() {
        return this.mSelectedLanguageArray;
    }

    public Locale getInputLocale() {
        return getLocaleCount() == 0 ? this.mDefaultInputLocale : this.mLocales[this.mCurrentIndex];
    }

    public Locale getNextInputLocale() {
        return getLocaleCount() == 0 ? this.mDefaultInputLocale : this.mLocales[(this.mCurrentIndex + 1) % this.mLocales.length];
    }

    public void setSystemLocale(Locale locale) {
        this.mSystemLocale = locale;
    }

    public Locale getSystemLocale() {
        return this.mSystemLocale;
    }

    public Locale getPrevInputLocale() {
        return getLocaleCount() == 0 ? this.mDefaultInputLocale : this.mLocales[((this.mCurrentIndex - 1) + this.mLocales.length) % this.mLocales.length];
    }

    public void reset() {
        this.mCurrentIndex = 0;
    }

    public void next() {
        this.mCurrentIndex++;
        if (this.mCurrentIndex >= this.mLocales.length) {
            this.mCurrentIndex = 0;
        }
    }

    public void prev() {
        this.mCurrentIndex--;
        if (this.mCurrentIndex < 0) {
            this.mCurrentIndex = this.mLocales.length - 1;
        }
    }

    public void persist() {
        new presistWrite(this, null).execute(new Void[0]);
    }

    private class presistWrite extends AsyncTask<Void, Void, Void> {
        private presistWrite() {
        }

        /* synthetic */ presistWrite(LanguageSwitcher languageSwitcher, presistWrite presistwrite) {
            this();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public Void doInBackground(Void... v) {
            SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(LanguageSwitcher.this.mIme);
            SharedPreferences.Editor editor = sp.edit();
            editor.putString(DictionaryEditor.PREF_INPUT_LANGUAGE, LanguageSwitcher.this.getInputLanguage());
            SharedPreferencesCompat.apply(editor);
            return null;
        }
    }

    static String toTitleCase(String s) {
        return s.length() == 0 ? s : String.valueOf(Character.toUpperCase(s.charAt(0))) + s.substring(1);
    }
}
