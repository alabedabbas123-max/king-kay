package com.android.inputmethod.latin;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public class BinaryDictionaryFileDumper {
    private static final boolean DEBUG = false;
    private static final int FILE_READ_BUFFER_SIZE = 1024;
    private static final String TAG = BinaryDictionaryFileDumper.class.getSimpleName();
    private static final byte[] MAGIC_NUMBER = {120, -79};
    private static final String[] DICTIONARY_PROJECTION = {"id"};

    private static Throwable th;

    private BinaryDictionaryFileDumper() {
    }

    private static Uri getProviderUri(String path) {
        return new Uri.Builder().scheme("content").authority(BinaryDictionary.DICTIONARY_PACK_AUTHORITY).appendPath(path).build();
    }

    private static List<WordListInfo> getWordListWordListInfos(Locale locale, Context context) {
        ContentResolver resolver = context.getContentResolver();
        Uri dictionaryPackUri = getProviderUri(locale.toString());
        Cursor c = resolver.query(dictionaryPackUri, DICTIONARY_PROJECTION, null, null, null);
        if (c == null) {
            return Collections.emptyList();
        }
        if (c.getCount() <= 0 || !c.moveToFirst()) {
            c.close();
            return Collections.emptyList();
        }
        try {
            List<WordListInfo> list = new ArrayList<>();
            do {
                String wordListId = c.getString(0);
                String wordListLocale = c.getString(1);
                if (!TextUtils.isEmpty(wordListId)) {
                    list.add(new WordListInfo(wordListId, wordListLocale));
                }
            } while (c.moveToNext());
            c.close();
            return list;
        } catch (Exception e) {
            Log.e(TAG, "Exception communicating with the dictionary pack : " + e);
            return Collections.emptyList();
        }
    }

    private static AssetFileDescriptor openAssetFileDescriptor(ContentResolver resolver, Uri uri) {
        try {
            return resolver.openAssetFileDescriptor(uri, "r");
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Could not find a word list from the dictionary provider.");
            return null;
        }
    }

    private static AssetFileAddress cacheWordList(String id, String locale, ContentResolver resolver, Context context) throws Throwable {
        FileOutputStream outputStream = null;
        Uri wordListUri = getProviderUri(id);
        String outputFileName = BinaryDictionaryGetter.getCacheFileName(id, locale, context);
        for (int mode = 0; mode <= 5; mode++) {
            InputStream inputStream = null;
            File outputFile = null;
            FileOutputStream outputStream2 = null;
            AssetFileDescriptor afd = null;
            try {
                try {
                    afd = openAssetFileDescriptor(resolver, wordListUri);
                    if (afd == null) {
                        if (afd != null) {
                            try {
                                afd.close();
                            } catch (Exception e) {
                                Log.e(TAG, "Exception while closing a cross-process file descriptor : " + e);
                            }
                        }
                        if (0 != 0) {
                            try {
                                outputStream2.close();
                            } catch (Exception e2) {
                                Log.e(TAG, "Exception while closing a file : " + e2);
                            }
                        }
                        return null;
                    }
                    InputStream originalSourceStream = afd.createInputStream();
                    File outputFile2 = new File(outputFileName);
                    try {
                        outputStream = new FileOutputStream(outputFile2);
                    } catch (Exception e3) {
                        outputFile = outputFile2;
                    } catch (Throwable th) {
                        th = th;
                    }
                    try {
                        switch (mode) {
                            case 0:
                                inputStream = FileTransforms.getUncompressedStream(FileTransforms.getDecryptedStream(FileTransforms.getUncompressedStream(originalSourceStream)));
                                break;
                            case 1:
                                inputStream = FileTransforms.getUncompressedStream(FileTransforms.getDecryptedStream(originalSourceStream));
                                break;
                            case 2:
                                inputStream = FileTransforms.getDecryptedStream(FileTransforms.getUncompressedStream(originalSourceStream));
                                break;
                            case 3:
                                inputStream = FileTransforms.getUncompressedStream(originalSourceStream);
                                break;
                            case 4:
                                inputStream = FileTransforms.getDecryptedStream(originalSourceStream);
                                break;
                            case 5:
                                inputStream = originalSourceStream;
                                break;
                        }
                        checkMagicAndCopyFileTo(new BufferedInputStream(inputStream), outputStream);
                        if (resolver.delete(wordListUri, null, null) <= 0) {
                            Log.e(TAG, "Could not have the dictionary pack delete a word list");
                        }
                        AssetFileAddress assetFileAddressMakeFromFileName = AssetFileAddress.makeFromFileName(outputFileName);
                        if (afd != null) {
                            try {
                                afd.close();
                            } catch (Exception e4) {
                                Log.e(TAG, "Exception while closing a cross-process file descriptor : " + e4);
                            }
                        }
                        if (outputStream == null) {
                            return assetFileAddressMakeFromFileName;
                        }
                        try {
                            outputStream.close();
                            return assetFileAddressMakeFromFileName;
                        } catch (Exception e5) {
                            Log.e(TAG, "Exception while closing a file : " + e5);
                            return assetFileAddressMakeFromFileName;
                        }
                    } catch (Exception e6) {
                        outputStream2 = outputStream;
                        outputFile = outputFile2;
                    } catch (Throwable th2) {
                        th = th2;
                        outputStream2 = outputStream;
                        if (afd != null) {
                            try {
                                afd.close();
                            } catch (Exception e7) {
                                Log.e(TAG, "Exception while closing a cross-process file descriptor : " + e7);
                            }
                        }
                        if (outputStream2 != null) {
                            try {
                                outputStream2.close();
                            } catch (Exception e8) {
                                Log.e(TAG, "Exception while closing a file : " + e8);
                            }
                        }
                        throw th;
                    }
                } catch (Exception e9) {
                }
                if (outputFile != null) {
                    outputFile.delete();
                }
                if (afd != null) {
                    try {
                        afd.close();
                    } catch (Exception e10) {
                        Log.e(TAG, "Exception while closing a cross-process file descriptor : " + e10);
                    }
                }
                if (outputStream2 != null) {
                    try {
                        outputStream2.close();
                    } catch (Exception e11) {
                        Log.e(TAG, "Exception while closing a file : " + e11);
                    }
                }
            } catch (Throwable th3) {
                th = th3;
            }
        }
        Log.e(TAG, "Could not copy a word list. Will not be able to use it.");
        if (resolver.delete(wordListUri, null, null) <= 0) {
            Log.e(TAG, "In addition, we were unable to delete it.");
        }
        return null;
    }

    public static List<AssetFileAddress> cacheWordListsFromContentProvider(Locale locale, Context context) throws Throwable {
        ContentResolver resolver = context.getContentResolver();
        List<WordListInfo> idList = getWordListWordListInfos(locale, context);
        List<AssetFileAddress> fileAddressList = new ArrayList<>();
        for (WordListInfo id : idList) {
            AssetFileAddress afd = cacheWordList(id.mId, id.mLocale, resolver, context);
            if (afd != null) {
                fileAddressList.add(afd);
            }
        }
        return fileAddressList;
    }

    private static void checkMagicAndCopyFileTo(BufferedInputStream input, FileOutputStream output) throws IOException {
        byte[] magicNumberBuffer = new byte[MAGIC_NUMBER.length];
        int readMagicNumberSize = input.read(magicNumberBuffer, 0, MAGIC_NUMBER.length);
        if (readMagicNumberSize < MAGIC_NUMBER.length) {
            throw new IOException("Less bytes to read than the magic number length");
        }
        if (!Arrays.equals(MAGIC_NUMBER, magicNumberBuffer)) {
            throw new IOException("Wrong magic number for downloaded file");
        }
        output.write(MAGIC_NUMBER);
        byte[] buffer = new byte[1024];
        int readBytes = input.read(buffer);
        while (readBytes >= 0) {
            output.write(buffer, 0, readBytes);
            readBytes = input.read(buffer);
        }
        input.close();
    }
}
