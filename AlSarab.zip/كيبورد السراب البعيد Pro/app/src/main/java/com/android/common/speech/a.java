package com.android.common.speech;

/* JADX INFO: compiled from: CIL */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: Dependency scan failed
        jadx.core.utils.exceptions.JadxRuntimeException: Usage info collection failed with error: newPosition > limit: (46917716 > 533872) at insn: 0x0000: INVOKE_SUPER_RANGE r12669, r12670, r12671, r12672, r12673, r12674, r12675, r12676, r12677, r12678, r12679, r12680, r12681, r12682, r12683, r12684, r12685, r12686, r12687, r12688, r12689, r12690, r12691, r12692, r12693, r12694, r12695, r12696, r12697, r12698, r12699, r12700, r12701, r12702, r12703, r12704, r12705, r12706, r12707, r12708, r12709, r12710, r12711, r12712, r12713, r12714, r12715, r12716, r12717, r12718, r12719, r12720, r12721, r12722, r12723, r12724, r12725, r12726, r12727, r12728, r12729, r12730, r12731, r12732, r12733, r12734, r12735, r12736, r12737, r12738, r12739, r12740, r12741, r12742, r12743, r12744, r12745, r12746, r12747, r12748, r12749, r12750
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.lambda$processInstructions$0(UsageInfoVisitor.java:133)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:86)
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.processInstructions(UsageInfoVisitor.java:128)
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.processMethod(UsageInfoVisitor.java:113)
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.processClass(UsageInfoVisitor.java:101)
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.buildUsageData(UsageInfoVisitor.java:81)
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.init(UsageInfoVisitor.java:65)
        	at jadx.core.dex.nodes.RootNode.runPreDecompileStage(RootNode.java:376)
        Caused by: java.lang.IllegalArgumentException: newPosition > limit: (46917716 > 533872)
        	at java.base/java.nio.Buffer.createPositionException(Buffer.java:352)
        	at java.base/java.nio.Buffer.position(Buffer.java:327)
        	at java.base/java.nio.ByteBuffer.position(ByteBuffer.java:1551)
        	at jadx.plugins.input.dex.sections.SectionReader.absPos(SectionReader.java:82)
        	at jadx.plugins.input.dex.sections.SectionReader.readTypeListAt(SectionReader.java:141)
        	at jadx.plugins.input.dex.sections.SectionReader.loadMethodRef(SectionReader.java:269)
        	at jadx.plugins.input.dex.sections.DexMethodRef.load(DexMethodRef.java:28)
        	at jadx.core.dex.info.MethodInfo.fromRef(MethodInfo.java:47)
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.processInsn(UsageInfoVisitor.java:166)
        	at jadx.core.dex.visitors.usage.UsageInfoVisitor.lambda$processInstructions$0(UsageInfoVisitor.java:130)
        	... 7 more
        */
    public java.lang.String a() {
        /*
            r1 = this;
            // decode failed: newPosition > limit: (46917716 > 533872)
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.common.speech.a.a():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: ARITH (r15 I:int) = (r15 I:int) % (r0 I:int), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int b() {
        /*
            r1 = this;
            int r15 = r15 % r0
            long r12 = r12 ^ r11
            return r205
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.common.speech.a.b():int");
    }
}
