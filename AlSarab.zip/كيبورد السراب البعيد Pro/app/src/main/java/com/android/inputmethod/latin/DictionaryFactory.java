package com.android.inputmethod.latin;

import DictionaryPackage.DicatinaryPackage;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.util.Log;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public class DictionaryFactory {
    private static final long PLACEHOLDER_LENGTH = 34;
    private static String TAG = DictionaryFactory.class.getSimpleName();

    public static DictionaryCollection createDictionaryFromManager(Context context, Locale locale, int fallbackResId, Flag[] flagArray) throws Throwable {
        if (locale == null) {
            Log.e(TAG, "No locale defined for dictionary");
            return new DictionaryCollection(createBinaryDictionary(context, fallbackResId, locale));
        }
        List<Dictionary> dictList = new LinkedList<>();
        List<AssetFileAddress> assetFileList = BinaryDictionaryGetter.getDictionaryFiles(locale, context, fallbackResId);
        if (assetFileList != null) {
            for (AssetFileAddress f : assetFileList) {
                BinaryDictionary binaryDictionary = new BinaryDictionary(context, f.mFilename, f.mOffset, f.mLength, flagArray);
                if (binaryDictionary.isValidDictionary()) {
                    dictList.add(binaryDictionary);
                }
            }
        }
        return new DictionaryCollection(dictList);
    }

    public static DictionaryCollection createDictionaryFromManager(Context context, Locale locale, int fallbackResId){
        try {
            return createDictionaryFromManager(context, locale, fallbackResId, null);
        } catch (Throwable e) {
            return null;
        }
    }

    protected static BinaryDictionary createBinaryDictionary(Context context, int resId, Locale locale) throws Throwable {
        AssetFileDescriptor afd;
        AssetFileDescriptor afd2 = null;
        try {
            try {
                Resources res = context.getResources();
                if (locale != null) {
                    Locale savedLocale = LocaleUtils.setSystemLocale(res, locale);
                    afd = Utils.openRawResourceFd(res, resId);
                    LocaleUtils.setSystemLocale(res, savedLocale);
                } else {
                    afd = Utils.openRawResourceFd(res, resId);
                }
                if (afd == null) {
                    Log.e(TAG, "Found the resource but it is compressed. resId=" + resId);
                } else if (isFullDictionary(afd)) {
                    String sourceDir = context.getApplicationInfo().sourceDir;
                    File packagePath = new File(sourceDir);
                    if (!packagePath.isFile()) {
                        Log.e(TAG, "sourceDir is not a file: " + sourceDir);
                        if (afd != null) {
                            try {
                                afd.close();
                            } catch (IOException e) {
                            }
                        }
                        return null;
                    }
                    BinaryDictionary binaryDictionary = new BinaryDictionary(context, sourceDir, afd.getStartOffset(), afd.getLength(), null);
                    if (afd == null) {
                        return binaryDictionary;
                    }
                    try {
                        afd.close();
                        return binaryDictionary;
                    } catch (IOException e2) {
                        return binaryDictionary;
                    }
                }
                if (afd != null) {
                    try {
                        afd.close();
                    } catch (IOException e3) {
                    }
                }
                return null;
            } catch (Resources.NotFoundException e4) {
                Log.e(TAG, "Could not find the resource. resId=" + resId);
                if (0 != 0) {
                    try {
                        afd2.close();
                    } catch (IOException e5) {
                    }
                }
                return null;
            }
        } catch (Throwable th) {
            if (0 != 0) {
                try {
                    afd2.close();
                } catch (IOException e6) {
                }
            }
            throw th;
        }
    }

    public static Dictionary createDictionaryForTest(Context context, File dictionary, long startOffset, long length, Flag[] flagArray) {
        if (dictionary.isFile()) {
            return new BinaryDictionary(context, dictionary.getAbsolutePath(), startOffset, length, flagArray);
        }
        Log.e(TAG, "Could not find the file. path=" + dictionary.getAbsolutePath());
        return null;
    }

    public static boolean isDictionaryAvailable(Context context, Locale locale) {
        Resources res = context.getResources();
        Locale saveLocale = LocaleUtils.setSystemLocale(res, locale);
        int resourceId = Utils.getMainDictionaryResourceId(res);
        AssetFileDescriptor afd = Utils.openRawResourceFd(res, resourceId);
        boolean hasDictionary = isFullDictionary(afd);
        if (afd != null) {
            try {
                afd.close();
            } catch (IOException e) {
            }
        }
        LocaleUtils.setSystemLocale(res, saveLocale);
        return hasDictionary;
    }

    public static Long getDictionaryId(Context context, Locale locale) {
        Long size;
        Resources res = context.getResources();
        Locale saveLocale = LocaleUtils.setSystemLocale(res, locale);
        int resourceId = Utils.getMainDictionaryResourceId(res);
        ArrayList<DicatinaryPackage.DictionaryBuilder> DictionaryBuilderASK = DicatinaryPackage.getAllBuilders(context);
        int length = DictionaryBuilderASK.size();
        int i = 0;
        while (true) {
            if (i >= length) {
                break;
            }
            String lang = locale.getLanguage();
            if (lang.equalsIgnoreCase("he")) {
                lang = "iw";
            }
            if (!DictionaryBuilderASK.get(i).getLanguage().equals(lang)) {
                i++;
            } else {
                resourceId = DictionaryBuilderASK.get(i).getDictionaryResourceId();
                res = DictionaryBuilderASK.get(i).getPackageContext().getResources();
                break;
            }
        }
        AssetFileDescriptor afd = Utils.openRawResourceFd(res, resourceId);
        if (afd != null && afd.getLength() > PLACEHOLDER_LENGTH) {
            size = Long.valueOf(afd.getLength());
        } else {
            size = null;
        }
        if (afd != null) {
            try {
                afd.close();
            } catch (IOException e) {
            }
        }
        LocaleUtils.setSystemLocale(res, saveLocale);
        return size;
    }

    protected static boolean isFullDictionary(AssetFileDescriptor afd) {
        return afd != null && afd.getLength() > PLACEHOLDER_LENGTH;
    }
}
