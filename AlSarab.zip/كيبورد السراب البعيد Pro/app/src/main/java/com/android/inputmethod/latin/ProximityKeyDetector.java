package com.android.inputmethod.latin;
import android.inputmethodservice.Keyboard.Key;
import android.inputmethodservice.Keyboard;
import java.util.Arrays;

/* JADX INFO: loaded from: classes.dex */
class ProximityKeyDetector extends KeyDetector {
    private static final int MAX_NEARBY_KEYS = 12;

    // working area
    private int[] mDistances = new int[MAX_NEARBY_KEYS];

    @Override
    protected int getMaxNearbyKeys() {
        return MAX_NEARBY_KEYS;
    }

    @Override
    public int getKeyIndexAndNearbyCodes(int x, int y, int[] allKeys) {
        final Key[] keys = getKeys();
        final int touchX = getTouchX(x);
        final int touchY = getTouchY(y);
        int primaryIndex = LatinKeyboardBaseView.NOT_A_KEY;
        int closestKey = LatinKeyboardBaseView.NOT_A_KEY;
        int closestKeyDist = mProximityThresholdSquare + 1;
        int[] distances = mDistances;
        Arrays.fill(distances, Integer.MAX_VALUE);
        int [] nearestKeyIndices = mKeyboard.getNearestKeys(touchX, touchY);
        final int keyCount = nearestKeyIndices.length;
        for (int i = 0; i < keyCount; i++) {
            final Key key = keys[nearestKeyIndices[i]];
            int dist = 0;
            boolean isInside = key.isInside(touchX, touchY);
            if (isInside) {
                primaryIndex = nearestKeyIndices[i];
            }

            if (((mProximityCorrectOn
                && (dist = key.squaredDistanceFrom(touchX, touchY)) < mProximityThresholdSquare)
                || isInside)
                && key.codes[0] > 32) {
                // Find insertion point
                final int nCodes = key.codes.length;
                if (dist < closestKeyDist) {
                    closestKeyDist = dist;
                    closestKey = nearestKeyIndices[i];
                }

                if (allKeys == null) continue;

                for (int j = 0; j < distances.length; j++) {
                    if (distances[j] > dist) {
                        // Make space for nCodes codes
                        System.arraycopy(distances, j, distances, j + nCodes,
                                         distances.length - j - nCodes);
                        System.arraycopy(allKeys, j, allKeys, j + nCodes,
                                         allKeys.length - j - nCodes);
                        System.arraycopy(key.codes, 0, allKeys, j, nCodes);
                        Arrays.fill(distances, j, j + nCodes, dist);
                        break;
                    }
                }
            }
        }
        if (primaryIndex == LatinKeyboardBaseView.NOT_A_KEY) {
            primaryIndex = closestKey;
        }
        return primaryIndex;
    }
    }
/*
class ProximityKeyDetector extends KeyDetector {
    private static final int MAX_NEARBY_KEYS = 18;
    private int[] mDistances = new int[18];

    ProximityKeyDetector() {
    }

    @Override // com.android.inputmethod.latin.KeyDetector
    protected int getMaxNearbyKeys() {
        return 18;
    }

    @Override // com.android.inputmethod.latin.KeyDetector
    public int getKeyIndexAndNearbyCodes(int x, int y, int[] allKeys) {
        Keyboard.Key[] keys = getKeys();
        if (keys == null || keys.length == 0) {
            return -1;
        }

        int touchX = getTouchX(x);
        int touchY = getTouchY(y);
        int primaryIndex = -1;
        int closestKey = -1;
        int closestKeyDist = this.mProximityThresholdSquare + 1;
        int[] distances = this.mDistances;

        if (distances != null) {
            Arrays.fill(distances, Integer.MAX_VALUE);
        }

        int[] nearestKeyIndices = this.mKeyboard.getNearestKeys(touchX, touchY);
        if (nearestKeyIndices == null) {
            return -1;
        }

        int keyCount = nearestKeyIndices.length;
        for (int i = 0; i < keyCount; i++) {
            int keyIndex = nearestKeyIndices[i];

            // حماية: التحقق من أن دليل المفتاح في النطاق الصحيح وليس -1 أو أكبر من حجم المصفوفة
            if (keyIndex < 0 || keyIndex >= keys.length) {
                continue;
            }

            Keyboard.Key key = keys[keyIndex];
            if (key == null) {
                continue;
            }

            int dist = 0;
            boolean isInside = key.isInside(touchX, touchY);
            if (isInside) {
                primaryIndex = keyIndex;
            }

            if ((this.mProximityCorrectOn && (dist = key.squaredDistanceFrom(touchX, touchY)) < this.mProximityThresholdSquare) || isInside) {
                if (key.codes == null) {
                    continue;
                }

                int nCodes = key.codes.length;
                if (dist < closestKeyDist) {
                    closestKeyDist = dist;
                    closestKey = keyIndex;
                }

                if (allKeys != null && distances != null) {
                    int j = 0;
                    while (true) {
                        if (j >= distances.length - nCodes) {
                            break;
                        }
                        if (distances[j] <= dist) {
                            j++;
                        } else {
                            System.arraycopy(distances, j, distances, j + nCodes, (distances.length - j) - nCodes);
                            System.arraycopy(allKeys, j, allKeys, j + nCodes, (allKeys.length - j) - nCodes);
                            System.arraycopy(key.codes, 0, allKeys, j, nCodes);
                            Arrays.fill(distances, j, j + nCodes, dist);
                            break;
                        }
                    }
                }
            }
        }

        if (primaryIndex == -1) {
            return closestKey;
        }
        return primaryIndex;
    }
    */
    
    
    
    /*public int getKeyIndexAndNearbyCodes(int x, int y, int[] allKeys) {
        Keyboard.Key[] keys = getKeys();
        int touchX = getTouchX(x);
        int touchY = getTouchY(y);
        int primaryIndex = -1;
        int closestKey = -1;
        int closestKeyDist = this.mProximityThresholdSquare + 1;
        int[] distances = this.mDistances;
        Arrays.fill(distances, Integer.MAX_VALUE);
        int[] nearestKeyIndices = this.mKeyboard.getNearestKeys(touchX, touchY);
        int keyCount = nearestKeyIndices.length;
        for (int i = 0; i < keyCount; i++) {
            Keyboard.Key key = keys[nearestKeyIndices[i]];
            int dist = 0;
            boolean isInside = key.isInside(touchX, touchY);
            if (isInside) {
                primaryIndex = nearestKeyIndices[i];
            }
            if ((this.mProximityCorrectOn && (dist = key.squaredDistanceFrom(touchX, touchY)) < this.mProximityThresholdSquare) || isInside) {
                int nCodes = key.codes.length;
                if (dist < closestKeyDist) {
                    closestKeyDist = dist;
                    closestKey = nearestKeyIndices[i];
                }
                if (allKeys != null) {
                    int j = 0;
                    while (true) {
                        if (j >= distances.length - nCodes) {
                            break;
                        }
                        if (distances[j] <= dist) {
                            j++;
                        } else {
                            System.arraycopy(distances, j, distances, j + nCodes, (distances.length - j) - nCodes);
                            System.arraycopy(allKeys, j, allKeys, j + nCodes, (allKeys.length - j) - nCodes);
                            System.arraycopy(key.codes, 0, allKeys, j, nCodes);
                            Arrays.fill(distances, j, j + nCodes, dist);
                            break;
                        }
                    }
                }
            }
        }
        if (primaryIndex == -1) {
            int primaryIndex2 = closestKey;
            return primaryIndex2;
        }
        return primaryIndex;
    }*/

