package com.android.inputmethod.latin;

import android.view.View;
import android.widget.EditText;
import inputmethod.latin.perfectkeyboard.R;

/* JADX INFO: compiled from: CustomDitctionaryEditor.java */
/* JADX INFO: loaded from: classes.dex */
class CustomDialogWrapper {
    View base;
    EditText localeField;
    EditText wordField;

    CustomDialogWrapper(View base) {
        this.wordField = null;
        this.localeField = null;
        this.base = null;
        this.base = base;
        this.wordField = (EditText) base.findViewById(R.id.theword);
        this.localeField = (EditText) base.findViewById(R.id.thelocale);
    }

    String getWord() {
        return getwordField().getText().toString();
    }

    String getLocale() {
        return getlocaleField().getText().toString();
    }

    private EditText getwordField() {
        if (this.wordField == null) {
            this.wordField = (EditText) this.base.findViewById(R.id.theword);
        }
        return this.wordField;
    }

    private EditText getlocaleField() {
        if (this.localeField == null) {
            this.localeField = (EditText) this.base.findViewById(R.id.thelocale);
        }
        return this.localeField;
    }
}
