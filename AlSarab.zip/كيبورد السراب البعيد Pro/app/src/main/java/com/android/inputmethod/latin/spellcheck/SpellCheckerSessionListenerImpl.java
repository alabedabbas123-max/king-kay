package com.android.inputmethod.latin.spellcheck;

/* JADX INFO: loaded from: classes.dex */
public class SpellCheckerSessionListenerImpl {
}
