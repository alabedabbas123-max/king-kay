package com.android.common;

/* JADX INFO: compiled from: CANCEL_DURING_ERROR */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: Failed to decode insn: 0x0002: UNKNOWN(0x93F6)
        jadx.core.utils.exceptions.DecodeException: Unknown instruction: '0x0002: UNKNOWN(0x93F6)'
        	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:513)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:51)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:86)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public java.lang.String a() {
        /*
            r1 = this;
            int r13 = r13 % r11
            double r13 = r13 % r0
            // decode failed: Unknown instruction: '0x0002: UNKNOWN(0x93F6)'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.common.a.a():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: CAST (r9 I:short) = (short) (r7 I:int), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int b() {
        /*
            r1 = this;
            short r9 = (short) r7
            r11 = r12
            int r8 = r8 >> r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.common.a.b():int");
    }
}
