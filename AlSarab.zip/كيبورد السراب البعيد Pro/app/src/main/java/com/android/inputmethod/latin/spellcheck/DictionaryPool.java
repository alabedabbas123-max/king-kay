package com.android.inputmethod.latin.spellcheck;

import java.util.Locale;
import java.util.concurrent.LinkedBlockingQueue;

/* JADX INFO: loaded from: classes.dex */
public class DictionaryPool extends LinkedBlockingQueue<DictAndProximity> {
    private final Locale mLocale;
    private final int mMaxSize;
    private final AndroidSpellCheckerService mService;
    private int mSize = 0;
    private volatile boolean mClosed = false;

    public DictionaryPool(int maxSize, AndroidSpellCheckerService service, Locale locale) {
        this.mMaxSize = maxSize;
        this.mService = service;
        this.mLocale = locale;
    }

    @Override // java.util.concurrent.LinkedBlockingQueue, java.util.concurrent.BlockingQueue
    public DictAndProximity take() throws InterruptedException {
        DictAndProximity dict = poll();
        if (dict == null) {
            synchronized (this) {
                if (this.mSize >= this.mMaxSize) {
                    dict = (DictAndProximity) super.take();
                } else {
                    this.mSize++;
                    try {
                        dict = this.mService.createDictAndProximity(this.mLocale);
                    } catch (Throwable e) {}
                }
            }
        }
        return dict;
    }

    public DictAndProximity takeOrGetNull() {
        try {
            return take();
        } catch (InterruptedException e) {
            return null;
        }
    }

    public void close() {
        synchronized (this) {
            this.mClosed = true;
            for (DictAndProximity dict : this) {
                dict.mDictionary.close();
            }
            clear();
        }
    }

    @Override // java.util.concurrent.LinkedBlockingQueue, java.util.Queue, java.util.concurrent.BlockingQueue
    public boolean offer(DictAndProximity dict) {
        if (!this.mClosed) {
            return super.offer(dict);
        }
        dict.mDictionary.close();
        return false;
    }
}
