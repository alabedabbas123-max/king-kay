package com.android.inputmethod.latin;

import android.view.View;
import android.widget.EditText;
import inputmethod.latin.perfectkeyboard.R;

/* JADX INFO: compiled from: AutoTextEditor.java */
/* JADX INFO: loaded from: classes.dex */
class DialogWrapper {
    View base;
    EditText keyField;
    EditText valueField;

    DialogWrapper(View base) {
        this.keyField = null;
        this.valueField = null;
        this.base = null;
        this.base = base;
        this.keyField = (EditText) base.findViewById(R.id.key);
        this.valueField = (EditText) base.findViewById(R.id.value);
    }

    String getKey() {
        return getKeyField().getText().toString();
    }

    String getValue() {
        return getValueField().getText().toString();
    }

    private EditText getKeyField() {
        if (this.keyField == null) {
            this.keyField = (EditText) this.base.findViewById(R.id.key);
        }
        return this.keyField;
    }

    private EditText getValueField() {
        if (this.valueField == null) {
            this.valueField = (EditText) this.base.findViewById(R.id.value);
        }
        return this.valueField;
    }
}
