package com.android.inputmethod.latin;

/* JADX INFO: loaded from: classes.dex */
public class WordListInfo {
    public final String mId;
    public final String mLocale;

    public WordListInfo(String id, String locale) {
        this.mId = id;
        this.mLocale = locale;
    }
}
