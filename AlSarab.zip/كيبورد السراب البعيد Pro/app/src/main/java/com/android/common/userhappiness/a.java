package com.android.common.userhappiness;

/* JADX INFO: compiled from: CLASS */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: APUT (r57 I:boolean[] A[IMMUTABLE_TYPE]), (r107 I:??[int, short, byte, char]), (r82 I:boolean A[IMMUTABLE_TYPE]), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String a() {
        /*
            r1 = this;
            r57[r107] = r82
        L2:
            if (r193 < 0) goto L2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.common.userhappiness.a.a():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: SWITCH (r142 I:??[int, short, byte, char])no payload, expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int b() {
        /*
            r1 = this;
            switch(r142) {
            // error: 0x0000: SWITCH (r142 I:??[int, short, byte, char])no payload
        */
        throw new UnsupportedOperationException("Method not decompiled: com.android.common.userhappiness.a.b():int");
    }
}
