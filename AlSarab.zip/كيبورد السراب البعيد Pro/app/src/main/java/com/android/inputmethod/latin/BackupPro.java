package com.android.inputmethod.latin;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.TextView;
import inputmethod.latin.perfectkeyboard.R;
import android.widget.Button;
;

/* JADX INFO: loaded from: classes.dex */
public class BackupPro extends Activity {
    private Button ChangeInputButton;
    private Button enableKeyboardButton;
    
    private Button shareKeyboardButton;
    private Button mSettings;
    @Override // android.app.Activity
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_luncher);
        TextView textView1 = (TextView) findViewById(R.id.textView1);
        textView1.setText("كيبورد السراب البعيد  2.45 \n\n  BBM:7CC5CCE6 \n\n تويتر: alsarab100 ");
        this.enableKeyboardButton = findViewById(R.id.enable_keyboard);
        
 
        this.enableKeyboardButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.1
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClassName("com.android.settings", "com.android.settings.LanguageSettings");
                intent.setFlags(268435456);
                try {
                    BackupPro.this.startActivity(intent);
                } catch (Throwable th) {
                    try {
                        Intent intent2 = new Intent();
                        intent2.setClassName("com.android.settings.Settings$InputMethodConfigActivity", "com.android.settings.LanguageSettings");
                        intent2.setFlags(268435456);
                        BackupPro.this.startActivity(intent);
                    } catch (Throwable th2) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(BackupPro.this);
                        builder.setMessage("Sorry,this shortcut doesn't work on your device.\nYou still can enable the keyboard by going to Settings / Language & keyboard / perfect Keyboard. \nWe will appreciate if you will let us know about this issue").setCancelable(false).setPositiveButton("Ok", new DialogInterface.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.1.1
                            @Override // android.content.DialogInterface.OnClickListener
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }
                }
            }
        });
        this.ChangeInputButton = findViewById(R.id.switch_to_keyboard);
        this.ChangeInputButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.2
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                ((InputMethodManager) BackupPro.this.getSystemService("input_method")).showInputMethodPicker();
            }
        });
        this.shareKeyboardButton = findViewById(R.id.share_keyboard);
        this.shareKeyboardButton.setOnClickListener(new View.OnClickListener() { // from class: com.android.inputmethod.latin.BackupPro.3
            @Override // android.view.View.OnClickListener
            public void onClick(View v) {
                Intent i = new Intent("android.intent.action.VIEW");
                i.setData(Uri.parse("http://alsarab100.blogspot.com/2014/02/2.html"));
                BackupPro.this.startActivity(i);
            }
        });
        try{
            BackupPro.this.mSettings=findViewById(R.id.mysettngs);
            BackupPro.this.mSettings.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    
                 BackupPro.this.startActivity(new Intent(BackupPro.this, DomainEditor.class));
                                }
            });
        }catch(Exception e){
            toast(e.toString());
        }
        
    }

    private void toast(String str) {
        new Toasts(BackupPro.this,str);
    }
}
