package com.android.inputmethod.voice;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.widget.ImageView;
import inputmethod.latin.perfectkeyboard.R;

/* JADX INFO: loaded from: classes.dex */
public class SoundIndicator extends ImageView {
    private static final float AUDIO_METER_DB_RANGE = 20.0f;
    private static final float AUDIO_METER_MIN_DB = 7.0f;
    private static final float DOWN_SMOOTHING_FACTOR = 0.4f;
    private static final long FRAME_DELAY = 50;
    private static final String TAG = "SoundIndicator";
    private static final float UP_SMOOTHING_FACTOR = 0.9f;
    private Canvas mBufferCanvas;
    private Paint mClearPaint;
    private Runnable mDrawFrame;
    private Bitmap mDrawingBuffer;
    private Bitmap mEdgeBitmap;
    private int mEdgeBitmapOffset;
    private Drawable mFrontDrawable;
    private Handler mHandler;
    private float mLevel;
    private Paint mMultPaint;

    public SoundIndicator(Context context) {
        this(context, null);
    }

    public SoundIndicator(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mLevel = 0.0f;
        this.mDrawFrame = new Runnable() { // from class: com.android.inputmethod.voice.SoundIndicator.1
            @Override // java.lang.Runnable
            public void run() {
                SoundIndicator.this.invalidate();
                SoundIndicator.this.mHandler.postDelayed(SoundIndicator.this.mDrawFrame, SoundIndicator.FRAME_DELAY);
            }
        };
        this.mFrontDrawable = getDrawable();
        BitmapDrawable edgeDrawable = (BitmapDrawable) context.getResources().getDrawable(R.drawable.vs_popup_mic_edge);
        this.mEdgeBitmap = edgeDrawable.getBitmap();
        this.mEdgeBitmapOffset = this.mEdgeBitmap.getHeight() / 2;
        this.mDrawingBuffer = Bitmap.createBitmap(this.mFrontDrawable.getIntrinsicWidth(), this.mFrontDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        this.mBufferCanvas = new Canvas(this.mDrawingBuffer);
        this.mClearPaint = new Paint();
        this.mClearPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        this.mMultPaint = new Paint();
        this.mMultPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY));
        this.mHandler = new Handler();
    }

    @Override // android.widget.ImageView, android.view.View
    public void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        this.mBufferCanvas.drawRect(0.0f, 0.0f, w, h, this.mClearPaint);
        Rect clip = new Rect(0, ((int) ((1.0d - ((double) this.mLevel)) * ((double) (this.mEdgeBitmapOffset + h)))) - this.mEdgeBitmapOffset, (int) w, (int) h);
        this.mBufferCanvas.save();
        this.mBufferCanvas.clipRect(clip);
        this.mFrontDrawable.setBounds(new Rect(0, 0, (int) w, (int) h));
        this.mFrontDrawable.draw(this.mBufferCanvas);
        this.mBufferCanvas.restore();
        this.mBufferCanvas.drawBitmap(this.mEdgeBitmap, 0.0f, clip.top, this.mMultPaint);
        canvas.drawBitmap(this.mDrawingBuffer, 0.0f, 0.0f, (Paint) null);
    }

    public void setRmsdB(float rmsdB) {
        float level = Math.min(Math.max(0.0f, (rmsdB - AUDIO_METER_MIN_DB) / AUDIO_METER_DB_RANGE), 1.0f);
        if (level > this.mLevel) {
            this.mLevel = ((level - this.mLevel) * UP_SMOOTHING_FACTOR) + this.mLevel;
        } else {
            this.mLevel = ((level - this.mLevel) * DOWN_SMOOTHING_FACTOR) + this.mLevel;
        }
        invalidate();
    }

    public void start() {
        this.mHandler.post(this.mDrawFrame);
    }

    public void stop() {
        this.mHandler.removeCallbacks(this.mDrawFrame);
    }
}
