package com.google.android;

/* JADX INFO: compiled from: GC_TRY_LOOP_MAX */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: ARITH (r100 I:long) = (r116 I:long) >> (r5 I:long), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String a() {
        /*
            r1 = this;
            long r100 = r116 >> r5
            long r6 = r6 >>> r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.a.a():java.lang.String");
    }

    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: ARITH (r85 I:float) = (r203 I:float) + (r15 I:float), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public int b() {
        /*
            r1 = this;
            float r85 = r203 + r15
            r5 = r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.a.b():int");
    }
}
