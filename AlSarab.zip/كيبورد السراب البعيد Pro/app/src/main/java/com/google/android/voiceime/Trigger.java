package com.google.android.voiceime;

/* JADX INFO: loaded from: classes.dex */
interface Trigger {
    void onStartInputView();

    void startVoiceRecognition(String str);
}
