package DictionaryPackage;

/* JADX INFO: compiled from:   */
/* JADX INFO: loaded from: classes.dex */
public class a {
    /*  JADX ERROR: JadxRuntimeException in pass: CheckCode
        jadx.core.utils.exceptions.JadxRuntimeException: Incorrect register number in instruction: 0x0000: MOVE (r58555 I:??[long, double]) = (r64687 I:??[long, double]), expected to be less than 2
        	at jadx.core.dex.visitors.CheckCode.checkInstructions(CheckCode.java:79)
        	at jadx.core.dex.visitors.CheckCode.visit(CheckCode.java:33)
        */
    public java.lang.String a() {
        /*
            r1 = this;
            r58555 = r64687
        */
        throw new UnsupportedOperationException("Method not decompiled: DictionaryPackage.a.a():java.lang.String");
    }

    /*  JADX ERROR: Failed to decode insn: 0x0000: UNKNOWN(0x64F6)
        jadx.core.utils.exceptions.DecodeException: Unknown instruction: '0x0000: UNKNOWN(0x64F6)'
        	at jadx.core.dex.instructions.InsnDecoder.decode(InsnDecoder.java:513)
        	at jadx.core.dex.instructions.InsnDecoder.lambda$process$0(InsnDecoder.java:51)
        	at jadx.plugins.input.dex.sections.DexCodeReader.visitInstructions(DexCodeReader.java:86)
        	at jadx.core.dex.instructions.InsnDecoder.process(InsnDecoder.java:46)
        	at jadx.core.dex.nodes.MethodNode.load(MethodNode.java:164)
        	at jadx.core.dex.nodes.ClassNode.load(ClassNode.java:462)
        	at jadx.core.ProcessClass.process(ProcessClass.java:77)
        	at jadx.core.ProcessClass.generateCode(ProcessClass.java:126)
        	at jadx.core.dex.nodes.ClassNode.generateClassCode(ClassNode.java:405)
        	at jadx.core.dex.nodes.ClassNode.decompile(ClassNode.java:393)
        	at jadx.core.dex.nodes.ClassNode.getCode(ClassNode.java:343)
        */
    public int b() {
        /*
            r1 = this;
            // decode failed: Unknown instruction: '0x0000: UNKNOWN(0x64F6)'
            r0 = r11 | (-8907(0xffffffffffffdd35, float:NaN))
        */
        throw new UnsupportedOperationException("Method not decompiled: DictionaryPackage.a.b():int");
    }
}
