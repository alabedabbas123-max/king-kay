package android.arch.lifecycle;

@Deprecated
public interface InterfaceC0099f extends InterfaceC0096c {
    @Override
    C0098e mo546j6();
}
