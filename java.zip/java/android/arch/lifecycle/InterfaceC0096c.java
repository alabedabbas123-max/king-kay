package android.arch.lifecycle;

public interface InterfaceC0096c {
    AbstractC0094a mo546j6();
}
