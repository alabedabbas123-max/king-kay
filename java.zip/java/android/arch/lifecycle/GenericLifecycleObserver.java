package android.arch.lifecycle;

public interface GenericLifecycleObserver extends InterfaceC0095b {
    void mo533j6(InterfaceC0096c interfaceC0096c, AbstractC0094a.a aVar);
}
