package android.arch.lifecycle;

public interface InterfaceC0095b {
}
