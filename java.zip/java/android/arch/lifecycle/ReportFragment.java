package android.arch.lifecycle;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.ComponentCallbacks2;
import android.os.Bundle;

public class ReportFragment extends Fragment {

    private InterfaceC0093a f431j6;

    interface InterfaceC0093a {
        void m545IS();

        void onCreate();

        void onResume();
    }

    private void m540DW(InterfaceC0093a interfaceC0093a) {
        if (interfaceC0093a != null) {
            interfaceC0093a.onResume();
        }
    }

    private void m541FH(InterfaceC0093a interfaceC0093a) {
        if (interfaceC0093a != null) {
            interfaceC0093a.m545IS();
        }
    }

    public static void m542j6(Activity activity) {
        FragmentManager fragmentManager = activity.getFragmentManager();
        if (fragmentManager.findFragmentByTag("android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add(new ReportFragment(), "android.arch.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    private void m543j6(InterfaceC0093a interfaceC0093a) {
        if (interfaceC0093a != null) {
            interfaceC0093a.onCreate();
        }
    }

    private void m544j6(AbstractC0094a.a aVar) {
        ComponentCallbacks2 activity = getActivity();
        if (activity instanceof InterfaceC0099f) {
            ((InterfaceC0099f) activity).mo546j6().m557DW(aVar);
        } else if (activity instanceof InterfaceC0096c) {
            AbstractC0094a abstractC0094aMo546j6 = ((InterfaceC0096c) activity).mo546j6();
            if (abstractC0094aMo546j6 instanceof C0098e) {
                ((C0098e) abstractC0094aMo546j6).m557DW(aVar);
            }
        }
    }

    @Override
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        m543j6(this.f431j6);
        m544j6(AbstractC0094a.a.ON_CREATE);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        m544j6(AbstractC0094a.a.ON_DESTROY);
        this.f431j6 = null;
    }

    @Override
    public void onPause() {
        super.onPause();
        m544j6(AbstractC0094a.a.ON_PAUSE);
    }

    @Override
    public void onResume() {
        super.onResume();
        m540DW(this.f431j6);
        m544j6(AbstractC0094a.a.ON_RESUME);
    }

    @Override
    public void onStart() {
        super.onStart();
        m541FH(this.f431j6);
        m544j6(AbstractC0094a.a.ON_START);
    }

    @Override
    public void onStop() {
        super.onStop();
        m544j6(AbstractC0094a.a.ON_STOP);
    }
}
