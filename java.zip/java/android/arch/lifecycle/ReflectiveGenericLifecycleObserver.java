package android.arch.lifecycle;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ReflectiveGenericLifecycleObserver implements GenericLifecycleObserver {

    static final Map<Class, C0091a> f424j6 = new HashMap();

    private final Object f425DW;

    private final C0091a f426FH;

    static class C0091a {

        final Map<C0092b, AbstractC0094a.a> f427DW;

        final Map<AbstractC0094a.a, List<C0092b>> f428j6 = new HashMap();

        C0091a(Map<C0092b, AbstractC0094a.a> map) {
            this.f427DW = map;
            for (Map.Entry<C0092b, AbstractC0094a.a> entry : map.entrySet()) {
                AbstractC0094a.a value = entry.getValue();
                List<C0092b> arrayList = this.f428j6.get(value);
                if (arrayList == null) {
                    arrayList = new ArrayList<>();
                    this.f428j6.put(value, arrayList);
                }
                arrayList.add(entry.getKey());
            }
        }
    }

    static class C0092b {

        final Method f429DW;

        final int f430j6;

        C0092b(int i, Method method) {
            this.f430j6 = i;
            this.f429DW = method;
            this.f429DW.setAccessible(true);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || C0092b.class != obj.getClass()) {
                return false;
            }
            C0092b c0092b = (C0092b) obj;
            return this.f430j6 == c0092b.f430j6 && this.f429DW.getName().equals(c0092b.f429DW.getName());
        }

        public int hashCode() {
            return (this.f430j6 * 31) + this.f429DW.getName().hashCode();
        }
    }

    ReflectiveGenericLifecycleObserver(Object obj) {
        this.f425DW = obj;
        this.f426FH = m534DW(this.f425DW.getClass());
    }

    private static C0091a m534DW(Class cls) {
        C0091a c0091a = f424j6.get(cls);
        return c0091a != null ? c0091a : m535j6(cls);
    }

    private static C0091a m535j6(Class cls) {
        int i;
        C0091a c0091aM534DW;
        Class superclass = cls.getSuperclass();
        HashMap map = new HashMap();
        if (superclass != null && (c0091aM534DW = m534DW(superclass)) != null) {
            map.putAll(c0091aM534DW.f427DW);
        }
        Method[] declaredMethods = cls.getDeclaredMethods();
        for (Class<?> cls2 : cls.getInterfaces()) {
            for (Map.Entry<C0092b, AbstractC0094a.a> entry : m534DW(cls2).f427DW.entrySet()) {
                m539j6(map, entry.getKey(), entry.getValue(), cls);
            }
        }
        for (Method method : declaredMethods) {
            InterfaceC0100g interfaceC0100g = (InterfaceC0100g) method.getAnnotation(InterfaceC0100g.class);
            if (interfaceC0100g != null) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length <= 0) {
                    i = 0;
                } else {
                    if (!parameterTypes[0].isAssignableFrom(InterfaceC0096c.class)) {
                        throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
                    }
                    i = 1;
                }
                AbstractC0094a.a aVarValue = interfaceC0100g.value();
                if (parameterTypes.length > 1) {
                    if (!parameterTypes[1].isAssignableFrom(AbstractC0094a.a.class)) {
                        throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
                    }
                    if (aVarValue != AbstractC0094a.a.ON_ANY) {
                        throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
                    }
                    i = 2;
                }
                if (parameterTypes.length > 2) {
                    throw new IllegalArgumentException("cannot have more than 2 params");
                }
                m539j6(map, new C0092b(i, method), aVarValue, cls);
            }
        }
        C0091a c0091a = new C0091a(map);
        f424j6.put(cls, c0091a);
        return c0091a;
    }

    private void m536j6(C0091a c0091a, InterfaceC0096c interfaceC0096c, AbstractC0094a.a aVar) {
        m538j6(c0091a.f428j6.get(aVar), interfaceC0096c, aVar);
        m538j6(c0091a.f428j6.get(AbstractC0094a.a.ON_ANY), interfaceC0096c, aVar);
    }

    private void m537j6(C0092b c0092b, InterfaceC0096c interfaceC0096c, AbstractC0094a.a aVar) {
        try {
            int i = c0092b.f430j6;
            if (i == 0) {
                c0092b.f429DW.invoke(this.f425DW, new Object[0]);
            } else if (i == 1) {
                c0092b.f429DW.invoke(this.f425DW, interfaceC0096c);
            } else {
                if (i != 2) {
                    return;
                }
                c0092b.f429DW.invoke(this.f425DW, interfaceC0096c, aVar);
            }
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e2) {
            throw new RuntimeException("Failed to call observer method", e2.getCause());
        }
    }

    private void m538j6(List<C0092b> list, InterfaceC0096c interfaceC0096c, AbstractC0094a.a aVar) {
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                m537j6(list.get(size), interfaceC0096c, aVar);
            }
        }
    }

    private static void m539j6(Map<C0092b, AbstractC0094a.a> map, C0092b c0092b, AbstractC0094a.a aVar, Class cls) {
        AbstractC0094a.a aVar2 = map.get(c0092b);
        if (aVar2 == null || aVar == aVar2) {
            if (aVar2 == null) {
                map.put(c0092b, aVar);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("Method " + c0092b.f429DW.getName() + " in " + cls.getName() + " already declared with different @OnLifecycleEvent value: previous value " + aVar2 + ", new value " + aVar);
    }

    @Override
    public void mo533j6(InterfaceC0096c interfaceC0096c, AbstractC0094a.a aVar) {
        m536j6(this.f426FH, interfaceC0096c, aVar);
    }
}
