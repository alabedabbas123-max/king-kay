package android.arch.lifecycle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

public class C0098e extends AbstractC0094a {

    private final InterfaceC0096c f441FH;

    private a<InterfaceC0095b, a> f445j6 = new abcd.a();

    private int f442Hw = 0;

    private boolean f446v5 = false;

    private boolean f444Zo = false;

    private ArrayList<AbstractC0094a.b> f443VH = new ArrayList<>();

    private AbstractC0094a.b f440DW = AbstractC0094a.b.INITIALIZED;

    static class a {

        GenericLifecycleObserver f447DW;

        AbstractC0094a.b f448j6;

        void m559j6(InterfaceC0096c interfaceC0096c, AbstractC0094a.a aVar) {
            AbstractC0094a.b bVarM553j6 = C0098e.m553j6(aVar);
            this.f448j6 = C0098e.m554j6(this.f448j6, bVarM553j6);
            this.f447DW.mo533j6(interfaceC0096c, aVar);
            this.f448j6 = bVarM553j6;
        }
    }

    public C0098e(InterfaceC0096c interfaceC0096c) {
        this.f441FH = interfaceC0096c;
    }

    private static AbstractC0094a.a m547DW(AbstractC0094a.b bVar) {
        int i = C0097d.f438DW[bVar.ordinal()];
        if (i == 1) {
            throw new IllegalArgumentException();
        }
        if (i == 2) {
            return AbstractC0094a.a.ON_DESTROY;
        }
        if (i == 3) {
            return AbstractC0094a.a.ON_STOP;
        }
        if (i == 4) {
            return AbstractC0094a.a.ON_PAUSE;
        }
        if (i == 5) {
            throw new IllegalArgumentException();
        }
        throw new IllegalArgumentException("Unexpected state value " + bVar);
    }

    private void m548DW() {
        abcd.c.d dVarDW = this.f445j6.DW();
        while (dVarDW.hasNext() && !this.f444Zo) {
            Map.Entry entry = (Map.Entry) dVarDW.next();
            a aVar = (a) entry.getValue();
            while (aVar.f448j6.compareTo(this.f440DW) < 0 && !this.f444Zo && this.f445j6.contains(entry.getKey())) {
                m549FH(aVar.f448j6);
                aVar.m559j6(this.f441FH, m551Hw(aVar.f448j6));
                m552Hw();
            }
        }
    }

    private void m549FH(AbstractC0094a.b bVar) {
        this.f443VH.add(bVar);
    }

    private boolean m550FH() {
        if (this.f445j6.size() == 0) {
            return true;
        }
        AbstractC0094a.b bVar = ((a) this.f445j6.j6().getValue()).f448j6;
        AbstractC0094a.b bVar2 = ((a) this.f445j6.FH().getValue()).f448j6;
        return bVar == bVar2 && this.f440DW == bVar2;
    }

    private static AbstractC0094a.a m551Hw(AbstractC0094a.b bVar) {
        int i = C0097d.f438DW[bVar.ordinal()];
        if (i != 1) {
            if (i == 2) {
                return AbstractC0094a.a.ON_START;
            }
            if (i == 3) {
                return AbstractC0094a.a.ON_RESUME;
            }
            if (i == 4) {
                throw new IllegalArgumentException();
            }
            if (i != 5) {
                throw new IllegalArgumentException("Unexpected state value " + bVar);
            }
        }
        return AbstractC0094a.a.ON_CREATE;
    }

    private void m552Hw() {
        ArrayList<AbstractC0094a.b> arrayList = this.f443VH;
        arrayList.remove(arrayList.size() - 1);
    }

    static AbstractC0094a.b m553j6(AbstractC0094a.a aVar) {
        switch (C0097d.f439j6[aVar.ordinal()]) {
            case 1:
            case 2:
                return AbstractC0094a.b.CREATED;
            case 3:
            case 4:
                return AbstractC0094a.b.STARTED;
            case 5:
                return AbstractC0094a.b.RESUMED;
            case 6:
                return AbstractC0094a.b.DESTROYED;
            default:
                throw new IllegalArgumentException("Unexpected event value " + aVar);
        }
    }

    static AbstractC0094a.b m554j6(AbstractC0094a.b bVar, AbstractC0094a.b bVar2) {
        return (bVar2 == null || bVar2.compareTo(bVar) >= 0) ? bVar : bVar2;
    }

    private void m555j6() {
        Iterator itDescendingIterator = this.f445j6.descendingIterator();
        while (itDescendingIterator.hasNext() && !this.f444Zo) {
            Map.Entry entry = (Map.Entry) itDescendingIterator.next();
            a aVar = (a) entry.getValue();
            while (aVar.f448j6.compareTo(this.f440DW) > 0 && !this.f444Zo && this.f445j6.contains(entry.getKey())) {
                AbstractC0094a.a aVarM547DW = m547DW(aVar.f448j6);
                m549FH(m553j6(aVarM547DW));
                aVar.m559j6(this.f441FH, aVarM547DW);
                m552Hw();
            }
        }
    }

    private void m556v5() {
        while (!m550FH()) {
            this.f444Zo = false;
            if (this.f440DW.compareTo(((a) this.f445j6.j6().getValue()).f448j6) < 0) {
                m555j6();
            }
            Map.Entry entryFH = this.f445j6.FH();
            if (!this.f444Zo && entryFH != null && this.f440DW.compareTo(((a) entryFH.getValue()).f448j6) > 0) {
                m548DW();
            }
        }
        this.f444Zo = false;
    }

    public void m557DW(AbstractC0094a.a aVar) {
        this.f440DW = m553j6(aVar);
        if (this.f446v5 || this.f442Hw != 0) {
            this.f444Zo = true;
            return;
        }
        this.f446v5 = true;
        m556v5();
        this.f446v5 = false;
    }

    public void m558j6(AbstractC0094a.b bVar) {
        this.f440DW = bVar;
    }
}
