package androidj.support.p003v4.accessibilityservice;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import androidj.support.annotation.RequiresApi;

@TargetApi(AccessibilityServiceInfoCompat.FLAG_REPORT_VIEW_IDS)
@RequiresApi(AccessibilityServiceInfoCompat.FLAG_REPORT_VIEW_IDS)
class AccessibilityServiceInfoCompatJellyBean {
    AccessibilityServiceInfoCompatJellyBean() {
    }

    public static String loadDescription(AccessibilityServiceInfo accessibilityServiceInfo, PackageManager packageManager) {
        return accessibilityServiceInfo.loadDescription(packageManager);
    }
}
