package androidj.support.p003v4.animation;

import android.view.View;

interface AnimatorProvider {
    void clearInterpolator(View view);

    ValueAnimatorCompat emptyValueAnimator();
}
