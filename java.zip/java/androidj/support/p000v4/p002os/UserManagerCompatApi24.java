package androidj.support.p000v4.p002os;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.UserManager;
import androidj.support.annotation.RequiresApi;
import androidj.support.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
@TargetApi(24)
@RequiresApi(24)
public class UserManagerCompatApi24 {
    public static boolean isUserUnlocked(Context context) {
        return ((UserManager) context.getSystemService(UserManager.class)).isUserUnlocked();
    }
}
