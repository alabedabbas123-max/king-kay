package androidj.support.p000v4.p002os;

import android.annotation.TargetApi;
import android.os.CancellationSignal;
import androidj.support.annotation.RequiresApi;

@TargetApi(16)
@RequiresApi(16)
class CancellationSignalCompatJellybean {
    CancellationSignalCompatJellybean() {
    }

    public static void cancel(Object obj) {
        ((CancellationSignal) obj).cancel();
    }

    public static Object create() {
        return new CancellationSignal();
    }
}
