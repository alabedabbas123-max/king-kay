package androidj.support.p000v4.internal.view;

import android.view.SubMenu;
import androidj.support.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public interface SupportSubMenu extends SupportMenu, SubMenu {
}
