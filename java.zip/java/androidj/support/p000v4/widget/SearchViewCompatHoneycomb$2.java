package androidj.support.p000v4.widget;

import android.widget.SearchView;

final class SearchViewCompatHoneycomb$2 implements SearchView.OnCloseListener {
    final InterfaceC0016x8671a441 val$listener;

    SearchViewCompatHoneycomb$2(InterfaceC0016x8671a441 interfaceC0016x8671a441) {
        this.val$listener = interfaceC0016x8671a441;
    }

    @Override
    public boolean onClose() {
        return this.val$listener.onClose();
    }
}
