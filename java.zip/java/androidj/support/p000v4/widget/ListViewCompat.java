package androidj.support.p000v4.widget;

import android.os.Build;
import android.widget.ListView;
import androidj.support.annotation.NonNull;

public final class ListViewCompat {
    private ListViewCompat() {
    }

    public static void scrollListBy(@NonNull ListView listView, int i) {
        if (Build.VERSION.SDK_INT >= 19) {
            ListViewCompatKitKat.scrollListBy(listView, i);
        } else {
            ListViewCompatGingerbread.scrollListBy(listView, i);
        }
    }
}
