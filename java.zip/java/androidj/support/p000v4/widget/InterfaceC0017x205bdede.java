package androidj.support.p000v4.widget;

interface InterfaceC0017x205bdede {
    boolean onQueryTextChange(String str);

    boolean onQueryTextSubmit(String str);
}
