package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.widget.EdgeEffect;
import androidj.support.annotation.RequiresApi;

@TargetApi(21)
@RequiresApi(21)
class EdgeEffectCompatLollipop {
    EdgeEffectCompatLollipop() {
    }

    public static boolean onPull(Object obj, float f, float f2) {
        ((EdgeEffect) obj).onPull(f, f2);
        return true;
    }
}
