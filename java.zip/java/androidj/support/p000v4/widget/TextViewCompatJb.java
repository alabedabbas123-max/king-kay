package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.widget.TextView;
import androidj.support.annotation.RequiresApi;

@TargetApi(16)
@RequiresApi(16)
class TextViewCompatJb {
    TextViewCompatJb() {
    }

    static int getMaxLines(TextView textView) {
        return textView.getMaxLines();
    }

    static int getMinLines(TextView textView) {
        return textView.getMinLines();
    }
}
