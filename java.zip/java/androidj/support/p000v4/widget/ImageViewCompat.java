package androidj.support.p000v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Build;
import android.widget.ImageView;

public class ImageViewCompat {
    static final ImageViewCompatImpl IMPL;

    static class BaseViewCompatImpl implements ImageViewCompatImpl {
        BaseViewCompatImpl() {
        }

        @Override
        public ColorStateList getImageTintList(ImageView imageView) {
            return ImageViewCompatBase.getImageTintList(imageView);
        }

        @Override
        public PorterDuff.Mode getImageTintMode(ImageView imageView) {
            return ImageViewCompatBase.getImageTintMode(imageView);
        }

        @Override
        public void setImageTintList(ImageView imageView, ColorStateList colorStateList) {
            ImageViewCompatBase.setImageTintList(imageView, colorStateList);
        }

        @Override
        public void setImageTintMode(ImageView imageView, PorterDuff.Mode mode) {
            ImageViewCompatBase.setImageTintMode(imageView, mode);
        }
    }

    interface ImageViewCompatImpl {
        ColorStateList getImageTintList(ImageView imageView);

        PorterDuff.Mode getImageTintMode(ImageView imageView);

        void setImageTintList(ImageView imageView, ColorStateList colorStateList);

        void setImageTintMode(ImageView imageView, PorterDuff.Mode mode);
    }

    static class LollipopViewCompatImpl extends BaseViewCompatImpl {
        LollipopViewCompatImpl() {
        }

        @Override
        public ColorStateList getImageTintList(ImageView imageView) {
            return ImageViewCompatLollipop.getImageTintList(imageView);
        }

        @Override
        public PorterDuff.Mode getImageTintMode(ImageView imageView) {
            return ImageViewCompatLollipop.getImageTintMode(imageView);
        }

        @Override
        public void setImageTintList(ImageView imageView, ColorStateList colorStateList) {
            ImageViewCompatLollipop.setImageTintList(imageView, colorStateList);
        }

        @Override
        public void setImageTintMode(ImageView imageView, PorterDuff.Mode mode) {
            ImageViewCompatLollipop.setImageTintMode(imageView, mode);
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 21) {
            IMPL = new LollipopViewCompatImpl();
        } else {
            IMPL = new BaseViewCompatImpl();
        }
    }

    private ImageViewCompat() {
    }

    public static ColorStateList getImageTintList(ImageView imageView) {
        return IMPL.getImageTintList(imageView);
    }

    public static PorterDuff.Mode getImageTintMode(ImageView imageView) {
        return IMPL.getImageTintMode(imageView);
    }

    public static void setImageTintList(ImageView imageView, ColorStateList colorStateList) {
        IMPL.setImageTintList(imageView, colorStateList);
    }

    public static void setImageTintMode(ImageView imageView, PorterDuff.Mode mode) {
        IMPL.setImageTintMode(imageView, mode);
    }
}
