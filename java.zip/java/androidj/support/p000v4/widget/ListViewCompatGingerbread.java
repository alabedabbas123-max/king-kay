package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.view.View;
import android.widget.ListView;
import androidj.support.annotation.RequiresApi;

@TargetApi(9)
@RequiresApi(9)
class ListViewCompatGingerbread {
    ListViewCompatGingerbread() {
    }

    static void scrollListBy(ListView listView, int i) {
        View childAt;
        int firstVisiblePosition = listView.getFirstVisiblePosition();
        if (firstVisiblePosition == -1 || (childAt = listView.getChildAt(0)) == null) {
            return;
        }
        listView.setSelectionFromTop(firstVisiblePosition, childAt.getTop() - i);
    }
}
