package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.widget.OverScroller;
import androidj.support.annotation.RequiresApi;

@TargetApi(14)
@RequiresApi(14)
class ScrollerCompatIcs {
    ScrollerCompatIcs() {
    }

    public static float getCurrVelocity(Object obj) {
        return ((OverScroller) obj).getCurrVelocity();
    }
}
