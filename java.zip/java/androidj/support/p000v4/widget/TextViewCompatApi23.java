package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.widget.TextView;
import androidj.support.annotation.NonNull;
import androidj.support.annotation.RequiresApi;
import androidj.support.annotation.StyleRes;

@TargetApi(23)
@RequiresApi(23)
class TextViewCompatApi23 {
    TextViewCompatApi23() {
    }

    public static void setTextAppearance(@NonNull TextView textView, @StyleRes int i) {
        textView.setTextAppearance(i);
    }
}
