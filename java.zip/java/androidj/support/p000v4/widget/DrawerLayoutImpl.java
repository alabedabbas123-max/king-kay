package androidj.support.p000v4.widget;

interface DrawerLayoutImpl {
    void setChildInsets(Object obj, boolean z);
}
