package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.view.View;
import android.widget.PopupMenu;
import androidj.support.annotation.RequiresApi;

@TargetApi(19)
@RequiresApi(19)
class PopupMenuCompatKitKat {
    PopupMenuCompatKitKat() {
    }

    public static View.OnTouchListener getDragToOpenListener(Object obj) {
        return ((PopupMenu) obj).getDragToOpenListener();
    }
}
