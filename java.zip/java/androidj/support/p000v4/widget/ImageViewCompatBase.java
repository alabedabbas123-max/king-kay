package androidj.support.p000v4.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.widget.ImageView;
import androidj.support.v4.widget.TintableImageSourceView;

class ImageViewCompatBase {
    ImageViewCompatBase() {
    }

    static ColorStateList getImageTintList(ImageView imageView) {
        if (imageView instanceof TintableImageSourceView) {
            return ((TintableImageSourceView) imageView).getSupportImageTintList();
        }
        return null;
    }

    static PorterDuff.Mode getImageTintMode(ImageView imageView) {
        if (imageView instanceof TintableImageSourceView) {
            return ((TintableImageSourceView) imageView).getSupportImageTintMode();
        }
        return null;
    }

    static void setImageTintList(ImageView imageView, ColorStateList colorStateList) {
        if (imageView instanceof TintableImageSourceView) {
            ((TintableImageSourceView) imageView).setSupportImageTintList(colorStateList);
        }
    }

    static void setImageTintMode(ImageView imageView, PorterDuff.Mode mode) {
        if (imageView instanceof TintableImageSourceView) {
            ((TintableImageSourceView) imageView).setSupportImageTintMode(mode);
        }
    }
}
