package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.view.View;
import android.widget.PopupWindow;
import androidj.support.annotation.RequiresApi;

@TargetApi(19)
@RequiresApi(19)
class PopupWindowCompatKitKat {
    PopupWindowCompatKitKat() {
    }

    public static void showAsDropDown(PopupWindow popupWindow, View view, int i, int i2, int i3) {
        popupWindow.showAsDropDown(view, i, i2, i3);
    }
}
