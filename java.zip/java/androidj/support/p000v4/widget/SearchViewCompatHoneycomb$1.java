package androidj.support.p000v4.widget;

import android.widget.SearchView;

final class SearchViewCompatHoneycomb$1 implements SearchView.OnQueryTextListener {
    final InterfaceC0017x205bdede val$listener;

    SearchViewCompatHoneycomb$1(InterfaceC0017x205bdede interfaceC0017x205bdede) {
        this.val$listener = interfaceC0017x205bdede;
    }

    @Override
    public boolean onQueryTextChange(String str) {
        return this.val$listener.onQueryTextChange(str);
    }

    @Override
    public boolean onQueryTextSubmit(String str) {
        return this.val$listener.onQueryTextSubmit(str);
    }
}
