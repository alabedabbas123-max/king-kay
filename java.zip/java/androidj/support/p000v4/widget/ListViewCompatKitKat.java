package androidj.support.p000v4.widget;

import android.annotation.TargetApi;
import android.widget.ListView;
import androidj.support.annotation.RequiresApi;

@TargetApi(19)
@RequiresApi(19)
class ListViewCompatKitKat {
    ListViewCompatKitKat() {
    }

    static void scrollListBy(ListView listView, int i) {
        listView.scrollListBy(i);
    }
}
