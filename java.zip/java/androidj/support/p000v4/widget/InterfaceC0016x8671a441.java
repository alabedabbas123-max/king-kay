package androidj.support.p000v4.widget;

interface InterfaceC0016x8671a441 {
    boolean onClose();
}
