package androidj.support.p000v4.media;

import android.annotation.TargetApi;
import android.view.KeyEvent;
import androidj.support.annotation.RequiresApi;

@TargetApi(18)
@RequiresApi(18)
interface TransportMediatorCallback {
    long getPlaybackPosition();

    void handleAudioFocusChange(int i);

    void handleKey(KeyEvent keyEvent);

    void playbackPositionUpdate(long j);
}
