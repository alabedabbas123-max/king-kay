package androidj.support.p000v4.media;

@Deprecated
public class TransportStateListener {
    @Deprecated
    public TransportStateListener() {
    }

    @Deprecated
    public void onPlayingChanged(TransportController transportController) {
    }

    @Deprecated
    public void onTransportControlsChanged(TransportController transportController) {
    }
}
