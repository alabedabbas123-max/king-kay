package androidj.support.p000v4.content;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Intent;
import androidj.support.annotation.RequiresApi;

@TargetApi(11)
@RequiresApi(11)
class IntentCompatHoneycomb {
    IntentCompatHoneycomb() {
    }

    public static Intent makeMainActivity(ComponentName componentName) {
        return Intent.makeMainActivity(componentName);
    }

    public static Intent makeRestartActivityTask(ComponentName componentName) {
        return Intent.makeRestartActivityTask(componentName);
    }
}
