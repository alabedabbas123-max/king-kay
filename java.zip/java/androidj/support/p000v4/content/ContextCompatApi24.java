package androidj.support.p000v4.content;

import android.annotation.TargetApi;
import android.content.Context;
import androidj.support.annotation.RequiresApi;
import java.io.File;

@TargetApi(24)
@RequiresApi(24)
class ContextCompatApi24 {
    ContextCompatApi24() {
    }

    public static Context createDeviceProtectedStorageContext(Context context) {
        return context.createDeviceProtectedStorageContext();
    }

    public static File getDataDir(Context context) {
        return context.getDataDir();
    }

    public static boolean isDeviceProtectedStorage(Context context) {
        return context.isDeviceProtectedStorage();
    }
}
