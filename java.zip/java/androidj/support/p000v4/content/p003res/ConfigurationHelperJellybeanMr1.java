package androidj.support.p000v4.content.p003res;

import android.annotation.TargetApi;
import android.content.res.Resources;
import androidj.support.annotation.NonNull;
import androidj.support.annotation.RequiresApi;

@TargetApi(17)
@RequiresApi(17)
class ConfigurationHelperJellybeanMr1 {
    ConfigurationHelperJellybeanMr1() {
    }

    static int getDensityDpi(@NonNull Resources resources) {
        return resources.getConfiguration().densityDpi;
    }
}
