package androidj.support.p000v4.content.p003res;

import android.annotation.TargetApi;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import androidj.support.annotation.NonNull;
import androidj.support.annotation.RequiresApi;

@TargetApi(9)
@RequiresApi(9)
class ConfigurationHelperGingerbread {
    ConfigurationHelperGingerbread() {
    }

    static int getDensityDpi(@NonNull Resources resources) {
        return resources.getDisplayMetrics().densityDpi;
    }

    static int getScreenHeightDp(@NonNull Resources resources) {
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        return (int) (displayMetrics.heightPixels / displayMetrics.density);
    }

    static int getScreenWidthDp(@NonNull Resources resources) {
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        return (int) (displayMetrics.widthPixels / displayMetrics.density);
    }

    static int getSmallestScreenWidthDp(@NonNull Resources resources) {
        return Math.min(getScreenWidthDp(resources), getScreenHeightDp(resources));
    }
}
