package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.ViewGroup;
import androidj.support.annotation.RequiresApi;

@TargetApi(18)
@RequiresApi(18)
class ViewGroupCompatJellybeanMR2 {
    ViewGroupCompatJellybeanMR2() {
    }

    public static int getLayoutMode(ViewGroup viewGroup) {
        return viewGroup.getLayoutMode();
    }

    public static void setLayoutMode(ViewGroup viewGroup, int i) {
        viewGroup.setLayoutMode(i);
    }
}
