package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.ViewConfiguration;
import androidj.support.annotation.RequiresApi;

@TargetApi(14)
@RequiresApi(14)
class ViewConfigurationCompatICS {
    ViewConfigurationCompatICS() {
    }

    static boolean hasPermanentMenuKey(ViewConfiguration viewConfiguration) {
        return viewConfiguration.hasPermanentMenuKey();
    }
}
