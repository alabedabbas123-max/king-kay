package androidj.support.p000v4.view;

import android.view.View;
import androidj.support.v4.view.WindowInsetsCompat;

public interface OnApplyWindowInsetsListener {
    WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat);
}
