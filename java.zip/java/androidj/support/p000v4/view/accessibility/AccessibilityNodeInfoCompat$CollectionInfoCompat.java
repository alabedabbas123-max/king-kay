package androidj.support.p000v4.view.accessibility;

import androidj.support.v4.view.accessibility.AccessibilityNodeInfoCompat;

public class AccessibilityNodeInfoCompat$CollectionInfoCompat {
    public static final int SELECTION_MODE_MULTIPLE = 2;
    public static final int SELECTION_MODE_NONE = 0;
    public static final int SELECTION_MODE_SINGLE = 1;
    final Object mInfo;

    AccessibilityNodeInfoCompat$CollectionInfoCompat(Object obj) {
        this.mInfo = obj;
    }

    public static AccessibilityNodeInfoCompat$CollectionInfoCompat obtain(int i, int i2, boolean z) {
        return new AccessibilityNodeInfoCompat$CollectionInfoCompat(AccessibilityNodeInfoCompat.IMPL.obtainCollectionInfo(i, i2, z));
    }

    public static AccessibilityNodeInfoCompat$CollectionInfoCompat obtain(int i, int i2, boolean z, int i3) {
        return new AccessibilityNodeInfoCompat$CollectionInfoCompat(AccessibilityNodeInfoCompat.IMPL.obtainCollectionInfo(i, i2, z, i3));
    }

    public int getColumnCount() {
        return AccessibilityNodeInfoCompat.IMPL.getCollectionInfoColumnCount(this.mInfo);
    }

    public int getRowCount() {
        return AccessibilityNodeInfoCompat.IMPL.getCollectionInfoRowCount(this.mInfo);
    }

    public int getSelectionMode() {
        return AccessibilityNodeInfoCompat.IMPL.getCollectionInfoSelectionMode(this.mInfo);
    }

    public boolean isHierarchical() {
        return AccessibilityNodeInfoCompat.IMPL.isCollectionInfoHierarchical(this.mInfo);
    }
}
