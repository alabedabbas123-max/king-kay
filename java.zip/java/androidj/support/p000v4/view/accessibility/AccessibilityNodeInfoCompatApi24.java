package androidj.support.p000v4.view.accessibility;

import android.annotation.TargetApi;
import android.view.accessibility.AccessibilityNodeInfo;
import androidj.support.annotation.RequiresApi;

@TargetApi(24)
@RequiresApi(24)
class AccessibilityNodeInfoCompatApi24 {
    AccessibilityNodeInfoCompatApi24() {
    }

    public static Object getActionSetProgress() {
        return AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS;
    }

    public static int getDrawingOrder(Object obj) {
        return ((AccessibilityNodeInfo) obj).getDrawingOrder();
    }

    public static boolean isImportantForAccessibility(Object obj) {
        return ((AccessibilityNodeInfo) obj).isImportantForAccessibility();
    }

    public static void setDrawingOrder(Object obj, int i) {
        ((AccessibilityNodeInfo) obj).setDrawingOrder(i);
    }

    public static void setImportantForAccessibility(Object obj, boolean z) {
        ((AccessibilityNodeInfo) obj).setImportantForAccessibility(z);
    }
}
