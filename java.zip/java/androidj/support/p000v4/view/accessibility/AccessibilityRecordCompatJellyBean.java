package androidj.support.p000v4.view.accessibility;

import android.annotation.TargetApi;
import android.view.View;
import android.view.accessibility.AccessibilityRecord;
import androidj.support.annotation.RequiresApi;

@TargetApi(16)
@RequiresApi(16)
class AccessibilityRecordCompatJellyBean {
    AccessibilityRecordCompatJellyBean() {
    }

    public static void setSource(Object obj, View view, int i) {
        ((AccessibilityRecord) obj).setSource(view, i);
    }
}
