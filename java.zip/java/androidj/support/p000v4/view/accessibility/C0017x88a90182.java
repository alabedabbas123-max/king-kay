package androidj.support.p000v4.view.accessibility;

import androidj.support.v4.view.accessibility.AccessibilityNodeInfoCompatApi24;

class C0017x88a90182 extends C0016x889aea01 {
    C0017x88a90182() {
    }

    @Override
    public Object getActionSetProgress() {
        return AccessibilityNodeInfoCompatApi24.getActionSetProgress();
    }

    @Override
    public int getDrawingOrder(Object obj) {
        return AccessibilityNodeInfoCompatApi24.getDrawingOrder(obj);
    }

    @Override
    public boolean isImportantForAccessibility(Object obj) {
        return AccessibilityNodeInfoCompatApi24.isImportantForAccessibility(obj);
    }

    @Override
    public void setDrawingOrder(Object obj, int i) {
        AccessibilityNodeInfoCompatApi24.setDrawingOrder(obj, i);
    }

    @Override
    public void setImportantForAccessibility(Object obj, boolean z) {
        AccessibilityNodeInfoCompatApi24.setImportantForAccessibility(obj, z);
    }
}
