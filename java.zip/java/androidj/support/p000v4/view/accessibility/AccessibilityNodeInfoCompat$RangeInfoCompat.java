package androidj.support.p000v4.view.accessibility;

import androidj.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import androidj.support.v4.view.accessibility.AccessibilityNodeInfoCompatKitKat;

public class AccessibilityNodeInfoCompat$RangeInfoCompat {
    public static final int RANGE_TYPE_FLOAT = 1;
    public static final int RANGE_TYPE_INT = 0;
    public static final int RANGE_TYPE_PERCENT = 2;
    final Object mInfo;

    AccessibilityNodeInfoCompat$RangeInfoCompat(Object obj) {
        this.mInfo = obj;
    }

    public static AccessibilityNodeInfoCompat$RangeInfoCompat obtain(int i, float f, float f2, float f3) {
        return new AccessibilityNodeInfoCompat$RangeInfoCompat(AccessibilityNodeInfoCompat.IMPL.obtainRangeInfo(i, f, f2, f3));
    }

    public float getCurrent() {
        return AccessibilityNodeInfoCompatKitKat.RangeInfo.getCurrent(this.mInfo);
    }

    public float getMax() {
        return AccessibilityNodeInfoCompatKitKat.RangeInfo.getMax(this.mInfo);
    }

    public float getMin() {
        return AccessibilityNodeInfoCompatKitKat.RangeInfo.getMin(this.mInfo);
    }

    public int getType() {
        return AccessibilityNodeInfoCompatKitKat.RangeInfo.getType(this.mInfo);
    }
}
