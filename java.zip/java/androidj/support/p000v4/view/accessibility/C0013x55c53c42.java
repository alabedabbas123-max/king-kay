package androidj.support.p000v4.view.accessibility;

import androidj.support.v4.view.accessibility.AccessibilityNodeInfoCompat;

public class C0013x55c53c42 {
    final Object mAction;
    public static final C0013x55c53c42 ACTION_FOCUS = new C0013x55c53c42(1, null);
    public static final C0013x55c53c42 ACTION_CLEAR_FOCUS = new C0013x55c53c42(2, null);
    public static final C0013x55c53c42 ACTION_SELECT = new C0013x55c53c42(4, null);
    public static final C0013x55c53c42 ACTION_CLEAR_SELECTION = new C0013x55c53c42(8, null);
    public static final C0013x55c53c42 ACTION_CLICK = new C0013x55c53c42(16, null);
    public static final C0013x55c53c42 ACTION_LONG_CLICK = new C0013x55c53c42(32, null);
    public static final C0013x55c53c42 ACTION_ACCESSIBILITY_FOCUS = new C0013x55c53c42(64, null);
    public static final C0013x55c53c42 ACTION_CLEAR_ACCESSIBILITY_FOCUS = new C0013x55c53c42(AccessibilityEventCompat.TYPE_VIEW_HOVER_ENTER, null);
    public static final C0013x55c53c42 ACTION_NEXT_AT_MOVEMENT_GRANULARITY = new C0013x55c53c42(AccessibilityEventCompat.TYPE_VIEW_HOVER_EXIT, null);
    public static final C0013x55c53c42 ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY = new C0013x55c53c42(AccessibilityEventCompat.TYPE_TOUCH_EXPLORATION_GESTURE_START, null);
    public static final C0013x55c53c42 ACTION_NEXT_HTML_ELEMENT = new C0013x55c53c42(AccessibilityEventCompat.TYPE_TOUCH_EXPLORATION_GESTURE_END, null);
    public static final C0013x55c53c42 ACTION_PREVIOUS_HTML_ELEMENT = new C0013x55c53c42(AccessibilityEventCompat.TYPE_WINDOW_CONTENT_CHANGED, null);
    public static final C0013x55c53c42 ACTION_SCROLL_FORWARD = new C0013x55c53c42(AccessibilityEventCompat.TYPE_VIEW_SCROLLED, null);
    public static final C0013x55c53c42 ACTION_SCROLL_BACKWARD = new C0013x55c53c42(AccessibilityEventCompat.TYPE_VIEW_TEXT_SELECTION_CHANGED, null);
    public static final C0013x55c53c42 ACTION_COPY = new C0013x55c53c42(AccessibilityEventCompat.TYPE_ANNOUNCEMENT, null);
    public static final C0013x55c53c42 ACTION_PASTE = new C0013x55c53c42(AccessibilityEventCompat.TYPE_VIEW_ACCESSIBILITY_FOCUSED, null);
    public static final C0013x55c53c42 ACTION_CUT = new C0013x55c53c42(AccessibilityEventCompat.TYPE_VIEW_ACCESSIBILITY_FOCUS_CLEARED, null);
    public static final C0013x55c53c42 ACTION_SET_SELECTION = new C0013x55c53c42(AccessibilityEventCompat.TYPE_VIEW_TEXT_TRAVERSED_AT_MOVEMENT_GRANULARITY, null);
    public static final C0013x55c53c42 ACTION_EXPAND = new C0013x55c53c42(AccessibilityEventCompat.TYPE_GESTURE_DETECTION_START, null);
    public static final C0013x55c53c42 ACTION_COLLAPSE = new C0013x55c53c42(AccessibilityEventCompat.TYPE_GESTURE_DETECTION_END, null);
    public static final C0013x55c53c42 ACTION_DISMISS = new C0013x55c53c42(AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START, null);
    public static final C0013x55c53c42 ACTION_SET_TEXT = new C0013x55c53c42(AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_END, null);
    public static final C0013x55c53c42 ACTION_SHOW_ON_SCREEN = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionShowOnScreen());
    public static final C0013x55c53c42 ACTION_SCROLL_TO_POSITION = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionScrollToPosition());
    public static final C0013x55c53c42 ACTION_SCROLL_UP = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionScrollUp());
    public static final C0013x55c53c42 ACTION_SCROLL_LEFT = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionScrollLeft());
    public static final C0013x55c53c42 ACTION_SCROLL_DOWN = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionScrollDown());
    public static final C0013x55c53c42 ACTION_SCROLL_RIGHT = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionScrollRight());
    public static final C0013x55c53c42 ACTION_CONTEXT_CLICK = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionContextClick());
    public static final C0013x55c53c42 ACTION_SET_PROGRESS = new C0013x55c53c42(AccessibilityNodeInfoCompat.IMPL.getActionSetProgress());

    public C0013x55c53c42(int i, CharSequence charSequence) {
        this(AccessibilityNodeInfoCompat.IMPL.newAccessibilityAction(i, charSequence));
    }

    C0013x55c53c42(Object obj) {
        this.mAction = obj;
    }

    public int getId() {
        return AccessibilityNodeInfoCompat.IMPL.getAccessibilityActionId(this.mAction);
    }

    public CharSequence getLabel() {
        return AccessibilityNodeInfoCompat.IMPL.getAccessibilityActionLabel(this.mAction);
    }
}
