package androidj.support.p000v4.view.accessibility;

import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import java.util.List;

interface InterfaceC0019xef16c2fa {
    void addAction(Object obj, int i);

    void addAction(Object obj, Object obj2);

    void addChild(Object obj, View view);

    void addChild(Object obj, View view, int i);

    boolean canOpenPopup(Object obj);

    List<Object> findAccessibilityNodeInfosByText(Object obj, String str);

    List<Object> findAccessibilityNodeInfosByViewId(Object obj, String str);

    Object findFocus(Object obj, int i);

    Object focusSearch(Object obj, int i);

    int getAccessibilityActionId(Object obj);

    CharSequence getAccessibilityActionLabel(Object obj);

    Object getActionContextClick();

    List<Object> getActionList(Object obj);

    Object getActionScrollDown();

    Object getActionScrollLeft();

    Object getActionScrollRight();

    Object getActionScrollToPosition();

    Object getActionScrollUp();

    Object getActionSetProgress();

    Object getActionShowOnScreen();

    int getActions(Object obj);

    void getBoundsInParent(Object obj, Rect rect);

    void getBoundsInScreen(Object obj, Rect rect);

    Object getChild(Object obj, int i);

    int getChildCount(Object obj);

    CharSequence getClassName(Object obj);

    Object getCollectionInfo(Object obj);

    int getCollectionInfoColumnCount(Object obj);

    int getCollectionInfoRowCount(Object obj);

    int getCollectionInfoSelectionMode(Object obj);

    int getCollectionItemColumnIndex(Object obj);

    int getCollectionItemColumnSpan(Object obj);

    Object getCollectionItemInfo(Object obj);

    int getCollectionItemRowIndex(Object obj);

    int getCollectionItemRowSpan(Object obj);

    CharSequence getContentDescription(Object obj);

    int getDrawingOrder(Object obj);

    CharSequence getError(Object obj);

    Bundle getExtras(Object obj);

    int getInputType(Object obj);

    Object getLabelFor(Object obj);

    Object getLabeledBy(Object obj);

    int getLiveRegion(Object obj);

    int getMaxTextLength(Object obj);

    int getMovementGranularities(Object obj);

    CharSequence getPackageName(Object obj);

    Object getParent(Object obj);

    Object getRangeInfo(Object obj);

    CharSequence getRoleDescription(Object obj);

    CharSequence getText(Object obj);

    int getTextSelectionEnd(Object obj);

    int getTextSelectionStart(Object obj);

    Object getTraversalAfter(Object obj);

    Object getTraversalBefore(Object obj);

    String getViewIdResourceName(Object obj);

    Object getWindow(Object obj);

    int getWindowId(Object obj);

    boolean isAccessibilityFocused(Object obj);

    boolean isCheckable(Object obj);

    boolean isChecked(Object obj);

    boolean isClickable(Object obj);

    boolean isCollectionInfoHierarchical(Object obj);

    boolean isCollectionItemHeading(Object obj);

    boolean isCollectionItemSelected(Object obj);

    boolean isContentInvalid(Object obj);

    boolean isContextClickable(Object obj);

    boolean isDismissable(Object obj);

    boolean isEditable(Object obj);

    boolean isEnabled(Object obj);

    boolean isFocusable(Object obj);

    boolean isFocused(Object obj);

    boolean isImportantForAccessibility(Object obj);

    boolean isLongClickable(Object obj);

    boolean isMultiLine(Object obj);

    boolean isPassword(Object obj);

    boolean isScrollable(Object obj);

    boolean isSelected(Object obj);

    boolean isVisibleToUser(Object obj);

    Object newAccessibilityAction(int i, CharSequence charSequence);

    Object obtain();

    Object obtain(View view);

    Object obtain(View view, int i);

    Object obtain(Object obj);

    Object obtainCollectionInfo(int i, int i2, boolean z);

    Object obtainCollectionInfo(int i, int i2, boolean z, int i3);

    Object obtainCollectionItemInfo(int i, int i2, int i3, int i4, boolean z);

    Object obtainCollectionItemInfo(int i, int i2, int i3, int i4, boolean z, boolean z2);

    Object obtainRangeInfo(int i, float f, float f2, float f3);

    boolean performAction(Object obj, int i);

    boolean performAction(Object obj, int i, Bundle bundle);

    void recycle(Object obj);

    boolean refresh(Object obj);

    boolean removeAction(Object obj, Object obj2);

    boolean removeChild(Object obj, View view);

    boolean removeChild(Object obj, View view, int i);

    void setAccessibilityFocused(Object obj, boolean z);

    void setBoundsInParent(Object obj, Rect rect);

    void setBoundsInScreen(Object obj, Rect rect);

    void setCanOpenPopup(Object obj, boolean z);

    void setCheckable(Object obj, boolean z);

    void setChecked(Object obj, boolean z);

    void setClassName(Object obj, CharSequence charSequence);

    void setClickable(Object obj, boolean z);

    void setCollectionInfo(Object obj, Object obj2);

    void setCollectionItemInfo(Object obj, Object obj2);

    void setContentDescription(Object obj, CharSequence charSequence);

    void setContentInvalid(Object obj, boolean z);

    void setContextClickable(Object obj, boolean z);

    void setDismissable(Object obj, boolean z);

    void setDrawingOrder(Object obj, int i);

    void setEditable(Object obj, boolean z);

    void setEnabled(Object obj, boolean z);

    void setError(Object obj, CharSequence charSequence);

    void setFocusable(Object obj, boolean z);

    void setFocused(Object obj, boolean z);

    void setImportantForAccessibility(Object obj, boolean z);

    void setInputType(Object obj, int i);

    void setLabelFor(Object obj, View view);

    void setLabelFor(Object obj, View view, int i);

    void setLabeledBy(Object obj, View view);

    void setLabeledBy(Object obj, View view, int i);

    void setLiveRegion(Object obj, int i);

    void setLongClickable(Object obj, boolean z);

    void setMaxTextLength(Object obj, int i);

    void setMovementGranularities(Object obj, int i);

    void setMultiLine(Object obj, boolean z);

    void setPackageName(Object obj, CharSequence charSequence);

    void setParent(Object obj, View view);

    void setParent(Object obj, View view, int i);

    void setPassword(Object obj, boolean z);

    void setRangeInfo(Object obj, Object obj2);

    void setRoleDescription(Object obj, CharSequence charSequence);

    void setScrollable(Object obj, boolean z);

    void setSelected(Object obj, boolean z);

    void setSource(Object obj, View view);

    void setSource(Object obj, View view, int i);

    void setText(Object obj, CharSequence charSequence);

    void setTextSelection(Object obj, int i, int i2);

    void setTraversalAfter(Object obj, View view);

    void setTraversalAfter(Object obj, View view, int i);

    void setTraversalBefore(Object obj, View view);

    void setTraversalBefore(Object obj, View view, int i);

    void setViewIdResourceName(Object obj, String str);

    void setVisibleToUser(Object obj, boolean z);
}
