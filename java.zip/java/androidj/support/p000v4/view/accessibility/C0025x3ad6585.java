package androidj.support.p000v4.view.accessibility;

import androidj.support.v4.view.accessibility.AccessibilityNodeInfoCompat;

public class C0025x3ad6585 {
    final Object mInfo;

    C0025x3ad6585(Object obj) {
        this.mInfo = obj;
    }

    public static C0025x3ad6585 obtain(int i, int i2, int i3, int i4, boolean z) {
        return new C0025x3ad6585(AccessibilityNodeInfoCompat.IMPL.obtainCollectionItemInfo(i, i2, i3, i4, z));
    }

    public static C0025x3ad6585 obtain(int i, int i2, int i3, int i4, boolean z, boolean z2) {
        return new C0025x3ad6585(AccessibilityNodeInfoCompat.IMPL.obtainCollectionItemInfo(i, i2, i3, i4, z, z2));
    }

    public int getColumnIndex() {
        return AccessibilityNodeInfoCompat.IMPL.getCollectionItemColumnIndex(this.mInfo);
    }

    public int getColumnSpan() {
        return AccessibilityNodeInfoCompat.IMPL.getCollectionItemColumnSpan(this.mInfo);
    }

    public int getRowIndex() {
        return AccessibilityNodeInfoCompat.IMPL.getCollectionItemRowIndex(this.mInfo);
    }

    public int getRowSpan() {
        return AccessibilityNodeInfoCompat.IMPL.getCollectionItemRowSpan(this.mInfo);
    }

    public boolean isHeading() {
        return AccessibilityNodeInfoCompat.IMPL.isCollectionItemHeading(this.mInfo);
    }

    public boolean isSelected() {
        return AccessibilityNodeInfoCompat.IMPL.isCollectionItemSelected(this.mInfo);
    }
}
