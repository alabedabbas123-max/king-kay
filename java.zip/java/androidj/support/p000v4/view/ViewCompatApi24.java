package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.PointerIcon;
import android.view.View;
import androidj.support.annotation.RequiresApi;

@TargetApi(24)
@RequiresApi(24)
class ViewCompatApi24 {
    ViewCompatApi24() {
    }

    public static void setPointerIcon(View view, Object obj) {
        view.setPointerIcon((PointerIcon) obj);
    }
}
