package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.ViewGroup;
import androidj.support.annotation.RequiresApi;

@TargetApi(11)
@RequiresApi(11)
class ViewGroupCompatHC {
    private ViewGroupCompatHC() {
    }

    public static void setMotionEventSplittingEnabled(ViewGroup viewGroup, boolean z) {
        viewGroup.setMotionEventSplittingEnabled(z);
    }
}
