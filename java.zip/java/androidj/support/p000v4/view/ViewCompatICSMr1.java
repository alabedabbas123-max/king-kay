package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.View;
import androidj.support.annotation.RequiresApi;

@TargetApi(15)
@RequiresApi(15)
class ViewCompatICSMr1 {
    ViewCompatICSMr1() {
    }

    public static boolean hasOnClickListeners(View view) {
        return view.hasOnClickListeners();
    }
}
