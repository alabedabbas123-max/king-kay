package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.widget.TextView;
import androidj.support.annotation.RequiresApi;

@TargetApi(14)
@RequiresApi(14)
class PagerTitleStripIcs {
    PagerTitleStripIcs() {
    }

    public static void setSingleLineAllCaps(TextView textView) {
        textView.setTransformationMethod(new SingleLineAllCapsTransform(textView.getContext()));
    }
}
