package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.MotionEvent;
import androidj.support.annotation.RequiresApi;

@TargetApi(MotionEventCompat.AXIS_RX)
@RequiresApi(MotionEventCompat.AXIS_RX)
class MotionEventCompatHoneycombMr1 {
    MotionEventCompatHoneycombMr1() {
    }

    static float getAxisValue(MotionEvent motionEvent, int i) {
        return motionEvent.getAxisValue(i);
    }

    static float getAxisValue(MotionEvent motionEvent, int i, int i2) {
        return motionEvent.getAxisValue(i, i2);
    }
}
