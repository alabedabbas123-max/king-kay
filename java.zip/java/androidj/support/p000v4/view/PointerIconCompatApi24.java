package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.view.PointerIcon;
import androidj.support.annotation.RequiresApi;

@TargetApi(24)
@RequiresApi(24)
class PointerIconCompatApi24 {
    PointerIconCompatApi24() {
    }

    public static Object create(Bitmap bitmap, float f, float f2) {
        return PointerIcon.create(bitmap, f, f2);
    }

    public static Object getSystemIcon(Context context, int i) {
        return PointerIcon.getSystemIcon(context, i);
    }

    public static Object load(Resources resources, int i) {
        return PointerIcon.load(resources, i);
    }
}
