package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.MotionEvent;
import androidj.support.annotation.RequiresApi;

@TargetApi(MotionEventCompat.AXIS_RZ)
@RequiresApi(MotionEventCompat.AXIS_RZ)
class MotionEventCompatICS {
    MotionEventCompatICS() {
    }

    public static int getButtonState(MotionEvent motionEvent) {
        return motionEvent.getButtonState();
    }
}
