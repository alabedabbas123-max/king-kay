package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.KeyEvent;
import androidj.support.annotation.RequiresApi;

@TargetApi(MotionEventCompat.AXIS_Z)
@RequiresApi(MotionEventCompat.AXIS_Z)
class KeyEventCompatHoneycomb {
    KeyEventCompatHoneycomb() {
    }

    public static boolean isCtrlPressed(KeyEvent keyEvent) {
        return keyEvent.isCtrlPressed();
    }

    public static boolean metaStateHasModifiers(int i, int i2) {
        return KeyEvent.metaStateHasModifiers(i, i2);
    }

    public static boolean metaStateHasNoModifiers(int i) {
        return KeyEvent.metaStateHasNoModifiers(i);
    }

    public static int normalizeMetaState(int i) {
        return KeyEvent.normalizeMetaState(i);
    }
}
