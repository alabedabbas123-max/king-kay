package androidj.support.p000v4.view;

import android.content.Context;
import android.text.method.SingleLineTransformationMethod;
import android.view.View;
import java.util.Locale;

public class PagerTitleStripIcs$SingleLineAllCapsTransform extends SingleLineTransformationMethod {

    private static final String f27TAG = "SingleLineAllCapsTransform";
    private Locale mLocale;

    public PagerTitleStripIcs$SingleLineAllCapsTransform(Context context) {
        this.mLocale = context.getResources().getConfiguration().locale;
    }

    @Override
    public CharSequence getTransformation(CharSequence charSequence, View view) {
        CharSequence transformation = super.getTransformation(charSequence, view);
        if (transformation != null) {
            return transformation.toString().toUpperCase(this.mLocale);
        }
        return null;
    }
}
