package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.ScaleGestureDetector;
import androidj.support.annotation.RequiresApi;

@TargetApi(19)
@RequiresApi(19)
class ScaleGestureDetectorCompatKitKat {
    private ScaleGestureDetectorCompatKitKat() {
    }

    public static boolean isQuickScaleEnabled(Object obj) {
        return ((ScaleGestureDetector) obj).isQuickScaleEnabled();
    }

    public static void setQuickScaleEnabled(Object obj, boolean z) {
        ((ScaleGestureDetector) obj).setQuickScaleEnabled(z);
    }
}
