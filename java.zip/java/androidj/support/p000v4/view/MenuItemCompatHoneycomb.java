package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.MenuItem;
import android.view.View;
import androidj.support.annotation.RequiresApi;

@TargetApi(MotionEventCompat.AXIS_Z)
@RequiresApi(MotionEventCompat.AXIS_Z)
class MenuItemCompatHoneycomb {
    MenuItemCompatHoneycomb() {
    }

    public static View getActionView(MenuItem menuItem) {
        return menuItem.getActionView();
    }

    public static MenuItem setActionView(MenuItem menuItem, int i) {
        return menuItem.setActionView(i);
    }

    public static MenuItem setActionView(MenuItem menuItem, View view) {
        return menuItem.setActionView(view);
    }

    public static void setShowAsAction(MenuItem menuItem, int i) {
        menuItem.setShowAsAction(i);
    }
}
