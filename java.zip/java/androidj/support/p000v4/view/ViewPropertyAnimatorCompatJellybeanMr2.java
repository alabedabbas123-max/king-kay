package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.View;
import android.view.animation.Interpolator;
import androidj.support.annotation.RequiresApi;

@TargetApi(18)
@RequiresApi(18)
class ViewPropertyAnimatorCompatJellybeanMr2 {
    ViewPropertyAnimatorCompatJellybeanMr2() {
    }

    public static Interpolator getInterpolator(View view) {
        return (Interpolator) view.animate().getInterpolator();
    }
}
