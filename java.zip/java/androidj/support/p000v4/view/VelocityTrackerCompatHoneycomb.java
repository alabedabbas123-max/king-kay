package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.VelocityTracker;
import androidj.support.annotation.RequiresApi;

@TargetApi(11)
@RequiresApi(11)
class VelocityTrackerCompatHoneycomb {
    VelocityTrackerCompatHoneycomb() {
    }

    public static float getXVelocity(VelocityTracker velocityTracker, int i) {
        return velocityTracker.getXVelocity(i);
    }

    public static float getYVelocity(VelocityTracker velocityTracker, int i) {
        return velocityTracker.getYVelocity(i);
    }
}
