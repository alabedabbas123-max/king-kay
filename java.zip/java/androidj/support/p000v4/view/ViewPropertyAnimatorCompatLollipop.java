package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.View;
import androidj.support.annotation.RequiresApi;

@TargetApi(21)
@RequiresApi(21)
class ViewPropertyAnimatorCompatLollipop {
    ViewPropertyAnimatorCompatLollipop() {
    }

    public static void translationZ(View view, float f) {
        view.animate().translationZ(f);
    }

    public static void translationZBy(View view, float f) {
        view.animate().translationZBy(f);
    }

    public static void m16z(View view, float f) {
        view.animate().z(f);
    }

    public static void m17zBy(View view, float f) {
        view.animate().zBy(f);
    }
}
