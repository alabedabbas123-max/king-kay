package androidj.support.p000v4.view;

import android.annotation.TargetApi;
import android.view.LayoutInflater;
import androidj.support.annotation.RequiresApi;

@TargetApi(MotionEventCompat.AXIS_WHEEL)
@RequiresApi(MotionEventCompat.AXIS_WHEEL)
class LayoutInflaterCompatLollipop {
    LayoutInflaterCompatLollipop() {
    }

    static void setFactory(LayoutInflater layoutInflater, LayoutInflaterFactory layoutInflaterFactory) {
        layoutInflater.setFactory2(layoutInflaterFactory != null ? new LayoutInflaterCompatHC.FactoryWrapperHC(layoutInflaterFactory) : null);
    }
}
