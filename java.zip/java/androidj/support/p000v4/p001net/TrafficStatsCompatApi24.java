package androidj.support.p000v4.p001net;

import android.annotation.TargetApi;
import android.net.TrafficStats;
import androidj.support.annotation.RequiresApi;
import androidj.support.annotation.RestrictTo;
import java.net.DatagramSocket;
import java.net.SocketException;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
@TargetApi(24)
@RequiresApi(24)
public class TrafficStatsCompatApi24 {
    public static void tagDatagramSocket(DatagramSocket datagramSocket) throws SocketException {
        TrafficStats.tagDatagramSocket(datagramSocket);
    }

    public static void untagDatagramSocket(DatagramSocket datagramSocket) throws SocketException {
        TrafficStats.untagDatagramSocket(datagramSocket);
    }
}
