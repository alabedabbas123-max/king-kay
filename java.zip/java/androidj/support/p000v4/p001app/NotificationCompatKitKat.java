package androidj.support.p000v4.p001app;

import android.annotation.TargetApi;
import android.app.Notification;
import android.os.Bundle;
import android.util.SparseArray;
import androidj.support.annotation.RequiresApi;
import androidj.support.v4.app.NotificationCompatBase;
import androidj.support.v4.app.NotificationCompatJellybean;

@TargetApi(19)
@RequiresApi(19)
class NotificationCompatKitKat {
    NotificationCompatKitKat() {
    }

    public static NotificationCompatBase.Action getAction(Notification notification, int i, NotificationCompatBase.Action.Factory factory, RemoteInputCompatBase.RemoteInput.Factory factory2) {
        Notification.Action action = notification.actions[i];
        SparseArray sparseParcelableArray = notification.extras.getSparseParcelableArray("android.support.actionExtras");
        return NotificationCompatJellybean.readAction(factory, factory2, action.icon, action.title, action.actionIntent, sparseParcelableArray != null ? (Bundle) sparseParcelableArray.get(i) : null);
    }

    public static int getActionCount(Notification notification) {
        if (notification.actions != null) {
            return notification.actions.length;
        }
        return 0;
    }

    public static Bundle getExtras(Notification notification) {
        return notification.extras;
    }

    public static String getGroup(Notification notification) {
        return notification.extras.getString("android.support.groupKey");
    }

    public static boolean getLocalOnly(Notification notification) {
        return notification.extras.getBoolean("android.support.localOnly");
    }

    public static String getSortKey(Notification notification) {
        return notification.extras.getString("android.support.sortKey");
    }

    public static boolean isGroupSummary(Notification notification) {
        return notification.extras.getBoolean("android.support.isGroupSummary");
    }
}
