package androidj.support.p000v4.p001app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.List;

public class NotificationCompatKitKat$Builder implements NotificationBuilderWithBuilderAccessor, NotificationBuilderWithActions {

    private Notification.Builder f19b;
    private List<Bundle> mActionExtrasList = new ArrayList();
    private RemoteViews mBigContentView;
    private RemoteViews mContentView;
    private Bundle mExtras;

    public NotificationCompatKitKat$Builder(Context context, Notification notification, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, RemoteViews remoteViews, int i, PendingIntent pendingIntent, PendingIntent pendingIntent2, Bitmap bitmap, int i2, int i3, boolean z, boolean z2, boolean z3, int i4, CharSequence charSequence4, boolean z4, ArrayList<String> arrayList, Bundle bundle, String str, boolean z5, String str2, RemoteViews remoteViews2, RemoteViews remoteViews3) {
        this.f19b = new Notification.Builder(context).setWhen(notification.when).setShowWhen(z2).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, remoteViews).setSound(notification.sound, notification.audioStreamType).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS).setOngoing((notification.flags & 2) != 0).setOnlyAlertOnce((notification.flags & 8) != 0).setAutoCancel((notification.flags & 16) != 0).setDefaults(notification.defaults).setContentTitle(charSequence).setContentText(charSequence2).setSubText(charSequence4).setContentInfo(charSequence3).setContentIntent(pendingIntent).setDeleteIntent(notification.deleteIntent).setFullScreenIntent(pendingIntent2, (notification.flags & NotificationCompat.FLAG_HIGH_PRIORITY) != 0).setLargeIcon(bitmap).setNumber(i).setUsesChronometer(z3).setPriority(i4).setProgress(i2, i3, z);
        this.mExtras = new Bundle();
        if (bundle != null) {
            this.mExtras.putAll(bundle);
        }
        if (arrayList != null && !arrayList.isEmpty()) {
            this.mExtras.putStringArray(NotificationCompat.EXTRA_PEOPLE, (String[]) arrayList.toArray(new String[arrayList.size()]));
        }
        if (z4) {
            this.mExtras.putBoolean(NotificationCompatExtras.EXTRA_LOCAL_ONLY, true);
        }
        if (str != null) {
            this.mExtras.putString(NotificationCompatExtras.EXTRA_GROUP_KEY, str);
            if (z5) {
                this.mExtras.putBoolean(NotificationCompatExtras.EXTRA_GROUP_SUMMARY, true);
            } else {
                this.mExtras.putBoolean("android.support.useSideChannel", true);
            }
        }
        if (str2 != null) {
            this.mExtras.putString(NotificationCompatExtras.EXTRA_SORT_KEY, str2);
        }
        this.mContentView = remoteViews2;
        this.mBigContentView = remoteViews3;
    }

    @Override
    public void addAction(NotificationCompatBase.Action action) {
        this.mActionExtrasList.add(NotificationCompatJellybean.writeActionAndGetExtras(this.f19b, action));
    }

    @Override
    public Notification build() {
        SparseArray<Bundle> sparseArrayBuildActionExtrasMap = NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
        if (sparseArrayBuildActionExtrasMap != null) {
            this.mExtras.putSparseParcelableArray(NotificationCompatExtras.EXTRA_ACTION_EXTRAS, sparseArrayBuildActionExtrasMap);
        }
        this.f19b.setExtras(this.mExtras);
        Notification notificationBuild = this.f19b.build();
        if (this.mContentView != null) {
            notificationBuild.contentView = this.mContentView;
        }
        if (this.mBigContentView != null) {
            notificationBuild.bigContentView = this.mBigContentView;
        }
        return notificationBuild;
    }

    @Override
    public Notification.Builder getBuilder() {
        return this.f19b;
    }
}
