package androidj.support.p000v4.p001app;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

abstract class BaseFragmentActivityHoneycomb extends BaseFragmentActivityGingerbread {
    BaseFragmentActivityHoneycomb() {
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View viewDispatchFragmentsOnCreateView = dispatchFragmentsOnCreateView(view, str, context, attributeSet);
        return (viewDispatchFragmentsOnCreateView != null || Build.VERSION.SDK_INT < 11) ? viewDispatchFragmentsOnCreateView : super.onCreateView(view, str, context, attributeSet);
    }
}
