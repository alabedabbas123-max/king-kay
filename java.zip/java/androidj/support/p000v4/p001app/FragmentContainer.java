package androidj.support.p000v4.p001app;

import android.view.View;
import androidj.support.annotation.IdRes;
import androidj.support.annotation.Nullable;

public abstract class FragmentContainer {
    @Nullable
    public abstract View onFindViewById(@IdRes int i);

    public abstract boolean onHasView();
}
