package androidj.support.p000v4.p001app;

import android.annotation.TargetApi;
import android.app.Service;
import androidj.support.annotation.RequiresApi;

@TargetApi(24)
@RequiresApi(24)
class ServiceCompatApi24 {
    ServiceCompatApi24() {
    }

    public static void stopForeground(Service service, int i) {
        service.stopForeground(i);
    }
}
