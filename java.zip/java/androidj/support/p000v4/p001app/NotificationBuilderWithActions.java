package androidj.support.p000v4.p001app;

interface NotificationBuilderWithActions {
    void addAction(NotificationCompatBase.Action action);
}
