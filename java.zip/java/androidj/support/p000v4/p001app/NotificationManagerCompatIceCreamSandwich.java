package androidj.support.p000v4.p001app;

import android.annotation.TargetApi;
import androidj.support.annotation.RequiresApi;

@TargetApi(14)
@RequiresApi(14)
class NotificationManagerCompatIceCreamSandwich {
    static final int SIDE_CHANNEL_BIND_FLAGS = 33;

    NotificationManagerCompatIceCreamSandwich() {
    }
}
