package androidj.support.p000v4.p001app;

import android.view.View;
import androidj.support.annotation.AnimRes;
import androidj.support.annotation.IdRes;
import androidj.support.annotation.Nullable;
import androidj.support.annotation.StringRes;
import androidj.support.annotation.StyleRes;

public abstract class FragmentTransaction {
    public static final int TRANSIT_ENTER_MASK = 4096;
    public static final int TRANSIT_EXIT_MASK = 8192;
    public static final int TRANSIT_FRAGMENT_CLOSE = 8194;
    public static final int TRANSIT_FRAGMENT_FADE = 4099;
    public static final int TRANSIT_FRAGMENT_OPEN = 4097;
    public static final int TRANSIT_NONE = 0;
    public static final int TRANSIT_UNSET = -1;

    public abstract FragmentTransaction mo0add(@IdRes int i, Fragment fragment);

    public abstract FragmentTransaction mo1add(@IdRes int i, Fragment fragment, @Nullable String str);

    public abstract FragmentTransaction mo2add(Fragment fragment, String str);

    public abstract FragmentTransaction addSharedElement(View view, String str);

    public abstract FragmentTransaction addToBackStack(@Nullable String str);

    public abstract FragmentTransaction attach(Fragment fragment);

    public abstract int commit();

    public abstract int commitAllowingStateLoss();

    public abstract void commitNow();

    public abstract void commitNowAllowingStateLoss();

    public abstract FragmentTransaction detach(Fragment fragment);

    public abstract FragmentTransaction disallowAddToBackStack();

    public abstract FragmentTransaction hide(Fragment fragment);

    public abstract boolean isAddToBackStackAllowed();

    public abstract boolean isEmpty();

    public abstract FragmentTransaction remove(Fragment fragment);

    public abstract FragmentTransaction replace(@IdRes int i, Fragment fragment);

    public abstract FragmentTransaction replace(@IdRes int i, Fragment fragment, @Nullable String str);

    public abstract FragmentTransaction setAllowOptimization(boolean z);

    public abstract FragmentTransaction setBreadCrumbShortTitle(@StringRes int i);

    public abstract FragmentTransaction setBreadCrumbShortTitle(CharSequence charSequence);

    public abstract FragmentTransaction setBreadCrumbTitle(@StringRes int i);

    public abstract FragmentTransaction setBreadCrumbTitle(CharSequence charSequence);

    public abstract FragmentTransaction setCustomAnimations(@AnimRes int i, @AnimRes int i2);

    public abstract FragmentTransaction setCustomAnimations(@AnimRes int i, @AnimRes int i2, @AnimRes int i3, @AnimRes int i4);

    public abstract FragmentTransaction setTransition(int i);

    public abstract FragmentTransaction setTransitionStyle(@StyleRes int i);

    public abstract FragmentTransaction show(Fragment fragment);
}
