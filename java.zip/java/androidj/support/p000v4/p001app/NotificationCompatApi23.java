package androidj.support.p000v4.p001app;

import android.annotation.TargetApi;
import androidj.support.annotation.RequiresApi;

@TargetApi(23)
@RequiresApi(23)
class NotificationCompatApi23 {
    public static final String CATEGORY_REMINDER = "reminder";

    NotificationCompatApi23() {
    }
}
