package androidj.support.p000v4.p001app;

import android.annotation.TargetApi;
import android.text.Html;
import androidj.support.annotation.RequiresApi;

@TargetApi(16)
@RequiresApi(16)
class ShareCompatJB {
    ShareCompatJB() {
    }

    public static String escapeHtml(CharSequence charSequence) {
        return Html.escapeHtml(charSequence);
    }
}
