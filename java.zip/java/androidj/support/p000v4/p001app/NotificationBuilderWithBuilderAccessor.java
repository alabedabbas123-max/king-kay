package androidj.support.p000v4.p001app;

import android.annotation.TargetApi;
import android.app.Notification;
import androidj.support.annotation.RequiresApi;
import androidj.support.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
@TargetApi(11)
@RequiresApi(11)
public interface NotificationBuilderWithBuilderAccessor {
    Notification build();

    Notification.Builder getBuilder();
}
