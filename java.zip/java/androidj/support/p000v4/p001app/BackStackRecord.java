package androidj.support.p000v4.p001app;

import android.os.Build;
import android.util.Log;
import android.view.View;
import androidj.support.v4.app.SuperNotCalledException;
import androidj.support.v4.util.LogWriter;
import androidj.support.v4.view.ViewCompat;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

final class BackStackRecord extends FragmentTransaction implements FragmentManager.BackStackEntry, FragmentManagerImpl.OpGenerator {
    static final int OP_ADD = 1;
    static final int OP_ATTACH = 7;
    static final int OP_DETACH = 6;
    static final int OP_HIDE = 4;
    static final int OP_NULL = 0;
    static final int OP_REMOVE = 3;
    static final int OP_REPLACE = 2;
    static final int OP_SHOW = 5;
    static final boolean SUPPORTS_TRANSITIONS;

    static final String f0TAG = "FragmentManager";
    boolean mAddToBackStack;
    int mBreadCrumbShortTitleRes;
    CharSequence mBreadCrumbShortTitleText;
    int mBreadCrumbTitleRes;
    CharSequence mBreadCrumbTitleText;
    boolean mCommitted;
    int mEnterAnim;
    int mExitAnim;
    final FragmentManagerImpl mManager;
    String mName;
    int mPopEnterAnim;
    int mPopExitAnim;
    ArrayList<String> mSharedElementSourceNames;
    ArrayList<String> mSharedElementTargetNames;
    int mTransition;
    int mTransitionStyle;
    ArrayList<C0001Op> mOps = new ArrayList<>();
    boolean mAllowAddToBackStack = true;
    int mIndex = -1;
    boolean mAllowOptimization = false;

    static final class C0001Op {

        int f1cmd;
        int enterAnim;
        int exitAnim;
        Fragment fragment;
        int popEnterAnim;
        int popExitAnim;

        C0001Op() {
        }
    }

    static {
        SUPPORTS_TRANSITIONS = Build.VERSION.SDK_INT >= 21;
    }

    public BackStackRecord(FragmentManagerImpl fragmentManagerImpl) {
        this.mManager = fragmentManagerImpl;
    }

    private void doAddOp(int i, Fragment fragment, String str, int i2) {
        Class<?> cls = fragment.getClass();
        int modifiers = cls.getModifiers();
        if (cls.isAnonymousClass() || !Modifier.isPublic(modifiers) || (cls.isMemberClass() && !Modifier.isStatic(modifiers))) {
            throw new IllegalStateException("Fragment " + cls.getCanonicalName() + " must be a public static class to be  properly recreated from instance state.");
        }
        fragment.mFragmentManager = this.mManager;
        if (str != null) {
            if (fragment.mTag != null && !str.equals(fragment.mTag)) {
                throw new IllegalStateException("Can't change tag of fragment " + fragment + ": was " + fragment.mTag + " now " + str);
            }
            fragment.mTag = str;
        }
        if (i != 0) {
            if (i == -1) {
                throw new IllegalArgumentException("Can't add fragment " + fragment + " with tag " + str + " to container view with no id");
            }
            if (fragment.mFragmentId != 0 && fragment.mFragmentId != i) {
                throw new IllegalStateException("Can't change container ID of fragment " + fragment + ": was " + fragment.mFragmentId + " now " + i);
            }
            fragment.mFragmentId = i;
            fragment.mContainerId = i;
        }
        C0001Op c0001Op = new C0001Op();
        c0001Op.f1cmd = i2;
        c0001Op.fragment = fragment;
        addOp(c0001Op);
    }

    private static boolean isFragmentPostponed(C0001Op c0001Op) {
        Fragment fragment = c0001Op.fragment;
        return (!fragment.mAdded || fragment.mView == null || fragment.mDetached || fragment.mHidden || !fragment.isPostponed()) ? false : true;
    }

    @Override
    public FragmentTransaction mo0add(int i, Fragment fragment) {
        doAddOp(i, fragment, null, 1);
        return this;
    }

    @Override
    public FragmentTransaction mo1add(int i, Fragment fragment, String str) {
        doAddOp(i, fragment, str, 1);
        return this;
    }

    @Override
    public FragmentTransaction mo2add(Fragment fragment, String str) {
        doAddOp(0, fragment, str, 1);
        return this;
    }

    void addOp(C0001Op c0001Op) {
        this.mOps.add(c0001Op);
        c0001Op.enterAnim = this.mEnterAnim;
        c0001Op.exitAnim = this.mExitAnim;
        c0001Op.popEnterAnim = this.mPopEnterAnim;
        c0001Op.popExitAnim = this.mPopExitAnim;
    }

    @Override
    public FragmentTransaction addSharedElement(View view, String str) {
        if (SUPPORTS_TRANSITIONS) {
            String transitionName = ViewCompat.getTransitionName(view);
            if (transitionName == null) {
                throw new IllegalArgumentException("Unique transitionNames are required for all sharedElements");
            }
            if (this.mSharedElementSourceNames == null) {
                this.mSharedElementSourceNames = new ArrayList<>();
                this.mSharedElementTargetNames = new ArrayList<>();
            } else {
                if (this.mSharedElementTargetNames.contains(str)) {
                    throw new IllegalArgumentException("A shared element with the target name '" + str + "' has already been added to the transaction.");
                }
                if (this.mSharedElementSourceNames.contains(transitionName)) {
                    throw new IllegalArgumentException("A shared element with the source name '" + transitionName + " has already been added to the transaction.");
                }
            }
            this.mSharedElementSourceNames.add(transitionName);
            this.mSharedElementTargetNames.add(str);
        }
        return this;
    }

    @Override
    public FragmentTransaction addToBackStack(String str) {
        if (!this.mAllowAddToBackStack) {
            throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
        }
        this.mAddToBackStack = true;
        this.mName = str;
        return this;
    }

    @Override
    public FragmentTransaction attach(Fragment fragment) {
        C0001Op c0001Op = new C0001Op();
        c0001Op.f1cmd = OP_ATTACH;
        c0001Op.fragment = fragment;
        addOp(c0001Op);
        return this;
    }

    void bumpBackStackNesting(int i) {
        if (this.mAddToBackStack) {
            if (FragmentManagerImpl.DEBUG) {
                Log.v(f0TAG, "Bump nesting in " + this + " by " + i);
            }
            int size = this.mOps.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0001Op c0001Op = this.mOps.get(i2);
                if (c0001Op.fragment != null) {
                    c0001Op.fragment.mBackStackNesting += i;
                    if (FragmentManagerImpl.DEBUG) {
                        Log.v(f0TAG, "Bump nesting of " + c0001Op.fragment + " to " + c0001Op.fragment.mBackStackNesting);
                    }
                }
            }
        }
    }

    @Override
    public int commit() {
        return commitInternal(false);
    }

    @Override
    public int commitAllowingStateLoss() {
        return commitInternal(true);
    }

    int commitInternal(boolean z) {
        if (this.mCommitted) {
            throw new IllegalStateException("commit already called");
        }
        if (FragmentManagerImpl.DEBUG) {
            Log.v(f0TAG, "Commit: " + this);
            PrintWriter printWriter = new PrintWriter((Writer) new LogWriter(f0TAG));
            dump("  ", null, printWriter, null);
            printWriter.close();
        }
        this.mCommitted = true;
        if (this.mAddToBackStack) {
            this.mIndex = this.mManager.allocBackStackIndex(this);
        } else {
            this.mIndex = -1;
        }
        this.mManager.enqueueAction(this, z);
        return this.mIndex;
    }

    @Override
    public void commitNow() throws SuperNotCalledException {
        disallowAddToBackStack();
        this.mManager.execSingleAction(this, false);
    }

    @Override
    public void commitNowAllowingStateLoss() throws SuperNotCalledException {
        disallowAddToBackStack();
        this.mManager.execSingleAction(this, true);
    }

    @Override
    public FragmentTransaction detach(Fragment fragment) {
        C0001Op c0001Op = new C0001Op();
        c0001Op.f1cmd = 6;
        c0001Op.fragment = fragment;
        addOp(c0001Op);
        return this;
    }

    @Override
    public FragmentTransaction disallowAddToBackStack() {
        if (this.mAddToBackStack) {
            throw new IllegalStateException("This transaction is already being added to the back stack");
        }
        this.mAllowAddToBackStack = false;
        return this;
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        dump(str, printWriter, true);
    }

    public void dump(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.mName);
            printWriter.print(" mIndex=");
            printWriter.print(this.mIndex);
            printWriter.print(" mCommitted=");
            printWriter.println(this.mCommitted);
            if (this.mTransition != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.mTransition));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.mTransitionStyle));
            }
            if (this.mEnterAnim != 0 || this.mExitAnim != 0) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.mEnterAnim));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.mExitAnim));
            }
            if (this.mPopEnterAnim != 0 || this.mPopExitAnim != 0) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.mPopEnterAnim));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.mPopExitAnim));
            }
            if (this.mBreadCrumbTitleRes != 0 || this.mBreadCrumbTitleText != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.mBreadCrumbTitleRes));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.mBreadCrumbTitleText);
            }
            if (this.mBreadCrumbShortTitleRes != 0 || this.mBreadCrumbShortTitleText != null) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.mBreadCrumbShortTitleRes));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.mBreadCrumbShortTitleText);
            }
        }
        if (this.mOps.isEmpty()) {
            return;
        }
        printWriter.print(str);
        printWriter.println("Operations:");
        String str3 = str + "    ";
        int size = this.mOps.size();
        for (int i = 0; i < size; i++) {
            C0001Op c0001Op = this.mOps.get(i);
            switch (c0001Op.f1cmd) {
                case 0:
                    str2 = "NULL";
                    break;
                case 1:
                    str2 = "ADD";
                    break;
                case 2:
                    str2 = "REPLACE";
                    break;
                case 3:
                    str2 = "REMOVE";
                    break;
                case 4:
                    str2 = "HIDE";
                    break;
                case 5:
                    str2 = "SHOW";
                    break;
                case 6:
                    str2 = "DETACH";
                    break;
                case OP_ATTACH:
                    str2 = "ATTACH";
                    break;
                default:
                    str2 = "cmd=" + c0001Op.f1cmd;
                    break;
            }
            printWriter.print(str);
            printWriter.print("  Op #");
            printWriter.print(i);
            printWriter.print(": ");
            printWriter.print(str2);
            printWriter.print(" ");
            printWriter.println(c0001Op.fragment);
            if (z) {
                if (c0001Op.enterAnim != 0 || c0001Op.exitAnim != 0) {
                    printWriter.print(str);
                    printWriter.print("enterAnim=#");
                    printWriter.print(Integer.toHexString(c0001Op.enterAnim));
                    printWriter.print(" exitAnim=#");
                    printWriter.println(Integer.toHexString(c0001Op.exitAnim));
                }
                if (c0001Op.popEnterAnim != 0 || c0001Op.popExitAnim != 0) {
                    printWriter.print(str);
                    printWriter.print("popEnterAnim=#");
                    printWriter.print(Integer.toHexString(c0001Op.popEnterAnim));
                    printWriter.print(" popExitAnim=#");
                    printWriter.println(Integer.toHexString(c0001Op.popExitAnim));
                }
            }
        }
    }

    void executeOps() {
        int size = this.mOps.size();
        for (int i = 0; i < size; i++) {
            C0001Op c0001Op = this.mOps.get(i);
            Fragment fragment = c0001Op.fragment;
            fragment.setNextTransition(this.mTransition, this.mTransitionStyle);
            switch (c0001Op.f1cmd) {
                case 1:
                    fragment.setNextAnim(c0001Op.enterAnim);
                    this.mManager.addFragment(fragment, false);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + c0001Op.f1cmd);
                case 3:
                    fragment.setNextAnim(c0001Op.exitAnim);
                    this.mManager.removeFragment(fragment);
                    break;
                case 4:
                    fragment.setNextAnim(c0001Op.exitAnim);
                    this.mManager.hideFragment(fragment);
                    break;
                case 5:
                    fragment.setNextAnim(c0001Op.enterAnim);
                    this.mManager.showFragment(fragment);
                    break;
                case 6:
                    fragment.setNextAnim(c0001Op.exitAnim);
                    this.mManager.detachFragment(fragment);
                    break;
                case OP_ATTACH:
                    fragment.setNextAnim(c0001Op.enterAnim);
                    this.mManager.attachFragment(fragment);
                    break;
            }
            if (!this.mAllowOptimization && c0001Op.f1cmd != 1) {
                this.mManager.moveFragmentToExpectedState(fragment);
            }
        }
        if (this.mAllowOptimization) {
            return;
        }
        this.mManager.moveToState(this.mManager.mCurState, true);
    }

    void executePopOps(boolean z) {
        for (int size = this.mOps.size() - 1; size >= 0; size--) {
            C0001Op c0001Op = this.mOps.get(size);
            Fragment fragment = c0001Op.fragment;
            fragment.setNextTransition(FragmentManagerImpl.reverseTransit(this.mTransition), this.mTransitionStyle);
            switch (c0001Op.f1cmd) {
                case 1:
                    fragment.setNextAnim(c0001Op.popExitAnim);
                    this.mManager.removeFragment(fragment);
                    break;
                case 2:
                default:
                    throw new IllegalArgumentException("Unknown cmd: " + c0001Op.f1cmd);
                case 3:
                    fragment.setNextAnim(c0001Op.popEnterAnim);
                    this.mManager.addFragment(fragment, false);
                    break;
                case 4:
                    fragment.setNextAnim(c0001Op.popEnterAnim);
                    this.mManager.showFragment(fragment);
                    break;
                case 5:
                    fragment.setNextAnim(c0001Op.popExitAnim);
                    this.mManager.hideFragment(fragment);
                    break;
                case 6:
                    fragment.setNextAnim(c0001Op.popEnterAnim);
                    this.mManager.attachFragment(fragment);
                    break;
                case OP_ATTACH:
                    fragment.setNextAnim(c0001Op.popExitAnim);
                    this.mManager.detachFragment(fragment);
                    break;
            }
            if (!this.mAllowOptimization && c0001Op.f1cmd != 3) {
                this.mManager.moveFragmentToExpectedState(fragment);
            }
        }
        if (this.mAllowOptimization || !z) {
            return;
        }
        this.mManager.moveToState(this.mManager.mCurState, true);
    }

    void expandReplaceOps(ArrayList<Fragment> arrayList) {
        boolean z;
        int i = 0;
        while (i < this.mOps.size()) {
            C0001Op c0001Op = this.mOps.get(i);
            switch (c0001Op.f1cmd) {
                case 1:
                case OP_ATTACH:
                    arrayList.add(c0001Op.fragment);
                    break;
                case 2:
                    Fragment fragment = c0001Op.fragment;
                    int i2 = fragment.mContainerId;
                    int size = arrayList.size() - 1;
                    int i3 = i;
                    boolean z2 = false;
                    while (size >= 0) {
                        Fragment fragment2 = arrayList.get(size);
                        if (fragment2.mContainerId != i2) {
                            z = z2;
                        } else if (fragment2 == fragment) {
                            z = true;
                        } else {
                            C0001Op c0001Op2 = new C0001Op();
                            c0001Op2.f1cmd = 3;
                            c0001Op2.fragment = fragment2;
                            c0001Op2.enterAnim = c0001Op.enterAnim;
                            c0001Op2.popEnterAnim = c0001Op.popEnterAnim;
                            c0001Op2.exitAnim = c0001Op.exitAnim;
                            c0001Op2.popExitAnim = c0001Op.popExitAnim;
                            this.mOps.add(i3, c0001Op2);
                            arrayList.remove(fragment2);
                            i3++;
                            z = z2;
                        }
                        size--;
                        z2 = z;
                    }
                    if (!z2) {
                        c0001Op.f1cmd = 1;
                        arrayList.add(fragment);
                        i = i3;
                    } else {
                        this.mOps.remove(i3);
                        i = i3 - 1;
                    }
                    break;
                case 3:
                case 6:
                    arrayList.remove(c0001Op.fragment);
                    break;
            }
            i++;
        }
    }

    @Override
    public boolean generateOps(ArrayList<BackStackRecord> arrayList, ArrayList<Boolean> arrayList2) {
        if (FragmentManagerImpl.DEBUG) {
            Log.v(f0TAG, "Run: " + this);
        }
        arrayList.add(this);
        arrayList2.add(false);
        if (!this.mAddToBackStack) {
            return true;
        }
        this.mManager.addBackStackState(this);
        return true;
    }

    @Override
    public CharSequence getBreadCrumbShortTitle() {
        return this.mBreadCrumbShortTitleRes != 0 ? this.mManager.mHost.getContext().getText(this.mBreadCrumbShortTitleRes) : this.mBreadCrumbShortTitleText;
    }

    @Override
    public int getBreadCrumbShortTitleRes() {
        return this.mBreadCrumbShortTitleRes;
    }

    @Override
    public CharSequence getBreadCrumbTitle() {
        return this.mBreadCrumbTitleRes != 0 ? this.mManager.mHost.getContext().getText(this.mBreadCrumbTitleRes) : this.mBreadCrumbTitleText;
    }

    @Override
    public int getBreadCrumbTitleRes() {
        return this.mBreadCrumbTitleRes;
    }

    @Override
    public int getId() {
        return this.mIndex;
    }

    @Override
    public String getName() {
        return this.mName;
    }

    public int getTransition() {
        return this.mTransition;
    }

    public int getTransitionStyle() {
        return this.mTransitionStyle;
    }

    @Override
    public FragmentTransaction hide(Fragment fragment) {
        C0001Op c0001Op = new C0001Op();
        c0001Op.f1cmd = 4;
        c0001Op.fragment = fragment;
        addOp(c0001Op);
        return this;
    }

    boolean interactsWith(int i) {
        int size = this.mOps.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (this.mOps.get(i2).fragment.mContainerId == i) {
                return true;
            }
        }
        return false;
    }

    boolean interactsWith(ArrayList<BackStackRecord> arrayList, int i, int i2) {
        int i3;
        if (i2 == i) {
            return false;
        }
        int size = this.mOps.size();
        int i4 = -1;
        int i5 = 0;
        while (i5 < size) {
            int i6 = this.mOps.get(i5).fragment.mContainerId;
            if (i6 == 0 || i6 == i4) {
                i3 = i4;
            } else {
                for (int i7 = i; i7 < i2; i7++) {
                    BackStackRecord backStackRecord = arrayList.get(i7);
                    int size2 = backStackRecord.mOps.size();
                    for (int i8 = 0; i8 < size2; i8++) {
                        if (backStackRecord.mOps.get(i8).fragment.mContainerId == i6) {
                            return true;
                        }
                    }
                }
                i3 = i6;
            }
            i5++;
            i4 = i3;
        }
        return false;
    }

    @Override
    public boolean isAddToBackStackAllowed() {
        return this.mAllowAddToBackStack;
    }

    @Override
    public boolean isEmpty() {
        return this.mOps.isEmpty();
    }

    boolean isPostponed() {
        for (int i = 0; i < this.mOps.size(); i++) {
            if (isFragmentPostponed(this.mOps.get(i))) {
                return true;
            }
        }
        return false;
    }

    @Override
    public FragmentTransaction remove(Fragment fragment) {
        C0001Op c0001Op = new C0001Op();
        c0001Op.f1cmd = 3;
        c0001Op.fragment = fragment;
        addOp(c0001Op);
        return this;
    }

    @Override
    public FragmentTransaction replace(int i, Fragment fragment) {
        return replace(i, fragment, null);
    }

    @Override
    public FragmentTransaction replace(int i, Fragment fragment, String str) {
        if (i == 0) {
            throw new IllegalArgumentException("Must use non-zero containerViewId");
        }
        doAddOp(i, fragment, str, 2);
        return this;
    }

    @Override
    public FragmentTransaction setAllowOptimization(boolean z) {
        this.mAllowOptimization = z;
        return this;
    }

    @Override
    public FragmentTransaction setBreadCrumbShortTitle(int i) {
        this.mBreadCrumbShortTitleRes = i;
        this.mBreadCrumbShortTitleText = null;
        return this;
    }

    @Override
    public FragmentTransaction setBreadCrumbShortTitle(CharSequence charSequence) {
        this.mBreadCrumbShortTitleRes = 0;
        this.mBreadCrumbShortTitleText = charSequence;
        return this;
    }

    @Override
    public FragmentTransaction setBreadCrumbTitle(int i) {
        this.mBreadCrumbTitleRes = i;
        this.mBreadCrumbTitleText = null;
        return this;
    }

    @Override
    public FragmentTransaction setBreadCrumbTitle(CharSequence charSequence) {
        this.mBreadCrumbTitleRes = 0;
        this.mBreadCrumbTitleText = charSequence;
        return this;
    }

    @Override
    public FragmentTransaction setCustomAnimations(int i, int i2) {
        return setCustomAnimations(i, i2, 0, 0);
    }

    @Override
    public FragmentTransaction setCustomAnimations(int i, int i2, int i3, int i4) {
        this.mEnterAnim = i;
        this.mExitAnim = i2;
        this.mPopEnterAnim = i3;
        this.mPopExitAnim = i4;
        return this;
    }

    void setOnStartPostponedListener(Fragment.OnStartEnterTransitionListener onStartEnterTransitionListener) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.mOps.size()) {
                return;
            }
            C0001Op c0001Op = this.mOps.get(i2);
            if (isFragmentPostponed(c0001Op)) {
                c0001Op.fragment.setOnStartEnterTransitionListener(onStartEnterTransitionListener);
            }
            i = i2 + 1;
        }
    }

    @Override
    public FragmentTransaction setTransition(int i) {
        this.mTransition = i;
        return this;
    }

    @Override
    public FragmentTransaction setTransitionStyle(int i) {
        this.mTransitionStyle = i;
        return this;
    }

    @Override
    public FragmentTransaction show(Fragment fragment) {
        C0001Op c0001Op = new C0001Op();
        c0001Op.f1cmd = 5;
        c0001Op.fragment = fragment;
        addOp(c0001Op);
        return this;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(NotificationCompat.FLAG_HIGH_PRIORITY);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.mIndex >= 0) {
            sb.append(" #");
            sb.append(this.mIndex);
        }
        if (this.mName != null) {
            sb.append(" ");
            sb.append(this.mName);
        }
        sb.append("}");
        return sb.toString();
    }

    void trackAddedFragmentsInPop(ArrayList<Fragment> arrayList) {
        int i = 0;
        while (true) {
            int i2 = i;
            if (i2 >= this.mOps.size()) {
                return;
            }
            C0001Op c0001Op = this.mOps.get(i2);
            switch (c0001Op.f1cmd) {
                case 1:
                case OP_ATTACH:
                    arrayList.remove(c0001Op.fragment);
                    break;
                case 3:
                case 6:
                    arrayList.add(c0001Op.fragment);
                    break;
            }
            i = i2 + 1;
        }
    }
}
