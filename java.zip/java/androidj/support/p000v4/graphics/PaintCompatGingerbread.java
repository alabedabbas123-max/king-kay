package androidj.support.p000v4.graphics;

import android.graphics.Paint;
import android.graphics.Rect;
import androidj.support.annotation.NonNull;
import androidj.support.annotation.RequiresApi;
import androidj.support.v4.util.Pair;

@RequiresApi(9)
class PaintCompatGingerbread {
    private static final String TOFU_STRING = "\udfffd";
    private static final ThreadLocal<Pair<Rect, Rect>> sRectThreadLocal = new ThreadLocal<>();

    PaintCompatGingerbread() {
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x004a, code lost:
    
        if (r6 < r3) goto L19;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    static boolean hasGlyph(@NonNull Paint paint, @NonNull String str) {
        float fMeasureText = 0.0f;
        int length = str.length();
        if (length == 1 && Character.isWhitespace(str.charAt(0))) {
            return true;
        }
        float fMeasureText2 = paint.measureText(TOFU_STRING);
        float fMeasureText3 = paint.measureText(str);
        if (fMeasureText3 != 0.0f) {
            if (str.codePointCount(0, str.length()) > 1) {
                if (fMeasureText3 <= 2.0f * fMeasureText2) {
                    int i = 0;
                    while (i < length) {
                        int iCharCount = Character.charCount(str.codePointAt(i));
                        fMeasureText += paint.measureText(str, i, i + iCharCount);
                        i += iCharCount;
                    }
                }
            }
            if (fMeasureText3 != fMeasureText2) {
                return true;
            }
            Pair<Rect, Rect> pairObtainEmptyRects = obtainEmptyRects();
            paint.getTextBounds(TOFU_STRING, 0, TOFU_STRING.length(), (Rect) pairObtainEmptyRects.first);
            paint.getTextBounds(str, 0, length, (Rect) pairObtainEmptyRects.second);
            return !((Rect) pairObtainEmptyRects.first).equals(pairObtainEmptyRects.second);
        }
        return false;
    }

    private static Pair<Rect, Rect> obtainEmptyRects() {
        Pair<Rect, Rect> pair = sRectThreadLocal.get();
        if (pair == null) {
            Pair<Rect, Rect> pair2 = new Pair<>(new Rect(), new Rect());
            sRectThreadLocal.set(pair2);
            return pair2;
        }
        ((Rect) pair.first).setEmpty();
        ((Rect) pair.second).setEmpty();
        return pair;
    }
}
