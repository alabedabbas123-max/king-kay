package androidj.support.p000v4.graphics.drawable;

import android.graphics.drawable.Drawable;
import androidj.support.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public interface DrawableWrapper {
    Drawable getWrappedDrawable();

    void setWrappedDrawable(Drawable drawable);
}
