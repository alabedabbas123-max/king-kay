package androidj.support.p000v4.graphics.drawable;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import androidj.support.annotation.Nullable;
import androidj.support.v4.graphics.drawable.DrawableWrapperLollipop;

public class C0006xe91398cb extends DrawableWrapperGingerbread.DrawableWrapperState {
    C0006xe91398cb(@Nullable DrawableWrapperGingerbread.DrawableWrapperState drawableWrapperState, @Nullable Resources resources) {
        super(drawableWrapperState, resources);
    }

    @Override
    public Drawable newDrawable(@Nullable Resources resources) {
        return new DrawableWrapperLollipop(this, resources);
    }
}
