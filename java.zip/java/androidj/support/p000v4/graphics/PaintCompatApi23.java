package androidj.support.p000v4.graphics;

import android.graphics.Paint;
import androidj.support.annotation.NonNull;
import androidj.support.annotation.RequiresApi;

@RequiresApi(23)
class PaintCompatApi23 {
    PaintCompatApi23() {
    }

    static boolean hasGlyph(@NonNull Paint paint, @NonNull String str) {
        return paint.hasGlyph(str);
    }
}
