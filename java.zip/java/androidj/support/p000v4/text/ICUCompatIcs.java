package androidj.support.p000v4.text;

import android.annotation.TargetApi;
import android.util.Log;
import androidj.support.annotation.RequiresApi;
import androidj.support.p000v4.view.MotionEventCompat;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

@TargetApi(MotionEventCompat.AXIS_RZ)
@RequiresApi(MotionEventCompat.AXIS_RZ)
class ICUCompatIcs {

    private static final String f9TAG = "ICUCompatIcs";
    private static Method sAddLikelySubtagsMethod;
    private static Method sGetScriptMethod;

    static {
        try {
            Class<?> cls = Class.forName("libcore.icu.ICU");
            if (cls != null) {
                sGetScriptMethod = cls.getMethod("getScript", String.class);
                sAddLikelySubtagsMethod = cls.getMethod("addLikelySubtags", String.class);
            }
        } catch (Exception e) {
            sGetScriptMethod = null;
            sAddLikelySubtagsMethod = null;
            Log.w(f9TAG, e);
        }
    }

    ICUCompatIcs() {
    }

    private static String addLikelySubtags(Locale locale) {
        String string = locale.toString();
        try {
            if (sAddLikelySubtagsMethod != null) {
                return (String) sAddLikelySubtagsMethod.invoke(null, string);
            }
        } catch (IllegalAccessException e) {
            Log.w(f9TAG, e);
        } catch (InvocationTargetException e2) {
            Log.w(f9TAG, e2);
        }
        return string;
    }

    private static String getScript(String str) {
        try {
            if (sGetScriptMethod != null) {
                return (String) sGetScriptMethod.invoke(null, str);
            }
        } catch (IllegalAccessException e) {
            Log.w(f9TAG, e);
        } catch (InvocationTargetException e2) {
            Log.w(f9TAG, e2);
        }
        return null;
    }

    public static String maximizeAndGetScript(Locale locale) {
        String strAddLikelySubtags = addLikelySubtags(locale);
        if (strAddLikelySubtags != null) {
            return getScript(strAddLikelySubtags);
        }
        return null;
    }
}
