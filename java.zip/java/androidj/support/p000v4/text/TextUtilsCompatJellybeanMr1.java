package androidj.support.p000v4.text;

import android.annotation.TargetApi;
import android.text.TextUtils;
import androidj.support.annotation.NonNull;
import androidj.support.annotation.Nullable;
import androidj.support.annotation.RequiresApi;
import androidj.support.p000v4.view.MotionEventCompat;
import java.util.Locale;

@TargetApi(MotionEventCompat.AXIS_LTRIGGER)
@RequiresApi(MotionEventCompat.AXIS_LTRIGGER)
class TextUtilsCompatJellybeanMr1 {
    TextUtilsCompatJellybeanMr1() {
    }

    public static int getLayoutDirectionFromLocale(@Nullable Locale locale) {
        return TextUtils.getLayoutDirectionFromLocale(locale);
    }

    @NonNull
    public static String htmlEncode(@NonNull String str) {
        return TextUtils.htmlEncode(str);
    }
}
