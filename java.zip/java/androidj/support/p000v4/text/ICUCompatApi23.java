package androidj.support.p000v4.text;

import android.annotation.TargetApi;
import android.util.Log;
import androidj.support.annotation.RequiresApi;
import androidj.support.p000v4.view.MotionEventCompat;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Locale;

@TargetApi(MotionEventCompat.AXIS_BRAKE)
@RequiresApi(MotionEventCompat.AXIS_BRAKE)
class ICUCompatApi23 {

    private static final String f8TAG = "ICUCompatIcs";
    private static Method sAddLikelySubtagsMethod;

    static {
        try {
            sAddLikelySubtagsMethod = Class.forName("libcore.icu.ICU").getMethod("addLikelySubtags", Locale.class);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    ICUCompatApi23() {
    }

    public static String maximizeAndGetScript(Locale locale) {
        try {
            return ((Locale) sAddLikelySubtagsMethod.invoke(null, locale)).getScript();
        } catch (IllegalAccessException e) {
            Log.w(f8TAG, e);
            return locale.getScript();
        } catch (InvocationTargetException e2) {
            Log.w(f8TAG, e2);
            return locale.getScript();
        }
    }
}
