package androidj.support.p000v4.print;

import android.annotation.TargetApi;
import android.content.Context;
import android.print.PrintAttributes;
import androidj.support.annotation.RequiresApi;
import androidj.support.p000v4.view.MotionEventCompat;
import androidj.support.v4.print.PrintHelperApi20;

@TargetApi(MotionEventCompat.AXIS_BRAKE)
@RequiresApi(MotionEventCompat.AXIS_BRAKE)
class PrintHelperApi23 extends PrintHelperApi20 {
    PrintHelperApi23(Context context) {
        super(context);
        this.mIsMinMarginsHandlingCorrect = false;
    }

    protected PrintAttributes.Builder copyAttributes(PrintAttributes printAttributes) {
        PrintAttributes.Builder builderCopyAttributes = super.copyAttributes(printAttributes);
        if (printAttributes.getDuplexMode() != 0) {
            builderCopyAttributes.setDuplexMode(printAttributes.getDuplexMode());
        }
        return builderCopyAttributes;
    }
}
