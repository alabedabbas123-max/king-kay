package androidj.support.p000v4.print;

import android.annotation.TargetApi;
import android.content.Context;
import androidj.support.annotation.RequiresApi;
import androidj.support.v4.print.PrintHelperKitkat;

@TargetApi(20)
@RequiresApi(20)
class PrintHelperApi20 extends PrintHelperKitkat {
    PrintHelperApi20(Context context) {
        super(context);
        this.mPrintActivityRespectsOrientation = false;
    }
}
