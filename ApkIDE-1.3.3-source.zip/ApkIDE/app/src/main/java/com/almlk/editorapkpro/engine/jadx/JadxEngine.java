package com.almlk.editorapkpro.engine.jadx;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.util.FileUtil;
import com.almlk.editorapkpro.util.Prefs;

import jadx.api.DecompilationMode;
import jadx.api.JadxArgs;
import jadx.api.JadxDecompiler;
import jadx.api.args.GeneratedRenamesMappingFileMode;
import jadx.api.args.ResourceNameSource;
import jadx.api.impl.NoOpCodeCache;
import jadx.api.usage.impl.EmptyUsageInfoCache;
import jadx.core.xmlgen.XmlSecurity;

import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

/**
 * الطبقة الحقيقية فوق jadx-core: تحويل DEX إلى Java مع إزالة التشويش
 * والحفاظ الكامل على أسماء الموارد ومعرّفاتها (R.id.* / R.layout.* ...).
 */
public class JadxEngine {

    private final Logger log;

    public JadxEngine(Logger log) { this.log = log; }

    public interface Progress { void on(long done, long total); }

    /** خيارات الفك القابلة للضبط من واجهة الإعدادات. */
    public static class Options {
        public boolean deobfuscation   = Prefs.deobfuscation();
        public boolean kotlinAware     = Prefs.decompileKotlin();
        public boolean preserveResIds  = Prefs.keepResIds();
        public boolean skipResources   = true;   // الموارد نأخذها من apktool (أدق بكثير)
        public boolean showInconsistentCode = true;
        public boolean inlineAnonymous = true;
        public boolean lowMemoryMode   = false;
        public int     threads         = Prefs.threads();
        public File    deobfMapFile    = null;   // mapping.txt من proguard إن توفر

        Options lowMemoryCopy(){
            Options x=new Options();
            x.deobfuscation=false;x.kotlinAware=kotlinAware;x.preserveResIds=preserveResIds;
            x.skipResources=true;x.showInconsistentCode=false;x.inlineAnonymous=false;
            x.lowMemoryMode=true;x.threads=1;x.deobfMapFile=null;
            return x;
        }
    }

    /**
     * يفك ملفات classes*.dex واحداً تلو الآخر. بهذه الطريقة لا يبني Jadx شجرة
     * استخدام لكل DEX في التطبيق داخل heap واحد، ولا يقرأ assets الضخمة من APK.
     */
    public void decompileDexDirectory(File dexDir, File srcOut, File resOut,
                                      Options o, Progress p) throws Exception {
        File[] dexFiles=dexDir.listFiles((d,n)->n.matches("classes(\\d*)?\\.dex"));
        if(dexFiles==null||dexFiles.length==0)
            throw new IllegalStateException("لم يعثر Jadx على classes*.dex بعد فك Apktool");
        Arrays.sort(dexFiles,Comparator.comparingInt(JadxEngine::dexIndex));
        log.i("jadx: وضع DEX المتسلسل منخفض الذاكرة — "+dexFiles.length+" ملف");
        for(int i=0;i<dexFiles.length;i++){
            File dex=dexFiles[i];
            final int part=i;
            final int count=dexFiles.length;
            log.i("jadx: معالجة "+dex.getName()+" ("+(i+1)+"/"+count+")");

            long heap=Runtime.getRuntime().maxMemory();
            boolean constrainedHeap=heap<=768L*1024L*1024L;
            boolean highPressure=dex.length()>=1536L*1024L&&constrainedHeap;
            int shardClasses=heap<=576L*1024L*1024L?420:700;
            File shardDir=null;
            List<File> units=Collections.singletonList(dex);
            if(highPressure){
                // لا يكفي فصل classes.dex عن classes2.dex إذا كان الملف الواحد نفسه
                // ضخماً؛ شظايا 420 صنفاً تحت heap 512MB تمنع تكرار OOM في SaveCode.
                shardDir=new File(resOut,"dex-shards-"+dex.getName());
                units=DexShardSplitter.split(dex,shardDir,shardClasses,log);
                System.gc();System.runFinalization();
            }
            Options effective=(highPressure||heap<=576L*1024L*1024L)?o.lowMemoryCopy():o;
            if(highPressure)
                log.i("jadx: "+dex.getName()+" كبير؛ الوضع الاقتصادي مع شظايا متسلسلة حدها "+shardClasses);
            try{
                final int unitCount=units.size();
                for(int u=0;u<unitCount;u++){
                    File unit=units.get(u);
                    final int unitPart=u;
                    Progress localProgress=(done,total)->{
                        if(p==null)return;
                        long slice=1000L;
                        long inUnit=total>0?Math.min(slice,done*slice/total):0;
                        long inDex=(unitPart*slice+inUnit)/unitCount;
                        p.on(part*slice+inDex,count*slice);
                    };
                    if(unitCount>1)log.i("jadx: شظية "+(u+1)+"/"+unitCount+" من "+dex.getName());
                    decompileAdaptive(unit,srcOut,resOut,effective,localProgress,0);
                    System.gc();System.runFinalization();
                }
            }finally{
                if(shardDir!=null)FileUtil.delete(shardDir);
            }
            if(p!=null)p.on((i+1)*1000L,count*1000L);
            System.gc();
            System.runFinalization();
        }
        log.i("jadx: اكتمل فك كل ملفات DEX بالتتابع");
    }

    /**
     * يعيد المحاولة تلقائياً بشظايا أدق عند OOM. لا يعلن النجاح إذا فشلت أصغر
     * شظية؛ عندها يصعد OOM إلى Engine وتُحذف نتيجة المشروع الجزئية.
     */
    private void decompileAdaptive(File input,File srcOut,File resOut,Options options,
                                   Progress progress,int depth)throws Exception{
        try{
            decompile(input,srcOut,resOut,options,progress);
            return;
        }catch(OutOfMemoryError oom){
            System.gc();System.runFinalization();
            if(!options.lowMemoryMode){
                log.w("jadx: ضغط ذاكرة؛ إعادة "+input.getName()+" بالوضع الاقتصادي");
                decompileAdaptive(input,srcOut,resOut,options.lowMemoryCopy(),progress,depth);
                return;
            }
            if(depth>=2)throw oom;
            int limit=depth==0?96:32;
            File retryDir=new File(resOut,"oom-retry-"+depth+"-"+
                    FileUtil.nameNoExt(input.getName()));
            List<File> smaller=null;
            try{
                smaller=DexShardSplitter.split(input,retryDir,limit,log);
                if(smaller.size()<=1)throw oom;
                log.w("jadx: OOM في شظية؛ إعادة المحاولة كـ "+smaller.size()+
                        " شظايا أدق (حد "+limit+" صنفاً)");
                for(File part:smaller){
                    decompileAdaptive(part,srcOut,resOut,options,null,depth+1);
                    System.gc();System.runFinalization();
                }
                if(progress!=null)progress.on(1,1);
            }finally{
                FileUtil.delete(retryDir);
            }
        }
    }

    /** يفك ملف APK/DEX/JAR واحداً إلى شيفرة Java. */
    public void decompile(File input, File srcOut, File resOut, Options o, Progress p)
            throws Exception {

        log.i("jadx: بدء فك " + input.getName() + " (" + input.length() / 1024 + " KB)");
        if(!XmlSecurity.ANDROID_COMPATIBLE||XmlSecurity.getDBF().newDocumentBuilder()==null)
            throw new IllegalStateException("Jadx XmlSecurity غير متوافق مع Android");
        log.i("jadx: XmlSecurity Android-compatible جاهز");
        srcOut.mkdirs();

        JadxArgs args = new JadxArgs();
        // لا تحتفظ بكل نصوص Java ولا بنسخة ثانية من رسم الاستخدام في الذاكرة.
        // save() يكتب كل صنف فوراً؛ وهذا خفّض ذروة DEX الكبير مئات الميغابايت.
        args.setCodeCache(NoOpCodeCache.INSTANCE);
        args.setUsageInfoCache(new EmptyUsageInfoCache());
        // تحميل Dex plugin المطلوب فقط؛ يمنع ServiceLoader من تهيئة smali-input غير اللازم.
        args.setPluginLoader(new AndroidJadxPluginLoader());
        args.getInputFiles().add(input);
        args.setOutDir(srcOut.getParentFile() != null ? srcOut.getParentFile() : srcOut);
        args.setOutDirSrc(srcOut);
        args.setOutDirRes(resOut);

        // Jadx متعطش للذاكرة؛ على Android يكون الثبات أهم من التوازي. APK الكبير
        // يعمل بخيط واحد، وبقية الملفات بخيطين كحد أقصى حتى مع اختيار قيمة أعلى.
        long maxHeap=Runtime.getRuntime().maxMemory();
        boolean rawDex=input.getName().toLowerCase(java.util.Locale.ROOT).endsWith(".dex");
        int safeCap=(rawDex||input.length()>=35L*1024L*1024L
                ||maxHeap<384L*1024L*1024L)?1:2;
        int safeThreads=Math.max(1,Math.min(o.threads,safeCap));
        args.setThreadsCount(safeThreads);
        log.i("jadx: Android safe mode — dex-input فقط، خيوط="+safeThreads
                +"، heap="+(maxHeap/1024/1024)+"MB"
                +(o.lowMemoryMode?"، اقتصادي":""));
        args.setSkipResources(o.skipResources);
        args.setSkipSources(false);
        args.setShowInconsistentCode(o.showInconsistentCode);
        args.setInlineAnonymousClasses(o.inlineAnonymous&&!o.lowMemoryMode);
        args.setInlineMethods(!o.lowMemoryMode);
        args.setReplaceConsts(!o.lowMemoryMode);
        args.setAllowInlineKotlinLambda(!o.lowMemoryMode);
        args.setMoveInnerClasses(!o.lowMemoryMode);
        args.setExtractFinally(!o.lowMemoryMode);
        args.setUseImports(!o.lowMemoryMode);
        args.setDebugInfo(!o.lowMemoryMode);
        if(o.lowMemoryMode)args.setDecompilationMode(DecompilationMode.SIMPLE);
        args.setRespectBytecodeAccModifiers(false);
        args.setFsCaseSensitive(true);
        args.setEscapeUnicode(false);
        args.setCommentsLevel(jadx.api.CommentsLevel.WARN);

        /* ---------- إزالة التشويش (De-obfuscation) ---------- */
        args.setDeobfuscationOn(o.deobfuscation);
        if (o.deobfuscation) {
            args.setDeobfuscationMinLength(3);      // a, ab -> يعاد تسميتها
            args.setDeobfuscationMaxLength(64);
            args.setUseSourceNameAsClassAlias(true); // استخدم SourceFile للأسماء الأصلية
            args.setRenameValid(true);
            args.setRenamePrintable(true);
            // حفظ خريطة إعادة التسمية بجانب المشروع ليمكن تعديلها لاحقاً
            args.setGeneratedRenamesMappingFileMode(GeneratedRenamesMappingFileMode.OVERWRITE);
            if (o.deobfMapFile != null && o.deobfMapFile.exists()) {
                args.setGeneratedRenamesMappingFile(o.deobfMapFile);
                args.setGeneratedRenamesMappingFileMode(GeneratedRenamesMappingFileMode.READ);
                log.i("jadx: استخدام خريطة إزالة التشويش " + o.deobfMapFile.getName());
            }
        }

        /* ---------- الحفاظ على معرّفات الموارد R.id.* ---------- */
        if (o.preserveResIds) {
            // لا تعيد تسمية أي شيء مرتبط بالموارد: احتفظ بالأسماء كما في ملف arsc
            args.setResourceNameSource(ResourceNameSource.AUTO);
            args.setRenameFlags(EnumSet.noneOf(JadxArgs.RenameEnum.class));
            log.i("jadx: وضع الحفاظ على معرّفات الموارد مفعّل (R.id / R.layout ثابتة)");
        }

        if (o.kotlinAware) {
            args.setUseKotlinMethodsForVarNames(JadxArgs.UseKotlinMethodsForVarNames.APPLY);
        }

        try (JadxDecompiler jadx = new JadxDecompiler(args)) {
            jadx.load();
            int classes = jadx.getClasses().size();
            log.i("jadx: تم تحميل " + classes + " صنف");
            // Jadx يشغّل الحفظ في عامل داخلي؛ في بعض JVMs لا يعيد OOM للعامل
            // إلى save() بل يطبعه ويكمل بمشروع ناقص. التقطه وحوّله إلى OOM حقيقي
            // كي تعمل إعادة المحاولة الاقتصادية ولا يختفي نصف الكلاسات.
            AtomicReference<OutOfMemoryError> workerOom=new AtomicReference<>();
            Thread.UncaughtExceptionHandler previous=Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler((thread,error)->{
                if(error instanceof OutOfMemoryError&&thread.getName().contains("pool"))
                    workerOom.compareAndSet(null,(OutOfMemoryError)error);
                else if(previous!=null)previous.uncaughtException(thread,error);
            });
            try{
                if (p != null) {
                    jadx.save(400, (done, total) -> p.on(done, total));
                } else {
                    jadx.save();
                }
            }finally{
                Thread.setDefaultUncaughtExceptionHandler(previous);
            }
            if(workerOom.get()!=null)throw workerOom.get();
            int errors = jadx.getErrorsCount();
            if (errors > 0) log.w("jadx: " + errors + " صنف فُكّ بشكل جزئي (سيظهر كتعليق داخل الملف)");
            log.i("jadx: اكتمل الفك إلى " + srcOut.getAbsolutePath());
        }
    }

    private static int dexIndex(File f){
        String n=f.getName();
        if(n.equals("classes.dex"))return 1;
        try{return Integer.parseInt(n.substring(7,n.length()-4));}
        catch(Exception ignored){return Integer.MAX_VALUE;}
    }
}
