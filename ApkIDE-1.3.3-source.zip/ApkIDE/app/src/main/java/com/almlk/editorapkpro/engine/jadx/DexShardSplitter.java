package com.almlk.editorapkpro.engine.jadx;

import com.almlk.editorapkpro.engine.Logger;
import com.almlk.editorapkpro.util.FileUtil;
import com.android.tools.smali.dexlib2.DexFileFactory;
import com.android.tools.smali.dexlib2.Opcodes;
import com.android.tools.smali.dexlib2.iface.ClassDef;
import com.android.tools.smali.dexlib2.dexbacked.DexBackedDexFile;
import com.android.tools.smali.dexlib2.writer.io.FileDataStore;
import com.android.tools.smali.dexlib2.writer.pool.DexPool;

import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * يقسم DEX الكبير مؤقتاً حسب الأصناف قبل Jadx. الفصل بين classes*.dex وحده لا
 * يكفي إذا احتوى DEX واحد عشرة آلاف صنف؛ الشظايا تمنع بناء رسم/نصوص كل هذه
 * الأصناف داخل heap ذي 512MB. الملفات الأصلية لا تتغير وتُحذف الشظايا بعد الفك.
 */
public final class DexShardSplitter {
    private DexShardSplitter(){}

    public static List<File> split(File input,File outDir,int maxClasses,Logger log)throws Exception{
        FileUtil.delete(outDir);
        outDir.mkdirs();
        Opcodes opcodes=Opcodes.getDefault();
        DexBackedDexFile dex=DexFileFactory.loadDexFile(input,opcodes);
        List<ClassDef> classes=new ArrayList<>(dex.getClasses());
        classes.sort(Comparator.comparing(ClassDef::getType));
        List<File> result=new ArrayList<>();
        int at=0,part=1;
        while(at<classes.size()){
            int end=Math.min(classes.size(),at+Math.max(32,maxClasses));
            // لا تفصل Outer وOuter$Inner عند حد الشظية.
            if(end<classes.size()){
                String family=family(classes.get(end-1).getType());
                while(end<classes.size()&&family(classes.get(end).getType()).equals(family))end++;
            }
            DexPool pool=new DexPool(dex.getOpcodes());
            for(int i=at;i<end;i++)pool.internClass(classes.get(i));
            File shard=new File(outDir,String.format(java.util.Locale.US,"shard%03d.dex",part++));
            FileDataStore store=new FileDataStore(shard);
            try{pool.writeTo(store);}finally{store.close();}
            if(!shard.isFile()||shard.length()==0)
                throw new IllegalStateException("تعذّر إنشاء شظية DEX منخفضة الذاكرة");
            result.add(shard);
            pool=null;
            System.gc();
            at=end;
        }
        if(log!=null)log.i("jadx: قُسّم "+input.getName()+" مؤقتاً إلى "+result.size()
                +" شظية ("+classes.size()+" صنفاً، حد "+maxClasses+")");
        return result;
    }

    private static String family(String type){
        int dollar=type.indexOf('$');
        return dollar<0?type:type.substring(0,dollar);
    }
}
