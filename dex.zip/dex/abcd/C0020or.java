package abcd;

class C0020or implements d<Vp> {

    final xr f360j6;

    C0020or(xr xrVar) {
        this.f360j6 = xrVar;
    }

    public Vp m73j6(Vp vp, yr yrVar) {
        return yrVar.j6(vp);
    }

    public void m75j6(hr.a aVar, Vp vp, int i, int i2, yr yrVar) {
        yrVar.DW(i, i2);
        vp.j6(aVar);
    }
}
