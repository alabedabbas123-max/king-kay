package abcd;

import android.content.res.Resources;
import io.fabric.sdk.android.Fabric;
import io.fabric.sdk.android.Kit;
import io.fabric.sdk.android.l;
import io.fabric.sdk.android.services.common.A;
import io.fabric.sdk.android.services.common.a;
import io.fabric.sdk.android.services.common.i;
import java.io.InputStream;
import java.util.Collection;
import java.util.Locale;

abstract class AbstractC0098Sz extends a implements Xz {
    public AbstractC0098Sz(Kit kit, String str, String str2, Jz jz, Fz fz) {
        super(kit, str, str2, jz, fz);
    }

    private Hz m666DW(Hz hz, Vz vz) {
        hz.v5("app[identifier]", vz.DW);
        hz.v5("app[name]", vz.Zo);
        hz.v5("app[display_version]", vz.FH);
        hz.v5("app[build_version]", vz.Hw);
        hz.j6("app[source]", Integer.valueOf(vz.VH));
        hz.v5("app[minimum_sdk_version]", vz.gn);
        hz.v5("app[built_sdk_version]", vz.u7);
        if (!i.DW(vz.v5)) {
            hz.v5("app[instance_identifier]", vz.v5);
        }
        if (vz.tp != null) {
            InputStream inputStreamOpenRawResource = null;
            try {
                try {
                    inputStreamOpenRawResource = ((a) this).Zo.getContext().getResources().openRawResource(vz.tp.DW);
                    hz.v5("app[icon][hash]", vz.tp.j6);
                    hz.j6("app[icon][data]", "icon.png", "application/octet-stream", inputStreamOpenRawResource);
                    hz.j6("app[icon][width]", Integer.valueOf(vz.tp.FH));
                    hz.j6("app[icon][height]", Integer.valueOf(vz.tp.Hw));
                } catch (Resources.NotFoundException e) {
                    Fabric.getLogger().FH("Fabric", "Failed to find app icon with resource ID: " + vz.tp.DW, e);
                }
                i.j6(inputStreamOpenRawResource, "Failed to close app icon InputStream.");
            } catch (Throwable th) {
                i.j6(inputStreamOpenRawResource, "Failed to close app icon InputStream.");
                throw th;
            }
        }
        Collection<l> collection = vz.EQ;
        if (collection != null) {
            for (l lVar : collection) {
                hz.v5(m668DW(lVar), lVar.FH());
                hz.v5(m669j6(lVar), lVar.j6());
            }
        }
        return hz;
    }

    private Hz m667j6(Hz hz, Vz vz) {
        hz.FH("X-CRASHLYTICS-API-KEY", vz.j6);
        hz.FH("X-CRASHLYTICS-API-CLIENT-TYPE", "android");
        hz.FH("X-CRASHLYTICS-API-CLIENT-VERSION", ((a) this).Zo.getVersion());
        return hz;
    }

    String m668DW(l lVar) {
        return String.format(Locale.US, "app[build][libraries][%s][version]", lVar.DW());
    }

    String m669j6(l lVar) {
        return String.format(Locale.US, "app[build][libraries][%s][type]", lVar.DW());
    }

    public boolean m670j6(Vz vz) {
        Hz hzJ6 = j6();
        m667j6(hzJ6, vz);
        m666DW(hzJ6, vz);
        Fabric.getLogger().Hw("Fabric", "Sending app info to " + DW());
        if (vz.tp != null) {
            Fabric.getLogger().Hw("Fabric", "App icon hash is " + vz.tp.j6);
            Fabric.getLogger().Hw("Fabric", "App icon size is " + vz.tp.FH + "x" + vz.tp.Hw);
        }
        int iVH = hzJ6.VH();
        String str = "POST".equals(hzJ6.EQ()) ? "Create" : "Update";
        Fabric.getLogger().Hw("Fabric", str + " app request ID: " + hzJ6.Hw("X-REQUEST-ID"));
        Fabric.getLogger().Hw("Fabric", "Result was " + iVH);
        return A.j6(iVH) == 0;
    }
}
