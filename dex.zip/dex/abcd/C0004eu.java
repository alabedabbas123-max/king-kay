package abcd;

public final class C0004eu {
    public static int m13DW(St st) throws Ut {
        int i;
        int i2 = 0;
        int i3 = 0;
        do {
            int i4 = st.readByte() & 255;
            i2 |= (i4 & 127) << (i3 * 7);
            i3++;
            i = i4 & 128;
            if (i != 128) {
                break;
            }
        } while (i3 < 5);
        if (i != 128) {
            return i2;
        }
        throw new Ut("invalid LEB128 sequence");
    }

    public static void m14DW(Tt tt, int i) {
        while (true) {
            int i2 = i;
            i >>>= 7;
            if (i == 0) {
                tt.writeByte((byte) (i2 & 127));
                return;
            }
            tt.writeByte((byte) ((i2 & 127) | 128));
        }
    }

    public static int m15j6(int i) {
        int i2 = i >> 7;
        int i3 = 0;
        while (i2 != 0) {
            i2 >>= 7;
            i3++;
        }
        return i3 + 1;
    }

    public static int m16j6(St st) throws Ut {
        int i;
        int i2 = 0;
        int i3 = 0;
        int i4 = -1;
        do {
            int i5 = st.readByte() & 255;
            i2 |= (i5 & 127) << (i3 * 7);
            i4 <<= 7;
            i3++;
            i = i5 & 128;
            if (i != 128) {
                break;
            }
        } while (i3 < 5);
        if (i != 128) {
            return ((i4 >> 1) & i2) != 0 ? i2 | i4 : i2;
        }
        throw new Ut("invalid LEB128 sequence");
    }

    public static void m17j6(Tt tt, int i) {
        int i2 = i >> 7;
        int i3 = (Integer.MIN_VALUE & i) == 0 ? 0 : -1;
        int i4 = i;
        boolean z = true;
        while (z) {
            z = (i2 == i3 && (i2 & 1) == ((i4 >> 6) & 1)) ? false : true;
            tt.writeByte((byte) ((i4 & 127) | (z ? 128 : 0)));
            i4 = i2;
            i2 >>= 7;
        }
    }
}
