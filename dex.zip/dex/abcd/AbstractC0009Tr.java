package abcd;

public abstract class AbstractC0009Tr implements lu {

    private final hs f21DW;

    private final bs f22FH;

    private final cs f23Hw;

    private final es f24j6;

    public static class a implements b {
        @Override
        public void mo65j6(Sr sr) {
        }

        @Override
        public void mo66j6(Zr zr) {
        }

        @Override
        public void mo67j6(is isVar) {
        }

        @Override
        public void mo68j6(js jsVar) {
        }

        @Override
        public void mo69j6(ks ksVar) {
        }
    }

    public interface b {
        void mo65j6(Sr sr);

        void m70j6(Yr yr);

        void mo66j6(Zr zr);

        void mo67j6(is isVar);

        void mo68j6(js jsVar);

        void mo69j6(ks ksVar);
    }

    public AbstractC0009Tr(es esVar, hs hsVar, bs bsVar, cs csVar) {
        if (esVar == null) {
            throw new NullPointerException("opcode == null");
        }
        if (hsVar == null) {
            throw new NullPointerException("position == null");
        }
        if (csVar == null) {
            throw new NullPointerException("sources == null");
        }
        this.f24j6 = esVar;
        this.f21DW = hsVar;
        this.f22FH = bsVar;
        this.f23Hw = csVar;
    }

    private static boolean m48j6(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    public abstract Ss m49DW();

    protected final String m50DW(String str) {
        StringBuffer stringBuffer = new StringBuffer(80);
        stringBuffer.append("Insn{");
        stringBuffer.append(this.f21DW);
        stringBuffer.append(' ');
        stringBuffer.append(this.f24j6);
        if (str != null) {
            stringBuffer.append(' ');
            stringBuffer.append(str);
        }
        stringBuffer.append(" :: ");
        bs bsVar = this.f22FH;
        if (bsVar != null) {
            stringBuffer.append(bsVar);
            stringBuffer.append(" <- ");
        }
        stringBuffer.append(this.f23Hw);
        stringBuffer.append('}');
        return stringBuffer.toString();
    }

    public String m51FH() {
        return null;
    }

    public final bs m52Hw() {
        bs bsVar = this.f24j6.Hw() == 54 ? this.f23Hw.get(0) : this.f22FH;
        if (bsVar == null || bsVar.Zo() == null) {
            return null;
        }
        return bsVar;
    }

    public final bs m53VH() {
        return this.f22FH;
    }

    public final hs m54Zo() {
        return this.f21DW;
    }

    public String m55aM() {
        return m59j6(m51FH());
    }

    public final boolean equals(Object obj) {
        return this == obj;
    }

    public final cs m56gn() {
        return this.f23Hw;
    }

    public final int hashCode() {
        return System.identityHashCode(this);
    }

    public abstract AbstractC0009Tr m57j6(Qs qs);

    public abstract AbstractC0009Tr m58j6(bs bsVar, cs csVar);

    protected final String m59j6(String str) {
        StringBuffer stringBuffer = new StringBuffer(80);
        stringBuffer.append(this.f21DW);
        stringBuffer.append(": ");
        stringBuffer.append(this.f24j6.FH());
        if (str != null) {
            stringBuffer.append("(");
            stringBuffer.append(str);
            stringBuffer.append(")");
        }
        if (this.f22FH == null) {
            stringBuffer.append(" .");
        } else {
            stringBuffer.append(" ");
            stringBuffer.append(this.f22FH.aM());
        }
        stringBuffer.append(" <-");
        int size = this.f23Hw.size();
        if (size == 0) {
            stringBuffer.append(" .");
        } else {
            for (int i = 0; i < size; i++) {
                stringBuffer.append(" ");
                stringBuffer.append(this.f23Hw.get(i).aM());
            }
        }
        return stringBuffer.toString();
    }

    public abstract void m60j6(b bVar);

    public final boolean m61j6() {
        return this.f24j6.j6();
    }

    public boolean m62j6(AbstractC0009Tr abstractC0009Tr) {
        return this.f24j6 == abstractC0009Tr.m64v5() && this.f21DW.equals(abstractC0009Tr.m54Zo()) && getClass() == abstractC0009Tr.getClass() && m48j6(this.f22FH, abstractC0009Tr.m53VH()) && m48j6(this.f23Hw, abstractC0009Tr.m56gn()) && Ps.DW(m49DW(), abstractC0009Tr.m49DW());
    }

    public String toString() {
        return m50DW(m51FH());
    }

    public AbstractC0009Tr m63u7() {
        return this;
    }

    public final es m64v5() {
        return this.f24j6;
    }
}
