package abcd;

import android.content.Context;

public class C0012Qy<T> extends Py<T> {

    private T f89DW;

    public C0012Qy() {
        this(null);
    }

    public C0012Qy(Ry<T> ry) {
        super(ry);
    }

    protected T m147j6(Context context) {
        return this.f89DW;
    }

    protected void m148j6(Context context, T t) {
        this.f89DW = t;
    }
}
