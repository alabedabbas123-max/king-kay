package abcd;

import android.content.SharedPreferences;
import com.appfour.backbone.api.Api;
import java.io.File;

public class C0018rw {
    private static void m158DW(String str, long j) {
        m164VH().edit().putLong(str, j).commit();
    }

    private static void m159DW(String str, boolean z) {
        m164VH().edit().putBoolean(str, z).commit();
    }

    public static boolean m160DW() {
        if (m166j6("last_run_version", -1L) == Api.getLastUpdateTime()) {
            return false;
        }
        m158DW("last_run_version", Api.getLastUpdateTime());
        return true;
    }

    public static boolean m161DW(lw lwVar) {
        return m170j6("is_event_defined_" + lwVar.DW(), false);
    }

    public static File m162FH() {
        return uw.j6(wu.j6(), "probesdex_" + Api.getProcessName());
    }

    public static boolean m163Hw() {
        return m170j6("has_fetched_referrer", false);
    }

    private static SharedPreferences m164VH() {
        return wu.j6().getSharedPreferences("BACKBONE_" + Api.getProcessName(), 0);
    }

    public static void m165Zo() {
        m159DW("has_fetched_referrer", true);
    }

    private static long m166j6(String str, long j) {
        return m164VH().getLong(str, j);
    }

    public static void m167j6(lw lwVar) {
        m159DW("is_event_defined_" + lwVar.DW(), true);
    }

    public static void m168j6(boolean z) {
        m159DW("is_developer", z);
    }

    public static boolean m169j6() {
        boolean zM170j6 = m170j6("is_first_run", true);
        if (zM170j6) {
            m159DW("is_first_run", false);
        }
        return zM170j6;
    }

    private static boolean m170j6(String str, boolean z) {
        return m164VH().getBoolean(str, z);
    }

    public static boolean m171v5() {
        return m170j6("is_developer", false);
    }
}
