package abcd;

public final class C0007us extends Cs {

    public static final C0007us f16DW = new C0007us(Double.doubleToLongBits(0.0d));

    public static final C0007us f17FH = new C0007us(Double.doubleToLongBits(1.0d));

    private C0007us(long j) {
        super(j);
    }

    public static C0007us m38j6(long j) {
        return new C0007us(j);
    }

    public String m39Zo() {
        return "double";
    }

    public String m40aM() {
        return Double.toString(Double.longBitsToDouble(lg()));
    }

    public Qs getType() {
        return Qs.v5;
    }

    public String toString() {
        long jLg = lg();
        return "double{0x" + Yt.DW(jLg) + " / " + Double.longBitsToDouble(jLg) + '}';
    }
}
