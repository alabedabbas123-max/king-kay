package abcd;

import java.util.BitSet;

public final class C0010Bo extends ao {

    public static final ao f48DW = new C0010Bo();

    private C0010Bo() {
    }

    public BitSet m49FH(Vn vn) {
        cs csVarGn = vn.gn();
        BitSet bitSet = new BitSet(1);
        bitSet.set(0, ao.Hw(csVarGn.get(0).we()));
        return bitSet;
    }

    public boolean m50VH(Vn vn) {
        cs csVarGn = vn.gn();
        if (!(vn instanceof po) || csVarGn.size() != 1 || !ao.Hw(csVarGn.get(0).we())) {
            return false;
        }
        po poVar = (po) vn;
        if (poVar.Ws()) {
            return m55j6(poVar);
        }
        return true;
    }

    public String m51Zo(Vn vn) {
        return vn.gn().get(0).lg() + ", " + ao.DW(vn);
    }

    public int m52j6() {
        return 2;
    }

    public String m53j6(Vn vn, boolean z) {
        return ao.j6(vn);
    }

    public void m54j6(Lt lt, Vn vn) {
        ao.j6(lt, ao.j6(vn, vn.gn().get(0).we()), (short) ((po) vn).J8());
    }

    public boolean m55j6(po poVar) {
        int iJ8 = poVar.J8();
        return iJ8 != 0 && ao.FH(iJ8);
    }
}
