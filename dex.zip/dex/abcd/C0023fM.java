package abcd;

import java.io.ByteArrayOutputStream;

public class C0023fM extends EL {

    private wL f113DW;

    private EL f114FH;

    private int f115Hw;

    private zL f116j6;

    private EL f117v5;

    public C0023fM(rL rLVar) {
        int i = 0;
        EL elM78j6 = m78j6(rLVar, 0);
        if (elM78j6 instanceof zL) {
            this.f116j6 = (zL) elM78j6;
            elM78j6 = m78j6(rLVar, 1);
            i = 1;
        }
        if (elM78j6 instanceof wL) {
            this.f113DW = (wL) elM78j6;
            i++;
            elM78j6 = m78j6(rLVar, i);
        }
        if (!(elM78j6 instanceof yM)) {
            this.f114FH = elM78j6;
            i++;
            elM78j6 = m78j6(rLVar, i);
        }
        if (rLVar.j6() != i + 1) {
            throw new IllegalArgumentException("input vector too large");
        }
        if (!(elM78j6 instanceof yM)) {
            throw new IllegalArgumentException("No tagged object found in vector. Structure doesn't seem to be of type External");
        }
        yM yMVar = (yM) elM78j6;
        m79j6(yMVar.tp());
        this.f117v5 = yMVar.u7();
    }

    private EL m78j6(rL rLVar, int i) {
        if (rLVar.j6() > i) {
            return rLVar.j6(i).DW();
        }
        throw new IllegalArgumentException("too few objects in input vector");
    }

    private void m79j6(int i) {
        if (i >= 0 && i <= 2) {
            this.f115Hw = i;
        } else {
            throw new IllegalArgumentException("invalid encoding value: " + i);
        }
    }

    public int m80EQ() {
        return this.f115Hw;
    }

    public wL m81J0() {
        return this.f113DW;
    }

    boolean m82Zo() {
        return true;
    }

    public int hashCode() {
        zL zLVar = this.f116j6;
        int iHashCode = zLVar != null ? zLVar.hashCode() : 0;
        wL wLVar = this.f113DW;
        if (wLVar != null) {
            iHashCode ^= wLVar.hashCode();
        }
        EL el = this.f114FH;
        if (el != null) {
            iHashCode ^= el.hashCode();
        }
        return iHashCode ^ this.f117v5.hashCode();
    }

    void m83j6(CL cl) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        zL zLVar = this.f116j6;
        if (zLVar != null) {
            byteArrayOutputStream.write(zLVar.j6("DER"));
        }
        wL wLVar = this.f113DW;
        if (wLVar != null) {
            byteArrayOutputStream.write(wLVar.j6("DER"));
        }
        EL el = this.f114FH;
        if (el != null) {
            byteArrayOutputStream.write(el.j6("DER"));
        }
        byteArrayOutputStream.write(new yM(true, this.f115Hw, this.f117v5).j6("DER"));
        cl.j6(32, 8, byteArrayOutputStream.toByteArray());
    }

    boolean m84j6(EL el) {
        EL el2;
        wL wLVar;
        zL zLVar;
        if (!(el instanceof C0023fM)) {
            return false;
        }
        if (this == el) {
            return true;
        }
        C0023fM c0023fM = (C0023fM) el;
        zL zLVar2 = this.f116j6;
        if (zLVar2 != null && ((zLVar = c0023fM.f116j6) == null || !zLVar.equals(zLVar2))) {
            return false;
        }
        wL wLVar2 = this.f113DW;
        if (wLVar2 != null && ((wLVar = c0023fM.f113DW) == null || !wLVar.equals(wLVar2))) {
            return false;
        }
        EL el3 = this.f114FH;
        if (el3 == null || ((el2 = c0023fM.f114FH) != null && el2.equals(el3))) {
            return this.f117v5.equals(c0023fM.f117v5);
        }
        return false;
    }

    public zL m85tp() {
        return this.f116j6;
    }

    public EL m86u7() {
        return this.f114FH;
    }

    int m87v5() {
        return Hw().length;
    }

    public EL m88we() {
        return this.f117v5;
    }
}
