package abcd;

enum C0005uq extends er {
    C0005uq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
