package abcd;

public abstract class AbstractC0009iG extends AE.a {

    int f41EQ;

    AbstractC0009iG(YD yd) {
        super(yd);
    }

    public final boolean m54DW(fG fGVar) {
        return (fGVar.Hw & this.f41EQ) != 0;
    }

    public abstract int m55aM();

    public final yE getId() {
        return this;
    }

    public final void m56j6(fG fGVar) {
        this.f41EQ = fGVar.Hw | this.f41EQ;
    }

    abstract void m57j6(qG qGVar);

    protected void m58j6(StringBuilder sb) {
        sb.append((this.f41EQ & 32) != 0 ? 'o' : '-');
        sb.append((this.f41EQ & 16) != 0 ? 't' : '-');
        sb.append((this.f41EQ & 8) != 0 ? 'r' : '-');
        sb.append((this.f41EQ & 4) != 0 ? 'u' : '-');
        sb.append((this.f41EQ & 2) != 0 ? 's' : '-');
        sb.append((this.f41EQ & 1) != 0 ? 'p' : '-');
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(hE.DW(m55aM()));
        sb.append(' ');
        sb.append(we());
        sb.append(' ');
        m58j6(sb);
        return sb.toString();
    }
}
