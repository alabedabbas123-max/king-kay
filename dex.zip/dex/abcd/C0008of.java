package abcd;

import com.aide.common.ab;
import com.aide.ui.U;
import java.util.List;

@xu
class C0008of implements ab<String> {

    @uu
    private static boolean f65DW;

    @tu
    private static boolean f66j6;

    @vu
    final C0050pf f67FH;

    static {
        wu.j6(C0008of.class, 3605670354921822675L, 879553407212038048L);
    }

    C0008of(C0050pf c0050pf) {
        this.f67FH = c0050pf;
    }

    @su(method = -5624784751671955367L)
    public void m41j6(String str) {
        try {
            if (f66j6) {
                wu.j6(1264946281582966253L, this, str);
            }
            U.vy().er();
            U.J8().Hw();
            U.tp().FH(str);
            U.vy().j6((List) null, false);
            U.lg().j6(new Tl(str, 1, 1, 1, 1));
        } catch (Throwable th) {
            if (f65DW) {
                wu.j6(th, 1264946281582966253L, this, str);
            }
            throw th;
        }
    }
}
