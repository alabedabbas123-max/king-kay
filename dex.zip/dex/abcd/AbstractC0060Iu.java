package abcd;

import com.appfour.backbone.api.closures.OnApplicationClosure;
import com.appfour.backbone.api.closures.OnCrashClosure;
import com.appfour.backbone.api.closures.OnInAppProductClosure;
import com.appfour.backbone.api.closures.OnMarketClosure;
import com.appfour.backbone.api.closures.OnMarketImpressionClosure;
import com.appfour.backbone.api.closures.OnVoidClosure;
import com.appfour.backbone.api.define.DefineHook;

public abstract class AbstractC0060Iu extends Bv {

    private boolean f416BT;

    private boolean f417KD;

    private boolean f418P8;

    private boolean f419SI;

    private boolean f420ei;

    private boolean f421gW;

    private boolean f422nw;

    private boolean f423vy;

    private boolean f424yS;

    public boolean m639BT() {
        return this.f417KD;
    }

    public boolean m640KD() {
        return this.f423vy;
    }

    public boolean m641P8() {
        return this.f419SI;
    }

    public boolean m642SI() {
        return this.f418P8;
    }

    public boolean m643cn() {
        return this.f421gW;
    }

    public boolean m644ei() {
        return this.f422nw;
    }

    public boolean m645nw() {
        return this.f424yS;
    }

    public DefineHook onApplicationCreate(OnApplicationClosure onApplicationClosure) {
        this.f420ei = true;
        ((yu) this).j6 = onApplicationClosure == null ? null : new C0018Hu(this, onApplicationClosure);
        return j6();
    }

    public DefineHook onCrash(OnCrashClosure onCrashClosure) {
        this.f417KD = true;
        ((yu) this).j6 = onCrashClosure == null ? null : new Bu(this, onCrashClosure);
        return j6();
    }

    public DefineHook onInAppProductImpression(OnInAppProductClosure onInAppProductClosure) {
        this.f419SI = true;
        ((yu) this).j6 = onInAppProductClosure == null ? null : new Cu(this, onInAppProductClosure);
        return j6();
    }

    public DefineHook onInAppProductPurchase(OnInAppProductClosure onInAppProductClosure) {
        this.f422nw = true;
        ((yu) this).j6 = onInAppProductClosure == null ? null : new Du(this, onInAppProductClosure);
        return j6();
    }

    public DefineHook onInstall(OnMarketClosure onMarketClosure) {
        this.f424yS = true;
        ((yu) this).j6 = onMarketClosure == null ? null : new Eu(this, onMarketClosure);
        return j6();
    }

    public DefineHook onNewVersion(OnVoidClosure onVoidClosure) {
        this.f416BT = true;
        ((yu) this).j6 = onVoidClosure == null ? null : new Gu(this, onVoidClosure);
        return j6();
    }

    public DefineHook onReferrerMarketClick(OnMarketClosure onMarketClosure) {
        this.f418P8 = true;
        ((yu) this).j6 = onMarketClosure == null ? null : new Au(this, onMarketClosure);
        return j6();
    }

    public DefineHook onReferrerMarketImpression(OnMarketImpressionClosure onMarketImpressionClosure) {
        this.f423vy = true;
        ((yu) this).j6 = onMarketImpressionClosure == null ? null : new zu(this, onMarketImpressionClosure);
        return j6();
    }

    public DefineHook onUpdate(OnVoidClosure onVoidClosure) {
        this.f421gW = true;
        ((yu) this).j6 = onVoidClosure == null ? null : new Fu(this, onVoidClosure);
        return j6();
    }

    public boolean m646ro() {
        return this.f416BT;
    }

    public boolean m647vy() {
        return this.f420ei;
    }
}
