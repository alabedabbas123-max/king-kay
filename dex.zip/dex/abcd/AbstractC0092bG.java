package abcd;

public abstract class AbstractC0092bG {
    public abstract void m640j6(hC hCVar);
}
