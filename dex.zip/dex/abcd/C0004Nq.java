package abcd;

enum C0004Nq extends er {
    C0004Nq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
