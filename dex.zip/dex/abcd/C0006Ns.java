package abcd;

public final class C0006Ns {
    public static ms m42j6(Qs qs) {
        switch (qs.j3()) {
            case 1:
                return rs.DW;
            case 2:
                return ss.DW;
            case 3:
                return ts.DW;
            case 4:
                return us.DW;
            case 5:
                return xs.DW;
            case 6:
                return ys.Hw;
            case 7:
                return Es.DW;
            case 8:
                return Is.DW;
            case 9:
                return As.j6;
            default:
                throw new UnsupportedOperationException("no zero for type: " + qs.aM());
        }
    }
}
