package abcd;

import io.fabric.sdk.android.Fabric;
import io.fabric.sdk.android.Kit;
import io.fabric.sdk.android.services.common.n;
import io.fabric.sdk.android.services.common.v;
import java.util.Collections;
import java.util.Map;

public class C0018Bw extends Kit<Boolean> implements n {
    public Map<v.a, String> m114Hw() {
        return Collections.emptyMap();
    }

    public Boolean m812doInBackground() {
        Fabric.getLogger().Hw("Beta", "Beta kit initializing...");
        return true;
    }

    public String getIdentifier() {
        return "com.crashlytics.sdk.android:beta";
    }

    public String getVersion() {
        return "1.2.10.27";
    }
}
