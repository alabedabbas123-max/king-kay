package abcd;

import java.util.Date;

public abstract class AbstractC0065wG extends yG {

    final int f146v5;

    private static class a extends AbstractC0065wG {
        a(long j) {
            super(j);
        }

        public boolean m268j6(qG qGVar, dG dGVar) throws sD {
            if (dGVar.U2() >= this.f146v5) {
                return true;
            }
            throw sD.j6;
        }

        public String toString() {
            return String.valueOf(super.toString()) + "(" + new Date(((long) this.f146v5) * 1000) + ")";
        }
    }

    AbstractC0065wG(long j) {
        this.f146v5 = (int) (j / 1000);
    }

    public static final yG m265j6(long j) {
        return new a(j);
    }

    public static final yG m266j6(Date date) {
        return m265j6(date.getTime());
    }

    public yG clone() {
        return this;
    }

    public boolean m267j6() {
        return false;
    }
}
