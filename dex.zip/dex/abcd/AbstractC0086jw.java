package abcd;

import com.appfour.backbone.api.define.DefineAnalytics;
import com.appfour.backbone.api.define.DefineOccurrences;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public abstract class AbstractC0086jw implements DefineAnalytics {

    private List<lw> f347DW;

    private Set<String> f348FH;

    private lw f349Hw;

    private Object f350j6 = new Object();

    public interface a {
        void m472get();
    }

    private void m469XL() {
        Set<String> set;
        lw lwVar = this.f349Hw;
        if (lwVar == null || this.f347DW == null || m470j6(lwVar.DW()) || (set = this.f348FH) == null || set.contains(this.f349Hw.DW())) {
            return;
        }
        this.f347DW.add(this.f349Hw);
    }

    private boolean m470j6(String str) {
        Iterator<lw> it = this.f347DW.iterator();
        while (it.hasNext()) {
            if (str.equals(it.next().DW())) {
                return true;
            }
        }
        return false;
    }

    public DefineOccurrences defineEvent(String str) {
        m469XL();
        lw lwVar = new lw(str);
        this.f349Hw = lwVar;
        return lwVar;
    }

    public void m471j6(a aVar, List<lw> list) {
        synchronized (this.f350j6) {
            try {
                this.f347DW = list;
                this.f348FH = new HashSet();
                this.f349Hw = null;
                aVar.m472get();
                m469XL();
                this.f347DW = null;
                this.f348FH = null;
                this.f349Hw = null;
            } catch (Throwable th) {
                m469XL();
                this.f347DW = null;
                this.f348FH = null;
                this.f349Hw = null;
                throw th;
            }
        }
    }

    public void onDefineEventError(Throwable th) {
        lw lwVar = this.f349Hw;
        if (lwVar != null) {
            ow.j6(lwVar, System.currentTimeMillis(), th);
            this.f349Hw = null;
        }
    }

    public void undefineEvent(String str) {
        Set<String> set = this.f348FH;
        if (set != null) {
            set.add(str);
        }
    }
}
