package abcd;

@xu
public class C0005X {

    @uu
    private static boolean f21DW;

    @tu
    private static boolean f22j6;

    @ru(field = 1251574424737331796L)
    private final ea f23FH;

    @ru(field = 1497130809243992377L)
    private final Ba f24Hw;

    @ru(field = 1543578175414544328L)
    private final Va f25v5;

    static {
        wu.j6(C0005X.class, 6278987004744662160L, 6278987004744662160L);
    }

    public C0005X(ea eaVar) {
        try {
            if (f22j6) {
                wu.j6(-2181356747002822320L, (Object) null, eaVar);
            }
            this.f23FH = eaVar;
            this.f24Hw = ((La) eaVar).a8;
            this.f25v5 = ((La) eaVar).U2;
        } catch (Throwable th) {
            if (f21DW) {
                wu.j6(th, -2181356747002822320L, (Object) null, eaVar);
            }
            throw th;
        }
    }

    @su(method = -373459676068359424L)
    private int m20j6(Sa sa, int i, int i2) throws Throwable {
        int iM20j6;
        try {
            if (f22j6) {
                iM20j6 = i2;
                try {
                    wu.j6(4781301762269741517L, this, sa, new Integer(i), new Integer(iM20j6));
                } catch (Throwable th) {
                    th = th;
                    if (f21DW) {
                        wu.j6(th, 4781301762269741517L, this, sa, new Integer(i), new Integer(iM20j6));
                    }
                    throw th;
                }
            } else {
                iM20j6 = i2;
            }
            int iWe = sa.we(i);
            for (int i3 = 0; i3 < iWe; i3++) {
                int iZo = sa.Zo(i, i3);
                if (sa.Qq(iZo)) {
                    if (!sa.XG(iZo) && sa.vy(iZo) > 0) {
                        int iM20j7 = m20j6(sa, iZo, 0);
                        int iJ3 = sa.J8().v5().j3(sa, iZo);
                        if (iJ3 <= 0) {
                            ((La) this.f23FH).Hw.j6(sa.vy(iZo) + "," + sa.BT(iZo), sa.J8().v5().aM(sa, iZo), sa.vy(iZo), sa.BT(iZo), sa.BT(iZo), sa.vy(iZo), sa.BT(iZo), sa.QX(iZo), sa.Ws(iZo), iM20j7);
                        } else {
                            ((La) this.f23FH).Hw.j6(((La) this.f23FH).j3.j6(sa.XL(iJ3)), sa.J8().v5().aM(sa, iZo), sa.vy(iJ3), sa.BT(iJ3), sa.Ws(iJ3), sa.vy(iZo), sa.BT(iZo), sa.QX(iZo), sa.Ws(iZo), iM20j7);
                        }
                        iM20j6++;
                    }
                } else if (sa.vJ(iZo)) {
                    if (!sa.XG(iZo) && sa.vy(iZo) > 0) {
                        int iM20j8 = m20j6(sa, iZo, 0);
                        try {
                            ua uaVarJ6 = this.f24Hw.j6(sa.VH(), sa.J8(), sa.J8(iZo));
                            ((La) this.f23FH).Hw.j6(uaVarJ6, uaVarJ6.J8(), uaVarJ6.Ws(), uaVarJ6.J0(), uaVarJ6.qp(), uaVarJ6.fY(), uaVarJ6.v5(), uaVarJ6.Hw(), iM20j8);
                            iM20j6++;
                        } catch (jc unused) {
                        }
                    }
                } else if (sa.lp(iZo)) {
                    if (!sa.XG(iZo) && sa.vy(iZo) > 0) {
                        Ia iaDW = this.f24Hw.DW(sa.VH(), sa.J8(), sa.J8(iZo));
                        ((La) this.f23FH).Hw.j6(iaDW, iaDW.J8(), iaDW.Ws(), iaDW.J0(), iaDW.Mz(), iaDW.g3(), iaDW.v5(), iaDW.Hw());
                        iM20j6++;
                    }
                } else if (!sa.ca(iZo)) {
                    iM20j6 = m20j6(sa, iZo, iM20j6);
                } else if (!sa.XG(iZo) && sa.vy(iZo) > 0) {
                    Ia iaDW2 = this.f24Hw.DW(sa.VH(), sa.J8(), sa.J8(iZo));
                    ((La) this.f23FH).Hw.j6(iaDW2, iaDW2.J8(), iaDW2.Ws(), iaDW2.J0(), iaDW2.Mz(), iaDW2.g3(), iaDW2.v5(), iaDW2.Hw());
                    iM20j6++;
                }
            }
            return iM20j6;
        } catch (Throwable th2) {
            th = th2;
            iM20j6 = i2;
        }
    }

    @su(method = 420409162597755540L)
    private void m21j6(Sa sa, int i) {
        try {
            if (f22j6) {
                wu.j6(-2305932276137642403L, this, sa, new Integer(i));
            }
            if (sa.lp(i)) {
                try {
                    Ia iaDW = this.f24Hw.DW(sa.VH(), sa.J8(), sa.J8(i));
                    if (iaDW.aj()) {
                        int iWs = iaDW.Ws();
                        int iJ0 = iaDW.J0();
                        int iJ8 = iaDW.J8();
                        ((La) this.f23FH).rN.Zo(sa.VH(), sa.J8(), iJ8, iWs, iJ8, iJ0, "", 91);
                    }
                } catch (jc unused) {
                }
            }
            if (sa.ca(i)) {
                try {
                    Ia iaDW2 = this.f24Hw.DW(sa.VH(), sa.J8(), sa.J8(i));
                    if (iaDW2.aj()) {
                        int iWs2 = iaDW2.Ws();
                        int iJ1 = iaDW2.J0();
                        int iJ9 = iaDW2.J8();
                        ((La) this.f23FH).rN.Zo(sa.VH(), sa.J8(), iJ9, iWs2, iJ9, iJ1, "", 91);
                    }
                } catch (jc unused2) {
                }
            }
            int iWe = sa.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m21j6(sa, sa.Zo(i, i2));
            }
        } catch (Throwable th) {
            if (f21DW) {
                wu.j6(th, -2305932276137642403L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    public void m22j6(Da da) {
        try {
            if (f22j6) {
                wu.j6(857450650939495415L, this, da);
            }
            if (da.gn() != null) {
                ((La) this.f23FH).Hw.j6();
                int i = 0;
                for (Sa sa : ((La) this.f23FH).U2.DW(da)) {
                    int iM20j6 = m20j6(sa, sa.aM(), 0);
                    if (iM20j6 > 0) {
                        ((La) this.f23FH).Hw.j6(sa.J8(), iM20j6);
                        i++;
                    }
                    this.f25v5.j6(sa);
                }
                ((La) this.f23FH).Hw.j6(da, i);
            }
        } catch (Throwable th) {
            if (f21DW) {
                wu.j6(th, 857450650939495415L, this, da);
            }
            throw th;
        }
    }

    public void m23j6(Sa sa) {
        try {
            if (f22j6) {
                wu.j6(3024303301771962140L, this, sa);
            }
            m21j6(sa, sa.aM());
        } catch (Throwable th) {
            if (f21DW) {
                wu.j6(th, 3024303301771962140L, this, sa);
            }
            throw th;
        }
    }
}
