package abcd;

public abstract class AbstractC0105xE {
    protected AbstractC0105xE() {
    }

    public boolean m428DW() {
        return true;
    }

    public abstract AbstractC0105xE m429FH();

    public abstract EE m430Hw();

    public FE m431j6(YD yd, int i) {
        IE ieM434v5 = m434v5();
        try {
            return ieM434v5.Hw(yd, i);
        } finally {
            ieM434v5.FH();
        }
    }

    public abstract void m432j6();

    public abstract boolean m433j6(YD yd);

    public abstract IE m434v5();
}
