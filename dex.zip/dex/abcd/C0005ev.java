package abcd;

import com.appfour.backbone.api.closures.OnExceptionClosure4;
import com.appfour.backbone.api.objects.EventData;

class C0005ev implements jv {

    final OnExceptionClosure4 f51DW;

    final AbstractC0137hv f52FH;

    final long f53j6;

    C0005ev(AbstractC0137hv abstractC0137hv, long j, OnExceptionClosure4 onExceptionClosure4) {
        this.f52FH = abstractC0137hv;
        this.f53j6 = j;
        this.f51DW = onExceptionClosure4;
    }

    public EventData m18j6(Object[] objArr) {
        Object objJ6 = Ev.j6(objArr[0], this.f53j6);
        return Mv.XL().j6(objJ6, new dv(this, objJ6, objArr));
    }
}
