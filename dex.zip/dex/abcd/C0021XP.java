package abcd;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public final class C0021XP {

    private static int f76j6 = 512;

    public static int m109j6(InputStream inputStream, byte[] bArr) {
        return m110j6(inputStream, bArr, 0, bArr.length);
    }

    public static int m110j6(InputStream inputStream, byte[] bArr, int i, int i2) throws IOException {
        int i3 = 0;
        while (i3 < i2) {
            int i4 = inputStream.read(bArr, i + i3, i2 - i3);
            if (i4 < 0) {
                break;
            }
            i3 += i4;
        }
        return i3;
    }

    public static void m111j6(InputStream inputStream, OutputStream outputStream) throws IOException {
        byte[] bArr = new byte[f76j6];
        while (true) {
            int i = inputStream.read(bArr, 0, bArr.length);
            if (i < 0) {
                return;
            } else {
                outputStream.write(bArr, 0, i);
            }
        }
    }

    public static byte[] m112j6(InputStream inputStream) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        m111j6(inputStream, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
}
