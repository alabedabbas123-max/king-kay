package abcd;

public final class C0000Nm extends hu {

    private final Rs[] f0DW;

    private final boolean[] f1FH;

    private int f2Hw;

    public C0000Nm(int i) {
        super(i != 0);
        this.f0DW = new Rs[i];
        this.f1FH = new boolean[i];
        this.f2Hw = 0;
    }

    private static Rs m0DW(String str) throws an {
        throw new an("stack: " + str);
    }

    private static String m1DW(Rs rs) {
        return rs == null ? "<invalid>" : rs.toString();
    }

    public Rs m2DW(int i) throws an {
        if (i < 0) {
            throw new IllegalArgumentException("n < 0");
        }
        int i2 = this.f2Hw;
        if (i < i2) {
            return this.f0DW[(i2 - i) - 1];
        }
        m0DW("underflow");
        throw null;
    }

    public void m3DW(Qs qs) {
        if (this.f2Hw == 0) {
            return;
        }
        J8();
        Rs rsWs = qs.Ws();
        for (int i = 0; i < this.f2Hw; i++) {
            Rs[] rsArr = this.f0DW;
            if (rsArr[i] == qs) {
                rsArr[i] = rsWs;
            }
        }
    }

    public boolean m4FH(int i) throws an {
        if (i < 0) {
            throw new IllegalArgumentException("n < 0");
        }
        int i2 = this.f2Hw;
        if (i < i2) {
            return this.f1FH[(i2 - i) - 1];
        }
        throw new an("stack: underflow");
    }

    public Qs m5Hw(int i) {
        return m2DW(i).getType();
    }

    public Rs m6er() throws an {
        J8();
        Rs rsM2DW = m2DW(0);
        Rs[] rsArr = this.f0DW;
        int i = this.f2Hw;
        rsArr[i - 1] = null;
        this.f1FH[i - 1] = false;
        this.f2Hw = i - rsM2DW.getType().Zo();
        return rsM2DW;
    }

    public C0000Nm m7j6(C0000Nm c0000Nm) throws an {
        try {
            return Um.j6(this, c0000Nm);
        } catch (an e) {
            e.j6("underlay stack:");
            m10j6((Vt) e);
            e.j6("overlay stack:");
            c0000Nm.m10j6((Vt) e);
            throw e;
        }
    }

    public void m8j6(int i, Rs rs) throws an {
        J8();
        try {
            Rs rsU2 = rs.U2();
            int i2 = (this.f2Hw - i) - 1;
            Rs rs2 = this.f0DW[i2];
            if (rs2 != null && rs2.getType().Zo() == rsU2.getType().Zo()) {
                this.f0DW[i2] = rsU2;
                return;
            }
            m0DW("incompatible substitution: " + m1DW(rs2) + " -> " + m1DW(rsU2));
            throw null;
        } catch (NullPointerException unused) {
            throw new NullPointerException("type == null");
        }
    }

    public void m9j6(Rs rs) throws an {
        J8();
        try {
            Rs rsU2 = rs.U2();
            int iZo = rsU2.getType().Zo();
            int i = this.f2Hw;
            int i2 = i + iZo;
            Rs[] rsArr = this.f0DW;
            if (i2 > rsArr.length) {
                m0DW("overflow");
                throw null;
            }
            if (iZo == 2) {
                rsArr[i] = null;
                this.f2Hw = i + 1;
            }
            Rs[] rsArr2 = this.f0DW;
            int i3 = this.f2Hw;
            rsArr2[i3] = rsU2;
            this.f2Hw = i3 + 1;
        } catch (NullPointerException unused) {
            throw new NullPointerException("type == null");
        }
    }

    public void m10j6(Vt vt) {
        int i = this.f2Hw - 1;
        int i2 = 0;
        while (i2 <= i) {
            vt.j6("stack[" + (i2 == i ? "top0" : Yt.v5(i - i2)) + "]: " + m1DW(this.f0DW[i2]));
            i2++;
        }
    }

    public void m11lg() {
        J8();
        for (int i = 0; i < this.f2Hw; i++) {
            this.f0DW[i] = null;
            this.f1FH[i] = false;
        }
        this.f2Hw = 0;
    }

    public C0000Nm m12rN() {
        C0000Nm c0000Nm = new C0000Nm(this.f0DW.length);
        Rs[] rsArr = this.f0DW;
        System.arraycopy(rsArr, 0, c0000Nm.f0DW, 0, rsArr.length);
        boolean[] zArr = this.f1FH;
        System.arraycopy(zArr, 0, c0000Nm.f1FH, 0, zArr.length);
        c0000Nm.f2Hw = this.f2Hw;
        return c0000Nm;
    }

    public int size() {
        return this.f2Hw;
    }

    public void m13yS() {
        J8();
        this.f1FH[this.f2Hw] = true;
    }
}
