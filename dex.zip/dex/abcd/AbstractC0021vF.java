package abcd;

import java.text.MessageFormat;
import java.util.HashMap;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0021vF {

    public static final AbstractC0021vF f38j6 = new yF("ours", 0);

    public static final AbstractC0021vF f35DW = new yF("theirs", 1);

    public static final BF f36FH = new AF();

    public static final BF f37Hw = new zF();

    private static final HashMap<String, AbstractC0021vF> f39v5 = new HashMap<>();

    static {
        m83j6(f38j6);
        m83j6(f35DW);
        m83j6((AbstractC0021vF) f36FH);
        m83j6((AbstractC0021vF) f37Hw);
    }

    public static void m83j6(AbstractC0021vF abstractC0021vF) {
        m84j6(abstractC0021vF.m86j6(), abstractC0021vF);
    }

    public static synchronized void m84j6(String str, AbstractC0021vF abstractC0021vF) {
        if (f39v5.containsKey(str)) {
            throw new IllegalArgumentException(MessageFormat.format(JGitText.j6().mergeStrategyAlreadyExistsAsDefault, str));
        }
        f39v5.put(str, abstractC0021vF);
    }

    public abstract AbstractC0064wF m85j6(UE ue);

    public abstract String m86j6();
}
