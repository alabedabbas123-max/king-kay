package abcd;

import com.aide.common.ab;
import com.aide.engine.EngineSolution;
import com.aide.ui.U;
import com.aide.ui.build.f;
import com.aide.ui.trainer.g;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@xu
public class C0023lj implements Ui {

    @uu
    private static boolean f230DW;

    @tu
    private static boolean f231j6;

    static {
        wu.j6(C0023lj.class, 2793693412414817632L, 2793693412414817632L);
    }

    public C0023lj() {
        try {
            if (f231j6) {
                wu.j6(391666163359204104L, (Object) null);
            }
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 391666163359204104L, (Object) null);
            }
            throw th;
        }
    }

    public static String m114DW(String str, String str2) {
        try {
            if (f231j6) {
                wu.j6(-1773787202765954299L, (Object) null, str, str2);
            }
            for (String str3 : m121U2(str)) {
                if (Vl.Hw(str3, str2)) {
                    return Vl.FH(str3, str2).replace('/', '.');
                }
            }
            return null;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -1773787202765954299L, (Object) null, str, str2);
            }
            throw th;
        }
    }

    public static String m115DW(String str, boolean z) {
        try {
            if (f231j6) {
                wu.j6(6940714751171552300L, (Object) null, str, new Boolean(z));
            }
            return m116FH(str, z) + "/dex/classes.dex.zip";
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 6940714751171552300L, (Object) null, str, new Boolean(z));
            }
            throw th;
        }
    }

    public static String m116FH(String str, boolean z) {
        try {
            if (f231j6) {
                wu.j6(1367789976640152271L, (Object) null, str, new Boolean(z));
            }
            for (Ri.a aVar : new Ri().j6(m122a8(str)).gn) {
                if (aVar.Hw()) {
                    String strJ6 = aVar.j6(str);
                    if (z) {
                        return strJ6 + "/debug";
                    }
                    return strJ6 + "/release";
                }
            }
            if (z) {
                return str + "/bin/debug";
            }
            return str + "/bin/release";
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1367789976640152271L, (Object) null, str, new Boolean(z));
            }
            throw th;
        }
    }

    public static String m117Hw(String str, boolean z) {
        try {
            if (f231j6) {
                wu.j6(551602789501091844L, (Object) null, str, new Boolean(z));
            }
            return m116FH(str, z) + "/dex/jars";
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 551602789501091844L, (Object) null, str, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = -1587184037009814155L)
    private int m118J0() {
        try {
            if (!f231j6) {
                return 2;
            }
            wu.j6(335761148619763803L, this);
            return 2;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 335761148619763803L, this);
            }
            throw th;
        }
    }

    @su(method = -1614000723129821520L)
    private boolean m119J8() {
        try {
            if (f231j6) {
                wu.j6(1033257694606972960L, this);
            }
            int iJ6 = 0;
            for (String str : m121U2(U.vy().J0())) {
                iJ6 += Vl.j6(str, m118J0(), new String[]{".java"});
                if (iJ6 >= m118J0()) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1033257694606972960L, this);
            }
            throw th;
        }
    }

    public static String[] m120Mr(String str) {
        try {
            if (f231j6) {
                wu.j6(2300870452191153304L, (Object) null, str);
            }
            ArrayList arrayList = new ArrayList();
            for (Ri.a aVar : new Ri().j6(m122a8(str)).gn) {
                if (aVar.FH()) {
                    arrayList.add(aVar.j6(str));
                }
            }
            return (String[]) arrayList.toArray(new String[arrayList.size()]);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 2300870452191153304L, (Object) null, str);
            }
            throw th;
        }
    }

    public static String[] m121U2(String str) {
        try {
            if (f231j6) {
                wu.j6(-5284948926816338715L, (Object) null, str);
            }
            ArrayList arrayList = new ArrayList();
            for (Ri.a aVar : new Ri().j6(m122a8(str)).gn) {
                if (aVar.Zo()) {
                    arrayList.add(aVar.j6(str));
                }
            }
            return (String[]) arrayList.toArray(new String[arrayList.size()]);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -5284948926816338715L, (Object) null, str);
            }
            throw th;
        }
    }

    public static String m122a8(String str) {
        try {
            if (f231j6) {
                wu.j6(2547595195144711764L, (Object) null, str);
            }
            return str + "/.classpath";
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 2547595195144711764L, (Object) null, str);
            }
            throw th;
        }
    }

    public static String m123j6(String str, boolean z) {
        try {
            if (f231j6) {
                wu.j6(-4341413986724372964L, (Object) null, str, new Boolean(z));
            }
            return m116FH(str, z) + "/dex";
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -4341413986724372964L, (Object) null, str, new Boolean(z));
            }
            throw th;
        }
    }

    public static String m124j6(Map<String, List<String>> map, String str) {
        try {
            if (f231j6) {
                wu.j6(-671951478432254660L, (Object) null, map, str);
            }
            for (String str2 : m125j6(map)) {
                if (Vl.Hw(str2, str)) {
                    return Vl.FH(str2, str).replace('/', '.');
                }
            }
            return null;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -671951478432254660L, (Object) null, map, str);
            }
            throw th;
        }
    }

    public static String[] m125j6(Map<String, List<String>> map) {
        try {
            if (f231j6) {
                wu.j6(932316593701375520L, (Object) null, map);
            }
            ArrayList arrayList = new ArrayList();
            for (String str : map.keySet()) {
                for (Ri.a aVar : new Ri().j6(m122a8(str)).gn) {
                    if (aVar.Zo()) {
                        arrayList.add(aVar.j6(str));
                    }
                }
            }
            String[] strArr = new String[arrayList.size()];
            arrayList.toArray(strArr);
            return strArr;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 932316593701375520L, (Object) null, map);
            }
            throw th;
        }
    }

    public boolean m126DW() {
        try {
            if (!f231j6) {
                return false;
            }
            wu.j6(6117126614163032755L, this);
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 6117126614163032755L, this);
            }
            throw th;
        }
    }

    public boolean m127DW(String str) {
        try {
            if (!f231j6) {
                return false;
            }
            wu.j6(3903443620038632736L, this, str);
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 3903443620038632736L, this, str);
            }
            throw th;
        }
    }

    public String m128EQ() {
        try {
            if (!f231j6) {
                return "com.aide.ui";
            }
            wu.j6(6669876335521596692L, this);
            return "com.aide.ui";
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 6669876335521596692L, this);
            }
            throw th;
        }
    }

    public boolean m129EQ(String str) {
        try {
            if (f231j6) {
                wu.j6(-2007612208033038345L, this, str);
            }
            return str.toLowerCase().endsWith(".jar") && !Arrays.asList(m120Mr(U.vy().J0())).contains(str);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -2007612208033038345L, this, str);
            }
            throw th;
        }
    }

    public String m130FH(String str) {
        try {
            if (f231j6) {
                wu.j6(-1557429322153859008L, this, str);
            }
            if (m135J8(str)) {
                return null;
            }
            return "com.aide.ui";
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -1557429322153859008L, this, str);
            }
            throw th;
        }
    }

    public List<g.b> m131FH() {
        try {
            if (f231j6) {
                wu.j6(-1751453124824682264L, this);
            }
            return Arrays.asList(new g.b("course_java", 1, new String[]{"com.aide.ui", "com.aide.trainer.java"}));
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -1751453124824682264L, this);
            }
            throw th;
        }
    }

    public void m132Hw() {
        try {
            if (f231j6) {
                wu.j6(1581057273621888879L, this);
            }
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1581057273621888879L, this);
            }
            throw th;
        }
    }

    public void m133Hw(String str) {
        try {
            if (f231j6) {
                wu.j6(1981618901340942695L, this, str);
            }
            String strJ0 = U.vy().J0();
            List<Ri.a> list = new Ri().j6(m122a8(strJ0)).gn;
            for (Ri.a aVar : list) {
                if (aVar.FH() && aVar.j6(strJ0).equals(str)) {
                    list.remove(aVar);
                    break;
                }
            }
            Ri.j6(m122a8(strJ0), list);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1981618901340942695L, this, str);
            }
            throw th;
        }
    }

    public int m134J0(String str) {
        try {
            if (f231j6) {
                wu.j6(1676999377948974401L, this, str);
            }
            return kj.DW(str);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1676999377948974401L, this, str);
            }
            throw th;
        }
    }

    public boolean m135J8(String str) {
        try {
            if (f231j6) {
                wu.j6(-4833072011717200944L, this, str);
            }
            return U.ef() || U.j6.equals("com.aide.ui") || U.j6.equals("com.aide.trainer.java");
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -4833072011717200944L, this, str);
            }
            throw th;
        }
    }

    public boolean m136QX(String str) {
        try {
            if (f231j6) {
                wu.j6(1013175581687134208L, this, str);
            }
            if (Vl.Hw(m122a8(str))) {
                if (!Vl.Hw(str + "/AndroidManifest.xml")) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1013175581687134208L, this, str);
            }
            throw th;
        }
    }

    public EngineSolution m137VH() {
        try {
            if (f231j6) {
                wu.j6(-3872239307417140704L, this);
            }
            return ij.j6(U.vy().J0(), U.vy().Zo(), (String) null);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -3872239307417140704L, this);
            }
            throw th;
        }
    }

    public void m138VH(String str) {
        try {
            if (f231j6) {
                wu.j6(-3427879366614745133L, this, str);
            }
            String strJ0 = U.vy().J0();
            List list = new Ri().j6(m122a8(strJ0)).gn;
            list.add(new Ri.a("lib", Vl.gn(strJ0, str), false));
            Ri.j6(m122a8(strJ0), list);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -3427879366614745133L, this, str);
            }
            throw th;
        }
    }

    public int m139Ws(String str) {
        try {
            if (f231j6) {
                wu.j6(-100285065325905132L, this, str);
            }
            return kj.FH(str);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -100285065325905132L, this, str);
            }
            throw th;
        }
    }

    public List<String> m140XL(String str) {
        try {
            if (!f231j6) {
                return null;
            }
            wu.j6(384500213864065539L, this, str);
            return null;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 384500213864065539L, this, str);
            }
            throw th;
        }
    }

    public boolean m141Zo() {
        try {
            if (f231j6) {
                wu.j6(-69811361997947040L, this);
            }
            if (U.ef() || U.U2().Zo()) {
                return false;
            }
            if (H.j6(U.lg(), "AllowSavingOneJavaFileInNonPremium", new double[]{1.0d, 0.0d})) {
                return m119J8();
            }
            return true;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -69811361997947040L, this);
            }
            throw th;
        }
    }

    public boolean m142Zo(String str) {
        try {
            if (f231j6) {
                wu.j6(-1658865502523695353L, this, str);
            }
            return Arrays.asList(m120Mr(U.vy().J0())).contains(str);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -1658865502523695353L, this, str);
            }
            throw th;
        }
    }

    public boolean m143aM(String str) {
        try {
            if (!f231j6) {
                return false;
            }
            wu.j6(1738458739672370240L, this, str);
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1738458739672370240L, this, str);
            }
            throw th;
        }
    }

    public Sk.a[] getTemplates() {
        try {
            if (f231j6) {
                wu.j6(1131067569338544863L, this);
            }
            return new Sk.a[]{new Sk.a("Java Application", new Sk.b(this, 3, "Java Application", "Java", "MyJavaConsoleApp", false, false, "com.aide.ui", "JAVA", "course_java", U.ef() || U.j6.equals("com.aide.ui")), com.aide.pro.R.drawable.ic_launcher_java, "JavaConsole.zip", new String[]{"Main.java"}, (String) null)};
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1131067569338544863L, this);
            }
            throw th;
        }
    }

    public int m144gn(String str) {
        try {
            if (!f231j6) {
                return com.aide.pro.R.string.command_files_open_java_project;
            }
            wu.j6(-1082840353118477184L, this, str);
            return com.aide.pro.R.string.command_files_open_java_project;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -1082840353118477184L, this, str);
            }
            throw th;
        }
    }

    public String m145gn() {
        try {
            if (f231j6) {
                wu.j6(1496832615736448696L, this);
            }
            String str = ("<b>Java Project:</b><br/><br/>" + U.vy().J0() + "<br/><br/>") + "<i>Library JARs:</i><br/><br/>";
            String[] strArrM120Mr = m120Mr(U.vy().J0());
            if (strArrM120Mr.length == 0) {
                return str + "&lt;none&gt;<br/><br/>";
            }
            for (String str2 : strArrM120Mr) {
                if (!Vl.Hw(str2)) {
                    str = str + "(NOT FOUND) ";
                }
                str = str + str2 + "<br/><br/>";
            }
            return str;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 1496832615736448696L, this);
            }
            throw th;
        }
    }

    public void m146j3(String str) {
        try {
            if (f231j6) {
                wu.j6(-3465622584135908980L, this, str);
            }
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -3465622584135908980L, this, str);
            }
            throw th;
        }
    }

    public String m147j6(String str) {
        try {
            if (f231j6) {
                wu.j6(-4328879974228677312L, this, str);
            }
            String strM124j6 = m124j6((Map<String, List<String>>) U.vy().J8(), Vl.EQ(str));
            if (strM124j6 == null) {
                return str;
            }
            return strM124j6.replace('.', '/') + "/" + Vl.tp(str);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -4328879974228677312L, this, str);
            }
            throw th;
        }
    }

    public void m148j6() {
        try {
            if (f231j6) {
                wu.j6(-3585970868152192L, this);
            }
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -3585970868152192L, this);
            }
            throw th;
        }
    }

    public void m149j6(String str, ab<String> abVar) {
        try {
            if (f231j6) {
                wu.j6(-1855678251007064891L, this, str, abVar);
            }
            kj.j6(str, abVar);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -1855678251007064891L, this, str, abVar);
            }
            throw th;
        }
    }

    public void m150j6(String str, String str2) {
        try {
            if (f231j6) {
                wu.j6(294812127363169395L, this, str, str2);
            }
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 294812127363169395L, this, str, str2);
            }
            throw th;
        }
    }

    public void m151j6(String str, Map<String, List<String>> map, List<String> list) {
        try {
            if (f231j6) {
                wu.j6(-6129825337551654335L, this, str, map, list);
            }
            map.put(str, new ArrayList());
            list.add(str);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -6129825337551654335L, this, str, map, list);
            }
            throw th;
        }
    }

    public void m152j6(List<String> list, boolean z) {
        try {
            if (f231j6) {
                wu.j6(4288878217891909980L, this, list, new Boolean(z));
            }
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 4288878217891909980L, this, list, new Boolean(z));
            }
            throw th;
        }
    }

    public void m153j6(boolean z) {
        try {
            if (f231j6) {
                wu.j6(6551052663397932620L, this, z);
            }
            f.DW.j6(z, U.vy().EQ());
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 6551052663397932620L, this, new Boolean(z));
            }
            throw th;
        }
    }

    public String m154tp(String str) {
        try {
            if (f231j6) {
                wu.j6(-7013994048444584208L, this, str);
            }
            String[] strArrM125j6 = m125j6((Map<String, List<String>>) U.vy().J8());
            if (!str.startsWith("/")) {
                str = "/" + str;
            }
            for (String str2 : strArrM125j6) {
                String str3 = str2 + str;
                if (Vl.Hw(str3)) {
                    return str3;
                }
            }
            return null;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -7013994048444584208L, this, str);
            }
            throw th;
        }
    }

    public boolean m155tp() {
        try {
            if (!f231j6) {
                return true;
            }
            wu.j6(4081838800878329337L, this);
            return true;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 4081838800878329337L, this);
            }
            throw th;
        }
    }

    public List<String> m156u7(String str) {
        try {
            if (!f231j6) {
                return null;
            }
            wu.j6(-2610082531592807255L, this, str);
            return null;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -2610082531592807255L, this, str);
            }
            throw th;
        }
    }

    public void m157u7() {
        try {
            if (f231j6) {
                wu.j6(-15643471048435296L, this);
            }
            U.U2().j6(U.lg(), com.aide.pro.R.string.shop_feature_premium_projects, "large_project");
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -15643471048435296L, this);
            }
            throw th;
        }
    }

    public boolean m158v5() {
        try {
            if (!f231j6) {
                return false;
            }
            wu.j6(-7089856552801447365L, this);
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -7089856552801447365L, this);
            }
            throw th;
        }
    }

    public boolean m159v5(String str) {
        try {
            if (f231j6) {
                wu.j6(-1502946952403260497L, this, str);
            }
            Iterator it = U.vy().J8().keySet().iterator();
            while (it.hasNext()) {
                if (Vl.Hw((String) it.next(), str)) {
                    return true;
                }
            }
            for (String str2 : m121U2(U.vy().J0())) {
                if (Vl.Hw(str2, str)) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, -1502946952403260497L, this, str);
            }
            throw th;
        }
    }

    public boolean m160we() {
        try {
            if (!f231j6) {
                return false;
            }
            wu.j6(311964585125593823L, this);
            return false;
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 311964585125593823L, this);
            }
            throw th;
        }
    }

    public boolean m161we(String str) {
        try {
            if (f231j6) {
                wu.j6(2727107145079476664L, this, str);
            }
            return kj.j6(str);
        } catch (Throwable th) {
            if (f230DW) {
                wu.j6(th, 2727107145079476664L, this, str);
            }
            throw th;
        }
    }
}
