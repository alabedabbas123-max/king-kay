package abcd;

@xu
public abstract class AbstractC0061tc {

    @uu
    private static boolean f208DW;

    @tu
    private static boolean f209j6;

    @ru(field = -1456585251406249295L)
    protected Sa f210EQ;

    @ru(field = 2159239594396043268L)
    protected final pa f211FH;

    @ru(field = -639764972249128061L)
    protected final Ca f212Hw;

    @ru(field = 2852311312572900777L)
    protected int f213J0;

    @ru(field = 3878940098194349235L)
    protected int f214J8;

    @ru(field = 4426913019366570801L)
    protected int[] f215Mr;

    @ru(field = 1094939260146292405L)
    protected int[] f216QX;

    @ru(field = 3790042629748569265L)
    protected int[] f217U2;

    @ru(field = -771520953783836816L)
    private boolean f218VH;

    @ru(field = 3133548740757660045L)
    protected int[] f219Ws;

    @ru(field = -2692041844269217696L)
    protected int[] f220XL;

    @ru(field = -2674072922617323039L)
    protected final Ba f221Zo;

    @ru(field = 4030436532707917423L)
    protected int f222a8;

    @ru(field = -1410840465421801275L)
    protected int[] f223aM;

    @ru(field = -3411445788856780548L)
    private int f224gn;

    @ru(field = 5203750808569409764L)
    protected int[] f225j3;

    @ru(field = 2582965753194724296L)
    protected boolean f226tp;

    @ru(field = -1455695039483370907L)
    private int f227u7;

    @ru(field = 4806766380864976011L)
    protected final Ga f228v5;

    @ru(field = -2636719083277406208L)
    protected int f229we;

    static {
        wu.j6(AbstractC0061tc.class, 124169490244666167L, 124169490244666167L);
    }

    public AbstractC0061tc(Ga ga, Ca ca, Ba ba, pa paVar, int i, int i2) {
        if (f209j6) {
            wu.j6(2556982381397340000L, (Object) null, new Object[]{ga, ca, ba, paVar, new Integer(i), new Integer(i2)});
        }
        this.f217U2 = new int[10000];
        this.f212Hw = ca;
        this.f228v5 = ga;
        this.f221Zo = ba;
        this.f211FH = paVar;
        this.f224gn = i;
        this.f227u7 = i2;
    }

    @su(method = -108504334746612720L)
    protected int m566DW(int i) {
        try {
            if (f209j6) {
                wu.j6(-4552738793638896544L, this, i);
            }
            int i2 = this.f213J0 + i;
            if (i2 < this.f214J8) {
                return this.f216QX[i2];
            }
            return 0;
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -4552738793638896544L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -3752348428494758548L)
    protected void m567DW() {
        try {
            if (f209j6) {
                wu.j6(-3235653410013790784L, this);
            }
            if (this.f226tp) {
                int i = this.f220XL[this.f213J0];
                int i2 = this.f225j3[this.f213J0];
                int i3 = this.f215Mr[this.f213J0];
                String string = this.f211FH.getString(this.f229we);
                this.f212Hw.DW(this.f210EQ.VH(), this.f210EQ.J8(), i, i2, i, i3, "错误的 </C>" + string + "<//C>", 0);
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -3235653410013790784L, this);
            }
            throw th;
        }
    }

    @su(method = 420587201319770496L)
    protected void m568DW(int i, int i2) {
        int i3;
        int i4;
        try {
            if (f209j6) {
                wu.j6(2597456785602609504L, this, new Integer(i), new Integer(i2));
            }
            if (this.f218VH) {
                if (this.f213J0 > 0) {
                    i3 = this.f220XL[this.f213J0 - 1];
                    i4 = this.f215Mr[this.f213J0 - 1];
                } else {
                    i3 = this.f220XL[this.f213J0];
                    i4 = this.f225j3[this.f213J0];
                }
                int i5 = i3;
                int i6 = i4;
                this.f222a8++;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                this.f217U2[this.f222a8] = this.f210EQ.j6(i, true, i2, i5, i6, i5, i6);
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, 2597456785602609504L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = -4063637893459125633L)
    protected void m569DW(int i, boolean z, int i2) {
        try {
            if (f209j6) {
                wu.j6(-2248176318411063717L, this, new Integer(i), new Boolean(z), new Integer(i2));
            }
            if (this.f218VH) {
                int iJ6 = this.f210EQ.j6(i, z, this.f217U2, (this.f222a8 - i2) + 1, i2, this.f220XL[this.f213J0], this.f225j3[this.f213J0]);
                this.f222a8 = (this.f222a8 - i2) + 1;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                this.f217U2[this.f222a8] = iJ6;
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -2248176318411063717L, this, new Integer(i), new Boolean(z), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = 577722138556150525L)
    protected int m570FH() {
        try {
            if (f209j6) {
                wu.j6(1994884584143556105L, this);
            }
            return this.f216QX[this.f213J0];
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, 1994884584143556105L, this);
            }
            throw th;
        }
    }

    @su(method = 46468429612263600L)
    protected void m571FH(int i) {
        try {
            if (f209j6) {
                wu.j6(-6601774980360144372L, this, i);
            }
            if (this.f218VH) {
                this.f222a8++;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                this.f217U2[this.f222a8] = this.f210EQ.j6(i, true, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f215Mr[this.f213J0]);
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -6601774980360144372L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -1472550081801976667L)
    protected void m572FH(int i, int i2) {
        try {
            if (f209j6) {
                wu.j6(-281104476381136211L, this, new Integer(i), new Integer(i2));
            }
            m581j6(i, true, i2);
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -281104476381136211L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = 736691946851523505L)
    protected void m573Hw() {
        try {
            if (f209j6) {
                wu.j6(2118961078039041205L, this);
            }
            if (this.f218VH) {
                this.f222a8++;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                if (this.f211FH.Zo(this.f229we) || this.f211FH.u7(this.f229we)) {
                    this.f217U2[this.f222a8] = this.f210EQ.j6(this.f229we, false, this.f216QX[this.f213J0], this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f223aM[this.f213J0], this.f215Mr[this.f213J0]);
                } else if (this.f211FH.we(this.f229we)) {
                    this.f217U2[this.f222a8] = this.f210EQ.j6(this.f229we, false, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f223aM[this.f213J0], this.f215Mr[this.f213J0]);
                } else {
                    this.f217U2[this.f222a8] = this.f210EQ.j6(this.f229we, false, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f215Mr[this.f213J0]);
                }
            }
            if (this.f213J0 < this.f214J8) {
                this.f213J0++;
                this.f229we = this.f219Ws[this.f213J0];
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, 2118961078039041205L, this);
            }
            throw th;
        }
    }

    @su(method = -215528572066294264L)
    protected void m574Hw(int i) {
        try {
            if (f209j6) {
                wu.j6(-7749183810588027552L, this, i);
            }
            if (this.f229we != i) {
                if (this.f218VH) {
                    this.f222a8++;
                    if (this.f222a8 >= this.f217U2.length) {
                        int[] iArr = new int[(this.f217U2.length * 2) + 1];
                        System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                        this.f217U2 = iArr;
                    }
                    if (this.f211FH.we(i)) {
                        this.f217U2[this.f222a8] = this.f210EQ.j6(i, true, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f223aM[this.f213J0], this.f215Mr[this.f213J0]);
                    } else {
                        this.f217U2[this.f222a8] = this.f210EQ.j6(i, true, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f215Mr[this.f213J0]);
                    }
                }
                mo563j6(i);
                return;
            }
            if (this.f218VH) {
                this.f222a8++;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr2 = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr2, 0, this.f217U2.length);
                    this.f217U2 = iArr2;
                }
                if (this.f211FH.we(this.f229we)) {
                    this.f217U2[this.f222a8] = this.f210EQ.j6(this.f229we, false, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f223aM[this.f213J0], this.f215Mr[this.f213J0]);
                } else {
                    this.f217U2[this.f222a8] = this.f210EQ.j6(this.f229we, false, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f215Mr[this.f213J0]);
                }
            }
            if (this.f213J0 < this.f214J8) {
                this.f213J0++;
                this.f229we = this.f219Ws[this.f213J0];
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -7749183810588027552L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -366642762537592224L)
    protected void m575Hw(int i, int i2) {
        try {
            if (f209j6) {
                wu.j6(-5771426013190878856L, this, new Integer(i), new Integer(i2));
            }
            m581j6(i, false, i2);
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -5771426013190878856L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = 4384934834712854128L)
    protected void m576VH(int i) {
        int i2;
        int i3;
        try {
            if (f209j6) {
                wu.j6(1678205529904752552L, this, i);
            }
            if (this.f226tp) {
                if (this.f213J0 > 0) {
                    i2 = this.f223aM[this.f213J0 - 1];
                    i3 = this.f215Mr[this.f213J0 - 1];
                } else {
                    i2 = this.f220XL[this.f213J0];
                    i3 = this.f225j3[this.f213J0];
                }
                int i4 = i3 - 1;
                int i5 = i4 + 2;
                String string = this.f211FH.getString(i);
                this.f212Hw.DW(this.f210EQ.VH(), this.f210EQ.J8(), i2, i4, i2, i5, "缺少 </C>" + string + "<//C>", 1);
                int i6 = i4 + 1;
                this.f212Hw.j6(this.f210EQ.VH(), this.f210EQ.J8(), i2, i6, i2, i6, string, "插入 '" + string + "'");
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, 1678205529904752552L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 1958099669883580131L)
    protected int m577Zo() {
        try {
            if (f209j6) {
                wu.j6(1753937972425972563L, this);
            }
            return this.f217U2[this.f222a8];
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, 1753937972425972563L, this);
            }
            throw th;
        }
    }

    @su(method = -195057312006026288L)
    protected int m578Zo(int i) {
        try {
            if (f209j6) {
                wu.j6(-5609276059107571848L, this, i);
            }
            int i2 = this.f213J0 + i;
            return i2 < this.f214J8 ? this.f219Ws[i2] : this.f227u7;
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -5609276059107571848L, this, new Integer(i));
            }
            throw th;
        }
    }

    protected abstract void mo562j6();

    @su(method = 863853519216458168L)
    protected void mo563j6(int i) {
        int i2;
        int i3;
        try {
            if (f209j6) {
                wu.j6(-910837666801806960L, this, i);
            }
            if (this.f226tp) {
                if (this.f213J0 > 0) {
                    i2 = this.f223aM[this.f213J0 - 1];
                    i3 = this.f215Mr[this.f213J0 - 1];
                } else {
                    i2 = this.f220XL[this.f213J0];
                    i3 = this.f225j3[this.f213J0];
                }
                int i4 = i3 - 1;
                int i5 = i4 + 2;
                String string = this.f211FH.getString(i);
                this.f212Hw.DW(this.f210EQ.VH(), this.f210EQ.J8(), i2, i4, i2, i5, "缺少 </C>" + string + "<//C>", 0);
                int i6 = i4 + 1;
                this.f212Hw.j6(this.f210EQ.VH(), this.f210EQ.J8(), i2, i6, i2, i6, string, "插入 '" + string + "'");
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -910837666801806960L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 268959459321191925L)
    protected void m579j6(int i, int i2) {
        try {
            if (f209j6) {
                wu.j6(-4494260712112960779L, this, new Integer(i), new Integer(i2));
            }
            if (this.f218VH) {
                this.f222a8++;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                this.f217U2[this.f222a8] = this.f210EQ.j6(i, true, i2, this.f220XL[this.f213J0], this.f225j3[this.f213J0], this.f223aM[this.f213J0], this.f215Mr[this.f213J0]);
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -4494260712112960779L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = -577752007578207501L)
    protected void m580j6(int i, int i2, int i3) {
        int i4;
        int i5;
        try {
            if (f209j6) {
                wu.j6(-3616143964656995205L, this, new Integer(i), new Integer(i2), new Integer(i3));
            }
            if (this.f218VH) {
                if (this.f213J0 > 0) {
                    i4 = this.f220XL[this.f213J0 - 1];
                    i5 = this.f215Mr[this.f213J0 - 1];
                } else {
                    i4 = this.f220XL[this.f213J0];
                    i5 = this.f225j3[this.f213J0];
                }
                int iJ6 = this.f210EQ.j6(i, false, this.f217U2, ((this.f222a8 - i3) - i2) + 1, i3, i4, i5);
                System.arraycopy(this.f217U2, (this.f222a8 - i2) + 1, this.f217U2, ((this.f222a8 - i2) - i3) + 2, i2);
                this.f222a8 = (this.f222a8 - i3) + 1;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                this.f217U2[this.f222a8 - i2] = iJ6;
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -3616143964656995205L, this, new Integer(i), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }

    @su(method = 1064440989616909593L)
    protected void m581j6(int i, boolean z, int i2) {
        int i3;
        int i4;
        try {
            if (f209j6) {
                wu.j6(7916207218309642237L, this, new Integer(i), new Boolean(z), new Integer(i2));
            }
            if (this.f218VH) {
                if (this.f213J0 > 0) {
                    i3 = this.f223aM[this.f213J0 - 1];
                    i4 = this.f215Mr[this.f213J0 - 1];
                } else {
                    i3 = this.f220XL[this.f213J0];
                    i4 = this.f225j3[this.f213J0];
                }
                int iJ6 = this.f210EQ.j6(i, z, this.f217U2, (this.f222a8 - i2) + 1, i2, i3, i4);
                this.f222a8 = (this.f222a8 - i2) + 1;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                this.f217U2[this.f222a8] = iJ6;
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, 7916207218309642237L, this, new Integer(i), new Boolean(z), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = 2329444839209796720L)
    protected void m582j6(int i, boolean z, int i2, int i3) {
        int i4;
        int i5;
        try {
            if (f209j6) {
                wu.j6(-2734554676045016088L, this, new Integer(i), new Boolean(z), new Integer(i2), new Integer(i3));
            }
            if (this.f218VH) {
                if (this.f213J0 > 0) {
                    i4 = this.f220XL[this.f213J0 - 1];
                    i5 = this.f215Mr[this.f213J0 - 1];
                } else {
                    i4 = this.f220XL[this.f213J0];
                    i5 = this.f225j3[this.f213J0];
                }
                int i6 = i4;
                int i7 = i5;
                int iJ6 = i3 != -1 ? this.f210EQ.j6(i, z, this.f217U2, (this.f222a8 - i2) + 1, i2, i6, i7, i3) : this.f210EQ.j6(i, z, this.f217U2, (this.f222a8 - i2) + 1, i2, i6, i7);
                this.f222a8 = (this.f222a8 - i2) + 1;
                if (this.f222a8 >= this.f217U2.length) {
                    int[] iArr = new int[(this.f217U2.length * 2) + 1];
                    System.arraycopy(this.f217U2, 0, iArr, 0, this.f217U2.length);
                    this.f217U2 = iArr;
                }
                this.f217U2[this.f222a8] = iJ6;
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -2734554676045016088L, this, new Integer(i), new Boolean(z), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }

    public void mo564j6(Wa wa, Da da, boolean z, Sa sa) {
        try {
            if (f209j6) {
                wu.j6(-3281760867051586701L, this, wa, da, new Boolean(z), sa);
            }
            try {
                try {
                    sa.j6(wa);
                    this.f219Ws = wa.FH;
                    this.f216QX = wa.Hw;
                    this.f220XL = wa.v5;
                    this.f223aM = wa.Zo;
                    this.f225j3 = wa.VH;
                    this.f215Mr = wa.gn;
                    this.f214J8 = wa.EQ - 1;
                    this.f210EQ = sa;
                    this.f226tp = z;
                    this.f218VH = true;
                    this.f222a8 = -1;
                    this.f213J0 = 0;
                    this.f229we = this.f219Ws[0];
                    mo562j6();
                    sa.DW(this.f217U2[0]);
                    if (this.f222a8 != 0) {
                        throw new RuntimeException("Corrupted syntax tree " + this.f222a8 + "  Bottom-most syntaxtag: " + sa.P8(this.f217U2[1]));
                    }
                    this.f210EQ = null;
                    this.f219Ws = null;
                    this.f216QX = null;
                    this.f220XL = null;
                    this.f223aM = null;
                    this.f225j3 = null;
                } catch (a unused) {
                    sa.DW(sa.j6(this.f224gn, true, new int[0], 0, 0, 1, 1));
                    this.f210EQ = null;
                    this.f219Ws = null;
                    this.f216QX = null;
                    this.f220XL = null;
                    this.f223aM = null;
                    this.f225j3 = null;
                }
                this.f215Mr = null;
            } catch (Throwable th) {
                this.f210EQ = null;
                this.f219Ws = null;
                this.f216QX = null;
                this.f220XL = null;
                this.f223aM = null;
                this.f225j3 = null;
                this.f215Mr = null;
                throw th;
            }
        } catch (Throwable th2) {
            if (f208DW) {
                wu.j6(th2, -3281760867051586701L, this, wa, da, new Boolean(z), sa);
            }
            throw th2;
        }
    }

    @su(method = 1896356021634659457L)
    protected void mo565j6(String str) {
        int i;
        int i2;
        try {
            if (f209j6) {
                wu.j6(-4405401829567086295L, this, str);
            }
            if (this.f226tp) {
                if (this.f213J0 > 0) {
                    i = this.f223aM[this.f213J0 - 1];
                    i2 = this.f215Mr[this.f213J0 - 1];
                } else {
                    i = this.f220XL[this.f213J0];
                    i2 = this.f225j3[this.f213J0];
                }
                int i3 = i2 - 1;
                int i4 = i;
                this.f212Hw.DW(this.f210EQ.VH(), this.f210EQ.J8(), i4, i3, i4, i3 + 2, str, 0);
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -4405401829567086295L, this, str);
            }
            throw th;
        }
    }

    @su(method = -757368751391587205L)
    protected void m583v5() {
        try {
            if (f209j6) {
                wu.j6(211340623713319919L, this);
            }
            if (this.f213J0 < this.f214J8) {
                this.f213J0++;
                this.f229we = this.f219Ws[this.f213J0];
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, 211340623713319919L, this);
            }
            throw th;
        }
    }

    @su(method = 1653945322325760596L)
    protected void m584v5(int i) {
        try {
            if (f209j6) {
                wu.j6(-580628100788316288L, this, i);
            }
            if (this.f229we != i) {
                mo563j6(i);
            } else if (this.f213J0 < this.f214J8) {
                this.f213J0++;
                this.f229we = this.f219Ws[this.f213J0];
            }
        } catch (Throwable th) {
            if (f208DW) {
                wu.j6(th, -580628100788316288L, this, new Integer(i));
            }
            throw th;
        }
    }
}
