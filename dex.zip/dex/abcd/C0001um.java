package abcd;

public final class C0001um extends zm {
    public C0001um(Jr jr, int i) {
        super("RuntimeVisibleAnnotations", jr, i);
    }
}
