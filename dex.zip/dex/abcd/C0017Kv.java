package abcd;

import com.android.installreferrer.api.b;
import com.android.installreferrer.api.d;
import com.android.installreferrer.api.e;
import com.appfour.backbone.api.Api;
import com.appfour.backbone.api.objects.Market;
import com.appfour.backbone.api.objects.MarketReferrer;

class C0017Kv implements d {

    final b f92j6;

    C0017Kv(b bVar) {
        this.f92j6 = bVar;
    }

    public void m124j6() {
    }

    public void m125j6(int i) {
        try {
            if (i != 0) {
                if (i != 2) {
                    return;
                }
                rw.Zo();
                return;
            }
            e eVarDW = this.f92j6.DW();
            String strDW = eVarDW.DW();
            long jFH = eVarDW.FH() * 1000;
            long jJ6 = eVarDW.j6() * 1000;
            long installTime = Api.getInstallTime();
            boolean z = true;
            boolean z2 = jJ6 != 0 && jJ6 < installTime;
            if (jFH == 0 || jFH >= installTime) {
                z = false;
            }
            if (z2 && z) {
                if (jJ6 <= jFH) {
                    jJ6 = jFH + 1;
                }
            } else if (!z2 && z) {
                jJ6 = jFH + 1;
            } else if (z2) {
                jFH = jJ6 - 1;
            } else {
                jFH = installTime - 2;
                jJ6 = installTime - 1;
            }
            rw.Zo();
            wu.j6(new MarketReferrer(new Market("com.android.vending"), strDW), jFH, jJ6);
            this.f92j6.j6();
        } catch (Throwable th) {
            yw.j6("Runtime Error", th);
        }
    }
}
