package abcd;

import java.util.BitSet;

public final class C0010Ko extends ao {

    public static final ao f57DW = new C0010Ko();

    private C0010Ko() {
    }

    public BitSet m80FH(Vn vn) {
        cs csVarGn = vn.gn();
        BitSet bitSet = new BitSet(1);
        bitSet.set(0, ao.Hw(csVarGn.get(0).we()));
        return bitSet;
    }

    public boolean m81VH(Vn vn) {
        cs csVarGn = vn.gn();
        if (!(vn instanceof Tn) || csVarGn.size() != 1 || !ao.Hw(csVarGn.get(0).we())) {
            return false;
        }
        Ds dsWe = ((Tn) vn).we();
        if (dsWe instanceof Ds) {
            return dsWe.J8();
        }
        return false;
    }

    public String m82Zo(Vn vn) {
        return vn.gn().get(0).lg() + ", " + ao.j6(((Tn) vn).we());
    }

    public int m83j6() {
        return 3;
    }

    public String m84j6(Vn vn, boolean z) {
        return ao.j6(((Tn) vn).we(), 32);
    }

    public void m85j6(InterfaceC0057Lt interfaceC0057Lt, Vn vn) {
        cs csVarGn = vn.gn();
        ao.j6(interfaceC0057Lt, ao.j6(vn, csVarGn.get(0).we()), ((Tn) vn).we().Ws());
    }
}
