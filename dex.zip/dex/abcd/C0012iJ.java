package abcd;

public class C0012iJ {

    public static final b<C0012iJ> f42j6 = new hJ();

    private final boolean f43DW;

    private C0012iJ(gE gEVar) {
        this.f43DW = gEVar.j6("receive", "fsckobjects", false);
    }

    C0012iJ(gE gEVar, C0012iJ c0012iJ) {
        this(gEVar);
    }

    public boolean m67j6() {
        return this.f43DW;
    }
}
