package abcd;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.a;
import com.google.android.gms.common.api.f;
import com.google.android.gms.common.api.g;
import com.google.android.gms.common.internal.d;

final class C0011Qx extends a.a<com.google.android.gms.signin.internal.a, Object> {
    C0011Qx() {
    }

    public final a.f m146j6(Context context, Looper looper, d dVar, Object obj, f fVar, g gVar) {
        throw new NoSuchMethodError();
    }
}
