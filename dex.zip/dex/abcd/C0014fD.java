package abcd;

import java.io.IOException;
import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public class C0014fD extends IOException {

    private final yE f83j6;

    public C0014fD(WD wd, int i) {
        super(MessageFormat.format(JGitText.j6().missingObject, C0103hE.m523DW(i), wd.Hw()));
        this.f83j6 = null;
    }

    public C0014fD(yE yEVar, int i) {
        this(yEVar, C0103hE.m523DW(i));
    }

    public C0014fD(yE yEVar, String str) {
        super(MessageFormat.format(JGitText.j6().missingObject, str, yEVar.we()));
        this.f83j6 = yEVar.Hw();
    }

    public yE m41j6() {
        return this.f83j6;
    }
}
