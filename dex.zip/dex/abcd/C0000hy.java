package abcd;

import java.util.concurrent.Executor;

final class C0000hy<TResult> implements ny<TResult> {

    private final Object f0DW = new Object();

    private Ux<TResult> f1FH;

    private final Executor f2j6;

    public C0000hy(Executor executor, Ux<TResult> ux) {
        this.f2j6 = executor;
        this.f1FH = ux;
    }

    public final void m2j6(Yx<TResult> yx) {
        synchronized (this.f0DW) {
            if (this.f1FH == null) {
                return;
            }
            this.f2j6.execute(new RunnableC0044iy(this, yx));
        }
    }
}
