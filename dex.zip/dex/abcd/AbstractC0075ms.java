package abcd;

public abstract class AbstractC0075ms implements InterfaceC0034lu, Comparable<AbstractC0075ms> {
    protected abstract int m336DW(AbstractC0075ms abstractC0075ms);

    public abstract boolean m337Hw();

    public abstract String m338Zo();

    @Override
    public final int compareTo(AbstractC0075ms abstractC0075ms) {
        Class<?> cls = getClass();
        Class<?> cls2 = abstractC0075ms.getClass();
        return cls != cls2 ? cls.getName().compareTo(cls2.getName()) : m336DW(abstractC0075ms);
    }
}
