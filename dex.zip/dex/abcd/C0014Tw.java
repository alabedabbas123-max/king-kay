package abcd;

import org.apache.http.ConnectionReuseStrategy;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.HttpParams;

class C0014Tw extends DefaultHttpClient {

    final Ww f30j6;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    C0014Tw(Ww ww, ClientConnectionManager clientConnectionManager, HttpParams httpParams) {
        super(clientConnectionManager, httpParams);
        this.f30j6 = ww;
    }

    @Override
    protected ConnectionKeepAliveStrategy createConnectionKeepAliveStrategy() {
        return new Ww.c((Sw) null);
    }

    @Override
    protected ConnectionReuseStrategy createConnectionReuseStrategy() {
        return new Ww.b((Sw) null);
    }
}
