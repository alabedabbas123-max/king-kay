package abcd;

import java.util.Set;

public abstract class AbstractC0112BH {
    public abstract long m1023DW();

    public abstract Set<yE> m1024FH();

    public long m1025j6() {
        return 0L;
    }

    public abstract boolean m1026j6(MH mh, UH uh);
}
