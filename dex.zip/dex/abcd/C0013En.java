package abcd;

public final class C0013En {
    public static int m241j6(byte[] bArr) {
        if (bArr.length == 8 && bArr[0] == 100 && bArr[1] == 101 && bArr[2] == 120 && bArr[3] == 10 && bArr[7] == 0) {
            String str = "" + ((char) bArr[4]) + ((char) bArr[5]) + ((char) bArr[6]);
            if (str.equals("036")) {
                return 14;
            }
            if (str.equals("035")) {
                return 13;
            }
        }
        return -1;
    }

    public static String m242j6(int i) {
        return "dex\n" + (i >= 14 ? "036" : "035") + "\u0000";
    }
}
