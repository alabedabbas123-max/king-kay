package abcd;

import java.util.Comparator;

class C0012fB implements Comparator<ME> {

    final C0056gB f82j6;

    C0012fB(C0056gB c0056gB) {
        this.f82j6 = c0056gB;
    }

    @Override
    public int compare(ME me, ME me2) {
        return me.getName().compareTo(me2.getName());
    }
}
