package abcd;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;
import org.apache.http.Header;
import org.apache.http.HeaderElement;
import org.apache.http.HeaderIterator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.ParseException;
import org.apache.http.ProtocolVersion;
import org.apache.http.TokenIterator;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionRequest;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.conn.params.ConnManagerParams;
import org.apache.http.conn.routing.HttpRoute;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.entity.HttpEntityWrapper;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.message.BasicHeaderElementIterator;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HttpContext;

public abstract class AbstractC0001Ww implements InterfaceC0130Zw {

    private final C0087Yw f4DW;

    private C0044Xw f5FH;

    private String f6Hw;

    private final InterfaceC0130Zw.a f7j6;

    private HttpClient f8v5;

    private static class a extends ThreadSafeClientConnManager {
        public a(HttpParams httpParams, SchemeRegistry schemeRegistry) {
            super(httpParams, schemeRegistry);
        }

        @Override
        public ClientConnectionRequest requestConnection(HttpRoute httpRoute, Object obj) {
            e.m18j6(this, 20, 5);
            return super.requestConnection(httpRoute, obj);
        }
    }

    private static class b extends DefaultConnectionReuseStrategy {
        private b() {
        }

        b(Sw sw) {
            this();
        }

        @Override
        public boolean keepAlive(HttpResponse httpResponse, HttpContext httpContext) {
            if (httpResponse == null) {
                throw new IllegalArgumentException("HTTP response may not be null.");
            }
            if (httpContext == null) {
                throw new IllegalArgumentException("HTTP context may not be null.");
            }
            ProtocolVersion protocolVersion = httpResponse.getStatusLine().getProtocolVersion();
            Header firstHeader = httpResponse.getFirstHeader("Transfer-Encoding");
            if (firstHeader == null) {
                Header[] headers = httpResponse.getHeaders("Content-Length");
                if (headers != null && headers.length == 1) {
                    try {
                        if (Integer.parseInt(headers[0].getValue()) < 0) {
                            return false;
                        }
                    } catch (NumberFormatException unused) {
                    }
                }
                return false;
            }
            if (!"chunked".equalsIgnoreCase(firstHeader.getValue())) {
                return false;
            }
            HeaderIterator headerIterator = httpResponse.headerIterator("Connection");
            if (!headerIterator.hasNext()) {
                headerIterator = httpResponse.headerIterator("Proxy-Connection");
            }
            if (headerIterator.hasNext()) {
                try {
                    TokenIterator tokenIteratorCreateTokenIterator = createTokenIterator(headerIterator);
                    boolean z = false;
                    while (tokenIteratorCreateTokenIterator.hasNext()) {
                        String strNextToken = tokenIteratorCreateTokenIterator.nextToken();
                        if ("Close".equalsIgnoreCase(strNextToken)) {
                            return false;
                        }
                        if ("Keep-Alive".equalsIgnoreCase(strNextToken)) {
                            z = true;
                        }
                    }
                    if (z) {
                        return true;
                    }
                } catch (ParseException unused2) {
                    return false;
                }
            }
            return !protocolVersion.lessEquals(HttpVersion.HTTP_1_0);
        }
    }

    private static class c implements ConnectionKeepAliveStrategy {
        private c() {
        }

        c(Sw sw) {
            this();
        }

        @Override
        public long getKeepAliveDuration(HttpResponse httpResponse, HttpContext httpContext) {
            BasicHeaderElementIterator basicHeaderElementIterator = new BasicHeaderElementIterator(httpResponse.headerIterator("Keep-Alive"));
            long jMin = 20000;
            while (basicHeaderElementIterator.hasNext()) {
                HeaderElement headerElementNextElement = basicHeaderElementIterator.nextElement();
                String name = headerElementNextElement.getName();
                String value = headerElementNextElement.getValue();
                if (value != null && name.equalsIgnoreCase("timeout")) {
                    try {
                        jMin = Math.min(jMin, Long.parseLong(value) * 1000);
                    } catch (NumberFormatException unused) {
                    }
                }
            }
            return jMin;
        }
    }

    private static class d extends HttpEntityWrapper {
        public d(HttpEntity httpEntity) {
            super(httpEntity);
        }

        @Override
        public InputStream getContent() {
            return new GZIPInputStream(((HttpEntityWrapper) this).wrappedEntity.getContent());
        }

        @Override
        public long getContentLength() {
            return -1L;
        }
    }

    private static class e extends Thread {

        private static e f9j6;

        private final a f10DW;

        private final int f11FH;

        private final int f12Hw;

        public e(a aVar, int i, int i2) {
            this.f10DW = aVar;
            this.f11FH = i;
            this.f12Hw = i2 * 1000;
        }

        public static synchronized void m18j6(a aVar, int i, int i2) {
            if (f9j6 == null) {
                f9j6 = new e(aVar, i, i2);
                f9j6.start();
            }
        }

        @Override
        public void run() {
            while (true) {
                try {
                    synchronized (this) {
                        wait(this.f12Hw);
                    }
                    this.f10DW.closeExpiredConnections();
                    this.f10DW.closeIdleConnections(this.f11FH, TimeUnit.SECONDS);
                    synchronized (e.class) {
                        if (this.f10DW.getConnectionsInPool() == 0) {
                            f9j6 = null;
                            return;
                        }
                    }
                } catch (InterruptedException unused) {
                    f9j6 = null;
                    return;
                }
            }
        }
    }

    public AbstractC0001Ww(C0087Yw c0087Yw, InterfaceC0130Zw.a aVar) {
        this(c0087Yw, aVar, null);
    }

    public AbstractC0001Ww(C0087Yw c0087Yw, InterfaceC0130Zw.a aVar, C0044Xw c0044Xw) {
        this.f5FH = null;
        this.f6Hw = null;
        this.f8v5 = null;
        if (c0087Yw == null) {
            throw new IllegalArgumentException("'appKeyPair' must be non-null");
        }
        if (aVar == null) {
            throw new IllegalArgumentException("'type' must be non-null");
        }
        this.f4DW = c0087Yw;
        this.f7j6 = aVar;
        this.f5FH = c0044Xw;
    }

    private static String m3DW(String str) {
        try {
            return URLEncoder.encode(str, "UTF-8");
        } catch (UnsupportedEncodingException e2) {
            AssertionError assertionError = new AssertionError("UTF-8 isn't available");
            assertionError.initCause(e2);
            throw assertionError;
        }
    }

    private static String m4j6(C0087Yw c0087Yw, C0044Xw c0044Xw) {
        String str;
        StringBuilder sb = new StringBuilder();
        sb.append("OAuth oauth_version=\"1.0\"");
        sb.append(", oauth_signature_method=\"PLAINTEXT\"");
        sb.append(", oauth_consumer_key=\"");
        sb.append(m3DW(((_w) c0087Yw).j6));
        sb.append("\"");
        if (c0044Xw != null) {
            sb.append(", oauth_token=\"");
            sb.append(m3DW(((_w) c0044Xw).j6));
            sb.append("\"");
            str = m3DW(((_w) c0087Yw).DW) + "&" + m3DW(((_w) c0044Xw).DW);
        } else {
            str = m3DW(((_w) c0087Yw).DW) + "&";
        }
        sb.append(", oauth_signature=\"");
        sb.append(str);
        sb.append("\"");
        return sb.toString();
    }

    @Override
    public boolean mo5DW() {
        return (this.f5FH == null && this.f6Hw == null) ? false : true;
    }

    @Override
    public InterfaceC0130Zw.a mo6FH() {
        return this.f7j6;
    }

    @Override
    public String mo7Hw() {
        return "api.dropbox.com";
    }

    public C0044Xw m8VH() {
        return this.f5FH;
    }

    @Override
    public String mo9Zo() {
        return "api-content.dropbox.com";
    }

    @Override
    public Locale getLocale() {
        return Locale.ENGLISH;
    }

    public C0087Yw m10gn() {
        return this.f4DW;
    }

    @Override
    public synchronized InterfaceC0130Zw.b mo11j6() {
        return null;
    }

    public void m12j6(C0044Xw c0044Xw) {
        if (c0044Xw == null) {
            throw new IllegalArgumentException("'oauth1AccessToken' must be non-null");
        }
        this.f5FH = c0044Xw;
        this.f6Hw = null;
    }

    public void m13j6(String str) {
        if (str == null) {
            throw new IllegalArgumentException("'oauth2AccessToken' must be non-null");
        }
        this.f6Hw = str;
        this.f5FH = null;
    }

    @Override
    public void mo14j6(HttpRequest httpRequest) {
        String strM4j6;
        if (this.f6Hw != null) {
            strM4j6 = "Bearer " + this.f6Hw;
        } else {
            strM4j6 = m4j6(this.f4DW, this.f5FH);
        }
        httpRequest.addHeader("Authorization", strM4j6);
    }

    @Override
    public void mo15j6(HttpUriRequest httpUriRequest) {
        HttpParams params = httpUriRequest.getParams();
        HttpConnectionParams.setSoTimeout(params, 30000);
        HttpConnectionParams.setConnectionTimeout(params, 30000);
    }

    public void m16u7() {
        this.f5FH = null;
        this.f6Hw = null;
    }

    @Override
    public synchronized HttpClient mo17v5() {
        if (this.f8v5 == null) {
            BasicHttpParams basicHttpParams = new BasicHttpParams();
            ConnManagerParams.setMaxConnectionsPerRoute(basicHttpParams, new Sw(this));
            ConnManagerParams.setMaxTotalConnections(basicHttpParams, 20);
            try {
                try {
                    try {
                        try {
                            try {
                                try {
                                    Iw iw = new Iw();
                                    SchemeRegistry schemeRegistry = new SchemeRegistry();
                                    schemeRegistry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
                                    schemeRegistry.register(new Scheme("https", iw, 443));
                                    a aVar = new a(basicHttpParams, schemeRegistry);
                                    BasicHttpParams basicHttpParams2 = new BasicHttpParams();
                                    HttpConnectionParams.setConnectionTimeout(basicHttpParams2, 30000);
                                    HttpConnectionParams.setSoTimeout(basicHttpParams2, 30000);
                                    HttpConnectionParams.setSocketBufferSize(basicHttpParams2, 8192);
                                    HttpProtocolParams.setUserAgent(basicHttpParams2, "OfficialDropboxJavaSDK/" + Dw.j6);
                                    Tw tw = new Tw(this, aVar, basicHttpParams2);
                                    tw.addRequestInterceptor(new Uw(this));
                                    tw.addResponseInterceptor(new Vw(this));
                                    this.f8v5 = tw;
                                } catch (CertificateException e2) {
                                    throw new RuntimeException(e2);
                                }
                            } catch (NoSuchAlgorithmException e3) {
                                throw new RuntimeException(e3);
                            }
                        } catch (UnrecoverableKeyException e4) {
                            throw new RuntimeException(e4);
                        }
                    } catch (IOException e5) {
                        throw new RuntimeException(e5);
                    }
                } catch (KeyManagementException e6) {
                    throw new RuntimeException(e6);
                }
            } catch (KeyStoreException e7) {
                throw new RuntimeException(e7);
            }
        }
        return this.f8v5;
    }
}
