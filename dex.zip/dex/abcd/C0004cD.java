package abcd;

import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public class C0004cD extends RuntimeException {

    private yE f14j6;

    public static class a extends C0004cD {
        @Override
        public String getMessage() {
            return MessageFormat.format(JGitText.j6().largeObjectExceedsByteArray, m41DW());
        }
    }

    public static class b extends C0004cD {

        private final long f15DW;

        private final long f16FH;

        public b(long j, long j2) {
            this.f15DW = j;
            this.f16FH = j2;
        }

        @Override
        public String getMessage() {
            return MessageFormat.format(JGitText.j6().largeObjectExceedsLimit, m41DW(), Long.valueOf(this.f15DW), Long.valueOf(this.f16FH));
        }
    }

    public static class c extends C0004cD {
        public c(OutOfMemoryError outOfMemoryError) {
            initCause(outOfMemoryError);
        }

        @Override
        public String getMessage() {
            return MessageFormat.format(JGitText.j6().largeObjectOutOfMemory, m41DW());
        }
    }

    public C0004cD() {
    }

    public C0004cD(YD yd) {
        m43j6(yd);
    }

    protected String m41DW() {
        return m42j6() != null ? m42j6().we() : JGitText.j6().unknownObject;
    }

    @Override
    public String getMessage() {
        return MessageFormat.format(JGitText.j6().largeObjectException, m41DW());
    }

    public yE m42j6() {
        return this.f14j6;
    }

    public void m43j6(YD yd) {
        if (this.f14j6 == null) {
            this.f14j6 = yd.Hw();
        }
    }
}
