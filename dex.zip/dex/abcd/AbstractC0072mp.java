package abcd;

public abstract class AbstractC0072mp implements InterfaceC0034lu {

    private final int f365j6;

    public AbstractC0072mp(int i) {
        this.f365j6 = i;
    }

    public final int m334Hw() {
        return this.f365j6;
    }

    public abstract int mo209j6(jp jpVar, Lt lt, int i, int i2);
}
