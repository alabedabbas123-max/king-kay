package abcd;

enum C0012Bq extends er {
    C0012Bq(String str, int i) {
        super(str, i, (C0012Bq) null);
    }
}
