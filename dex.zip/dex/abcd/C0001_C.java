package abcd;

import java.io.IOException;
import org.eclipse.jgit.JGitText;

public class C0001_C extends IOException {
    public C0001_C() {
        super(JGitText.j6().indexWriteException);
    }
}
