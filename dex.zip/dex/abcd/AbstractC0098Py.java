package abcd;

import android.content.Context;

public abstract class AbstractC0098Py<T> implements Ry<T> {

    private final Ry<T> f479j6;

    public AbstractC0098Py(Ry<T> ry) {
        this.f479j6 = ry;
    }

    private void m572DW(Context context, T t) {
        if (t == null) {
            throw new NullPointerException();
        }
        m575j6(context, t);
    }

    protected abstract T m573j6(Context context);

    public final synchronized T m574j6(Context context, Sy<T> sy) {
        T tM573j6;
        tM573j6 = m573j6(context);
        if (tM573j6 == null) {
            tM573j6 = (T) (this.f479j6 != null ? this.f479j6.j6(context, sy) : sy.j6(context));
            m572DW(context, tM573j6);
        }
        return tM573j6;
    }

    protected abstract void m575j6(Context context, T t);
}
