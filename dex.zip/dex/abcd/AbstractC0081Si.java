package abcd;

import Si;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

@xu
public abstract class AbstractC0081Si<T extends Si<?>> {

    @ru(field = -3344617948668254421L)
    private static Map<String, Long> f391DW;

    @tu
    private static boolean f392FH;

    @uu
    private static boolean f393Hw;

    @ru(field = 1228273754641376112L)
    private static Map<String, Si<?>> f394j6;

    public String f395v5;

    static {
        try {
            wu.j6(AbstractC0081Si.class, 839444887493871625L, 839444887493871625L);
            if (f392FH) {
                wu.j6(-3194633388059074720L, (Object) null);
            }
            f394j6 = new HashMap();
            f391DW = new HashMap();
        } catch (Throwable th) {
            if (f393Hw) {
                wu.j6(th, -3194633388059074720L, (Object) null);
            }
            throw th;
        }
    }

    public AbstractC0081Si() {
        try {
            if (f392FH) {
                wu.j6(2821760026110388885L, (Object) null);
            }
        } catch (Throwable th) {
            if (f393Hw) {
                wu.j6(th, 2821760026110388885L, (Object) null);
            }
            throw th;
        }
    }

    protected abstract T m609DW(String str);

    public T m610j6(String str) {
        try {
            if (f392FH) {
                wu.j6(7000091445372223072L, this, str);
            }
            if (f394j6.containsKey(str) && f391DW.containsKey(str) && new File(str).lastModified() == f391DW.get(str).longValue()) {
                return f394j6.get(str);
            }
            try {
                AbstractC0081Si abstractC0081SiM609DW = m609DW(str);
                abstractC0081SiM609DW.f395v5 = str;
                f394j6.put(str, abstractC0081SiM609DW);
                f391DW.put(str, Long.valueOf(new File(str).lastModified()));
                return abstractC0081SiM609DW;
            } catch (Exception e) {
                e.printStackTrace();
                return this;
            }
        } catch (Throwable th) {
            if (f393Hw) {
                wu.j6(th, 7000091445372223072L, this, str);
            }
            throw th;
        }
    }
}
