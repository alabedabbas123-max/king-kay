package abcd;

import java.util.Date;
import java.util.Hashtable;
import java.util.Map;

public class C0017iO implements WN {

    private final Hashtable f52j6 = new Hashtable();

    public RM getAttributes(Map map) {
        return new RM(m76j6(map));
    }

    protected Hashtable m76j6(Map map) {
        oM oMVar;
        Hashtable hashtable = (Hashtable) this.f52j6.clone();
        if (!hashtable.containsKey(SM.j6) && (oMVar = (oM) map.get("contentType")) != null) {
            QM qm = new QM(SM.j6, new vM(oMVar));
            hashtable.put(qm.v5(), qm);
        }
        if (!hashtable.containsKey(SM.FH)) {
            QM qm2 = new QM(SM.FH, new vM(new ZM(new Date())));
            hashtable.put(qm2.v5(), qm2);
        }
        if (!hashtable.containsKey(SM.DW)) {
            QM qm3 = new QM(SM.DW, new vM(new pM((byte[]) map.get("digest"))));
            hashtable.put(qm3.v5(), qm3);
        }
        return hashtable;
    }
}
