package abcd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.util.concurrent.CopyOnWriteArrayList;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0056jJ {

    public static final WI f222DW;

    public static final WI f223FH;

    private static int[] f224Hw;

    private static final List<WeakReference<DJ>> f225j6 = new CopyOnWriteArrayList();

    private boolean f228J8;

    private boolean f229QX;

    private boolean f231Ws;

    private int f232XL;

    protected final HJ f233Zo;

    private NH f234aM;

    private AbstractC0099kI f236j3;

    protected final UE f239v5;

    private String f230VH = "git-upload-pack";

    private List<WI> f235gn = Collections.emptyList();

    private eJ f238u7 = eJ.DW;

    private boolean f237tp = true;

    private String f226EQ = "git-receive-pack";

    private List<WI> f240we = Collections.emptyList();

    private boolean f227J0 = false;

    public enum a {
        FETCH,
        PUSH;

        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            int length = aVarArrValuesCustom.length;
            a[] aVarArr = new a[length];
            System.arraycopy(aVarArrValuesCustom, 0, aVarArr, 0, length);
            return aVarArr;
        }
    }

    static {
        m300j6(zJ.Mr);
        m300j6(oJ.Mr);
        m300j6(lJ.Mr);
        m300j6(qJ.Mr);
        m300j6(GJ.a8);
        m300j6(xJ.a8);
        m300j6(xJ.U2);
        m300j6(tJ.a8);
        m290aM();
        f222DW = new WI("refs/tags/*:refs/tags/*");
        f223FH = new WI("refs/heads/*:refs/heads/*");
    }

    protected AbstractC0056jJ(UE ue, HJ hj) {
        C0012iJ c0012iJ = (C0012iJ) ue.Zo().j6(C0012iJ.f42j6);
        this.f239v5 = ue;
        this.f233Zo = hj;
        this.f231Ws = c0012iJ.m67j6();
        this.f236j3 = AbstractC0099kI.m497j6();
    }

    public static List<AbstractC0056jJ> m287DW(UE ue, XI xi, a aVar) throws C0050jD {
        List<HJ> listM299j6 = m299j6(xi, aVar);
        ArrayList arrayList = new ArrayList(listM299j6.size());
        Iterator<HJ> it = listM299j6.iterator();
        while (it.hasNext()) {
            AbstractC0056jJ abstractC0056jJM291j6 = m291j6(ue, it.next(), xi.DW());
            abstractC0056jJM291j6.m325j6(xi);
            arrayList.add(abstractC0056jJM291j6);
        }
        return arrayList;
    }

    public static List<AbstractC0056jJ> m288DW(UE ue, String str, a aVar) {
        XI xi = new XI(ue.Zo(), str);
        if (!m289DW(xi)) {
            return m287DW(ue, xi, aVar);
        }
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(m291j6(ue, new HJ(str), (String) null));
        return arrayList;
    }

    private static boolean m289DW(XI xi) {
        return xi.gn().isEmpty() && xi.Hw().isEmpty();
    }

    private static void m290aM() {
        ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        if (contextClassLoader == null) {
            contextClassLoader = AbstractC0056jJ.class.getClassLoader();
        }
        Enumeration<URL> enumerationM298j6 = m298j6(contextClassLoader);
        while (enumerationM298j6.hasMoreElements()) {
            m302j6(contextClassLoader, enumerationM298j6.nextElement());
        }
    }

    public static AbstractC0056jJ m291j6(UE ue, HJ hj, String str) throws C0050jD {
        for (WeakReference<DJ> weakReference : f225j6) {
            DJ dj = weakReference.get();
            if (dj == null) {
                f225j6.remove(weakReference);
            } else if (dj.j6(hj, ue, str)) {
                return dj.DW(hj, ue, str);
            }
        }
        throw new C0050jD(MessageFormat.format(JGitText.j6().URINotSupported, hj));
    }

    public static AbstractC0056jJ m292j6(UE ue, XI xi, a aVar) throws C0050jD {
        List<HJ> listM299j6 = m299j6(xi, aVar);
        if (listM299j6.isEmpty()) {
            throw new IllegalArgumentException(MessageFormat.format(JGitText.j6().remoteConfigHasNoURIAssociated, xi.DW()));
        }
        AbstractC0056jJ abstractC0056jJM291j6 = m291j6(ue, listM299j6.get(0), xi.DW());
        abstractC0056jJM291j6.m325j6(xi);
        return abstractC0056jJM291j6;
    }

    public static AbstractC0056jJ m293j6(UE ue, String str) {
        return m294j6(ue, str, a.FETCH);
    }

    public static AbstractC0056jJ m294j6(UE ue, String str, a aVar) {
        XI xi = new XI(ue.Zo(), str);
        return m289DW(xi) ? m291j6(ue, new HJ(str), (String) null) : m292j6(ue, xi, aVar);
    }

    private static String m295j6(String str, Collection<WI> collection) {
        for (WI wi : collection) {
            if (wi.v5(str)) {
                return wi.Hw() ? wi.DW(str).j6() : wi.j6();
            }
        }
        return null;
    }

    private static Collection<WI> m296j6(UE ue, Collection<WI> collection) {
        Map mapV5 = ue.v5();
        HashSet hashSet = new HashSet();
        for (WI wi : collection) {
            if (wi.Hw()) {
                for (ME me : mapV5.values()) {
                    if (wi.DW(me)) {
                        hashSet.add(wi.j6(me));
                    }
                }
            } else {
                hashSet.add(wi);
            }
        }
        return hashSet;
    }

    public static Collection<YI> m297j6(UE ue, Collection<WI> collection, Collection<WI> collection2) {
        if (collection2 == null) {
            collection2 = Collections.emptyList();
        }
        LinkedList linkedList = new LinkedList();
        for (WI wi : m296j6(ue, collection)) {
            String strDW = wi.DW();
            ME meJ6 = ue.j6(strDW);
            if (meJ6 != null) {
                strDW = meJ6.getName();
            }
            String str = strDW;
            String strJ6 = wi.j6();
            if (strJ6 == null) {
                strJ6 = str;
            }
            if (meJ6 != null && !strJ6.startsWith("refs/")) {
                String name = meJ6.getName();
                strJ6 = String.valueOf(name.substring(0, name.indexOf(47, 5) + 1)) + strJ6;
            }
            String str2 = strJ6;
            linkedList.add(new YI(ue, str, str2, wi.FH(), m295j6(str2, collection2), (yE) null));
        }
        return linkedList;
    }

    private static Enumeration<URL> m298j6(ClassLoader classLoader) {
        try {
            return classLoader.getResources("META-INF/services/" + AbstractC0056jJ.class.getName());
        } catch (IOException unused) {
            return new Vector().elements();
        }
    }

    private static List<HJ> m299j6(XI xi, a aVar) {
        int i = m303j6()[aVar.ordinal()];
        if (i == 1) {
            return xi.gn();
        }
        if (i != 2) {
            throw new IllegalArgumentException(aVar.toString());
        }
        List<HJ> listHw = xi.Hw();
        return listHw.isEmpty() ? xi.gn() : listHw;
    }

    public static void m300j6(DJ dj) {
        f225j6.add(0, new WeakReference<>(dj));
    }

    private static void m301j6(ClassLoader classLoader, String str) {
        try {
            for (Field field : Class.forName(str, false, classLoader).getDeclaredFields()) {
                if ((field.getModifiers() & 8) == 8 && DJ.class.isAssignableFrom(field.getType())) {
                    try {
                        DJ dj = (DJ) field.get(null);
                        if (dj != null) {
                            m300j6(dj);
                        }
                    } catch (IllegalAccessException | IllegalArgumentException unused) {
                    }
                }
            }
        } catch (ClassNotFoundException unused2) {
        }
    }

    private static void m302j6(ClassLoader classLoader, URL url) {
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(url.openStream(), "UTF-8"));
            while (true) {
                try {
                    String line = bufferedReader.readLine();
                    if (line == null) {
                        break;
                    } else if (line.length() > 0 && !line.startsWith("#")) {
                        m301j6(classLoader, line);
                    }
                } catch (IOException unused) {
                } catch (Throwable th) {
                    try {
                        bufferedReader.close();
                    } catch (IOException unused2) {
                    }
                    throw th;
                }
            }
            bufferedReader.close();
        } catch (IOException unused3) {
        }
    }

    static int[] m303j6() {
        int[] iArr = f224Hw;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[a.valuesCustom().length];
        try {
            iArr2[a.FETCH.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[a.PUSH.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        f224Hw = iArr2;
        return iArr2;
    }

    public static List<DJ> m304u7() {
        ArrayList arrayList = new ArrayList(f225j6.size());
        for (WeakReference<DJ> weakReference : f225j6) {
            DJ dj = weakReference.get();
            if (dj != null) {
                arrayList.add(dj);
            } else {
                f225j6.remove(weakReference);
            }
        }
        return Collections.unmodifiableList(arrayList);
    }

    public NI m305DW(LE le, Collection<YI> collection) throws yD {
        if (collection == null || collection.isEmpty()) {
            try {
                collection = m323j6(this.f240we);
                if (collection.isEmpty()) {
                    throw new yD(JGitText.j6().nothingToPush);
                }
            } catch (IOException e) {
                throw new yD(MessageFormat.format(JGitText.j6().problemWithResolvingPushRefSpecsLocally, e.getMessage()), e);
            }
        }
        return new MI(this, collection).j6(le);
    }

    public abstract void m306DW();

    public void m307DW(String str) {
        if (str == null || str.length() <= 0) {
            this.f230VH = "git-upload-pack";
        } else {
            this.f230VH = str;
        }
    }

    public void m308DW(boolean z) {
        this.f228J8 = z;
    }

    public boolean m309EQ() {
        return this.f231Ws;
    }

    public AbstractC0099kI m310FH() {
        return this.f236j3;
    }

    public void m311FH(boolean z) {
        this.f237tp = z;
    }

    public String m312Hw() {
        return this.f226EQ;
    }

    public void m313Hw(boolean z) {
        this.f227J0 = z;
    }

    public boolean m314J0() {
        return this.f237tp;
    }

    public boolean m315J8() {
        return this.f227J0;
    }

    public abstract nI m316QX();

    public eJ m317VH() {
        return this.f238u7;
    }

    public boolean m318Ws() {
        return this.f229QX;
    }

    public abstract LI m319XL();

    public NH m320Zo() {
        if (this.f234aM == null) {
            this.f234aM = new NH(this.f239v5);
        }
        return this.f234aM;
    }

    public int m321gn() {
        return this.f232XL;
    }

    public qI m322j6(LE le, Collection<WI> collection) throws yD {
        if (collection == null || collection.isEmpty()) {
            if (this.f235gn.isEmpty()) {
                throw new yD(JGitText.j6().nothingToFetch);
            }
            collection = this.f235gn;
        } else if (!this.f235gn.isEmpty()) {
            ArrayList arrayList = new ArrayList(collection);
            Iterator<WI> it = collection.iterator();
            while (it.hasNext()) {
                String strDW = it.next().DW();
                for (WI wi : this.f235gn) {
                    String strDW2 = wi.DW();
                    String strJ6 = wi.j6();
                    if (strDW2.equals(strDW) && strJ6 != null) {
                        arrayList.add(wi);
                        break;
                    }
                }
            }
            collection = arrayList;
        }
        qI qIVar = new qI();
        new pI(this, collection).j6(le, qIVar);
        return qIVar;
    }

    public Collection<YI> m323j6(Collection<WI> collection) {
        return m297j6(this.f239v5, collection, this.f235gn);
    }

    public void m324j6(int i) {
        this.f232XL = i;
    }

    public void m325j6(XI xi) {
        m307DW(xi.u7());
        m328j6(xi.v5());
        m326j6(xi.Zo());
        this.f235gn = xi.j6();
        this.f240we = xi.FH();
        this.f232XL = xi.VH();
    }

    public void m326j6(eJ eJVar) {
        if (eJVar == null) {
            eJVar = eJ.j6;
        }
        this.f238u7 = eJVar;
    }

    public void m327j6(AbstractC0099kI abstractC0099kI) {
        this.f236j3 = abstractC0099kI;
    }

    public void m328j6(String str) {
        if (str == null || str.length() <= 0) {
            this.f226EQ = "git-receive-pack";
        } else {
            this.f226EQ = str;
        }
    }

    public void m329j6(boolean z) {
        this.f231Ws = z;
    }

    public HJ m330tp() {
        return this.f233Zo;
    }

    public String m331v5() {
        return this.f230VH;
    }

    public void m332v5(boolean z) {
        this.f229QX = z;
    }

    public boolean m333we() {
        return this.f228J8;
    }
}
