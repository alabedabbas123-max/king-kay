package abcd;

import abcd.LD;

public abstract class AbstractC0113KD<T extends LD> {

    private UE f730j6;

    public abstract Class<T> m1041j6();

    public abstract void m1042j6(T t);

    public void m1043j6(UE ue) {
        if (this.f730j6 == null) {
            this.f730j6 = ue;
        }
    }

    public String toString() {
        String simpleName = getClass().getSimpleName();
        if (this.f730j6 == null) {
            return simpleName;
        }
        return String.valueOf(simpleName) + "[" + this.f730j6 + "]";
    }
}
