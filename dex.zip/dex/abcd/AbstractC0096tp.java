package abcd;

public abstract class AbstractC0096tp extends up {

    private final Ks f352DW;

    public AbstractC0096tp(Ks ks) {
        if (ks == null) {
            throw new NullPointerException("type == null");
        }
        this.f352DW = ks;
    }

    public final Ks m620aM() {
        return this.f352DW;
    }

    public void m621j6(jp jpVar) {
        jpVar.Ws().DW(this.f352DW);
    }
}
