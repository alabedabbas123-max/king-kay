package abcd;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.Set;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0093bH implements Iterable<b> {

    protected byte[] f422j6;

    abstract class a implements Iterator<b> {

        protected final b f425j6 = m653j6();

        protected long f423DW = 0;

        a() {
        }

        @Override
        public boolean hasNext() {
            return this.f423DW < AbstractC0093bH.this.m648j6();
        }

        protected abstract b m653j6();

        /* JADX WARN: Can't rename method to resolve collision */
        @Override
        public abstract b next();

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    public static class b {

        long f426DW;

        final uE f427j6 = new uE();

        public long m654j6() {
            return this.f426DW;
        }
    }

    public static AbstractC0093bH m641j6(File file) {
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            try {
                AbstractC0093bH abstractC0093bHM642j6 = m642j6(fileInputStream);
                try {
                    fileInputStream.close();
                } catch (IOException unused) {
                }
                return abstractC0093bHM642j6;
            } catch (IOException e) {
                IOException iOException = new IOException(MessageFormat.format(JGitText.j6().unreadablePackIndex, file.getAbsolutePath()));
                iOException.initCause(e);
                throw iOException;
            }
        } catch (Throwable th) {
            try {
                fileInputStream.close();
            } catch (IOException unused2) {
            }
            throw th;
        }
    }

    public static AbstractC0093bH m642j6(InputStream inputStream) throws IOException {
        byte[] bArr = new byte[8];
        BK.j6(inputStream, bArr, 0, bArr.length);
        if (!m643j6(bArr)) {
            return new dH(inputStream, bArr);
        }
        int iJ6 = FK.j6(bArr, 4);
        if (iJ6 == 2) {
            return new fH(inputStream);
        }
        throw new IOException(MessageFormat.format(JGitText.j6().unsupportedPackIndexVersion, Integer.valueOf(iJ6)));
    }

    private static boolean m643j6(byte[] bArr) {
        byte[] bArr2 = gH.j6;
        for (int i = 0; i < bArr2.length; i++) {
            if (bArr[i] != bArr2[i]) {
                return false;
            }
        }
        return true;
    }

    public abstract long m644DW();

    public abstract long m645DW(YD yd);

    public abstract boolean m646FH();

    public boolean m647FH(YD yd) {
        return m645DW(yd) != -1;
    }

    @Override
    public abstract Iterator<b> iterator();

    public abstract long m648j6();

    public abstract long m649j6(YD yd);

    public abstract yE m650j6(long j);

    public abstract void m651j6(Set<yE> set, WD wd, int i);

    public final yE m652v5(int i) {
        if (i >= 0) {
            return m650j6(i);
        }
        return m650j6((((long) (i >>> 1)) << 1) | ((long) (i & 1)));
    }
}
