package abcd;

public final class C0013Br {

    private static final byte[] f49j6 = new byte[255];

    static {
        int i;
        for (int i2 = 1; i2 < 255; i2++) {
            try {
                oq.a aVarJ6 = oq.j6(i2);
                mq mqVarDW = aVarJ6.DW();
                er erVarJ6 = aVarJ6.j6();
                if (mqVarDW == mq.DW) {
                    f49j6[i2] = m61j6(erVarJ6);
                } else {
                    byte bM61j6 = m61j6(erVarJ6);
                    int i3 = Ar.j6[mqVarDW.ordinal()];
                    if (i3 == 1) {
                        i = bM61j6 | 16;
                    } else if (i3 == 2) {
                        i = bM61j6 | 32;
                    } else if (i3 == 3) {
                        i = bM61j6 | 48;
                    } else {
                        if (i3 != 4) {
                            throw new RuntimeException("Unknown index type: " + mqVarDW);
                        }
                        i = bM61j6 | 64;
                    }
                    f49j6[i2] = (byte) i;
                }
            } catch (IllegalArgumentException unused) {
            }
        }
    }

    private static byte m61j6(er erVar) {
        switch (Ar.DW[erVar.ordinal()]) {
            case 1:
                throw new RuntimeException("Unexpected format");
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
                return (byte) 1;
            case 7:
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
            case 13:
            case 14:
            case 15:
            case 16:
            case 17:
                return (byte) 2;
            case 18:
            case 19:
                throw new RuntimeException("Unexpected format");
            case 20:
            case 21:
            case 22:
            case 23:
            case 24:
            case 25:
            case 26:
            case 27:
            case 28:
                return (byte) 3;
            case 29:
            case 30:
            case 31:
            case 32:
                throw new RuntimeException("Unexpected format");
            case 33:
                throw new RuntimeException("Unexpected format");
            case 34:
                throw new RuntimeException("Jumbo opcodes not supported");
            case 35:
                return (byte) 5;
            case 36:
            case 37:
                throw new RuntimeException("Jumbo opcodes not supported");
            default:
                throw new RuntimeException("Unknown opcode format");
        }
    }

    public static void m62j6(short[] sArr, yr yrVar) {
        int i;
        int i2;
        byte[] bArr = f49j6;
        int i3 = 0;
        while (i3 < sArr.length) {
            int i4 = sArr[i3] & 255;
            if (i4 == 0) {
                int i5 = sArr[i3] & 65535;
                if (i5 == 256) {
                    i = (sArr[i3 + 1] & 65535) * 2;
                } else if (i5 == 512) {
                    i2 = ((sArr[i3 + 1] & 65535) * 4) + 1;
                    i3 += i2;
                } else if (i5 == 768) {
                    i = (((sArr[i3 + 1] & 65535) * (sArr[i3 + 2] & 65535)) + 1) / 2;
                }
                i2 = i + 3;
                i3 += i2;
            } else {
                if (i4 == 27) {
                    throw new RuntimeException("Extended opcodes not supported");
                }
                if (i4 == 255) {
                    throw new RuntimeException("Extended opcodes not supported");
                }
                byte b = bArr[i4];
                if (b == 0) {
                    throw new RuntimeException("Opcode size not found for opcode " + Integer.toHexString(i4));
                }
                if (b < 15) {
                    i3 += b - 1;
                } else {
                    int i6 = b & 240;
                    if (i6 == 16) {
                        int i7 = i3 + 1;
                        sArr[i7] = (short) yrVar.tp(65535 & sArr[i7]);
                    } else if (i6 == 32) {
                        int i8 = i3 + 1;
                        sArr[i8] = (short) yrVar.u7(65535 & sArr[i8]);
                    } else if (i6 == 48) {
                        int i9 = i3 + 1;
                        sArr[i9] = (short) yrVar.Zo(65535 & sArr[i9]);
                    } else {
                        if (i6 != 64) {
                            throw new RuntimeException("Unexpected mask");
                        }
                        int i10 = i3 + 1;
                        sArr[i10] = (short) yrVar.VH(65535 & sArr[i10]);
                    }
                    i2 = (b & 15) - 1;
                    i3 += i2;
                }
            }
            i3++;
        }
    }
}
