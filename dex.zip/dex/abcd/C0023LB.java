package abcd;

import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public class C0023LB extends AbstractC0109NB {

    private InterfaceC0069ME f113DW;

    private RE.a f114j6;

    /* JADX WARN: Illegal instructions before constructor call */
    public C0023LB(String str, InterfaceC0069ME interfaceC0069ME, RE.a aVar) {
        if (aVar != null) {
            str = String.valueOf(str) + ". " + MessageFormat.format(JGitText.j6().refUpdateReturnCodeWas, aVar);
        }
        super(str);
        this.f114j6 = aVar;
        this.f113DW = interfaceC0069ME;
    }
}
