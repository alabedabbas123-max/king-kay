package abcd;

import java.util.List;

final class C0017RD implements QD {

    static final QD f111j6 = new C0017RD();

    private C0017RD() {
    }

    public List<QD> m164j6(char c) {
        return OD.j6;
    }
}
