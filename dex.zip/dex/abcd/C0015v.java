package abcd;

public class C0015v<T> extends u<T> {

    private final Object f31FH;

    public C0015v(int i) {
        super(i);
        this.f31FH = new Object();
    }

    public boolean m71j6(T t) {
        boolean zJ6;
        synchronized (this.f31FH) {
            zJ6 = super.j6(t);
        }
        return zJ6;
    }
}
