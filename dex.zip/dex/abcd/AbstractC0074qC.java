package abcd;

public abstract class AbstractC0074qC extends eC {
    public <S extends CC> kC m381DW(DC<? super S> dc, S s, S s2) {
        nC nCVar = new nC(dc, s, s2);
        mC mCVarFH = nCVar.FH();
        lC lCVarJ6 = nCVar.j6();
        lC lCVarDW = nCVar.DW();
        kC kCVar = new kC();
        mo382j6(kCVar, mCVarFH, lCVarJ6, lCVarDW, new jC(0, s.j6(), 0, s2.j6()));
        return kCVar;
    }

    public abstract <S extends CC> void mo382j6(kC kCVar, mC<S> mCVar, lC<S> lCVar, lC<S> lCVar2, jC jCVar);
}
