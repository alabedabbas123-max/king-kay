package abcd;

import java.util.Collection;
import java.util.Iterator;
import java.util.TreeMap;

public final class C0003Qp extends AbstractC0088Sp {

    private final TreeMap<C0006Qs, Pp> f11Zo;

    public C0003Qp(jp jpVar) {
        super("type_ids", jpVar, 4);
        this.f11Zo = new TreeMap<>();
    }

    public Pp m29DW(Ks ks) {
        if (ks == null) {
            throw new NullPointerException("type == null");
        }
        gn();
        C0006Qs c0006QsVH = ks.VH();
        Pp pp = this.f11Zo.get(c0006QsVH);
        if (pp != null) {
            return pp;
        }
        Pp pp2 = new Pp(ks);
        this.f11Zo.put(c0006QsVH, pp2);
        return pp2;
    }

    public Pp m30DW(C0006Qs c0006Qs) {
        if (c0006Qs == null) {
            throw new NullPointerException("type == null");
        }
        gn();
        Pp pp = this.f11Zo.get(c0006Qs);
        if (pp != null) {
            return pp;
        }
        Pp pp2 = new Pp(new Ks(c0006Qs));
        this.f11Zo.put(c0006Qs, pp2);
        return pp2;
    }

    public Collection<? extends vp> m31Hw() {
        return this.f11Zo.values();
    }

    public void m32Hw(Lt lt) {
        VH();
        int size = this.f11Zo.size();
        int iFH = size == 0 ? 0 : FH();
        if (size > 65536) {
            throw new UnsupportedOperationException("too many type ids");
        }
        if (lt.Hw()) {
            lt.j6(4, "type_ids_size:   " + Yt.gn(size));
            lt.j6(4, "type_ids_off:    " + Yt.gn(iFH));
        }
        lt.writeInt(size);
        lt.writeInt(iFH);
    }

    public int m33j6(Ks ks) {
        if (ks != null) {
            return m34j6(ks.VH());
        }
        throw new NullPointerException("type == null");
    }

    public int m34j6(C0006Qs c0006Qs) {
        if (c0006Qs == null) {
            throw new NullPointerException("type == null");
        }
        VH();
        Pp pp = this.f11Zo.get(c0006Qs);
        if (pp != null) {
            return pp.we();
        }
        throw new IllegalArgumentException("not found: " + c0006Qs);
    }

    public up m35j6(ms msVar) {
        if (msVar == null) {
            throw new NullPointerException("cst == null");
        }
        VH();
        up upVar = this.f11Zo.get(((Ks) msVar).VH());
        if (upVar != null) {
            return upVar;
        }
        throw new IllegalArgumentException("not found: " + msVar);
    }

    @Override
    protected void mo36tp() {
        Iterator<? extends vp> it = m31Hw().iterator();
        int i = 0;
        while (it.hasNext()) {
            it.next().j6(i);
            i++;
        }
    }
}
