package abcd;

public class C0023vH {

    private int f47j6 = 128;

    private long f43DW = 10485760;

    private int f44FH = 8192;

    private boolean f45Hw = false;

    private int f48v5 = 10485760;

    private int f46Zo = 52428800;

    public long m90DW() {
        return this.f43DW;
    }

    public int m91FH() {
        return this.f47j6;
    }

    public int m92Hw() {
        return this.f44FH;
    }

    public boolean m93Zo() {
        return this.f45Hw;
    }

    public int m94j6() {
        return this.f48v5;
    }

    public int m95v5() {
        return this.f46Zo;
    }
}
