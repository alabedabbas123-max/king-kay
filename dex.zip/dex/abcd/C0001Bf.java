package abcd;

import com.aide.ui.U;

@xu
public class C0001Bf implements Yl {

    @uu
    private static boolean f16DW;

    @tu
    private static boolean f17j6;

    static {
        wu.j6(C0001Bf.class, 822434286047457699L, 822434286047457699L);
    }

    public C0001Bf() {
        try {
            if (f17j6) {
                wu.j6(17448753741992001L, (Object) null);
            }
        } catch (Throwable th) {
            if (f16DW) {
                wu.j6(th, 17448753741992001L, (Object) null);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (!f17j6) {
                return true;
            }
            wu.j6(-126373416554491623L, this);
            return true;
        } catch (Throwable th) {
            if (f16DW) {
                wu.j6(th, -126373416554491623L, this);
            }
            throw th;
        }
    }

    public int m35j6() {
        try {
            if (!f17j6) {
                return com.aide.pro.R.id.mainMenuExit;
            }
            wu.j6(-2166214369910658093L, this);
            return com.aide.pro.R.id.mainMenuExit;
        } catch (Throwable th) {
            if (f16DW) {
                wu.j6(th, -2166214369910658093L, this);
            }
            throw th;
        }
    }

    public boolean m36run() {
        try {
            if (f17j6) {
                wu.j6(-611232472490858985L, this);
            }
            U.lg().gn();
            return true;
        } catch (Throwable th) {
            if (f16DW) {
                wu.j6(th, -611232472490858985L, this);
            }
            throw th;
        }
    }
}
