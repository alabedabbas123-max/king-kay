package abcd;

public class C0010Nw extends Kw {
    public C0010Nw() {
        super("Proxy may have been updated, try request again.");
    }
}
