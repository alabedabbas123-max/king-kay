package abcd;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.DataFormatException;
import java.util.zip.DeflaterOutputStream;
import java.util.zip.InflaterInputStream;

class C0021OG extends FE {

    private final long f69FH;

    private final long f70Hw;

    private final GG f71VH;

    private final aH f72Zo;

    private final int f74v5;

    private int f73j6 = -1;

    private long f68DW = -1;

    C0021OG(long j, long j2, int i, aH aHVar, GG gg) {
        this.f69FH = j;
        this.f70Hw = j2;
        this.f74v5 = i;
        this.f72Zo = aHVar;
        this.f71VH = gg;
    }

    private yE m110Zo() {
        return this.f72Zo.j6(this.f69FH);
    }

    public InputStream m113j6(wH wHVar) {
        try {
            InflaterInputStream inflaterInputStream = new InflaterInputStream(new jH(this.f72Zo, this.f69FH + ((long) this.f74v5), wHVar));
            FE feHw = this.f72Zo.Hw(wHVar, this.f70Hw);
            NG ng = new NG(this, inflaterInputStream, feHw, wHVar);
            if (this.f73j6 == -1 && !(feHw instanceof C0021OG)) {
                this.f73j6 = feHw.FH();
            }
            if (this.f68DW == -1) {
                this.f68DW = ng.DW();
            }
            return ng;
        } catch (IOException unused) {
            return wHVar.FH(m110Zo()).v5();
        }
    }

    public long m114DW() {
        if (this.f68DW == -1) {
            wH wHVar = new wH(this.f71VH);
            try {
                try {
                    this.f68DW = AH.j6(this.f72Zo.j6(wHVar, this.f69FH + ((long) this.f74v5)));
                } catch (IOException unused) {
                    this.f68DW = wHVar.FH(m110Zo()).DW();
                } catch (IOException | DataFormatException unused2) {
                }
            } finally {
                wHVar.FH();
            }
        }
        return this.f68DW;
    }

    public int m115FH() {
        if (this.f73j6 == -1) {
            wH wHVar = new wH(this.f71VH);
            try {
                try {
                    try {
                        this.f73j6 = this.f72Zo.FH(wHVar, this.f69FH);
                    } catch (IOException unused) {
                    }
                } finally {
                    wHVar.FH();
                }
            } catch (IOException unused2) {
                this.f73j6 = wHVar.FH(m110Zo()).FH();
            }
        }
        return this.f73j6;
    }

    public boolean m116Hw() {
        return true;
    }

    public byte[] m117j6() throws cD {
        try {
            throw new cD(m110Zo());
        } catch (IOException e) {
            cD cDVar = new cD();
            cDVar.initCause(e);
            throw cDVar;
        }
    }

    public JE m118v5() {
        yE yEVarM110Zo = m110Zo();
        wH wHVar = new wH(this.f71VH);
        FE feFH = this.f71VH.FH(wHVar, yEVarM110Zo.we(), yEVarM110Zo);
        if (feFH != null) {
            return feFH.v5();
        }
        BufferedInputStream bufferedInputStream = new BufferedInputStream(m113j6(wHVar), 8192);
        int iM115FH = m115FH();
        long jM114DW = m114DW();
        YG ygHw = this.f71VH.Hw();
        File fileZo = ygHw.Zo();
        DeflaterOutputStream deflaterOutputStreamJ6 = ygHw.j6(new FileOutputStream(fileZo));
        ygHw.j6(deflaterOutputStreamJ6, iM115FH, jM114DW);
        return new MG(this, iM115FH, jM114DW, new ZK(bufferedInputStream, deflaterOutputStreamJ6), ygHw, wHVar, fileZo, yEVarM110Zo);
    }
}
