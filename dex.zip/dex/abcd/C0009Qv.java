package abcd;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;
import android.os.Handler;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.RecyclerView;
import android.util.Pair;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import com.appfour.backbone.api.objects.UserActionWidget;
import com.appfour.backbone.api.objects.UserActionWindow;
import com.appfour.backbone.api.objects.UserInputAction;
import com.appfour.backbone.api.objects.UserTouchAction;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class C0009Qv {

    public static int f72DW;

    private static boolean f73FH;

    private static Map<Integer, c> f74Hw = new HashMap();

    public static boolean f75j6;

    private static class a {

        private final int f76DW;

        private final int f77FH;

        private final Handler f78Hw = new Handler();

        private float f79VH;

        private float f80Zo;

        private boolean f81gn;

        private final UserActionWindow f82j6;

        private final Runnable f83v5;

        public a(UserActionWindow userActionWindow) {
            this.f82j6 = userActionWindow;
            this.f83v5 = new Pv(this, userActionWindow);
            int i = (int) (userActionWindow.getContext().getResources().getDisplayMetrics().density * 12.0f);
            this.f76DW = i * i;
            this.f77FH = ViewConfiguration.getLongPressTimeout();
        }

        public static boolean m120DW(View view) {
            if (!view.isShown()) {
                return false;
            }
            Activity activityM122j6 = m122j6(view.getContext());
            return activityM122j6 == null || activityM122j6.getWindow().getDecorView().isShown();
        }

        private static Activity m122j6(Context context) {
            if (context instanceof Activity) {
                return (Activity) context;
            }
            if (context instanceof ContextWrapper) {
                return m122j6(((ContextWrapper) context).getBaseContext());
            }
            return null;
        }

        public void m126DW(MotionEvent motionEvent) {
            if (motionEvent.getActionMasked() == 0) {
                this.f80Zo = motionEvent.getX();
                this.f79VH = motionEvent.getY();
                this.f81gn = true;
                this.f78Hw.postDelayed(this.f83v5, this.f77FH);
                return;
            }
            if (motionEvent.getActionMasked() != 1) {
                if (motionEvent.getActionMasked() == 3) {
                    this.f78Hw.removeCallbacks(this.f83v5);
                    return;
                } else {
                    if (motionEvent.getActionMasked() != 2 || ((motionEvent.getX() - this.f80Zo) * (motionEvent.getX() - this.f80Zo)) + ((motionEvent.getY() - this.f79VH) * (motionEvent.getY() - this.f79VH)) < this.f76DW) {
                        return;
                    }
                    this.f78Hw.removeCallbacks(this.f83v5);
                    return;
                }
            }
            this.f78Hw.removeCallbacks(this.f83v5);
            if (this.f81gn) {
                this.f81gn = false;
                float x = (motionEvent.getX() - this.f80Zo) * (motionEvent.getX() - this.f80Zo);
                float y = motionEvent.getY() - this.f79VH;
                float y2 = motionEvent.getY();
                float f = this.f79VH;
                if (x + (y * (y2 - f)) >= this.f76DW) {
                    e.m145j6(this.f82j6, this.f80Zo, f, motionEvent.getX(), motionEvent.getY());
                } else {
                    e.m144j6(this.f82j6, this.f80Zo, f);
                }
            }
        }

        public void m127j6(MotionEvent motionEvent) {
            m126DW(motionEvent);
        }
    }

    private static class b implements View.OnTouchListener {

        private final a f84j6;

        public b(PopupWindow popupWindow, UserActionWindow userActionWindow) {
            this.f84j6 = new a(userActionWindow);
        }

        public static View.OnTouchListener m128j6(PopupWindow popupWindow) {
            try {
                Field declaredField = PopupWindow.class.getDeclaredField("mTouchInterceptor");
                declaredField.setAccessible(true);
                return (View.OnTouchListener) declaredField.get(popupWindow);
            } catch (Throwable th) {
                yw.j6("Runtime Error", th);
                return null;
            }
        }

        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            try {
                this.f84j6.m126DW(motionEvent);
                return false;
            } catch (Throwable th) {
                yw.j6("Runtime Error", th);
                return false;
            }
        }
    }

    private static class c extends FrameLayout {

        private a f85j6;

        @Override
        public boolean dispatchTouchEvent(MotionEvent motionEvent) {
            a aVar = this.f85j6;
            if (aVar != null) {
                aVar.m126DW(motionEvent);
            }
            return getChildAt(0).dispatchTouchEvent(motionEvent);
        }

        public void m129j6(UserActionWindow userActionWindow) {
            this.f85j6 = new a(userActionWindow);
        }

        @Override
        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            ((ViewGroup) getChildAt(0)).onInterceptTouchEvent(motionEvent);
            return true;
        }
    }

    static class d implements Window.Callback {

        private final Window.Callback f86DW;

        private final UserActionWindow f87FH;

        private final a f88j6;

        public d(Window window, UserActionWindow userActionWindow) {
            this.f86DW = window.getCallback();
            this.f88j6 = new a(userActionWindow);
            this.f87FH = userActionWindow;
            if (userActionWindow.getType() == 0) {
                window.getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserverOnGlobalLayoutListenerC0051Rv(this));
                m130j6();
            }
        }

        public void m130j6() {
            try {
                InputMethodManager inputMethodManager = (InputMethodManager) this.f87FH.getWindowView().getContext().getSystemService("input_method");
                Method declaredMethod = inputMethodManager.getClass().getDeclaredMethod("getInputMethodWindowVisibleHeight", new Class[0]);
                boolean z = true;
                declaredMethod.setAccessible(true);
                Integer num = (Integer) declaredMethod.invoke(inputMethodManager, new Object[0]);
                C0009Qv.f72DW = num.intValue();
                if (num.intValue() <= 0) {
                    z = false;
                }
                if (C0009Qv.f75j6 != z) {
                    C0009Qv.f75j6 = z;
                    if (C0009Qv.f75j6) {
                        C0009Qv.m104Hw(this.f87FH);
                    } else {
                        C0009Qv.m99FH(this.f87FH);
                    }
                }
            } catch (Exception unused) {
            }
        }

        @Override
        public boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
            try {
                this.f88j6.m127j6(motionEvent);
            } catch (Throwable th) {
                yw.j6("Runtime Error", th);
            }
            return this.f86DW.dispatchGenericMotionEvent(motionEvent);
        }

        @Override
        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            UserActionWindow userActionWindowGn;
            if (keyEvent.getAction() == 1 && this.f87FH.getActivity() != null && (userActionWindowGn = Hv.gn()) != null) {
                C0009Qv.m100FH(new UserInputAction(userActionWindowGn, keyEvent.getKeyCode() == 4));
            }
            return this.f86DW.dispatchKeyEvent(keyEvent);
        }

        @Override
        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return this.f86DW.dispatchKeyShortcutEvent(keyEvent);
        }

        @Override
        public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            return this.f86DW.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }

        @Override
        public boolean dispatchTouchEvent(MotionEvent motionEvent) {
            try {
                this.f88j6.m126DW(motionEvent);
            } catch (Throwable th) {
                yw.j6("Runtime Error", th);
            }
            return this.f86DW.dispatchTouchEvent(motionEvent);
        }

        @Override
        public boolean dispatchTrackballEvent(MotionEvent motionEvent) {
            return this.f86DW.dispatchTrackballEvent(motionEvent);
        }

        @Override
        public void onActionModeFinished(ActionMode actionMode) {
            this.f86DW.onActionModeFinished(actionMode);
        }

        @Override
        public void onActionModeStarted(ActionMode actionMode) {
            this.f86DW.onActionModeStarted(actionMode);
        }

        @Override
        public void onAttachedToWindow() {
            this.f86DW.onAttachedToWindow();
        }

        @Override
        public void onContentChanged() {
            this.f86DW.onContentChanged();
        }

        @Override
        public boolean onCreatePanelMenu(int i, Menu menu) {
            return this.f86DW.onCreatePanelMenu(i, menu);
        }

        @Override
        public View onCreatePanelView(int i) {
            return this.f86DW.onCreatePanelView(i);
        }

        @Override
        public void onDetachedFromWindow() {
            this.f86DW.onDetachedFromWindow();
        }

        @Override
        public boolean onMenuItemSelected(int i, MenuItem menuItem) {
            return this.f86DW.onMenuItemSelected(i, menuItem);
        }

        @Override
        public boolean onMenuOpened(int i, Menu menu) {
            return this.f86DW.onMenuOpened(i, menu);
        }

        @Override
        public void onPanelClosed(int i, Menu menu) {
            this.f86DW.onPanelClosed(i, menu);
        }

        @Override
        public void onPointerCaptureChanged(boolean z) {
            this.f86DW.onPointerCaptureChanged(z);
        }

        @Override
        public boolean onPreparePanel(int i, View view, Menu menu) {
            return this.f86DW.onPreparePanel(i, view, menu);
        }

        @Override
        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i) {
            this.f86DW.onProvideKeyboardShortcuts(list, menu, i);
        }

        @Override
        public boolean onSearchRequested() {
            return this.f86DW.onSearchRequested();
        }

        @Override
        public boolean onSearchRequested(SearchEvent searchEvent) {
            return this.f86DW.onSearchRequested(searchEvent);
        }

        @Override
        public void onWindowAttributesChanged(WindowManager.LayoutParams layoutParams) {
            this.f86DW.onWindowAttributesChanged(layoutParams);
        }

        @Override
        public void onWindowFocusChanged(boolean z) {
            this.f86DW.onWindowFocusChanged(z);
        }

        @Override
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            return this.f86DW.onWindowStartingActionMode(callback);
        }

        @Override
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i) {
            return this.f86DW.onWindowStartingActionMode(callback, i);
        }
    }

    private static class e {
        private static float m132DW(View view, View view2) {
            if (view2 == view) {
                return 0.0f;
            }
            return view2.getY() + m132DW(view, (View) view2.getParent());
        }

        private static MenuItem m133DW(View view) {
            try {
                if (view instanceof MenuView.ItemView) {
                    return ((MenuView.ItemView) view).getItemData();
                }
            } catch (Throwable unused) {
            }
            try {
                Class<?> cls = Class.forName("com.android.internal.view.menu.MenuView$ItemView");
                if (cls.isInstance(view)) {
                    return (MenuItem) cls.getDeclaredMethod("getItemData", new Class[0]).invoke(view, new Object[0]);
                }
                return null;
            } catch (Throwable unused2) {
                return null;
            }
        }

        private static View m134DW(View view, float f, float f2) {
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                View view2 = null;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    View childAt = viewGroup.getChildAt(i);
                    View viewM134DW = m134DW(childAt, (f - childAt.getX()) + childAt.getScrollX(), (f2 - childAt.getY()) + childAt.getScrollY());
                    if (viewM134DW != null && (view2 == null || m138FH(viewM134DW, view2))) {
                        view2 = viewM134DW;
                    }
                }
                if (view2 != null) {
                    return view2;
                }
            }
            if (!view.isClickable() || f < 0.0f || f2 < 0.0f || f > view.getWidth() || f2 > view.getHeight() || !view.isShown()) {
                return null;
            }
            return view;
        }

        public static void m135DW(UserActionWindow userActionWindow, float f, float f2) {
            View viewM137FH = m137FH(userActionWindow.getWindowView(), f, f2);
            if (viewM137FH == null) {
                int i = (int) f;
                int i2 = (int) f2;
                C0009Qv.m105Hw(new UserTouchAction(userActionWindow, (UserActionWidget) null, 2, i, i2, i, i2));
                return;
            }
            Pair<Integer, View> pairM140j6 = m140j6(userActionWindow.getWindowView(), f, f2, viewM137FH);
            if (pairM140j6 != null) {
                int i3 = (int) f;
                int i4 = (int) f2;
                C0009Qv.m107Hw(new UserTouchAction(userActionWindow, new UserActionWidget(viewM137FH, ((Integer) pairM140j6.first).intValue(), (View) pairM140j6.second), 3, i3, i4, i3, i4), viewM137FH, m143j6(viewM137FH), ((Integer) pairM140j6.first).intValue(), (View) pairM140j6.second);
                return;
            }
            Pair<? extends View, Integer> pairM136FH = m136FH(viewM137FH);
            if (pairM136FH == null) {
                int i5 = (int) f;
                int i6 = (int) f2;
                C0009Qv.m106Hw(new UserTouchAction(userActionWindow, new UserActionWidget(viewM137FH, 0, (View) null), 4, i5, i6, i5, i6), viewM137FH);
            } else {
                int i7 = (int) f;
                int i8 = (int) f2;
                UserTouchAction userTouchAction = new UserTouchAction(userActionWindow, new UserActionWidget(viewM137FH, ((Integer) pairM136FH.second).intValue(), (View) pairM136FH.first), 3, i7, i8, i7, i8);
                Object obj = pairM136FH.first;
                C0009Qv.m107Hw(userTouchAction, (View) obj, m143j6((View) obj), ((Integer) pairM136FH.second).intValue(), viewM137FH);
            }
        }

        private static Pair<? extends View, Integer> m136FH(View view) {
            try {
                Pair pairM141j6 = m141j6(view, RecyclerView.class);
                if (pairM141j6 == null) {
                    return null;
                }
                return new Pair<>(pairM141j6.first, Integer.valueOf(((RecyclerView) pairM141j6.first).getChildAdapterPosition((View) pairM141j6.second)));
            } catch (Throwable unused) {
                return null;
            }
        }

        private static View m137FH(View view, float f, float f2) {
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                View view2 = null;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    View childAt = viewGroup.getChildAt(i);
                    View viewM134DW = m134DW(childAt, (f - childAt.getX()) + childAt.getScrollX(), (f2 - childAt.getY()) + childAt.getScrollY());
                    if (viewM134DW != null && (view2 == null || m138FH(viewM134DW, view2))) {
                        view2 = viewM134DW;
                    }
                }
                if (view2 != null) {
                    return view2;
                }
            }
            if (!view.isLongClickable() || f < 0.0f || f2 < 0.0f || f > view.getWidth() || f2 > view.getHeight() || !view.isShown()) {
                return null;
            }
            return view;
        }

        private static boolean m138FH(View view, View view2) {
            return (Build.VERSION.SDK_INT >= 21 && view.getElevation() > view2.getElevation()) || view.getWidth() * view.getHeight() < view2.getWidth() * view2.getHeight();
        }

        private static float m139j6(View view, View view2) {
            if (view2 == view) {
                return 0.0f;
            }
            return view2.getX() + m139j6(view, (View) view2.getParent());
        }

        private static Pair<Integer, View> m140j6(View view, float f, float f2, View view2) {
            if (!(view2 instanceof ListView)) {
                return null;
            }
            float fM139j6 = f - m139j6(view, view2);
            float fM132DW = f2 - m132DW(view, view2);
            int iPointToPosition = ((ListView) view2).pointToPosition((int) fM139j6, (int) fM132DW);
            if (iPointToPosition == -1) {
                return null;
            }
            return new Pair<>(Integer.valueOf(iPointToPosition), m142j6(view2, fM139j6, fM132DW));
        }

        private static <V extends View> Pair<V, View> m141j6(View view, Class<V> cls) {
            Object parent = view.getParent();
            if (cls.isInstance(parent)) {
                return new Pair<>((View) parent, view);
            }
            if (parent instanceof View) {
                return m141j6((View) parent, cls);
            }
            return null;
        }

        private static View m142j6(View view, float f, float f2) {
            if (!(view instanceof ViewGroup)) {
                return null;
            }
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                View childAt = viewGroup.getChildAt(i);
                if (childAt.getX() <= f && childAt.getX() + childAt.getWidth() >= f && childAt.getY() <= f2 && childAt.getY() + childAt.getHeight() >= f2) {
                    return childAt;
                }
            }
            return null;
        }

        private static Object m143j6(View view) {
            if (view instanceof AdapterView) {
                return ((AdapterView) view).getAdapter();
            }
            try {
                if (view instanceof RecyclerView) {
                    return ((RecyclerView) view).getAdapter();
                }
                return null;
            } catch (Throwable unused) {
                return null;
            }
        }

        public static void m144j6(UserActionWindow userActionWindow, float f, float f2) {
            View viewM134DW = m134DW(userActionWindow.getWindowView(), f, f2);
            if (viewM134DW == null) {
                int i = (int) f;
                int i2 = (int) f2;
                C0009Qv.m108Zo(new UserTouchAction(userActionWindow, (UserActionWidget) null, 0, i, i2, i, i2));
                return;
            }
            MenuItem menuItemM133DW = m133DW(viewM134DW);
            if (menuItemM133DW != null) {
                int i3 = (int) f;
                int i4 = (int) f2;
                C0009Qv.m96DW(new UserTouchAction(userActionWindow, new UserActionWidget(viewM134DW, 0, (View) null), 5, i3, i4, i3, i4), menuItemM133DW);
                return;
            }
            Pair<Integer, View> pairM140j6 = m140j6(userActionWindow.getWindowView(), f, f2, viewM134DW);
            if (pairM140j6 != null) {
                MenuItem menuItemM133DW2 = m133DW((View) pairM140j6.second);
                if (menuItemM133DW2 != null) {
                    int i5 = (int) f;
                    int i6 = (int) f2;
                    C0009Qv.m96DW(new UserTouchAction(userActionWindow, new UserActionWidget(viewM134DW, ((Integer) pairM140j6.first).intValue(), (View) pairM140j6.second), 5, i5, i6, i5, i6), menuItemM133DW2);
                    return;
                } else {
                    int i7 = (int) f;
                    int i8 = (int) f2;
                    C0009Qv.m103FH(new UserTouchAction(userActionWindow, new UserActionWidget(viewM134DW, ((Integer) pairM140j6.first).intValue(), (View) pairM140j6.second), 6, i7, i8, i7, i8), viewM134DW, m143j6(viewM134DW), ((Integer) pairM140j6.first).intValue(), (View) pairM140j6.second);
                    return;
                }
            }
            Pair<? extends View, Integer> pairM136FH = m136FH(viewM134DW);
            if (pairM136FH == null) {
                int i9 = (int) f;
                int i10 = (int) f2;
                C0009Qv.m102FH(new UserTouchAction(userActionWindow, new UserActionWidget(viewM134DW, 0, (View) null), 7, i9, i10, i9, i10), viewM134DW);
            } else {
                int i11 = (int) f;
                int i12 = (int) f2;
                UserTouchAction userTouchAction = new UserTouchAction(userActionWindow, new UserActionWidget(viewM134DW, ((Integer) pairM136FH.second).intValue(), (View) pairM136FH.first), 6, i11, i12, i11, i12);
                Object obj = pairM136FH.first;
                C0009Qv.m103FH(userTouchAction, (View) obj, m143j6((View) obj), ((Integer) pairM136FH.second).intValue(), viewM134DW);
            }
        }

        public static void m145j6(UserActionWindow userActionWindow, float f, float f2, float f3, float f4) {
            C0009Qv.m118v5(new UserTouchAction(userActionWindow, (UserActionWidget) null, 1, (int) f, (int) f2, (int) f3, (int) f4));
        }
    }

    public static void m94DW(UserInputAction userInputAction) {
        m100FH(userInputAction);
    }

    public static void m96DW(UserTouchAction userTouchAction, MenuItem menuItem) {
        kv.j6(userTouchAction);
        kv.j6(userTouchAction, menuItem);
        f73FH = false;
    }

    public static void m99FH(UserActionWindow userActionWindow) {
        kv.j6(userActionWindow);
    }

    public static void m100FH(UserInputAction userInputAction) {
        if (userInputAction.isBackKey()) {
            kv.j6(userInputAction);
            f73FH = false;
        } else {
            if (f73FH) {
                return;
            }
            kv.j6(userInputAction);
            f73FH = true;
        }
    }

    public static void m102FH(UserTouchAction userTouchAction, View view) {
        kv.j6(userTouchAction);
        kv.j6(userTouchAction, view);
        f73FH = false;
    }

    public static void m103FH(UserTouchAction userTouchAction, View view, Object obj, int i, View view2) {
        kv.j6(userTouchAction);
        kv.j6(userTouchAction, view, obj, i, view2);
        f73FH = false;
    }

    public static void m104Hw(UserActionWindow userActionWindow) {
        kv.DW(userActionWindow);
    }

    public static void m105Hw(UserTouchAction userTouchAction) {
        kv.j6(userTouchAction);
        f73FH = false;
    }

    public static void m106Hw(UserTouchAction userTouchAction, View view) {
        kv.j6(userTouchAction);
        kv.DW(userTouchAction, view);
        f73FH = false;
    }

    public static void m107Hw(UserTouchAction userTouchAction, View view, Object obj, int i, View view2) {
        kv.j6(userTouchAction);
        kv.DW(userTouchAction, view, obj, i, view2);
        f73FH = false;
    }

    public static void m108Zo(UserTouchAction userTouchAction) {
        kv.j6(userTouchAction);
        f73FH = false;
    }

    public static void m109j6(View view, UserActionWindow userActionWindow) {
        if (view instanceof c) {
            ((c) view).m129j6(userActionWindow);
        }
    }

    public static void m110j6(Window window, UserActionWindow userActionWindow) {
        if (window.getCallback() instanceof d) {
            ((d) window.getCallback()).m130j6();
        } else {
            window.setCallback(new d(window, userActionWindow));
        }
    }

    public static void m111j6(PopupWindow popupWindow, UserActionWindow userActionWindow) {
        if (b.m128j6(popupWindow) instanceof b) {
            return;
        }
        popupWindow.setTouchInterceptor(new b(popupWindow, userActionWindow));
    }

    public static void m118v5(UserTouchAction userTouchAction) {
        kv.j6(userTouchAction);
        f73FH = false;
    }
}
