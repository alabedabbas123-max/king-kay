package abcd;

public class C0023OI {

    private final yE f84DW;

    private final String f85FH;

    private b f86Hw;

    private String f87VH;

    private a f88Zo;

    private final yE f89j6;

    private ME f90v5;

    public enum a {
        NOT_ATTEMPTED,
        REJECTED_NOCREATE,
        REJECTED_NODELETE,
        REJECTED_NONFASTFORWARD,
        REJECTED_CURRENT_BRANCH,
        REJECTED_MISSING_OBJECT,
        REJECTED_OTHER_REASON,
        LOCK_FAILURE,
        OK;

        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            int length = aVarArrValuesCustom.length;
            a[] aVarArr = new a[length];
            System.arraycopy(aVarArrValuesCustom, 0, aVarArr, 0, length);
            return aVarArr;
        }
    }

    public enum b {
        CREATE,
        UPDATE,
        UPDATE_NONFASTFORWARD,
        DELETE;

        public static b[] valuesCustom() {
            b[] bVarArrValuesCustom = values();
            int length = bVarArrValuesCustom.length;
            b[] bVarArr = new b[length];
            System.arraycopy(bVarArrValuesCustom, 0, bVarArr, 0, length);
            return bVarArr;
        }
    }

    public C0023OI(yE yEVar, yE yEVar2, String str) {
        this.f89j6 = yEVar;
        this.f84DW = yEVar2;
        this.f85FH = str;
        this.f86Hw = b.UPDATE;
        if (yE.Ws().DW(yEVar)) {
            this.f86Hw = b.CREATE;
        }
        if (yE.Ws().DW(yEVar2)) {
            this.f86Hw = b.DELETE;
        }
        this.f88Zo = a.NOT_ATTEMPTED;
    }

    public yE m129DW() {
        return this.f84DW;
    }

    public yE m130FH() {
        return this.f89j6;
    }

    public ME m131Hw() {
        return this.f90v5;
    }

    public b m132VH() {
        return this.f86Hw;
    }

    public a m133Zo() {
        return this.f88Zo;
    }

    public String m134j6() {
        return this.f87VH;
    }

    void m135j6(ME me) {
        this.f90v5 = me;
    }

    public void m136j6(a aVar) {
        m137j6(aVar, null);
    }

    public void m137j6(a aVar, String str) {
        this.f88Zo = aVar;
        this.f87VH = str;
    }

    void m138j6(b bVar) {
        this.f86Hw = bVar;
    }

    public String toString() {
        return String.valueOf(m132VH().name()) + ": " + m130FH().we() + " " + m129DW().we() + " " + m139v5();
    }

    public String m139v5() {
        return this.f85FH;
    }
}
