package abcd;

public abstract class AbstractC0051vt implements lu, Cloneable {

    private bs f121DW;

    private final tt f122j6;

    public interface a {
        void mo221DW(mt mtVar);

        void mo222j6(mt mtVar);

        void mo223j6(ot otVar);
    }

    protected AbstractC0051vt(bs bsVar, tt ttVar) {
        if (ttVar == null) {
            throw new NullPointerException("block == null");
        }
        this.f122j6 = ttVar;
        this.f121DW = bsVar;
    }

    public static AbstractC0051vt m201j6(Tr tr, tt ttVar) {
        return new mt(tr, ttVar);
    }

    public tt m202DW() {
        return this.f122j6;
    }

    public abstract void m203DW(qt qtVar);

    public boolean m204DW(int i) {
        bs bsVar = this.f121DW;
        return bsVar != null && bsVar.we() == i;
    }

    public abstract boolean m205EQ();

    public bs m206FH() {
        bs bsVar = this.f121DW;
        if (bsVar == null || bsVar.Zo() == null) {
            return null;
        }
        return this.f121DW;
    }

    public boolean m207J0() {
        return false;
    }

    public boolean m208QX() {
        return false;
    }

    public abstract boolean m209XL();

    public AbstractC0051vt m610clone() {
        try {
            return (AbstractC0051vt) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("unexpected", e);
        }
    }

    public abstract Tr m210gn();

    public void m211j6(int i) {
        bs bsVar = this.f121DW;
        if (bsVar != null) {
            this.f121DW = bsVar.FH(i);
        }
    }

    public final void m212j6(Vr vr) {
        if (vr != this.f121DW.Zo()) {
            if (vr == null || !vr.equals(this.f121DW.Zo())) {
                this.f121DW = bs.FH(this.f121DW.we(), this.f121DW.getType(), vr);
            }
        }
    }

    protected void m213j6(bs bsVar) {
        if (bsVar == null) {
            throw new NullPointerException("result == null");
        }
        this.f121DW = bsVar;
    }

    public final void m214j6(qt qtVar) {
        bs bsVar = this.f121DW;
        this.f121DW = qtVar.j6(bsVar);
        this.f122j6.v5().j6(this, bsVar);
        m203DW(qtVar);
    }

    public abstract void m215j6(a aVar);

    public abstract boolean m216j6();

    public abstract Tr m217lg();

    public abstract cs m218tp();

    public bs m219u7() {
        return this.f121DW;
    }

    public abstract es m220v5();
}
