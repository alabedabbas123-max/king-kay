package abcd;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;

class C0010iH extends gH {
    C0010iH(OutputStream outputStream) {
        super(outputStream);
    }

    private void m59Hw() throws IOException {
        Iterator it = ((gH) this).Hw.iterator();
        while (it.hasNext()) {
            FK.DW(((gH) this).FH, 0, ((CI) it.next()).aM());
            ((gH) this).DW.write(((gH) this).FH, 0, 4);
        }
    }

    private void m60VH() throws IOException {
        Iterator it = ((gH) this).Hw.iterator();
        while (it.hasNext()) {
            long offset = ((CI) it.next()).getOffset();
            if (2147483647L < offset) {
                FK.j6(((gH) this).FH, 0, offset);
                ((gH) this).DW.write(((gH) this).FH, 0, 8);
            }
        }
    }

    private void m61Zo() throws IOException {
        Iterator it = ((gH) this).Hw.iterator();
        int i = 0;
        while (it.hasNext()) {
            long offset = ((CI) it.next()).getOffset();
            if (offset <= 2147483647L) {
                FK.DW(((gH) this).FH, 0, (int) offset);
            } else {
                FK.DW(((gH) this).FH, 0, i | Integer.MIN_VALUE);
                i++;
            }
            ((gH) this).DW.write(((gH) this).FH, 0, 4);
        }
    }

    private void m62v5() {
        Iterator it = ((gH) this).Hw.iterator();
        while (it.hasNext()) {
            ((CI) it.next()).j6(((gH) this).DW);
        }
    }

    protected void m63FH() throws IOException {
        j6(2);
        DW();
        m62v5();
        m59Hw();
        m61Zo();
        m60VH();
        j6();
    }
}
