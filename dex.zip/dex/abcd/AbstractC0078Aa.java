package abcd;

@xu
public abstract class AbstractC0078Aa {

    @uu
    private static boolean f255DW;

    @tu
    private static boolean f256j6;

    @ru(field = 44520228824574177L)
    private final C0121Ba f257FH;

    @ru(field = -3016463939925410483L)
    private final Ea f258Hw;

    @ru(field = -1812272055819256440L)
    private int f259v5;

    static {
        wu.j6(AbstractC0078Aa.class, 3091211355621814035L, 3091211355621814035L);
    }

    public AbstractC0078Aa(Ea ea, C0121Ba c0121Ba) {
        try {
            if (f256j6) {
                wu.j6(-5945430865859731317L, (Object) null, ea, c0121Ba);
            }
            this.f257FH = c0121Ba;
            this.f258Hw = ea;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -5945430865859731317L, (Object) null, ea, c0121Ba);
            }
            throw th;
        }
    }

    public boolean m836BT() {
        try {
            if (f256j6) {
                wu.j6(438098811500716032L, this);
            }
            return this instanceof Ka;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 438098811500716032L, this);
            }
            throw th;
        }
    }

    public String m837DW() {
        try {
            if (f256j6) {
                wu.j6(7026474921549569761L, this);
            }
            return this.f257FH.m1066DW(this);
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 7026474921549569761L, this);
            }
            throw th;
        }
    }

    public int m838EQ() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(229355711983395855L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 229355711983395855L, this);
            }
            throw th;
        }
    }

    public ua m839FH() {
        try {
            if (!f256j6) {
                return null;
            }
            wu.j6(1284381904473755928L, this);
            return null;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 1284381904473755928L, this);
            }
            throw th;
        }
    }

    public int m840Hw() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(2304186534256667555L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 2304186534256667555L, this);
            }
            throw th;
        }
    }

    public int m841J0() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(5360656096701397836L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 5360656096701397836L, this);
            }
            throw th;
        }
    }

    public int m842J8() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(-2469560169562506733L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -2469560169562506733L, this);
            }
            throw th;
        }
    }

    public boolean m843KD() {
        try {
            if (f256j6) {
                wu.j6(-2489643244220016863L, this);
            }
            return Ma.gn(m851XL()) || Ma.FH(m851XL());
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -2489643244220016863L, this);
            }
            throw th;
        }
    }

    public int m844Mr() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(4821502408814776384L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 4821502408814776384L, this);
            }
            throw th;
        }
    }

    public boolean m845P8() {
        try {
            if (f256j6) {
                wu.j6(6858308041257987237L, this);
            }
            return this instanceof Oa;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 6858308041257987237L, this);
            }
            throw th;
        }
    }

    public na m846QX() {
        try {
            if (f256j6) {
                wu.j6(-572083171358031864L, this);
            }
            return this.f258Hw.VH(this.f259v5);
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -572083171358031864L, this);
            }
            throw th;
        }
    }

    public boolean m847SI() {
        try {
            if (f256j6) {
                wu.j6(-2387113772941119165L, this);
            }
            return this instanceof Ra;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -2387113772941119165L, this);
            }
            throw th;
        }
    }

    public int m848U2() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(463451198947209300L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 463451198947209300L, this);
            }
            throw th;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    public String m849VH() {
        long jFH = -1873808331444597780;
        try {
            if (f256j6) {
                wu.j6(-1873808331444597780L, this);
            }
            if (m846QX().gn() == null) {
                return "";
            }
            jFH = m846QX().gn().FH(this);
            return jFH;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, jFH, this);
            }
            throw th;
        }
    }

    public int m850Ws() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(-86332603077239865L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -86332603077239865L, this);
            }
            throw th;
        }
    }

    public int m851XL() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(2362449499358597880L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 2362449499358597880L, this);
            }
            throw th;
        }
    }

    public Da m852Zo() {
        try {
            if (!f256j6) {
                return null;
            }
            wu.j6(-2075445635947343760L, this);
            return null;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -2075445635947343760L, this);
            }
            throw th;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    public String m853a8() {
        long jJ6 = -1238879461921243856;
        try {
            if (f256j6) {
                wu.j6(-1238879461921243856L, this);
            }
            if (m846QX().gn() == null) {
                return "";
            }
            jJ6 = m846QX().gn().j6(this);
            return jJ6;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, jJ6, this);
            }
            throw th;
        }
    }

    public int m854aM() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(-5355673430291792289L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -5355673430291792289L, this);
            }
            throw th;
        }
    }

    public boolean m855ei() {
        try {
            if (f256j6) {
                wu.j6(4718209407422905609L, this);
            }
            return this instanceof Pa;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 4718209407422905609L, this);
            }
            throw th;
        }
    }

    public boolean m856er() {
        try {
            if (f256j6) {
                wu.j6(-3173610091232860931L, this);
            }
            return m843KD();
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -3173610091232860931L, this);
            }
            throw th;
        }
    }

    public boolean m857gW() {
        try {
            if (f256j6) {
                wu.j6(5506123317957703508L, this);
            }
            return this instanceof Ja;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 5506123317957703508L, this);
            }
            throw th;
        }
    }

    public String m858gn() {
        try {
            if (f256j6) {
                wu.j6(-810787462930310400L, this);
            }
            return this.f257FH.m1082FH(this);
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -810787462930310400L, this);
            }
            throw th;
        }
    }

    public int m859j3() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(5346620395120324635L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 5346620395120324635L, this);
            }
            throw th;
        }
    }

    public int m860j6() {
        try {
            if (!f256j6) {
                return -1;
            }
            wu.j6(130865449371280995L, this);
            return -1;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 130865449371280995L, this);
            }
            throw th;
        }
    }

    @su(method = 3636350109401213020L)
    protected void m861j6(ec ecVar) {
        try {
            if (f256j6) {
                wu.j6(6019967505924994336L, this, ecVar);
            }
            this.f259v5 = ecVar.readInt();
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 6019967505924994336L, this, ecVar);
            }
            throw th;
        }
    }

    @su(method = -2634842377108876544L)
    protected void m862j6(fc fcVar) {
        try {
            if (f256j6) {
                wu.j6(-7046726584844572120L, this, fcVar);
            }
            fcVar.writeInt(this.f259v5);
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -7046726584844572120L, this, fcVar);
            }
            throw th;
        }
    }

    public void m863j6(na naVar) {
        try {
            if (f256j6) {
                wu.j6(-572014759548391831L, this, naVar);
            }
            this.f259v5 = this.f258Hw.j6(naVar);
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -572014759548391831L, this, naVar);
            }
            throw th;
        }
    }

    public boolean m864lg() {
        try {
            if (f256j6) {
                wu.j6(-1644828627261769225L, this);
            }
            return this instanceof sa;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -1644828627261769225L, this);
            }
            throw th;
        }
    }

    public boolean m865nw() {
        try {
            if (f256j6) {
                wu.j6(-1997850885849529707L, this);
            }
            return this instanceof Qa;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -1997850885849529707L, this);
            }
            throw th;
        }
    }

    public boolean m866rN() {
        try {
            if (f256j6) {
                wu.j6(212609930446551900L, this);
            }
            return this instanceof ua;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 212609930446551900L, this);
            }
            throw th;
        }
    }

    public boolean m867ro() {
        try {
            if (f256j6) {
                wu.j6(-904117650879194528L, this);
            }
            return this instanceof Ya;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -904117650879194528L, this);
            }
            throw th;
        }
    }

    public String m868tp() {
        try {
            if (!f256j6) {
                return null;
            }
            wu.j6(-30816168344222400L, this);
            return null;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -30816168344222400L, this);
            }
            throw th;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0 */
    /* JADX WARN: Type inference failed for: r0v3, types: [java.lang.String] */
    public String m869u7() {
        long jDW = 2941961060510501136;
        try {
            if (f256j6) {
                wu.j6(2941961060510501136L, this);
            }
            if (m846QX().gn() == null) {
                return "";
            }
            jDW = m846QX().gn().DW(this);
            return jDW;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, jDW, this);
            }
            throw th;
        }
    }

    public int m870v5() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(-3349419743437400857L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -3349419743437400857L, this);
            }
            throw th;
        }
    }

    public boolean m871vy() {
        try {
            if (f256j6) {
                wu.j6(1082929037224904043L, this);
            }
            return this instanceof Na;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, 1082929037224904043L, this);
            }
            throw th;
        }
    }

    public int m872we() {
        try {
            if (!f256j6) {
                return 0;
            }
            wu.j6(-4055204696803213281L, this);
            return 0;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -4055204696803213281L, this);
            }
            throw th;
        }
    }

    public boolean m873yS() {
        try {
            if (f256j6) {
                wu.j6(-1806588453531639592L, this);
            }
            return this instanceof Ia;
        } catch (Throwable th) {
            if (f255DW) {
                wu.j6(th, -1806588453531639592L, this);
            }
            throw th;
        }
    }
}
