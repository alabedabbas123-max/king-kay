package abcd;

import java.util.AbstractList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class C0008lK<T> extends AbstractList<T> {

    private int f27DW;

    private int f28FH;

    private int f29Hw;

    private T[][] f30j6;

    private T[] f31v5;

    private class a implements Iterator<T> {

        private int f32DW;

        private int f33FH;

        private T[] f34Hw;

        private int f35j6;

        private a() {
            this.f34Hw = (T[]) C0008lK.this.f30j6[0];
        }

        a(C0008lK c0008lK, a aVar) {
            this();
        }

        @Override
        public boolean hasNext() {
            return this.f35j6 < C0008lK.this.f27DW;
        }

        @Override
        public T next() {
            if (C0008lK.this.f27DW <= this.f35j6) {
                throw new NoSuchElementException();
            }
            T[] tArr = this.f34Hw;
            int i = this.f33FH;
            T t = tArr[i];
            int i2 = i + 1;
            this.f33FH = i2;
            if (i2 == 1024) {
                int i3 = this.f32DW + 1;
                this.f32DW = i3;
                if (i3 < C0008lK.this.f30j6.length) {
                    this.f34Hw = (T[]) C0008lK.this.f30j6[this.f32DW];
                } else {
                    this.f34Hw = null;
                }
                this.f33FH = 0;
            }
            this.f35j6++;
            return t;
        }

        @Override
        public void remove() {
            int i = this.f35j6;
            if (i == 0) {
                throw new IllegalStateException();
            }
            C0008lK c0008lK = C0008lK.this;
            int i2 = i - 1;
            this.f35j6 = i2;
            c0008lK.remove(i2);
            this.f32DW = C0008lK.m51u7(this.f35j6);
            this.f33FH = C0008lK.m48gn(this.f35j6);
            this.f34Hw = (T[]) C0008lK.this.f30j6[this.f32DW];
        }
    }

    public C0008lK() {
        this.f30j6 = (T[][]) m46VH(256);
        ((T[][]) this.f30j6)[0] = m49j6();
        this.f31v5 = this.f30j6[0];
    }

    public C0008lK(int i) {
        int iM51u7 = m51u7(i);
        this.f30j6 = (T[][]) m46VH(((i & 1023) != 0 || iM51u7 == 0) ? iM51u7 + 1 : iM51u7);
        ((T[][]) this.f30j6)[0] = m49j6();
        this.f31v5 = this.f30j6[0];
    }

    private void m45DW() {
        this.f28FH = m51u7(this.f27DW);
        this.f29Hw = m48gn(this.f27DW);
        this.f31v5 = this.f30j6[this.f28FH];
    }

    private static <T> T[][] m46VH(int i) {
        return (T[][]) new Object[i][];
    }

    public static final int m48gn(int i) {
        return i & 1023;
    }

    private static <T> T[] m49j6() {
        return (T[]) new Object[1024];
    }

    public static final int m51u7(int i) {
        return i >>> 10;
    }

    public void m53FH(lK<T> lKVar) {
        if (lKVar.f27DW == 0) {
            return;
        }
        for (int i = 0; i < lKVar.f28FH; i++) {
            m54j6(lKVar.f30j6[i], 0, 1024);
        }
        int i2 = lKVar.f29Hw;
        if (i2 != 0) {
            m54j6(lKVar.f31v5, 0, i2);
        }
    }

    @Override
    public void add(int i, T t) {
        int i2 = this.f27DW;
        if (i == i2) {
            add(t);
            return;
        }
        if (i < 0 || i2 < i) {
            throw new IndexOutOfBoundsException(String.valueOf(i));
        }
        add(null);
        for (int i3 = this.f27DW - 2; i <= i3; i3--) {
            set(i3 + 1, get(i3));
        }
        set(i, t);
    }

    @Override
    public boolean add(T t) {
        int i = this.f29Hw;
        if (i < 1024) {
            this.f31v5[i] = t;
            this.f29Hw = i + 1;
            this.f27DW++;
            return true;
        }
        int i2 = this.f28FH + 1;
        this.f28FH = i2;
        T[][] tArr = this.f30j6;
        if (i2 == tArr.length) {
            T[][] tArr2 = (T[][]) m46VH(tArr.length << 1);
            T[][] tArr3 = this.f30j6;
            System.arraycopy(tArr3, 0, tArr2, 0, tArr3.length);
            this.f30j6 = tArr2;
        }
        T[] tArr4 = this.f30j6[this.f28FH];
        if (tArr4 == null) {
            tArr4 = (T[]) m49j6();
            this.f30j6[this.f28FH] = tArr4;
        }
        tArr4[0] = t;
        this.f31v5 = tArr4;
        this.f29Hw = 1;
        this.f27DW++;
        return true;
    }

    @Override
    public void clear() {
        for (T[] tArr : this.f30j6) {
            if (tArr != null) {
                Arrays.fill(tArr, (Object) null);
            }
        }
        this.f27DW = 0;
        this.f28FH = 0;
        this.f29Hw = 0;
        this.f31v5 = this.f30j6[0];
    }

    @Override
    public T get(int i) {
        if (i < 0 || this.f27DW <= i) {
            throw new IndexOutOfBoundsException(String.valueOf(i));
        }
        return this.f30j6[m51u7(i)][m48gn(i)];
    }

    @Override
    public Iterator<T> iterator() {
        return new a(this, null);
    }

    public void m54j6(T[] tArr, int i, int i2) {
        while (i2 > 0) {
            int i3 = this.f29Hw;
            int iMin = Math.min(i2, 1024 - i3);
            if (iMin == 0) {
                add(tArr[i]);
                i2--;
                i++;
            } else {
                System.arraycopy(tArr, i, this.f31v5, i3, iMin);
                this.f29Hw += iMin;
                this.f27DW += iMin;
                i += iMin;
                i2 -= iMin;
            }
        }
    }

    @Override
    public T remove(int i) {
        int i2 = this.f27DW;
        if (i == i2 - 1) {
            T[] tArr = this.f30j6[m51u7(i)];
            int iM48gn = m48gn(i);
            T t = tArr[iM48gn];
            tArr[iM48gn] = null;
            this.f27DW--;
            int i3 = this.f29Hw;
            if (i3 > 0) {
                this.f29Hw = i3 - 1;
            } else {
                m45DW();
            }
            return t;
        }
        if (i < 0 || i2 <= i) {
            throw new IndexOutOfBoundsException(String.valueOf(i));
        }
        T t2 = get(i);
        while (true) {
            int i4 = this.f27DW;
            if (i >= i4 - 1) {
                set(i4 - 1, null);
                this.f27DW--;
                m45DW();
                return t2;
            }
            int i5 = i + 1;
            set(i, get(i5));
            i = i5;
        }
    }

    @Override
    public T set(int i, T t) {
        if (i < 0 || this.f27DW <= i) {
            throw new IndexOutOfBoundsException(String.valueOf(i));
        }
        T[] tArr = this.f30j6[m51u7(i)];
        int iM48gn = m48gn(i);
        T t2 = tArr[iM48gn];
        tArr[iM48gn] = t;
        return t2;
    }

    @Override
    public int size() {
        return this.f27DW;
    }
}
