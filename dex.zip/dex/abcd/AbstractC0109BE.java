package abcd;

public abstract class AbstractC0109BE implements ME {

    private final ME.a f341DW;

    private final yE f342FH;

    private final String f343j6;

    public static class a extends AbstractC0109BE {
        public a(ME.a aVar, String str, yE yEVar) {
            super(aVar, str, yEVar);
        }

        public yE m1013FH() {
            return null;
        }

        public boolean m1014Hw() {
            return true;
        }
    }

    public static class b extends AbstractC0109BE {

        private final yE f344Hw;

        public b(ME.a aVar, String str, yE yEVar, yE yEVar2) {
            super(aVar, str, yEVar);
            this.f344Hw = yEVar2;
        }

        public yE m1015FH() {
            return this.f344Hw;
        }

        public boolean m1016Hw() {
            return true;
        }
    }

    public static class c extends AbstractC0109BE {
        public c(ME.a aVar, String str, yE yEVar) {
            super(aVar, str, yEVar);
        }

        public yE m1017FH() {
            return null;
        }

        public boolean m1018Hw() {
            return false;
        }
    }

    protected AbstractC0109BE(ME.a aVar, String str, yE yEVar) {
        this.f343j6 = str;
        this.f341DW = aVar;
        this.f342FH = yEVar;
    }

    public yE m1009DW() {
        return this.f342FH;
    }

    public boolean m1010Zo() {
        return false;
    }

    public String getName() {
        return this.f343j6;
    }

    public ME getTarget() {
        return this;
    }

    public ME.a m1011j6() {
        return this.f341DW;
    }

    public String toString() {
        return "Ref[" + getName() + '=' + yE.j6(m1009DW()) + ']';
    }

    public ME m1012v5() {
        return this;
    }
}
