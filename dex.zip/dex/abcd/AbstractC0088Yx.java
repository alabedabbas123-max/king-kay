package abcd;

import java.util.concurrent.Executor;

public abstract class AbstractC0088Yx<TResult> {
    public <TContinuationResult> Yx<TContinuationResult> m540DW(Executor executor, Sx<TResult, Yx<TContinuationResult>> sx) {
        throw new UnsupportedOperationException("continueWithTask is not implemented");
    }

    public abstract TResult m541DW();

    public abstract boolean m542FH();

    public abstract boolean m543Hw();

    public <TContinuationResult> Yx<TContinuationResult> m544j6(Executor executor, Sx<TResult, TContinuationResult> sx) {
        throw new UnsupportedOperationException("continueWith is not implemented");
    }

    public Yx<TResult> m545j6(Executor executor, Tx tx) {
        throw new UnsupportedOperationException("addOnCanceledListener is not implemented");
    }

    public Yx<TResult> m546j6(Executor executor, Ux<TResult> ux) {
        throw new UnsupportedOperationException("addOnCompleteListener is not implemented");
    }

    public abstract Yx<TResult> m547j6(Executor executor, Vx vx);

    public abstract Yx<TResult> m548j6(Executor executor, Wx<? super TResult> wx);

    public abstract Exception m549j6();

    public abstract <X extends Throwable> TResult m550j6(Class<X> cls);

    public abstract boolean m551v5();
}
