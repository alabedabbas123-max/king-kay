package abcd;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import org.apache.http.HttpEntity;
import org.apache.http.entity.HttpEntityWrapper;

public abstract class AbstractC0065Fw {

    public static class a extends HttpEntityWrapper {

        private final long f361DW;

        private final AbstractC0065Fw f362j6;

        private class C0132a extends FilterOutputStream {

            private long f363DW;

            private long f364FH;

            private long f366j6;

            public C0132a(OutputStream outputStream) {
                super(outputStream);
                this.f366j6 = 0L;
                this.f363DW = 0L;
                this.f364FH = 0L;
                this.f363DW = a.this.f362j6.m653j6();
            }

            @Override
            public void write(int i) throws IOException {
                super.write(i);
                this.f364FH++;
                long jCurrentTimeMillis = System.currentTimeMillis();
                if (jCurrentTimeMillis - this.f366j6 > this.f363DW) {
                    this.f366j6 = jCurrentTimeMillis;
                    a.this.f362j6.m654j6(this.f364FH, a.this.f361DW);
                }
            }

            @Override
            public void write(byte[] bArr, int i, int i2) throws IOException {
                ((FilterOutputStream) this).out.write(bArr, i, i2);
                this.f364FH += (long) i2;
                long jCurrentTimeMillis = System.currentTimeMillis();
                if (jCurrentTimeMillis - this.f366j6 > this.f363DW) {
                    this.f366j6 = jCurrentTimeMillis;
                    a.this.f362j6.m654j6(this.f364FH, a.this.f361DW);
                }
            }
        }

        public a(HttpEntity httpEntity, AbstractC0065Fw abstractC0065Fw) {
            super(httpEntity);
            if (abstractC0065Fw == null) {
                throw new IllegalArgumentException("'listener' is null");
            }
            this.f362j6 = abstractC0065Fw;
            this.f361DW = httpEntity.getContentLength();
        }

        @Override
        public void writeTo(OutputStream outputStream) throws IOException {
            ((HttpEntityWrapper) this).wrappedEntity.writeTo(new C0132a(outputStream));
        }
    }

    public abstract long m653j6();

    public abstract void m654j6(long j, long j2);
}
