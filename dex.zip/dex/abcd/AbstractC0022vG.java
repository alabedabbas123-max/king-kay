package abcd;

public abstract class AbstractC0022vG extends yG {

    private static class a extends AbstractC0022vG {

        private final boolean f40VH;

        private final yG f41Zo;

        private final yG f42v5;

        a(yG yGVar, yG yGVar2) {
            this.f42v5 = yGVar;
            this.f41Zo = yGVar2;
            this.f40VH = this.f42v5.j6() || this.f41Zo.j6();
        }

        public yG clone() {
            return new a(this.f42v5.clone(), this.f41Zo.clone());
        }

        public boolean m88j6() {
            return this.f40VH;
        }

        public boolean m89j6(qG qGVar, dG dGVar) {
            return this.f42v5.j6(qGVar, dGVar) && this.f41Zo.j6(qGVar, dGVar);
        }

        public String toString() {
            return "(" + this.f42v5.toString() + " AND " + this.f41Zo.toString() + ")";
        }
    }

    public static yG m87j6(yG yGVar, yG yGVar2) {
        yG yGVar3 = yG.j6;
        if (yGVar == yGVar3) {
            return yGVar2;
        }
        return yGVar2 == yGVar3 ? yGVar : new a(yGVar, yGVar2);
    }
}
