package abcd;

public abstract class AbstractC0009Bn implements tn {

    private final int f44DW;

    private final Hs f45FH;

    private final pn f46Hw;

    private final Ks f47j6;

    public AbstractC0009Bn(Ks ks, int i, Hs hs, pn pnVar) {
        if (ks == null) {
            throw new NullPointerException("definingClass == null");
        }
        if (hs == null) {
            throw new NullPointerException("nat == null");
        }
        if (pnVar == null) {
            throw new NullPointerException("attributes == null");
        }
        this.f47j6 = ks;
        this.f44DW = i;
        this.f45FH = hs;
        this.f46Hw = pnVar;
    }

    public final Ks m45DW() {
        return this.f47j6;
    }

    public final Hs m46FH() {
        return this.f45FH;
    }

    public final Js m47Hw() {
        return this.f45FH.VH();
    }

    public final pn getAttributes() {
        return this.f46Hw;
    }

    public final Js getName() {
        return this.f45FH.J8();
    }

    public final int m48j6() {
        return this.f44DW;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer(100);
        stringBuffer.append(getClass().getName());
        stringBuffer.append('{');
        stringBuffer.append(this.f45FH.aM());
        stringBuffer.append('}');
        return stringBuffer.toString();
    }
}
