package abcd;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.StatFs;
import com.a4455jkjh.ndk.InstallNdk;
import com.aide.common.Xa;
import com.aide.common.h;
import com.aide.common.ma;
import com.aide.ui.U;
import com.aide.ui.aa;
import com.aide.ui.activities.o;
import com.aide.ui.build.android.Q;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

@xu
public class C0005Kj {

    @tu
    private static boolean f12DW;

    @uu
    private static boolean f13FH;

    @ru(field = -4202060075032220128L)
    private static final String[] f14j6;

    @ru(field = 989806457798188968L)
    private long f15EQ;

    @ru(field = 4433282344342142808L)
    private List<e> f16Hw;

    @ru(field = -4738582443023003125L)
    private int f17VH;

    @ru(field = 4562881294852079121L)
    private d f18Zo;

    @ru(field = 2903019151407850277L)
    private int f19gn;

    @ru(field = 742594865030139220L)
    private String f20tp;

    @ru(field = 8011871614383065288L)
    private String f21u7;

    @ru(field = 2804031065431800971L)
    private final ExecutorService f22v5;

    @xu
    private class a implements Callable<Void> {

        @uu
        private static boolean f23DW;

        @tu
        private static boolean f24j6;

        @ru(field = 3082869889477183360L)
        private Activity f25FH;

        @ru(field = -2358735417931783149L)
        private final String f26Hw;

        @ru(field = 2198247884211197952L)
        private final List<Boolean> f27VH;

        @ru(field = -3600953705733070375L)
        private final List<String> f28Zo;

        @ru(field = -2377537357297047651L)
        private final List<Boolean> f29gn;

        @vu
        final C0005Kj f30tp;

        @ru(field = -1086624133356398643L)
        private Runnable f31u7;

        @ru(field = -1070877179123963525L)
        private final List<String> f32v5;

        static {
            wu.j6(a.class, -3145251390647306304L, -3145251390647306304L);
        }

        @su(method = 24453236163896040L)
        public a(C0005Kj c0005Kj, Activity activity, List<String> list, List<String> list2, List<Boolean> list3, List<Boolean> list4, String str, Runnable runnable) {
            if (f24j6) {
                wu.j6(1974883876875097528L, (Object) null, new Object[]{c0005Kj, activity, list, list2, list3, list4, str, runnable});
            }
            this.f30tp = c0005Kj;
            this.f32v5 = list;
            this.f28Zo = list2;
            this.f27VH = list3;
            this.f29gn = list4;
            this.f26Hw = str;
            this.f25FH = activity;
            this.f31u7 = runnable;
        }

        @su(method = 1669136765763900083L)
        private void m59DW(String str, String str2) {
            try {
                if (f24j6) {
                    wu.j6(6163114749508265008L, this, str, str2);
                }
                ZipFile zipFile = new ZipFile(str2);
                try {
                    Enumeration<? extends ZipEntry> enumerationEntries = zipFile.entries();
                    ArrayList arrayList = new ArrayList();
                    while (enumerationEntries.hasMoreElements()) {
                        arrayList.add(enumerationEntries.nextElement());
                    }
                    for (int i = 0; i < arrayList.size(); i++) {
                        if (Thread.interrupted()) {
                            throw new InterruptedException();
                        }
                        ZipEntry zipEntry = (ZipEntry) arrayList.get(i);
                        File file = new File(str, zipEntry.getName());
                        if (zipEntry.isDirectory()) {
                            file.mkdirs();
                        } else if (file.exists() && zipEntry.getSize() != -1 && file.length() == zipEntry.getSize()) {
                            continue;
                        } else {
                            m62j6(str, zipEntry.getName());
                            InputStream inputStream = zipFile.getInputStream(zipEntry);
                            try {
                                FileOutputStream fileOutputStream = new FileOutputStream(file);
                                try {
                                    Xa.j6(inputStream, fileOutputStream, false);
                                    fileOutputStream.close();
                                    inputStream.close();
                                } catch (Throwable th) {
                                    fileOutputStream.close();
                                    throw th;
                                }
                            } catch (Throwable th2) {
                                inputStream.close();
                                throw th2;
                            }
                        }
                        this.f30tp.m14DW((i * 100) / arrayList.size());
                    }
                    zipFile.close();
                    new File(str2).delete();
                } catch (Throwable th3) {
                    zipFile.close();
                    throw th3;
                }
            } catch (Throwable th4) {
                if (f23DW) {
                    wu.j6(th4, 6163114749508265008L, this, str, str2);
                }
                throw th4;
            }
        }

        @su(method = -84815219172732432L)
        private void m60FH(String str, String str2) {
            try {
                if (f24j6) {
                    wu.j6(1322617374622443525L, this, str, str2);
                }
                String str3 = "";
                for (String str4 : C0005Kj.f14j6) {
                    if (str2.contains(str4)) {
                        str3 = str4;
                        break;
                    }
                }
                if (str3.isEmpty()) {
                    return;
                }
                for (String str5 : Vl.v5(str)) {
                    if (str5.contains(str3) && !str5.contains(str2)) {
                        Vl.FH(str5);
                    }
                }
            } catch (Throwable th) {
                if (f23DW) {
                    wu.j6(th, 1322617374622443525L, this, str, str2);
                }
                throw th;
            }
        }

        @su(method = -4271541019289853188L)
        private void m62j6(String str, String str2) {
            try {
                if (f24j6) {
                    wu.j6(-3941310768045594229L, this, str, str2);
                }
                new File(str, str2).getParentFile().mkdirs();
            } catch (Throwable th) {
                if (f23DW) {
                    wu.j6(th, -3941310768045594229L, this, str, str2);
                }
                throw th;
            }
        }

        @Override
        @su(method = 2343864346493592160L)
        public Void call() {
            try {
                if (f24j6) {
                    wu.j6(2173232752141261023L, this);
                }
                m63j6();
                return null;
            } catch (Throwable th) {
                if (f23DW) {
                    wu.j6(th, 2173232752141261023L, this);
                }
                throw th;
            }
        }

        @su(method = 1428980225888223099L)
        public void m63j6() {
            try {
                if (f24j6) {
                    wu.j6(1172204763922790700L, this);
                }
                if (!new File(this.f26Hw).isDirectory() && !new File(this.f26Hw).mkdirs()) {
                    throw new IOException("Could not create directory: " + this.f26Hw);
                }
                IOException e = null;
                for (int i = 0; i < this.f32v5.size(); i++) {
                    try {
                        String str = this.f32v5.get(i);
                        String str2 = this.f28Zo.get(i);
                        boolean z = true;
                        boolean z2 = this.f27VH != null && this.f27VH.get(i).booleanValue();
                        if (this.f29gn == null || !this.f29gn.get(i).booleanValue()) {
                            z = false;
                        }
                        File file = new File(new File(this.f26Hw, str2).getPath() + ".tmp");
                        int i2 = i * 100;
                        this.f30tp.m40j6("Downloading " + str2, i2 / this.f32v5.size(), 0);
                        this.f30tp.m41j6(str, file.getPath(), z2);
                        if (z) {
                            this.f30tp.m40j6("Extracting " + str2, i2 / this.f32v5.size(), 0);
                            m59DW(this.f26Hw + "/" + str2, file.getPath());
                            file.delete();
                            this.f30tp.m40j6("Removing old libraries", i2 / this.f32v5.size(), 50);
                            m60FH(this.f26Hw, str2);
                        }
                    } catch (IOException e2) {
                        e = e2;
                    }
                }
                if (e != null) {
                    throw e;
                }
                U.j6(new Jj(this));
            } catch (Throwable th) {
                if (f23DW) {
                    wu.j6(th, 1172204763922790700L, this);
                }
                throw th;
            }
        }
    }

    @xu
    class b implements Callable<Void> {

        @uu
        private static boolean f33DW;

        @tu
        private static boolean f34j6;

        @ru(field = 811756249331064113L)
        private Activity f35FH;

        @ru(field = 2048489441362397260L)
        private Runnable f36Hw;

        @vu
        final C0005Kj f37VH;

        @ru(field = 4132327847824836064L)
        private List<Be.m> f38Zo;

        @ru(field = 896385643373546748L)
        private List<Be.g> f39v5;

        static {
            wu.j6(b.class, 1775716618827084105L, 1775716618827084105L);
        }

        @su(method = 1636572046011079667L)
        public b(C0005Kj c0005Kj, Activity activity, List<Be.g> list, List<Be.m> list2, Runnable runnable) {
            try {
                if (f34j6) {
                    wu.j6(730983366186194460L, (Object) null, c0005Kj, activity, list, list2, runnable);
                }
                this.f37VH = c0005Kj;
                this.f35FH = activity;
                this.f36Hw = runnable;
                this.f39v5 = list;
                this.f38Zo = list2;
            } catch (Throwable th) {
                if (f33DW) {
                    wu.j6(th, 730983366186194460L, (Object) null, c0005Kj, activity, list, list2, runnable);
                }
                throw th;
            }
        }

        @Override
        @su(method = 2363662118935744157L)
        public Void call() {
            String str;
            String str2;
            String str3;
            ArrayList arrayList;
            Iterator<Be.g> it;
            int i;
            String strFH;
            String str4 = ".jar";
            String str5 = ".aar";
            String str6 = ".pom";
            try {
                if (f34j6) {
                    wu.j6(-1470332521460336188L, this);
                }
                ArrayList arrayList2 = new ArrayList();
                for (Be.m mVar : this.f38Zo) {
                    if (!arrayList2.contains(mVar)) {
                        arrayList2.add(mVar);
                    }
                }
                Iterator<Be.g> it2 = this.f39v5.iterator();
                boolean z = false;
                boolean z2 = false;
                int i2 = 0;
                while (it2.hasNext()) {
                    Be.g next = it2.next();
                    Iterator it3 = arrayList2.iterator();
                    while (true) {
                        if (!it3.hasNext()) {
                            String str7 = str4;
                            String str8 = str5;
                            String str9 = str6;
                            ArrayList arrayList3 = arrayList2;
                            Iterator<Be.g> it4 = it2;
                            if (!Thread.interrupted()) {
                                str6 = str9;
                                str5 = str8;
                                str4 = str7;
                                arrayList2 = arrayList3;
                                it2 = it4;
                                z = false;
                                break;
                            }
                            throw new InterruptedException();
                        }
                        Be.m mVar2 = (Be.m) it3.next();
                        try {
                            String strDW = Jk.DW(mVar2, next);
                            String strJ6 = Jk.j6(mVar2, next);
                            this.f37VH.m41j6(strDW, strJ6, z);
                            if (!new File(strJ6).exists() || (strFH = new He().j6(strJ6).FH(next.tp)) == null) {
                                str = str4;
                                str2 = str5;
                                str3 = str6;
                            } else {
                                String strDW2 = Jk.DW(mVar2, next, strFH, str6);
                                String strJ7 = Jk.j6(mVar2, next, strFH, str6);
                                String strDW3 = Jk.DW(mVar2, next, strFH, str5);
                                str3 = str6;
                                try {
                                    String strJ8 = Jk.j6(mVar2, next, strFH, str5);
                                    str2 = str5;
                                    try {
                                        String strDW4 = Jk.DW(mVar2, next, strFH, str4);
                                        String strJ9 = Jk.j6(mVar2, next, strFH, str4);
                                        str = str4;
                                        try {
                                            if ((!new File(strJ9).exists() && !new File(strJ8).exists()) || !new File(strJ7).exists()) {
                                                C0005Kj c0005Kj = this.f37VH;
                                                arrayList = arrayList2;
                                                try {
                                                    StringBuilder sb = new StringBuilder();
                                                    it = it2;
                                                    try {
                                                        sb.append(next.gn);
                                                        sb.append(":");
                                                        sb.append(next.u7);
                                                        sb.append(":");
                                                        sb.append(strFH);
                                                        String string = sb.toString();
                                                        i = i2 + 1;
                                                        try {
                                                            try {
                                                                c0005Kj.m40j6(string, (i2 * 100) / this.f39v5.size(), 0);
                                                                try {
                                                                    this.f37VH.m41j6(strDW2, strJ7, true);
                                                                    try {
                                                                        this.f37VH.m41j6(strDW3, strJ8, true);
                                                                    } catch (IOException unused) {
                                                                    }
                                                                    try {
                                                                        try {
                                                                            this.f37VH.m41j6(strDW4, strJ9, true);
                                                                        } catch (IOException unused2) {
                                                                        }
                                                                    } catch (IOException unused3) {
                                                                    }
                                                                    if ((new File(strJ9).exists() || new File(strJ8).exists()) && new File(strJ7).exists()) {
                                                                        i2 = i;
                                                                        str6 = str3;
                                                                        str5 = str2;
                                                                        str4 = str;
                                                                        arrayList2 = arrayList;
                                                                        it2 = it;
                                                                        z = false;
                                                                        z2 = true;
                                                                        break;
                                                                    }
                                                                } catch (IOException unused4) {
                                                                }
                                                            } catch (IOException unused5) {
                                                            }
                                                        } catch (IOException unused6) {
                                                        }
                                                    } catch (IOException unused7) {
                                                    }
                                                } catch (IOException unused8) {
                                                    it = it2;
                                                    str6 = str3;
                                                    str5 = str2;
                                                    str4 = str;
                                                    arrayList2 = arrayList;
                                                    it2 = it;
                                                    z = false;
                                                }
                                            }
                                            i2 = i;
                                        } catch (IOException unused9) {
                                            arrayList = arrayList2;
                                            it = it2;
                                            str6 = str3;
                                            str5 = str2;
                                            str4 = str;
                                            arrayList2 = arrayList;
                                            it2 = it;
                                            z = false;
                                        }
                                    } catch (IOException unused10) {
                                        str = str4;
                                    }
                                } catch (IOException unused11) {
                                    str = str4;
                                    str2 = str5;
                                }
                                str6 = str3;
                                str5 = str2;
                                str4 = str;
                                arrayList2 = arrayList;
                                it2 = it;
                                z = false;
                            }
                            arrayList = arrayList2;
                            it = it2;
                            i = i2;
                            i2 = i;
                        } catch (IOException unused12) {
                            str = str4;
                            str2 = str5;
                            str3 = str6;
                        }
                        str6 = str3;
                        str5 = str2;
                        str4 = str;
                        arrayList2 = arrayList;
                        it2 = it;
                        z = false;
                    }
                }
                U.j6(new RunnableC0047Lj(this, z2));
                return null;
            } catch (Throwable th) {
                if (f33DW) {
                    wu.j6(th, -1470332521460336188L, this);
                }
                throw th;
            }
        }
    }

    @xu
    class c implements Callable<Void> {

        @uu
        private static boolean f40DW;

        @tu
        private static boolean f41j6;

        @ru(field = 2925924587991985125L)
        private final File f42FH;

        @ru(field = 2031208876039285137L)
        private Activity f43Hw;

        @vu
        final C0005Kj f44v5;

        static {
            wu.j6(c.class, -765257841527394565L, -765257841527394565L);
        }

        @su(method = 1847457920836429425L)
        public c(C0005Kj c0005Kj, Activity activity, File file) {
            try {
                if (f41j6) {
                    wu.j6(7756105238798265680L, (Object) null, c0005Kj, activity, file);
                }
                this.f44v5 = c0005Kj;
                this.f42FH = file;
                this.f43Hw = activity;
            } catch (Throwable th) {
                if (f40DW) {
                    wu.j6(th, 7756105238798265680L, (Object) null, c0005Kj, activity, file);
                }
                throw th;
            }
        }

        @Override
        @su(method = -1936327786269343235L)
        public Void call() {
            try {
                if (f41j6) {
                    wu.j6(2129064633578234068L, this);
                }
                File fileFH = Q.FH();
                if (!fileFH.isDirectory() && !fileFH.mkdirs()) {
                    throw new IOException("Could not create directory: " + fileFH.getPath());
                }
                this.f44v5.m40j6("Installing NDK support (might take several minutes)", 0, 0);
                String path = new File(fileFH, "busybox").getPath();
                C0005Kj.m16DW(this.f43Hw, "busybox", path);
                File file = new File(this.f42FH, "ndkinstall.sh");
                C0005Kj.m16DW(this.f43Hw, "ndkinstall.sh", file.getPath());
                this.f44v5.m39j6(path);
                List listAsList = Arrays.asList(path, "ash", file.getPath(), Q.v5());
                if (Thread.interrupted()) {
                    throw new InterruptedException();
                }
                Pl plJ6 = Rl.j6(listAsList, fileFH.getPath(), (Map) null, true, (OutputStream) null, (byte[]) null);
                if (plJ6.DW() != 0) {
                    throw new IOException(this.f44v5.m27j6(plJ6.j6(), plJ6.DW()));
                }
                file.delete();
                U.j6(new RunnableC0133Nj(this));
                return null;
            } catch (Throwable th) {
                if (f40DW) {
                    wu.j6(th, 2129064633578234068L, this);
                }
                throw th;
            }
        }
    }

    @xu
    private class d extends FutureTask<Void> {

        @uu
        private static boolean f45DW;

        @tu
        private static boolean f46j6;

        @ru(field = 2880281372734206215L)
        private Activity f47FH;

        @vu
        final C0005Kj f48Hw;

        static {
            wu.j6(d.class, 5884104101721941200L, 5884104101721941200L);
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        @su(method = 292195037055316836L)
        public d(C0005Kj c0005Kj, Activity activity, Callable<Void> callable) {
            super(callable);
            try {
                if (f46j6) {
                    wu.j6(-1596322257627964476L, (Object) null, c0005Kj, activity, callable);
                }
                this.f48Hw = c0005Kj;
                this.f47FH = activity;
            } catch (Throwable th) {
                if (f45DW) {
                    wu.j6(th, -1596322257627964476L, (Object) null, c0005Kj, activity, callable);
                }
                throw th;
            }
        }

        @Override
        @su(method = -2305601103037444791L)
        protected void done() {
            try {
                if (f46j6) {
                    wu.j6(-1387865085839080236L, this);
                }
                if (isCancelled()) {
                    U.j6(new Rj(this));
                    return;
                }
                try {
                    try {
                        get();
                        U.j6(new Oj(this));
                    } catch (InterruptedException e) {
                        h.DW(e);
                        U.j6(new Pj(this, e));
                    }
                } catch (ExecutionException e2) {
                    h.DW(e2);
                    U.j6(new Qj(this, e2));
                }
            } catch (Throwable th) {
                if (f45DW) {
                    wu.j6(th, -1387865085839080236L, this);
                }
                throw th;
            }
        }
    }

    public interface e {
        void m67FH();

        void m68j6();
    }

    static {
        try {
            wu.j6(C0005Kj.class, 144659656370786727L, 144659656370786727L);
            if (f12DW) {
                wu.j6(-1734812296278077355L, (Object) null);
            }
            f14j6 = new String[]{"google_m2repository", "android_m2repository"};
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -1734812296278077355L, (Object) null);
            }
            throw th;
        }
    }

    public C0005Kj() {
        try {
            if (f12DW) {
                wu.j6(3401377218976517560L, (Object) null);
            }
            this.f16Hw = new ArrayList();
            this.f22v5 = Executors.newSingleThreadExecutor();
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 3401377218976517560L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -103294737400022979L)
    public void m14DW(int i) {
        try {
            if (f12DW) {
                wu.j6(-2857012969847673951L, this, i);
            }
            long jCurrentTimeMillis = System.currentTimeMillis();
            if (jCurrentTimeMillis - this.f15EQ < 1000) {
                return;
            }
            this.f15EQ = jCurrentTimeMillis;
            U.j6(new xj(this, i));
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -2857012969847673951L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 628017763248795663L)
    private void m15DW(Activity activity, String str) {
        try {
            if (f12DW) {
                wu.j6(-938275142224642797L, this, activity, str);
            }
            File file = new File(str);
            if (file.isAbsolute()) {
                while (file != null && !file.exists()) {
                    file = file.getParentFile();
                }
                if (file == null) {
                    return;
                }
                if (m43j6(file.getPath(), o.aM())) {
                    m21FH(activity, str);
                    return;
                }
                ma.j6(activity, "Download documents", "There doesn't seem to be enough space on the file system, at least" + ((o.aM() / 1000) / 1000) + "MB，是否继续？", new Bj(this, activity, str), (Runnable) null);
            }
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -938275142224642797L, this, activity, str);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:24:0x0045 A[Catch: all -> 0x0049, Throwable -> 0x004b, TryCatch #0 {, blocks: (B:7:0x0020, B:9:0x0028, B:25:0x0048, B:24:0x0045, B:23:0x0041), top: B:43:0x0020, outer: #5 }] */
    /* JADX WARN: Code duplicated, block: B:47:0x003c A[EXC_TOP_SPLITTER, SYNTHETIC] */
    @su(method = 5229319481629725800L)
    @SuppressLint({"NewApi"})
    public static void m16DW(Context context, String str, String str2) {
        Throwable th;
        Throwable th2;
        try {
            if (f12DW) {
                wu.j6(-359937338776396056L, (Object) null, context, str, str2);
            }
            InputStream inputStreamOpen = context.createPackageContext("com.aide.ndk", 0).getAssets().open(str);
            Throwable th3 = null;
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(str2);
                try {
                    Xa.j6(inputStreamOpen, fileOutputStream);
                    fileOutputStream.close();
                    if (inputStreamOpen != null) {
                        inputStreamOpen.close();
                    }
                } catch (Throwable th4) {
                    try {
                        throw th4;
                    } catch (Throwable th5) {
                        th = th4;
                        th2 = th5;
                        if (th == null) {
                            fileOutputStream.close();
                            throw th2;
                        }
                        fileOutputStream.close();
                        throw th2;
                    }
                }
            } catch (Throwable th6) {
                if (inputStreamOpen != null) {
                    if (0 != 0) {
                        try {
                            inputStreamOpen.close();
                        } catch (Throwable th7) {
                            th3.addSuppressed(th7);
                        }
                    } else {
                        inputStreamOpen.close();
                    }
                }
                throw th6;
            }
        } catch (Throwable th8) {
            if (f13FH) {
                wu.j6(th8, -359937338776396056L, (Object) null, context, str, str2);
            }
            throw th8;
        }
    }

    @su(method = 1347762535711949480L)
    public void m20FH(Activity activity) {
        try {
            if (f12DW) {
                wu.j6(94216401131110128L, this, activity);
            }
            if (this.f18Zo != null) {
                ma.j6(activity, new Ph());
                return;
            }
            m15DW(activity, Vl.Zo() + "/docs");
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 94216401131110128L, this, activity);
            }
            throw th;
        }
    }

    @su(method = 1035600556512919824L)
    public void m21FH(Activity activity, String str) {
        try {
            if (f12DW) {
                wu.j6(-635227546968661536L, this, activity, str);
            }
            aa.Hw(str);
            if (this.f18Zo != null) {
                this.f18Zo.cancel(true);
                this.f18Zo = null;
            }
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            ArrayList arrayList3 = new ArrayList();
            for (o oVar : o.Mr()) {
                if (oVar.Zo() != null && !arrayList.contains(oVar.VH())) {
                    arrayList.add(oVar.VH());
                    arrayList2.add(oVar.Zo());
                    arrayList3.add(Boolean.valueOf(oVar.Hw()));
                }
            }
            this.f18Zo = new d(this, activity, new a(this, activity, arrayList, arrayList2, arrayList3, null, str, new Cj(this)));
            this.f21u7 = "Installation documentation";
            this.f22v5.execute(this.f18Zo);
            ma.j6(activity, new Ph());
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -635227546968661536L, this, activity, str);
            }
            throw th;
        }
    }

    @su(method = 2760131776093308360L)
    private void m23Hw(Activity activity) {
        try {
            if (f12DW) {
                wu.j6(-1149880843046871000L, this, activity);
            }
            m37j6(activity, "Download documents", (Runnable) new Aj(this, activity));
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -1149880843046871000L, this, activity);
            }
            throw th;
        }
    }

    @su(method = 4575825327920922467L)
    public void m24gn() {
        try {
            if (f12DW) {
                wu.j6(3106041240484178775L, this);
            }
            Iterator<e> it = this.f16Hw.iterator();
            while (it.hasNext()) {
                it.next().m67FH();
            }
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 3106041240484178775L, this);
            }
            throw th;
        }
    }

    @su(method = -7689254782209305136L)
    public String m27j6(byte[] bArr, int i) {
        try {
            if (f12DW) {
                wu.j6(4582069672216390136L, this, bArr, new Integer(i));
            }
            String strJ6 = "";
            try {
                strJ6 = Xa.j6(new InputStreamReader(new ByteArrayInputStream(bArr)));
            } catch (IOException unused) {
            }
            String strTrim = strJ6.trim();
            if (strTrim.length() != 0) {
                strTrim = strTrim + '\n';
            }
            return strTrim + " ### binary exited with code " + i;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 4582069672216390136L, this, bArr, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -3431680285534130799L)
    public void m36j6(Activity activity, File file) {
        try {
            if (f12DW) {
                wu.j6(-436815280658991083L, this, activity, file);
            }
            if (this.f18Zo != null) {
                this.f18Zo.cancel(true);
                this.f18Zo = null;
            }
            this.f18Zo = new d(this, activity, new c(this, activity, file));
            this.f21u7 = "Install support for native code (C / C + +)";
            this.f22v5.execute(this.f18Zo);
            ma.j6(activity, new Ph());
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -436815280658991083L, this, activity, file);
            }
            throw th;
        }
    }

    @su(method = -490872077590993365L)
    private void m37j6(Activity activity, String str, Runnable runnable) {
        try {
            if (f12DW) {
                wu.j6(1911670666599768663L, this, activity, str, runnable);
            }
            NetworkInfo activeNetworkInfo = ((ConnectivityManager) activity.getSystemService("connectivity")).getActiveNetworkInfo();
            if (activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting()) {
                if (activeNetworkInfo.getType() == 1 || activeNetworkInfo.getType() == 7 || activeNetworkInfo.getType() == 9) {
                    runnable.run();
                    return;
                } else {
                    ma.j6(activity, str, "Do you want to continue downloading via mobile Internet?", runnable, (Runnable) null);
                    return;
                }
            }
            ma.j6(activity, str, "There seems to be no active network connection. Do you want to continue?", runnable, (Runnable) null);
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 1911670666599768663L, this, activity, str, runnable);
            }
            throw th;
        }
    }

    @su(method = -1993651585384904421L)
    public void m39j6(String str) {
        try {
            if (f12DW) {
                wu.j6(-2514308002856759921L, this, str);
            }
            if (Thread.interrupted()) {
                throw new InterruptedException();
            }
            try {
                Pl plJ6 = Rl.j6(Arrays.asList("/system/bin/chmod", "755", str), (String) null, (Map) null, true, (OutputStream) null, (byte[]) null);
                if (plJ6.DW() == 0) {
                    return;
                }
                throw new IOException("Could not make " + str + " executable - exit code " + plJ6.DW());
            } catch (IOException unused) {
                Pl plJ7 = Rl.j6(Arrays.asList("/system/xbin/chmod", "755", str), (String) null, (Map) null, true, (OutputStream) null, (byte[]) null);
                if (plJ7.DW() == 0) {
                    return;
                }
                throw new IOException("Could not make " + str + " executable - exit code " + plJ7.DW());
            }
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -2514308002856759921L, this, str);
            }
            throw th;
        }
    }

    @su(method = 3718113849926677885L)
    public void m40j6(String str, int i, int i2) {
        try {
            if (f12DW) {
                wu.j6(-2508467732859247959L, this, str, new Integer(i), new Integer(i2));
            }
            this.f15EQ = System.currentTimeMillis();
            U.j6(new yj(this, str, i, i2));
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -2508467732859247959L, this, str, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:108:0x01f9 A[Catch: all -> 0x021e, TRY_LEAVE, TryCatch #11 {all -> 0x021e, blocks: (B:104:0x01f1, B:105:0x01f4, B:97:0x01e3, B:108:0x01f9), top: B:152:0x00d7 }] */
    /* JADX WARN: Code duplicated, block: B:155:0x01e1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:156:0x01d7 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:48:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:60:0x0102  */
    /* JADX WARN: Code duplicated, block: B:63:0x0108 A[Catch: all -> 0x0222, TRY_ENTER, TRY_LEAVE, TryCatch #0 {all -> 0x0222, blocks: (B:37:0x009e, B:41:0x00a9, B:46:0x00d3, B:50:0x00df, B:52:0x00e5, B:54:0x00ed, B:56:0x00f3, B:63:0x0108, B:44:0x00ce), top: B:133:0x009e }] */
    /* JADX WARN: Code duplicated, block: B:69:0x0139 A[Catch: all -> 0x01ee, TryCatch #5 {all -> 0x01ee, blocks: (B:66:0x0124, B:67:0x012f, B:69:0x0139, B:71:0x013f), top: B:142:0x0124 }] */
    /* JADX WARN: Code duplicated, block: B:71:0x013f A[Catch: all -> 0x01ee, TRY_LEAVE, TryCatch #5 {all -> 0x01ee, blocks: (B:66:0x0124, B:67:0x012f, B:69:0x0139, B:71:0x013f), top: B:142:0x0124 }] */
    /* JADX WARN: Code duplicated, block: B:74:0x0152  */
    /* JADX WARN: Code duplicated, block: B:82:0x01ab  */
    /* JADX WARN: Code duplicated, block: B:90:0x01c6  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1, types: [java.net.HttpURLConnection] */
    /* JADX WARN: Type inference failed for: r15v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r15v3 */
    /* JADX WARN: Type inference failed for: r15v4 */
    /* JADX WARN: Type inference failed for: r15v6 */
    @su(method = -3874464954827275745L)
    public void m41j6(String str, String str2, boolean z) throws Throwable {
        long j;
        ?? M42j6;
        int responseCode;
        boolean z2;
        FileOutputStream fileOutputStream;
        byte[] bArr;
        long jCurrentTimeMillis;
        long j2;
        long j3;
        int i;
        long j4;
        long jCurrentTimeMillis2;
        long j5;
        C0005Kj c0005Kj;
        int i2;
        Map<String, List<String>> headerFields;
        List<String> list;
        List<String> list2;
        C0005Kj c0005Kj2 = this;
        try {
            if (f12DW) {
                wu.j6(980541538863681675L, this, str, str2, new Boolean(z));
            }
            try {
                if (Thread.interrupted()) {
                    throw new InterruptedException();
                }
                File file = new File(str2);
                long j6 = 0;
                long length = (z && file.exists()) ? file.length() : 0L;
                int i3 = 0;
                if (length > 0) {
                    HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
                    try {
                        httpURLConnection.setRequestMethod("HEAD");
                        httpURLConnection.setRequestProperty("Accept-Encoding", "identity");
                        Map<String, List<String>> headerFields2 = httpURLConnection.getHeaderFields();
                        if (!c0005Kj2.m42j6(httpURLConnection.getResponseCode()) || headerFields2 == null || (list2 = headerFields2.get("content-Length")) == null || list2.isEmpty()) {
                            j = -1;
                        } else {
                            try {
                                j = Long.parseLong(list2.get(0));
                            } catch (NumberFormatException unused) {
                                j = -1;
                            }
                        }
                    } finally {
                        httpURLConnection.disconnect();
                    }
                } else {
                    j = -1;
                }
                if (length == j) {
                    return;
                }
                HttpURLConnection httpURLConnection2 = (HttpURLConnection) new URL(str).openConnection();
                try {
                    httpURLConnection2.setRequestProperty("Accept-Encoding", "identity");
                    try {
                        if (j > 0 && length > 0) {
                            httpURLConnection2.setRequestProperty("Range", "bytes=" + length + "-");
                            responseCode = httpURLConnection2.getResponseCode();
                            z2 = responseCode == 206;
                            M42j6 = c0005Kj2.m42j6(responseCode);
                            if (M42j6 == 0) {
                                if (j == -1 && (headerFields = httpURLConnection2.getHeaderFields()) != null && (list = headerFields.get("content-Length")) != null && !list.isEmpty()) {
                                    try {
                                        j = Long.parseLong(list.get(0));
                                    } catch (NumberFormatException unused2) {
                                        j = -1;
                                    }
                                }
                                if (!z2) {
                                    length = 0;
                                }
                                try {
                                    System.currentTimeMillis();
                                    if (!z2) {
                                        new File(str2).delete();
                                    }
                                    new File(str2).getParentFile().mkdirs();
                                    fileOutputStream = new FileOutputStream(str2, z2);
                                    try {
                                        bArr = new byte[32768];
                                        jCurrentTimeMillis = System.currentTimeMillis();
                                        int i4 = -1;
                                        j2 = 0;
                                        j3 = jCurrentTimeMillis;
                                        while (true) {
                                            i = httpURLConnection2.getInputStream().read(bArr);
                                            if (i <= 0) {
                                                if (!Thread.interrupted()) {
                                                    throw new InterruptedException();
                                                }
                                                fileOutputStream.write(bArr, i3, i);
                                                j4 = j;
                                                j6 += (long) i;
                                                jCurrentTimeMillis2 = System.currentTimeMillis();
                                                j5 = jCurrentTimeMillis2 - j3;
                                                if (j5 > 5000) {
                                                    long j7 = j6 - j2;
                                                    long j8 = jCurrentTimeMillis2 - jCurrentTimeMillis;
                                                    try {
                                                        PrintStream printStream = System.out;
                                                        StringBuilder sb = new StringBuilder();
                                                        sb.append("Last 5 secs Average input bytes/sec: ");
                                                        double d2 = j7;
                                                        Double.isNaN(d2);
                                                        double d3 = j5;
                                                        Double.isNaN(d3);
                                                        sb.append((d2 * 1000.0d) / d3);
                                                        printStream.println(sb.toString());
                                                        PrintStream printStream2 = System.out;
                                                        StringBuilder sb2 = new StringBuilder();
                                                        sb2.append("Total Average input bytes/sec: ");
                                                        double d4 = j6;
                                                        Double.isNaN(d4);
                                                        double d5 = j8;
                                                        Double.isNaN(d5);
                                                        sb2.append((d4 * 1000.0d) / d5);
                                                        printStream2.println(sb2.toString());
                                                        j2 = j6;
                                                        j3 = jCurrentTimeMillis2;
                                                    } catch (Throwable th) {
                                                        th = th;
                                                    }
                                                }
                                                if (j4 != -1 || i4 == (i2 = (int) (((length + j6) * 100) / j4))) {
                                                    c0005Kj = this;
                                                } else {
                                                    c0005Kj = this;
                                                    try {
                                                        c0005Kj.m14DW(i2);
                                                        i4 = i2;
                                                    } catch (Throwable th2) {
                                                        th = th2;
                                                    }
                                                }
                                                c0005Kj2 = c0005Kj;
                                                httpURLConnection2 = httpURLConnection2;
                                                j = j4;
                                                bArr = bArr;
                                                i3 = 0;
                                                th = th2;
                                                fileOutputStream.close();
                                                throw th;
                                            }
                                            HttpURLConnection httpURLConnection3 = httpURLConnection2;
                                            fileOutputStream.close();
                                            try {
                                                httpURLConnection3.disconnect();
                                                return;
                                            } catch (Throwable th3) {
                                                th = th3;
                                            }
                                        }
                                    } catch (Throwable th4) {
                                        th = th4;
                                    }
                                } catch (Throwable th5) {
                                    th = th5;
                                    M42j6 = httpURLConnection2;
                                    M42j6.disconnect();
                                    throw th;
                                }
                            } else {
                                M42j6 = httpURLConnection2;
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append("HTTP connection to ");
                                try {
                                    sb3.append(str);
                                    sb3.append(" failed with response code ");
                                    sb3.append(responseCode);
                                    throw new IOException(sb3.toString());
                                } catch (Throwable th6) {
                                    th = th6;
                                }
                            }
                            M42j6.disconnect();
                            throw th;
                        }
                        responseCode = httpURLConnection2.getResponseCode();
                        if (M42j6 == 0) {
                            M42j6 = httpURLConnection2;
                            StringBuilder sb4 = new StringBuilder();
                            sb4.append("HTTP connection to ");
                            sb4.append(str);
                            sb4.append(" failed with response code ");
                            sb4.append(responseCode);
                            throw new IOException(sb4.toString());
                        }
                        if (j == -1) {
                            j = Long.parseLong(list.get(0));
                        }
                        if (!z2) {
                            length = 0;
                        }
                        System.currentTimeMillis();
                        if (!z2) {
                            new File(str2).delete();
                        }
                        new File(str2).getParentFile().mkdirs();
                        fileOutputStream = new FileOutputStream(str2, z2);
                        bArr = new byte[32768];
                        jCurrentTimeMillis = System.currentTimeMillis();
                        int i5 = -1;
                        j2 = 0;
                        j3 = jCurrentTimeMillis;
                        while (true) {
                            i = httpURLConnection2.getInputStream().read(bArr);
                            if (i <= 0) {
                                HttpURLConnection httpURLConnection4 = httpURLConnection2;
                                fileOutputStream.close();
                                httpURLConnection4.disconnect();
                                return;
                            }
                            if (!Thread.interrupted()) {
                                throw new InterruptedException();
                            }
                            fileOutputStream.write(bArr, i3, i);
                            j4 = j;
                            j6 += (long) i;
                            jCurrentTimeMillis2 = System.currentTimeMillis();
                            j5 = jCurrentTimeMillis2 - j3;
                            if (j5 > 5000) {
                                long j9 = j6 - j2;
                                long j10 = jCurrentTimeMillis2 - jCurrentTimeMillis;
                                PrintStream printStream3 = System.out;
                                StringBuilder sb5 = new StringBuilder();
                                sb5.append("Last 5 secs Average input bytes/sec: ");
                                double d6 = j9;
                                Double.isNaN(d6);
                                double d7 = j5;
                                Double.isNaN(d7);
                                sb5.append((d6 * 1000.0d) / d7);
                                printStream3.println(sb5.toString());
                                PrintStream printStream4 = System.out;
                                StringBuilder sb6 = new StringBuilder();
                                sb6.append("Total Average input bytes/sec: ");
                                double d8 = j6;
                                Double.isNaN(d8);
                                double d9 = j10;
                                Double.isNaN(d9);
                                sb6.append((d8 * 1000.0d) / d9);
                                printStream4.println(sb6.toString());
                                j2 = j6;
                                j3 = jCurrentTimeMillis2;
                            }
                            if (j4 != -1) {
                                c0005Kj = this;
                            } else {
                                c0005Kj = this;
                            }
                            c0005Kj2 = c0005Kj;
                            httpURLConnection2 = httpURLConnection2;
                            j = j4;
                            bArr = bArr;
                            i3 = 0;
                            th = th2;
                            fileOutputStream.close();
                            throw th;
                        }
                    } catch (Throwable th7) {
                        th = th7;
                    }
                    M42j6 = c0005Kj2.m42j6(responseCode);
                } catch (Throwable th8) {
                    th = th8;
                    M42j6 = httpURLConnection2;
                }
                M42j6.disconnect();
                throw th;
            } catch (Throwable th9) {
                th = th9;
            }
        } catch (Throwable th10) {
            th = th10;
        }
        if (f13FH) {
            wu.j6(th, 980541538863681675L, this, str, str2, new Boolean(z));
        }
        throw th;
    }

    @su(method = 62385971052779160L)
    private boolean m42j6(int i) {
        try {
            if (f12DW) {
                wu.j6(1102941307242553368L, this, i);
            }
            return i >= 200 && i < 300;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 1102941307242553368L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -5956746909814501608L)
    private boolean m43j6(String str, long j) {
        try {
            if (f12DW) {
                wu.j6(5421331127921477760L, this, str, new Long(j));
            }
            StatFs statFs = new StatFs(str);
            return ((long) statFs.getAvailableBlocks()) * ((long) statFs.getBlockSize()) > j;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 5421331127921477760L, this, str, new Long(j));
            }
            throw th;
        }
    }

    @su(method = -6429436051174786783L)
    public void m45u7() {
        try {
            if (f12DW) {
                wu.j6(5745705053264358605L, this);
            }
            Iterator<e> it = this.f16Hw.iterator();
            while (it.hasNext()) {
                it.next().m68j6();
            }
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 5745705053264358605L, this);
            }
            throw th;
        }
    }

    @su(method = -7154755893037973880L)
    private void m46v5(Activity activity) {
        try {
            if (f12DW) {
                wu.j6(1581038918728490352L, this, activity);
            }
            Q.DW();
            File file = new File(Vl.FH());
            if (m43j6(Vl.Zo(), 750000000L)) {
                m36j6(activity, file);
                return;
            }
            ma.j6(activity, "Download support for native code (C / C + +)", "There doesn't seem to be enough space on the internal memory, which requires at least 200MB.Continue?", new wj(this, activity, file), (Runnable) null);
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 1581038918728490352L, this, activity);
            }
            throw th;
        }
    }

    public void m47DW() {
        try {
            if (f12DW) {
                wu.j6(-1028873464844655003L, this);
            }
            this.f18Zo.cancel(true);
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -1028873464844655003L, this);
            }
            throw th;
        }
    }

    public void m48DW(e eVar) {
        try {
            if (f12DW) {
                wu.j6(-117280532438165727L, this, eVar);
            }
            this.f16Hw.remove(eVar);
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -117280532438165727L, this, eVar);
            }
            throw th;
        }
    }

    public void m49DW(Activity activity) {
        try {
            if (f12DW) {
                wu.j6(3009125045795206316L, this, activity);
            }
            if (Q.VH()) {
                ma.j6(activity, "Support for native code (C/C++)", "Uninstall support for native code?", new Dj(this, activity), (Runnable) null);
            } else {
                InstallNdk.a(activity);
            }
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 3009125045795206316L, this, activity);
            }
            throw th;
        }
    }

    public String m50FH() {
        try {
            if (f12DW) {
                wu.j6(-258467314333153413L, this);
            }
            return this.f21u7;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -258467314333153413L, this);
            }
            throw th;
        }
    }

    public int m51Hw() {
        try {
            if (f12DW) {
                wu.j6(-4719786361984446696L, this);
            }
            return this.f17VH;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -4719786361984446696L, this);
            }
            throw th;
        }
    }

    public boolean m52VH() {
        try {
            if (f12DW) {
                wu.j6(-319444074868741328L, this);
            }
            return this.f18Zo != null;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -319444074868741328L, this);
            }
            throw th;
        }
    }

    public String m53Zo() {
        try {
            if (f12DW) {
                wu.j6(889241999412804771L, this);
            }
            return this.f20tp;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 889241999412804771L, this);
            }
            throw th;
        }
    }

    public void m54j6(e eVar) {
        try {
            if (f12DW) {
                wu.j6(-4764645981434530240L, this, eVar);
            }
            this.f16Hw.add(eVar);
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -4764645981434530240L, this, eVar);
            }
            throw th;
        }
    }

    public void m55j6(Activity activity) {
        try {
            if (f12DW) {
                wu.j6(216170759644784888L, this, activity);
            }
            if (U.U2().j6(activity, "offline_docs")) {
                m23Hw(activity);
            }
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, 216170759644784888L, this, activity);
            }
            throw th;
        }
    }

    public void m56j6(Activity activity, String str) {
        try {
            if (f12DW) {
                wu.j6(-2159692624017865617L, this, activity, str);
            }
            int i = zj.j6[Q.j6(activity).ordinal()];
            if (i == 2) {
                ma.j6(activity, "NDK Support package is outdated", str + ".\n\nThe AIDE NDK Support package is outdated. Open Play Store to update?", new Gj(this), (Runnable) null);
                return;
            }
            if (i == 3) {
                ma.j6(activity, "AIDE is outdated", str + ".\n\nYour version of AIDE is outdated and does not support the updated AIDE NDK Support package. Open Play Store to update?", new Hj(this), (Runnable) null);
                return;
            }
            if (i == 4) {
                ma.j6(activity, "Install support for native code (C/C++)", str + "The AIDE NDK Support Package has not been completely installed. Open AIDE NDK Support Package to download expansion file?", new Ij(this, activity), (Runnable) null);
                return;
            }
            if (i == 5) {
                m46v5(activity);
                return;
            }
            ma.j6(activity, "Install support for native code (C/C++)", str + "After installing support for native code you can build apps using native-code languages such as C and C++. The native code support takes about 750MB of space on internal storage space once installed.\n\nDownload native code support package now?", new Fj(this), (Runnable) null);
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -2159692624017865617L, this, activity, str);
            }
            throw th;
        }
    }

    public void m57j6(Activity activity, List<Be.g> list, List<Be.m> list2, Runnable runnable) {
        try {
            if (f12DW) {
                wu.j6(-139018920714890249L, this, activity, list, list2, runnable);
            }
            m37j6(activity, "Download Maven Library", (Runnable) new Ej(this, activity, list, list2, runnable));
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -139018920714890249L, this, activity, list, list2, runnable);
            }
            throw th;
        }
    }

    public int m58v5() {
        try {
            if (f12DW) {
                wu.j6(-3945926478657840480L, this);
            }
            return this.f19gn;
        } catch (Throwable th) {
            if (f13FH) {
                wu.j6(th, -3945926478657840480L, this);
            }
            throw th;
        }
    }
}
