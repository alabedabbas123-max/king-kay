package abcd;

class C0020RG extends C0063SG {
    C0020RG() {
    }

    public int m201DW() {
        return 1;
    }
}
