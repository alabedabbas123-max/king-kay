package abcd;

import java.util.ArrayList;

class C0011Hn {
    private static C0100Jr m152DW(pn pnVar) {
        um umVarJ6 = pnVar.j6("RuntimeVisibleAnnotations");
        sm smVarJ6 = pnVar.j6("RuntimeInvisibleAnnotations");
        if (umVarJ6 == null) {
            return smVarJ6 == null ? C0100Jr.f640DW : smVarJ6.j6();
        }
        return smVarJ6 == null ? umVarJ6.j6() : C0100Jr.m960j6(umVarJ6.j6(), smVarJ6.j6());
    }

    public static C0100Jr m153DW(un unVar) {
        C0100Jr c0100JrM160j6 = m160j6(unVar.getAttributes());
        Ss ssM161j6 = m161j6(unVar);
        return ssM161j6.size() != 0 ? C0100Jr.m959j6(c0100JrM160j6, Yo.DW(ssM161j6)) : c0100JrM160j6;
    }

    private static C0015Hr m154FH(pn pnVar) {
        wm wmVarJ6 = pnVar.j6("Signature");
        if (wmVarJ6 == null) {
            return null;
        }
        return Yo.j6(wmVarJ6.j6());
    }

    public static Kr m155FH(un unVar) {
        pn attributes = unVar.getAttributes();
        vm vmVarJ6 = attributes.j6("RuntimeVisibleParameterAnnotations");
        tm tmVarJ6 = attributes.j6("RuntimeInvisibleParameterAnnotations");
        if (vmVarJ6 == null) {
            return tmVarJ6 == null ? Kr.FH : tmVarJ6.j6();
        }
        return tmVarJ6 == null ? vmVarJ6.j6() : Kr.j6(vmVarJ6.j6(), tmVarJ6.j6());
    }

    private static C0015Hr m156Hw(pn pnVar) {
        mm mmVarJ6 = pnVar.j6("EnclosingMethod");
        if (mmVarJ6 == null) {
            return null;
        }
        Ks ksJ6 = mmVarJ6.j6();
        C0016Hs c0016HsDW = mmVarJ6.DW();
        return c0016HsDW == null ? Yo.j6(ksJ6) : Yo.j6(new Gs(ksJ6, c0016HsDW));
    }

    private static C0015Hr m157j6(jn jnVar) {
        Ks ksJ8 = jnVar.J8();
        vn vnVarEQ = jnVar.EQ();
        int size = vnVarEQ.size();
        C0015Hr c0015Hr = new C0015Hr(ksJ8, EnumC0057Ir.EMBEDDED);
        boolean z = false;
        for (int i = 0; i < size; i++) {
            un unVar = vnVarEQ.get(i);
            im imVarJ6 = unVar.getAttributes().j6("AnnotationDefault");
            if (imVarJ6 != null) {
                c0015Hr.m175j6(new Lr(unVar.FH().m180J8(), imVarJ6.j6()));
                z = true;
            }
        }
        if (!z) {
            return null;
        }
        c0015Hr.we();
        return Yo.j6(c0015Hr);
    }

    private static C0100Jr m158j6(Ks ks, pn pnVar, boolean z) throws ou {
        om omVarJ6 = pnVar.j6("InnerClasses");
        if (omVarJ6 == null) {
            return null;
        }
        Dm dmJ6 = omVarJ6.j6();
        int size = dmJ6.size();
        ArrayList arrayList = new ArrayList();
        Dm.a aVar = null;
        for (int i = 0; i < size; i++) {
            Dm.a aVar2 = dmJ6.get(i);
            Ks ksDW = aVar2.DW();
            if (ksDW.equals(ks)) {
                aVar = aVar2;
            } else if (ks.equals(aVar2.Hw())) {
                arrayList.add(ksDW.VH());
            }
        }
        int size2 = arrayList.size();
        if (aVar == null && size2 == 0) {
            return null;
        }
        C0100Jr c0100Jr = new C0100Jr();
        if (aVar != null) {
            c0100Jr.m962j6(Yo.j6(aVar.FH(), aVar.j6()));
            if (z) {
                if (aVar.Hw() == null) {
                    throw new ou("Ignoring InnerClasses attribute for an anonymous inner class\n(" + ks.aM() + ") that doesn't come with an\nassociated EnclosingMethod attribute. This class was probably produced by a\ncompiler that did not target the modern .class file format. The recommended\nsolution is to recompile the class from source, using an up-to-date compiler\nand without specifying any \"-target\" type options. The consequence of ignoring\nthis warning is that reflective operations on this class will incorrectly\nindicate that it is *not* an inner class.");
                }
                c0100Jr.m962j6(Yo.j6(aVar.Hw()));
            }
        }
        if (size2 != 0) {
            Ps ps = new Ps(size2);
            for (int i2 = 0; i2 < size2; i2++) {
                ps.j6(i2, (Qs) arrayList.get(i2));
            }
            ps.we();
            c0100Jr.m962j6(Yo.j6(ps));
        }
        c0100Jr.we();
        return c0100Jr;
    }

    public static C0100Jr m159j6(jn jnVar, C0053In c0053In) {
        C0015Hr c0015HrM157j6;
        Ks ksJ8 = jnVar.J8();
        pn pnVarFH = jnVar.FH();
        C0100Jr c0100JrM160j6 = m160j6(pnVarFH);
        C0015Hr c0015HrM156Hw = m156Hw(pnVarFH);
        try {
            C0100Jr c0100JrM158j6 = m158j6(ksJ8, pnVarFH, c0015HrM156Hw == null);
            if (c0100JrM158j6 != null) {
                c0100JrM160j6 = C0100Jr.m960j6(c0100JrM160j6, c0100JrM158j6);
            }
        } catch (ou e) {
            c0053In.f400gn.println("warning: " + e.getMessage());
        }
        if (c0015HrM156Hw != null) {
            c0100JrM160j6 = C0100Jr.m959j6(c0100JrM160j6, c0015HrM156Hw);
        }
        return (!Mr.v5(jnVar.j6()) || (c0015HrM157j6 = m157j6(jnVar)) == null) ? c0100JrM160j6 : C0100Jr.m959j6(c0100JrM160j6, c0015HrM157j6);
    }

    public static C0100Jr m160j6(pn pnVar) {
        C0100Jr c0100JrM152DW = m152DW(pnVar);
        C0015Hr c0015HrM154FH = m154FH(pnVar);
        return c0015HrM154FH != null ? C0100Jr.m959j6(c0100JrM152DW, c0015HrM154FH) : c0100JrM152DW;
    }

    public static Ss m161j6(un unVar) {
        nm nmVarJ6 = unVar.getAttributes().j6("Exceptions");
        return nmVarJ6 == null ? Ps.FH : nmVarJ6.j6();
    }
}
