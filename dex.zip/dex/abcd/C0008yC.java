package abcd;

class C0008yC extends AbstractC0051zC {
    C0008yC() {
    }

    @Override
    protected int mo22j6(byte[] bArr, int i, int i2) {
        int iDW = HK.DW(bArr, i, i2);
        int i3 = 5381;
        while (i < iDW) {
            byte b = bArr[i];
            i3 = (b & 255) + (i3 << 5) + i3;
            i = HK.j6(b) ? HK.j6(bArr, i, iDW) : i + 1;
        }
        return i3;
    }

    public boolean m23j6(tC tCVar, int i, tC tCVar2, int i2) {
        int i3 = i + 1;
        int i4 = i2 + 1;
        int iDW = tCVar.FH.DW(i3);
        int iDW2 = tCVar2.FH.DW(i4);
        int iDW3 = tCVar.FH.DW(i3 + 1);
        int iDW4 = tCVar2.FH.DW(i4 + 1);
        int iDW5 = HK.DW(tCVar.DW, iDW, iDW3);
        int iDW6 = HK.DW(tCVar2.DW, iDW2, iDW4);
        while (iDW < iDW5 && iDW2 < iDW6) {
            byte b = tCVar.DW[iDW];
            byte b2 = tCVar2.DW[iDW2];
            if (b != b2) {
                return false;
            }
            iDW = HK.j6(b) ? HK.j6(tCVar.DW, iDW, iDW5) : iDW + 1;
            iDW2 = HK.j6(b2) ? HK.j6(tCVar2.DW, iDW2, iDW6) : iDW2 + 1;
        }
        return iDW == iDW5 && iDW2 == iDW6;
    }
}
