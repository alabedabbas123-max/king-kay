package abcd;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public class BinderC0105Dx extends Binder implements IInterface {
    protected BinderC0105Dx(String str) {
        attachInterface(this, str);
    }

    @Override
    public IBinder asBinder() {
        return this;
    }

    protected boolean m702j6(int i, Parcel parcel, Parcel parcel2, int i2) {
        return false;
    }

    @Override
    public boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) throws RemoteException {
        boolean zOnTransact;
        if (i > 16777215) {
            zOnTransact = super.onTransact(i, parcel, parcel2, i2);
        } else {
            parcel.enforceInterface(getInterfaceDescriptor());
            zOnTransact = false;
        }
        if (zOnTransact) {
            return true;
        }
        return m702j6(i, parcel, parcel2, i2);
    }
}
