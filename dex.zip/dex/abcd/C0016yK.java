package abcd;

import java.io.File;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Arrays;

class C0016yK extends vK {

    private static String f39Hw;

    C0016yK() {
    }

    static boolean m68u7() {
        String str = (String) AccessController.doPrivileged((PrivilegedAction) new wK());
        if (str == null) {
            return false;
        }
        File fileDW = pK.DW(str, new String[]{"cygpath.exe"});
        if (fileDW != null) {
            f39Hw = fileDW.getPath();
        }
        return f39Hw != null;
    }

    protected File m69VH() {
        String str = (String) AccessController.doPrivileged((PrivilegedAction) new xK(this));
        return (str == null || str.length() == 0) ? super.VH() : m70j6(new File("."), str);
    }

    public File m70j6(File file, String str) {
        String strJ6;
        String property = System.getProperty("jgit.usecygpath");
        return (property == null || !property.equals("true") || (strJ6 = pK.j6(file, new String[]{f39Hw, "--windows", "--absolute", str}, "UTF-8")) == null) ? super/*abcd.pK*/.j6(file, str) : new File(strJ6);
    }

    public ProcessBuilder m71j6(String str, String[] strArr) {
        ArrayList arrayList = new ArrayList(strArr.length + 4);
        arrayList.add("sh.exe");
        arrayList.add("-c");
        arrayList.add(String.valueOf(str) + " \"$@\"");
        arrayList.add(str);
        arrayList.addAll(Arrays.asList(strArr));
        ProcessBuilder processBuilder = new ProcessBuilder(new String[0]);
        processBuilder.command(arrayList);
        return processBuilder;
    }
}
