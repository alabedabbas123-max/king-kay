package abcd;

import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;

public abstract class AbstractC0052YD implements Comparable {

    int f188FH;

    int f189Hw;

    int f190VH;

    int f191Zo;

    int f192v5;

    private static final byte[] f187j6 = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102};

    private static final char[] f186DW = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    private byte[] m292Ws() {
        byte[] bArr = new byte[40];
        m295j6(bArr, 0, this.f188FH);
        m295j6(bArr, 8, this.f189Hw);
        m295j6(bArr, 16, this.f192v5);
        m295j6(bArr, 24, this.f191Zo);
        m295j6(bArr, 32, this.f190VH);
        return bArr;
    }

    private char[] m293aM() {
        char[] cArr = new char[40];
        m296j6(cArr);
        return cArr;
    }

    private static void m294j6(OutputStream outputStream, int i) throws IOException {
        outputStream.write(i >>> 24);
        outputStream.write(i >>> 16);
        outputStream.write(i >>> 8);
        outputStream.write(i);
    }

    private static void m295j6(byte[] bArr, int i, int i2) {
        int i3 = i + 7;
        while (i3 >= i && i2 != 0) {
            bArr[i3] = f187j6[i2 & 15];
            i2 >>>= 4;
            i3--;
        }
        while (i3 >= i) {
            bArr[i3] = 48;
            i3--;
        }
    }

    private void m296j6(char[] cArr) {
        m297j6(cArr, 0, this.f188FH);
        m297j6(cArr, 8, this.f189Hw);
        m297j6(cArr, 16, this.f192v5);
        m297j6(cArr, 24, this.f191Zo);
        m297j6(cArr, 32, this.f190VH);
    }

    static void m297j6(char[] cArr, int i, int i2) {
        int i3 = i + 7;
        while (i3 >= i && i2 != 0) {
            cArr[i3] = f186DW[i2 & 15];
            i2 >>>= 4;
            i3--;
        }
        while (i3 >= i) {
            cArr[i3] = '0';
            i3--;
        }
    }

    public static boolean m298j6(AbstractC0052YD abstractC0052YD, AbstractC0052YD abstractC0052YD2) {
        if (abstractC0052YD == abstractC0052YD2) {
            return true;
        }
        return abstractC0052YD.f189Hw == abstractC0052YD2.f189Hw && abstractC0052YD.f192v5 == abstractC0052YD2.f192v5 && abstractC0052YD.f191Zo == abstractC0052YD2.f191Zo && abstractC0052YD.f190VH == abstractC0052YD2.f190VH && abstractC0052YD.f188FH == abstractC0052YD2.f188FH;
    }

    public void m299DW(OutputStream outputStream) throws IOException {
        outputStream.write(m292Ws());
    }

    public void m300DW(byte[] bArr, int i) {
        FK.DW(bArr, i, this.f188FH);
        FK.DW(bArr, i + 4, this.f189Hw);
        FK.DW(bArr, i + 8, this.f192v5);
        FK.DW(bArr, i + 12, this.f191Zo);
        FK.DW(bArr, i + 16, this.f190VH);
    }

    public final boolean m301DW(AbstractC0052YD abstractC0052YD) {
        if (abstractC0052YD != null) {
            return m298j6(this, abstractC0052YD);
        }
        return false;
    }

    public void m302FH(byte[] bArr, int i) {
        m295j6(bArr, i + 0, this.f188FH);
        m295j6(bArr, i + 8, this.f189Hw);
        m295j6(bArr, i + 16, this.f192v5);
        m295j6(bArr, i + 24, this.f191Zo);
        m295j6(bArr, i + 32, this.f190VH);
    }

    public final yE m303Hw() {
        return getClass() == yE.class ? (yE) this : new yE(this);
    }

    public abstract yE m304J8();

    public final String m305VH() {
        return m314we();
    }

    public final int m306Zo() {
        return this.f188FH >>> 24;
    }

    @Override
    public final int compareTo(Object obj) {
        return m307j6((AbstractC0052YD) obj);
    }

    public final boolean equals(Object obj) {
        if (obj instanceof AbstractC0052YD) {
            return m301DW((AbstractC0052YD) obj);
        }
        return false;
    }

    public final int hashCode() {
        return this.f189Hw;
    }

    public final int m307j6(AbstractC0052YD abstractC0052YD) {
        if (this == abstractC0052YD) {
            return 0;
        }
        int iJ6 = FK.j6(this.f188FH, abstractC0052YD.f188FH);
        if (iJ6 != 0) {
            return iJ6;
        }
        int iJ7 = FK.j6(this.f189Hw, abstractC0052YD.f189Hw);
        if (iJ7 != 0) {
            return iJ7;
        }
        int iJ8 = FK.j6(this.f192v5, abstractC0052YD.f192v5);
        if (iJ8 != 0) {
            return iJ8;
        }
        int iJ9 = FK.j6(this.f191Zo, abstractC0052YD.f191Zo);
        return iJ9 != 0 ? iJ9 : FK.j6(this.f190VH, abstractC0052YD.f190VH);
    }

    public final int m308j6(byte[] bArr, int i) {
        int iJ6 = FK.j6(this.f188FH, FK.j6(bArr, i));
        if (iJ6 != 0) {
            return iJ6;
        }
        int iJ7 = FK.j6(this.f189Hw, FK.j6(bArr, i + 4));
        if (iJ7 != 0) {
            return iJ7;
        }
        int iJ8 = FK.j6(this.f192v5, FK.j6(bArr, i + 8));
        if (iJ8 != 0) {
            return iJ8;
        }
        int iJ9 = FK.j6(this.f191Zo, FK.j6(bArr, i + 12));
        return iJ9 != 0 ? iJ9 : FK.j6(this.f190VH, FK.j6(bArr, i + 16));
    }

    public final int m309j6(int[] iArr, int i) {
        int iJ6 = FK.j6(this.f188FH, iArr[i]);
        if (iJ6 != 0) {
            return iJ6;
        }
        int iJ7 = FK.j6(this.f189Hw, iArr[i + 1]);
        if (iJ7 != 0) {
            return iJ7;
        }
        int iJ8 = FK.j6(this.f192v5, iArr[i + 2]);
        if (iJ8 != 0) {
            return iJ8;
        }
        int iJ9 = FK.j6(this.f191Zo, iArr[i + 3]);
        return iJ9 != 0 ? iJ9 : FK.j6(this.f190VH, iArr[i + 4]);
    }

    public WD m310j6(int i) {
        return new WD(i, WD.j6(i, 1, this.f188FH), WD.j6(i, 2, this.f189Hw), WD.j6(i, 3, this.f192v5), WD.j6(i, 4, this.f191Zo), WD.j6(i, 5, this.f190VH));
    }

    public void m311j6(OutputStream outputStream) throws IOException {
        m294j6(outputStream, this.f188FH);
        m294j6(outputStream, this.f189Hw);
        m294j6(outputStream, this.f192v5);
        m294j6(outputStream, this.f191Zo);
        m294j6(outputStream, this.f190VH);
    }

    public void m312j6(char[] cArr, Writer writer) throws IOException {
        m296j6(cArr);
        writer.write(cArr, 0, 40);
    }

    public void m313j6(char[] cArr, StringBuilder sb) {
        m296j6(cArr);
        sb.append(cArr, 0, 40);
    }

    public String toString() {
        return "AnyObjectId[" + m314we() + "]";
    }

    public final String m314we() {
        return new String(m293aM());
    }
}
