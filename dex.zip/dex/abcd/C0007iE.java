package abcd;

class C0007iE implements b<C0051jE> {
    C0007iE() {
    }

    public C0051jE m52j6(gE gEVar) {
        return new C0051jE(gEVar, null);
    }
}
