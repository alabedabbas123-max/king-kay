package abcd;

public class C0023ou extends RuntimeException {
    public C0023ou(String str) {
        super(str);
    }
}
