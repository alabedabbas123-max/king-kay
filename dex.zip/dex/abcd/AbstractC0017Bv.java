package abcd;

import android.app.Activity;
import com.appfour.backbone.api.closures.OnActivityClosure;
import com.appfour.backbone.api.closures.OnClickClosure;
import com.appfour.backbone.api.closures.OnInputClosure;
import com.appfour.backbone.api.closures.OnItemClickClosure;
import com.appfour.backbone.api.closures.OnLaunchClosure;
import com.appfour.backbone.api.closures.OnMenuItemSelectedClosure;
import com.appfour.backbone.api.closures.OnNotificationActionClosure;
import com.appfour.backbone.api.closures.OnNotificationClosure;
import com.appfour.backbone.api.closures.OnTouchClosure;
import com.appfour.backbone.api.closures.OnWindowClosure;
import com.appfour.backbone.api.define.DefineHook;

public abstract class AbstractC0017Bv extends Vu {

    private boolean f66EQ;

    private boolean f67J0;

    private boolean f68J8;

    private boolean f69Mr;

    private boolean f70QX;

    private boolean f71U2;

    private boolean f72Ws;

    private boolean f73XL;

    private boolean f74a8;

    private boolean f75aM;

    private int f76er = -1;

    private boolean f77j3;

    private boolean f78lg;

    private Class<? extends Activity> f79rN;

    private boolean f80tp;

    private boolean f81u7;

    private boolean f82we;

    public Class<? extends Activity> m97EQ() {
        return this.f79rN;
    }

    public boolean m98J0() {
        return this.f81u7;
    }

    public boolean m99J8() {
        return this.f80tp;
    }

    public boolean m100Mr() {
        return this.f75aM;
    }

    public boolean m101QX() {
        return this.f77j3;
    }

    public boolean m102U2() {
        return this.f71U2;
    }

    public boolean m103Ws() {
        return this.f66EQ;
    }

    public boolean m104XL() {
        return this.f73XL;
    }

    public boolean m105a8() {
        return this.f69Mr;
    }

    public boolean m106aM() {
        return this.f74a8;
    }

    public boolean m107er() {
        return this.f70QX;
    }

    public boolean m108gW() {
        return this.f82we;
    }

    public boolean m109j3() {
        return this.f78lg;
    }

    public boolean m110lg() {
        return this.f72Ws;
    }

    public DefineHook onActivityCreate(OnActivityClosure onActivityClosure) {
        this.f81u7 = true;
        ((yu) this).j6 = onActivityClosure == null ? null : new uv(this, onActivityClosure);
        return j6();
    }

    public DefineHook onActivityStart(OnActivityClosure onActivityClosure) {
        this.f80tp = true;
        ((yu) this).j6 = onActivityClosure == null ? null : new sv(this, onActivityClosure);
        return j6();
    }

    public DefineHook onActivityStop(OnActivityClosure onActivityClosure) {
        this.f66EQ = true;
        ((yu) this).j6 = onActivityClosure == null ? null : new tv(this, onActivityClosure);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <A extends Activity> DefineHook onClick(Class<A> cls, int i, OnClickClosure<A> onClickClosure) {
        this.f77j3 = true;
        this.f79rN = cls;
        this.f76er = i;
        ((yu) this).j6 = onClickClosure == null ? null : new Av(this, onClickClosure);
        return j6();
    }

    public DefineHook onInput(OnInputClosure onInputClosure) {
        this.f73XL = true;
        ((yu) this).j6 = onInputClosure == null ? null : new nv(this, onInputClosure);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <A extends Activity> DefineHook onItemClick(Class<A> cls, int i, OnItemClickClosure<A> onItemClickClosure) {
        this.f74a8 = true;
        this.f76er = i;
        this.f79rN = cls;
        ((yu) this).j6 = onItemClickClosure == null ? null : new yv(this, onItemClickClosure);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <A extends Activity> DefineHook onItemLongPress(Class<A> cls, int i, OnItemClickClosure<A> onItemClickClosure) {
        this.f78lg = true;
        this.f76er = i;
        this.f79rN = cls;
        ((yu) this).j6 = onItemClickClosure == null ? null : new zv(this, onItemClickClosure);
        return j6();
    }

    public DefineHook onLaunch(OnLaunchClosure onLaunchClosure) {
        this.f75aM = true;
        ((yu) this).j6 = onLaunchClosure == null ? null : new rv(this, onLaunchClosure);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <A extends Activity> DefineHook onLongPress(Class<A> cls, int i, OnClickClosure<A> onClickClosure) {
        this.f71U2 = true;
        this.f79rN = cls;
        this.f76er = i;
        ((yu) this).j6 = onClickClosure == null ? null : new mv(this, onClickClosure);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <A extends Activity> DefineHook onMenuItemSelected(Class<A> cls, int i, OnMenuItemSelectedClosure<A> onMenuItemSelectedClosure) {
        this.f69Mr = true;
        this.f76er = i;
        this.f79rN = cls;
        ((yu) this).j6 = onMenuItemSelectedClosure == null ? null : new xv(this, onMenuItemSelectedClosure);
        return j6();
    }

    public DefineHook onNotificationAction(OnNotificationActionClosure onNotificationActionClosure) {
        this.f72Ws = true;
        ((yu) this).j6 = onNotificationActionClosure == null ? null : new qv(this, onNotificationActionClosure);
        return j6();
    }

    public DefineHook onNotificationShown(OnNotificationClosure onNotificationClosure) {
        this.f68J8 = true;
        ((yu) this).j6 = onNotificationClosure == null ? null : new pv(this, onNotificationClosure);
        return j6();
    }

    public DefineHook onTouch(OnTouchClosure onTouchClosure) {
        this.f70QX = true;
        ((yu) this).j6 = onTouchClosure == null ? null : new ov(this, onTouchClosure);
        return j6();
    }

    public DefineHook onWindowHidden(OnWindowClosure onWindowClosure) {
        this.f67J0 = true;
        ((yu) this).j6 = onWindowClosure == null ? null : new wv(this, onWindowClosure);
        return j6();
    }

    public DefineHook onWindowShown(OnWindowClosure onWindowClosure) {
        this.f82we = true;
        ((yu) this).j6 = onWindowClosure == null ? null : new vv(this, onWindowClosure);
        return j6();
    }

    public boolean m111rN() {
        return this.f68J8;
    }

    public int m112we() {
        return this.f76er;
    }

    public boolean m113yS() {
        return this.f67J0;
    }
}
