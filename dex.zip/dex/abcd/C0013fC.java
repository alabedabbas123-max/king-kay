package abcd;

class C0013fC implements b<C0057gC> {
    C0013fC() {
    }

    public C0057gC m40j6(C0059gE c0059gE) {
        return new C0057gC(c0059gE, null);
    }
}
