package abcd;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class C0000Wv {

    public static class a {

        public String f0DW;

        public C0043Xv f1FH;

        public long f2Hw;

        public String f3j6;

        public a(String str, String str2, C0043Xv c0043Xv, long j) {
            this.f3j6 = str;
            this.f0DW = str2;
            this.f1FH = c0043Xv;
            this.f2Hw = j;
        }
    }

    private static File m0DW() {
        return uw.j6(wu.j6(), "properties");
    }

    public static List<a> m1j6() {
        ArrayList arrayList = new ArrayList();
        File[] fileArrListFiles = m0DW().listFiles();
        if (fileArrListFiles != null) {
            for (File file : fileArrListFiles) {
                if (file.getName().endsWith(".ser")) {
                    try {
                        DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
                        try {
                            arrayList.add(new a(dataInputStream.readUTF(), dataInputStream.readUTF(), new C0043Xv(dataInputStream), dataInputStream.readLong()));
                            dataInputStream.close();
                        } catch (Throwable th) {
                            dataInputStream.close();
                            throw th;
                        }
                    } catch (Throwable th2) {
                        yw.j6("Property error", th2);
                    }
                }
            }
        }
        Collections.sort(arrayList, new Vv());
        return arrayList;
    }

    public static void m2j6(String str, String str2, C0043Xv c0043Xv, long j) {
        if (c0043Xv.f154tp) {
            try {
                DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(new File(m0DW(), str2 + ".ser")));
                try {
                    dataOutputStream.writeUTF(str);
                    dataOutputStream.writeUTF(str2);
                    dataOutputStream.writeLong(j);
                    c0043Xv.m268j6(dataOutputStream);
                } finally {
                    dataOutputStream.close();
                }
            } catch (Throwable th) {
                yw.j6("Property error", th);
            }
        }
    }
}
