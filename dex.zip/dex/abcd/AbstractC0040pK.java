package abcd;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.Arrays;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class AbstractC0040pK {

    public static final AbstractC0040pK f444j6 = m175j6();

    private volatile a<File> f445DW;

    private volatile a<File> f446FH;

    private static class a<V> {

        final V f447j6;

        a(V v) {
            this.f447j6 = v;
        }
    }

    protected AbstractC0040pK() {
    }

    static File m174DW(String str, String... strArr) {
        if (str == null) {
            return null;
        }
        for (String str2 : str.split(File.pathSeparator)) {
            for (String str3 : strArr) {
                File file = new File(str2, str3);
                if (file.isFile()) {
                    return file.getAbsoluteFile();
                }
            }
        }
        return null;
    }

    public static AbstractC0040pK m175j6() {
        return m176j6((Boolean) null);
    }

    public static AbstractC0040pK m176j6(Boolean bool) {
        if (!vK.gn()) {
            return tK.gn() ? new tK() : new sK();
        }
        if (bool == null) {
            bool = Boolean.valueOf(yK.u7());
        }
        return bool.booleanValue() ? new yK() : new vK();
    }

    /* JADX WARN: Code duplicated, block: B:21:0x00aa A[Catch: InterruptedException -> 0x0090, IOException -> 0x00d2, TRY_LEAVE, TryCatch #0 {InterruptedException -> 0x0090, blocks: (B:12:0x0090, B:15:0x009b, B:17:0x00a1, B:21:0x00aa), top: B:36:0x0090 }] */
    /* JADX WARN: Code duplicated, block: B:23:0x00be A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:41:0x00c0 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:42:0x0086 A[EDGE_INSN: B:42:0x0086->B:11:0x0086 BREAK  A[LOOP:0: B:9:0x0080->B:43:0x0080], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:44:0x0080 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:48:0x00da A[EDGE_INSN: B:48:0x00da->B:32:0x00da BREAK  A[LOOP:1: B:36:0x0090->B:35:0x0090], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:8:0x0061 A[Catch: all -> 0x00c6, TryCatch #1 {all -> 0x00c6, blocks: (B:6:0x005b, B:8:0x0061, B:9:0x0080, B:24:0x00c0), top: B:38:0x005b, outer: #2 }] */
    /* JADX WARN: Instruction removed from duplicated block: B:21:0x00aa, please report this as an issue */
    /* JADX WARN: Instruction removed from duplicated block: B:8:0x0061, please report this as an issue */
    protected static String m177j6(File file, String[] strArr, String str) {
        Process processExec;
        BufferedReader bufferedReader;
        oK oKVar;
        String line;
        String line2;
        int iWaitFor;
        boolean z = Boolean.parseBoolean(QK.FH().j6("jgit.fs.debug"));
        if (!z) {
            processExec = Runtime.getRuntime().exec(strArr, (String[]) null, file);
            bufferedReader = new BufferedReader(new InputStreamReader(processExec.getInputStream(), str));
            processExec.getOutputStream().close();
            AtomicBoolean atomicBoolean = new AtomicBoolean(false);
            oKVar = new oK(processExec, z, atomicBoolean);
            oKVar.start();
            line = bufferedReader.readLine();
            if (z) {
                System.err.println("readpipe may return '" + line + "'");
                System.err.println("(ignoring remaing output:");
            }
            while (true) {
                line2 = bufferedReader.readLine();
                if (line2 == null) {
                    break;
                    break;
                }
                if (z) {
                    System.err.println(line2);
                }
            }
            processExec.getErrorStream().close();
            bufferedReader.close();
            while (true) {
                iWaitFor = processExec.waitFor();
                oKVar.join();
                if (iWaitFor != 0) {
                }
                if (z) {
                    break;
                    break;
                }
                System.err.println("readpipe rc=" + iWaitFor);
                break;
                break;
            }
        }
        try {
            System.err.println("readpipe " + Arrays.asList(strArr) + "," + file);
            processExec = Runtime.getRuntime().exec(strArr, (String[]) null, file);
            bufferedReader = new BufferedReader(new InputStreamReader(processExec.getInputStream(), str));
            processExec.getOutputStream().close();
            AtomicBoolean atomicBoolean2 = new AtomicBoolean(false);
            oKVar = new oK(processExec, z, atomicBoolean2);
            oKVar.start();
            try {
                line = bufferedReader.readLine();
                if (z) {
                    System.err.println("readpipe may return '" + line + "'");
                    System.err.println("(ignoring remaing output:");
                }
                while (true) {
                    line2 = bufferedReader.readLine();
                    if (line2 == null) {
                        break;
                    }
                    if (z) {
                        System.err.println(line2);
                    }
                }
                processExec.getErrorStream().close();
                bufferedReader.close();
                while (true) {
                    try {
                        iWaitFor = processExec.waitFor();
                        oKVar.join();
                        if (iWaitFor != 0 && line != null && line.length() > 0 && !atomicBoolean2.get()) {
                            return line;
                        }
                        if (z) {
                            break;
                        }
                        System.err.println("readpipe rc=" + iWaitFor);
                        break;
                    } catch (InterruptedException unused) {
                    }
                }
            } catch (Throwable th) {
                processExec.getErrorStream().close();
                bufferedReader.close();
                throw th;
            }
        } catch (IOException e) {
            if (z) {
                System.err.println(e);
            }
        }
        if (z) {
            System.err.println("readpipe returns null");
        }
        return null;
    }

    public AbstractC0040pK m178DW(File file) {
        this.f445DW = new a(file);
        return this;
    }

    protected abstract File mo179DW();

    /* JADX WARN: Multi-variable type inference failed */
    public File m180FH() {
        a<File> aVar = this.f446FH;
        if (aVar == null) {
            String strJ6 = QK.FH().j6("jgit.gitprefix");
            aVar = strJ6 != null ? new a<>(new File(strJ6)) : new a<>(mo179DW());
            this.f446FH = aVar;
        }
        return (File) aVar.f447j6;
    }

    public abstract boolean m181Hw();

    protected File m182VH() {
        String str = (String) AccessController.doPrivileged((PrivilegedAction) new nK(this));
        if (str == null || str.length() == 0) {
            return null;
        }
        return new File(str).getAbsoluteFile();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public File m183Zo() {
        a aVar = this.f445DW;
        if (aVar == null) {
            aVar = new a(m182VH());
            this.f445DW = aVar;
        }
        return (File) aVar.f447j6;
    }

    public File m184j6(File file, String str) {
        File file2 = new File(str);
        return file2.isAbsolute() ? file2 : new File(file, str);
    }

    public abstract ProcessBuilder mo185j6(String str, String[] strArr);

    public abstract boolean m186j6(File file);

    public abstract boolean m187j6(File file, boolean z);

    public abstract boolean m188v5();
}
