package abcd;

public abstract class AbstractC0010ro extends Vn {
    public AbstractC0010ro(hs hsVar) {
        super(Yn.DW, hsVar, cs.FH);
    }

    public final int m128DW() {
        return 0;
    }

    public Vn m129DW(int i) {
        return j6(gn().v5(i));
    }

    public final Vn m130j6(Xn xn) {
        throw new RuntimeException("unsupported");
    }

    public final void m131j6(Lt lt) {
    }
}
