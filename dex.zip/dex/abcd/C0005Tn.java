package abcd;

public final class C0005Tn extends Zn {

    private int f15VH;

    private int f16Zo;

    private final ms f17v5;

    public C0005Tn(Xn xn, hs hsVar, cs csVar, ms msVar) {
        super(xn, hsVar, csVar);
        if (msVar == null) {
            throw new NullPointerException("constant == null");
        }
        this.f17v5 = msVar;
        this.f16Zo = -1;
        this.f15VH = -1;
    }

    public void m26FH(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("index < 0");
        }
        if (this.f15VH >= 0) {
            throw new RuntimeException("class index already set");
        }
        this.f15VH = i;
    }

    public void m27Hw(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("index < 0");
        }
        if (this.f16Zo >= 0) {
            throw new RuntimeException("index already set");
        }
        this.f16Zo = i;
    }

    public int m28J0() {
        int i = this.f16Zo;
        if (i >= 0) {
            return i;
        }
        throw new RuntimeException("index not yet set for " + this.f17v5);
    }

    public boolean m29J8() {
        return this.f16Zo >= 0;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [abcd.Tn, abcd.Vn] */
    public AbstractC0091Vn m30j6(Xn xn) {
        ?? c0005Tn = new C0005Tn(xn, m569VH(), m571gn(), this.f17v5);
        int i = this.f16Zo;
        if (i >= 0) {
            c0005Tn.m27Hw(i);
        }
        int i2 = this.f15VH;
        if (i2 >= 0) {
            c0005Tn.m26FH(i2);
        }
        return c0005Tn;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [abcd.Tn, abcd.Vn] */
    public AbstractC0091Vn m31j6(cs csVar) {
        ?? c0005Tn = new C0005Tn(m570Zo(), m569VH(), csVar, this.f17v5);
        int i = this.f16Zo;
        if (i >= 0) {
            c0005Tn.m27Hw(i);
        }
        int i2 = this.f15VH;
        if (i2 >= 0) {
            c0005Tn.m26FH(i2);
        }
        return c0005Tn;
    }

    protected String m32j6() {
        return this.f17v5.aM();
    }

    public ms m33we() {
        return this.f17v5;
    }
}
