package abcd;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class C0014XI implements Serializable {

    private List<HJ> f59DW;

    private List<HJ> f60FH;

    private List<WI> f61Hw;

    private String f62VH;

    private String f63Zo;

    private eJ f64gn;

    private String f65j6;

    private int f66tp;

    private boolean f67u7;

    private List<WI> f68v5;

    public C0014XI(gE gEVar, String str) {
        this.f65j6 = str;
        String[] strArrDW = gEVar.DW("remote", this.f65j6, "url");
        this.f59DW = new ArrayList(strArrDW.length);
        for (String str2 : strArrDW) {
            this.f59DW.add(new HJ(str2));
        }
        String[] strArrDW2 = gEVar.DW("remote", this.f65j6, "pushurl");
        this.f60FH = new ArrayList(strArrDW2.length);
        for (String str3 : strArrDW2) {
            this.f60FH.add(new HJ(str3));
        }
        String[] strArrDW3 = gEVar.DW("remote", this.f65j6, "fetch");
        this.f61Hw = new ArrayList(strArrDW3.length);
        for (String str4 : strArrDW3) {
            this.f61Hw.add(new WI(str4));
        }
        String[] strArrDW4 = gEVar.DW("remote", this.f65j6, "push");
        this.f68v5 = new ArrayList(strArrDW4.length);
        for (String str5 : strArrDW4) {
            this.f68v5.add(new WI(str5));
        }
        String strJ6 = gEVar.j6("remote", this.f65j6, "uploadpack");
        this.f63Zo = strJ6 == null ? "git-upload-pack" : strJ6;
        String strJ7 = gEVar.j6("remote", this.f65j6, "receivepack");
        this.f62VH = strJ7 == null ? "git-receive-pack" : strJ7;
        this.f64gn = eJ.j6(gEVar.j6("remote", this.f65j6, "tagopt"));
        this.f67u7 = gEVar.j6("remote", this.f65j6, "mirror", false);
        this.f66tp = gEVar.j6("remote", this.f65j6, "timeout", 0);
    }

    private void m78j6(gE gEVar, String str) {
        gEVar.FH("remote", m82DW(), str);
    }

    private void m79j6(gE gEVar, String str, int i, int i2) {
        if (i2 == i) {
            m78j6(gEVar, str);
        } else {
            gEVar.DW("remote", m82DW(), str, i);
        }
    }

    private void m80j6(gE gEVar, String str, String str2, String str3) {
        if (str3.equals(str2)) {
            m78j6(gEVar, str);
        } else {
            gEVar.j6("remote", m82DW(), str, str2);
        }
    }

    private void m81j6(gE gEVar, String str, boolean z, boolean z2) {
        if (z2 == z) {
            m78j6(gEVar, str);
        } else {
            gEVar.DW("remote", m82DW(), str, z);
        }
    }

    public String m82DW() {
        return this.f65j6;
    }

    public List<WI> m83FH() {
        return Collections.unmodifiableList(this.f68v5);
    }

    public List<HJ> m84Hw() {
        return Collections.unmodifiableList(this.f60FH);
    }

    public int m85VH() {
        return this.f66tp;
    }

    public eJ m86Zo() {
        return this.f64gn;
    }

    public List<HJ> m87gn() {
        return Collections.unmodifiableList(this.f59DW);
    }

    public List<WI> m88j6() {
        return Collections.unmodifiableList(this.f61Hw);
    }

    public void m89j6(gE gEVar) {
        ArrayList arrayList = new ArrayList();
        arrayList.clear();
        Iterator<HJ> it = m87gn().iterator();
        while (it.hasNext()) {
            arrayList.add(it.next().u7());
        }
        gEVar.j6("remote", m82DW(), "url", arrayList);
        arrayList.clear();
        Iterator<HJ> it2 = m84Hw().iterator();
        while (it2.hasNext()) {
            arrayList.add(it2.next().u7());
        }
        gEVar.j6("remote", m82DW(), "pushurl", arrayList);
        arrayList.clear();
        Iterator<WI> it3 = m88j6().iterator();
        while (it3.hasNext()) {
            arrayList.add(it3.next().toString());
        }
        gEVar.j6("remote", m82DW(), "fetch", arrayList);
        arrayList.clear();
        Iterator<WI> it4 = m83FH().iterator();
        while (it4.hasNext()) {
            arrayList.add(it4.next().toString());
        }
        gEVar.j6("remote", m82DW(), "push", arrayList);
        m80j6(gEVar, "uploadpack", m92u7(), "git-upload-pack");
        m80j6(gEVar, "receivepack", m93v5(), "git-receive-pack");
        m80j6(gEVar, "tagopt", m86Zo().Hw(), eJ.j6.Hw());
        m81j6(gEVar, "mirror", this.f67u7, false);
        m79j6(gEVar, "timeout", this.f66tp, 0);
    }

    public boolean m90j6(HJ hj) {
        if (this.f59DW.contains(hj)) {
            return false;
        }
        return this.f59DW.add(hj);
    }

    public boolean m91j6(WI wi) {
        if (this.f61Hw.contains(wi)) {
            return false;
        }
        return this.f61Hw.add(wi);
    }

    public String m92u7() {
        return this.f63Zo;
    }

    public String m93v5() {
        return this.f62VH;
    }
}
