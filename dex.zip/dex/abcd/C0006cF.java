package abcd;

enum C0006cF extends iF {
    C0006cF(String str, int i) {
        super(str, i, (iF) null);
    }

    public boolean m44Hw() {
        return true;
    }
}
