package abcd;

import com.aide.ui.AIDEEditor;

@xu
public class C0011El {

    @uu
    private static boolean f134DW;

    @tu
    private static boolean f135j6;

    static {
        wu.j6(C0011El.class, 1246809773463033264L, 1246809773463033264L);
    }

    public C0011El() {
        try {
            if (f135j6) {
                wu.j6(1847650909741426892L, (Object) null);
            }
        } catch (Throwable th) {
            if (f134DW) {
                wu.j6(th, 1847650909741426892L, (Object) null);
            }
            throw th;
        }
    }

    public static boolean m238j6(AIDEEditor aIDEEditor, char c, int i, int i2) {
        try {
            if (f135j6) {
                wu.j6(2959221165330660072L, (Object) null, aIDEEditor, new Character(c), new Integer(i), new Integer(i2));
            }
            if (c != '{') {
                return true;
            }
            aIDEEditor.j6(i2, i, '}');
            aIDEEditor.EQ(i, i2);
            return true;
        } catch (Throwable th) {
            if (f134DW) {
                wu.j6(th, 2959221165330660072L, (Object) null, aIDEEditor, new Character(c), new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public static boolean m239j6(AIDEEditor aIDEEditor, int i, int i2, int i3) {
        try {
            if (f135j6) {
                wu.j6(1235029394990727013L, (Object) null, aIDEEditor, new Integer(i), new Integer(i2), new Integer(i3));
            }
            int i4 = i;
            while (i4 > 1 && aIDEEditor.Hw(i4).trim().length() == 0) {
                i4--;
            }
            int iFH = aIDEEditor.FH(i4);
            String strHw = aIDEEditor.Hw(i4);
            int i5 = i + 1;
            String strHw2 = aIDEEditor.Hw(i5);
            if (!strHw.endsWith("{")) {
                aIDEEditor.gn(i5, iFH);
            } else if (strHw2.startsWith("}")) {
                aIDEEditor.u7(i5, 1);
                aIDEEditor.EQ(i5, 1);
                aIDEEditor.gn(i5, iFH + i3);
                aIDEEditor.gn(i + 2, iFH);
            } else {
                aIDEEditor.gn(i5, iFH + i3);
            }
            return true;
        } catch (Throwable th) {
            if (f134DW) {
                wu.j6(th, 1235029394990727013L, (Object) null, aIDEEditor, new Integer(i), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }
}
