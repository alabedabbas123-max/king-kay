package abcd;

import java.util.zip.Inflater;

class C0009XD extends Inflater {

    private static final byte[] f36j6 = new byte[1];

    C0009XD() {
        super(false);
    }

    @Override
    public void end() {
    }

    @Override
    public int inflate(byte[] bArr) {
        return super.inflate(bArr);
    }

    @Override
    public int inflate(byte[] bArr, int i, int i2) {
        if (i2 != 0) {
            return super.inflate(bArr, i, i2);
        }
        if (super.inflate(f36j6, 0, 1) <= 0) {
            return 0;
        }
        throw new RuntimeException();
    }

    void m36j6() {
        super.end();
    }
}
