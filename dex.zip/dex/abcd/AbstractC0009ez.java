package abcd;

import java.util.Collection;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;

public abstract class AbstractC0009ez<Params, Progress, Result> extends Xy<Params, Progress, Result> implements _y<lz>, hz, lz, Zy {

    private final jz f64Ws = new jz();

    private static class a<Result> implements Executor {

        private final AbstractC0009ez f65DW;

        private final Executor f66j6;

        public a(Executor executor, AbstractC0009ez abstractC0009ez) {
            this.f66j6 = executor;
            this.f65DW = abstractC0009ez;
        }

        @Override
        public void execute(Runnable runnable) {
            this.f66j6.execute(new dz(this, runnable, (Object) null));
        }
    }

    public boolean m20DW() {
        return ((hz) m22gn()).DW();
    }

    public Collection<lz> m21FH() {
        return ((hz) m22gn()).FH();
    }

    public int compareTo(Object obj) {
        return cz.j6(this, obj);
    }

    public <T extends _y<lz> & hz & lz> T m22gn() {
        return this.f64Ws;
    }

    public void m24j6(lz lzVar) {
        if (Hw() != Xy.d.j6) {
            throw new IllegalStateException("Must not add Dependency after task is running");
        }
        ((hz) m22gn()).j6(lzVar);
    }

    public void m25j6(Throwable th) {
        ((hz) m22gn()).j6(th);
    }

    public final void m26j6(ExecutorService executorService, Params... paramsArr) {
        super.j6(new a(executorService, this), paramsArr);
    }

    public void m27j6(boolean z) {
        ((hz) m22gn()).j6(z);
    }

    public boolean m28j6() {
        return ((hz) m22gn()).j6();
    }
}
