package abcd;

public class C0004lG extends iG {

    private byte[] f8J0;

    private String f9J8;

    private iG f10we;

    protected C0004lG(YD yd) {
        super(yd);
    }

    public final int m9aM() {
        return 4;
    }

    public final iG m10j3() {
        return this.f10we;
    }

    void m11j6(qG qGVar) {
        m12j6(qGVar, qGVar.j6(this));
    }

    void m12j6(qG qGVar, byte[] bArr) {
        EK ek = new EK();
        ek.j6 = 53;
        int iJ6 = hE.j6(this, bArr, (byte) 10, ek);
        qGVar.FH.v5(bArr, 7);
        this.f10we = qGVar.j6(qGVar.FH, iJ6);
        int i = ek.j6 + 4;
        ek.j6 = i;
        this.f9J8 = IK.j6(hE.Zo, bArr, i, IK.Zo(bArr, i) - 1);
        if (qGVar.u7()) {
            this.f8J0 = bArr;
        }
        ((iG) this).EQ |= 1;
    }
}
