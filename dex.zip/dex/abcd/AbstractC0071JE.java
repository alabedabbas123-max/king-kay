package abcd;

import java.io.IOException;
import java.io.InputStream;

public abstract class AbstractC0071JE extends InputStream {

    public static class a extends AbstractC0071JE {

        private final long f464DW;

        private final InputStream f465FH;

        private final int f466j6;

        public a(int i, long j, InputStream inputStream) {
            this.f466j6 = i;
            this.f464DW = j;
            this.f465FH = inputStream;
        }

        @Override
        public int available() {
            return this.f465FH.available();
        }

        @Override
        public void close() throws IOException {
            this.f465FH.close();
        }

        @Override
        public long mo672j6() {
            return this.f464DW;
        }

        @Override
        public void mark(int i) {
            this.f465FH.mark(i);
        }

        @Override
        public boolean markSupported() {
            return this.f465FH.markSupported();
        }

        @Override
        public int read() {
            return this.f465FH.read();
        }

        @Override
        public int read(byte[] bArr, int i, int i2) {
            return this.f465FH.read(bArr, i, i2);
        }

        @Override
        public void reset() throws IOException {
            this.f465FH.reset();
        }

        @Override
        public long skip(long j) {
            return this.f465FH.skip(j);
        }
    }

    public static class b extends AbstractC0071JE {

        private final byte[] f467DW;

        private int f468FH;

        private int f469Hw;

        private final int f470j6;

        public b(int i, byte[] bArr) {
            this.f470j6 = i;
            this.f467DW = bArr;
        }

        public b(FE fe) {
            this(fe.FH(), fe.j6());
        }

        @Override
        public int available() {
            return this.f467DW.length - this.f468FH;
        }

        @Override
        public long mo672j6() {
            return this.f467DW.length;
        }

        @Override
        public void mark(int i) {
            this.f469Hw = this.f468FH;
        }

        @Override
        public boolean markSupported() {
            return true;
        }

        @Override
        public int read() {
            int i = this.f468FH;
            byte[] bArr = this.f467DW;
            if (i == bArr.length) {
                return -1;
            }
            this.f468FH = i + 1;
            return bArr[i] & 255;
        }

        @Override
        public int read(byte[] bArr, int i, int i2) {
            if (this.f468FH == this.f467DW.length) {
                return -1;
            }
            int iMin = Math.min(available(), i2);
            System.arraycopy(this.f467DW, this.f468FH, bArr, i, iMin);
            this.f468FH += iMin;
            return iMin;
        }

        @Override
        public void reset() {
            this.f468FH = this.f469Hw;
        }

        @Override
        public long skip(long j) {
            int iMin = (int) Math.min(available(), Math.max(0L, j));
            this.f468FH += iMin;
            return iMin;
        }
    }

    public abstract long mo672j6();
}
