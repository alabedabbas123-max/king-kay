package abcd;

public final class C0018Es extends Cs {

    public static final C0018Es f140DW = m249j6(0);

    public static final C0018Es f141FH = m249j6(1);

    private C0018Es(long j) {
        super(j);
    }

    public static C0018Es m249j6(long j) {
        return new C0018Es(j);
    }

    public String m250Zo() {
        return "long";
    }

    public String m251aM() {
        return Long.toString(lg());
    }

    public Qs getType() {
        return Qs.gn;
    }

    public long m252rN() {
        return lg();
    }

    public String toString() {
        long jLg = lg();
        return "long{0x" + Yt.DW(jLg) + " / " + jLg + '}';
    }
}
