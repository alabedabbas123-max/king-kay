package abcd;

enum C0004Qq extends er {
    C0004Qq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
