package abcd;

public abstract class AbstractC0037yp extends tp {

    private final Fs f184FH;

    public AbstractC0037yp(Fs fs) {
        super(fs.VH());
        this.f184FH = fs;
    }

    protected abstract int m209DW(jp jpVar);

    protected abstract String m210Mr();

    public int m211VH() {
        return 8;
    }

    public final Fs m212j3() {
        return this.f184FH;
    }

    public void m213j6(jp jpVar) {
        super.j6(jpVar);
        jpVar.J8().DW(m212j3().we().J8());
    }

    public final void m214j6(jp jpVar, Lt lt) {
        Qp qpWs = jpVar.Ws();
        Op opJ8 = jpVar.J8();
        Hs hsWe = this.f184FH.we();
        int iJ6 = qpWs.j6(aM());
        int iJ7 = opJ8.j6(hsWe.J8());
        int iM209DW = m209DW(jpVar);
        if (lt.Hw()) {
            lt.j6(0, Ws() + ' ' + this.f184FH.aM());
            StringBuilder sb = new StringBuilder();
            sb.append("  class_idx: ");
            sb.append(Yt.v5(iJ6));
            lt.j6(2, sb.toString());
            lt.j6(2, String.format("  %-10s %s", m210Mr() + ':', Yt.v5(iM209DW)));
            lt.j6(4, "  name_idx:  " + Yt.gn(iJ7));
        }
        lt.writeShort(iJ6);
        lt.writeShort(iM209DW);
        lt.writeInt(iJ7);
    }
}
