package abcd;

public final class C0012Em extends Am {

    private final Pt f136DW;

    private final ns f137FH;

    public C0012Em(String str, Pt pt, int i, int i2, ns nsVar) {
        this(str, pt.j6(i, i2 + i), nsVar);
    }

    public C0012Em(String str, Pt pt, ns nsVar) {
        super(str);
        if (pt == null) {
            throw new NullPointerException("data == null");
        }
        this.f136DW = pt;
        this.f137FH = nsVar;
    }

    public int m240Hw() {
        return this.f136DW.FH() + 6;
    }
}
