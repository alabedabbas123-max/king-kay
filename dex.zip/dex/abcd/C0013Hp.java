package abcd;

import java.util.ArrayList;

public final class C0013Hp implements lu, Comparable<C0013Hp> {

    private final Kr f97DW;

    private final Tp<Xo> f98FH;

    private final Gs f99j6;

    public C0013Hp(Gs gs, Kr kr) {
        if (gs == null) {
            throw new NullPointerException("method == null");
        }
        if (kr == null) {
            throw new NullPointerException("annotationsList == null");
        }
        this.f99j6 = gs;
        this.f97DW = kr;
        int size = kr.size();
        ArrayList arrayList = new ArrayList(size);
        for (int i = 0; i < size; i++) {
            arrayList.add(new Xo(new Wo(kr.get(i))));
        }
        this.f98FH = new Tp(wp.tp, arrayList);
    }

    public String m168aM() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f99j6.aM());
        sb.append(": ");
        boolean z = true;
        for (Xo xo : this.f98FH.j3()) {
            if (z) {
                z = false;
            } else {
                sb.append(", ");
            }
            sb.append(xo.aM());
        }
        return sb.toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0013Hp) {
            return this.f99j6.equals(((C0013Hp) obj).f99j6);
        }
        return false;
    }

    public int hashCode() {
        return this.f99j6.hashCode();
    }

    @Override
    public int compareTo(C0013Hp c0013Hp) {
        return this.f99j6.j6(c0013Hp.f99j6);
    }

    public void m170j6(jp jpVar) {
        Cp cpTp = jpVar.tp();
        Fp fpXL = jpVar.XL();
        cpTp.DW(this.f99j6);
        fpXL.j6(this.f98FH);
    }

    public void m171j6(jp jpVar, Lt lt) {
        int iJ6 = jpVar.tp().j6(this.f99j6);
        int iWe = this.f98FH.we();
        if (lt.Hw()) {
            lt.j6(0, "    " + this.f99j6.aM());
            lt.j6(4, "      method_idx:      " + Yt.gn(iJ6));
            lt.j6(4, "      annotations_off: " + Yt.gn(iWe));
        }
        lt.writeInt(iJ6);
        lt.writeInt(iWe);
    }
}
