package abcd;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import com.aide.common.c;
import com.aide.common.ma;
import com.aide.licensing.d;
import com.aide.ui.PromoNotificationAlarmReceiver;
import com.aide.ui.U;
import com.aide.ui.trainer.TrainerNotificationAlarmReceiver;
import com.aide.ui.trainer.g;
import java.util.Arrays;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

@xu
public class C0010Ek {

    @uu
    private static boolean f121DW;

    @tu
    private static boolean f122j6;

    @ru(field = 2444638751229946760L)
    private Pi f123EQ;

    @ru(field = 4765635909877695875L)
    private long f124FH;

    @ru(field = -4096731277695067328L)
    private long f125Hw;

    @ru(field = -2624380913457292483L)
    private AtomicBoolean f126J0;

    @ru(field = 1819482178336402032L)
    private boolean f127VH;

    @ru(field = 5040277543243240024L)
    private boolean f128Zo;

    @ru(field = -2219440165332424144L)
    private d f129gn;

    @ru(field = 2333946689440500480L)
    private AtomicLong f130tp;

    @ru(field = 4810292570148432477L)
    private AtomicLong f131u7;

    @ru(field = -1778107694123030400L)
    private long f132v5;

    @ru(field = 56943212107263040L)
    private Qi f133we;

    static {
        wu.j6(C0010Ek.class, -5512199351607094776L, -5512199351607094776L);
    }

    public C0010Ek() {
        try {
            if (f122j6) {
                wu.j6(4997135016184014040L, (Object) null);
            }
            this.f124FH = 0L;
            this.f125Hw = 0L;
            this.f132v5 = 0L;
            this.f128Zo = false;
            this.f127VH = false;
            this.f131u7 = new AtomicLong(0L);
            this.f130tp = new AtomicLong(0L);
            this.f123EQ = new Pi();
            this.f133we = new Qi();
            this.f126J0 = new AtomicBoolean(false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 4997135016184014040L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -2143727912137271985L)
    private boolean m194DW(Activity activity, int i, String str) {
        try {
            if (f122j6) {
                wu.j6(-1854435506479910424L, this, activity, new Integer(i), str);
            }
            if (m221Zo()) {
                return true;
            }
            m228j6(activity, i, str);
            return false;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -1854435506479910424L, this, activity, new Integer(i), str);
            }
            throw th;
        }
    }

    @su(method = -1164736582577366112L)
    private void m195a8() {
        try {
            if (f122j6) {
                wu.j6(-322554253526051855L, this);
            }
            U.QX().j6();
            U.yS().j6();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -322554253526051855L, this);
            }
            throw th;
        }
    }

    @su(method = -1399727759734925336L)
    private void m196er() {
        try {
            if (f122j6) {
                wu.j6(435436208635078035L, this);
            }
            SharedPreferences sharedPreferences = U.Zo().getSharedPreferences("LicenseService", 0);
            if (sharedPreferences.getLong("first_shop_time", -1L) == -1) {
                long jCurrentTimeMillis = System.currentTimeMillis();
                SharedPreferences.Editor editorEdit = sharedPreferences.edit();
                editorEdit.putLong("first_shop_time", jCurrentTimeMillis);
                editorEdit.commit();
            }
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 435436208635078035L, this);
            }
            throw th;
        }
    }

    @su(method = -1586376168595155793L)
    private void m198j6(String str) {
        try {
            if (f122j6) {
                wu.j6(-1153740540392817704L, this, str);
            }
            if (U.lg().er()) {
                C0026F.m298j6(str);
                return;
            }
            C0026F.m283DW((Context) U.lg());
            C0026F.m298j6(str);
            C0026F.m295j6((Context) U.lg());
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -1153740540392817704L, this, str);
            }
            throw th;
        }
    }

    @su(method = -565330052686229565L)
    public void m199lg() {
        try {
            if (f122j6) {
                wu.j6(126753521188421888L, this);
            }
            TrainerNotificationAlarmReceiver.j6(U.Zo());
            PromoNotificationAlarmReceiver.j6(U.Zo());
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 126753521188421888L, this);
            }
            throw th;
        }
    }

    @su(method = -3721792343971238200L)
    private boolean m200rN() {
        try {
            if (f122j6) {
                wu.j6(3145210352097905517L, this);
            }
            if (U.ro() || U.ef()) {
                return true;
            }
            if (U.j6.equals("com.aide.web")) {
                try {
                    GregorianCalendar gregorianCalendar = new GregorianCalendar();
                    gregorianCalendar.setTimeInMillis(U.Zo().getPackageManager().getPackageInfo(U.j6, 0).firstInstallTime);
                    if (gregorianCalendar.before(new GregorianCalendar(2016, 11, 13))) {
                        return true;
                    }
                } catch (PackageManager.NameNotFoundException unused) {
                }
            }
            m195a8();
            return System.currentTimeMillis() < this.f130tp.get();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 3145210352097905517L, this);
            }
            throw th;
        }
    }

    public long m201DW() {
        try {
            if (f122j6) {
                wu.j6(4453378525276254145L, this);
            }
            return U.Zo().getSharedPreferences("LicenseService", 0).getLong("first_shop_time", -1L);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 4453378525276254145L, this);
            }
            throw th;
        }
    }

    public void m202DW(long j) {
        try {
            if (f122j6) {
                wu.j6(-6582413399638072623L, this, new Long(j));
            }
            this.f130tp.set(j);
            m198j6("Developer license verified");
            C0112H.m1011j6(U.Zo(), "Developer", true);
            SharedPreferences.Editor editorEdit = U.Zo().getSharedPreferences("InAppBillingSettings", 0).edit();
            editorEdit.putBoolean("WasDeveloperLicensedAtSomePoint", true);
            editorEdit.commit();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -6582413399638072623L, this, new Long(j));
            }
            throw th;
        }
    }

    public void m203DW(Activity activity, String str, String str2) {
        try {
            if (f122j6) {
                wu.j6(-606448954352369625L, this, activity, str, str2);
            }
            if (U.ef()) {
                return;
            }
            U.QX().j6(str, true, str2);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -606448954352369625L, this, activity, str, str2);
            }
            throw th;
        }
    }

    public boolean m204DW(Activity activity, String str) {
        try {
            if (f122j6) {
                wu.j6(1338284351672724429L, this, activity, str);
            }
            return m194DW(activity, com.aide.pro.R.string.shop_feature_premium_settings, "setting_" + str);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 1338284351672724429L, this, activity, str);
            }
            throw th;
        }
    }

    public boolean m205EQ() {
        try {
            if (f122j6) {
                wu.j6(-5299563432382699920L, this);
            }
            if (U.ro() || U.ef() || m200rN()) {
                return true;
            }
            m195a8();
            if (System.currentTimeMillis() < this.f131u7.get()) {
                return true;
            }
            this.f133we.j6();
            return System.currentTimeMillis() < this.f125Hw;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -5299563432382699920L, this);
            }
            throw th;
        }
    }

    public void m206FH() {
        try {
            if (f122j6) {
                wu.j6(747801893305988400L, this);
            }
            this.f123EQ.DW();
            this.f123EQ.j6();
            this.f133we.DW();
            this.f133we.j6();
            if (!m218VH()) {
                C0112H.m1011j6(U.Zo(), "Premium", false);
            }
            if (m237we()) {
                return;
            }
            C0112H.m1011j6(U.Zo(), "UIDesigner", false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 747801893305988400L, this);
            }
            throw th;
        }
    }

    public void m207FH(long j) {
        try {
            if (f122j6) {
                wu.j6(-4949806600581638560L, this, new Long(j));
            }
            boolean z = System.currentTimeMillis() < this.f124FH;
            this.f124FH = j;
            if (z) {
                return;
            }
            m199lg();
            m198j6("Premium license verified");
            C0112H.m1011j6(U.Zo(), "Premium", true);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -4949806600581638560L, this, new Long(j));
            }
            throw th;
        }
    }

    public void m208FH(Activity activity, String str) {
        try {
            if (f122j6) {
                wu.j6(-4509976496187872212L, this, activity, str);
            }
            if (m221Zo()) {
                return;
            }
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(C0026F.m291j6(U.j6, "com.aide.premium.key", str)));
            intent.setFlags(1074266112);
            try {
                U.VH().startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                ma.j6(U.VH(), "Google Play Store", "Google Play Store App could not be opened. Not installed?");
            }
            C0026F.m299j6("Premium key market page shown", (Map<String, String>) Collections.singletonMap("linkid", str));
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -4509976496187872212L, this, activity, str);
            }
            throw th;
        }
    }

    public void m209FH(Activity activity, String str, String str2) {
        try {
            if (f122j6) {
                wu.j6(-2144703421766129133L, this, activity, str, str2);
            }
            if (U.ef()) {
                return;
            }
            C0026F.m299j6("Edition shown " + str, (Map<String, String>) Collections.singletonMap("linkid", str2));
            Intent intent = new Intent("android.intent.action.VIEW");
            intent.setData(Uri.parse(C0026F.m291j6(U.j6, str, str2)));
            intent.setFlags(1074266112);
            try {
                U.VH().startActivity(intent);
            } catch (ActivityNotFoundException unused) {
                ma.j6(U.VH(), "Google Play Store", "Google Play Store App could not be opened. Not installed?");
            }
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -2144703421766129133L, this, activity, str, str2);
            }
            throw th;
        }
    }

    public void m210Hw(long j) {
        try {
            if (f122j6) {
                wu.j6(-1816418135529324711L, this, new Long(j));
            }
            this.f125Hw = j;
            m198j6("UI Builder license verified");
            C0112H.m1011j6(U.Zo(), "UIDesigner", true);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -1816418135529324711L, this, new Long(j));
            }
            throw th;
        }
    }

    public void m211Hw(Activity activity, String str, String str2) {
        try {
            if (f122j6) {
                wu.j6(-3610362533331703455L, this, activity, str, str2);
            }
            for (String str3 : new String[]{"com.aide.ui", "com.aide.web", "com.aide.cpp", "com.aide.phonegap"}) {
                for (Ui ui : U.Hw()) {
                    List<g.b> listFH = ui.FH();
                    if (listFH != null) {
                        for (g.b bVar : listFH) {
                            if (bVar.FH.equals(str) && Arrays.asList(bVar.v5).contains(str3)) {
                                m209FH(activity, str3, str2);
                                return;
                            }
                        }
                    }
                }
            }
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -3610362533331703455L, this, activity, str, str2);
            }
            throw th;
        }
    }

    public boolean m212Hw() {
        try {
            if (f122j6) {
                wu.j6(-6174224977488323027L, this);
            }
            return m200rN() || m235u7() || m236v5() || m221Zo() || m205EQ();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -6174224977488323027L, this);
            }
            throw th;
        }
    }

    public void m213J0() {
        try {
            if (f122j6) {
                wu.j6(-1138790814506516744L, this);
            }
            this.f124FH = 0L;
            C0112H.m1011j6(U.Zo(), "Premium", false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -1138790814506516744L, this);
            }
            throw th;
        }
    }

    public void m214J8() {
        try {
            if (f122j6) {
                wu.j6(5209077328786717568L, this);
            }
            this.f128Zo = true;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 5209077328786717568L, this);
            }
            throw th;
        }
    }

    public boolean m215Mr() {
        try {
            if (f122j6) {
                wu.j6(3464804052391628955L, this);
            }
            if (U.ro() || U.ef()) {
                return true;
            }
            return U.Zo().getSharedPreferences("InAppBillingSettings", 0).getBoolean("WasPrimeAtSomePoint", false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 3464804052391628955L, this);
            }
            throw th;
        }
    }

    public void m216QX() {
        try {
            if (f122j6) {
                wu.j6(-1838863534148358200L, this);
            }
            this.f127VH = true;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -1838863534148358200L, this);
            }
            throw th;
        }
    }

    public boolean m217U2() {
        try {
            if (f122j6) {
                wu.j6(-159770495043666572L, this);
            }
            if (m215Mr() || m224j3()) {
                return true;
            }
            return m218VH() && m237we() && m222aM();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -159770495043666572L, this);
            }
            throw th;
        }
    }

    public boolean m218VH() {
        try {
            if (f122j6) {
                wu.j6(-5144597395457319540L, this);
            }
            return this.f123EQ.FH();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -5144597395457319540L, this);
            }
            throw th;
        }
    }

    public void m219Ws() {
        try {
            if (f122j6) {
                wu.j6(2183249550071396477L, this);
            }
            this.f125Hw = 0L;
            C0112H.m1011j6(U.Zo(), "UIDesigner", false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 2183249550071396477L, this);
            }
            throw th;
        }
    }

    public void m220XL() {
        try {
            if (f122j6) {
                wu.j6(-3208404806142114436L, this);
            }
            this.f123EQ.v5();
            this.f133we.v5();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -3208404806142114436L, this);
            }
            throw th;
        }
    }

    public boolean m221Zo() {
        try {
            if (f122j6) {
                wu.j6(64075054600324521L, this);
            }
            if (U.ro() || U.ef()) {
                return true;
            }
            if (U.j6.equals("com.aide.phonegap")) {
                if (this.f129gn == null) {
                    this.f129gn = new d();
                    this.f129gn.j6(U.lg(), false);
                }
                this.f129gn.j6(new Ck(this));
                return true;
            }
            if (m200rN()) {
                return true;
            }
            m195a8();
            if (System.currentTimeMillis() < this.f131u7.get()) {
                return true;
            }
            this.f123EQ.j6();
            return System.currentTimeMillis() < this.f124FH;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 64075054600324521L, this);
            }
            throw th;
        }
    }

    public boolean m222aM() {
        try {
            if (f122j6) {
                wu.j6(3127144497962780880L, this);
            }
            if (U.ro() || U.ef()) {
                return true;
            }
            return U.Zo().getSharedPreferences("InAppBillingSettings", 0).getBoolean("WasDebuggerLicensedAtSomePoint", false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 3127144497962780880L, this);
            }
            throw th;
        }
    }

    public boolean m223gn() {
        try {
            if (f122j6) {
                wu.j6(-219774369393488192L, this);
            }
            this.f123EQ.j6();
            return this.f128Zo;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -219774369393488192L, this);
            }
            throw th;
        }
    }

    public boolean m224j3() {
        try {
            if (f122j6) {
                wu.j6(-1467742067547199423L, this);
            }
            if (U.ro() || U.ef()) {
                return true;
            }
            if (U.j6.equals("com.aide.web")) {
                try {
                    GregorianCalendar gregorianCalendar = new GregorianCalendar();
                    gregorianCalendar.setTimeInMillis(U.Zo().getPackageManager().getPackageInfo(U.j6, 0).firstInstallTime);
                    if (gregorianCalendar.before(new GregorianCalendar(2016, 11, 13))) {
                        return true;
                    }
                } catch (PackageManager.NameNotFoundException unused) {
                }
            }
            return U.Zo().getSharedPreferences("InAppBillingSettings", 0).getBoolean("WasDeveloperLicensedAtSomePoint", false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -1467742067547199423L, this);
            }
            throw th;
        }
    }

    public void m225j6(long j) {
        try {
            if (f122j6) {
                wu.j6(106833866093579277L, this, new Long(j));
            }
            this.f132v5 = j;
            m198j6("Debugger license verified");
            C0112H.m1011j6(U.Zo(), "Debugger", true);
            SharedPreferences.Editor editorEdit = U.Zo().getSharedPreferences("InAppBillingSettings", 0).edit();
            editorEdit.putBoolean("WasDebuggerLicensedAtSomePoint", true);
            editorEdit.commit();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 106833866093579277L, this, new Long(j));
            }
            throw th;
        }
    }

    public void m226j6(long j, boolean z) {
        try {
            if (f122j6) {
                wu.j6(4830136333632272037L, this, new Long(j), new Boolean(z));
            }
            this.f131u7.set(j);
            this.f126J0.set(z);
            U.j6(new Dk(this));
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 4830136333632272037L, this, new Long(j), new Boolean(z));
            }
            throw th;
        }
    }

    public void m227j6(Activity activity, int i, int i2, String str, boolean z) {
        try {
            if (f122j6) {
                wu.j6(6504810879069821185L, this, activity, new Integer(i), new Integer(i2), str, new Boolean(z));
            }
            m196er();
            c.j6(activity, i, i2 != 0 ? U.Zo().getResources().getString(i2) : "", str, z);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 6504810879069821185L, this, activity, new Integer(i), new Integer(i2), str, new Boolean(z));
            }
            throw th;
        }
    }

    public void m228j6(Activity activity, int i, String str) {
        try {
            if (f122j6) {
                wu.j6(-385487729671325952L, this, activity, new Integer(i), str);
            }
            if (m221Zo()) {
                return;
            }
            m195a8();
            m229j6(activity, i, str, false, false);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -385487729671325952L, this, activity, new Integer(i), str);
            }
            throw th;
        }
    }

    public void m229j6(Activity activity, int i, String str, boolean z, boolean z2) {
        try {
            if (f122j6) {
                wu.j6(-1122893914841510225L, this, activity, new Integer(i), str, new Boolean(z), new Boolean(z2));
            }
            m196er();
            if (!com.aide.common.g.J8(activity) && (U.j6.equals("com.aide.ui") || U.j6.equals("com.aide.web"))) {
                c.j6(activity, i, str, z, z2);
                return;
            }
            m227j6(activity, i, 0, str, z2);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -1122893914841510225L, this, activity, new Integer(i), str, new Boolean(z), new Boolean(z2));
            }
            throw th;
        }
    }

    public void m230j6(Activity activity, String str, String str2) {
        try {
            if (f122j6) {
                wu.j6(177444579551092821L, this, activity, str, str2);
            }
            if (U.ef()) {
                return;
            }
            U.QX().j6(str, false, str2);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 177444579551092821L, this, activity, str, str2);
            }
            throw th;
        }
    }

    public boolean m231j6() {
        try {
            if (f122j6) {
                wu.j6(-110968290167263808L, this);
            }
            if (m235u7() || m200rN()) {
                return true;
            }
            return m221Zo() && m205EQ() && m236v5();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -110968290167263808L, this);
            }
            throw th;
        }
    }

    public boolean m232j6(Activity activity) {
        try {
            if (f122j6) {
                wu.j6(-913028588914349964L, this, activity);
            }
            if (m236v5()) {
                return true;
            }
            m229j6(activity, com.aide.pro.R.string.shop_feature_debugger, "debugger", false, false);
            return false;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -913028588914349964L, this, activity);
            }
            throw th;
        }
    }

    public boolean m233j6(Activity activity, String str) {
        try {
            if (f122j6) {
                wu.j6(808434900014983033L, this, activity, str);
            }
            return m194DW(activity, com.aide.pro.R.string.shop_feature_premium, "feature_" + str);
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 808434900014983033L, this, activity, str);
            }
            throw th;
        }
    }

    public boolean m234tp() {
        try {
            if (f122j6) {
                wu.j6(-4830149327964595461L, this);
            }
            return this.f126J0.get();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -4830149327964595461L, this);
            }
            throw th;
        }
    }

    public boolean m235u7() {
        try {
            if (f122j6) {
                wu.j6(3603857704322702427L, this);
            }
            if (U.ro() || U.ef()) {
                return true;
            }
            m195a8();
            return System.currentTimeMillis() < this.f131u7.get();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 3603857704322702427L, this);
            }
            throw th;
        }
    }

    public boolean m236v5() {
        try {
            if (f122j6) {
                wu.j6(-4582521866206478684L, this);
            }
            if (U.ro() || U.ef() || m200rN()) {
                return true;
            }
            m195a8();
            return System.currentTimeMillis() < this.f131u7.get() || System.currentTimeMillis() < this.f132v5;
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, -4582521866206478684L, this);
            }
            throw th;
        }
    }

    public boolean m237we() {
        try {
            if (f122j6) {
                wu.j6(59752351634626200L, this);
            }
            return this.f133we.FH();
        } catch (Throwable th) {
            if (f121DW) {
                wu.j6(th, 59752351634626200L, this);
            }
            throw th;
        }
    }
}
