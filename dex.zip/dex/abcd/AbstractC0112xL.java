package abcd;

public abstract class AbstractC0112xL extends EL {
    public int hashCode() {
        return -1;
    }

    boolean m493j6(EL el) {
        return el instanceof AbstractC0112xL;
    }

    public String toString() {
        return "NULL";
    }
}
