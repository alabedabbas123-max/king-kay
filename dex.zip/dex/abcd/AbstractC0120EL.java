package abcd;

import java.io.IOException;

public abstract class AbstractC0120EL extends yL {
    AbstractC0120EL() {
    }

    public static AbstractC0120EL m772j6(byte[] bArr) throws IOException {
        try {
            return new vL(bArr).Hw();
        } catch (ClassCastException unused) {
            throw new IOException("cannot recognise object in stream");
        }
    }

    public AbstractC0120EL m773DW() {
        return this;
    }

    AbstractC0120EL m774VH() {
        return this;
    }

    abstract boolean mo163Zo();

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof qL) && mo165j6(((qL) obj).DW());
    }

    AbstractC0120EL m775gn() {
        return this;
    }

    abstract void mo164j6(C0034CL c0034cl);

    abstract boolean mo165j6(AbstractC0120EL abstractC0120EL);

    abstract int mo166v5();
}
