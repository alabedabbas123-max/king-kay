package abcd;

import java.util.BitSet;

public class C0019Et {

    private final Or f142DW;

    private final Or f143FH;

    private final fs f144j6;

    public C0019Et(fs fsVar) {
        this.f144j6 = fsVar;
        this.f142DW = this.f144j6.j6();
        this.f143FH = this.f142DW.gW();
    }

    private void m253j6(int i, au auVar) {
        int size = auVar.size();
        for (int i2 = 0; i2 < size; i2++) {
            int i3 = auVar.get(i2);
            au auVarJ6 = this.f144j6.j6(this.f142DW.v5(i3).DW());
            int size2 = auVarJ6.size();
            for (int i4 = 0; i4 < size2; i4++) {
                m254j6(this.f143FH.v5(auVarJ6.get(i4)), i3, i);
            }
        }
    }

    private void m254j6(Nr nr, int i, int i2) {
        au auVarLg = nr.gn().lg();
        auVarLg.FH(auVarLg.v5(i), i2);
        int iZo = nr.Zo();
        if (iZo != i) {
            i2 = iZo;
        }
        auVarLg.we();
        Nr nr2 = new Nr(nr.DW(), nr.Hw(), auVarLg, i2);
        Or or = this.f143FH;
        or.j6(or.Hw(nr.DW()), nr2);
    }

    private static boolean m255j6(Nr nr, Nr nr2) {
        return nr.Hw().j6(nr2.Hw());
    }

    public fs m256j6() {
        int size = this.f142DW.size();
        BitSet bitSet = new BitSet(this.f142DW.rN());
        for (int i = 0; i < size; i++) {
            Nr nr = this.f142DW.get(i);
            if (!bitSet.get(nr.DW())) {
                au auVarJ6 = this.f144j6.j6(nr.DW());
                int size2 = auVarJ6.size();
                for (int i2 = 0; i2 < size2; i2++) {
                    int i3 = auVarJ6.get(i2);
                    Nr nrV5 = this.f142DW.v5(i3);
                    if (!bitSet.get(i3) && nrV5.gn().size() <= 1 && nrV5.FH().v5().Hw() != 55) {
                        au auVar = new au();
                        for (int i4 = i2 + 1; i4 < size2; i4++) {
                            int i5 = auVarJ6.get(i4);
                            Nr nrV6 = this.f142DW.v5(i5);
                            if (nrV6.gn().size() == 1 && m255j6(nrV5, nrV6)) {
                                auVar.DW(i5);
                                bitSet.set(i5);
                            }
                        }
                        m253j6(i3, auVar);
                    }
                }
            }
        }
        for (int i6 = size - 1; i6 >= 0; i6--) {
            if (bitSet.get(this.f143FH.get(i6).DW())) {
                this.f143FH.j6(i6, (Nr) null);
            }
        }
        this.f143FH.lg();
        this.f143FH.we();
        return new fs(this.f143FH, this.f144j6.DW());
    }
}
