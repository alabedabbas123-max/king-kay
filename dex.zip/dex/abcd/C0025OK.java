package abcd;

import java.io.File;

class C0025OK extends FG {

    final C0068PK f133tp;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    C0025OK(C0068PK c0068pk, File file, pK pKVar) {
        super(file, pKVar);
        this.f133tp = c0068pk;
    }

    public boolean m171VH() {
        return false;
    }

    public void m172gn() {
    }
}
