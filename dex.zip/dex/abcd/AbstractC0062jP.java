package abcd;

public abstract class AbstractC0062jP {
    public abstract void configure(gP gPVar);
}
