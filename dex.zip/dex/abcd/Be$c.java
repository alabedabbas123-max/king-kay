package abcd;

@xu
public class Be$c extends Be$b {

    @uu
    private static boolean f451VH;

    @tu
    private static boolean f452Zo;

    public String f453gn;

    static {
        wu.j6(Be$c.class, 31424070432103911L, 31424070432103911L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$c(int i) {
        super(i);
        try {
            if (f452Zo) {
                wu.j6(-1365430300804738289L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f451VH) {
                wu.j6(th, -1365430300804738289L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }

    public String m1277j6(String str) {
        try {
            if (f452Zo) {
                wu.j6(-93095401323740544L, this, str);
            }
            if (this.f453gn == null) {
                return null;
            }
            return Vl.VH(str, this.f453gn);
        } catch (Throwable th) {
            if (f451VH) {
                wu.j6(th, -93095401323740544L, this, str);
            }
            throw th;
        }
    }
}
