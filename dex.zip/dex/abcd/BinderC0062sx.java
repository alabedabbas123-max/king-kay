package abcd;

import android.os.Binder;
import android.os.IInterface;

public class BinderC0062sx extends Binder implements IInterface {
}
