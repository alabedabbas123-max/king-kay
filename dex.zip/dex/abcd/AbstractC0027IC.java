package abcd;

import java.io.IOException;

abstract class AbstractC0027IC {

    protected QC[] f191DW;

    protected int f192FH;

    protected C0112KC f193j6;

    protected AbstractC0027IC(C0112KC c0112kc, int i) {
        this.f193j6 = c0112kc;
        this.f191DW = new QC[i];
    }

    public abstract void m316DW();

    public C0112KC m317FH() {
        return this.f193j6;
    }

    protected void m318Hw() {
        int i = this.f192FH;
        QC[] qcArr = this.f191DW;
        if (i < qcArr.length / 2) {
            QC[] qcArr2 = new QC[i];
            System.arraycopy(qcArr, 0, qcArr2, 0, i);
            this.f191DW = qcArr2;
        }
        this.f193j6.m1037j6(this.f191DW, this.f192FH);
    }

    protected void m319j6(int i, int i2) {
        int i3 = this.f192FH;
        if (i3 + i2 > this.f191DW.length) {
            QC[] qcArr = new QC[Math.max(((i3 + 16) * 3) / 2, i3 + i2)];
            System.arraycopy(this.f191DW, 0, qcArr, 0, this.f192FH);
            this.f191DW = qcArr;
        }
        this.f193j6.m1035j6(i, this.f191DW, this.f192FH, i2);
        this.f192FH += i2;
    }

    protected void m320j6(QC qc) {
        QC[] qcArr = this.f191DW;
        int length = qcArr.length;
        int i = this.f192FH;
        if (length == i) {
            QC[] qcArr2 = new QC[((i + 16) * 3) / 2];
            System.arraycopy(qcArr, 0, qcArr2, 0, i);
            this.f191DW = qcArr2;
        }
        QC[] qcArr3 = this.f191DW;
        int i2 = this.f192FH;
        this.f192FH = i2 + 1;
        qcArr3[i2] = qc;
    }

    public boolean m321j6() throws IOException {
        m316DW();
        this.f193j6.m1024EQ();
        return this.f193j6.m1025FH();
    }
}
