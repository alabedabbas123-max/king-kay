package abcd;

public final class C0007ex {

    public static final int f55s1 = com.aide.pro.R.string.s1;

    public static final int f56s2 = com.aide.pro.R.string.s2;

    public static final int f57s3 = com.aide.pro.R.string.s3;

    public static final int f58s4 = com.aide.pro.R.string.s4;

    public static final int f59s5 = com.aide.pro.R.string.s5;

    public static final int f60s6 = com.aide.pro.R.string.s6;

    public static final int f61s7 = com.aide.pro.R.string.s7;
}
