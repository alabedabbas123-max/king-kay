package abcd;

public abstract class AbstractRunnableC0045iz extends C0089jz implements Runnable {
}
