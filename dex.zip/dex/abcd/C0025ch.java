package abcd;

import com.aide.ui.U;

@xu
public class C0025ch implements _l {

    @uu
    private static boolean f80DW;

    @tu
    private static boolean f81j6;

    static {
        wu.j6(C0025ch.class, 1364190057063971L, 1364190057063971L);
    }

    public C0025ch() {
        try {
            if (f81j6) {
                wu.j6(-4612239745123818567L, (Object) null);
            }
        } catch (Throwable th) {
            if (f80DW) {
                wu.j6(th, -4612239745123818567L, (Object) null);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f81j6) {
                wu.j6(-2491029940215663451L, this);
            }
            return U.gn().J0();
        } catch (Throwable th) {
            if (f80DW) {
                wu.j6(th, -2491029940215663451L, this);
            }
            throw th;
        }
    }

    public int m129j6() {
        try {
            if (!f81j6) {
                return com.aide.pro.R.id.mainMenuStepOver;
            }
            wu.j6(4209664394147838543L, this);
            return com.aide.pro.R.id.mainMenuStepOver;
        } catch (Throwable th) {
            if (f80DW) {
                wu.j6(th, 4209664394147838543L, this);
            }
            throw th;
        }
    }

    public boolean m130j6(boolean z) {
        try {
            if (f81j6) {
                wu.j6(157704758762245827L, this, z);
            }
            return U.gn().tp() && !U.lg().J8().Ws();
        } catch (Throwable th) {
            if (f80DW) {
                wu.j6(th, 157704758762245827L, this, new Boolean(z));
            }
            throw th;
        }
    }

    public boolean m131run() {
        try {
            if (f81j6) {
                wu.j6(997480146549669939L, this);
            }
            U.gn().aM();
            return true;
        } catch (Throwable th) {
            if (f80DW) {
                wu.j6(th, 997480146549669939L, this);
            }
            throw th;
        }
    }
}
