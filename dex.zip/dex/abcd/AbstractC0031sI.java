package abcd;

public abstract class AbstractC0031sI extends jJ {
    protected AbstractC0031sI(UE ue, HJ hj) {
        super(ue, hj);
    }
}
