package abcd;

class C0013rr implements d<Wp> {

    final xr f31j6;

    C0013rr(xr xrVar) {
        this.f31j6 = xrVar;
    }

    public Wp m137j6(Wp wp, yr yrVar) {
        return yrVar.j6(wp);
    }

    public void m139j6(hr.a aVar, Wp wp, int i, int i2, yr yrVar) {
        yrVar.j6(i, i2);
        wp.j6(aVar);
    }
}
