package abcd;

public final class C0018op implements lu, Comparable<C0018op> {

    private Wo f92DW;

    private final ws f93j6;

    public C0018op(ws wsVar, Wo wo) {
        if (wsVar == null) {
            throw new NullPointerException("field == null");
        }
        if (wo == null) {
            throw new NullPointerException("annotations == null");
        }
        this.f93j6 = wsVar;
        this.f92DW = wo;
    }

    public String m61aM() {
        return this.f93j6.aM() + ": " + this.f92DW;
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0018op) {
            return this.f93j6.equals(((C0018op) obj).f93j6);
        }
        return false;
    }

    public int hashCode() {
        return this.f93j6.hashCode();
    }

    @Override
    public int compareTo(C0018op c0018op) {
        return this.f93j6.j6(c0018op.f93j6);
    }

    public void m63j6(jp jpVar) {
        C0103qp c0103qpV5 = jpVar.v5();
        Fp fpXL = jpVar.XL();
        c0103qpV5.m536DW(this.f93j6);
        this.f92DW = fpXL.DW(this.f92DW);
    }

    public void m64j6(jp jpVar, Lt lt) {
        int iM539j6 = jpVar.v5().m539j6(this.f93j6);
        int iWe = this.f92DW.we();
        if (lt.Hw()) {
            lt.j6(0, "    " + this.f93j6.aM());
            lt.j6(4, "      field_idx:       " + Yt.gn(iM539j6));
            lt.j6(4, "      annotations_off: " + Yt.gn(iWe));
        }
        lt.writeInt(iM539j6);
        lt.writeInt(iWe);
    }
}
