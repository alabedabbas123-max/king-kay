package abcd;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.TreeMap;

public final class C0015Hr extends hu implements Comparable<C0015Hr>, lu {

    private final Ks f100DW;

    private final EnumC0057Ir f101FH;

    private final TreeMap<C0101Js, Lr> f102Hw;

    public C0015Hr(Ks ks, EnumC0057Ir enumC0057Ir) {
        if (ks == null) {
            throw new NullPointerException("type == null");
        }
        if (enumC0057Ir == null) {
            throw new NullPointerException("visibility == null");
        }
        this.f100DW = ks;
        this.f101FH = enumC0057Ir;
        this.f102Hw = new TreeMap<>();
    }

    public void m172DW(Lr lr) {
        J8();
        if (lr == null) {
            throw new NullPointerException("pair == null");
        }
        this.f102Hw.put(lr.Hw(), lr);
    }

    public String m173aM() {
        StringBuilder sb = new StringBuilder();
        sb.append(this.f101FH.m632aM());
        sb.append("-annotation ");
        sb.append(this.f100DW.aM());
        sb.append(" {");
        boolean z = true;
        for (Lr lr : this.f102Hw.values()) {
            if (z) {
                z = false;
            } else {
                sb.append(", ");
            }
            sb.append(lr.Hw().m974aM());
            sb.append(": ");
            sb.append(lr.Zo().aM());
        }
        sb.append("}");
        return sb.toString();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0015Hr)) {
            return false;
        }
        C0015Hr c0015Hr = (C0015Hr) obj;
        if (this.f100DW.equals(c0015Hr.f100DW) && this.f101FH == c0015Hr.f101FH) {
            return this.f102Hw.equals(c0015Hr.f102Hw);
        }
        return false;
    }

    public Ks getType() {
        return this.f100DW;
    }

    public int hashCode() {
        return (((this.f100DW.hashCode() * 31) + this.f102Hw.hashCode()) * 31) + this.f101FH.hashCode();
    }

    @Override
    public int compareTo(C0015Hr c0015Hr) {
        int iJ6 = this.f100DW.j6(c0015Hr.f100DW);
        if (iJ6 != 0) {
            return iJ6;
        }
        int iCompareTo = this.f101FH.compareTo(c0015Hr.f101FH);
        if (iCompareTo != 0) {
            return iCompareTo;
        }
        Iterator<Lr> it = this.f102Hw.values().iterator();
        Iterator<Lr> it2 = c0015Hr.f102Hw.values().iterator();
        while (it.hasNext() && it2.hasNext()) {
            int iJ7 = it.next().j6(it2.next());
            if (iJ7 != 0) {
                return iJ7;
            }
        }
        if (it.hasNext()) {
            return 1;
        }
        return it2.hasNext() ? -1 : 0;
    }

    public void m175j6(Lr lr) {
        J8();
        if (lr == null) {
            throw new NullPointerException("pair == null");
        }
        C0101Js c0101JsHw = lr.Hw();
        if (this.f102Hw.get(c0101JsHw) == null) {
            this.f102Hw.put(c0101JsHw, lr);
            return;
        }
        throw new IllegalArgumentException("name already added: " + c0101JsHw);
    }

    public Collection<Lr> m176lg() {
        return Collections.unmodifiableCollection(this.f102Hw.values());
    }

    public EnumC0057Ir m177rN() {
        return this.f101FH;
    }

    public String toString() {
        return m173aM();
    }
}
