package abcd;

import java.math.BigInteger;

public class C0010lM extends EL {

    byte[] f58j6;

    public C0010lM(int i) {
        this.f58j6 = BigInteger.valueOf(i).toByteArray();
    }

    public C0010lM(BigInteger bigInteger) {
        this.f58j6 = bigInteger.toByteArray();
    }

    public C0010lM(byte[] bArr) {
        this.f58j6 = bArr;
    }

    public static wL m70j6(LL ll, boolean z) {
        EL elU7 = ll.u7();
        return (z || (elU7 instanceof C0010lM)) ? m71j6((Object) elU7) : new wL(AL.j6(ll.u7()).u7());
    }

    public static wL m71j6(Object obj) {
        if (obj == null || (obj instanceof wL)) {
            return (wL) obj;
        }
        if (obj instanceof C0010lM) {
            return new wL(((C0010lM) obj).m75tp());
        }
        throw new IllegalArgumentException("illegal object in getInstance: " + obj.getClass().getName());
    }

    boolean m72Zo() {
        return false;
    }

    public int hashCode() {
        int i = 0;
        int i2 = 0;
        while (true) {
            byte[] bArr = this.f58j6;
            if (i == bArr.length) {
                return i2;
            }
            i2 ^= (bArr[i] & 255) << (i % 4);
            i++;
        }
    }

    void m73j6(CL cl) {
        cl.j6(2, this.f58j6);
    }

    boolean m74j6(EL el) {
        if (el instanceof C0010lM) {
            return OP.j6(this.f58j6, ((C0010lM) el).f58j6);
        }
        return false;
    }

    public String toString() {
        return m75tp().toString();
    }

    public BigInteger m75tp() {
        return new BigInteger(this.f58j6);
    }

    public BigInteger m76u7() {
        return new BigInteger(1, this.f58j6);
    }

    int m77v5() {
        return OM.j6(this.f58j6.length) + 1 + this.f58j6.length;
    }
}
