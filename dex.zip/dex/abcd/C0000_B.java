package abcd;

import org.eclipse.jgit.JGitText;

public class C0000_B extends NB {
    public C0000_B() {
        super(JGitText.j6().unmergedPaths);
    }
}
