package abcd;

@xu
public class C0002Ec extends C0003Ed {

    @uu
    private static boolean f53QX;

    @tu
    private static boolean f54Ws;

    @ru(field = -2818312186944331035L)
    private _b f55Mr;

    @ru(field = 2499642038751122295L)
    private Cb f56U2;

    @ru(field = 2480255487950380896L)
    private final La f57XL;

    @ru(field = -193134621565374192L)
    private final Hd f58aM;

    @ru(field = -2367020310169348585L)
    private final yd f59j3;

    static {
        wu.j6(C0002Ec.class, -513772379058812832L, -513772379058812832L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0002Ec(La la, Bc bc) {
        super(la, bc);
        try {
            if (f54Ws) {
                wu.j6(172246938447311735L, (Object) null, la, bc);
            }
            this.f57XL = la;
            this.f59j3 = bc;
            this.f58aM = bc.FH();
            this.f55Mr = new _b(la.Mr);
            this.f56U2 = new Cb();
        } catch (Throwable th) {
            if (f53QX) {
                wu.j6(th, 172246938447311735L, (Object) null, la, bc);
            }
            throw th;
        }
    }

    @Override
    public long mo70DW(Sa sa) {
        try {
            if (!f54Ws) {
                return 0L;
            }
            wu.j6(5796477585997516495L, this, sa);
            return 0L;
        } catch (Throwable th) {
            if (f53QX) {
                wu.j6(th, 5796477585997516495L, this, sa);
            }
            throw th;
        }
    }

    @Override
    public long mo71Hw(Sa sa) {
        try {
            if (!f54Ws) {
                return 0L;
            }
            wu.j6(-2141794977862123293L, this, sa);
            return 0L;
        } catch (Throwable th) {
            if (f53QX) {
                wu.j6(th, -2141794977862123293L, this, sa);
            }
            throw th;
        }
    }

    @Override
    public void mo72Hw(Da da) {
        try {
            if (f54Ws) {
                wu.j6(-4324578288929117424L, this, da);
            }
            if (!da.er()) {
                super.mo72Hw(da);
                return;
            }
            Da daWs = da.Ws();
            this.f56U2.j6();
            for (Da daQX = da.QX(); daQX != daWs; daQX = daQX.QX()) {
                this.f56U2.j6(daQX.u7());
            }
            Na naU7 = this.f58aM.u7();
            Na naJ6 = naU7;
            for (int iHw = this.f56U2.Hw() - 1; iHw >= 0; iHw--) {
                naJ6 = naJ6.j6(this.f56U2.DW(iHw));
            }
            this.f57XL.a8.j6(da, this.f59j3, naJ6, da.J8(), false, -1);
        } catch (Throwable th) {
            if (f53QX) {
                wu.j6(th, -4324578288929117424L, this, da);
            }
            throw th;
        }
    }

    @Override
    public long mo73v5(Sa sa) {
        try {
            if (!f54Ws) {
                return 0L;
            }
            wu.j6(-1603456240630352880L, this, sa);
            return 0L;
        } catch (Throwable th) {
            if (f53QX) {
                wu.j6(th, -1603456240630352880L, this, sa);
            }
            throw th;
        }
    }
}
