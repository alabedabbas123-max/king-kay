package abcd;

import com.aide.engine.EngineSolution;
import com.aide.engine.EngineSolutionProject;
import com.aide.engine.service.x;
import com.aide.ui.U;
import java.util.ArrayList;

@xu
public class C0012oj {

    @uu
    private static boolean f78DW;

    @tu
    private static boolean f79j6;

    static {
        wu.j6(C0012oj.class, 5531562394700995328L, 5531562394700995328L);
    }

    public C0012oj() {
        try {
            if (f79j6) {
                wu.j6(1911039512398473105L, (Object) null);
            }
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, 1911039512398473105L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -170490128409866685L)
    private static EngineSolutionProject m43DW(String str) {
        try {
            if (f79j6) {
                wu.j6(-1789172338563227552L, (Object) null, str);
            }
            String str2 = str + "/bin";
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            arrayList.add(new EngineSolution.File(str + "/jni", "C++", (String) null, false, false));
            return new EngineSolutionProject(str, str, str, arrayList, arrayList2, true, "", str2, str2, "1.5", false, false, false, false, "", new ArrayList(), new ArrayList(), new ArrayList());
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, -1789172338563227552L, (Object) null, str);
            }
            throw th;
        }
    }

    public static EngineSolution m44j6(String str) {
        try {
            if (f79j6) {
                wu.j6(-947437862087354149L, (Object) null, str);
            }
            ArrayList arrayList = new ArrayList();
            arrayList.add(m43DW(str));
            return new EngineSolution(arrayList, (String) null, x.j6(U.FH()), U.FH());
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, -947437862087354149L, (Object) null, str);
            }
            throw th;
        }
    }
}
