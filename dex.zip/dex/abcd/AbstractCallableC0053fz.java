package abcd;

import java.util.concurrent.Callable;

public abstract class AbstractCallableC0053fz<V> extends jz implements Callable<V> {
}
