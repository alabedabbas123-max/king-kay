package abcd;

public abstract class AbstractC0057jK {

    public static final AbstractC0057jK f245j6 = new a(null);

    public static final AbstractC0057jK f244DW = new b(0 == true ? 1 : 0);

    private static final class a extends AbstractC0057jK {
        private a() {
        }

        a(a aVar) {
            this();
        }

        @Override
        public AbstractC0057jK m694clone() {
            return this;
        }

        @Override
        public boolean mo68j6() {
            return false;
        }

        @Override
        public boolean mo69j6(YJ yj) {
            return true;
        }

        @Override
        public String toString() {
            return "ALL";
        }
    }

    private static final class b extends AbstractC0057jK {
        private b() {
        }

        b(b bVar) {
            this();
        }

        @Override
        public AbstractC0057jK m694clone() {
            return this;
        }

        @Override
        public boolean mo68j6() {
            return false;
        }

        @Override
        public boolean mo69j6(YJ yj) {
            int iZo = yj.Zo();
            if (iZo == 1) {
                return true;
            }
            int iFH = yj.FH(0);
            for (int i = 1; i < iZo; i++) {
                if (yj.FH(i) != iFH || !yj.j6(i, 0)) {
                    return true;
                }
            }
            return false;
        }

        @Override
        public String toString() {
            return "ANY_DIFF";
        }
    }

    public abstract AbstractC0057jK m694clone();

    public abstract boolean mo68j6();

    public abstract boolean mo69j6(YJ yj);

    public String toString() {
        String name = getClass().getName();
        int iLastIndexOf = name.lastIndexOf(46);
        if (iLastIndexOf >= 0) {
            name = name.substring(iLastIndexOf + 1);
        }
        return name.replace('$', '.');
    }
}
