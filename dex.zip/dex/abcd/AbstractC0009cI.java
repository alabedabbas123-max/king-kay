package abcd;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;
import org.eclipse.jgit.JGitText;

abstract class AbstractC0009cI extends aI {

    protected OutputStream f19EQ;

    protected final UE f20Hw;

    protected EI f21J0;

    protected boolean f22J8;

    protected _K f24VH;

    protected boolean f25Ws;

    protected final jJ f27Zo;

    protected aL f28gn;

    protected InputStream f29tp;

    private VK f30u7;

    protected final HJ f31v5;

    protected DI f32we;

    private final Set<String> f23QX = new HashSet();

    protected final Set<yE> f26XL = new HashSet();

    AbstractC0009cI(BI bi) {
        this.f27Zo = (jJ) bi;
        jJ jJVar = this.f27Zo;
        this.f20Hw = jJVar.v5;
        this.f31v5 = jJVar.Zo;
    }

    private nD m47FH(String str) {
        return new nD(this.f31v5, MessageFormat.format(JGitText.j6().duplicateAdvertisementsOf, str));
    }

    private void m48we() throws oD, nD, EOFException, yD {
        int iIndexOf;
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        while (true) {
            try {
                String strDW = this.f32we.DW();
                if (strDW == DI.j6) {
                    j6(linkedHashMap);
                    return;
                }
                if (strDW.startsWith("ERR ")) {
                    throw new oD(this.f31v5, strDW.substring(4));
                }
                if (linkedHashMap.isEmpty() && (iIndexOf = strDW.indexOf(0)) >= 0) {
                    for (String str : strDW.substring(iIndexOf + 1).split(" ")) {
                        this.f23QX.add(str);
                    }
                    strDW = strDW.substring(0, iIndexOf);
                }
                String strSubstring = strDW.substring(41, strDW.length());
                if (!linkedHashMap.isEmpty() || !strSubstring.equals("capabilities^{}")) {
                    yE yEVarJ6 = yE.j6(strDW.substring(0, 40));
                    if (strSubstring.equals(".have")) {
                        this.f26XL.add(yEVarJ6);
                    } else if (strSubstring.endsWith("^{}")) {
                        String strSubstring2 = strSubstring.substring(0, strSubstring.length() - 3);
                        ME me = (ME) linkedHashMap.get(strSubstring2);
                        if (me == null) {
                            throw new nD(this.f31v5, MessageFormat.format(JGitText.j6().advertisementCameBefore, strSubstring2, strSubstring2));
                        }
                        if (me.FH() != null) {
                            throw m47FH(String.valueOf(strSubstring2) + "^{}");
                        }
                        linkedHashMap.put(strSubstring2, new BE.b(ME.a.v5, strSubstring2, me.DW(), yEVarJ6));
                    } else if (((ME) linkedHashMap.put(strSubstring, new BE.a(ME.a.v5, strSubstring, yEVarJ6))) != null) {
                        throw m47FH(strSubstring);
                    }
                }
            } catch (EOFException e) {
                if (!linkedHashMap.isEmpty()) {
                    throw e;
                }
                throw m53tp();
            }
        }
    }

    protected boolean m49DW(String str) {
        return this.f23QX.contains(str);
    }

    protected void m50EQ() throws oD, nD, yD {
        try {
            m48we();
        } catch (IOException e) {
            close();
            throw new yD(e.getMessage(), e);
        } catch (RuntimeException e2) {
            close();
            throw new yD(e2.getMessage(), e2);
        } catch (yD e3) {
            close();
            throw e3;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public void close() {
        if (this.f19EQ != null) {
            try {
                if (this.f22J8) {
                    this.f22J8 = false;
                    this.f21J0.j6();
                }
                this.f19EQ.close();
            } catch (IOException unused) {
            } finally {
                this.f19EQ = null;
                this.f21J0 = null;
            }
        }
        InputStream inputStream = this.f29tp;
        if (inputStream != null) {
            try {
                inputStream.close();
            } catch (IOException unused2) {
            } finally {
                this.f29tp = null;
                this.f32we = null;
            }
        }
        VK vk = this.f30u7;
        if (vk != null) {
            try {
                vk.DW();
            } finally {
                this.f30u7 = null;
                this.f24VH = null;
                this.f28gn = null;
            }
        }
    }

    protected final void m51j6(InputStream inputStream, OutputStream outputStream) {
        int iGn = this.f27Zo.gn();
        if (iGn > 0) {
            this.f30u7 = new VK(String.valueOf(Thread.currentThread().getName()) + "-Timer");
            this.f24VH = new _K(inputStream, this.f30u7);
            this.f28gn = new aL(outputStream, this.f30u7);
            int i = iGn * 1000;
            this.f24VH.j6(i);
            this.f28gn.j6(i);
            inputStream = this.f24VH;
            outputStream = this.f28gn;
        }
        this.f29tp = inputStream;
        this.f19EQ = outputStream;
        this.f32we = new DI(this.f29tp);
        this.f21J0 = new EI(this.f19EQ);
        this.f22J8 = true;
    }

    protected boolean m52j6(StringBuilder sb, String str) {
        if (!m49DW(str)) {
            return false;
        }
        sb.append(' ');
        sb.append(str);
        return true;
    }

    protected yD m53tp() {
        return new hD(this.f31v5, JGitText.j6().notFound);
    }

    protected void m54u7() {
        if (!this.f22J8 || this.f19EQ == null) {
            return;
        }
        try {
            this.f22J8 = false;
            this.f21J0.j6();
        } catch (IOException unused) {
            try {
                this.f19EQ.close();
            } catch (IOException unused2) {
            } finally {
                this.f19EQ = null;
                this.f21J0 = null;
            }
        }
    }
}
