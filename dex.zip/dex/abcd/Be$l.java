package abcd;

@xu
public class Be$l extends Be$b {

    @uu
    private static boolean f485VH;

    @tu
    private static boolean f486Zo;

    static {
        wu.j6(Be$l.class, -2778988359321004501L, -2778988359321004501L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$l(int i) {
        super(i);
        try {
            if (f486Zo) {
                wu.j6(-2874288245464115491L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f485VH) {
                wu.j6(th, -2874288245464115491L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }
}
