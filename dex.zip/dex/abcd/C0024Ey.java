package abcd;

public final class C0024Ey implements InterfaceC0067Fy {

    private static int[] f156j6 = new int[256];

    private int f157DW = 0;

    static {
        for (int i = 0; i < 256; i++) {
            int i2 = 8;
            int i3 = i;
            while (true) {
                i2--;
                if (i2 < 0) {
                    break;
                } else {
                    i3 = (i3 & 1) != 0 ? (i3 >>> 1) ^ (-306674912) : i3 >>> 1;
                }
            }
            f156j6[i] = i3;
        }
    }

    @Override
    public long getValue() {
        return ((long) this.f157DW) & 4294967295L;
    }

    @Override
    public void mo274j6(long j) {
        this.f157DW = (int) (j & 4294967295L);
    }

    @Override
    public void reset() {
        this.f157DW = 0;
    }

    @Override
    public void update(byte[] bArr, int i, int i2) {
        int i3 = this.f157DW ^ (-1);
        while (true) {
            i2--;
            if (i2 < 0) {
                this.f157DW = i3 ^ (-1);
                return;
            }
            i3 = (i3 >>> 8) ^ f156j6[(bArr[i] ^ i3) & 255];
            i++;
        }
    }
}
