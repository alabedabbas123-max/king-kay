package abcd;

public abstract class AbstractC0004up extends AbstractC0047vp {

    private int f14j6 = -1;

    public final boolean m32J8() {
        return this.f14j6 >= 0;
    }

    public final String m33Ws() {
        return '[' + Integer.toHexString(this.f14j6) + ']';
    }

    public final void m34j6(int i) {
        if (this.f14j6 != -1) {
            throw new RuntimeException("index already set");
        }
        this.f14j6 = i;
    }

    public final int m35we() {
        int i = this.f14j6;
        if (i >= 0) {
            return i;
        }
        throw new RuntimeException("index not yet set");
    }
}
