package abcd;

import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Binder;
import android.os.Process;
import android.os.RemoteException;
import com.aide.licensing.IAideLicensingService;
import com.aide.licensing.f;
import com.aide.licensing.g;
import com.aide.ui.U;

@xu
public abstract class AbstractC0039Oi {

    @uu
    private static boolean f192DW;

    @tu
    private static boolean f193j6;

    @ru(field = 6274737380717667505L)
    private IAideLicensingService f194FH;

    @ru(field = 278290876105144799L)
    private ServiceConnection f195Hw;

    @ru(field = 861711742328130144L)
    private String f196VH;

    @ru(field = -5317556928652143645L)
    private a f197Zo;

    @ru(field = -1195671941431952425L)
    private String f198gn;

    @ru(field = -404762652007184016L)
    private String f199tp;

    @ru(field = 742411422137571605L)
    private int f200u7;

    @ru(field = 800758648115464284L)
    private boolean f201v5;

    @xu
    private class a extends g.a {

        @tu
        private static boolean f202FH;

        @uu
        private static boolean f203Hw;

        @vu
        final AbstractC0039Oi f204v5;

        static {
            wu.j6(a.class, 31530143936738400L, 31530143936738400L);
        }

        @su(method = 76885377396235581L)
        private a(AbstractC0039Oi abstractC0039Oi) {
            try {
                if (f202FH) {
                    wu.j6(-2260724432237922420L, (Object) null, abstractC0039Oi);
                }
                this.f204v5 = abstractC0039Oi;
            } catch (Throwable th) {
                if (f203Hw) {
                    wu.j6(th, -2260724432237922420L, (Object) null, abstractC0039Oi);
                }
                throw th;
            }
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        a(AbstractC0039Oi abstractC0039Oi, Ki ki) {
            this(abstractC0039Oi);
            try {
                if (f202FH) {
                    wu.j6(3045516327804306288L, (Object) null, abstractC0039Oi, ki);
                }
            } catch (Throwable th) {
                if (f203Hw) {
                    wu.j6(th, 3045516327804306288L, (Object) null, abstractC0039Oi, ki);
                }
                throw th;
            }
        }

        @su(method = -79683348119109457L)
        public void m281DW(String str, String str2) {
            try {
                if (f202FH) {
                    wu.j6(-2708104841865264099L, this, str, str2);
                }
                this.f204v5.m263DW("licenseVerified: " + str);
                if (Binder.getCallingUid() == Process.myUid()) {
                    U.j6(new Ni(this, str, str2));
                    return;
                }
                this.f204v5.m264FH("UID mismatch - my uid: " + Process.myUid() + " calling uid: " + Binder.getCallingUid());
            } catch (Throwable th) {
                if (f203Hw) {
                    wu.j6(th, -2708104841865264099L, this, str, str2);
                }
                throw th;
            }
        }

        @su(method = -2243428915497216240L)
        public void m282XX() {
            try {
                if (f202FH) {
                    wu.j6(-4562683260330864240L, this);
                }
                this.f204v5.m263DW("licenseNotVerified");
                if (Binder.getCallingUid() == Process.myUid()) {
                    U.j6(new Mi(this));
                    return;
                }
                this.f204v5.m264FH("UID mismatch - my uid: " + Process.myUid() + " calling uid: " + Binder.getCallingUid());
            } catch (Throwable th) {
                if (f203Hw) {
                    wu.j6(th, -4562683260330864240L, this);
                }
                throw th;
            }
        }
    }

    static {
        wu.j6(AbstractC0039Oi.class, -6228992669085397497L, -6228992669085397497L);
    }

    public AbstractC0039Oi(String str, String str2, int i, String str3) {
        try {
            if (f193j6) {
                wu.j6(-3038348709593117004L, (Object) null, str, str2, new Integer(i), str3);
            }
            this.f197Zo = new a(this, null);
            this.f196VH = str;
            this.f198gn = str2;
            this.f200u7 = i;
            this.f199tp = str3;
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, -3038348709593117004L, (Object) null, str, str2, new Integer(i), str3);
            }
            throw th;
        }
    }

    @su(method = -1370846427655774193L)
    public void m263DW(String str) {
        try {
            if (f193j6) {
                wu.j6(-5382733115908416264L, this, str);
            }
            ue.j6("(" + this.f196VH + ") " + str);
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, -5382733115908416264L, this, str);
            }
            throw th;
        }
    }

    @su(method = 6340873389908543052L)
    public void m264FH(String str) {
        try {
            if (f193j6) {
                wu.j6(2168766339546846501L, this, str);
            }
            ue.DW("(" + this.f196VH + ") " + str);
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, 2168766339546846501L, this, str);
            }
            throw th;
        }
    }

    @su(method = 4602333303917591165L)
    public void m265VH() {
        try {
            if (f193j6) {
                wu.j6(7356759073356652992L, this);
            }
            try {
                m263DW("Requesting license check");
                this.f194FH.j6(this.f197Zo);
            } catch (RemoteException e) {
                m271j6(e);
            }
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, 7356759073356652992L, this);
            }
            throw th;
        }
    }

    @su(method = -2420763878479367811L)
    private void m266Zo() {
        try {
            if (f193j6) {
                wu.j6(7596241288596834744L, this);
            }
            if (this.f194FH != null) {
                m265VH();
                return;
            }
            if (this.f201v5) {
                m263DW("Licensing service bind already pending");
                return;
            }
            this.f195Hw = new Ki(this);
            m263DW("Binding to " + IAideLicensingService.class.getName());
            boolean zBindService = false;
            try {
                Intent intent = new Intent(this.f199tp);
                intent.setPackage(this.f196VH);
                zBindService = U.Zo().bindService(intent, this.f195Hw, 1);
            } catch (Exception unused) {
            }
            if (zBindService) {
                this.f201v5 = zBindService;
            } else {
                m263DW("Licensing service could not be bound");
            }
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, 7596241288596834744L, this);
            }
            throw th;
        }
    }

    @su(method = -2846317221657453600L)
    private void m271j6(Exception exc) {
        try {
            if (f193j6) {
                wu.j6(-6818064566062512009L, this, exc);
            }
            ue.j6("(" + this.f196VH + ")", exc);
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, -6818064566062512009L, this, exc);
            }
            throw th;
        }
    }

    @su(method = -5998873921622435375L)
    public void m272j6(String str, String str2) {
        try {
            if (f193j6) {
                wu.j6(-5057723731334384124L, this, str, str2);
            }
            f.a aVarJ6 = f.j6(U.Zo(), -1L, -1, -1, this.f196VH, str, str2, this.f198gn);
            int i = Li.j6[aVarJ6.ordinal()];
            if (i == 1 || i == 2) {
                mo278j6(f.j6(str, str2, this.f198gn).EQ);
                return;
            }
            if (i == 3) {
                mo279j6("OVER_GRACE_PERIOD");
                return;
            }
            if (i == 4) {
                mo279j6("NOT_LICENSED");
            } else {
                if (i == 5) {
                    mo279j6("TEMPORARY_ERROR");
                    return;
                }
                throw new RuntimeException("Unknown LicenseVerificationResult " + aVarJ6);
            }
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, -5057723731334384124L, this, str, str2);
            }
            throw th;
        }
    }

    public void m274DW() {
        try {
            if (f193j6) {
                wu.j6(1939618777909265128L, this);
            }
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, 1939618777909265128L, this);
            }
            throw th;
        }
    }

    public boolean m275FH() {
        try {
            if (f193j6) {
                wu.j6(6360085930485499135L, this);
            }
            return U.Zo().getPackageManager().checkSignatures(this.f196VH, "com.aide.ui") == 0;
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, 6360085930485499135L, this);
            }
            throw th;
        }
    }

    protected abstract void mo276Hw();

    public void m277j6() {
        try {
            if (f193j6) {
                wu.j6(-170208189781830628L, this);
            }
            if (U.j6.equals("com.aide.phonegap")) {
                return;
            }
            PackageManager packageManager = U.Zo().getPackageManager();
            boolean zM275FH = m275FH();
            boolean z = false;
            if (zM275FH) {
                try {
                    if (packageManager.getPackageInfo(this.f196VH, 0).versionCode >= this.f200u7) {
                        z = true;
                    }
                } catch (PackageManager.NameNotFoundException unused) {
                }
            }
            if (zM275FH && z) {
                m266Zo();
            } else {
                if (!zM275FH || z) {
                    return;
                }
                mo276Hw();
            }
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, -170208189781830628L, this);
            }
            throw th;
        }
    }

    protected abstract void mo278j6(long j);

    protected abstract void mo279j6(String str);

    public void m280v5() {
        try {
            if (f193j6) {
                wu.j6(-2677966163372558652L, this);
            }
            if (this.f194FH != null) {
                m263DW("Unbinding license service");
                U.Zo().unbindService(this.f195Hw);
                this.f195Hw = null;
                this.f201v5 = false;
            }
        } catch (Throwable th) {
            if (f192DW) {
                wu.j6(th, -2677966163372558652L, this);
            }
            throw th;
        }
    }
}
