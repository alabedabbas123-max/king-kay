package abcd;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

public abstract class AbstractC0073AL extends EL implements InterfaceC0116BL {

    byte[] f245j6;

    public AbstractC0073AL(byte[] bArr) {
        if (bArr == null) {
            throw new NullPointerException("string cannot be null");
        }
        this.f245j6 = bArr;
    }

    public static AbstractC0073AL m810j6(Object obj) {
        if (obj == null || (obj instanceof AbstractC0073AL)) {
            return (AbstractC0073AL) obj;
        }
        if (obj instanceof byte[]) {
            try {
                return m810j6((Object) EL.j6((byte[]) obj));
            } catch (IOException e) {
                throw new IllegalArgumentException("failed to construct OCTET STRING from byte[]: " + e.getMessage());
            }
        }
        if (obj instanceof qL) {
            EL elDW = ((qL) obj).DW();
            if (elDW instanceof AbstractC0073AL) {
                return (AbstractC0073AL) elDW;
            }
        }
        throw new IllegalArgumentException("illegal object in getInstance: " + obj.getClass().getName());
    }

    @Override
    public InputStream mo811FH() {
        return new ByteArrayInputStream(this.f245j6);
    }

    EL m812VH() {
        return new pM(this.f245j6);
    }

    EL m813gn() {
        return new pM(this.f245j6);
    }

    public int hashCode() {
        return OP.DW(m816u7());
    }

    public EL m814j6() {
        DW();
        return this;
    }

    boolean m815j6(EL el) {
        if (el instanceof AbstractC0073AL) {
            return OP.j6(this.f245j6, ((AbstractC0073AL) el).f245j6);
        }
        return false;
    }

    public String toString() {
        return "#" + new String(VP.j6(this.f245j6));
    }

    public byte[] m816u7() {
        return this.f245j6;
    }
}
