package abcd;

import com.aide.common.ab;
import com.aide.engine.EngineSolution;
import com.aide.ui.U;
import com.aide.ui.htmluidesigner.PhonegapDesignActivity;
import com.aide.ui.trainer.g;
import com.aide.uidesigner.XmlLayoutDesignActivity;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

@xu
public class C0005rj implements Ui {

    @uu
    private static boolean f20DW;

    @InterfaceC0101tu
    private static boolean f21j6;

    static {
        wu.j6(C0005rj.class, 6278583807911632520L, 6278583807911632520L);
    }

    public C0005rj() {
        try {
            if (f21j6) {
                wu.j6(137902972726981100L, (Object) null);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 137902972726981100L, (Object) null);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 5746424337665410175L)
    private static boolean m89Mr(String str) {
        try {
            if (f21j6) {
                wu.j6(5209632990406912896L, (Object) null, str);
            }
            if (Vl.Hw(str + "/www")) {
                if (Vl.Hw(str + "/.cordova")) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 5209632990406912896L, (Object) null, str);
            }
            throw th;
        }
    }

    public boolean m90DW() {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(2676228434037406056L, this);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 2676228434037406056L, this);
            }
            throw th;
        }
    }

    public boolean m91DW(String str) {
        try {
            if (f21j6) {
                wu.j6(5465574077662338165L, this, str);
            }
            if ((U.ef() || U.j6.equals("com.aide.phonegap")) && str.toLowerCase().endsWith(".html")) {
                return Vl.DW(str, "www") != null;
            }
            return (U.ef() || U.j6.equals("com.aide.ui")) && str.toLowerCase().endsWith(".xml") && Vl.tp(Vl.EQ(str)).startsWith("layout") && Vl.DW(str, "res") != null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 5465574077662338165L, this, str);
            }
            throw th;
        }
    }

    public String m92EQ() {
        try {
            if (!f21j6) {
                return null;
            }
            wu.j6(-603249438593227141L, this);
            return null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -603249438593227141L, this);
            }
            throw th;
        }
    }

    public boolean m93EQ(String str) {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(3629048862892493320L, this, str);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 3629048862892493320L, this, str);
            }
            throw th;
        }
    }

    public String m94FH(String str) {
        try {
            if (f21j6) {
                wu.j6(-2082901003700079883L, this, str);
            }
            if (m99J8(str)) {
                return null;
            }
            return "com.aide.phonegap";
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -2082901003700079883L, this, str);
            }
            throw th;
        }
    }

    public List<g.b> m95FH() {
        try {
            if (!f21j6) {
                return null;
            }
            wu.j6(2505224707110381525L, this);
            return null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 2505224707110381525L, this);
            }
            throw th;
        }
    }

    public void m96Hw() {
        try {
            if (f21j6) {
                wu.j6(-1913695732293162400L, this);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -1913695732293162400L, this);
            }
            throw th;
        }
    }

    public void m97Hw(String str) {
        try {
            if (f21j6) {
                wu.j6(-7164807204466483360L, this, str);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -7164807204466483360L, this, str);
            }
            throw th;
        }
    }

    public int m98J0(String str) {
        try {
            if (!f21j6) {
                return 0;
            }
            wu.j6(-450712604494893352L, this, str);
            return 0;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -450712604494893352L, this, str);
            }
            throw th;
        }
    }

    public boolean m99J8(String str) {
        try {
            if (f21j6) {
                wu.j6(-1087136101276985441L, this, str);
            }
            return U.ef() || U.j6.equals("com.aide.phonegap");
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -1087136101276985441L, this, str);
            }
            throw th;
        }
    }

    public boolean m100QX(String str) {
        try {
            if (f21j6) {
                wu.j6(-4125156091452051591L, this, str);
            }
            return m89Mr(str);
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -4125156091452051591L, this, str);
            }
            throw th;
        }
    }

    public EngineSolution m101VH() {
        try {
            if (f21j6) {
                wu.j6(-2650949043609565179L, this);
            }
            return qj.j6(U.vy().J0(), U.DW().Hw());
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -2650949043609565179L, this);
            }
            throw th;
        }
    }

    public void m102VH(String str) {
        try {
            if (f21j6) {
                wu.j6(-659511791645162624L, this, str);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -659511791645162624L, this, str);
            }
            throw th;
        }
    }

    public int m103Ws(String str) {
        try {
            if (!f21j6) {
                return -1;
            }
            wu.j6(2219087622165063915L, this, str);
            return -1;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 2219087622165063915L, this, str);
            }
            throw th;
        }
    }

    public List<String> m104XL(String str) {
        try {
            if (!f21j6) {
                return null;
            }
            wu.j6(936309991619585892L, this, str);
            return null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 936309991619585892L, this, str);
            }
            throw th;
        }
    }

    public boolean m105Zo() {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(488608058230507347L, this);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 488608058230507347L, this);
            }
            throw th;
        }
    }

    public boolean m106Zo(String str) {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(1339498028451651824L, this, str);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 1339498028451651824L, this, str);
            }
            throw th;
        }
    }

    public boolean m107aM(String str) {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(-1525037520331382369L, this, str);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -1525037520331382369L, this, str);
            }
            throw th;
        }
    }

    public Sk.a[] getTemplates() {
        try {
            if (!f21j6) {
                return null;
            }
            wu.j6(2615765033205145600L, this);
            return null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 2615765033205145600L, this);
            }
            throw th;
        }
    }

    public int m108gn(String str) {
        try {
            if (!f21j6) {
                return com.aide.pro.R.string.command_files_open_phonegap_project;
            }
            wu.j6(1618826157516539859L, this, str);
            return com.aide.pro.R.string.command_files_open_phonegap_project;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 1618826157516539859L, this, str);
            }
            throw th;
        }
    }

    public String m109gn() {
        try {
            if (f21j6) {
                wu.j6(-288030851533373039L, this);
            }
            return "<b>Phonegap 3 Project Home:</b><br/><br/>" + U.vy().J0();
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -288030851533373039L, this);
            }
            throw th;
        }
    }

    public void m110j3(String str) {
        try {
            if (f21j6) {
                wu.j6(576661785080655855L, this, str);
            }
            if ((U.ef() || U.j6.equals("com.aide.phonegap")) && str.toLowerCase().endsWith(".html")) {
                PhonegapDesignActivity.j6(U.lg(), Vl.DW(str, "www"), str);
            } else if ((U.ef() || U.j6.equals("com.aide.ui")) && str.toLowerCase().endsWith(".xml")) {
                XmlLayoutDesignActivity.j6(U.lg(), U.Mr(), str, !U.U2().EQ(), false);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 576661785080655855L, this, str);
            }
            throw th;
        }
    }

    public String m111j6(String str) {
        try {
            if (!f21j6) {
                return null;
            }
            wu.j6(1227659381303459181L, this, str);
            return null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 1227659381303459181L, this, str);
            }
            throw th;
        }
    }

    public void m112j6() {
        try {
            if (f21j6) {
                wu.j6(497096024930466327L, this);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 497096024930466327L, this);
            }
            throw th;
        }
    }

    public void m113j6(String str, ab<String> abVar) {
        try {
            if (f21j6) {
                wu.j6(635289971738385120L, this, str, abVar);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 635289971738385120L, this, str, abVar);
            }
            throw th;
        }
    }

    public void m114j6(String str, String str2) {
        try {
            if (f21j6) {
                wu.j6(2066109773119899200L, this, str, str2);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 2066109773119899200L, this, str, str2);
            }
            throw th;
        }
    }

    public void m115j6(String str, Map<String, List<String>> map, List<String> list) {
        try {
            if (f21j6) {
                wu.j6(3791414898153510336L, this, str, map, list);
            }
            map.put(str, new ArrayList());
            list.add(str);
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 3791414898153510336L, this, str, map, list);
            }
            throw th;
        }
    }

    public void m116j6(List<String> list, boolean z) {
        try {
            if (f21j6) {
                wu.j6(5759658763136226813L, this, list, new Boolean(z));
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 5759658763136226813L, this, list, new Boolean(z));
            }
            throw th;
        }
    }

    public void m117j6(boolean z) {
        try {
            if (f21j6) {
                wu.j6(-1953553705877620345L, this, z);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -1953553705877620345L, this, new Boolean(z));
            }
            throw th;
        }
    }

    public String m118tp(String str) {
        try {
            if (!f21j6) {
                return null;
            }
            wu.j6(396130903327706157L, this, str);
            return null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 396130903327706157L, this, str);
            }
            throw th;
        }
    }

    public boolean m119tp() {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(2460258591798150096L, this);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 2460258591798150096L, this);
            }
            throw th;
        }
    }

    public List<String> m120u7(String str) {
        try {
            if (!f21j6) {
                return null;
            }
            wu.j6(1108994348180996688L, this, str);
            return null;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 1108994348180996688L, this, str);
            }
            throw th;
        }
    }

    public void m121u7() {
        try {
            if (f21j6) {
                wu.j6(479283654876108021L, this);
            }
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 479283654876108021L, this);
            }
            throw th;
        }
    }

    public boolean m122v5() {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(-5831643404155416048L, this);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -5831643404155416048L, this);
            }
            throw th;
        }
    }

    public boolean m123v5(String str) {
        try {
            if (f21j6) {
                wu.j6(1274153650165219980L, this, str);
            }
            Iterator it = U.vy().J8().keySet().iterator();
            while (it.hasNext()) {
                if (Vl.Hw((String) it.next(), str)) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, 1274153650165219980L, this, str);
            }
            throw th;
        }
    }

    public boolean m124we() {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(-328581186207334704L, this);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -328581186207334704L, this);
            }
            throw th;
        }
    }

    public boolean m125we(String str) {
        try {
            if (!f21j6) {
                return false;
            }
            wu.j6(-6815324642545824489L, this, str);
            return false;
        } catch (Throwable th) {
            if (f20DW) {
                wu.j6(th, -6815324642545824489L, this, str);
            }
            throw th;
        }
    }
}
