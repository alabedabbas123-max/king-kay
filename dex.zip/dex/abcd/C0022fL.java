package abcd;

import java.util.HashMap;
import java.util.Map;

public class C0022fL extends HashMap implements Map, eL, InterfaceC0066gL {
    private static String m75j6(String str, Object obj, StringBuffer stringBuffer) {
        stringBuffer.append('\"');
        if (str == null) {
            stringBuffer.append("null");
        } else {
            C0110hL.m555j6(str, stringBuffer);
        }
        stringBuffer.append('\"');
        stringBuffer.append(':');
        stringBuffer.append(C0110hL.m553j6(obj));
        return stringBuffer.toString();
    }

    public static String m76j6(Map map) {
        if (map == null) {
            return "null";
        }
        StringBuffer stringBuffer = new StringBuffer();
        boolean z = true;
        stringBuffer.append('{');
        for (Map.Entry entry : map.entrySet()) {
            if (z) {
                z = false;
            } else {
                stringBuffer.append(',');
            }
            m75j6(String.valueOf(entry.getKey()), entry.getValue(), stringBuffer);
        }
        stringBuffer.append('}');
        return stringBuffer.toString();
    }

    public String m77j6() {
        return m76j6(this);
    }

    @Override
    public String toString() {
        return m77j6();
    }
}
