package abcd;

import android.app.Activity;
import android.view.MenuItem;
import com.appfour.backbone.api.closures.OnMenuItemSelectedClosure;
import com.appfour.backbone.api.objects.EventData;

class C0000xv implements jv {

    final Bv f0DW;

    final OnMenuItemSelectedClosure f1j6;

    C0000xv(Bv bv, OnMenuItemSelectedClosure onMenuItemSelectedClosure) {
        this.f0DW = bv;
        this.f1j6 = onMenuItemSelectedClosure;
    }

    public EventData m0j6(Object[] objArr) {
        return this.f1j6.getValue((Activity) objArr[0], (MenuItem) objArr[1]);
    }
}
