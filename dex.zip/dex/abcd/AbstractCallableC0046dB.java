package abcd;

import java.text.MessageFormat;
import java.util.concurrent.Callable;
import org.eclipse.jgit.JGitText;

public abstract class AbstractCallableC0046dB<T> implements Callable<T> {

    private boolean f182DW = true;

    protected final UE f183j6;

    protected AbstractCallableC0046dB(UE ue) {
        this.f183j6 = ue;
    }

    public UE m264DW() {
        return this.f183j6;
    }

    protected void m265j6() {
        if (!this.f182DW) {
            throw new IllegalStateException(MessageFormat.format(JGitText.j6().commandWasCalledInTheWrongState, getClass().getName()));
        }
    }

    protected void m266j6(boolean z) {
        this.f182DW = z;
    }
}
