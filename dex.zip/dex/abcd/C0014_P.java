package abcd;

import java.security.InvalidKeyException;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.SignatureException;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

class C0014_P {

    private static Hashtable f100j6 = new Hashtable();

    private static Hashtable f98DW = new Hashtable();

    private static Set f99FH = new HashSet();

    static {
        f100j6.put("MD2WITHRSAENCRYPTION", lN.FH);
        f100j6.put("MD2WITHRSA", lN.FH);
        f100j6.put("MD5WITHRSAENCRYPTION", lN.v5);
        f100j6.put("MD5WITHRSA", lN.v5);
        f100j6.put("SHA1WITHRSAENCRYPTION", lN.Zo);
        f100j6.put("SHA1WITHRSA", lN.Zo);
        f100j6.put("SHA224WITHRSAENCRYPTION", lN.Ws);
        f100j6.put("SHA224WITHRSA", lN.Ws);
        f100j6.put("SHA256WITHRSAENCRYPTION", lN.we);
        f100j6.put("SHA256WITHRSA", lN.we);
        f100j6.put("SHA384WITHRSAENCRYPTION", lN.J0);
        f100j6.put("SHA384WITHRSA", lN.J0);
        f100j6.put("SHA512WITHRSAENCRYPTION", lN.J8);
        f100j6.put("SHA512WITHRSA", lN.J8);
        f100j6.put("SHA1WITHRSAANDMGF1", lN.EQ);
        f100j6.put("SHA224WITHRSAANDMGF1", lN.EQ);
        f100j6.put("SHA256WITHRSAANDMGF1", lN.EQ);
        f100j6.put("SHA384WITHRSAANDMGF1", lN.EQ);
        f100j6.put("SHA512WITHRSAANDMGF1", lN.EQ);
        f100j6.put("RIPEMD160WITHRSAENCRYPTION", oN.Zo);
        f100j6.put("RIPEMD160WITHRSA", oN.Zo);
        f100j6.put("RIPEMD128WITHRSAENCRYPTION", oN.VH);
        f100j6.put("RIPEMD128WITHRSA", oN.VH);
        f100j6.put("RIPEMD256WITHRSAENCRYPTION", oN.gn);
        f100j6.put("RIPEMD256WITHRSA", oN.gn);
        f100j6.put("SHA1WITHDSA", QN.x9);
        f100j6.put("DSAWITHSHA1", QN.x9);
        f100j6.put("SHA224WITHDSA", hN.vy);
        f100j6.put("SHA256WITHDSA", hN.P8);
        f100j6.put("SHA384WITHDSA", hN.ei);
        f100j6.put("SHA512WITHDSA", hN.nw);
        f100j6.put("SHA1WITHECDSA", QN.u7);
        f100j6.put("ECDSAWITHSHA1", QN.u7);
        f100j6.put("SHA224WITHECDSA", QN.J0);
        f100j6.put("SHA256WITHECDSA", QN.J8);
        f100j6.put("SHA384WITHECDSA", QN.Ws);
        f100j6.put("SHA512WITHECDSA", QN.QX);
        f100j6.put("GOST3411WITHGOST3410", InterfaceC0011_M.f96v5);
        f100j6.put("GOST3411WITHGOST3410-94", InterfaceC0011_M.f96v5);
        f100j6.put("GOST3411WITHECGOST3410", InterfaceC0011_M.f89Zo);
        f100j6.put("GOST3411WITHECGOST3410-2001", InterfaceC0011_M.f89Zo);
        f100j6.put("GOST3411WITHGOST3410-2001", InterfaceC0011_M.f89Zo);
        f99FH.add(QN.u7);
        f99FH.add(QN.J0);
        f99FH.add(QN.J8);
        f99FH.add(QN.Ws);
        f99FH.add(QN.QX);
        f99FH.add(QN.x9);
        f99FH.add(hN.vy);
        f99FH.add(hN.P8);
        f99FH.add(hN.ei);
        f99FH.add(hN.nw);
        f99FH.add(InterfaceC0011_M.f96v5);
        f99FH.add(InterfaceC0011_M.f89Zo);
        f98DW.put("SHA1WITHRSAANDMGF1", m111j6(new wN(jN.u7, new mM()), 20));
        f98DW.put("SHA224WITHRSAANDMGF1", m111j6(new wN(hN.v5, new mM()), 28));
        f98DW.put("SHA256WITHRSAANDMGF1", m111j6(new wN(hN.DW, new mM()), 32));
        f98DW.put("SHA384WITHRSAANDMGF1", m111j6(new wN(hN.FH, new mM()), 48));
        f98DW.put("SHA512WITHRSAANDMGF1", m111j6(new wN(hN.Hw, new mM()), 64));
    }

    private static nN m111j6(wN wNVar, int i) {
        return new nN(wNVar, new wN(lN.u7, wNVar), new wL(i), new wL(1));
    }

    static oM m112j6(String str) {
        String strFH = TP.FH(str);
        return f100j6.containsKey(strFH) ? (oM) f100j6.get(strFH) : new oM(strFH);
    }

    static wN m113j6(oM oMVar, String str) {
        if (f99FH.contains(oMVar)) {
            return new wN(oMVar);
        }
        String strFH = TP.FH(str);
        return f98DW.containsKey(strFH) ? new wN(oMVar, (qL) f98DW.get(strFH)) : new wN(oMVar, new mM());
    }

    static Signature m114j6(String str, String str2) {
        return str2 != null ? Signature.getInstance(str, str2) : Signature.getInstance(str);
    }

    static byte[] m115j6(oM oMVar, String str, String str2, PrivateKey privateKey, SecureRandom secureRandom, qL qLVar) throws SignatureException, InvalidKeyException {
        if (oMVar == null) {
            throw new IllegalStateException("no signature algorithm specified");
        }
        Signature signatureM114j6 = m114j6(str, str2);
        if (secureRandom != null) {
            signatureM114j6.initSign(privateKey, secureRandom);
        } else {
            signatureM114j6.initSign(privateKey);
        }
        signatureM114j6.update(qLVar.DW().j6("DER"));
        return signatureM114j6.sign();
    }
}
