package abcd;

import android.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;

@xu
class C0022_h implements TextWatcher {

    @uu
    private static boolean f152DW;

    @tu
    private static boolean f153j6;

    final AlertDialog f154FH;

    @vu
    final di f155Hw;

    static {
        wu.j6(C0022_h.class, 294461532386472240L, -2596429009759115700L);
    }

    C0022_h(di diVar, AlertDialog alertDialog) {
        this.f155Hw = diVar;
        this.f154FH = alertDialog;
    }

    @Override
    @su(method = -5045051986624764133L)
    public void afterTextChanged(Editable editable) {
        try {
            if (f153j6) {
                wu.j6(-6407635121654582912L, this, editable);
            }
            this.f155Hw.j6(this.f154FH);
        } catch (Throwable th) {
            if (f152DW) {
                wu.j6(th, -6407635121654582912L, this, editable);
            }
            throw th;
        }
    }

    @Override
    @su(method = 3071736262787866848L)
    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        try {
            if (f153j6) {
                wu.j6(37951182274725951L, this, charSequence, new Integer(i), new Integer(i2), new Integer(i3));
            }
        } catch (Throwable th) {
            if (f152DW) {
                wu.j6(th, 37951182274725951L, this, charSequence, new Integer(i), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }

    @Override
    @su(method = 7310497506064733224L)
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        try {
            if (f153j6) {
                wu.j6(-1759088855460985435L, this, charSequence, new Integer(i), new Integer(i2), new Integer(i3));
            }
        } catch (Throwable th) {
            if (f152DW) {
                wu.j6(th, -1759088855460985435L, this, charSequence, new Integer(i), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }
}
