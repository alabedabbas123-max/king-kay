package abcd;

public abstract class AbstractC0057Cs extends AbstractC0100Ds {

    private final long f216j6;

    AbstractC0057Cs(long j) {
        this.f216j6 = j;
    }

    protected int m371DW(ms msVar) {
        long j = ((AbstractC0057Cs) msVar).f216j6;
        long j2 = this.f216j6;
        if (j2 < j) {
            return -1;
        }
        return j2 > j ? 1 : 0;
    }

    public final boolean m372Hw() {
        return true;
    }

    @Override
    public final boolean mo65J8() {
        long j = this.f216j6;
        return ((long) ((int) j)) == j;
    }

    @Override
    public final int mo66Ws() {
        return (int) this.f216j6;
    }

    public final boolean equals(Object obj) {
        return obj != null && getClass() == obj.getClass() && this.f216j6 == ((AbstractC0057Cs) obj).f216j6;
    }

    public final int hashCode() {
        long j = this.f216j6;
        return ((int) j) ^ ((int) (j >> 32));
    }

    @Override
    public final long mo67lg() {
        return this.f216j6;
    }
}
