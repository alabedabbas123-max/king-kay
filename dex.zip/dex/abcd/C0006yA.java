package abcd;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Method;

public class C0006yA {

    static Object f10DW;

    static Method f11FH;

    static tA f12Hw = uA.j6(C0006yA.class.getName());

    static Method f13j6;

    static {
        try {
            Class<?> cls = Class.forName("android.util.Base64");
            f13j6 = cls.getMethod("encode", byte[].class, Integer.TYPE);
            f12Hw.Hw(cls.getName() + " is available.");
        } catch (ClassNotFoundException unused) {
        } catch (Exception e) {
            f12Hw.j6("Failed to initialize use of android.util.Base64", e);
        }
        try {
            Class<?> cls2 = Class.forName("org.bouncycastle.util.encoders.Base64Encoder");
            f10DW = cls2.newInstance();
            f11FH = cls2.getMethod("encode", byte[].class, Integer.TYPE, Integer.TYPE, OutputStream.class);
            f12Hw.Hw(cls2.getName() + " is available.");
        } catch (ClassNotFoundException unused2) {
        } catch (Exception e2) {
            f12Hw.j6("Failed to initialize use of org.bouncycastle.util.encoders.Base64Encoder", e2);
        }
        if (f13j6 == null && f11FH == null) {
            throw new IllegalStateException("No base64 encoder implementation is available.");
        }
    }

    public static String m20j6(byte[] bArr) {
        try {
            if (f13j6 != null) {
                return new String((byte[]) f13j6.invoke(null, bArr, 2));
            }
            if (f11FH == null) {
                throw new IllegalStateException("No base64 encoder implementation is available.");
            }
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            f11FH.invoke(f10DW, bArr, 0, Integer.valueOf(bArr.length), byteArrayOutputStream);
            return new String(byteArrayOutputStream.toByteArray());
        } catch (Exception e) {
            throw new IllegalStateException(e.getClass().getName() + ": " + e.getMessage());
        }
    }
}
