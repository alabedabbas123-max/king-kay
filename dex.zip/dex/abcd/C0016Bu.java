package abcd;

import com.appfour.backbone.api.closures.OnCrashClosure;
import com.appfour.backbone.api.objects.EventData;

class C0016Bu implements jv {

    final Iu f64DW;

    final OnCrashClosure f65j6;

    C0016Bu(Iu iu, OnCrashClosure onCrashClosure) {
        this.f64DW = iu;
        this.f65j6 = onCrashClosure;
    }

    public EventData m96j6(Object[] objArr) {
        return this.f65j6.getValue((Thread) objArr[0], (Throwable) objArr[1]);
    }
}
