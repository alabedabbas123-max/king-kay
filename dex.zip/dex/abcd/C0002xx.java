package abcd;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public class C0002xx implements IInterface {

    private final String f3DW;

    private final IBinder f4j6;

    protected C0002xx(IBinder iBinder, String str) {
        this.f4j6 = iBinder;
        this.f3DW = str;
    }

    protected final void m3DW(int i, Parcel parcel) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            this.f4j6.transact(i, parcel, parcelObtain, 0);
            parcelObtain.readException();
        } finally {
            parcel.recycle();
            parcelObtain.recycle();
        }
    }

    @Override
    public IBinder asBinder() {
        return this.f4j6;
    }

    protected final Parcel m4j6(int i, Parcel parcel) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            try {
                this.f4j6.transact(i, parcel, parcelObtain, 0);
                parcelObtain.readException();
                parcel.recycle();
                return parcelObtain;
            } catch (RuntimeException e) {
                parcelObtain.recycle();
                throw e;
            }
        } catch (Throwable th) {
            parcel.recycle();
            throw th;
        }
    }

    protected final Parcel m5v5() {
        Parcel parcelObtain = Parcel.obtain();
        parcelObtain.writeInterfaceToken(this.f3DW);
        return parcelObtain;
    }
}
