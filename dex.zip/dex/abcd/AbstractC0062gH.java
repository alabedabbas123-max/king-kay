package abcd;

import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.DigestOutputStream;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.List;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0062gH {

    protected static final byte[] f255j6 = {-1, 116, 79, 99};

    protected final DigestOutputStream f256DW;

    protected final byte[] f257FH;

    protected List<? extends CI> f258Hw;

    protected byte[] f259v5;

    protected AbstractC0062gH(OutputStream outputStream) {
        this.f256DW = new DigestOutputStream(outputStream instanceof BufferedOutputStream ? outputStream : new XK(outputStream), C0103hE.m526j6());
        this.f257FH = new byte[24];
    }

    public static AbstractC0062gH m233j6(OutputStream outputStream, int i) {
        if (i == 1) {
            return new C0106hH(outputStream);
        }
        if (i == 2) {
            return new iH(outputStream);
        }
        throw new IllegalArgumentException(MessageFormat.format(JGitText.j6().unsupportedPackIndexVersion, Integer.valueOf(i)));
    }

    public static AbstractC0062gH m234j6(OutputStream outputStream, List<? extends CI> list) {
        int i;
        Iterator<? extends CI> it = list.iterator();
        while (it.hasNext()) {
            if (!C0106hH.m532j6(it.next())) {
                i = 2;
                return m233j6(outputStream, i);
            }
        }
        i = 1;
        return m233j6(outputStream, i);
    }

    protected void m235DW() throws IOException {
        int i;
        int[] iArr = new int[256];
        Iterator<? extends CI> it = this.f258Hw.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            int iZo = it.next().Zo() & 255;
            iArr[iZo] = iArr[iZo] + 1;
        }
        for (i = 1; i < 256; i++) {
            iArr[i] = iArr[i] + iArr[i - 1];
        }
        for (int i2 : iArr) {
            FK.DW(this.f257FH, 0, i2);
            this.f256DW.write(this.f257FH, 0, 4);
        }
    }

    protected abstract void mo236FH();

    protected void m237j6() {
        this.f256DW.write(this.f259v5);
        this.f256DW.on(false);
        DigestOutputStream digestOutputStream = this.f256DW;
        digestOutputStream.write(digestOutputStream.getMessageDigest().digest());
    }

    protected void m238j6(int i) throws IOException {
        this.f256DW.write(f255j6);
        FK.DW(this.f257FH, 0, i);
        this.f256DW.write(this.f257FH, 0, 4);
    }

    public void m239j6(List<? extends CI> list, byte[] bArr) {
        this.f258Hw = list;
        this.f259v5 = bArr;
        mo236FH();
        this.f256DW.flush();
    }
}
