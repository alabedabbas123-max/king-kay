package abcd;

import android.os.Handler;

public class C0001xw {

    private static Handler f2j6;

    public static void m1j6() {
        f2j6 = new Handler();
    }

    public static void m2j6(int i, int i2, String str) {
        f2j6.post(new ww(i, i2, str));
    }
}
