package abcd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public class C0014yI {

    private final File f27DW;

    private long f28FH;

    private Map<String, a> f29Hw = Collections.emptyMap();

    private final File f30j6;

    public static class a {

        String f31DW;

        int f32FH;

        File f33Hw;

        Boolean f34VH;

        String f35Zo;

        String f36gn;

        boolean f37j6;

        String f38v5;

        public File m56DW() {
            return this.f33Hw;
        }

        public int m57FH() {
            return this.f32FH;
        }

        public String m58Hw() {
            return this.f35Zo;
        }

        public boolean m59VH() {
            Boolean bool = this.f34VH;
            return bool != null && bool.booleanValue();
        }

        public String m60Zo() {
            return this.f38v5;
        }

        public String m61j6() {
            return this.f31DW;
        }

        void m62j6(a aVar) {
            if (this.f31DW == null) {
                this.f31DW = aVar.f31DW;
            }
            if (this.f32FH == 0) {
                this.f32FH = aVar.f32FH;
            }
            if (this.f33Hw == null) {
                this.f33Hw = aVar.f33Hw;
            }
            if (this.f38v5 == null) {
                this.f38v5 = aVar.f38v5;
            }
            if (this.f35Zo == null) {
                this.f35Zo = aVar.f35Zo;
            }
            if (this.f34VH == null) {
                this.f34VH = aVar.f34VH;
            }
            if (this.f36gn == null) {
                this.f36gn = aVar.f36gn;
            }
        }

        public String m63v5() {
            return this.f36gn;
        }
    }

    C0014yI(File file, File file2) {
        this.f30j6 = file;
        this.f27DW = file2;
    }

    private static String m45DW(String str) {
        return (str.startsWith("\"") && str.endsWith("\"")) ? str.substring(1, str.length() - 1) : str;
    }

    private synchronized Map<String, a> m46DW() {
        long jLastModified = this.f27DW.lastModified();
        if (jLastModified != this.f28FH) {
            try {
                FileInputStream fileInputStream = new FileInputStream(this.f27DW);
                try {
                    this.f29Hw = m52j6(fileInputStream);
                    fileInputStream.close();
                } catch (Throwable th) {
                    fileInputStream.close();
                    throw th;
                }
            } catch (FileNotFoundException unused) {
                this.f29Hw = Collections.emptyMap();
            } catch (IOException unused2) {
                this.f29Hw = Collections.emptyMap();
            }
            this.f28FH = jLastModified;
        }
        return this.f29Hw;
    }

    private static boolean m47FH(String str) {
        return str.indexOf(42) >= 0 || str.indexOf(63) >= 0;
    }

    private static String m48Hw(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            if (!Character.isSpaceChar(str.charAt(i))) {
                sb.append(str.charAt(i));
            }
        }
        return sb.toString();
    }

    private static Boolean m49Zo(String str) {
        return NK.j6("yes", str) ? Boolean.TRUE : Boolean.FALSE;
    }

    public static C0014yI m50j6(pK pKVar) {
        File fileZo = pKVar.Zo();
        if (fileZo == null) {
            fileZo = new File(".").getAbsoluteFile();
        }
        C0014yI c0014yI = new C0014yI(fileZo, new File(new File(fileZo, ".ssh"), "config"));
        c0014yI.m46DW();
        return c0014yI;
    }

    static String m51j6() {
        return (String) AccessController.doPrivileged((PrivilegedAction) new xI());
    }

    private Map<String, a> m52j6(InputStream inputStream) throws IOException {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        ArrayList<a> arrayList = new ArrayList(4);
        while (true) {
            String line = bufferedReader.readLine();
            if (line == null) {
                return linkedHashMap;
            }
            String strTrim = line.trim();
            if (strTrim.length() != 0 && !strTrim.startsWith("#")) {
                String[] strArrSplit = strTrim.split("[ \t]*[= \t]", 2);
                String strTrim2 = strArrSplit[0].trim();
                String strTrim3 = strArrSplit[1].trim();
                if (NK.j6("Host", strTrim2)) {
                    arrayList.clear();
                    for (String str : strTrim3.split("[ \t]")) {
                        String strM45DW = m45DW(str);
                        a aVar = (a) linkedHashMap.get(strM45DW);
                        if (aVar == null) {
                            aVar = new a();
                            linkedHashMap.put(strM45DW, aVar);
                        }
                        arrayList.add(aVar);
                    }
                } else if (!arrayList.isEmpty()) {
                    if (NK.j6("HostName", strTrim2)) {
                        for (a aVar2 : arrayList) {
                            if (aVar2.f31DW == null) {
                                aVar2.f31DW = m45DW(strTrim3);
                            }
                        }
                    } else if (NK.j6("User", strTrim2)) {
                        for (a aVar3 : arrayList) {
                            if (aVar3.f38v5 == null) {
                                aVar3.f38v5 = m45DW(strTrim3);
                            }
                        }
                    } else if (NK.j6("Port", strTrim2)) {
                        try {
                            int i = Integer.parseInt(m45DW(strTrim3));
                            for (a aVar4 : arrayList) {
                                if (aVar4.f32FH == 0) {
                                    aVar4.f32FH = i;
                                }
                            }
                        } catch (NumberFormatException unused) {
                        }
                    } else if (NK.j6("IdentityFile", strTrim2)) {
                        for (a aVar5 : arrayList) {
                            if (aVar5.f33Hw == null) {
                                aVar5.f33Hw = m54v5(m45DW(strTrim3));
                            }
                        }
                    } else if (NK.j6("PreferredAuthentications", strTrim2)) {
                        for (a aVar6 : arrayList) {
                            if (aVar6.f35Zo == null) {
                                aVar6.f35Zo = m48Hw(m45DW(strTrim3));
                            }
                        }
                    } else if (NK.j6("BatchMode", strTrim2)) {
                        for (a aVar7 : arrayList) {
                            if (aVar7.f34VH == null) {
                                aVar7.f34VH = m49Zo(m45DW(strTrim3));
                            }
                        }
                    } else if (NK.j6("StrictHostKeyChecking", strTrim2)) {
                        String strM45DW2 = m45DW(strTrim3);
                        for (a aVar8 : arrayList) {
                            if (aVar8.f36gn == null) {
                                aVar8.f36gn = strM45DW2;
                            }
                        }
                    }
                }
            }
        }
    }

    private static boolean m53j6(String str, String str2) {
        try {
            OD od = new OD(str, (Character) null);
            od.j6(str2);
            return od.j6();
        } catch (bD unused) {
            return false;
        }
    }

    private File m54v5(String str) {
        if (str.startsWith("~/")) {
            return new File(this.f30j6, str.substring(2));
        }
        File file = new File(str);
        return file.isAbsolute() ? file : new File(this.f30j6, str);
    }

    public a m55j6(String str) {
        Map<String, a> mapM46DW = m46DW();
        a aVar = mapM46DW.get(str);
        if (aVar == null) {
            aVar = new a();
        }
        if (aVar.f37j6) {
            return aVar;
        }
        for (Map.Entry<String, a> entry : mapM46DW.entrySet()) {
            if (m47FH(entry.getKey()) && m53j6(entry.getKey(), str)) {
                aVar.m62j6(entry.getValue());
            }
        }
        if (aVar.f31DW == null) {
            aVar.f31DW = str;
        }
        if (aVar.f38v5 == null) {
            aVar.f38v5 = m51j6();
        }
        if (aVar.f32FH == 0) {
            aVar.f32FH = 22;
        }
        aVar.f37j6 = true;
        return aVar;
    }
}
