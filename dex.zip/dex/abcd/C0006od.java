package abcd;

@xu
public class C0006od {

    @uu
    private static boolean f33DW;

    @tu
    private static boolean f34j6;

    @ru(field = 946275383582972736L)
    private int[] f35FH;

    @ru(field = 902637302880787968L)
    private final La f36Hw;

    static {
        wu.j6(C0006od.class, -5564382537054054784L, -5564382537054054784L);
    }

    public C0006od(La la) {
        try {
            if (f34j6) {
                wu.j6(-1095510792867191783L, (Object) null, la);
            }
            this.f35FH = new int[10000];
            this.f36Hw = la;
        } catch (Throwable th) {
            if (f33DW) {
                wu.j6(th, -1095510792867191783L, (Object) null, la);
            }
            throw th;
        }
    }

    public void m21j6(Wa wa, Da da, boolean z, Sa sa) throws Throwable {
        Sa sa2 = sa;
        try {
            if (f34j6) {
                wu.j6(-909219274576662465L, this, wa, da, new Boolean(z), sa);
            }
            sa2.j6(wa);
            int[] iArr = wa.FH;
            int[] iArr2 = wa.Hw;
            int[] iArr3 = wa.v5;
            int[] iArr4 = wa.Zo;
            int[] iArr5 = wa.VH;
            int[] iArr6 = wa.gn;
            int i = wa.EQ;
            int i2 = 0;
            while (true) {
                int i3 = i2;
                int i4 = 0;
                while (i4 < i && iArr[i4] != 0) {
                    int i5 = iArr[i4];
                    int i6 = iArr2[i4];
                    int i7 = iArr3[i4];
                    int i8 = i3;
                    int i9 = i4;
                    int[] iArr7 = iArr3;
                    Sa sa3 = sa2;
                    try {
                        int iJ6 = sa.j6(i5, false, i6, i7, iArr5[i4], iArr4[i4], iArr6[i4]);
                        if (i8 >= this.f35FH.length) {
                            int[] iArr8 = new int[this.f35FH.length * 2];
                            System.arraycopy(this.f35FH, 0, iArr8, 0, this.f35FH.length);
                            this.f35FH = iArr8;
                        }
                        i3 = i8 + 1;
                        this.f35FH[i8] = iJ6;
                        i4 = i9 + 1;
                        sa2 = sa3;
                        iArr3 = iArr7;
                    } catch (Throwable th) {
                        th = th;
                        if (f33DW) {
                            wu.j6(th, -909219274576662465L, this, wa, da, new Boolean(z), sa);
                        }
                        throw th;
                    }
                }
                int[] iArr9 = iArr3;
                int i10 = i3;
                Sa sa4 = sa2;
                if (iArr[iArr.length - 1] == 0) {
                    sa4.DW(sa.j6(10, false, this.f35FH, 0, i10, 1, 1));
                    return;
                } else {
                    sa2 = sa4;
                    i2 = i10;
                    iArr3 = iArr9;
                }
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
