package abcd;

import android.content.SharedPreferences;
import com.aide.common.h;
import com.aide.common.u;
import com.aide.ui.U;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@xu
public class C0006Bk {

    @uu
    private static boolean f37DW;

    @tu
    private static boolean f38j6;

    @ru(field = 3055510209590855760L)
    private Map<String, u> f39FH;

    static {
        wu.j6(C0006Bk.class, 1379969761310196368L, 1379969761310196368L);
    }

    public C0006Bk() {
        try {
            if (f38j6) {
                wu.j6(3149001928542884067L, (Object) null);
            }
            this.f39FH = new HashMap();
        } catch (Throwable th) {
            if (f37DW) {
                wu.j6(th, 3149001928542884067L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -3358690075395431205L)
    private String m37DW(Wl wl) {
        try {
            if (f38j6) {
                wu.j6(2528444115235219595L, this, wl);
            }
            return wl instanceof Xl ? ((Xl) wl).v5() : wl.getClass().getName();
        } catch (Throwable th) {
            if (f37DW) {
                wu.j6(th, 2528444115235219595L, this, wl);
            }
            throw th;
        }
    }

    @su(method = -3042358371263704224L)
    private void m38FH() {
        try {
            if (f38j6) {
                wu.j6(-619641613257993356L, this);
            }
            try {
                SharedPreferences.Editor editorEdit = U.Zo().getSharedPreferences("KeybindingsService_2", 0).edit();
                editorEdit.clear();
                for (Map.Entry<String, u> entry : this.f39FH.entrySet()) {
                    editorEdit.putString(entry.getKey(), entry.getValue().Hw());
                }
                editorEdit.commit();
            } catch (Throwable th) {
                h.DW(th);
            }
        } catch (Throwable th2) {
            if (f37DW) {
                wu.j6(th2, -619641613257993356L, this);
            }
            throw th2;
        }
    }

    public void m39DW() {
        try {
            if (f38j6) {
                wu.j6(5270513457793762555L, this);
            }
            this.f39FH.clear();
            m38FH();
        } catch (Throwable th) {
            if (f37DW) {
                wu.j6(th, 5270513457793762555L, this);
            }
            throw th;
        }
    }

    public List<u> m40j6(Wl wl) {
        try {
            if (f38j6) {
                wu.j6(-378332460155568384L, this, wl);
            }
            ArrayList arrayList = new ArrayList();
            u uVar = this.f39FH.get(m37DW(wl));
            if (uVar != null) {
                arrayList.add(uVar);
            } else {
                arrayList.add(wl.FH());
                if (wl instanceof am) {
                    arrayList.addAll(((am) wl).Hw());
                }
            }
            return arrayList;
        } catch (Throwable th) {
            if (f37DW) {
                wu.j6(th, -378332460155568384L, this, wl);
            }
            throw th;
        }
    }

    public void m41j6() {
        u uVarJ6;
        try {
            if (f38j6) {
                wu.j6(1752110392064426607L, this);
            }
            try {
                for (Map.Entry<String, ?> entry : U.Zo().getSharedPreferences("KeybindingsService_2", 0).getAll().entrySet()) {
                    if ((entry.getValue() instanceof String) && (uVarJ6 = u.j6(entry.getValue().toString())) != null) {
                        this.f39FH.put(entry.getKey(), uVarJ6);
                    }
                }
            } catch (Throwable th) {
                h.DW(th);
            }
        } catch (Throwable th2) {
            if (f37DW) {
                wu.j6(th2, 1752110392064426607L, this);
            }
            throw th2;
        }
    }

    public void m42j6(Wl wl, u uVar) {
        try {
            if (f38j6) {
                wu.j6(-665299666285206764L, this, wl, uVar);
            }
            if (uVar == null) {
                this.f39FH.remove(m37DW(wl));
            } else {
                this.f39FH.put(m37DW(wl), uVar);
            }
            m38FH();
        } catch (Throwable th) {
            if (f37DW) {
                wu.j6(th, -665299666285206764L, this, wl, uVar);
            }
            throw th;
        }
    }
}
