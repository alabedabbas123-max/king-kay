package abcd;

public abstract class AbstractC0099Ms extends ms implements Rs {
    public final int m525Mr() {
        return getType().Mr();
    }

    public final Rs m526U2() {
        return this;
    }

    public final boolean m527a8() {
        return true;
    }

    public final int m528j3() {
        return getType().j3();
    }
}
