package abcd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import org.eclipse.jgit.JGitText;

public class C0012XG extends GG {

    private static final b f37j6 = new b(LG.j6, new aH[0]);

    private final gE f38DW;

    private final File f40FH;

    private final File f41Hw;

    private final File f42VH;

    private final File f43Zo;

    private final pK f45tp;

    private final File f47v5;

    private final AtomicReference<b> f44gn = new AtomicReference<>(f37j6);

    private final AtomicReference<a> f46u7 = new AtomicReference<>();

    private final tH f48we = new tH();

    private final AtomicReference<GG.a[]> f39EQ = new AtomicReference<>();

    private static final class a {

        final Collection<QG> f49DW;

        final byte[] f50FH;

        final LG f51j6;

        a(LG lg, List<QG> list, byte[] bArr) {
            this.f51j6 = lg;
            this.f49DW = list;
            this.f50FH = bArr;
        }

        Collection<BH> m77j6() {
            return this.f49DW;
        }
    }

    private static final class b {

        final aH[] f52DW;

        final LG f53j6;

        b(LG lg, aH[] aHVarArr) {
            this.f53j6 = lg;
            this.f52DW = aHVarArr;
        }
    }

    public C0012XG(gE gEVar, File file, File[] fileArr, pK pKVar) {
        this.f38DW = gEVar;
        this.f40FH = file;
        this.f41Hw = new File(this.f40FH, "info");
        this.f47v5 = new File(this.f40FH, "pack");
        this.f43Zo = new File(this.f41Hw, "alternates");
        this.f42VH = new File(this.f41Hw, "cached-packs");
        this.f45tp = pKVar;
        if (fileArr != null) {
            GG.a[] aVarArr = new GG.a[fileArr.length];
            for (int i = 0; i < fileArr.length; i++) {
                aVarArr[i] = m41DW(fileArr[i]);
            }
            this.f39EQ.set(aVarArr);
        }
    }

    private GG.a m41DW(File file) {
        File parentFile = file.getParentFile();
        return WE.a.DW(parentFile, this.f45tp) ? new GG.b(WE.j6(WE.a.j6(parentFile, this.f45tp))) : new GG.a(new C0012XG(this.f38DW, file, null, this.f45tp));
    }

    private b m42DW(b bVar) {
        b bVar2;
        b bVarM44FH;
        synchronized (this.f44gn) {
            do {
                bVar2 = this.f44gn.get();
                if (bVar2 != bVar) {
                    return bVar2;
                }
                bVarM44FH = m44FH(bVar2);
                if (bVarM44FH == bVar2) {
                    return bVarM44FH;
                }
            } while (!this.f44gn.compareAndSet(bVar2, bVarM44FH));
            return bVarM44FH;
        }
    }

    private void m43DW(aH aHVar) {
        b bVar;
        aH[] aHVarArr;
        do {
            bVar = this.f44gn.get();
            aH[] aHVarArr2 = bVar.f52DW;
            int iM48j6 = m48j6(aHVarArr2, aHVar);
            if (iM48j6 < 0) {
                break;
            }
            aHVarArr = new aH[aHVarArr2.length - 1];
            System.arraycopy(aHVarArr2, 0, aHVarArr, 0, iM48j6);
            System.arraycopy(aHVarArr2, iM48j6 + 1, aHVarArr, iM48j6, aHVarArr.length - iM48j6);
        } while (!this.f44gn.compareAndSet(bVar, new b(bVar.f53j6, aHVarArr)));
        aHVar.DW();
    }

    private b m44FH(b bVar) {
        Map<String, aH> mapM51j6 = m51j6(bVar);
        LG lgDW = LG.DW(this.f47v5);
        Set<String> setM47Ws = m47Ws();
        ArrayList arrayList = new ArrayList(setM47Ws.size() >> 2);
        boolean z = false;
        for (String str : setM47Ws) {
            if (str.length() == 49 && str.endsWith(".idx")) {
                String str2 = String.valueOf(str.substring(0, str.length() - 4)) + ".pack";
                if (setM47Ws.contains(str2)) {
                    aH aHVarRemove = mapM51j6.remove(str2);
                    if (aHVarRemove != null) {
                        arrayList.add(aHVarRemove);
                    } else {
                        arrayList.add(new aH(new File(this.f47v5, str), new File(this.f47v5, str2)));
                        z = true;
                    }
                }
            }
        }
        if (!z && mapM51j6.isEmpty() && lgDW.j6(bVar.f53j6)) {
            bVar.f53j6.DW(lgDW);
            return bVar;
        }
        Iterator<aH> it = mapM51j6.values().iterator();
        while (it.hasNext()) {
            it.next().DW();
        }
        if (arrayList.isEmpty()) {
            return new b(lgDW, f37j6.f52DW);
        }
        aH[] aHVarArr = (aH[]) arrayList.toArray(new aH[arrayList.size()]);
        Arrays.sort(aHVarArr, aH.j6);
        return new b(lgDW, aHVarArr);
    }

    private GG.a m45Hw(String str) {
        return m41DW(this.f45tp.j6(this.f40FH, str));
    }

    private GG.a[] m46QX() throws IOException {
        ArrayList arrayList = new ArrayList(4);
        BufferedReader bufferedReaderM50j6 = m50j6(this.f43Zo);
        while (true) {
            try {
                String line = bufferedReaderM50j6.readLine();
                if (line == null) {
                    bufferedReaderM50j6.close();
                    return (GG.a[]) arrayList.toArray(new GG.a[arrayList.size()]);
                }
                arrayList.add(m45Hw(line));
            } catch (Throwable th) {
                bufferedReaderM50j6.close();
                throw th;
            }
        }
    }

    private Set<String> m47Ws() {
        String[] list = this.f47v5.list();
        if (list == null) {
            return Collections.emptySet();
        }
        HashSet hashSet = new HashSet(list.length << 1);
        for (String str : list) {
            if (str.startsWith("pack-")) {
                hashSet.add(str);
            }
        }
        return hashSet;
    }

    private static int m48j6(aH[] aHVarArr, aH aHVar) {
        for (int i = 0; i < aHVarArr.length; i++) {
            if (aHVarArr[i] == aHVar) {
                return i;
            }
        }
        return -1;
    }

    private a m49j6(a aVar) {
        byte[] bArrJ6;
        LG lgDW = LG.DW(this.f42VH);
        int iZo = 0;
        try {
            bArrJ6 = BK.j6(this.f42VH);
        } catch (FileNotFoundException unused) {
            bArrJ6 = new byte[0];
        }
        if (aVar != null && aVar.f51j6.j6(lgDW) && Arrays.equals(aVar.f50FH, bArrJ6)) {
            aVar.f51j6.DW(lgDW);
            return aVar;
        }
        ArrayList arrayList = new ArrayList(4);
        HashSet hashSet = new HashSet();
        while (iZo < bArrJ6.length) {
            if (bArrJ6[iZo] == 35 || bArrJ6[iZo] == 10) {
                iZo = IK.Zo(bArrJ6, iZo);
            } else if (bArrJ6[iZo] == 43) {
                int i = iZo + 2;
                hashSet.add(yE.v5(bArrJ6, i));
                iZo = IK.Zo(bArrJ6, i);
            } else {
                ArrayList arrayList2 = new ArrayList(4);
                while (iZo < bArrJ6.length && bArrJ6[iZo] == 80) {
                    int iZo2 = IK.Zo(bArrJ6, iZo);
                    if (bArrJ6[iZo2 - 1] == 10) {
                        iZo2--;
                    }
                    arrayList2.add(IK.j6(bArrJ6, iZo + 2, iZo2));
                    iZo = IK.Zo(bArrJ6, iZo2);
                }
                if (!hashSet.isEmpty() && !arrayList2.isEmpty()) {
                    arrayList.add(new QG(this, hashSet, arrayList2));
                    hashSet = new HashSet();
                }
            }
        }
        arrayList.trimToSize();
        return new a(lgDW, Collections.unmodifiableList(arrayList), bArrJ6);
    }

    private static BufferedReader m50j6(File file) {
        return new BufferedReader(new FileReader(file));
    }

    private static Map<String, aH> m51j6(b bVar) {
        HashMap map = new HashMap();
        for (aH aHVar : bVar.f52DW) {
            if (aHVar.VH()) {
                aHVar.DW();
            } else {
                aH aHVar2 = (aH) map.put(aHVar.v5().getName(), aHVar);
                if (aHVar2 != null) {
                    map.put(aHVar2.v5().getName(), aHVar2);
                    aHVar.DW();
                }
            }
        }
        return map;
    }

    private void m52j6(aH aHVar) {
        b bVar;
        aH[] aHVarArr;
        do {
            bVar = this.f44gn.get();
            aH[] aHVarArr2 = bVar.f52DW;
            String name = aHVar.v5().getName();
            for (aH aHVar2 : aHVarArr2) {
                if (aH.j6.compare(aHVar, aHVar2) < 0) {
                    break;
                } else {
                    if (name.equals(aHVar2.v5().getName())) {
                        return;
                    }
                }
            }
            aHVarArr = new aH[aHVarArr2.length + 1];
            aHVarArr[0] = aHVar;
            System.arraycopy(aHVarArr2, 0, aHVarArr, 1, aHVarArr2.length);
        } while (!this.f44gn.compareAndSet(bVar, new b(bVar.f53j6, aHVarArr)));
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:?, code lost:
    
        continue;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    long m53DW(wH wHVar, AbstractC0052YD abstractC0052YD) {
        b bVarM42DW = this.f44gn.get();
        while (true) {
            for (aH aHVar : bVarM42DW.f52DW) {
                try {
                    long jDW = aHVar.DW(wHVar, abstractC0052YD);
                    if (0 <= jDW) {
                        return jDW;
                    }
                } catch (IOException unused) {
                    m43DW(aHVar);
                } catch (mD unused2) {
                    bVarM42DW = m42DW(bVarM42DW);
                }
            }
            return -1L;
        }
    }

    public File m54DW(AbstractC0052YD abstractC0052YD) {
        return super.DW(abstractC0052YD);
    }

    public boolean m55DW() {
        return this.f40FH.exists();
    }

    boolean m56DW(String str) {
        return j6(str).exists();
    }

    GG m57EQ() {
        return new DG(this);
    }

    FE m58FH(wH wHVar, String str, AbstractC0052YD abstractC0052YD) throws IOException {
        try {
            File fileJ6 = j6(str);
            FileInputStream fileInputStream = new FileInputStream(fileJ6);
            try {
                this.f48we.j6(abstractC0052YD);
                return sH.j6(fileInputStream, fileJ6, abstractC0052YD, wHVar);
            } finally {
                fileInputStream.close();
            }
        } catch (FileNotFoundException unused) {
            this.f48we.FH(abstractC0052YD);
            return null;
        }
    }

    public xE m59FH() {
        return m57EQ();
    }

    boolean m60FH(AbstractC0052YD abstractC0052YD) {
        if (this.f48we.DW(abstractC0052YD)) {
            return true;
        }
        for (aH aHVar : this.f44gn.get().f52DW) {
            try {
                if (aHVar.j6(abstractC0052YD)) {
                    return true;
                }
            } catch (IOException unused) {
                m43DW(aHVar);
            }
        }
        return false;
    }

    public C0055YG m61Hw() {
        return new C0055YG(this, this.f38DW);
    }

    public void m62J0() {
        zK.FH(this.f40FH);
        zK.DW(this.f41Hw);
        zK.DW(this.f47v5);
    }

    public Collection<aH> m63J8() {
        b bVarM42DW = this.f44gn.get();
        if (bVarM42DW == f37j6) {
            bVarM42DW = m42DW(bVarM42DW);
        }
        return Collections.unmodifiableCollection(Arrays.asList(bVarM42DW.f52DW));
    }

    gE m64VH() {
        return this.f38DW;
    }

    Collection<? extends BH> m65Zo() {
        a aVarM49j6 = this.f46u7.get();
        if (aVarM49j6 == null || aVarM49j6.f51j6.j6(this.f42VH)) {
            aVarM49j6 = m49j6(aVarM49j6);
        }
        Collection<? extends BH> collectionM77j6 = aVarM49j6.m77j6();
        boolean z = false;
        for (GG.a aVar : m73tp()) {
            Collection<? extends BH> collectionDW = aVar.DW();
            if (!collectionDW.isEmpty()) {
                if (collectionM77j6.isEmpty()) {
                    collectionM77j6 = collectionDW;
                } else {
                    if (!z) {
                        collectionM77j6 = new ArrayList((Collection<? extends Object>) collectionM77j6);
                        z = true;
                    }
                    collectionM77j6.addAll(collectionDW);
                }
            }
        }
        return collectionM77j6;
    }

    public final File m66gn() {
        return this.f40FH;
    }

    long m67j6(wH wHVar, String str, AbstractC0052YD abstractC0052YD) throws IOException {
        try {
            FileInputStream fileInputStream = new FileInputStream(j6(str));
            try {
                return sH.j6(fileInputStream, abstractC0052YD, wHVar);
            } finally {
                fileInputStream.close();
            }
        } catch (FileNotFoundException unused) {
            return -1L;
        }
    }

    GG.c m68j6(File file, yE yEVar, boolean z) {
        if (this.f48we.DW(yEVar)) {
            zK.j6(file);
            return GG.c.FH;
        }
        if (!z && j6(yEVar)) {
            zK.j6(file);
            return GG.c.DW;
        }
        File fileM54DW = m54DW((AbstractC0052YD) yEVar);
        if (fileM54DW.exists()) {
            zK.j6(file);
            return GG.c.FH;
        }
        if (file.renameTo(fileM54DW)) {
            fileM54DW.setReadOnly();
            this.f48we.j6(yEVar);
            return GG.c.j6;
        }
        zK.DW(fileM54DW.getParentFile());
        if (file.renameTo(fileM54DW)) {
            fileM54DW.setReadOnly();
            this.f48we.j6(yEVar);
            return GG.c.j6;
        }
        if (z || !j6(yEVar)) {
            zK.j6(file);
            return GG.c.Hw;
        }
        zK.j6(file);
        return GG.c.DW;
    }

    public aH m69j6(File file, File file2) throws IOException {
        String name = file.getName();
        String name2 = file2.getName();
        if (name.length() != 50 || !name.startsWith("pack-") || !name.endsWith(".pack")) {
            throw new IOException(MessageFormat.format(JGitText.j6().notAValidPack, file));
        }
        if (name2.length() != 49 || !name2.startsWith("pack-") || !name2.endsWith(".idx")) {
            throw new IOException(MessageFormat.format(JGitText.j6().notAValidPack, file2));
        }
        if (!name.substring(0, 45).equals(name2.substring(0, 45))) {
            throw new IOException(MessageFormat.format(JGitText.j6().packDoesNotMatchIndex, file));
        }
        aH aHVar = new aH(file2, file);
        m52j6(aHVar);
        return aHVar;
    }

    public void m70j6() {
        this.f48we.j6();
        b bVar = this.f44gn.get();
        this.f44gn.set(f37j6);
        for (aH aHVar : bVar.f52DW) {
            aHVar.DW();
        }
        GG.a[] aVarArr = this.f39EQ.get();
        if (aVarArr != null) {
            this.f39EQ.set(null);
            for (GG.a aVar : aVarArr) {
                aVar.j6();
            }
        }
    }

    void m71j6(TH th, MH mh, wH wHVar) {
        int i;
        b bVarM42DW = this.f44gn.get();
        loop0: while (true) {
            for (aH aHVar : bVarM42DW.f52DW) {
                try {
                    SG sgFH = aHVar.FH(wHVar, mh);
                    if (sgFH != null) {
                        th.j6(mh, sgFH);
                    }
                } catch (IOException unused) {
                    m43DW(aHVar);
                } catch (mD unused2) {
                    bVarM42DW = m42DW(bVarM42DW);
                }
            }
            break loop0;
        }
        for (GG.a aVar : m73tp()) {
            aVar.j6.j6(th, mh, wHVar);
        }
    }

    void m72j6(Set<yE> set, WD wd) {
        int i;
        b bVarM42DW;
        int size = set.size();
        b bVar = this.f44gn.get();
        while (true) {
            for (aH aHVar : bVar.f52DW) {
                try {
                    aHVar.j6(set, wd, 256);
                } catch (IOException unused) {
                    m43DW(aHVar);
                }
                if (set.size() > 256) {
                    return;
                }
            }
            if (set.size() != size || (bVarM42DW = m42DW(bVar)) == bVar || bVarM42DW.f52DW.length == 0) {
                break;
            } else {
                bVar = bVarM42DW;
            }
        }
        String strSubstring = wd.Hw().substring(0, 2);
        String[] list = new File(m66gn(), strSubstring).list();
        if (list != null) {
            for (String str : list) {
                if (str.length() == 38) {
                    try {
                        yE yEVarJ6 = yE.j6(String.valueOf(strSubstring) + str);
                        if (wd.DW(yEVarJ6) == 0) {
                            set.add(yEVarJ6);
                        }
                        if (set.size() > 256) {
                            return;
                        }
                    } catch (IllegalArgumentException unused2) {
                        continue;
                    }
                }
            }
        }
        for (GG.a aVar : m73tp()) {
            aVar.j6.j6(set, wd);
            if (set.size() > 256) {
                return;
            }
        }
    }

    public String toString() {
        return "ObjectDirectory[" + m66gn() + "]";
    }

    GG.a[] m73tp() {
        GG.a[] aVarArrM46QX = this.f39EQ.get();
        if (aVarArrM46QX == null) {
            synchronized (this.f39EQ) {
                aVarArrM46QX = this.f39EQ.get();
                if (aVarArrM46QX == null) {
                    try {
                        aVarArrM46QX = m46QX();
                    } catch (IOException unused) {
                        aVarArrM46QX = new GG.a[0];
                    }
                    this.f39EQ.set(aVarArrM46QX);
                }
            }
        }
        return aVarArrM46QX;
    }

    pK m74u7() {
        return this.f45tp;
    }

    /* JADX WARN: Code restructure failed: missing block: B:21:?, code lost:
    
        continue;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    FE m75v5(wH wHVar, AbstractC0052YD abstractC0052YD) throws IOException {
        if (this.f48we.DW(abstractC0052YD)) {
            FE feM58FH = m58FH(wHVar, abstractC0052YD.m314we(), abstractC0052YD);
            if (feM58FH != null) {
                return feM58FH;
            }
            this.f48we.FH(abstractC0052YD);
        }
        b bVarM42DW = this.f44gn.get();
        while (true) {
            for (aH aHVar : bVarM42DW.f52DW) {
                try {
                    FE feJ6 = aHVar.j6(wHVar, abstractC0052YD);
                    if (feJ6 != null) {
                        return feJ6;
                    }
                } catch (IOException unused) {
                    m43DW(aHVar);
                } catch (mD unused2) {
                    bVarM42DW = m42DW(bVarM42DW);
                }
            }
            return null;
        }
    }

    boolean m76we() {
        b bVar = this.f44gn.get();
        return bVar.f53j6.j6(this.f47v5) && bVar != m42DW(bVar);
    }
}
