package abcd;

import java.util.concurrent.Semaphore;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class C0003lF implements LE {

    private final LE f6j6;

    private final ReentrantLock f2DW = new ReentrantLock();

    private final Thread f3FH = Thread.currentThread();

    private final AtomicInteger f4Hw = new AtomicInteger(0);

    private final AtomicInteger f7v5 = new AtomicInteger(0);

    private final Semaphore f5Zo = new Semaphore(0);

    public C0003lF(LE le) {
        this.f6j6 = le;
    }

    private void m2Hw() {
        int andSet = this.f7v5.getAndSet(0);
        if (andSet > 0) {
            this.f6j6.update(andSet);
        }
    }

    private boolean m3v5() {
        return Thread.currentThread() == this.f3FH;
    }

    public void m4DW() {
        if (this.f4Hw.decrementAndGet() == 0) {
            this.f5Zo.release();
        }
    }

    public void m5FH() throws InterruptedException {
        while (this.f4Hw.get() > 0) {
            m2Hw();
            this.f5Zo.acquire();
        }
        m2Hw();
    }

    public boolean isCancelled() {
        this.f2DW.lock();
        try {
            return this.f6j6.isCancelled();
        } finally {
            this.f2DW.unlock();
        }
    }

    public void m6j6() {
        if (!m3v5()) {
            throw new IllegalStateException();
        }
        this.f6j6.j6();
    }

    public void m7j6(int i) {
        this.f4Hw.addAndGet(i);
    }

    public void m8j6(String str, int i) {
        if (!m3v5()) {
            throw new IllegalStateException();
        }
        this.f6j6.j6(str, i);
    }

    public void start(int i) {
        if (!m3v5()) {
            throw new IllegalStateException();
        }
        this.f6j6.start(i);
    }

    public void update(int i) {
        int andAdd = this.f7v5.getAndAdd(i);
        if (m3v5()) {
            m2Hw();
        } else if (andAdd == 0) {
            this.f5Zo.release();
        }
    }
}
