package abcd;

public abstract class AbstractC0090Am implements on {

    private final String f303j6;

    public AbstractC0090Am(String str) {
        if (str == null) {
            throw new NullPointerException("name == null");
        }
        this.f303j6 = str;
    }

    public String getName() {
        return this.f303j6;
    }
}
