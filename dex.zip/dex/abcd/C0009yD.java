package abcd;

import java.io.IOException;

public class C0009yD extends IOException {
    public C0009yD(HJ hj, String str) {
        super(hj.DW((String) null) + ": " + str);
    }

    public C0009yD(HJ hj, String str, Throwable th) {
        this(hj.DW((String) null) + ": " + str, th);
    }

    public C0009yD(String str) {
        super(str);
    }

    public C0009yD(String str, Throwable th) {
        super(str);
        initCause(th);
    }
}
