package abcd;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0077GH extends InputStream {

    private long f401DW;

    private int f402EQ;

    private long f403FH;

    private final byte[] f404Hw = new byte[512];

    private InputStream f405VH;

    private int f406Zo;

    private long f407gn;

    private final InputStream f408j6;

    private long f409tp;

    private int f410u7;

    private int f411v5;

    public AbstractC0077GH(InputStream inputStream) throws EOFException {
        int i;
        int i2;
        this.f408j6 = inputStream;
        if (!m725j6(this.f404Hw.length)) {
            throw new EOFException();
        }
        int i3 = 0;
        int i4 = 0;
        do {
            byte[] bArr = this.f404Hw;
            int i5 = this.f411v5;
            this.f411v5 = i5 + 1;
            i = bArr[i5] & 255;
            this.f401DW |= (long) ((i & 127) << i4);
            i4 += 7;
        } while ((i & 128) != 0);
        do {
            byte[] bArr2 = this.f404Hw;
            int i6 = this.f411v5;
            this.f411v5 = i6 + 1;
            i2 = bArr2[i6] & 255;
            this.f403FH |= (long) ((i2 & 127) << i3);
            i3 += 7;
        } while ((i2 & 128) != 0);
        this.f410u7 = m726v5();
    }

    private int m723Hw() {
        return this.f406Zo - this.f411v5;
    }

    private void m724Zo() throws IOException, YC {
        InputStream inputStream = this.f405VH;
        if (inputStream == null) {
            this.f405VH = m728FH();
            if (m729j6() != this.f401DW) {
                throw new YC(JGitText.j6().baseLengthIncorrect);
            }
            BK.j6(this.f405VH, this.f409tp);
            this.f407gn = this.f409tp;
            return;
        }
        long j = this.f407gn;
        long j2 = this.f409tp;
        if (j < j2) {
            BK.j6(inputStream, j2 - j);
            this.f407gn = this.f409tp;
        } else if (j > j2) {
            inputStream.close();
            this.f405VH = m728FH();
            BK.j6(this.f405VH, this.f409tp);
            this.f407gn = this.f409tp;
        }
    }

    private boolean m725j6(int i) throws IOException {
        int iM723Hw = m723Hw();
        if (i < iM723Hw) {
            return true;
        }
        if (iM723Hw == 0) {
            this.f411v5 = 0;
            this.f406Zo = 0;
        } else {
            byte[] bArr = this.f404Hw;
            int length = bArr.length;
            int i2 = this.f411v5;
            if (length - i2 < i) {
                System.arraycopy(bArr, i2, bArr, 0, iM723Hw);
                this.f411v5 = 0;
                this.f406Zo = iM723Hw;
            }
        }
        do {
            InputStream inputStream = this.f408j6;
            byte[] bArr2 = this.f404Hw;
            int i3 = this.f406Zo;
            int i4 = inputStream.read(bArr2, i3, bArr2.length - i3);
            if (i4 < 0) {
                return m723Hw() > 0;
            }
            this.f406Zo += i4;
        } while (this.f406Zo < this.f404Hw.length);
        return true;
    }

    private int m726v5() throws IOException, YC {
        if (!m725j6(8)) {
            return 2;
        }
        byte[] bArr = this.f404Hw;
        int i = this.f411v5;
        this.f411v5 = i + 1;
        int i2 = bArr[i] & 255;
        if ((i2 & 128) == 0) {
            if (i2 == 0) {
                throw new YC(JGitText.j6().unsupportedCommand0);
            }
            m725j6(i2);
            this.f402EQ = i2;
            return 1;
        }
        this.f409tp = 0L;
        if ((i2 & 1) != 0) {
            int i3 = this.f411v5;
            this.f411v5 = i3 + 1;
            this.f409tp = bArr[i3] & 255;
        }
        if ((i2 & 2) != 0) {
            long j = this.f409tp;
            byte[] bArr2 = this.f404Hw;
            int i4 = this.f411v5;
            this.f411v5 = i4 + 1;
            this.f409tp = j | ((long) ((bArr2[i4] & 255) << 8));
        }
        if ((i2 & 4) != 0) {
            long j2 = this.f409tp;
            byte[] bArr3 = this.f404Hw;
            int i5 = this.f411v5;
            this.f411v5 = i5 + 1;
            this.f409tp = j2 | ((long) ((bArr3[i5] & 255) << 16));
        }
        if ((i2 & 8) != 0) {
            long j3 = this.f409tp;
            byte[] bArr4 = this.f404Hw;
            int i6 = this.f411v5;
            this.f411v5 = i6 + 1;
            this.f409tp = j3 | ((long) ((bArr4[i6] & 255) << 24));
        }
        this.f402EQ = 0;
        if ((i2 & 16) != 0) {
            byte[] bArr5 = this.f404Hw;
            int i7 = this.f411v5;
            this.f411v5 = i7 + 1;
            this.f402EQ = bArr5[i7] & 255;
        }
        if ((i2 & 32) != 0) {
            int i8 = this.f402EQ;
            byte[] bArr6 = this.f404Hw;
            int i9 = this.f411v5;
            this.f411v5 = i9 + 1;
            this.f402EQ = ((bArr6[i9] & 255) << 8) | i8;
        }
        if ((i2 & 64) != 0) {
            int i10 = this.f402EQ;
            byte[] bArr7 = this.f404Hw;
            int i11 = this.f411v5;
            this.f411v5 = i11 + 1;
            this.f402EQ = i10 | ((bArr7[i11] & 255) << 16);
        }
        if (this.f402EQ == 0) {
            this.f402EQ = 65536;
        }
        return 0;
    }

    public long m727DW() {
        return this.f403FH;
    }

    protected abstract InputStream m728FH();

    @Override
    public void close() throws IOException {
        this.f408j6.close();
        InputStream inputStream = this.f405VH;
        if (inputStream != null) {
            inputStream.close();
        }
    }

    protected abstract long m729j6();

    @Override
    public int read() {
        byte[] bArr = new byte[1];
        if (read(bArr, 0, 1) == 1) {
            return bArr[0] & 255;
        }
        return -1;
    }

    @Override
    public int read(byte[] bArr, int i, int i2) throws IOException, YC {
        int i3 = 0;
        while (i2 > 0) {
            int iMin = Math.min(i2, this.f402EQ);
            int i4 = this.f410u7;
            if (i4 == 0) {
                m724Zo();
                iMin = this.f405VH.read(bArr, i, iMin);
                if (iMin < 0) {
                    throw new YC(JGitText.j6().baseLengthIncorrect);
                }
                this.f409tp += (long) iMin;
                this.f407gn = this.f409tp;
            } else {
                if (i4 != 1) {
                    if (i4 != 2) {
                        throw new YC(JGitText.j6().unsupportedCommand0);
                    }
                    if (i3 > 0) {
                        return i3;
                    }
                    return -1;
                }
                System.arraycopy(this.f404Hw, this.f411v5, bArr, i, iMin);
                this.f411v5 += iMin;
            }
            i3 += iMin;
            i += iMin;
            i2 -= iMin;
            this.f402EQ -= iMin;
            if (this.f402EQ == 0) {
                this.f410u7 = m726v5();
            }
        }
        return i3;
    }

    @Override
    public long skip(long j) throws YC {
        long j2 = 0;
        while (0 < j) {
            long jMin = Math.min(j, this.f402EQ);
            int i = this.f410u7;
            if (i == 0) {
                this.f409tp += jMin;
            } else {
                if (i != 1) {
                    if (i == 2) {
                        return j2;
                    }
                    throw new YC(JGitText.j6().unsupportedCommand0);
                }
                this.f411v5 = (int) (((long) this.f411v5) + jMin);
            }
            j2 += jMin;
            j -= jMin;
            this.f402EQ = (int) (((long) this.f402EQ) - jMin);
            if (this.f402EQ == 0) {
                this.f410u7 = m726v5();
            }
        }
        return j2;
    }
}
