package abcd;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0024RK extends OutputStream {

    private int f140DW;

    private OutputStream f141FH;

    private ArrayList<a> f142j6;

    static class a {

        int f143DW;

        final byte[] f144j6;

        a() {
            this.f144j6 = new byte[8192];
        }

        a(int i) {
            this.f144j6 = new byte[i];
        }

        boolean m236j6() {
            return this.f143DW == this.f144j6.length;
        }
    }

    private class b extends InputStream {

        private int f145DW;

        private a f146FH;

        private int f147Hw;

        private byte[] f148j6;

        b() {
            this.f146FH = (a) AbstractC0024RK.this.f142j6.get(this.f145DW);
        }

        private boolean m237j6() {
            int i = this.f145DW + 1;
            this.f145DW = i;
            if (i >= AbstractC0024RK.this.f142j6.size()) {
                return false;
            }
            this.f146FH = (a) AbstractC0024RK.this.f142j6.get(this.f145DW);
            this.f147Hw = 0;
            return true;
        }

        @Override
        public int read() {
            if (this.f148j6 == null) {
                this.f148j6 = new byte[1];
            }
            if (read(this.f148j6) == 1) {
                return this.f148j6[0] & 255;
            }
            return -1;
        }

        @Override
        public int read(byte[] bArr, int i, int i2) {
            int i3 = 0;
            if (i2 == 0) {
                return 0;
            }
            while (i2 > 0) {
                int iMin = Math.min(this.f146FH.f143DW - this.f147Hw, i2);
                if (iMin <= 0) {
                    if (!m237j6()) {
                        break;
                    }
                } else {
                    System.arraycopy(this.f146FH.f144j6, this.f147Hw, bArr, i, iMin);
                    this.f147Hw += iMin;
                    i += iMin;
                    i2 -= iMin;
                    i3 += iMin;
                }
            }
            if (i3 > 0) {
                return i3;
            }
            return -1;
        }

        @Override
        public long skip(long j) {
            long j2 = 0;
            while (0 < j) {
                int iMin = (int) Math.min(this.f146FH.f143DW - this.f147Hw, j);
                if (iMin <= 0) {
                    if (!m237j6()) {
                        break;
                    }
                } else {
                    this.f147Hw += iMin;
                    long j3 = iMin;
                    j2 += j3;
                    j -= j3;
                }
            }
            return j2;
        }
    }

    public static class c extends AbstractC0024RK {
        public c(int i) {
            super(i);
        }

        @Override
        protected OutputStream mo230Hw() throws IOException {
            throw new IOException(JGitText.j6().inMemoryBufferLimitExceeded);
        }
    }

    public static class d extends AbstractC0024RK {

        private final File f150Hw;

        private File f151v5;

        public d() {
            this(null, 1048576);
        }

        public d(File file, int i) {
            super(i);
            this.f150Hw = file;
        }

        @Override
        public long mo228DW() {
            File file = this.f151v5;
            return file == null ? super.mo228DW() : file.length();
        }

        @Override
        protected OutputStream mo230Hw() {
            this.f151v5 = File.createTempFile("jgit_", ".buf", this.f150Hw);
            return new FileOutputStream(this.f151v5);
        }

        @Override
        public void mo232j6() {
            super.mo232j6();
            File file = this.f151v5;
            if (file != null) {
                try {
                    if (!file.delete()) {
                        this.f151v5.deleteOnExit();
                    }
                } finally {
                    this.f151v5 = null;
                }
            }
        }

        @Override
        public void mo234j6(OutputStream outputStream, LE le) throws IOException {
            if (this.f151v5 == null) {
                super.mo234j6(outputStream, le);
                return;
            }
            if (le == null) {
                le = vE.j6;
            }
            FileInputStream fileInputStream = new FileInputStream(this.f151v5);
            try {
                byte[] bArr = new byte[8192];
                while (true) {
                    int i = fileInputStream.read(bArr);
                    if (i < 0) {
                        fileInputStream.close();
                        return;
                    } else {
                        outputStream.write(bArr, 0, i);
                        le.update(i / 1024);
                    }
                }
            } catch (Throwable th) {
                fileInputStream.close();
                throw th;
            }
        }
    }

    protected AbstractC0024RK(int i) {
        this.f140DW = i;
        m235v5();
    }

    private long m223VH() {
        return ((((long) this.f142j6.size()) - 1) * 8192) + ((long) m224gn().f143DW);
    }

    private a m224gn() {
        ArrayList<a> arrayList = this.f142j6;
        return arrayList.get(arrayList.size() - 1);
    }

    private void m226tp() throws IOException {
        this.f141FH = mo230Hw();
        ArrayList<a> arrayList = this.f142j6;
        a aVarRemove = arrayList.remove(arrayList.size() - 1);
        for (a aVar : this.f142j6) {
            this.f141FH.write(aVar.f144j6, 0, aVar.f143DW);
        }
        this.f142j6 = null;
        this.f141FH = new XK(this.f141FH, 8192);
        this.f141FH.write(aVarRemove.f144j6, 0, aVarRemove.f143DW);
    }

    private boolean m227u7() throws IOException {
        if (m223VH() < this.f140DW) {
            return false;
        }
        m226tp();
        return true;
    }

    public long mo228DW() {
        return m223VH();
    }

    public InputStream m229FH() {
        return new b();
    }

    protected abstract OutputStream mo230Hw();

    public byte[] m231Zo() {
        long jMo228DW = mo228DW();
        if (2147483647L < jMo228DW) {
            throw new OutOfMemoryError(JGitText.j6().lengthExceedsMaximumArraySize);
        }
        byte[] bArr = new byte[(int) jMo228DW];
        int i = 0;
        for (a aVar : this.f142j6) {
            System.arraycopy(aVar.f144j6, 0, bArr, i, aVar.f143DW);
            i += aVar.f143DW;
        }
        return bArr;
    }

    @Override
    public void close() {
        OutputStream outputStream = this.f141FH;
        if (outputStream != null) {
            try {
                outputStream.close();
            } finally {
                this.f141FH = null;
            }
        }
    }

    public void mo232j6() {
        this.f142j6 = null;
        OutputStream outputStream = this.f141FH;
        if (outputStream != null) {
            try {
                outputStream.close();
            } catch (IOException unused) {
            } finally {
                this.f141FH = null;
            }
        }
    }

    public void m233j6(InputStream inputStream) throws IOException {
        if (this.f142j6 != null) {
            while (true) {
                a aVarM224gn = m224gn();
                if (aVarM224gn.m236j6()) {
                    if (m227u7()) {
                        break;
                    }
                    aVarM224gn = new a();
                    this.f142j6.add(aVarM224gn);
                }
                byte[] bArr = aVarM224gn.f144j6;
                int i = aVarM224gn.f143DW;
                int i2 = inputStream.read(bArr, i, bArr.length - i);
                if (i2 < 1) {
                    return;
                } else {
                    aVarM224gn.f143DW += i2;
                }
            }
        }
        byte[] bArr2 = new byte[8192];
        while (true) {
            int i3 = inputStream.read(bArr2);
            if (i3 <= 0) {
                return;
            } else {
                this.f141FH.write(bArr2, 0, i3);
            }
        }
    }

    public void mo234j6(OutputStream outputStream, LE le) throws IOException {
        if (le == null) {
            le = vE.j6;
        }
        for (a aVar : this.f142j6) {
            outputStream.write(aVar.f144j6, 0, aVar.f143DW);
            le.update(aVar.f143DW / 1024);
        }
    }

    public void m235v5() {
        if (this.f141FH != null) {
            mo232j6();
        }
        int i = this.f140DW;
        if (i < 8192) {
            this.f142j6 = new ArrayList<>(1);
            this.f142j6.add(new a(this.f140DW));
        } else {
            this.f142j6 = new ArrayList<>(i / 8192);
            this.f142j6.add(new a());
        }
    }

    @Override
    public void write(int i) throws IOException {
        OutputStream outputStream = this.f141FH;
        if (outputStream != null) {
            outputStream.write(i);
            return;
        }
        a aVarM224gn = m224gn();
        if (aVarM224gn.m236j6()) {
            if (m227u7()) {
                this.f141FH.write(i);
                return;
            } else {
                aVarM224gn = new a();
                this.f142j6.add(aVarM224gn);
            }
        }
        byte[] bArr = aVarM224gn.f144j6;
        int i2 = aVarM224gn.f143DW;
        aVarM224gn.f143DW = i2 + 1;
        bArr[i2] = (byte) i;
    }

    @Override
    public void write(byte[] bArr, int i, int i2) throws IOException {
        if (this.f141FH == null) {
            while (i2 > 0) {
                a aVarM224gn = m224gn();
                if (aVarM224gn.m236j6()) {
                    if (m227u7()) {
                        break;
                    }
                    aVarM224gn = new a();
                    this.f142j6.add(aVarM224gn);
                }
                int iMin = Math.min(aVarM224gn.f144j6.length - aVarM224gn.f143DW, i2);
                System.arraycopy(bArr, i, aVarM224gn.f144j6, aVarM224gn.f143DW, iMin);
                aVarM224gn.f143DW += iMin;
                i2 -= iMin;
                i += iMin;
            }
        }
        if (i2 > 0) {
            this.f141FH.write(bArr, i, i2);
        }
    }
}
