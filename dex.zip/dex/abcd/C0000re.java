package abcd;

import java.util.List;
import java.util.Set;

@xu
public class C0000re implements qa {

    @uu
    private static boolean f0DW;

    @InterfaceC0101tu
    private static boolean f1j6;

    @InterfaceC0016ru(field = 102912974583382600L)
    private final La f2FH;

    @InterfaceC0016ru(field = -1332211849537951909L)
    private final ke f3Hw;

    @InterfaceC0016ru(field = -503388224877062583L)
    private final he f4Zo;

    @InterfaceC0016ru(field = -3010890552775801696L)
    private final je f5v5;

    static {
        wu.j6(C0000re.class, 1010501436938537065L, 1010501436938537065L);
    }

    public C0000re(La la, ne neVar, boolean z) {
        try {
            if (f1j6) {
                wu.j6(-1574519301101311920L, (Object) null, la, neVar, new Boolean(z));
            }
            this.f2FH = la;
            this.f3Hw = new ke(la, neVar);
            this.f5v5 = new je(la, neVar, z);
            this.f4Zo = new he(la, neVar);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1574519301101311920L, (Object) null, la, neVar, new Boolean(z));
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 1849110850037684793L)
    private int m0DW(String str) {
        try {
            if (f1j6) {
                wu.j6(1869820821095322120L, this, str);
            }
            int i = 0;
            while (i < str.length() && Character.isWhitespace(str.charAt(i))) {
                i++;
            }
            return i + 1;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1869820821095322120L, this, str);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -5341401720954772L)
    private void m1DW(Sa sa, int i) {
        try {
            if (f1j6) {
                wu.j6(2366403061129824853L, this, sa, new Integer(i));
            }
            m2DW(sa, sa.Zo(sa.Zo(i, 0), 1), sa.Zo(sa.Zo(i, 2), 1));
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2366403061129824853L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -205019711792590435L)
    private void m2DW(Sa sa, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(289467232685241160L, this, sa, new Integer(i), new Integer(i2));
            }
            if (sa.XG(i) || sa.XG(i2)) {
                return;
            }
            this.f2FH.J0.j6(sa.VH(), sa.vy(i), sa.BT(i), sa.QX(i), sa.Ws(i), sa.vy(i2), sa.BT(i2), sa.QX(i2), sa.Ws(i2));
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 289467232685241160L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -603203008029866595L)
    private int m3FH(String str) {
        try {
            if (f1j6) {
                wu.j6(-472086351111739140L, this, str);
            }
            int length = str.length() - 1;
            while (length > 0 && Character.isWhitespace(str.charAt(length))) {
                length--;
            }
            return length + 1;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -472086351111739140L, this, str);
            }
            throw th;
        }
    }

    public wb<qa.a> m4DW(Sa sa, Ta ta, int i, int i2, int i3) {
        try {
            if (f1j6) {
                wu.j6(-2491723192358478388L, this, sa, ta, new Integer(i), new Integer(i2), new Integer(i3));
            }
            return this.f3Hw.j6(sa, ta, i, i2, i3);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2491723192358478388L, this, sa, ta, new Integer(i), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }

    public String m5DW(Na na) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(-1670892993668847816L, this, na);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1670892993668847816L, this, na);
            }
            throw th;
        }
    }

    public void m6DW(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(961919751465946021L, this, da, new Integer(i), new Integer(i2));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 961919751465946021L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m7DW(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                wu.j6(-474093140711396373L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -474093140711396373L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m8DW(Sa sa, Ta ta, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(6166254513527951040L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            this.f3Hw.j6(sa, ta, i, i2);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 6166254513527951040L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public wb<qa.a> m9FH(Sa sa, Ta ta, int i, int i2, int i3) {
        try {
            if (f1j6) {
                wu.j6(-595394456226193827L, this, sa, ta, new Integer(i), new Integer(i2), new Integer(i3));
            }
            return this.f3Hw.FH(sa, ta, i, i2, i3);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -595394456226193827L, this, sa, ta, new Integer(i), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }

    public String m10FH(Na na) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(587188576794522675L, this, na);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 587188576794522675L, this, na);
            }
            throw th;
        }
    }

    public void m11FH(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(-110986418908970752L, this, da, new Integer(i), new Integer(i2));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -110986418908970752L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m12FH(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                wu.j6(-1807382166699742947L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1807382166699742947L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m13FH(Sa sa, Ta ta, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(2551865586770273140L, this, sa, ta, new Integer(i), new Integer(i2));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2551865586770273140L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m14Hw(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(2517929480133794496L, this, da, new Integer(i), new Integer(i2));
            }
            int iM0DW = m0DW(da.DW(i));
            this.f2FH.gn.j6(da, i, iM0DW, i, iM0DW, "<!--");
            int iM3FH = m3FH(da.DW(i2)) + 1;
            if (i == i2) {
                iM3FH += 4;
            }
            int i3 = iM3FH;
            this.f2FH.gn.j6(da, i2, i3, i2, i3, "-->");
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2517929480133794496L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m15Hw(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                wu.j6(3941994839119065900L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 3941994839119065900L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m16VH(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(-3941912067738213900L, this, da, new Integer(i), new Integer(i2));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -3941912067738213900L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m17Zo(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(389873193327982233L, this, da, new Integer(i), new Integer(i2));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 389873193327982233L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m18gn(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(-3943172402235690720L, this, da, new Integer(i), new Integer(i2));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -3943172402235690720L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public wb<qa.a> m19j6(Sa sa, Ta ta, int i, int i2, int i3) {
        try {
            if (f1j6) {
                wu.j6(6193409928459745912L, this, sa, ta, new Integer(i), new Integer(i2), new Integer(i3));
            }
            return this.f3Hw.DW(sa, ta, i, i2, i3);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 6193409928459745912L, this, sa, ta, new Integer(i), new Integer(i2), new Integer(i3));
            }
            throw th;
        }
    }

    public String m20j6() {
        try {
            if (!f1j6) {
                return "";
            }
            wu.j6(-193302768788419601L, this);
            return "";
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -193302768788419601L, this);
            }
            throw th;
        }
    }

    public String m21j6(Na na) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(-2320507863624455712L, this, na);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2320507863624455712L, this, na);
            }
            throw th;
        }
    }

    public String m22j6(Sa sa, int i, int i2, Ya ya) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(1174241279949807279L, this, sa, new Integer(i), new Integer(i2), ya);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1174241279949807279L, this, sa, new Integer(i), new Integer(i2), ya);
            }
            throw th;
        }
    }

    public String m23j6(Sa sa, int i, int i2, Yb<? extends Ya> yb) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(604909140766229025L, this, sa, new Integer(i), new Integer(i2), yb);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 604909140766229025L, this, sa, new Integer(i), new Integer(i2), yb);
            }
            throw th;
        }
    }

    public String m24j6(Sa sa, int i, int i2, Yb<? extends Ya> yb, Yb<Aa> yb2) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(-5063898020577652512L, this, sa, new Integer(i), new Integer(i2), yb, yb2);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -5063898020577652512L, this, sa, new Integer(i), new Integer(i2), yb, yb2);
            }
            throw th;
        }
    }

    public String m25j6(Sa sa, Fb<C0124ua, Aa> fb) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(1302591888364909185L, this, sa, fb);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1302591888364909185L, this, sa, fb);
            }
            throw th;
        }
    }

    public String m26j6(Sa sa, Fb<C0124ua, Aa> fb, Yb<Na> yb) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(7770089407291155249L, this, sa, fb, yb);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 7770089407291155249L, this, sa, fb, yb);
            }
            throw th;
        }
    }

    public String m27j6(String str, String str2) {
        try {
            if (!f1j6) {
                return null;
            }
            wu.j6(-1508917702694676332L, this, str, str2);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1508917702694676332L, this, str, str2);
            }
            throw th;
        }
    }

    public Set<? extends ha> m28j6(Sa sa, int i) {
        try {
            if (f1j6) {
                wu.j6(432655876143943519L, this, sa, new Integer(i));
            }
            return this.f3Hw.j6(sa, i);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 432655876143943519L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    public void m29j6(Da da) {
        try {
            if (f1j6) {
                wu.j6(489926657373165753L, this, da);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 489926657373165753L, this, da);
            }
            throw th;
        }
    }

    public void m30j6(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                wu.j6(7185132023099642640L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 7185132023099642640L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m31j6(Da da, int i, int i2, int i3, int i4, Ya ya) {
        if (f1j6) {
            wu.j6(-1027558388378482368L, this, new Object[]{da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4), ya});
        }
    }

    public void m32j6(Da da, int i, int i2, int i3, int i4, Ya ya, int[] iArr, Ya[] yaArr, int[] iArr2) {
        if (f1j6) {
            wu.j6(-478182998222750076L, this, new Object[]{da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4), ya, iArr, yaArr, iArr2});
        }
    }

    public void m33j6(Da da, int i, int i2, int i3, Ya ya) {
        try {
            if (f1j6) {
                wu.j6(175451714998947989L, this, da, new Integer(i), new Integer(i2), new Integer(i3), ya);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 175451714998947989L, this, da, new Integer(i), new Integer(i2), new Integer(i3), ya);
            }
            throw th;
        }
    }

    public void m34j6(Da da, int i, int i2, Ia ia) {
        try {
            if (f1j6) {
                wu.j6(-689291171790965577L, this, da, new Integer(i), new Integer(i2), ia);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -689291171790965577L, this, da, new Integer(i), new Integer(i2), ia);
            }
            throw th;
        }
    }

    public void m35j6(Da da, int i, int i2, String str, int i3) {
        try {
            if (f1j6) {
                wu.j6(2882729295617150265L, this, da, new Integer(i), new Integer(i2), str, new Integer(i3));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2882729295617150265L, this, da, new Integer(i), new Integer(i2), str, new Integer(i3));
            }
            throw th;
        }
    }

    public void m36j6(Da da, int i, int i2, String str, int i3, int i4, boolean z) {
        if (f1j6) {
            wu.j6(5752809181914140160L, this, new Object[]{da, new Integer(i), new Integer(i2), str, new Integer(i3), new Integer(i4), new Boolean(z)});
        }
    }

    public void m37j6(Da da, int i, int i2, boolean z) {
        try {
            if (f1j6) {
                wu.j6(711241113394162617L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 711241113394162617L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            throw th;
        }
    }

    public void m38j6(Da da, Da da2, int i, int i2, int i3, int i4) {
        if (f1j6) {
            wu.j6(303297395368493435L, this, new Object[]{da, da2, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4)});
        }
        this.f4Zo.j6(da, da2, i, i2, i3, i4);
    }

    public void m39j6(Da da, Ia ia, Cb cb, Cb cb2, Cb cb3, Cb cb4, Cb cb5) {
        if (f1j6) {
            wu.j6(-367586317134423465L, this, new Object[]{da, ia, cb, cb2, cb3, cb4, cb5});
        }
    }

    public void m40j6(Da da, String str) {
        try {
            if (f1j6) {
                wu.j6(4810940132383529120L, this, da, str);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 4810940132383529120L, this, da, str);
            }
            throw th;
        }
    }

    public void m41j6(Sa sa, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(-1922970941579436048L, this, sa, new Integer(i), new Integer(i2));
            }
            int iJ8 = sa.J8(i, i2 - 1);
            if (iJ8 != -1) {
                int iP8 = sa.P8(iJ8);
                if (iP8 != 7) {
                    if (iP8 != 8) {
                        if (iP8 != 11) {
                            if (iP8 != 12) {
                                if (iP8 == 25 || iP8 == 49) {
                                    int iEr = sa.er(sa.er(iJ8));
                                    int iP9 = sa.P8(iEr);
                                    if (iP9 == 200) {
                                        m1DW(sa, sa.er(iEr));
                                        return;
                                    } else if (iP9 != 201 && iP9 == 207) {
                                        m1DW(sa, sa.er(iEr));
                                        return;
                                    }
                                } else if (iP8 != 76) {
                                    if (iP8 != 100) {
                                        switch (iP8) {
                                        }
                                    }
                                }
                            }
                        }
                    }
                    m2DW(sa, iJ8, sa.Zo(sa.er(iJ8), 0));
                    return;
                }
                int iEr2 = sa.er(iJ8);
                m2DW(sa, iJ8, sa.Zo(iEr2, sa.we(iEr2) - 1));
                return;
            }
            this.f2FH.J0.j6(sa.VH());
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1922970941579436048L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m42j6(Sa sa, int i, int i2, int i3, boolean z) {
        try {
            if (f1j6) {
                wu.j6(6349940832521391900L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Boolean(z));
            }
            this.f5v5.j6(sa, i, i2, i3, z);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 6349940832521391900L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Boolean(z));
            }
            throw th;
        }
    }

    public void m43j6(Sa sa, Da da, na naVar, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(389169130374868327L, this, sa, da, naVar, new Integer(i), new Integer(i2));
            }
            this.f5v5.FH(sa, i, i2);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 389169130374868327L, this, sa, da, naVar, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m44j6(nb nbVar, Da da, int i, int i2, String str, List<String> list) {
        if (f1j6) {
            wu.j6(-1806681135341169032L, this, new Object[]{nbVar, da, new Integer(i), new Integer(i2), str, list});
        }
    }

    public boolean m45j6(Da da, int i, int i2) {
        try {
            if (!f1j6) {
                return false;
            }
            wu.j6(164711689744161792L, this, da, new Integer(i), new Integer(i2));
            return false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 164711689744161792L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m46j6(Ia ia, Cb cb, Cb cb2, Cb cb3, Cb cb4, Cb cb5) {
        if (f1j6) {
            wu.j6(673448448851259525L, this, new Object[]{ia, cb, cb2, cb3, cb4, cb5});
        }
        return false;
    }

    public boolean m47j6(String str) {
        try {
            if (!f1j6) {
                return false;
            }
            wu.j6(-1454639518865758733L, this, str);
            return false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1454639518865758733L, this, str);
            }
            throw th;
        }
    }

    public int[] m48j6(Sa sa, Ta ta, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(3093121321746811992L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            return this.f3Hw.DW(sa, ta, i, i2);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 3093121321746811992L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m49u7(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(4588557452633736513L, this, da, new Integer(i), new Integer(i2));
            }
            String strDW = da.DW(i2);
            if (strDW.trim().endsWith("-->")) {
                int iM3FH = m3FH(strDW);
                this.f2FH.gn.j6(da, i2, iM3FH - 2, i2, iM3FH + 1, "");
            }
            String strDW2 = da.DW(i);
            if (strDW2.trim().startsWith("<!--")) {
                int iM0DW = m0DW(strDW2);
                this.f2FH.gn.j6(da, i, iM0DW, i, iM0DW + 4, "");
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 4588557452633736513L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m50v5(Da da, int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(1937374321911848967L, this, da, new Integer(i), new Integer(i2));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1937374321911848967L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m51v5(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                wu.j6(2812181874164000208L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2812181874164000208L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }
}
