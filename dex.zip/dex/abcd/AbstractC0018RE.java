package abcd;

import java.io.IOException;
import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0018RE {

    private boolean f112DW;

    private KE f113FH;

    private yE f115VH;

    private yE f116Zo;

    private yE f118j6;

    private boolean f119tp;

    private final ME f120u7;

    private boolean f121v5;

    private a f117gn = a.NOT_ATTEMPTED;

    private String f114Hw = "";

    public enum a {
        NOT_ATTEMPTED,
        LOCK_FAILURE,
        NO_CHANGE,
        NEW,
        FORCED,
        FAST_FORWARD,
        REJECTED,
        REJECTED_CURRENT_BRANCH,
        IO_FAILURE,
        RENAMED;

        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            int length = aVarArrValuesCustom.length;
            a[] aVarArr = new a[length];
            System.arraycopy(aVarArrValuesCustom, 0, aVarArr, 0, length);
            return aVarArr;
        }
    }

    private abstract class b {
        private b() {
        }

        b(AbstractC0018RE abstractC0018RE, b bVar) {
            this();
        }

        abstract a m198j6(a aVar);
    }

    protected AbstractC0018RE(ME me) {
        this.f120u7 = me;
        this.f116Zo = me.DW();
    }

    private void m165aM() {
        if (this.f118j6 == null) {
            throw new IllegalStateException(JGitText.j6().aNewObjectIdIsRequired);
        }
    }

    private a m166j6(qG qGVar, b bVar) {
        if (m184gn().FH(m176Hw())) {
            return a.LOCK_FAILURE;
        }
        try {
            if (!m173DW(true)) {
                return a.LOCK_FAILURE;
            }
            if (this.f115VH != null) {
                if (!YD.j6(this.f115VH, this.f116Zo != null ? this.f116Zo : yE.Ws())) {
                    return a.LOCK_FAILURE;
                }
            }
            if (this.f116Zo == null) {
                return bVar.m198j6(a.NEW);
            }
            dG dGVarM167j6 = m167j6(qGVar, (YD) this.f118j6);
            dG dGVarM167j7 = m167j6(qGVar, (YD) this.f116Zo);
            if (dGVarM167j6 == dGVarM167j7 && !this.f119tp) {
                return bVar.m198j6(a.NO_CHANGE);
            }
            if ((dGVarM167j6 instanceof dG) && (dGVarM167j7 instanceof dG) && qGVar.j6(dGVarM167j7, dGVarM167j6)) {
                return bVar.m198j6(a.FAST_FORWARD);
            }
            return m177J0() ? bVar.m198j6(a.FORCED) : a.REJECTED;
        } finally {
            m179QX();
        }
    }

    private static iG m167j6(qG qGVar, YD yd) {
        if (yd == null) {
            return null;
        }
        try {
            return qGVar.Zo(yd);
        } catch (fD unused) {
            return null;
        }
    }

    protected abstract a m168DW(a aVar);

    public a m169DW(qG qGVar) throws IOException {
        m165aM();
        try {
            a aVarM166j6 = m166j6(qGVar, (b) new PE(this));
            this.f117gn = aVarM166j6;
            return aVarM166j6;
        } catch (IOException e) {
            this.f117gn = a.IO_FAILURE;
            throw e;
        }
    }

    public a m170DW(String str) {
        if (!str.startsWith("refs/")) {
            throw new IllegalArgumentException(MessageFormat.format(JGitText.j6().illegalArgumentNotA, "refs/"));
        }
        try {
            if (m184gn().FH(m176Hw())) {
                return a.LOCK_FAILURE;
            }
            try {
                if (!m173DW(false)) {
                    a aVar = a.LOCK_FAILURE;
                    m179QX();
                    return aVar;
                }
                ME meJ6 = m184gn().j6(m176Hw());
                if (meJ6 != null && meJ6.Zo() && str.equals(meJ6.getTarget().getName())) {
                    a aVar2 = a.NO_CHANGE;
                    this.f117gn = aVar2;
                    m179QX();
                    return aVar2;
                }
                if (meJ6 != null && meJ6.DW() != null) {
                    m191j6(meJ6.DW());
                }
                ME meJ7 = m184gn().j6(str);
                if (meJ7 != null && meJ7.DW() != null) {
                    m172DW((YD) meJ7.DW());
                }
                a aVarM188j6 = m188j6(str);
                this.f117gn = aVarM188j6;
                m179QX();
                return aVarM188j6;
            } catch (IOException e) {
                this.f117gn = a.IO_FAILURE;
                throw e;
            }
        } catch (Throwable th) {
            m179QX();
            throw th;
        }
    }

    public void m171DW() {
        this.f114Hw = null;
        this.f121v5 = false;
    }

    public void m172DW(YD yd) {
        this.f118j6 = yd.Hw();
    }

    protected abstract boolean m173DW(boolean z);

    protected abstract UE m174EQ();

    public a m175FH() {
        this.f112DW = true;
        return m182XL();
    }

    public String m176Hw() {
        return m180VH().getName();
    }

    public boolean m177J0() {
        return this.f112DW;
    }

    protected boolean m178J8() {
        return this.f121v5;
    }

    protected abstract void m179QX();

    public ME m180VH() {
        return this.f120u7;
    }

    public void m181Ws() {
        this.f119tp = true;
    }

    public a m182XL() {
        qG qGVar = new qG(m174EQ());
        try {
            return m169DW(qGVar);
        } finally {
            qGVar.EQ();
        }
    }

    public yE m183Zo() {
        return this.f116Zo;
    }

    protected abstract OE m184gn();

    public a m185j6() {
        qG qGVar = new qG(m174EQ());
        try {
            return m187j6(qGVar);
        } finally {
            qGVar.EQ();
        }
    }

    protected abstract a m186j6(a aVar);

    public a m187j6(qG qGVar) throws IOException {
        String name = m180VH().v5().getName();
        if (name.startsWith("refs/heads/")) {
            ME meJ6 = m184gn().j6("HEAD");
            while (meJ6.Zo()) {
                meJ6 = meJ6.getTarget();
                if (name.equals(meJ6.getName())) {
                    a aVar = a.REJECTED_CURRENT_BRANCH;
                    this.f117gn = aVar;
                    return aVar;
                }
            }
        }
        try {
            a aVarM166j6 = m166j6(qGVar, (b) new QE(this));
            this.f117gn = aVarM166j6;
            return aVarM166j6;
        } catch (IOException e) {
            this.f117gn = a.IO_FAILURE;
            throw e;
        }
    }

    protected abstract a m188j6(String str);

    public void m189j6(KE ke) {
        this.f113FH = ke;
    }

    public void m190j6(YD yd) {
        this.f115VH = yd != null ? yd.J8() : null;
    }

    protected void m191j6(yE yEVar) {
        this.f116Zo = yEVar;
    }

    public void m192j6(String str, boolean z) {
        if (str == null && !z) {
            m171DW();
            return;
        }
        if (str == null && z) {
            this.f114Hw = "";
            this.f121v5 = true;
        } else {
            this.f114Hw = str;
            this.f121v5 = z;
        }
    }

    public void m193j6(boolean z) {
        this.f112DW = z;
    }

    public String m194tp() {
        return this.f114Hw;
    }

    public KE m195u7() {
        return this.f113FH;
    }

    public yE m196v5() {
        return this.f118j6;
    }

    public a m197we() {
        return this.f117gn;
    }
}
