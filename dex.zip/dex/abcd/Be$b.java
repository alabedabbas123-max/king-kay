package abcd;

@xu
public abstract class Be$b extends Be$f {

    @tu
    private static boolean f449Hw;

    @uu
    private static boolean f450v5;

    static {
        wu.j6(Be$b.class, -4143679928279952933L, -4143679928279952933L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$b(int i) {
        super(i);
        try {
            if (f449Hw) {
                wu.j6(270184301417492539L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f450v5) {
                wu.j6(th, 270184301417492539L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }
}
