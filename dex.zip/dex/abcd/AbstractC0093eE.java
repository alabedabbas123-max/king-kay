package abcd;

import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public abstract class AbstractC0093eE implements LE {

    static final Object f377DW;

    private static final ScheduledThreadPoolExecutor f378j6 = new ScheduledThreadPoolExecutor(1, new ThreadFactoryC0005cE());

    private long f379FH;

    private TimeUnit f380Hw = TimeUnit.MILLISECONDS;

    private a f381v5;

    private static class a implements Runnable {

        private final int f382DW;

        private volatile boolean f383FH = true;

        private Future<?> f384Hw;

        private int f385VH;

        private int f386Zo;

        private final String f387j6;

        private boolean f388v5;

        a(String str, int i) {
            this.f387j6 = str;
            this.f382DW = i;
        }

        private void m468j6() {
            this.f383FH = false;
            this.f384Hw = AbstractC0093eE.f378j6.schedule(this, 1L, TimeUnit.SECONDS);
        }

        void m469j6(long j, TimeUnit timeUnit) {
            this.f383FH = false;
            this.f384Hw = AbstractC0093eE.f378j6.schedule(this, j, timeUnit);
        }

        void m470j6(AbstractC0093eE abstractC0093eE) {
            if (this.f388v5) {
                int i = this.f382DW;
                if (i == 0) {
                    abstractC0093eE.m461DW(this.f387j6, this.f386Zo);
                } else {
                    int i2 = this.f386Zo;
                    abstractC0093eE.m467j6(this.f387j6, i2, i, (i2 * 100) / i);
                }
            }
            Future<?> future = this.f384Hw;
            if (future != null) {
                future.cancel(false);
            }
        }

        void m471j6(AbstractC0093eE abstractC0093eE, int i) {
            this.f386Zo += i;
            int i2 = this.f382DW;
            if (i2 == 0) {
                if (this.f383FH) {
                    abstractC0093eE.m463FH(this.f387j6, this.f386Zo);
                    this.f388v5 = true;
                    m468j6();
                    return;
                }
                return;
            }
            int i3 = (this.f386Zo * 100) / i2;
            if (this.f383FH) {
                abstractC0093eE.m462DW(this.f387j6, this.f386Zo, this.f382DW, i3);
                this.f388v5 = true;
                m468j6();
                this.f385VH = i3;
                return;
            }
            if (i3 != this.f385VH) {
                abstractC0093eE.m462DW(this.f387j6, this.f386Zo, this.f382DW, i3);
                this.f388v5 = true;
                this.f385VH = i3;
            }
        }

        @Override
        public void run() {
            this.f383FH = true;
        }
    }

    static {
        f378j6.setContinueExistingPeriodicTasksAfterShutdownPolicy(false);
        f378j6.setExecuteExistingDelayedTasksAfterShutdownPolicy(false);
        f378j6.prestartAllCoreThreads();
        f378j6.setThreadFactory(Executors.defaultThreadFactory());
        f377DW = new C0049dE();
    }

    protected abstract void m461DW(String str, int i);

    protected abstract void m462DW(String str, int i, int i2, int i3);

    protected abstract void m463FH(String str, int i);

    public boolean isCancelled() {
        return false;
    }

    public void m464j6() {
        a aVar = this.f381v5;
        if (aVar != null) {
            aVar.m470j6(this);
            this.f381v5 = null;
        }
    }

    public void m465j6(long j, TimeUnit timeUnit) {
        this.f379FH = j;
        this.f380Hw = timeUnit;
    }

    public void m466j6(String str, int i) {
        m464j6();
        this.f381v5 = new a(str, i);
        long j = this.f379FH;
        if (j != 0) {
            this.f381v5.m469j6(j, this.f380Hw);
        }
    }

    protected abstract void m467j6(String str, int i, int i2, int i3);

    public void start(int i) {
    }

    public void update(int i) {
        a aVar = this.f381v5;
        if (aVar != null) {
            aVar.m471j6(this, i);
        }
    }
}
