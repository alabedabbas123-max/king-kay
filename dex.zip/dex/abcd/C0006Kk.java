package abcd;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import com.aide.ui.U;

@xu
public class C0006Kk {

    @uu
    private static boolean f49DW;

    @tu
    private static boolean f50j6;

    static {
        wu.j6(C0006Kk.class, -495786187121037287L, -495786187121037287L);
    }

    public C0006Kk() {
        try {
            if (f50j6) {
                wu.j6(-1322339339664368060L, (Object) null);
            }
        } catch (Throwable th) {
            if (f49DW) {
                wu.j6(th, -1322339339664368060L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -2207084599969325960L)
    private void m69j6(Context context) {
        try {
            if (f50j6) {
                wu.j6(-1911362321980657488L, this, context);
            }
            m70j6(context, "engine", "Code Analysis Notifications", "Notifications showing error checking progress and statistics.", 2);
            m70j6(context, "other", "Other Notifications", "All other notifications.", 3);
        } catch (Throwable th) {
            if (f49DW) {
                wu.j6(th, -1911362321980657488L, this, context);
            }
            throw th;
        }
    }

    @su(method = 1445762437662561304L)
    private void m70j6(Context context, String str, String str2, String str3, int i) {
        try {
            if (f50j6) {
                wu.j6(-1405744868706864096L, this, context, str, str2, str3, new Integer(i));
            }
            if (Build.VERSION.SDK_INT < 26) {
                return;
            }
            NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
            NotificationChannel notificationChannel = new NotificationChannel(str, str2, i);
            notificationChannel.setDescription(str3);
            notificationManager.createNotificationChannel(notificationChannel);
        } catch (Throwable th) {
            if (f49DW) {
                wu.j6(th, -1405744868706864096L, this, context, str, str2, str3, new Integer(i));
            }
            throw th;
        }
    }

    public void m71j6() {
        try {
            if (f50j6) {
                wu.j6(2465520606808208779L, this);
            }
            m69j6(U.Zo());
        } catch (Throwable th) {
            if (f49DW) {
                wu.j6(th, 2465520606808208779L, this);
            }
            throw th;
        }
    }
}
