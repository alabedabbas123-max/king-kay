package abcd;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

abstract class AbstractC0114r<K, V> {

    r<K, V>.c f650DW;

    r<K, V>.e f651FH;

    r<K, V>.b f652j6;

    final class a<T> implements Iterator<T> {

        int f653DW;

        int f654FH;

        boolean f655Hw = false;

        final int f656j6;

        a(int i) {
            this.f656j6 = i;
            this.f653DW = AbstractC0114r.this.m607FH();
        }

        @Override
        public boolean hasNext() {
            return this.f654FH < this.f653DW;
        }

        @Override
        public T next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            T t = (T) AbstractC0114r.this.m611j6(this.f654FH, this.f656j6);
            this.f654FH++;
            this.f655Hw = true;
            return t;
        }

        @Override
        public void remove() {
            if (!this.f655Hw) {
                throw new IllegalStateException();
            }
            this.f654FH--;
            this.f653DW--;
            this.f655Hw = false;
            AbstractC0114r.this.m614j6(this.f654FH);
        }
    }

    final class b implements Set<Map.Entry<K, V>> {
        b() {
        }

        @Override
        public boolean add(Object obj) {
            m618j6((Map.Entry) obj);
            throw null;
        }

        @Override
        public boolean addAll(Collection<? extends Map.Entry<K, V>> collection) {
            int iM607FH = AbstractC0114r.this.m607FH();
            for (Map.Entry<K, V> entry : collection) {
                AbstractC0114r.this.m615j6(entry.getKey(), entry.getValue());
            }
            return iM607FH != AbstractC0114r.this.m607FH();
        }

        @Override
        public void clear() {
            AbstractC0114r.this.m613j6();
        }

        @Override
        public boolean contains(Object obj) {
            if (!(obj instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry) obj;
            int iM610j6 = AbstractC0114r.this.m610j6(entry.getKey());
            if (iM610j6 < 0) {
                return false;
            }
            return n.j6(AbstractC0114r.this.m611j6(iM610j6, 1), entry.getValue());
        }

        @Override
        public boolean containsAll(Collection<?> collection) {
            Iterator<?> it = collection.iterator();
            while (it.hasNext()) {
                if (!contains(it.next())) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public boolean equals(Object obj) {
            return AbstractC0114r.m603j6((Set) this, obj);
        }

        @Override
        public int hashCode() {
            int iHashCode = 0;
            for (int iM607FH = AbstractC0114r.this.m607FH() - 1; iM607FH >= 0; iM607FH--) {
                Object objM611j6 = AbstractC0114r.this.m611j6(iM607FH, 0);
                Object objM611j7 = AbstractC0114r.this.m611j6(iM607FH, 1);
                iHashCode += (objM611j6 == null ? 0 : objM611j6.hashCode()) ^ (objM611j7 == null ? 0 : objM611j7.hashCode());
            }
            return iHashCode;
        }

        @Override
        public boolean isEmpty() {
            return AbstractC0114r.this.m607FH() == 0;
        }

        @Override
        public Iterator<Map.Entry<K, V>> iterator() {
            return new d();
        }

        public boolean m618j6(Map.Entry<K, V> entry) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean remove(Object obj) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public int size() {
            return AbstractC0114r.this.m607FH();
        }

        @Override
        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        @Override
        public <T> T[] toArray(T[] tArr) {
            throw new UnsupportedOperationException();
        }
    }

    final class c implements Set<K> {
        c() {
        }

        @Override
        public boolean add(K k) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clear() {
            AbstractC0114r.this.m613j6();
        }

        @Override
        public boolean contains(Object obj) {
            return AbstractC0114r.this.m610j6(obj) >= 0;
        }

        @Override
        public boolean containsAll(Collection<?> collection) {
            return AbstractC0114r.m602j6((Map) AbstractC0114r.this.m605DW(), collection);
        }

        @Override
        public boolean equals(Object obj) {
            return AbstractC0114r.m603j6((Set) this, obj);
        }

        @Override
        public int hashCode() {
            int iHashCode = 0;
            for (int iM607FH = AbstractC0114r.this.m607FH() - 1; iM607FH >= 0; iM607FH--) {
                Object objM611j6 = AbstractC0114r.this.m611j6(iM607FH, 0);
                iHashCode += objM611j6 == null ? 0 : objM611j6.hashCode();
            }
            return iHashCode;
        }

        @Override
        public boolean isEmpty() {
            return AbstractC0114r.this.m607FH() == 0;
        }

        @Override
        public Iterator<K> iterator() {
            return new a(0);
        }

        @Override
        public boolean remove(Object obj) {
            int iM610j6 = AbstractC0114r.this.m610j6(obj);
            if (iM610j6 < 0) {
                return false;
            }
            AbstractC0114r.this.m614j6(iM610j6);
            return true;
        }

        @Override
        public boolean removeAll(Collection<?> collection) {
            return AbstractC0114r.m600DW(AbstractC0114r.this.m605DW(), collection);
        }

        @Override
        public boolean retainAll(Collection<?> collection) {
            return AbstractC0114r.m601FH(AbstractC0114r.this.m605DW(), collection);
        }

        @Override
        public int size() {
            return AbstractC0114r.this.m607FH();
        }

        @Override
        public Object[] toArray() {
            return AbstractC0114r.this.m606DW(0);
        }

        @Override
        public <T> T[] toArray(T[] tArr) {
            return (T[]) AbstractC0114r.this.m616j6(tArr, 0);
        }
    }

    final class d implements Iterator<Map.Entry<K, V>>, Map.Entry<K, V> {

        int f663j6;

        boolean f661FH = false;

        int f660DW = -1;

        d() {
            this.f663j6 = AbstractC0114r.this.m607FH() - 1;
        }

        @Override
        public final boolean equals(Object obj) {
            if (!this.f661FH) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            if (!(obj instanceof Map.Entry)) {
                return false;
            }
            Map.Entry entry = (Map.Entry) obj;
            return n.j6(entry.getKey(), AbstractC0114r.this.m611j6(this.f660DW, 0)) && n.j6(entry.getValue(), AbstractC0114r.this.m611j6(this.f660DW, 1));
        }

        @Override
        public K getKey() {
            if (this.f661FH) {
                return (K) AbstractC0114r.this.m611j6(this.f660DW, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        @Override
        public V getValue() {
            if (this.f661FH) {
                return (V) AbstractC0114r.this.m611j6(this.f660DW, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        @Override
        public boolean hasNext() {
            return this.f660DW < this.f663j6;
        }

        @Override
        public final int hashCode() {
            if (!this.f661FH) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            }
            Object objM611j6 = AbstractC0114r.this.m611j6(this.f660DW, 0);
            Object objM611j7 = AbstractC0114r.this.m611j6(this.f660DW, 1);
            return (objM611j6 == null ? 0 : objM611j6.hashCode()) ^ (objM611j7 != null ? objM611j7.hashCode() : 0);
        }

        @Override
        public Object next() {
            next();
            return this;
        }

        @Override
        public Map.Entry<K, V> next() {
            if (!hasNext()) {
                throw new NoSuchElementException();
            }
            this.f660DW++;
            this.f661FH = true;
            return this;
        }

        @Override
        public void remove() {
            if (!this.f661FH) {
                throw new IllegalStateException();
            }
            AbstractC0114r.this.m614j6(this.f660DW);
            this.f660DW--;
            this.f663j6--;
            this.f661FH = false;
        }

        @Override
        public V setValue(V v) {
            if (this.f661FH) {
                return (V) AbstractC0114r.this.m612j6(this.f660DW, v);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final String toString() {
            return getKey() + "=" + getValue();
        }
    }

    final class e implements Collection<V> {
        e() {
        }

        @Override
        public boolean add(V v) {
            throw new UnsupportedOperationException();
        }

        @Override
        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void clear() {
            AbstractC0114r.this.m613j6();
        }

        @Override
        public boolean contains(Object obj) {
            return AbstractC0114r.this.m604DW(obj) >= 0;
        }

        @Override
        public boolean containsAll(Collection<?> collection) {
            Iterator<?> it = collection.iterator();
            while (it.hasNext()) {
                if (!contains(it.next())) {
                    return false;
                }
            }
            return true;
        }

        @Override
        public boolean isEmpty() {
            return AbstractC0114r.this.m607FH() == 0;
        }

        @Override
        public Iterator<V> iterator() {
            return new a(1);
        }

        @Override
        public boolean remove(Object obj) {
            int iM604DW = AbstractC0114r.this.m604DW(obj);
            if (iM604DW < 0) {
                return false;
            }
            AbstractC0114r.this.m614j6(iM604DW);
            return true;
        }

        @Override
        public boolean removeAll(Collection<?> collection) {
            int iM607FH = AbstractC0114r.this.m607FH();
            int i = 0;
            boolean z = false;
            while (i < iM607FH) {
                if (collection.contains(AbstractC0114r.this.m611j6(i, 1))) {
                    AbstractC0114r.this.m614j6(i);
                    i--;
                    iM607FH--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        @Override
        public boolean retainAll(Collection<?> collection) {
            int iM607FH = AbstractC0114r.this.m607FH();
            int i = 0;
            boolean z = false;
            while (i < iM607FH) {
                if (!collection.contains(AbstractC0114r.this.m611j6(i, 1))) {
                    AbstractC0114r.this.m614j6(i);
                    i--;
                    iM607FH--;
                    z = true;
                }
                i++;
            }
            return z;
        }

        @Override
        public int size() {
            return AbstractC0114r.this.m607FH();
        }

        @Override
        public Object[] toArray() {
            return AbstractC0114r.this.m606DW(1);
        }

        @Override
        public <T> T[] toArray(T[] tArr) {
            return (T[]) AbstractC0114r.this.m616j6(tArr, 1);
        }
    }

    AbstractC0114r() {
    }

    public static <K, V> boolean m600DW(Map<K, V> map, Collection<?> collection) {
        int size = map.size();
        Iterator<?> it = collection.iterator();
        while (it.hasNext()) {
            map.remove(it.next());
        }
        return size != map.size();
    }

    public static <K, V> boolean m601FH(Map<K, V> map, Collection<?> collection) {
        int size = map.size();
        Iterator<K> it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return size != map.size();
    }

    public static <K, V> boolean m602j6(Map<K, V> map, Collection<?> collection) {
        Iterator<?> it = collection.iterator();
        while (it.hasNext()) {
            if (!map.containsKey(it.next())) {
                return false;
            }
        }
        return true;
    }

    public static <T> boolean m603j6(Set<T> set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set2 = (Set) obj;
            try {
                return set.size() == set2.size() && set.containsAll(set2);
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    protected abstract int m604DW(Object obj);

    protected abstract Map<K, V> m605DW();

    public Object[] m606DW(int i) {
        int iM607FH = m607FH();
        Object[] objArr = new Object[iM607FH];
        for (int i2 = 0; i2 < iM607FH; i2++) {
            objArr[i2] = m611j6(i2, i);
        }
        return objArr;
    }

    protected abstract int m607FH();

    public Set<Map.Entry<K, V>> m608Hw() {
        if (this.f652j6 == null) {
            this.f652j6 = new b();
        }
        return this.f652j6;
    }

    public Collection<V> m609Zo() {
        if (this.f651FH == null) {
            this.f651FH = new e();
        }
        return this.f651FH;
    }

    protected abstract int m610j6(Object obj);

    protected abstract Object m611j6(int i, int i2);

    protected abstract V m612j6(int i, V v);

    protected abstract void m613j6();

    protected abstract void m614j6(int i);

    protected abstract void m615j6(K k, V v);

    public <T> T[] m616j6(T[] tArr, int i) {
        int iM607FH = m607FH();
        if (tArr.length < iM607FH) {
            tArr = (T[]) ((Object[]) Array.newInstance(tArr.getClass().getComponentType(), iM607FH));
        }
        for (int i2 = 0; i2 < iM607FH; i2++) {
            tArr[i2] = m611j6(i2, i);
        }
        if (tArr.length > iM607FH) {
            tArr[iM607FH] = null;
        }
        return tArr;
    }

    public Set<K> m617v5() {
        if (this.f650DW == null) {
            this.f650DW = new c();
        }
        return this.f650DW;
    }
}
