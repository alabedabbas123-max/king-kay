package abcd;

@xu
public abstract class AbstractC0102nc {

    @ru(field = 3635854830533470211L)
    private static AbstractC0102nc f441DW;

    @tu
    private static boolean f442FH;

    @uu
    private static boolean f443Hw;

    @ru(field = -922319701128509175L)
    private static Object f444j6;

    @xu
    public class a extends Exception {
        static {
            wu.j6(a.class, 1236042494955155008L, 1236042494955155008L);
        }
    }

    public interface b {
        void m464j6(char[] cArr, int i, int i2);
    }

    public interface c {
        int m465end();

        void m466j6(b bVar);

        boolean m467j6();

        int start();
    }

    public interface d {
        c m468j6();
    }

    static {
        try {
            wu.j6(AbstractC0102nc.class, -220214977736913120L, -220214977736913120L);
            if (f442FH) {
                wu.j6(1895400739506206011L, (Object) null);
            }
            f444j6 = new Object();
        } catch (Throwable th) {
            if (f443Hw) {
                wu.j6(th, 1895400739506206011L, (Object) null);
            }
            throw th;
        }
    }

    public AbstractC0102nc() {
        try {
            if (f442FH) {
                wu.j6(-5050141221366318676L, (Object) null);
            }
        } catch (Throwable th) {
            if (f443Hw) {
                wu.j6(th, -5050141221366318676L, (Object) null);
            }
            throw th;
        }
    }

    public static AbstractC0102nc m460j6() {
        AbstractC0102nc abstractC0102nc;
        try {
            if (f442FH) {
                wu.j6(-1850313852432464160L, (Object) null);
            }
            synchronized (f444j6) {
                abstractC0102nc = f441DW;
            }
            return abstractC0102nc;
        } catch (Throwable th) {
            if (f443Hw) {
                wu.j6(th, -1850313852432464160L, (Object) null);
            }
            throw th;
        }
    }

    public abstract b m461DW();

    public abstract d m462DW(String str);

    public abstract d m463j6(String str);
}
