package abcd;

public class C0020UB extends NB {
    public C0020UB(String str) {
        super(str);
    }
}
