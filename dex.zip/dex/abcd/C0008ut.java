package abcd;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Iterator;

public class C0008ut {
    private static void m41DW(yt ytVar) {
        ArrayList arrayListDW = ytVar.DW();
        for (int size = arrayListDW.size() - 1; size >= 0; size--) {
            tt ttVar = (tt) arrayListDW.get(size);
            if (!ttVar.XL() && ttVar.VH().cardinality() > 1 && ((AbstractC0051vt) ttVar.FH().get(0)).m207J0()) {
                BitSet bitSet = (BitSet) ttVar.VH().clone();
                for (int iNextSetBit = bitSet.nextSetBit(0); iNextSetBit >= 0; iNextSetBit = bitSet.nextSetBit(iNextSetBit + 1)) {
                    ((tt) arrayListDW.get(iNextSetBit)).Hw(ttVar).FH().add(0, ((AbstractC0051vt) ttVar.FH().get(0)).m610clone());
                }
                ttVar.FH().remove(0);
            }
        }
    }

    private static void m42FH(yt ytVar) {
        ArrayList arrayListDW = ytVar.DW();
        for (int size = arrayListDW.size() - 1; size >= 0; size--) {
            tt ttVar = (tt) arrayListDW.get(size);
            if (m48j6(ttVar)) {
                ttVar.QX();
            }
        }
    }

    private static void m43Hw(yt ytVar) {
        ArrayList arrayListDW = ytVar.DW();
        for (int size = arrayListDW.size() - 1; size >= 0; size--) {
            tt ttVar = (tt) arrayListDW.get(size);
            BitSet bitSet = (BitSet) ttVar.Ws().clone();
            for (int iNextSetBit = bitSet.nextSetBit(0); iNextSetBit >= 0; iNextSetBit = bitSet.nextSetBit(iNextSetBit + 1)) {
                tt ttVar2 = (tt) arrayListDW.get(iNextSetBit);
                if (m49j6(ttVar, ttVar2)) {
                    ttVar.Hw(ttVar2);
                }
            }
        }
    }

    public static yt m44j6(fs fsVar, int i, boolean z) {
        yt ytVarJ6 = yt.j6(fsVar, i, z);
        m45j6(ytVarJ6);
        m47j6(ytVarJ6, ht.j6(ytVarJ6), 0);
        new Bt(ytVarJ6).run();
        ytVarJ6.EQ();
        return ytVarJ6;
    }

    private static void m45j6(yt ytVar) {
        m42FH(ytVar);
        m41DW(ytVar);
        m43Hw(ytVar);
    }

    public static void m46j6(yt ytVar, int i) {
        m47j6(ytVar, ht.j6(ytVar), i);
        new Bt(ytVar, i).run();
    }

    private static void m47j6(yt ytVar, it itVar, int i) {
        ArrayList arrayListDW = ytVar.DW();
        int size = arrayListDW.size();
        int iU7 = ytVar.u7() - i;
        Ys.a[] aVarArrJ6 = new Ys(ytVar).j6();
        BitSet[] bitSetArr = new BitSet[iU7];
        BitSet[] bitSetArr2 = new BitSet[iU7];
        for (int i2 = 0; i2 < iU7; i2++) {
            bitSetArr[i2] = new BitSet(size);
            bitSetArr2[i2] = new BitSet(size);
        }
        int size2 = arrayListDW.size();
        for (int i3 = 0; i3 < size2; i3++) {
            Iterator it = ((tt) arrayListDW.get(i3)).FH().iterator();
            while (it.hasNext()) {
                bs bsVarM219u7 = ((AbstractC0051vt) it.next()).m219u7();
                if (bsVarM219u7 != null && bsVarM219u7.we() - i >= 0) {
                    bitSetArr[bsVarM219u7.we() - i].set(i3);
                }
            }
        }
        for (int i4 = 0; i4 < iU7; i4++) {
            BitSet bitSet = (BitSet) bitSetArr[i4].clone();
            while (true) {
                int iNextSetBit = bitSet.nextSetBit(0);
                if (iNextSetBit >= 0) {
                    bitSet.clear(iNextSetBit);
                    _t it2 = aVarArrJ6[iNextSetBit].j6.iterator();
                    while (it2.hasNext()) {
                        int next = it2.next();
                        if (!bitSetArr2[i4].get(next)) {
                            bitSetArr2[i4].set(next);
                            int i5 = i4 + i;
                            bs bsVar = itVar.DW(next).get(i5);
                            if (bsVar == null) {
                                ((tt) arrayListDW.get(next)).FH(i5);
                            } else {
                                ((tt) arrayListDW.get(next)).j6(bsVar);
                            }
                            if (!bitSetArr[i4].get(next)) {
                                bitSet.set(next);
                            }
                        }
                    }
                }
            }
        }
    }

    private static boolean m48j6(tt ttVar) {
        return ttVar.VH().cardinality() > 1 && ttVar.Ws().cardinality() > 1;
    }

    private static boolean m49j6(tt ttVar, tt ttVar2) {
        ArrayList arrayListFH = ttVar.FH();
        AbstractC0051vt abstractC0051vt = (AbstractC0051vt) arrayListFH.get(arrayListFH.size() - 1);
        return (abstractC0051vt.m219u7() != null || abstractC0051vt.m218tp().size() > 0) && ttVar2.VH().cardinality() > 1;
    }
}
