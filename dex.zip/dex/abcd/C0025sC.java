package abcd;

import abcd.CC;
import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public class C0025sC<S extends CC> {

    public static final eC f60j6 = new rC();

    protected kC f61DW;

    protected mC<S> f62FH;

    protected lC<S> f63Hw;

    sC<S>.a f64Zo;

    protected lC<S> f65v5;

    class a {

        protected int f67FH;

        protected int f68Hw;

        protected jC f69VH;

        protected int f70Zo;

        protected int f73v5;

        sC<S>.a.b f72j6 = new c();

        sC<S>.a.b f66DW = new C0135a();

        class C0135a extends sC<S>.a.b {
            C0135a() {
                super();
            }

            final int m186DW(int i) {
                return i - 1;
            }

            final int m187FH(int i) {
                return i;
            }

            final int m188VH(int i, int i2) {
                int i3;
                while (true) {
                    a aVar = a.this;
                    if (i2 <= aVar.f67FH || (i3 = i + i2) <= aVar.f73v5 || !C0025sC.this.f62FH.j6(C0025sC.this.f63Hw, i2 - 1, C0025sC.this.f65v5, i3 - 1)) {
                        break;
                    }
                    i2--;
                }
                return i2;
            }

            final void m189j6(int i, int i2) {
                a aVar = a.this;
                if (i2 <= aVar.f67FH || i2 + i <= aVar.f73v5) {
                    if (i > a.this.f72j6.f84v5) {
                        this.f83u7 = i;
                    } else {
                        this.f80gn = i;
                    }
                }
            }

            final boolean m190j6(int i, int i2, int i3, long j) {
                sC<S>.a.b bVar = a.this.f72j6;
                if (i2 < bVar.f76FH || i2 > bVar.f77Hw || ((i + i2) - bVar.f84v5) % 2 != 0 || i3 > bVar.m198Hw(i, i2)) {
                    return false;
                }
                m206j6(a.this.f72j6.m197FH(i, i2), j);
                return true;
            }

            final boolean m191v5(int i, int i2) {
                return i < i2;
            }
        }

        abstract class b {

            int f76FH;

            int f77Hw;

            int f78VH;

            int f79Zo;

            int f80gn;

            int f83u7;

            int f84v5;

            private CK f81j6 = new CK();

            private DK f75DW = new DK();

            b() {
            }

            private int m192Hw(int i) {
                int i2 = this.f80gn;
                if (i < i2) {
                    return i2 + ((i ^ i2) & 1);
                }
                int i3 = this.f83u7;
                return i > i3 ? i3 - ((i ^ i3) & 1) : i;
            }

            abstract int m193DW(int i);

            final int m194DW(int i, int i2) {
                int i3 = i + i2;
                int i4 = this.f84v5;
                if ((i3 - i4) % 2 == 0) {
                    return (i3 - i4) / 2;
                }
                throw new RuntimeException(MessageFormat.format(JGitText.j6().unexpectedOddResult, Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(this.f84v5)));
            }

            final int m195DW(long j) {
                return (int) j;
            }

            abstract int m196FH(int i);

            final long m197FH(int i, int i2) {
                if (i2 < this.f76FH || i2 > this.f77Hw) {
                    throw new RuntimeException(MessageFormat.format(JGitText.j6().kNotInRange, Integer.valueOf(i2), Integer.valueOf(this.f76FH), Integer.valueOf(this.f77Hw)));
                }
                return this.f75DW.j6(m194DW(i, i2));
            }

            final int m198Hw(int i, int i2) {
                if (i2 < this.f76FH || i2 > this.f77Hw) {
                    throw new RuntimeException(MessageFormat.format(JGitText.j6().kNotInRange, Integer.valueOf(i2), Integer.valueOf(this.f76FH), Integer.valueOf(this.f77Hw)));
                }
                return this.f81j6.DW(m194DW(i, i2));
            }

            abstract int m199VH(int i, int i2);

            final long m200Zo(int i, int i2) {
                return (((long) i2) << 32) | ((long) (i + i2));
            }

            final int m201j6(long j) {
                return (int) (j >>> 32);
            }

            abstract void m202j6(int i, int i2);

            void m203j6(int i, int i2, int i3, int i4) {
                this.f80gn = i3;
                this.f83u7 = i4;
                this.f84v5 = i;
                this.f77Hw = i;
                this.f76FH = i;
                this.f81j6.j6();
                this.f81j6.j6(i2);
                this.f75DW.j6();
                this.f75DW.j6(m200Zo(i, i2));
            }

            boolean m204j6(int i) {
                long jM200Zo;
                int iM193DW;
                int iM196FH;
                this.f79Zo = this.f76FH;
                this.f78VH = this.f77Hw;
                this.f76FH = m192Hw(this.f84v5 - i);
                this.f77Hw = m192Hw(this.f84v5 + i);
                for (int i2 = this.f77Hw; i2 >= this.f76FH; i2 -= 2) {
                    long j = -1;
                    if (i2 > this.f79Zo) {
                        int i3 = i2 - 1;
                        int iM194DW = m194DW(i - 1, i3);
                        int iDW = this.f81j6.DW(iM194DW);
                        int iM199VH = m199VH(i3, iDW);
                        jM200Zo = iDW != iM199VH ? m200Zo(i3, iM199VH) : this.f75DW.j6(iM194DW);
                        if (m205j6(i, i3, iM199VH, jM200Zo)) {
                            return true;
                        }
                        iM193DW = m193DW(iM199VH);
                    } else {
                        jM200Zo = -1;
                        iM193DW = -1;
                    }
                    if (i2 < this.f78VH) {
                        int i4 = i2 + 1;
                        int iM194DW2 = m194DW(i - 1, i4);
                        int iDW2 = this.f81j6.DW(iM194DW2);
                        int iM199VH2 = m199VH(i4, iDW2);
                        long jM200Zo2 = iDW2 != iM199VH2 ? m200Zo(i4, iM199VH2) : this.f75DW.j6(iM194DW2);
                        if (m205j6(i, i4, iM199VH2, jM200Zo2)) {
                            return true;
                        }
                        iM196FH = m196FH(iM199VH2);
                        j = jM200Zo2;
                    } else {
                        iM196FH = -1;
                    }
                    if (i2 < this.f78VH && (i2 <= this.f79Zo || !m207v5(iM193DW, iM196FH))) {
                        iM193DW = iM196FH;
                        jM200Zo = j;
                    }
                    if (m205j6(i, i2, iM193DW, jM200Zo)) {
                        return true;
                    }
                    m202j6(i2, iM193DW);
                    int iM194DW3 = m194DW(i, i2);
                    this.f81j6.DW(iM194DW3, iM193DW);
                    this.f75DW.j6(iM194DW3, jM200Zo);
                }
                return false;
            }

            abstract boolean m205j6(int i, int i2, int i3, long j);

            final boolean m206j6(long j, long j2) {
                int iM201j6 = m201j6(j);
                int iM201j7 = m201j6(j2);
                int iM195DW = m195DW(j);
                int iM195DW2 = m195DW(j2);
                if (iM201j6 > iM201j7 || iM195DW > iM195DW2) {
                    iM195DW = iM195DW2;
                    iM201j6 = iM201j7;
                }
                a.this.f69VH = new jC(iM201j6, iM201j7, iM195DW, iM195DW2);
                return true;
            }

            abstract boolean m207v5(int i, int i2);
        }

        class c extends sC<S>.a.b {
            c() {
                super();
            }

            final int m208DW(int i) {
                return i;
            }

            final int m209FH(int i) {
                return i + 1;
            }

            final int m210VH(int i, int i2) {
                int i3;
                while (true) {
                    a aVar = a.this;
                    if (i2 >= aVar.f68Hw || (i3 = i + i2) >= aVar.f70Zo || !C0025sC.this.f62FH.j6(C0025sC.this.f63Hw, i2, C0025sC.this.f65v5, i3)) {
                        break;
                    }
                    i2++;
                }
                return i2;
            }

            final void m211j6(int i, int i2) {
                a aVar = a.this;
                if (i2 >= aVar.f68Hw || i2 + i >= aVar.f70Zo) {
                    if (i > a.this.f66DW.f84v5) {
                        this.f83u7 = i;
                    } else {
                        this.f80gn = i;
                    }
                }
            }

            final boolean m212j6(int i, int i2, int i3, long j) {
                sC<S>.a.b bVar = a.this.f66DW;
                if (i2 < bVar.f76FH || i2 > bVar.f77Hw) {
                    return false;
                }
                int i4 = i - 1;
                if (((i4 + i2) - bVar.f84v5) % 2 != 0 || i3 < bVar.m198Hw(i4, i2)) {
                    return false;
                }
                m206j6(j, a.this.f66DW.m197FH(i4, i2));
                return true;
            }

            final boolean m213v5(int i, int i2) {
                return i > i2;
            }
        }

        a() {
        }

        void m184DW(int i, int i2, int i3, int i4) {
            this.f67FH = i;
            this.f68Hw = i2;
            this.f73v5 = i3;
            this.f70Zo = i4;
            int i5 = i3 - i;
            this.f67FH = this.f72j6.m199VH(i5, i);
            this.f73v5 = i5 + this.f67FH;
            int i6 = i4 - i2;
            this.f68Hw = this.f66DW.m199VH(i6, i2);
            this.f70Zo = i6 + this.f68Hw;
        }

        jC m185j6(int i, int i2, int i3, int i4) {
            if (i == i2 || i3 == i4) {
                return new jC(i, i2, i3, i4);
            }
            this.f67FH = i;
            this.f68Hw = i2;
            this.f73v5 = i3;
            this.f70Zo = i4;
            int i5 = i3 - i2;
            int i6 = i4 - i;
            this.f72j6.m203j6(i3 - i, i, i5, i6);
            this.f66DW.m203j6(i4 - i2, i2, i5, i6);
            for (int i7 = 1; !this.f72j6.m204j6(i7) && !this.f66DW.m204j6(i7); i7++) {
            }
            return this.f69VH;
        }
    }

    private C0025sC(kC kCVar, mC<S> mCVar, lC<S> lCVar, lC<S> lCVar2, jC jCVar) {
        this.f64Zo = new a();
        this.f61DW = kCVar;
        this.f62FH = mCVar;
        this.f63Hw = lCVar;
        this.f65v5 = lCVar2;
        m181j6(jCVar);
    }

    C0025sC(kC kCVar, mC mCVar, lC lCVar, lC lCVar2, jC jCVar, C0025sC c0025sC) {
        this(kCVar, mCVar, lCVar, lCVar2, jCVar);
    }

    private void m181j6(jC jCVar) {
        this.f64Zo.m184DW(jCVar.j6, jCVar.DW, jCVar.FH, jCVar.Hw);
        sC<S>.a aVar = this.f64Zo;
        if (aVar.f67FH < aVar.f68Hw || aVar.f73v5 < aVar.f70Zo) {
            sC<S>.a aVar2 = this.f64Zo;
            m182j6(aVar2.f67FH, aVar2.f68Hw, aVar2.f73v5, aVar2.f70Zo);
        }
    }

    protected void m182j6(int i, int i2, int i3, int i4) {
        jC jCVarM185j6 = this.f64Zo.m185j6(i, i2, i3, i4);
        if (i < jCVarM185j6.j6 || i3 < jCVarM185j6.FH) {
            int i5 = jCVarM185j6.FH;
            int i6 = jCVarM185j6.j6;
            int i7 = i5 - i6;
            int iM199VH = this.f64Zo.f66DW.m199VH(i7, i6);
            m182j6(i, iM199VH, i3, i7 + iM199VH);
        }
        if (jCVarM185j6.gn() != jC.a.Hw) {
            kC kCVar = this.f61DW;
            kCVar.add(kCVar.size(), jCVarM185j6);
        }
        if (i2 > jCVarM185j6.DW || i4 > jCVarM185j6.Hw) {
            int i8 = jCVarM185j6.Hw;
            int i9 = jCVarM185j6.DW;
            int i10 = i8 - i9;
            int iM199VH2 = this.f64Zo.f72j6.m199VH(i10, i9);
            m182j6(iM199VH2, i2, i10 + iM199VH2, i4);
        }
    }
}
