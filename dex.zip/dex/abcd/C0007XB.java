package abcd;

import org.eclipse.jgit.JGitText;

public class C0007XB extends NB {
    public C0007XB() {
        super(JGitText.j6().notMergedExceptionMessage);
    }
}
