package abcd;

enum C0012Kq extends er {
    C0012Kq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
