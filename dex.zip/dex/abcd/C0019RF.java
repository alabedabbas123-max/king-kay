package abcd;

final class C0019RF extends XF {

    private final UF f134DW = new UF();

    private int f135FH;

    private final XF f136j6;

    C0019RF(XF xf) {
        this.f136j6 = xf;
    }

    int m199DW() {
        return this.f136j6.DW();
    }

    dG m200j6() {
        dG dGVarJ6;
        while (this.f135FH < 6 && (dGVarJ6 = this.f136j6.j6()) != null) {
            this.f134DW.j6(dGVarJ6);
            this.f135FH++;
        }
        dG dGVarJ7 = this.f134DW.j6();
        if (dGVarJ7 == null) {
            return null;
        }
        this.f135FH--;
        return dGVarJ7;
    }
}
