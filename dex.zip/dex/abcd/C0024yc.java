package abcd;

@xu
public class C0024yc {

    @ru(field = 1851604470520814949L)
    private static Object f79DW;

    @tu
    private static boolean f80FH;

    @uu
    private static boolean f81Hw;

    @ru(field = 1863575866833605661L)
    private static long f82j6;

    static {
        try {
            wu.j6(C0024yc.class, -431451251040535232L, -431451251040535232L);
            if (f80FH) {
                wu.j6(1505740036645125567L, (Object) null);
            }
            f79DW = new Object();
            xc xcVar = new xc("Time getter");
            xcVar.setPriority(1);
            xcVar.start();
        } catch (Throwable th) {
            if (f81Hw) {
                wu.j6(th, 1505740036645125567L, (Object) null);
            }
            throw th;
        }
    }

    public C0024yc() {
        try {
            if (f80FH) {
                wu.j6(-3510476266293760201L, (Object) null);
            }
        } catch (Throwable th) {
            if (f81Hw) {
                wu.j6(th, -3510476266293760201L, (Object) null);
            }
            throw th;
        }
    }

    public static long m104DW() {
        long j;
        try {
            if (f80FH) {
                wu.j6(-668219584164888381L, (Object) null);
            }
            synchronized (f79DW) {
                j = f82j6;
            }
            return j;
        } catch (Throwable th) {
            if (f81Hw) {
                wu.j6(th, -668219584164888381L, (Object) null);
            }
            throw th;
        }
    }
}
