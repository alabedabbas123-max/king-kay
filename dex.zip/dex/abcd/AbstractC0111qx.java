package abcd;

import android.content.Context;
import android.os.IBinder;
import com.google.android.gms.common.f;

public abstract class AbstractC0111qx<T> {

    private T f642DW;

    private final String f643j6;

    public static class a extends Exception {
        public a(String str) {
            super(str);
        }

        public a(String str, Throwable th) {
            super(str, th);
        }
    }

    protected AbstractC0111qx(String str) {
        this.f643j6 = str;
    }

    protected final T m577j6(Context context) throws a {
        if (this.f642DW == null) {
            com.google.android.gms.common.internal.r.j6(context);
            Context remoteContext = f.getRemoteContext(context);
            if (remoteContext == null) {
                throw new a("Could not get remote context.");
            }
            try {
                this.f642DW = m578j6((IBinder) remoteContext.getClassLoader().loadClass(this.f643j6).newInstance());
            } catch (ClassNotFoundException e) {
                throw new a("Could not load creator class.", e);
            } catch (IllegalAccessException e2) {
                throw new a("Could not access creator.", e2);
            } catch (InstantiationException e3) {
                throw new a("Could not instantiate creator.", e3);
            }
        }
        return this.f642DW;
    }

    protected abstract T m578j6(IBinder iBinder);
}
