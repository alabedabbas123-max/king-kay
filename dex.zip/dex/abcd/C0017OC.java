package abcd;

import java.util.Comparator;

class C0017OC implements Comparator<C0060PC.b> {
    C0017OC() {
    }

    @Override
    public int compare(C0060PC.b bVar, C0060PC.b bVar2) {
        byte[] bArr = bVar.f292j6;
        byte[] bArr2 = bVar2.f292j6;
        return KC.j6(bArr, bArr.length, bArr2, bArr2.length);
    }
}
