package abcd;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.SequenceInputStream;
import java.util.Date;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

public class C0025IA implements Cloneable {

    private static tA f168DW;

    private static byte[] f169j6 = new byte[4];

    private int f170EQ;

    private LA f171FH;

    private short f172Hw;

    private String f173J0;

    private byte[] f174J8;

    private int f175Mr;

    private String f176QX;

    private long f177U2;

    private short f178VH;

    private short f179Ws;

    private short f180XL;

    private short f181Zo;

    private byte[] f182a8;

    private short f183aM;

    private short f184gn;

    private int f185j3;

    private C0110KA f186lg;

    private int f187tp;

    private short f188u7;

    private short f189v5;

    private int f190we;

    public C0025IA(LA la) {
        this.f179Ws = (short) 0;
        this.f177U2 = -1L;
        this.f182a8 = null;
        this.f186lg = null;
        this.f171FH = la;
    }

    public C0025IA(String str) {
        this.f179Ws = (short) 0;
        this.f177U2 = -1L;
        this.f182a8 = null;
        this.f186lg = null;
        this.f173J0 = str;
        this.f176QX = "";
        this.f178VH = (short) 8;
        this.f174J8 = new byte[0];
        m312j6(System.currentTimeMillis());
    }

    private void m296DW(LA la) {
        boolean zIsDebugEnabled = m298tp().isDebugEnabled();
        this.f172Hw = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Version made by: 0x%04x", Short.valueOf(this.f172Hw)));
        }
        this.f189v5 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Version required: 0x%04x", Short.valueOf(this.f189v5)));
        }
        this.f181Zo = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("General purpose bits: 0x%04x", Short.valueOf(this.f181Zo)));
        }
        if ((this.f181Zo & 63473) != 0) {
            throw new IllegalStateException("Can't handle general purpose bits == " + String.format("0x%04x", Short.valueOf(this.f181Zo)));
        }
        this.f178VH = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Compression: 0x%04x", Short.valueOf(this.f178VH)));
        }
        this.f184gn = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Modification time: 0x%04x", Short.valueOf(this.f184gn)));
        }
        this.f188u7 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Modification date: 0x%04x", Short.valueOf(this.f188u7)));
        }
        this.f187tp = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("CRC-32: 0x%04x", Integer.valueOf(this.f187tp)));
        }
        this.f170EQ = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Compressed size: 0x%04x", Integer.valueOf(this.f170EQ)));
        }
        this.f190we = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Size: 0x%04x", Integer.valueOf(this.f190we)));
        }
        short sHw = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("File name length: 0x%04x", Short.valueOf(sHw)));
        }
        short sHw2 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Extra length: 0x%04x", Short.valueOf(sHw2)));
        }
        short sHw3 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("File comment length: 0x%04x", Short.valueOf(sHw3)));
        }
        this.f180XL = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Disk number start: 0x%04x", Short.valueOf(this.f180XL)));
        }
        this.f183aM = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Internal attributes: 0x%04x", Short.valueOf(this.f183aM)));
        }
        this.f185j3 = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("External attributes: 0x%08x", Integer.valueOf(this.f185j3)));
        }
        this.f175Mr = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Local header offset: 0x%08x", Integer.valueOf(this.f175Mr)));
        }
        this.f173J0 = la.DW(sHw);
        if (zIsDebugEnabled) {
            f168DW.FH("Filename: " + this.f173J0);
        }
        this.f174J8 = la.j6(sHw2);
        this.f176QX = la.DW(sHw3);
        if (zIsDebugEnabled) {
            f168DW.FH("File comment: " + this.f176QX);
        }
        this.f181Zo = (short) (this.f181Zo & 2048);
        if (this.f190we == 0) {
            this.f170EQ = 0;
            this.f178VH = (short) 0;
            this.f187tp = 0;
        }
    }

    public static C0025IA m297j6(LA la) {
        if (la.FH() != 33639248) {
            la.j6(la.DW() - 4);
            return null;
        }
        C0025IA c0025ia = new C0025IA(la);
        c0025ia.m296DW(la);
        return c0025ia;
    }

    public static tA m298tp() {
        if (f168DW == null) {
            f168DW = uA.j6(C0025IA.class.getName());
        }
        return f168DW;
    }

    public short m299DW() {
        return this.f178VH;
    }

    public void m300DW(NA na) throws IOException {
        short sDW;
        long j = 0;
        if (this.f182a8 == null && this.f177U2 < 0 && this.f171FH != null) {
            m304Mr();
        }
        this.f175Mr = na.DW();
        boolean zIsDebugEnabled = m298tp().isDebugEnabled();
        if (zIsDebugEnabled) {
            m298tp().FH(String.format("Writing local header at 0x%08x - %s", Integer.valueOf(this.f175Mr), this.f173J0));
        }
        C0110KA c0110ka = this.f186lg;
        if (c0110ka != null) {
            c0110ka.close();
            this.f190we = this.f186lg.m1005DW();
            this.f182a8 = ((ByteArrayOutputStream) this.f186lg.m1006FH()).toByteArray();
            this.f170EQ = this.f182a8.length;
            this.f187tp = this.f186lg.m1007j6();
        }
        na.j6(67324752);
        na.j6(this.f189v5);
        na.j6(this.f181Zo);
        na.j6(this.f178VH);
        na.j6(this.f184gn);
        na.j6(this.f188u7);
        na.j6(this.f187tp);
        na.j6(this.f170EQ);
        na.j6(this.f190we);
        na.j6((short) this.f173J0.length());
        this.f179Ws = (short) 0;
        if (this.f178VH == 0 && (sDW = (short) (((long) (((na.DW() + 2) + this.f173J0.length()) + this.f174J8.length)) % 4)) > 0) {
            this.f179Ws = (short) (4 - sDW);
        }
        na.j6((short) (this.f174J8.length + this.f179Ws));
        na.j6(this.f173J0);
        na.j6(this.f174J8);
        short s = this.f179Ws;
        if (s > 0) {
            na.j6(f169j6, 0, s);
        }
        if (zIsDebugEnabled) {
            m298tp().FH(String.format("Data position 0x%08x", Integer.valueOf(na.DW())));
        }
        byte[] bArr = this.f182a8;
        if (bArr != null) {
            na.j6(bArr);
            if (zIsDebugEnabled) {
                m298tp().FH(String.format("Wrote %d bytes", Integer.valueOf(this.f182a8.length)));
                return;
            }
            return;
        }
        if (zIsDebugEnabled) {
            m298tp().FH(String.format("Seeking to position 0x%08x", Long.valueOf(this.f177U2)));
        }
        this.f171FH.j6(this.f177U2);
        int iMin = Math.min(this.f170EQ, 8096);
        byte[] bArr2 = new byte[iMin];
        while (true) {
            int i = this.f170EQ;
            if (j == i) {
                return;
            }
            int i2 = this.f171FH.FH.read(bArr2, 0, (int) Math.min(((long) i) - j, iMin));
            if (i2 <= 0) {
                throw new IllegalStateException(String.format("EOF reached while copying %s with %d bytes left to go", this.f173J0, Long.valueOf(((long) this.f170EQ) - j)));
            }
            na.j6(bArr2, 0, i2);
            if (zIsDebugEnabled) {
                m298tp().FH(String.format("Wrote %d bytes", Integer.valueOf(i2)));
            }
            j += (long) i2;
        }
    }

    public String m301EQ() {
        return this.f173J0;
    }

    public int m302FH() {
        return this.f187tp;
    }

    public OutputStream m303J0() {
        this.f186lg = new C0110KA(this.f178VH, new ByteArrayOutputStream());
        return this.f186lg;
    }

    public void m304Mr() {
        LA la = this.f171FH;
        boolean zIsDebugEnabled = m298tp().isDebugEnabled();
        la.j6(this.f175Mr);
        if (zIsDebugEnabled) {
            m298tp().FH(String.format("FILE POSITION: 0x%08x", Long.valueOf(la.DW())));
        }
        if (la.FH() != 67324752) {
            throw new IllegalStateException(String.format("Local header not found at pos=0x%08x, file=%s", Long.valueOf(la.DW()), this.f173J0));
        }
        short sHw = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Version required: 0x%04x", Short.valueOf(sHw)));
        }
        short sHw2 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("General purpose bits: 0x%04x", Short.valueOf(sHw2)));
        }
        short sHw3 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Compression: 0x%04x", Short.valueOf(sHw3)));
        }
        short sHw4 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Modification time: 0x%04x", Short.valueOf(sHw4)));
        }
        short sHw5 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Modification date: 0x%04x", Short.valueOf(sHw5)));
        }
        int iFH = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("CRC-32: 0x%04x", Integer.valueOf(iFH)));
        }
        int iFH2 = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Compressed size: 0x%04x", Integer.valueOf(iFH2)));
        }
        int iFH3 = la.FH();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Size: 0x%04x", Integer.valueOf(iFH3)));
        }
        short sHw6 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("File name length: 0x%04x", Short.valueOf(sHw6)));
        }
        short sHw7 = la.Hw();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Extra length: 0x%04x", Short.valueOf(sHw7)));
        }
        String strDW = la.DW(sHw6);
        if (zIsDebugEnabled) {
            f168DW.FH("Filename: " + strDW);
        }
        la.j6(sHw7);
        this.f177U2 = la.DW();
        if (zIsDebugEnabled) {
            f168DW.FH(String.format("Data position: 0x%08x", Long.valueOf(this.f177U2)));
        }
    }

    public int m305QX() {
        return this.f190we;
    }

    public long m306XL() {
        short s = this.f188u7;
        int i = ((s >> 9) & 127) + 80;
        int i2 = ((s >> 5) & 15) - 1;
        int i3 = s & 31;
        short s2 = this.f184gn;
        return new Date(i, i2, i3, (s2 >> 11) & 31, (s2 >> 5) & 63, (s2 << 1) & 62).getTime();
    }

    public LA m307aM() {
        return this.f171FH;
    }

    public long m308gn() {
        return this.f177U2;
    }

    public boolean m309j3() {
        return this.f173J0.endsWith("/");
    }

    public int m310j6() {
        return this.f170EQ;
    }

    public InputStream m311j6(OutputStream outputStream) throws IOException {
        C0110KA c0110ka = this.f186lg;
        if (c0110ka == null) {
            C0067JA c0067ja = new C0067JA(this);
            if (outputStream != null) {
                c0067ja.m668j6(outputStream);
            }
            if (this.f178VH == 0) {
                return c0067ja;
            }
            c0067ja.m669j6(true);
            return new InflaterInputStream(c0067ja, new Inflater(true));
        }
        c0110ka.close();
        this.f190we = this.f186lg.m1005DW();
        this.f182a8 = ((ByteArrayOutputStream) this.f186lg.m1006FH()).toByteArray();
        this.f170EQ = this.f182a8.length;
        this.f187tp = this.f186lg.m1007j6();
        this.f186lg = null;
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.f182a8);
        return this.f178VH == 0 ? byteArrayInputStream : new InflaterInputStream(new SequenceInputStream(byteArrayInputStream, new ByteArrayInputStream(new byte[1])), new Inflater(true));
    }

    public void m312j6(long j) {
        Date date = new Date(j);
        int year = date.getYear() + 1900;
        long month = year < 1980 ? 2162688L : ((year - 1980) << 25) | ((date.getMonth() + 1) << 21) | (date.getDate() << 16) | (date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1);
        this.f188u7 = (short) (month >> 16);
        this.f184gn = (short) (65535 & month);
    }

    public void m313j6(NA na) {
        m298tp().isDebugEnabled();
        na.j6(33639248);
        na.j6(this.f172Hw);
        na.j6(this.f189v5);
        na.j6(this.f181Zo);
        na.j6(this.f178VH);
        na.j6(this.f184gn);
        na.j6(this.f188u7);
        na.j6(this.f187tp);
        na.j6(this.f170EQ);
        na.j6(this.f190we);
        na.j6((short) this.f173J0.length());
        na.j6((short) (this.f174J8.length + this.f179Ws));
        na.j6((short) this.f176QX.length());
        na.j6(this.f180XL);
        na.j6(this.f183aM);
        na.j6(this.f185j3);
        na.j6(this.f175Mr);
        na.j6(this.f173J0);
        na.j6(this.f174J8);
        short s = this.f179Ws;
        if (s > 0) {
            na.j6(f169j6, 0, s);
        }
        na.j6(this.f176QX);
    }

    public InputStream m314u7() {
        return m311j6((OutputStream) null);
    }

    public byte[] m315v5() throws IOException {
        byte[] bArr = this.f182a8;
        if (bArr != null) {
            return bArr;
        }
        byte[] bArr2 = new byte[this.f190we];
        InputStream inputStreamM314u7 = m314u7();
        int i = 0;
        while (true) {
            int i2 = this.f190we;
            if (i == i2) {
                return bArr2;
            }
            int i3 = inputStreamM314u7.read(bArr2, i, i2 - i);
            if (i3 < 0) {
                throw new IllegalStateException(String.format("Read failed, expecting %d bytes, got %d instead", Integer.valueOf(this.f190we), Integer.valueOf(i)));
            }
            i += i3;
        }
    }
}
