package abcd;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

public final class C0021Kz {
    public static final SSLSocketFactory m131j6(InterfaceC0063Lz interfaceC0063Lz) throws NoSuchAlgorithmException, KeyManagementException {
        SSLContext sSLContext = SSLContext.getInstance("TLS");
        sSLContext.init(null, new TrustManager[]{new C0106Mz(new Nz(interfaceC0063Lz.m324DW(), interfaceC0063Lz.m327j6()), interfaceC0063Lz)}, null);
        return sSLContext.getSocketFactory();
    }
}
