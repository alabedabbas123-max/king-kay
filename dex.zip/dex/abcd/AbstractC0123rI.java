package abcd;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

abstract class AbstractC0123rI {

    static final AbstractC0123rI f682j6 = new c(null);

    private static class a extends AbstractC0123rI {

        private String f683DW;

        private String f684FH;

        private a() {
        }

        a(a aVar) {
            this();
        }

        @Override
        void mo635j6(String str, String str2) {
            this.f683DW = str;
            this.f684FH = str2;
        }

        @Override
        void mo636j6(HttpURLConnection httpURLConnection) {
            String strJ6 = kK.j6((String.valueOf(this.f683DW) + ":" + this.f684FH).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder("Basic ");
            sb.append(strJ6);
            httpURLConnection.setRequestProperty("Authorization", sb.toString());
        }
    }

    private static class b extends AbstractC0123rI {

        private static final Random f685DW = new Random();

        private static final char[] f686FH = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

        private final Map<String, String> f687Hw;

        private String f688VH;

        private String f689Zo;

        private int f690v5;

        b(String str) {
            this.f687Hw = m639DW(str);
            if ("auth".equals(this.f687Hw.get("qop"))) {
                byte[] bArr = new byte[8];
                f685DW.nextBytes(bArr);
                this.f687Hw.put("cnonce", kK.j6(bArr));
            }
        }

        private static String m638DW(String str, String str2) {
            try {
                MessageDigest messageDigestM643j6 = m643j6();
                messageDigestM643j6.update(str.getBytes("UTF-8"));
                messageDigestM643j6.update((byte) 58);
                messageDigestM643j6.update(str2.getBytes("UTF-8"));
                return m642j6(messageDigestM643j6.digest());
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException("UTF-8 encoding not available", e);
            }
        }

        private static Map<String, String> m639DW(String str) {
            int i;
            int i2;
            String strSubstring;
            HashMap map = new HashMap();
            int i3 = 0;
            while (i3 < str.length()) {
                if (i3 < str.length() && str.charAt(i3) == ',') {
                    i3++;
                }
                while (i3 < str.length() && Character.isWhitespace(str.charAt(i3))) {
                    i3++;
                }
                int iIndexOf = str.indexOf(61, i3);
                if (iIndexOf < 0 || (i = iIndexOf + 1) == str.length()) {
                    return Collections.emptyMap();
                }
                String strSubstring2 = str.substring(i3, iIndexOf);
                if (str.charAt(i) == '\"') {
                    int i4 = iIndexOf + 2;
                    int iIndexOf2 = str.indexOf(34, i4);
                    if (iIndexOf2 < 0) {
                        return Collections.emptyMap();
                    }
                    strSubstring = str.substring(i4, iIndexOf2);
                    i2 = iIndexOf2 + 1;
                } else {
                    int iIndexOf3 = str.indexOf(32, i);
                    int iIndexOf4 = str.indexOf(44, i);
                    if (iIndexOf3 < 0) {
                        iIndexOf3 = str.length();
                    }
                    if (iIndexOf4 < 0) {
                        iIndexOf4 = str.length();
                    }
                    int iMin = Math.min(iIndexOf3, iIndexOf4);
                    i2 = iMin + 1;
                    strSubstring = str.substring(i, iMin);
                }
                map.put(strSubstring2, strSubstring);
                i3 = i2;
            }
            return map;
        }

        private static String m640j6(String str) {
            try {
                MessageDigest messageDigestM643j6 = m643j6();
                messageDigestM643j6.update(str.getBytes("UTF-8"));
                return m642j6(messageDigestM643j6.digest());
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException("UTF-8 encoding not available", e);
            }
        }

        private static String m641j6(URL url) {
            StringBuilder sb = new StringBuilder();
            sb.append(url.getProtocol());
            sb.append("://");
            sb.append(url.getHost());
            if (url.getPort() > 0 && ((url.getPort() != 80 || !"http".equals(url.getProtocol())) && (url.getPort() != 443 || !"https".equals(url.getProtocol())))) {
                sb.append(':');
                sb.append(url.getPort());
            }
            sb.append(url.getPath());
            if (url.getQuery() != null) {
                sb.append('?');
                sb.append(url.getQuery());
            }
            return sb.toString();
        }

        private static String m642j6(byte[] bArr) {
            StringBuilder sb = new StringBuilder(bArr.length * 2);
            for (byte b : bArr) {
                sb.append(f686FH[(b >>> 4) & 15]);
                sb.append(f686FH[b & 15]);
            }
            return sb.toString();
        }

        private static MessageDigest m643j6() {
            try {
                return MessageDigest.getInstance("MD5");
            } catch (NoSuchAlgorithmException e) {
                throw new RuntimeException("No MD5 available", e);
            }
        }

        @Override
        void mo635j6(String str, String str2) {
            this.f689Zo = str;
            this.f688VH = str2;
        }

        @Override
        void mo636j6(HttpURLConnection httpURLConnection) {
            String str;
            String strM638DW;
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            String str2 = this.f687Hw.get("realm");
            String str3 = this.f687Hw.get("nonce");
            String str4 = this.f687Hw.get("cnonce");
            String strM641j6 = m641j6(httpURLConnection.getURL());
            String str5 = this.f687Hw.get("qop");
            String requestMethod = httpURLConnection.getRequestMethod();
            String str6 = String.valueOf(this.f689Zo) + ":" + str2 + ":" + this.f688VH;
            String str7 = String.valueOf(requestMethod) + ":" + strM641j6;
            linkedHashMap.put("username", this.f689Zo);
            linkedHashMap.put("realm", str2);
            linkedHashMap.put("nonce", str3);
            linkedHashMap.put("uri", strM641j6);
            if ("auth".equals(str5)) {
                int i = this.f690v5 + 1;
                this.f690v5 = i;
                str = String.format("%08x", Integer.valueOf(i));
                strM638DW = m638DW(m640j6(str6), String.valueOf(str3) + ":" + str + ":" + str4 + ":" + str5 + ":" + m640j6(str7));
            } else {
                str = null;
                strM638DW = m638DW(m640j6(str6), String.valueOf(str3) + ":" + m640j6(str7));
            }
            linkedHashMap.put("response", strM638DW);
            if (this.f687Hw.containsKey("algorithm")) {
                linkedHashMap.put("algorithm", "MD5");
            }
            if (str4 != null && str5 != null) {
                linkedHashMap.put("cnonce", str4);
            }
            if (this.f687Hw.containsKey("opaque")) {
                linkedHashMap.put("opaque", this.f687Hw.get("opaque"));
            }
            if (str5 != null) {
                linkedHashMap.put("qop", str5);
            }
            if (str != null) {
                linkedHashMap.put("nc", str);
            }
            StringBuilder sb = new StringBuilder();
            for (Map.Entry entry : linkedHashMap.entrySet()) {
                if (sb.length() > 0) {
                    sb.append(", ");
                }
                sb.append((String) entry.getKey());
                sb.append('=');
                sb.append('\"');
                sb.append((String) entry.getValue());
                sb.append('\"');
            }
            httpURLConnection.setRequestProperty("Authorization", "Digest " + ((Object) sb));
        }
    }

    private static class c extends AbstractC0123rI {
        private c() {
        }

        c(c cVar) {
            this();
        }

        @Override
        void mo635j6(String str, String str2) {
        }

        @Override
        void mo636j6(HttpURLConnection httpURLConnection) {
        }
    }

    AbstractC0123rI() {
    }

    static AbstractC0123rI m634DW(HttpURLConnection httpURLConnection) {
        String headerField = httpURLConnection.getHeaderField("WWW-Authenticate");
        if (headerField == null || headerField.length() == 0) {
            return f682j6;
        }
        int iIndexOf = headerField.indexOf(32);
        if (iIndexOf < 0) {
            return f682j6;
        }
        String strSubstring = headerField.substring(0, iIndexOf);
        if ("Basic".equalsIgnoreCase(strSubstring)) {
            return new a(null);
        }
        return "Digest".equalsIgnoreCase(strSubstring) ? new b(headerField.substring(iIndexOf + 1)) : f682j6;
    }

    abstract void mo635j6(String str, String str2);

    abstract void mo636j6(HttpURLConnection httpURLConnection);

    boolean m637j6(HJ hj, kI kIVar) {
        String strFH;
        String strDW;
        if (kIVar != null) {
            jI eVar = new jI.e();
            jI cVar = new jI.c();
            if (!kIVar.j6(new jI[]{eVar, cVar}) || !kIVar.j6(hj, new jI[]{eVar, cVar})) {
                return false;
            }
            strDW = eVar.DW();
            strFH = new String(cVar.FH());
            cVar.DW();
        } else {
            String strGn = hj.gn();
            strFH = hj.FH();
            strDW = strGn;
        }
        if (strDW == null) {
            return false;
        }
        mo635j6(strDW, strFH);
        return true;
    }
}
