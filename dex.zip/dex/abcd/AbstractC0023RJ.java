package abcd;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import org.eclipse.jgit.JGitText;

abstract class AbstractC0023RJ {

    static final class a {

        final long f138DW;

        final InputStream f139j6;

        a(InputStream inputStream, long j) {
            this.f139j6 = inputStream;
            this.f138DW = j;
        }

        byte[] m222j6() throws IOException {
            byte[] byteArray;
            try {
                if (this.f138DW >= 0) {
                    byteArray = new byte[(int) this.f138DW];
                    BK.j6(this.f139j6, byteArray, 0, byteArray.length);
                } else {
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] bArr = new byte[2048];
                    while (true) {
                        int i = this.f139j6.read(bArr);
                        if (i < 0) {
                            break;
                        }
                        byteArrayOutputStream.write(bArr, 0, i);
                    }
                    byteArray = byteArrayOutputStream.toByteArray();
                }
                return byteArray;
            } finally {
                this.f139j6.close();
            }
        }
    }

    AbstractC0023RJ() {
    }

    private void m205j6(Map<String, ME> map, BufferedReader bufferedReader) throws IOException, yD {
        BE.a aVar = null;
        boolean zContains = false;
        while (true) {
            String line = bufferedReader.readLine();
            if (line == null) {
                return;
            }
            if (line.charAt(0) == '#') {
                if (line.startsWith("# pack-refs with:")) {
                    zContains = line.substring(17).contains(" peeled");
                }
            } else if (line.charAt(0) != '^') {
                int iIndexOf = line.indexOf(32);
                if (iIndexOf < 0) {
                    throw new yD(MessageFormat.format(JGitText.j6().unrecognizedRef, line));
                }
                yE yEVarJ6 = yE.j6(line.substring(0, iIndexOf));
                String strSubstring = line.substring(iIndexOf + 1);
                aVar = zContains ? new BE.a(ME.a.FH, strSubstring, yEVarJ6) : new BE.c(ME.a.FH, strSubstring, yEVarJ6);
                map.put(aVar.getName(), aVar);
            } else {
                if (aVar == null) {
                    throw new yD(JGitText.j6().peeledLineBeforeRef);
                }
                BE.a bVar = new BE.b(ME.a.FH, aVar.getName(), aVar.DW(), yE.j6(line.substring(1)));
                map.put(bVar.getName(), bVar);
                aVar = bVar;
            }
        }
    }

    abstract Collection<AbstractC0023RJ> m206DW();

    void m207DW(String str) throws IOException {
        m216j6("../" + str);
    }

    abstract Collection<String> m208FH();

    void m209FH(String str) throws IOException {
        m216j6("../logs/" + str);
    }

    abstract HJ m210Hw();

    abstract a m211Hw(String str);

    Collection<AbstractC0023RJ> m212VH(String str) throws IOException {
        BufferedReader bufferedReaderM213Zo = m213Zo(str);
        try {
            ArrayList arrayList = new ArrayList();
            while (true) {
                String line = bufferedReaderM213Zo.readLine();
                if (line == null) {
                    return arrayList;
                }
                if (!line.endsWith("/")) {
                    line = String.valueOf(line) + "/";
                }
                arrayList.add(m221v5(line));
            }
        } finally {
            bufferedReaderM213Zo.close();
        }
    }

    BufferedReader m213Zo(String str) {
        return new BufferedReader(new InputStreamReader(m211Hw(str).f139j6, hE.Zo));
    }

    OutputStream m214j6(String str, LE le, String str2) throws IOException {
        throw new IOException(MessageFormat.format(JGitText.j6().writingNotSupported, str));
    }

    abstract void m215j6();

    void m216j6(String str) throws IOException {
        throw new IOException(MessageFormat.format(JGitText.j6().deletingNotSupported, str));
    }

    void m217j6(String str, yE yEVar) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(41);
        yEVar.DW(byteArrayOutputStream);
        byteArrayOutputStream.write(10);
        m218j6("../" + str, byteArrayOutputStream.toByteArray());
    }

    void m218j6(String str, byte[] bArr) throws IOException {
        OutputStream outputStreamM214j6 = m214j6(str, null, null);
        try {
            outputStreamM214j6.write(bArr);
        } finally {
            outputStreamM214j6.close();
        }
    }

    void m219j6(Collection<String> collection) throws IOException {
        StringBuilder sb = new StringBuilder();
        for (String str : collection) {
            sb.append("P ");
            sb.append(str);
            sb.append('\n');
        }
        m218j6("info/packs", hE.DW(sb.toString()));
    }

    protected void m220j6(Map<String, ME> map) throws yD {
        try {
            BufferedReader bufferedReaderM213Zo = m213Zo("../packed-refs");
            try {
                m205j6(map, bufferedReaderM213Zo);
            } finally {
                bufferedReaderM213Zo.close();
            }
        } catch (FileNotFoundException unused) {
        } catch (IOException e) {
            throw new yD(m210Hw(), JGitText.j6().errorInPackedRefs, e);
        }
    }

    abstract AbstractC0023RJ m221v5(String str);
}
