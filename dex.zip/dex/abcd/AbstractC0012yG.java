package abcd;

import org.eclipse.jgit.JGitText;

public abstract class AbstractC0012yG {

    public static final AbstractC0012yG f22j6 = new a(null);

    public static final AbstractC0012yG f19DW = new d(0 == true ? 1 : 0);

    public static final AbstractC0012yG f20FH = new c(0 == true ? 1 : 0);

    public static final AbstractC0012yG f21Hw = new b(0 == true ? 1 : 0);

    private static final class a extends AbstractC0012yG {
        private a() {
        }

        a(a aVar) {
            this();
        }

        @Override
        public AbstractC0012yG m600clone() {
            return this;
        }

        @Override
        public boolean mo40j6() {
            return false;
        }

        @Override
        public boolean mo41j6(qG qGVar, dG dGVar) {
            return true;
        }

        @Override
        public String toString() {
            return "ALL";
        }
    }

    private static final class b extends AbstractC0012yG {
        private b() {
        }

        b(b bVar) {
            this();
        }

        @Override
        public AbstractC0012yG m600clone() {
            return this;
        }

        @Override
        public boolean mo40j6() {
            return false;
        }

        @Override
        public boolean mo41j6(qG qGVar, dG dGVar) {
            throw new UnsupportedOperationException(JGitText.j6().cannotBeCombined);
        }

        @Override
        public String toString() {
            return "MERGE_BASE";
        }
    }

    private static final class c extends AbstractC0012yG {
        private c() {
        }

        c(c cVar) {
            this();
        }

        @Override
        public AbstractC0012yG m600clone() {
            return this;
        }

        @Override
        public boolean mo40j6() {
            return false;
        }

        @Override
        public boolean mo41j6(qG qGVar, dG dGVar) {
            return dGVar.lg() < 2;
        }

        @Override
        public String toString() {
            return "NO_MERGES";
        }
    }

    private static final class d extends AbstractC0012yG {
        private d() {
        }

        d(d dVar) {
            this();
        }

        @Override
        public AbstractC0012yG m600clone() {
            return this;
        }

        @Override
        public boolean mo40j6() {
            return false;
        }

        @Override
        public boolean mo41j6(qG qGVar, dG dGVar) {
            return false;
        }

        @Override
        public String toString() {
            return "NONE";
        }
    }

    public abstract AbstractC0012yG m600clone();

    public boolean mo40j6() {
        return true;
    }

    public abstract boolean mo41j6(qG qGVar, dG dGVar);

    public String toString() {
        String name = getClass().getName();
        int iLastIndexOf = name.lastIndexOf(46);
        if (iLastIndexOf >= 0) {
            name = name.substring(iLastIndexOf + 1);
        }
        return name.replace('$', '.');
    }
}
