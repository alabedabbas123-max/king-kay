package abcd;

public abstract class AbstractC0106qs extends Fs {

    private final Os f621FH;

    private Os f622Hw;

    AbstractC0106qs(Ks ks, Hs hs) {
        super(ks, hs);
        this.f621FH = Os.j6(we().VH().we());
        this.f622Hw = null;
    }

    protected final int m550DW(ms msVar) {
        int iDW = super.DW(msVar);
        return iDW != 0 ? iDW : this.f621FH.j6(((AbstractC0106qs) msVar).f621FH);
    }

    public final Os m551DW(boolean z) {
        if (z) {
            return this.f621FH;
        }
        if (this.f622Hw == null) {
            this.f622Hw = this.f621FH.j6(VH().VH());
        }
        return this.f622Hw;
    }

    public final Os m552J8() {
        return this.f621FH;
    }

    public final boolean m553Ws() {
        return we().Ws();
    }

    public final Qs getType() {
        return this.f621FH.we();
    }

    public final int m554j6(boolean z) {
        return m551DW(z).VH().rN();
    }

    public final boolean m555lg() {
        return we().lg();
    }
}
