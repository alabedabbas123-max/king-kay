package abcd;

import java.io.File;
import java.util.Collections;
import java.util.Set;
import org.eclipse.jgit.JGitText;

class C0015yJ extends DJ {
    C0015yJ() {
    }

    public jJ m64DW(HJ hj, UE ue, String str) throws hD {
        File fileJ6 = ue.gn().j6(new File("."), hj.Hw());
        if (fileJ6.isFile()) {
            return new oJ(ue, hj, fileJ6);
        }
        File fileHw = WE.a.Hw(fileJ6, ue.gn());
        if (fileHw != null) {
            return new C0058zJ(ue, hj, fileHw);
        }
        throw new hD(hj, JGitText.j6().notFound);
    }

    public String m65DW() {
        return JGitText.j6().transportProtoLocal;
    }

    public boolean m66j6(HJ hj, UE ue, String str) {
        if (hj.Hw() != null && hj.v5() <= 0 && hj.gn() == null && hj.FH() == null && hj.j6() == null) {
            return hj.VH() == null || m67v5().contains(hj.VH());
        }
        return false;
    }

    public Set<String> m67v5() {
        return Collections.singleton("file");
    }
}
