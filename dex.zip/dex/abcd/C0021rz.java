package abcd;

public class C0021rz {

    private final nz f48DW;

    private final qz f49FH;

    private final int f50j6;

    public C0021rz(int i, nz nzVar, qz qzVar) {
        this.f50j6 = i;
        this.f48DW = nzVar;
        this.f49FH = qzVar;
    }

    public C0021rz(nz nzVar, qz qzVar) {
        this(0, nzVar, qzVar);
    }

    public C0021rz m174DW() {
        return new C0021rz(this.f48DW, this.f49FH);
    }

    public C0021rz m175FH() {
        return new C0021rz(this.f50j6 + 1, this.f48DW, this.f49FH);
    }

    public long m176j6() {
        return this.f48DW.j6(this.f50j6);
    }
}
