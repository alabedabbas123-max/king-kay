package abcd;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.List;

public class C0015fE {

    private String f90EQ;

    private yE f91VH;

    private KE f93tp;

    private KE f94u7;

    private static final yE[] f88j6 = new yE[0];

    private static final byte[] f84DW = C0103hE.m524DW("tree");

    private static final byte[] f85FH = C0103hE.m524DW("parent");

    private static final byte[] f86Hw = C0103hE.m524DW("author");

    private static final byte[] f89v5 = C0103hE.m524DW("committer");

    private static final byte[] f87Zo = C0103hE.m524DW("encoding");

    private yE[] f92gn = f88j6;

    private Charset f95we = C0103hE.f569Zo;

    public KE m42DW() {
        return this.f94u7;
    }

    public void m43DW(KE ke) {
        this.f93tp = ke;
    }

    public KE m44FH() {
        return this.f93tp;
    }

    public Charset m45Hw() {
        return this.f95we;
    }

    public yE m46VH() {
        return this.f91VH;
    }

    public yE[] m47Zo() {
        return this.f92gn;
    }

    public void m48j6(KE ke) {
        this.f94u7 = ke;
    }

    public void m49j6(YD yd) {
        this.f91VH = yd.Hw();
    }

    public void m50j6(String str) {
        this.f90EQ = str;
    }

    public void m51j6(List<? extends YD> list) {
        this.f92gn = new yE[list.size()];
        for (int i = 0; i < list.size(); i++) {
            this.f92gn[i] = list.get(i).Hw();
        }
    }

    public byte[] m52j6() {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(byteArrayOutputStream, m45Hw());
        try {
            byteArrayOutputStream.write(f84DW);
            byteArrayOutputStream.write(32);
            m46VH().DW(byteArrayOutputStream);
            byteArrayOutputStream.write(10);
            for (YD yd : m47Zo()) {
                byteArrayOutputStream.write(f85FH);
                byteArrayOutputStream.write(32);
                yd.DW(byteArrayOutputStream);
                byteArrayOutputStream.write(10);
            }
            byteArrayOutputStream.write(f86Hw);
            byteArrayOutputStream.write(32);
            outputStreamWriter.write(m42DW().Hw());
            outputStreamWriter.flush();
            byteArrayOutputStream.write(10);
            byteArrayOutputStream.write(f89v5);
            byteArrayOutputStream.write(32);
            outputStreamWriter.write(m44FH().Hw());
            outputStreamWriter.flush();
            byteArrayOutputStream.write(10);
            if (m45Hw() != C0103hE.f569Zo) {
                byteArrayOutputStream.write(f87Zo);
                byteArrayOutputStream.write(32);
                byteArrayOutputStream.write(C0103hE.m524DW(m45Hw().name()));
                byteArrayOutputStream.write(10);
            }
            byteArrayOutputStream.write(10);
            if (m53v5() != null) {
                outputStreamWriter.write(m53v5());
                outputStreamWriter.flush();
            }
            return byteArrayOutputStream.toByteArray();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Commit");
        sb.append("={\n");
        sb.append("tree ");
        yE yEVar = this.f91VH;
        sb.append(yEVar != null ? yEVar.we() : "NOT_SET");
        sb.append("\n");
        for (YD yd : this.f92gn) {
            sb.append("parent ");
            sb.append(yd.we());
            sb.append("\n");
        }
        sb.append("author ");
        KE ke = this.f94u7;
        sb.append(ke != null ? ke.toString() : "NOT_SET");
        sb.append("\n");
        sb.append("committer ");
        KE ke2 = this.f93tp;
        sb.append(ke2 != null ? ke2.toString() : "NOT_SET");
        sb.append("\n");
        Charset charset = this.f95we;
        if (charset != null && charset != C0103hE.f569Zo) {
            sb.append("encoding ");
            sb.append(this.f95we.name());
            sb.append("\n");
        }
        sb.append("\n");
        String str = this.f90EQ;
        if (str == null) {
            str = "";
        }
        sb.append(str);
        sb.append("}");
        return sb.toString();
    }

    public String m53v5() {
        return this.f90EQ;
    }
}
