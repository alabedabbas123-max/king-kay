package abcd;

public final class C0003Np extends up implements Comparable {

    private final Js f9DW;

    private Mp f10FH;

    public C0003Np(Js js) {
        if (js == null) {
            throw new NullPointerException("value == null");
        }
        this.f9DW = js;
        this.f10FH = null;
    }

    public wp m27Hw() {
        return wp.DW;
    }

    public int m28VH() {
        return 4;
    }

    public Js m29aM() {
        return this.f9DW;
    }

    @Override
    public int compareTo(Object obj) {
        return this.f9DW.j6(((C0003Np) obj).f9DW);
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0003Np) {
            return this.f9DW.equals(((C0003Np) obj).f9DW);
        }
        return false;
    }

    public int hashCode() {
        return this.f9DW.hashCode();
    }

    public void m30j6(jp jpVar) {
        if (this.f10FH == null) {
            Fp fpJ0 = jpVar.J0();
            this.f10FH = new Mp(this.f9DW);
            fpJ0.j6(this.f10FH);
        }
    }

    public void m31j6(jp jpVar, Lt lt) {
        int iWe = this.f10FH.we();
        if (lt.Hw()) {
            lt.j6(0, Ws() + ' ' + this.f9DW.j6(100));
            StringBuilder sb = new StringBuilder();
            sb.append("  string_data_off: ");
            sb.append(Yt.gn(iWe));
            lt.j6(4, sb.toString());
        }
        lt.writeInt(iWe);
    }
}
