package abcd;

import abcd.dB;

public abstract class AbstractC0071GB<C extends dB, T> extends dB<T> {

    protected kI f382FH;

    protected int f383Hw;

    protected InterfaceC0114HB f384v5;

    protected AbstractC0071GB(UE ue) {
        super(ue);
    }

    protected final C m675FH() {
        return this;
    }

    public C m676j6(int i) {
        this.f383Hw = i;
        m675FH();
        return this;
    }

    protected C m677j6(AbstractC0071GB abstractC0071GB) {
        abstractC0071GB.m680j6(this.f382FH);
        abstractC0071GB.m676j6(this.f383Hw);
        abstractC0071GB.m678j6(this.f384v5);
        m675FH();
        return this;
    }

    public C m678j6(InterfaceC0114HB interfaceC0114HB) {
        this.f384v5 = interfaceC0114HB;
        m675FH();
        return this;
    }

    protected C m679j6(jJ jJVar) {
        kI kIVar = this.f382FH;
        if (kIVar != null) {
            jJVar.j6(kIVar);
        }
        jJVar.j6(this.f383Hw);
        InterfaceC0114HB interfaceC0114HB = this.f384v5;
        if (interfaceC0114HB != null) {
            interfaceC0114HB.m1020j6(jJVar);
        }
        m675FH();
        return this;
    }

    public C m680j6(kI kIVar) {
        this.f382FH = kIVar;
        m675FH();
        return this;
    }
}
