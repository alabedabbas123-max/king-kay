package abcd;

import java.util.BitSet;

public final class C0002Qo extends ao {

    public static final ao f10DW = new C0002Qo();

    private C0002Qo() {
    }

    public BitSet m23FH(Vn vn) {
        cs csVarGn = vn.gn();
        BitSet bitSet = new BitSet(1);
        bitSet.set(0, ao.Hw(csVarGn.get(0).we()));
        return bitSet;
    }

    public boolean m24VH(Vn vn) {
        cs csVarGn = vn.gn();
        if ((vn instanceof Tn) && csVarGn.size() == 1 && ao.Hw(csVarGn.get(0).we())) {
            return ((Tn) vn).we() instanceof Cs;
        }
        return false;
    }

    public String m25Zo(Vn vn) {
        return vn.gn().get(0).lg() + ", " + ao.j6(((Tn) vn).we());
    }

    public int m26j6() {
        return 5;
    }

    public String m27j6(Vn vn, boolean z) {
        return ao.j6(((Tn) vn).we(), 64);
    }

    public void m28j6(Lt lt, Vn vn) {
        cs csVarGn = vn.gn();
        ao.j6(lt, ao.j6(vn, csVarGn.get(0).we()), ((Tn) vn).we().lg());
    }
}
