package abcd;

import java.util.Comparator;

class C0021RH implements Comparator<MH> {

    final C0107TH f137j6;

    C0021RH(C0107TH c0107th) {
        this.f137j6 = c0107th;
    }

    @Override
    public int compare(MH mh, MH mh2) {
        int i = (mh.vy() ? 1 : 0) - (mh2.vy() ? 1 : 0);
        if (i != 0) {
            return i;
        }
        int iYS = mh.yS() - mh2.yS();
        if (iYS != 0) {
            return iYS;
        }
        int iEr = (mh.er() >>> 1) - (mh2.er() >>> 1);
        if (iEr != 0) {
            return iEr;
        }
        int iEr2 = (mh.er() & 1) - (mh2.er() & 1);
        if (iEr2 != 0) {
            return iEr2;
        }
        int i2 = (!mh.P8() ? 1 : 0) - (!mh2.P8() ? 1 : 0);
        return i2 != 0 ? i2 : mh2.gW() - mh.gW();
    }
}
