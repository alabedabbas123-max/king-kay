package abcd;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.Iterator;

public class C0015rt {

    private int f34DW;

    private int[] f35FH;

    private ms[] f36Hw;

    private BitSet f37VH;

    private ArrayList<C0100tt> f38Zo;

    private ArrayList<vt> f39gn;

    private yt f40j6;

    private ArrayList<vt> f41tp;

    private ArrayList<vt> f42u7;

    private ArrayList<C0100tt> f43v5;

    private C0015rt(yt ytVar) {
        this.f40j6 = ytVar;
        this.f34DW = ytVar.u7();
        int i = this.f34DW;
        this.f35FH = new int[i];
        this.f36Hw = new ms[i];
        this.f43v5 = new ArrayList<>();
        this.f38Zo = new ArrayList<>();
        this.f37VH = new BitSet(ytVar.DW().size());
        this.f39gn = new ArrayList<>();
        this.f42u7 = new ArrayList<>();
        this.f41tp = new ArrayList<>();
        for (int i2 = 0; i2 < this.f34DW; i2++) {
            this.f35FH[i2] = 0;
            this.f36Hw[i2] = null;
        }
    }

    private void m144DW() {
        for (int i = 0; i < this.f34DW; i++) {
            if (this.f35FH[i] == 1 && (this.f36Hw[i] instanceof Ms)) {
                vt vtVarFH = this.f40j6.FH(i);
                if (!vtVarFH.u7().J8().a8()) {
                    vtVarFH.j6(vtVarFH.u7().j6(this.f36Hw[i]));
                    for (mt mtVar : this.f40j6.Hw(i)) {
                        if (!mtVar.XL()) {
                            mt mtVar2 = mtVar;
                            cs csVarTp = mtVar.tp();
                            int iHw = csVarTp.Hw(i);
                            mtVar2.j6(iHw, csVarTp.get(iHw).j6(this.f36Hw[i]));
                        }
                    }
                }
            }
        }
    }

    private void m145DW(C0100tt c0100tt) {
        for (vt vtVar : c0100tt.m642FH()) {
            if (vtVar instanceof ot) {
                m152j6((ot) vtVar);
            } else {
                m146DW(vtVar);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:35:0x009f A[PHI: r6
      0x009f: PHI (r6v3 abcd.ms) = (r6v0 abcd.ms), (r6v0 abcd.ms), (r6v6 abcd.ms), (r6v0 abcd.ms) binds: [B:33:0x0088, B:29:0x0070, B:26:0x0069, B:23:0x005d] A[DONT_GENERATE, DONT_INLINE]] */
    private void m146DW(vt vtVar) {
        Pr prGn = vtVar.gn();
        int i = 1;
        if (prGn.v5().DW() != 1 || prGn.v5().VH()) {
            m154j6(vtVar);
        }
        int iHw = vtVar.v5().Hw();
        bs bsVarU7 = vtVar.u7();
        if (bsVarU7 == null) {
            if (iHw != 17 && iHw != 18) {
                return;
            } else {
                bsVarU7 = vtVar.DW().m657gn().m642FH().get(0).u7();
            }
        }
        int iWe = bsVarU7.we();
        ms msVarTp = null;
        if (iHw != 2) {
            if (iHw == 5) {
                msVarTp = prGn.tp();
            } else if (iHw != 56) {
                switch (iHw) {
                    default:
                        switch (iHw) {
                            case 20:
                            case 21:
                            case 22:
                            case 23:
                            case 24:
                            case 25:
                                break;
                            default:
                                i = 2;
                                break;
                        }
                    case 14:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                        msVarTp = m149j6(vtVar, bsVarU7.j3());
                        if (msVarTp == null) {
                            i = 2;
                        }
                        break;
                }
            } else {
                int[] iArr = this.f35FH;
                if (iArr[iWe] == 1) {
                    i = iArr[iWe];
                    msVarTp = this.f36Hw[iWe];
                } else {
                    i = 2;
                }
            }
        } else if (vtVar.tp().size() == 1) {
            int iWe2 = vtVar.tp().get(0).we();
            i = this.f35FH[iWe2];
            msVarTp = this.f36Hw[iWe2];
        } else {
            i = 2;
        }
        if (m156j6(iWe, i, msVarTp)) {
            m151j6(iWe, i);
        }
    }

    private void m147FH() {
        m153j6(this.f40j6.Hw());
        while (true) {
            if (this.f43v5.isEmpty() && this.f38Zo.isEmpty() && this.f39gn.isEmpty() && this.f42u7.isEmpty()) {
                m144DW();
                m150j6();
                return;
            }
            while (!this.f43v5.isEmpty()) {
                m145DW(this.f43v5.remove(this.f43v5.size() - 1));
            }
            while (!this.f38Zo.isEmpty()) {
                m148FH(this.f38Zo.remove(this.f38Zo.size() - 1));
            }
            while (!this.f42u7.isEmpty()) {
                vt vtVarRemove = this.f42u7.remove(this.f42u7.size() - 1);
                if (this.f37VH.get(vtVarRemove.DW().m636DW())) {
                    if (vtVarRemove instanceof ot) {
                        m152j6((ot) vtVarRemove);
                    } else {
                        m146DW(vtVarRemove);
                    }
                }
            }
            while (!this.f39gn.isEmpty()) {
                vt vtVarRemove2 = this.f39gn.remove(this.f39gn.size() - 1);
                if (this.f37VH.get(vtVarRemove2.DW().m636DW())) {
                    if (vtVarRemove2 instanceof ot) {
                        m152j6((ot) vtVarRemove2);
                    } else {
                        m146DW(vtVarRemove2);
                    }
                }
            }
        }
    }

    private void m148FH(C0100tt c0100tt) {
        for (vt vtVar : c0100tt.m642FH()) {
            if (!(vtVar instanceof ot)) {
                return;
            } else {
                m152j6((ot) vtVar);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:33:0x0082  */
    /* JADX WARN: Code duplicated, block: B:43:0x009c  */
    /* JADX WARN: Code duplicated, block: B:47:? A[RETURN, SYNTHETIC] */
    private ms m149j6(vt vtVar, int i) {
        ms msVarTp;
        int i2;
        Pr prGn = vtVar.gn();
        int iHw = vtVar.v5().Hw();
        cs csVarTp = vtVar.tp();
        boolean z = false;
        int iWe = csVarTp.get(0).we();
        ys ysVar = this.f35FH[iWe] != 1 ? null : this.f36Hw[iWe];
        if (csVarTp.size() == 1) {
            msVarTp = prGn.tp();
        } else {
            int iWe2 = csVarTp.get(1).we();
            msVarTp = this.f35FH[iWe2] != 1 ? null : this.f36Hw[iWe2];
        }
        if (ysVar == null || msVarTp == null || i != 6) {
            return null;
        }
        int iRN = ysVar.rN();
        int iRN2 = ((ys) msVarTp).rN();
        switch (iHw) {
            case 14:
                i2 = iRN + iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 15:
                i2 = csVarTp.size() == 1 ? iRN2 - iRN : iRN - iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 16:
                i2 = iRN * iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 17:
                if (iRN2 == 0) {
                    i2 = 0;
                    z = true;
                } else {
                    i2 = iRN / iRN2;
                }
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 18:
                if (iRN2 == 0) {
                    i2 = 0;
                    z = true;
                } else {
                    i2 = iRN % iRN2;
                }
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 19:
            default:
                throw new RuntimeException("Unexpected op");
            case 20:
                i2 = iRN & iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 21:
                i2 = iRN | iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 22:
                i2 = iRN ^ iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 23:
                i2 = iRN << iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 24:
                i2 = iRN >> iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
            case 25:
                i2 = iRN >>> iRN2;
                if (z) {
                    return null;
                }
                return ys.j6(i2);
        }
    }

    private void m150j6() {
        for (vt vtVar : this.f41tp) {
            C0100tt c0100ttDW = vtVar.DW();
            int size = c0100ttDW.m649J8().size();
            int i = -1;
            for (int i2 = 0; i2 < size; i2++) {
                int i3 = c0100ttDW.m649J8().get(i2);
                if (!this.f37VH.get(i3)) {
                    i = i3;
                }
            }
            if (size == 2 && i != -1) {
                c0100ttDW.m638DW((Tr) new Zr(gs.j3, vtVar.gn().Zo(), (bs) null, cs.FH));
                c0100ttDW.m647Hw(i);
            }
        }
    }

    private void m151j6(int i, int i2) {
        if (i2 == 2) {
            Iterator it = this.f40j6.Hw(i).iterator();
            while (it.hasNext()) {
                this.f42u7.add((vt) it.next());
            }
            return;
        }
        Iterator it2 = this.f40j6.Hw(i).iterator();
        while (it2.hasNext()) {
            this.f39gn.add((vt) it2.next());
        }
    }

    private void m152j6(ot otVar) {
        int iWe = otVar.u7().we();
        int i = 2;
        if (this.f35FH[iWe] == 2) {
            return;
        }
        cs csVarTp = otVar.tp();
        ms msVar = null;
        int size = csVarTp.size();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= size) {
                i = i3;
                break;
            }
            int iFH = otVar.FH(i2);
            int iWe2 = csVarTp.get(i2).we();
            int i4 = this.f35FH[iWe2];
            if (this.f37VH.get(iFH)) {
                if (i4 != 1) {
                    i = i4;
                    break;
                } else if (msVar == null) {
                    msVar = this.f36Hw[iWe2];
                    i3 = 1;
                } else if (!this.f36Hw[iWe2].equals(msVar)) {
                    break;
                }
            }
            i2++;
        }
        if (m156j6(iWe, i, msVar)) {
            m151j6(iWe, i);
        }
    }

    private void m153j6(C0100tt c0100tt) {
        if (this.f37VH.get(c0100tt.m636DW())) {
            this.f38Zo.add(c0100tt);
        } else {
            this.f43v5.add(c0100tt);
            this.f37VH.set(c0100tt.m636DW());
        }
    }

    /* JADX WARN: Code duplicated, block: B:60:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:61:0x00c4  */
    /* JADX WARN: Code duplicated, block: B:63:0x00c8  */
    private void m154j6(vt vtVar) {
        boolean z;
        boolean z2;
        boolean z3;
        es esVarV5 = vtVar.v5();
        cs csVarTp = vtVar.tp();
        if (esVarV5.DW() == 4) {
            bs bsVar = csVarTp.get(0);
            int iWe = bsVar.we();
            ms msVar = null;
            ms msVar2 = (this.f40j6.j6(bsVar) || this.f35FH[iWe] != 1) ? null : this.f36Hw[iWe];
            if (csVarTp.size() == 2) {
                bs bsVar2 = csVarTp.get(1);
                int iWe2 = bsVar2.we();
                if (!this.f40j6.j6(bsVar2) && this.f35FH[iWe2] == 1) {
                    msVar = this.f36Hw[iWe2];
                }
            }
            if (msVar2 == null || csVarTp.size() != 1) {
                if (msVar2 == null || msVar == null || ((Ms) msVar2).j3() != 6) {
                    z = false;
                    z2 = false;
                } else {
                    int iRN = ((ys) msVar2).rN();
                    int iRN2 = ((ys) msVar).rN();
                    switch (esVarV5.Hw()) {
                        case 7:
                            if (iRN == iRN2) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            z2 = z3;
                            z = true;
                            break;
                        case 8:
                            if (iRN != iRN2) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            z2 = z3;
                            z = true;
                            break;
                        case 9:
                            if (iRN < iRN2) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            z2 = z3;
                            z = true;
                            break;
                        case 10:
                            if (iRN >= iRN2) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            z2 = z3;
                            z = true;
                            break;
                        case 11:
                            if (iRN <= iRN2) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            z2 = z3;
                            z = true;
                            break;
                        case 12:
                            if (iRN > iRN2) {
                                z3 = true;
                            } else {
                                z3 = false;
                            }
                            z2 = z3;
                            z = true;
                            break;
                        default:
                            throw new RuntimeException("Unexpected op");
                    }
                }
            } else if (((Ms) msVar2).j3() != 6) {
                z = false;
                z2 = false;
            } else {
                int iRN3 = ((ys) msVar2).rN();
                switch (esVarV5.Hw()) {
                    case 7:
                        if (iRN3 == 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        z2 = z3;
                        z = true;
                        break;
                    case 8:
                        if (iRN3 != 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        z2 = z3;
                        z = true;
                        break;
                    case 9:
                        if (iRN3 < 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        z2 = z3;
                        z = true;
                        break;
                    case 10:
                        if (iRN3 >= 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        z2 = z3;
                        z = true;
                        break;
                    case 11:
                        if (iRN3 <= 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        z2 = z3;
                        z = true;
                        break;
                    case 12:
                        if (iRN3 > 0) {
                            z3 = true;
                        } else {
                            z3 = false;
                        }
                        z2 = z3;
                        z = true;
                        break;
                    default:
                        throw new RuntimeException("Unexpected op");
                }
            }
        } else {
            z = false;
            z2 = false;
        }
        C0100tt c0100ttDW = vtVar.DW();
        if (z) {
            m153j6((C0100tt) this.f40j6.DW().get(z2 ? c0100ttDW.m649J8().get(1) : c0100ttDW.m649J8().get(0)));
            this.f41tp.add(vtVar);
        } else {
            for (int i = 0; i < c0100ttDW.m649J8().size(); i++) {
                m153j6((C0100tt) this.f40j6.DW().get(c0100ttDW.m649J8().get(i)));
            }
        }
    }

    public static void m155j6(yt ytVar) {
        new C0015rt(ytVar).m147FH();
    }

    private boolean m156j6(int i, int i2, ms msVar) {
        if (i2 != 1) {
            int[] iArr = this.f35FH;
            if (iArr[i] == i2) {
                return false;
            }
            iArr[i] = i2;
            return true;
        }
        if (this.f35FH[i] == i2 && this.f36Hw[i].equals(msVar)) {
            return false;
        }
        this.f35FH[i] = i2;
        this.f36Hw[i] = msVar;
        return true;
    }
}
