package abcd;

import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.text.MessageFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.eclipse.jgit.JGitText;

class C0007_I extends InputStream {

    private boolean f32EQ;

    private final InputStream f33Hw;

    private int f34J0;

    private final Writer f35VH;

    private final LE f36Zo;

    private int f38tp;

    private final DI f40v5;

    private int f41we;

    private static final String f31j6 = JGitText.j6().prefixRemote;

    private static Pattern f29DW = Pattern.compile("^([\\w ]+): +(\\d+)(?:, done\\.)? *[\r\n]$");

    private static Pattern f30FH = Pattern.compile("^([\\w ]+): +\\d+% +\\( *(\\d+)/ *(\\d+)\\)(?:, done\\.)? *[\r\n]$");

    private String f37gn = "";

    private String f39u7 = "";

    C0007_I(InputStream inputStream, LE le, Writer writer) {
        this.f33Hw = inputStream;
        this.f40v5 = new DI(this.f33Hw);
        this.f36Zo = le;
        this.f35VH = writer;
    }

    private String m51DW(int i) {
        byte[] bArr = new byte[i];
        BK.j6(this.f33Hw, bArr, 0, i);
        return IK.j6(hE.Zo, bArr, 0, i);
    }

    private void m52DW(String str) throws IOException {
        String strSubstring = String.valueOf(this.f37gn) + str;
        while (true) {
            int iIndexOf = strSubstring.indexOf(10);
            int iIndexOf2 = strSubstring.indexOf(13);
            if (iIndexOf >= 0 && iIndexOf2 >= 0) {
                iIndexOf = Math.min(iIndexOf, iIndexOf2);
            } else if (iIndexOf >= 0) {
                continue;
            } else {
                if (iIndexOf2 < 0) {
                    this.f37gn = strSubstring;
                    return;
                }
                iIndexOf = iIndexOf2;
            }
            int i = iIndexOf + 1;
            m55j6(strSubstring.substring(0, i));
            strSubstring = strSubstring.substring(i);
        }
    }

    private void m53j6() throws IOException, nD, yD {
        if (this.f32EQ) {
            return;
        }
        if (this.f41we == 1 && this.f34J0 > 0) {
            return;
        }
        while (true) {
            this.f34J0 = this.f40v5.j6();
            if (this.f34J0 == 0) {
                this.f32EQ = true;
                return;
            }
            this.f41we = this.f33Hw.read() & 255;
            this.f34J0 -= 5;
            int i = this.f34J0;
            if (i != 0) {
                int i2 = this.f41we;
                if (i2 == 1) {
                    return;
                }
                if (i2 != 2) {
                    if (i2 != 3) {
                        throw new nD(MessageFormat.format(JGitText.j6().invalidChannel, Integer.valueOf(this.f41we)));
                    }
                    this.f32EQ = true;
                    throw new yD(String.valueOf(f31j6) + m51DW(this.f34J0));
                }
                m52DW(m51DW(i));
            }
        }
    }

    private void m54j6(int i) {
        this.f36Zo.j6(String.valueOf(f31j6) + this.f39u7, i);
    }

    private void m55j6(String str) throws IOException {
        Matcher matcher = f30FH.matcher(str);
        if (matcher.matches()) {
            String strGroup = matcher.group(1);
            if (!this.f39u7.equals(strGroup)) {
                this.f39u7 = strGroup;
                this.f38tp = 0;
                m54j6(Integer.parseInt(matcher.group(3)));
            }
            int i = Integer.parseInt(matcher.group(2));
            this.f36Zo.update(i - this.f38tp);
            this.f38tp = i;
            return;
        }
        Matcher matcher2 = f29DW.matcher(str);
        if (!matcher2.matches()) {
            this.f35VH.write(str);
            return;
        }
        String strGroup2 = matcher2.group(1);
        if (!this.f39u7.equals(strGroup2)) {
            this.f39u7 = strGroup2;
            this.f38tp = 0;
            m54j6(0);
        }
        int i2 = Integer.parseInt(matcher2.group(2));
        this.f36Zo.update(i2 - this.f38tp);
        this.f38tp = i2;
    }

    @Override
    public int read() throws IOException, nD, yD {
        m53j6();
        if (this.f32EQ) {
            return -1;
        }
        this.f34J0--;
        return this.f33Hw.read();
    }

    @Override
    public int read(byte[] bArr, int i, int i2) throws IOException, nD, yD {
        int i3;
        int i4 = 0;
        while (i2 > 0) {
            m53j6();
            if (this.f32EQ || (i3 = this.f33Hw.read(bArr, i, Math.min(i2, this.f34J0))) < 0) {
                break;
            }
            i4 += i3;
            i += i3;
            i2 -= i3;
            this.f34J0 -= i3;
        }
        if (this.f32EQ && i4 == 0) {
            return -1;
        }
        return i4;
    }
}
