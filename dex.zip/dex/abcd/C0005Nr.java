package abcd;

public final class C0005Nr implements cu {

    private final Ur f11DW;

    private final au f12FH;

    private final int f13Hw;

    private final int f14j6;

    public interface a {
        void m41j6(C0005Nr c0005Nr);
    }

    public C0005Nr(int i, Ur ur, au auVar, int i2) {
        if (i < 0) {
            throw new IllegalArgumentException("label < 0");
        }
        try {
            ur.Ws();
            int size = ur.size();
            if (size == 0) {
                throw new IllegalArgumentException("insns.size() == 0");
            }
            for (int i3 = size - 2; i3 >= 0; i3--) {
                if (ur.get(i3).v5().DW() != 1) {
                    throw new IllegalArgumentException("insns[" + i3 + "] is a branch or can throw");
                }
            }
            if (ur.get(size - 1).v5().DW() == 1) {
                throw new IllegalArgumentException("insns does not end with a branch or throwing instruction");
            }
            try {
                auVar.Ws();
                if (i2 < -1) {
                    throw new IllegalArgumentException("primarySuccessor < -1");
                }
                if (i2 < 0 || auVar.Hw(i2)) {
                    this.f14j6 = i;
                    this.f11DW = ur;
                    this.f12FH = auVar;
                    this.f13Hw = i2;
                    return;
                }
                throw new IllegalArgumentException("primarySuccessor " + i2 + " not in successors " + auVar);
            } catch (NullPointerException unused) {
                throw new NullPointerException("successors == null");
            }
        } catch (NullPointerException unused2) {
            throw new NullPointerException("insns == null");
        }
    }

    public int m32DW() {
        return this.f14j6;
    }

    public Tr m33FH() {
        return this.f11DW.get(0);
    }

    public Ur m34Hw() {
        return this.f11DW;
    }

    public int m35VH() {
        if (this.f12FH.size() != 2) {
            throw new UnsupportedOperationException("block doesn't have exactly two successors");
        }
        int i = this.f12FH.get(0);
        return i == this.f13Hw ? this.f12FH.get(1) : i;
    }

    public int m36Zo() {
        return this.f13Hw;
    }

    public boolean equals(Object obj) {
        return this == obj;
    }

    public au m37gn() {
        return this.f12FH;
    }

    public int hashCode() {
        return System.identityHashCode(this);
    }

    public boolean m38j6() {
        return this.f11DW.rN().j6();
    }

    public String toString() {
        return '{' + Yt.v5(this.f14j6) + '}';
    }

    public boolean m39u7() {
        return this.f11DW.rN().DW().size() != 0;
    }

    public Tr m40v5() {
        return this.f11DW.rN();
    }
}
