package abcd;

import java.io.ByteArrayOutputStream;

public abstract class AbstractC0017yL implements qL {
    public abstract EL mo72DW();

    public byte[] m73Hw() {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        new CL(byteArrayOutputStream).j6(this);
        return byteArrayOutputStream.toByteArray();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof qL) {
            return mo72DW().equals(((qL) obj).DW());
        }
        return false;
    }

    public int hashCode() {
        return mo72DW().hashCode();
    }

    public byte[] m74j6(String str) {
        if (str.equals("DER")) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            new rM(byteArrayOutputStream).j6(this);
            return byteArrayOutputStream.toByteArray();
        }
        if (!str.equals("DL")) {
            return m73Hw();
        }
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        new DM(byteArrayOutputStream2).j6(this);
        return byteArrayOutputStream2.toByteArray();
    }
}
