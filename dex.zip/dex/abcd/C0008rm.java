package abcd;

public final class C0008rm extends Bm {
    public C0008rm(Qm qm) {
        super("LocalVariableTypeTable", qm);
    }
}
