package abcd;

import java.io.StringWriter;
import java.io.Writer;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0050aI implements iI {

    private boolean f268DW;

    private Writer f269FH;

    private Map<String, ME> f270j6 = Collections.emptyMap();

    public final Collection<ME> m298DW() {
        return this.f270j6.values();
    }

    public Map<String, ME> m299FH() {
        return this.f270j6;
    }

    protected Writer m300VH() {
        if (this.f269FH == null) {
            m303j6(new StringWriter());
        }
        return this.f269FH;
    }

    public final ME getRef(String str) {
        return this.f270j6.get(str);
    }

    protected void m301gn() throws yD {
        if (this.f268DW) {
            throw new yD(JGitText.j6().onlyOneOperationCallPerConnectionIsSupported);
        }
        this.f268DW = true;
    }

    public String m302j6() {
        Writer writer = this.f269FH;
        return writer != null ? writer.toString() : "";
    }

    protected void m303j6(Writer writer) {
        if (this.f269FH != null) {
            throw new IllegalStateException(JGitText.j6().writerAlreadyInitialized);
        }
        this.f269FH = writer;
    }

    protected void m304j6(Map<String, ME> map) {
        this.f270j6 = Collections.unmodifiableMap(map);
    }
}
