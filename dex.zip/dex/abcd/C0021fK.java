package abcd;

import org.eclipse.jgit.JGitText;

public class C0021fK extends jK {

    final String f111FH;

    final byte[] f112Hw;

    private C0021fK(String str) {
        this.f111FH = str;
        this.f112Hw = C0103hE.m529j6(this.f111FH);
    }

    public static C0021fK m70j6(String str) {
        while (str.endsWith("/")) {
            str = str.substring(0, str.length() - 1);
        }
        if (str.length() != 0) {
            return new C0021fK(str);
        }
        throw new IllegalArgumentException(JGitText.j6().emptyPathNotPermitted);
    }

    public String m71DW() {
        return this.f111FH;
    }

    public boolean m72DW(YJ yj) {
        return this.f112Hw.length == yj.FH();
    }

    public C0021fK clone() {
        return this;
    }

    public jK m791clone() {
        clone();
        return this;
    }

    public boolean m73j6() {
        for (byte b : this.f112Hw) {
            if (b == 47) {
                return true;
            }
        }
        return false;
    }

    public boolean m74j6(YJ yj) {
        byte[] bArr = this.f112Hw;
        return yj.j6(bArr, bArr.length) == 0;
    }

    public String toString() {
        return "PATH(\"" + this.f111FH + "\")";
    }
}
