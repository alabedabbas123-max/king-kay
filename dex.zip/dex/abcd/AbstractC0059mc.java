package abcd;

@xu
public abstract class AbstractC0059mc {

    @ru(field = -523064720799552701L)
    private static AbstractC0059mc f325DW;

    @tu
    private static boolean f326FH;

    @uu
    private static boolean f327Hw;

    @ru(field = 2296690719094790161L)
    private static Object f328j6;

    static {
        try {
            wu.j6(AbstractC0059mc.class, -763031331629171476L, -763031331629171476L);
            if (f326FH) {
                wu.j6(1230057188939856771L, (Object) null);
            }
            f328j6 = new Object();
        } catch (Throwable th) {
            if (f327Hw) {
                wu.j6(th, 1230057188939856771L, (Object) null);
            }
            throw th;
        }
    }

    public AbstractC0059mc() {
        try {
            if (f326FH) {
                wu.j6(-2819042032058163600L, (Object) null);
            }
        } catch (Throwable th) {
            if (f327Hw) {
                wu.j6(th, -2819042032058163600L, (Object) null);
            }
            throw th;
        }
    }

    public static AbstractC0059mc m298j6() {
        AbstractC0059mc abstractC0059mc;
        try {
            if (f326FH) {
                wu.j6(-3787814060744596520L, (Object) null);
            }
            synchronized (f328j6) {
                abstractC0059mc = f325DW;
            }
            return abstractC0059mc;
        } catch (Throwable th) {
            if (f327Hw) {
                wu.j6(th, -3787814060744596520L, (Object) null);
            }
            throw th;
        }
    }

    public abstract float m299j6(String str);
}
