package abcd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class C0018OD {

    private List<InterfaceC0104QD> f58FH;

    private List<InterfaceC0104QD> f59Hw;

    private List<InterfaceC0104QD> f60v5;

    static final List<InterfaceC0104QD> f57j6 = Collections.emptyList();

    private static final Pattern f56DW = Pattern.compile("\\[[.:=]");

    public C0018OD(String str, Character ch) {
        this(m86j6(str, ch));
    }

    private C0018OD(List<InterfaceC0104QD> list) {
        this(list, list);
    }

    private C0018OD(List<InterfaceC0104QD> list, List<InterfaceC0104QD> list2) {
        this.f58FH = list;
        this.f59Hw = new ArrayList(list2.size());
        this.f59Hw.addAll(list2);
        this.f60v5 = new ArrayList(list2.size());
    }

    private static List<MD> m82DW(String str, Character ch) {
        ArrayList arrayList = new ArrayList(str.length());
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            if (cCharAt == '*') {
                arrayList.add(m85j6(ch, true));
            } else if (cCharAt != '?') {
                arrayList.add(new ND(cCharAt));
            } else {
                arrayList.add(m85j6(ch, false));
            }
        }
        return arrayList;
    }

    private static List<MD> m83FH(String str, Character ch) throws gD {
        ArrayList arrayList = new ArrayList();
        int length = 0;
        while (length < str.length()) {
            int iIndexOf = str.indexOf(91, length);
            if (iIndexOf == -1) {
                arrayList.addAll(m82DW(str.substring(length), ch));
                length = str.length();
            } else {
                arrayList.addAll(m82DW(str.substring(length, iIndexOf), ch));
                int iM84j6 = m84j6(iIndexOf, str);
                arrayList.add(new C0061PD(str.substring(iIndexOf + 1, iM84j6), str));
                length = iM84j6 + 1;
            }
        }
        return arrayList;
    }

    private static int m84j6(int i, String str) throws gD {
        int i2 = i + 1;
        int i3 = i + 2;
        if (i2 >= str.length()) {
            throw new gD(i, "[", "]", str);
        }
        if (str.charAt(i2) == '!') {
            i2++;
            i3++;
        }
        Matcher matcher = f56DW.matcher(str);
        int i4 = i2;
        int i5 = -1;
        while (i5 == -1) {
            int iIndexOf = str.indexOf(93, i3);
            if (iIndexOf == -1) {
                throw new gD(i, "[", "]", str);
            }
            if (!matcher.find(i4) || matcher.start() >= iIndexOf) {
                i5 = iIndexOf;
            } else {
                String strGroup = matcher.group(0);
                String str2 = String.valueOf(strGroup.charAt(1)) + "]";
                int iStart = matcher.start();
                int iIndexOf2 = str.indexOf(str2, iStart + 2);
                if (iIndexOf2 == -1) {
                    throw new gD(iStart, strGroup, str2, str);
                }
                i4 = iIndexOf2 + 2;
                i3 = i4;
            }
        }
        return i5;
    }

    private static MD m85j6(Character ch, boolean z) {
        return ch != null ? new SD(ch.charValue(), z) : new TD(z);
    }

    private static List<InterfaceC0104QD> m86j6(String str, Character ch) throws gD {
        List<MD> listM83FH = m83FH(str, ch);
        ArrayList arrayList = new ArrayList(2);
        arrayList.add(RD.j6);
        for (int size = listM83FH.size() - 1; size >= 0; size--) {
            MD md = listM83FH.get(size);
            if (md.j6()) {
                arrayList.add(md);
                md.j6(arrayList);
            } else {
                md.j6(arrayList);
                arrayList = new ArrayList(2);
                arrayList.add(md);
            }
        }
        return arrayList;
    }

    private void m87j6(char c) {
        List<InterfaceC0104QD> list = this.f60v5;
        list.clear();
        List<InterfaceC0104QD> list2 = null;
        for (int i = 0; i < this.f59Hw.size(); i++) {
            List<InterfaceC0104QD> listM639j6 = this.f59Hw.get(i).m639j6(c);
            if (listM639j6 != list2) {
                list.addAll(listM639j6);
                list2 = listM639j6;
            }
        }
        this.f60v5 = this.f59Hw;
        this.f59Hw = list;
    }

    public void m88DW() {
        this.f59Hw.clear();
        this.f59Hw.addAll(this.f58FH);
    }

    public void m89j6(String str) {
        for (int i = 0; i < str.length(); i++) {
            m87j6(str.charAt(i));
        }
    }

    public boolean m90j6() {
        List<InterfaceC0104QD> list = this.f59Hw;
        ListIterator<InterfaceC0104QD> listIterator = list.listIterator(list.size());
        while (listIterator.hasPrevious()) {
            if (listIterator.previous() == RD.j6) {
                return true;
            }
        }
        return false;
    }
}
