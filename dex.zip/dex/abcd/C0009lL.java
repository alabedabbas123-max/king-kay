package abcd;

import java.io.IOException;
import java.io.Reader;

class C0009lL {

    private int f45J0;

    private int f46J8;

    private boolean f47Mr;

    private int f48QX;

    private int f50Ws;

    private int f51XL;

    private int f52aM;

    private Reader f53gn;

    private int f56u7;

    private int f57we;

    private static final int[] f42j6 = {0, 0, 1, 1};

    private static final char[] f37DW = m62j6("\t\u0000\u0001\u0007\u0001\u0007\u0002\u0000\u0001\u0007\u0012\u0000\u0001\u0007\u0001\u0000\u0001\t\b\u0000\u0001\u0006\u0001\u0019\u0001\u0002\u0001\u0004\u0001\n\n\u0003\u0001\u001a\u0006\u0000\u0004\u0001\u0001\u0005\u0001\u0001\u0014\u0000\u0001\u0017\u0001\b\u0001\u0018\u0003\u0000\u0001\u0012\u0001\u000b\u0002\u0001\u0001\u0011\u0001\f\u0005\u0000\u0001\u0013\u0001\u0000\u0001\r\u0003\u0000\u0001\u000e\u0001\u0014\u0001\u000f\u0001\u0010\u0005\u0000\u0001\u0015\u0001\u0000\u0001\u0016ﾂ\u0000");

    private static final int[] f38FH = m63v5();

    private static final int[] f39Hw = m59VH();

    private static final int[] f43v5 = {2, 2, 3, 4, 2, 2, 2, 5, 2, 6, 2, 2, 7, 8, 2, 9, 2, 2, 2, 2, 2, 10, 11, 12, 13, 14, 15, 16, 16, 16, 16, 16, 16, 16, 16, 17, 18, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 4, 19, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 5, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 21, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 22, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 23, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 16, 16, 16, 16, 16, 16, 16, 16, -1, -1, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, -1, -1, -1, -1, -1, -1, -1, -1, 24, 25, 26, 27, 28, 29, 30, 31, 32, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 33, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 34, 35, -1, -1, 34, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 36, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 37, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 38, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 39, -1, 39, -1, 39, -1, -1, -1, -1, -1, 39, 39, -1, -1, -1, -1, 39, 39, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 33, -1, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 20, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 35, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 38, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 40, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 41, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 42, -1, 42, -1, 42, -1, -1, -1, -1, -1, 42, 42, -1, -1, -1, -1, 42, 42, -1, -1, -1, -1, -1, -1, -1, -1, -1, 43, -1, 43, -1, 43, -1, -1, -1, -1, -1, 43, 43, -1, -1, -1, -1, 43, 43, -1, -1, -1, -1, -1, -1, -1, -1, -1, 44, -1, 44, -1, 44, -1, -1, -1, -1, -1, 44, 44, -1, -1, -1, -1, 44, 44, -1, -1, -1, -1, -1, -1, -1, -1};

    private static final String[] f41Zo = {"Unkown internal scanner error", "Error: could not match input", "Error: pushback value was too large"};

    private static final int[] f40VH = m60Zo();

    private int f55tp = 0;

    private char[] f44EQ = new char[16384];

    private boolean f54j3 = true;

    private StringBuffer f49U2 = new StringBuffer();

    C0009lL(Reader reader) {
        this.f53gn = reader;
    }

    private static int m55DW(String str, int i, int[] iArr) {
        int i2;
        int length = str.length();
        int i3 = 0;
        while (i3 < length) {
            int i4 = i3 + 1;
            int iCharAt = str.charAt(i3);
            int i5 = i4 + 1;
            char cCharAt = str.charAt(i4);
            while (true) {
                i2 = i + 1;
                iArr[i] = cCharAt;
                iCharAt--;
                if (iCharAt <= 0) {
                    break;
                }
                i = i2;
            }
            i3 = i5;
            i = i2;
        }
        return i;
    }

    private static int m56FH(String str, int i, int[] iArr) {
        int length = str.length();
        int i2 = 0;
        while (i2 < length) {
            int i3 = i2 + 1;
            iArr[i] = (str.charAt(i2) << 16) | str.charAt(i3);
            i++;
            i2 = i3 + 1;
        }
        return i;
    }

    private void m57FH(int i) {
        String str;
        try {
            str = f41Zo[i];
        } catch (ArrayIndexOutOfBoundsException unused) {
            str = f41Zo[0];
        }
        throw new Error(str);
    }

    private boolean m58Hw() throws IOException {
        int i;
        int i2 = this.f46J8;
        if (i2 > 0) {
            char[] cArr = this.f44EQ;
            System.arraycopy(cArr, i2, cArr, 0, this.f50Ws - i2);
            int i3 = this.f50Ws;
            int i4 = this.f46J8;
            this.f50Ws = i3 - i4;
            this.f45J0 -= i4;
            this.f57we -= i4;
            this.f46J8 = 0;
        }
        int i5 = this.f45J0;
        char[] cArr2 = this.f44EQ;
        if (i5 >= cArr2.length) {
            char[] cArr3 = new char[i5 * 2];
            System.arraycopy(cArr2, 0, cArr3, 0, cArr2.length);
            this.f44EQ = cArr3;
        }
        Reader reader = this.f53gn;
        char[] cArr4 = this.f44EQ;
        int i6 = this.f50Ws;
        int i7 = reader.read(cArr4, i6, cArr4.length - i6);
        if (i7 > 0) {
            this.f50Ws += i7;
            return false;
        }
        if (i7 != 0 || (i = this.f53gn.read()) == -1) {
            return true;
        }
        char[] cArr5 = this.f44EQ;
        int i8 = this.f50Ws;
        this.f50Ws = i8 + 1;
        cArr5[i8] = (char) i;
        return false;
    }

    private static int[] m59VH() {
        int[] iArr = new int[45];
        m56FH("\u0000\u0000\u0000\u001b\u00006\u0000Q\u0000l\u0000\u0087\u00006\u0000¢\u0000½\u0000Ø\u00006\u00006\u00006\u00006\u00006\u00006\u0000ó\u0000Ď\u00006\u0000ĩ\u0000ń\u0000ş\u0000ź\u0000ƕ\u00006\u00006\u00006\u00006\u00006\u00006\u00006\u00006\u0000ư\u0000ǋ\u0000Ǧ\u0000Ǧ\u0000ȁ\u0000Ȝ\u0000ȷ\u0000ɒ\u00006\u00006\u0000ɭ\u0000ʈ\u00006", 0, iArr);
        return iArr;
    }

    private static int[] m60Zo() {
        int[] iArr = new int[45];
        m55DW("\u0002\u0000\u0001\t\u0003\u0001\u0001\t\u0003\u0001\u0006\t\u0002\u0001\u0001\t\u0005\u0000\b\t\u0001\u0000\u0001\u0001\u0001\u0000\u0001\u0001\u0004\u0000\u0002\t\u0002\u0000\u0001\t", 0, iArr);
        return iArr;
    }

    private static int m61j6(String str, int i, int[] iArr) {
        int i2;
        int length = str.length();
        int i3 = 0;
        while (i3 < length) {
            int i4 = i3 + 1;
            int iCharAt = str.charAt(i3);
            int i5 = i4 + 1;
            char cCharAt = str.charAt(i4);
            while (true) {
                i2 = i + 1;
                iArr[i] = cCharAt;
                iCharAt--;
                if (iCharAt <= 0) {
                    break;
                }
                i = i2;
            }
            i3 = i5;
            i = i2;
        }
        return i;
    }

    private static char[] m62j6(String str) {
        int i;
        char[] cArr = new char[65536];
        int i2 = 0;
        int i3 = 0;
        while (i2 < 90) {
            int i4 = i2 + 1;
            int iCharAt = str.charAt(i2);
            int i5 = i4 + 1;
            char cCharAt = str.charAt(i4);
            while (true) {
                i = i3 + 1;
                cArr[i3] = cCharAt;
                iCharAt--;
                if (iCharAt <= 0) {
                    break;
                }
                i3 = i;
            }
            i2 = i5;
            i3 = i;
        }
        return cArr;
    }

    private static int[] m63v5() {
        int[] iArr = new int[45];
        m61j6("\u0002\u0000\u0002\u0001\u0001\u0002\u0001\u0003\u0001\u0004\u0003\u0001\u0001\u0005\u0001\u0006\u0001\u0007\u0001\b\u0001\t\u0001\n\u0001\u000b\u0001\f\u0001\r\u0005\u0000\u0001\f\u0001\u000e\u0001\u000f\u0001\u0010\u0001\u0011\u0001\u0012\u0001\u0013\u0001\u0014\u0001\u0000\u0001\u0015\u0001\u0000\u0001\u0015\u0004\u0000\u0001\u0016\u0001\u0017\u0002\u0000\u0001\u0018", 0, iArr);
        return iArr;
    }

    public final char m64DW(int i) {
        return this.f44EQ[this.f46J8 + i];
    }

    public C0052mL m65DW() throws kL, IOException {
        char[] cArr;
        byte b;
        StringBuffer stringBuffer;
        char c;
        int i = this.f50Ws;
        char[] cArr2 = this.f44EQ;
        char[] cArr3 = f37DW;
        int[] iArr = f43v5;
        int[] iArr2 = f39Hw;
        int[] iArr3 = f40VH;
        while (true) {
            int i2 = this.f57we;
            this.f51XL += i2 - this.f46J8;
            this.f46J8 = i2;
            this.f45J0 = i2;
            this.f56u7 = f42j6[this.f55tp];
            int i3 = -1;
            int i4 = i2;
            int i5 = -1;
            while (true) {
                if (i2 < i) {
                    cArr = cArr2;
                    b = cArr2[i2];
                    i2++;
                } else if (this.f47Mr) {
                    cArr = cArr2;
                    b = -1;
                } else {
                    this.f45J0 = i2;
                    this.f57we = i4;
                    boolean zM58Hw = m58Hw();
                    int i6 = this.f45J0;
                    i4 = this.f57we;
                    char[] cArr4 = this.f44EQ;
                    int i7 = this.f50Ws;
                    if (zM58Hw) {
                        i = i7;
                        b = -1;
                        cArr = cArr4;
                    } else {
                        int i8 = i6 + 1;
                        char c2 = cArr4[i6];
                        i2 = i8;
                        i = i7;
                        cArr = cArr4;
                        b = c2;
                    }
                }
                int i9 = iArr[iArr2[this.f56u7] + cArr3[b]];
                if (i9 != i3) {
                    this.f56u7 = i9;
                    int i10 = this.f56u7;
                    int i11 = iArr3[i10];
                    if ((i11 & 1) == 1) {
                        if ((i11 & 8) == 8) {
                            i4 = i2;
                            i5 = i10;
                        } else {
                            i4 = i2;
                            i5 = i10;
                        }
                    }
                    cArr2 = cArr;
                    i3 = -1;
                }
            }
            this.f57we = i4;
            if (i5 >= 0) {
                i5 = f38FH[i5];
            }
            switch (i5) {
                case 1:
                    throw new kL(this.f51XL, 0, new Character(m64DW(0)));
                case 2:
                    return new C0052mL(0, Long.valueOf(m66FH()));
                case 3:
                case 25:
                case 26:
                case 27:
                case 28:
                case 29:
                case 30:
                case 31:
                case 32:
                case 33:
                case 34:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                case 40:
                case 41:
                case 42:
                case 43:
                case 44:
                case 45:
                case 46:
                case 47:
                case 48:
                    continue;
                    cArr2 = cArr;
                    break;
                case 4:
                    StringBuffer stringBuffer2 = this.f49U2;
                    stringBuffer2.delete(0, stringBuffer2.length());
                    m68j6(2);
                    continue;
                    cArr2 = cArr;
                    break;
                case 5:
                    return new C0052mL(1, null);
                case 6:
                    return new C0052mL(2, null);
                case 7:
                    return new C0052mL(3, null);
                case 8:
                    return new C0052mL(4, null);
                case 9:
                    return new C0052mL(5, null);
                case 10:
                    return new C0052mL(6, null);
                case 11:
                    this.f49U2.append(m66FH());
                    continue;
                    cArr2 = cArr;
                    break;
                case 12:
                    stringBuffer = this.f49U2;
                    c = '\\';
                    break;
                case 13:
                    m68j6(0);
                    return new C0052mL(0, this.f49U2.toString());
                case 14:
                    stringBuffer = this.f49U2;
                    c = '\"';
                    break;
                case 15:
                    stringBuffer = this.f49U2;
                    c = '/';
                    break;
                case 16:
                    this.f49U2.append('\b');
                    continue;
                    cArr2 = cArr;
                    break;
                case 17:
                    stringBuffer = this.f49U2;
                    c = '\f';
                    break;
                case 18:
                    stringBuffer = this.f49U2;
                    c = '\n';
                    break;
                case 19:
                    stringBuffer = this.f49U2;
                    c = '\r';
                    break;
                case 20:
                    stringBuffer = this.f49U2;
                    c = '\t';
                    break;
                case 21:
                    return new C0052mL(0, Double.valueOf(m66FH()));
                case 22:
                    return new C0052mL(0, null);
                case 23:
                    return new C0052mL(0, Boolean.valueOf(m66FH()));
                case 24:
                    try {
                        this.f49U2.append((char) Integer.parseInt(m66FH().substring(2), 16));
                        continue;
                        cArr2 = cArr;
                    } catch (Exception e) {
                        throw new kL(this.f51XL, 2, e);
                    }
                    break;
                default:
                    if (b == -1 && this.f46J8 == this.f45J0) {
                        this.f47Mr = true;
                        return null;
                    }
                    m57FH(1);
                    throw null;
            }
            stringBuffer.append(c);
            cArr2 = cArr;
        }
    }

    public final String m66FH() {
        char[] cArr = this.f44EQ;
        int i = this.f46J8;
        return new String(cArr, i, this.f57we - i);
    }

    int m67j6() {
        return this.f51XL;
    }

    public final void m68j6(int i) {
        this.f55tp = i;
    }

    public final void m69j6(Reader reader) {
        this.f53gn = reader;
        this.f54j3 = true;
        this.f47Mr = false;
        this.f46J8 = 0;
        this.f50Ws = 0;
        this.f57we = 0;
        this.f45J0 = 0;
        this.f52aM = 0;
        this.f51XL = 0;
        this.f48QX = 0;
        this.f55tp = 0;
    }
}
