package abcd;

import com.aide.common.u;
import com.aide.ui.U;

@xu
public class C0020lg implements Yl, Wl {

    @uu
    private static boolean f222DW;

    @tu
    private static boolean f223j6;

    static {
        wu.j6(C0020lg.class, 3293585062521864541L, 3293585062521864541L);
    }

    public C0020lg() {
        try {
            if (f223j6) {
                wu.j6(-5181600903522880L, (Object) null);
            }
        } catch (Throwable th) {
            if (f222DW) {
                wu.j6(th, -5181600903522880L, (Object) null);
            }
            throw th;
        }
    }

    public u m111FH() {
        try {
            if (f223j6) {
                wu.j6(-5119427983714315425L, this);
            }
            return new u(9, false, true, false);
        } catch (Throwable th) {
            if (f222DW) {
                wu.j6(th, -5119427983714315425L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f223j6) {
                return "Show Errors";
            }
            wu.j6(467064237447557280L, this);
            return "Show Errors";
        } catch (Throwable th) {
            if (f222DW) {
                wu.j6(th, 467064237447557280L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (!f223j6) {
                return true;
            }
            wu.j6(-868114264366123512L, this);
            return true;
        } catch (Throwable th) {
            if (f222DW) {
                wu.j6(th, -868114264366123512L, this);
            }
            throw th;
        }
    }

    public int m112j6() {
        try {
            if (!f223j6) {
                return com.aide.pro.R.id.mainMenuOpenErrorBrowser;
            }
            wu.j6(4689453657226800100L, this);
            return com.aide.pro.R.id.mainMenuOpenErrorBrowser;
        } catch (Throwable th) {
            if (f222DW) {
                wu.j6(th, 4689453657226800100L, this);
            }
            throw th;
        }
    }

    public boolean m113run() {
        try {
            if (f223j6) {
                wu.j6(2046416676396123020L, this);
            }
            U.lg().KD();
            return true;
        } catch (Throwable th) {
            if (f222DW) {
                wu.j6(th, 2046416676396123020L, this);
            }
            throw th;
        }
    }
}
