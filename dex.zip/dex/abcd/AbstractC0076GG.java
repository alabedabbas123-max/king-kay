package abcd;

import java.io.File;
import java.util.Collection;
import java.util.Set;

abstract class AbstractC0076GG extends xE {

    static class a {

        final AbstractC0076GG f394j6;

        a(AbstractC0076GG abstractC0076GG) {
            this.f394j6 = abstractC0076GG;
        }

        Collection<BH> m721DW() {
            return this.f394j6.m706Zo();
        }

        void mo722j6() {
            this.f394j6.j6();
        }
    }

    static class b extends a {

        final IG f395DW;

        b(IG ig) {
            super(ig.EQ());
            this.f395DW = ig;
        }

        @Override
        void mo722j6() {
            this.f395DW.j6();
        }
    }

    enum c {
        INSERTED,
        EXISTS_PACKED,
        EXISTS_LOOSE,
        FAILURE;

        public static c[] valuesCustom() {
            c[] cVarArrValuesCustom = values();
            int length = cVarArrValuesCustom.length;
            c[] cVarArr = new c[length];
            System.arraycopy(cVarArrValuesCustom, 0, cVarArr, 0, length);
            return cVarArr;
        }
    }

    AbstractC0076GG() {
    }

    abstract long m690DW(wH wHVar, YD yd);

    final long m691DW(wH wHVar, String str, YD yd) {
        long jM709j6 = m709j6(wHVar, str, yd);
        if (0 <= jM709j6) {
            return jM709j6;
        }
        for (a aVar : m716tp()) {
            long jM691DW = aVar.f394j6.m691DW(wHVar, str, yd);
            if (0 <= jM691DW) {
                return jM691DW;
            }
        }
        return -1L;
    }

    File m692DW(YD yd) {
        return m712j6(yd.we());
    }

    abstract boolean m693DW(String str);

    abstract AbstractC0076GG m694EQ();

    final long m695FH(wH wHVar, YD yd) {
        long jM690DW = m690DW(wHVar, yd);
        if (0 <= jM690DW) {
            return jM690DW;
        }
        for (a aVar : m716tp()) {
            long jM695FH = aVar.f394j6.m695FH(wHVar, yd);
            if (0 <= jM695FH) {
                return jM695FH;
            }
        }
        if (!m720we()) {
            return -1L;
        }
        long jM690DW2 = m690DW(wHVar, yd);
        if (0 <= jM690DW2) {
            return jM690DW2;
        }
        return -1L;
    }

    abstract AbstractC0031FE m696FH(wH wHVar, String str, YD yd);

    abstract boolean m697FH(YD yd);

    final boolean m698FH(String str) {
        if (m693DW(str)) {
            return true;
        }
        for (a aVar : m716tp()) {
            if (aVar.f394j6.m698FH(str)) {
                return true;
            }
        }
        return false;
    }

    AbstractC0031FE m700Hw(wH wHVar, YD yd) {
        AbstractC0031FE abstractC0031FEM705Zo = m705Zo(wHVar, yd);
        if (abstractC0031FEM705Zo != null) {
            return abstractC0031FEM705Zo;
        }
        AbstractC0031FE abstractC0031FEM701Hw = m701Hw(wHVar, yd.we(), yd);
        if (abstractC0031FEM701Hw != null) {
            return abstractC0031FEM701Hw;
        }
        return null;
    }

    final AbstractC0031FE m701Hw(wH wHVar, String str, YD yd) {
        AbstractC0031FE abstractC0031FEM696FH = m696FH(wHVar, str, yd);
        if (abstractC0031FEM696FH != null) {
            return abstractC0031FEM696FH;
        }
        for (a aVar : m716tp()) {
            AbstractC0031FE abstractC0031FEM701Hw = aVar.f394j6.m701Hw(wHVar, str, yd);
            if (abstractC0031FEM701Hw != null) {
                return abstractC0031FEM701Hw;
            }
        }
        return null;
    }

    public YG m699Hw() {
        return new YG(this, m704VH());
    }

    final boolean m703Hw(YD yd) {
        if (m697FH(yd)) {
            return true;
        }
        for (a aVar : m716tp()) {
            if (aVar.f394j6.m703Hw(yd)) {
                return true;
            }
        }
        return m720we() && m697FH(yd);
    }

    abstract gE m704VH();

    final AbstractC0031FE m705Zo(wH wHVar, YD yd) {
        AbstractC0031FE abstractC0031FEM718v5;
        AbstractC0031FE abstractC0031FEM718v6 = m718v5(wHVar, yd);
        if (abstractC0031FEM718v6 != null) {
            return abstractC0031FEM718v6;
        }
        for (a aVar : m716tp()) {
            AbstractC0031FE abstractC0031FEM705Zo = aVar.f394j6.m705Zo(wHVar, yd);
            if (abstractC0031FEM705Zo != null) {
                return abstractC0031FEM705Zo;
            }
        }
        if (!m720we() || (abstractC0031FEM718v5 = m718v5(wHVar, yd)) == null) {
            return null;
        }
        return abstractC0031FEM718v5;
    }

    abstract Collection<? extends BH> m706Zo();

    abstract File m707gn();

    long m708j6(wH wHVar, YD yd) {
        long jM695FH = m695FH(wHVar, yd);
        return 0 <= jM695FH ? jM695FH : m691DW(wHVar, yd.we(), yd);
    }

    abstract long m709j6(wH wHVar, String str, YD yd);

    abstract c m710j6(File file, yE yEVar, boolean z);

    abstract aH m711j6(File file, File file2);

    File m712j6(String str) {
        String strSubstring = str.substring(0, 2);
        return new File(new File(m707gn(), strSubstring), str.substring(2));
    }

    abstract void m713j6(TH th, MH mh, wH wHVar);

    abstract void m714j6(Set<yE> set, WD wd);

    public boolean m715j6(YD yd) {
        return m703Hw(yd) || m698FH(yd.we());
    }

    abstract a[] m716tp();

    abstract pK m717u7();

    abstract AbstractC0031FE m718v5(wH wHVar, YD yd);

    public IE m719v5() {
        return new wH(this);
    }

    abstract boolean m720we();
}
