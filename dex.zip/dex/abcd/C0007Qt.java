package abcd;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;

public final class C0007Qt implements Lt, Tt {

    private byte[] f59DW;

    private int f60FH;

    private boolean f61Hw;

    private int f62VH;

    private int f63Zo;

    private final boolean f64j6;

    private ArrayList<a> f65v5;

    private static class a {

        private int f66DW;

        private final String f67FH;

        private final int f68j6;

        public a(int i, int i2, String str) {
            this.f68j6 = i;
            this.f66DW = i2;
            this.f67FH = str;
        }

        public a(int i, String str) {
            this(i, Integer.MAX_VALUE, str);
        }

        public int m87DW() {
            return this.f68j6;
        }

        public void m88DW(int i) {
            if (this.f66DW == Integer.MAX_VALUE) {
                this.f66DW = i;
            }
        }

        public String m89FH() {
            return this.f67FH;
        }

        public int m90j6() {
            return this.f66DW;
        }

        public void m91j6(int i) {
            this.f66DW = i;
        }
    }

    public C0007Qt() {
        this(1000);
    }

    public C0007Qt(int i) {
        this(new byte[i], true);
    }

    public C0007Qt(byte[] bArr) {
        this(bArr, false);
    }

    private C0007Qt(byte[] bArr, boolean z) {
        if (bArr == null) {
            throw new NullPointerException("data == null");
        }
        this.f64j6 = z;
        this.f59DW = bArr;
        this.f60FH = 0;
        this.f61Hw = false;
        this.f65v5 = null;
        this.f63Zo = 0;
        this.f62VH = 0;
    }

    private void m66Zo(int i) {
        byte[] bArr = this.f59DW;
        if (bArr.length < i) {
            byte[] bArr2 = new byte[(i * 2) + 1000];
            System.arraycopy(bArr, 0, bArr2, 0, this.f60FH);
            this.f59DW = bArr2;
        }
    }

    private static void m67u7() {
        throw new IndexOutOfBoundsException("attempt to write past the end");
    }

    public int m68DW(int i) {
        if (this.f64j6) {
            m66Zo(this.f60FH + 5);
        }
        int i2 = this.f60FH;
        eu.DW(this, i);
        return this.f60FH - i2;
    }

    public boolean m69DW() {
        return this.f61Hw;
    }

    public void m70FH() {
        int size;
        ArrayList<a> arrayList = this.f65v5;
        if (arrayList == null || (size = arrayList.size()) == 0) {
            return;
        }
        this.f65v5.get(size - 1).m88DW(this.f60FH);
    }

    public void m71FH(int i) throws Vt {
        if (this.f60FH == i) {
            return;
        }
        throw new Vt("expected cursor " + i + "; actual value: " + this.f60FH);
    }

    public void m72Hw(int i) {
        int i2 = i - 1;
        if (i < 0 || (i & i2) != 0) {
            throw new IllegalArgumentException("bogus alignment");
        }
        int i3 = (this.f60FH + i2) & (i2 ^ (-1));
        if (this.f64j6) {
            m66Zo(i3);
        } else if (i3 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        this.f60FH = i3;
    }

    public boolean m73Hw() {
        return this.f65v5 != null;
    }

    public byte[] m74VH() {
        return this.f59DW;
    }

    public void m75Zo() {
        m70FH();
        ArrayList<a> arrayList = this.f65v5;
        if (arrayList != null) {
            for (int size = arrayList.size(); size > 0; size--) {
                int i = size - 1;
                a aVar = this.f65v5.get(i);
                if (aVar.m87DW() <= this.f60FH) {
                    int iM90j6 = aVar.m90j6();
                    int i2 = this.f60FH;
                    if (iM90j6 > i2) {
                        aVar.m91j6(i2);
                        return;
                    }
                    return;
                }
                this.f65v5.remove(i);
            }
        }
    }

    public byte[] m76gn() {
        int i = this.f60FH;
        byte[] bArr = new byte[i];
        System.arraycopy(this.f59DW, 0, bArr, 0, i);
        return bArr;
    }

    public int m77j6() {
        int i = this.f62VH;
        return this.f63Zo - (((i * 2) + 8) + (i / 2));
    }

    public void m78j6(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("count < 0");
        }
        int i2 = this.f60FH + i;
        if (this.f64j6) {
            m66Zo(i2);
        } else if (i2 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        this.f60FH = i2;
    }

    public void m79j6(int i, String str) {
        if (this.f65v5 == null) {
            return;
        }
        m70FH();
        int size = this.f65v5.size();
        int iM90j6 = size == 0 ? 0 : this.f65v5.get(size - 1).m90j6();
        int i2 = this.f60FH;
        if (iM90j6 <= i2) {
            iM90j6 = i2;
        }
        this.f65v5.add(new a(iM90j6, i + iM90j6, str));
    }

    public void m80j6(int i, boolean z) {
        if (this.f65v5 != null || this.f60FH != 0) {
            throw new RuntimeException("cannot enable annotations");
        }
        if (i < 40) {
            throw new IllegalArgumentException("annotationWidth < 40");
        }
        int i2 = (((i - 7) / 15) + 1) & (-2);
        if (i2 < 6) {
            i2 = 6;
        } else if (i2 > 10) {
            i2 = 10;
        }
        this.f65v5 = new ArrayList<>(1000);
        this.f63Zo = i;
        this.f62VH = i2;
        this.f61Hw = z;
    }

    public void m81j6(Pt pt) {
        int iFH = pt.FH();
        int i = this.f60FH;
        int i2 = iFH + i;
        if (this.f64j6) {
            m66Zo(i2);
        } else if (i2 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        pt.j6(this.f59DW, i);
        this.f60FH = i2;
    }

    public void m82j6(Writer writer) throws IOException {
        String strM89FH;
        int i;
        int iM77j6 = m77j6();
        mu muVar = new mu(writer, (this.f63Zo - iM77j6) - 1, iM77j6, "|");
        Writer writerDW = muVar.DW();
        Writer writerFH = muVar.FH();
        int size = this.f65v5.size();
        int i2 = 0;
        int i3 = 0;
        while (i3 < this.f60FH && i2 < size) {
            a aVar = this.f65v5.get(i2);
            int iM87DW = aVar.m87DW();
            if (i3 < iM87DW) {
                strM89FH = "";
                i = i3;
            } else {
                int iM90j6 = aVar.m90j6();
                strM89FH = aVar.m89FH();
                i2++;
                i = iM87DW;
                iM87DW = iM90j6;
            }
            writerDW.write(Yt.j6(this.f59DW, i, iM87DW - i, i, this.f62VH, 6));
            writerFH.write(strM89FH);
            muVar.j6();
            i3 = iM87DW;
        }
        int i4 = this.f60FH;
        if (i3 < i4) {
            writerDW.write(Yt.j6(this.f59DW, i3, i4 - i3, i3, this.f62VH, 6));
        }
        while (i2 < size) {
            writerFH.write(this.f65v5.get(i2).m89FH());
            i2++;
        }
        muVar.j6();
    }

    public void m83j6(String str) {
        if (this.f65v5 == null) {
            return;
        }
        m70FH();
        this.f65v5.add(new a(this.f60FH, str));
    }

    public void m84j6(byte[] bArr, int i, int i2) {
        int i3 = this.f60FH;
        int i4 = i3 + i2;
        int i5 = i + i2;
        if ((i | i2 | i4) < 0 || i5 > bArr.length) {
            throw new IndexOutOfBoundsException("bytes.length " + bArr.length + "; " + i + "..!" + i4);
        }
        if (this.f64j6) {
            m66Zo(i4);
        } else if (i4 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        System.arraycopy(bArr, i, this.f59DW, i3, i2);
        this.f60FH = i4;
    }

    public int m85v5() {
        return this.f60FH;
    }

    public int m86v5(int i) {
        if (this.f64j6) {
            m66Zo(this.f60FH + 5);
        }
        int i2 = this.f60FH;
        eu.j6(this, i);
        return this.f60FH - i2;
    }

    public void write(byte[] bArr) {
        m84j6(bArr, 0, bArr.length);
    }

    public void writeByte(int i) {
        int i2 = this.f60FH;
        int i3 = i2 + 1;
        if (this.f64j6) {
            m66Zo(i3);
        } else if (i3 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        this.f59DW[i2] = (byte) i;
        this.f60FH = i3;
    }

    public void writeInt(int i) {
        int i2 = this.f60FH;
        int i3 = i2 + 4;
        if (this.f64j6) {
            m66Zo(i3);
        } else if (i3 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        byte[] bArr = this.f59DW;
        bArr[i2] = (byte) i;
        bArr[i2 + 1] = (byte) (i >> 8);
        bArr[i2 + 2] = (byte) (i >> 16);
        bArr[i2 + 3] = (byte) (i >> 24);
        this.f60FH = i3;
    }

    public void writeLong(long j) {
        int i = this.f60FH;
        int i2 = i + 8;
        if (this.f64j6) {
            m66Zo(i2);
        } else if (i2 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        int i3 = (int) j;
        byte[] bArr = this.f59DW;
        bArr[i] = (byte) i3;
        bArr[i + 1] = (byte) (i3 >> 8);
        bArr[i + 2] = (byte) (i3 >> 16);
        bArr[i + 3] = (byte) (i3 >> 24);
        int i4 = (int) (j >> 32);
        bArr[i + 4] = (byte) i4;
        bArr[i + 5] = (byte) (i4 >> 8);
        bArr[i + 6] = (byte) (i4 >> 16);
        bArr[i + 7] = (byte) (i4 >> 24);
        this.f60FH = i2;
    }

    public void writeShort(int i) {
        int i2 = this.f60FH;
        int i3 = i2 + 2;
        if (this.f64j6) {
            m66Zo(i3);
        } else if (i3 > this.f59DW.length) {
            m67u7();
            throw null;
        }
        byte[] bArr = this.f59DW;
        bArr[i2] = (byte) i;
        bArr[i2 + 1] = (byte) (i >> 8);
        this.f60FH = i3;
    }
}
