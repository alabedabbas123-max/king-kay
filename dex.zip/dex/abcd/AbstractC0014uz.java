package abcd;

import android.content.Context;
import io.fabric.sdk.android.services.common.i;
import io.fabric.sdk.android.services.common.k;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;

public abstract class AbstractC0014uz<T> {

    protected final sz<T> f22DW;

    protected final k f23FH;

    protected final InterfaceC0057vz f24Hw;

    protected final List<InterfaceC0099wz> f25VH = new CopyOnWriteArrayList();

    protected volatile long f26Zo;

    protected final Context f27j6;

    private final int f28v5;

    static class a {

        final long f29DW;

        final File f30j6;

        public a(File file, long j) {
            this.f30j6 = file;
            this.f29DW = j;
        }
    }

    public AbstractC0014uz(Context context, sz<T> szVar, k kVar, InterfaceC0057vz interfaceC0057vz, int i) {
        this.f27j6 = context.getApplicationContext();
        this.f22DW = szVar;
        this.f24Hw = interfaceC0057vz;
        this.f23FH = kVar;
        this.f26Zo = this.f23FH.j6();
        this.f28v5 = i;
    }

    private void m58DW(String str) {
        Iterator<InterfaceC0099wz> it = this.f25VH.iterator();
        while (it.hasNext()) {
            try {
                it.next().m409j6(str);
            } catch (Exception e) {
                i.j6(this.f27j6, "One of the roll over listeners threw an exception", e);
            }
        }
    }

    private void m59j6(int i) {
        if (this.f24Hw.m240j6(i, m70v5())) {
            return;
        }
        i.j6(this.f27j6, 4, "Fabric", String.format(Locale.US, "session analytics events file is %d bytes, new event is %d bytes, this is over flush limit of %d, rolling it over", Integer.valueOf(this.f24Hw.m235j6()), Integer.valueOf(i), Integer.valueOf(m70v5())));
        m63VH();
    }

    public void m60DW() {
        List<File> listM232DW = this.f24Hw.m232DW();
        int iM64Zo = m64Zo();
        if (listM232DW.size() <= iM64Zo) {
            return;
        }
        int size = listM232DW.size() - iM64Zo;
        i.FH(this.f27j6, String.format(Locale.US, "Found %d files in  roll over directory, this is greater than %d, deleting %d oldest files", Integer.valueOf(listM232DW.size()), Integer.valueOf(iM64Zo), Integer.valueOf(size)));
        TreeSet treeSet = new TreeSet((Comparator) new tz(this));
        for (File file : listM232DW) {
            treeSet.add(new a(file, m65j6(file.getName())));
        }
        ArrayList arrayList = new ArrayList();
        Iterator it = treeSet.iterator();
        while (it.hasNext()) {
            arrayList.add(((a) it.next()).f30j6);
            if (arrayList.size() == size) {
                break;
            }
        }
        this.f24Hw.m238j6(arrayList);
    }

    protected abstract String m61FH();

    public List<File> m62Hw() {
        return this.f24Hw.m236j6(1);
    }

    public boolean m63VH() {
        String strM61FH;
        boolean z = true;
        if (this.f24Hw.m233FH()) {
            strM61FH = null;
            z = false;
        } else {
            strM61FH = m61FH();
            this.f24Hw.m237j6(strM61FH);
            i.j6(this.f27j6, 4, "Fabric", String.format(Locale.US, "generated new file %s", strM61FH));
            this.f26Zo = this.f23FH.j6();
        }
        m58DW(strM61FH);
        return z;
    }

    protected int m64Zo() {
        return this.f28v5;
    }

    public long m65j6(String str) {
        String[] strArrSplit = str.split("_");
        if (strArrSplit.length != 3) {
            return 0L;
        }
        try {
            return Long.valueOf(strArrSplit[2]).longValue();
        } catch (NumberFormatException unused) {
            return 0L;
        }
    }

    public void m66j6() {
        InterfaceC0057vz interfaceC0057vz = this.f24Hw;
        interfaceC0057vz.m238j6(interfaceC0057vz.m232DW());
        this.f24Hw.m234Hw();
    }

    public void m67j6(InterfaceC0099wz interfaceC0099wz) {
        if (interfaceC0099wz != null) {
            this.f25VH.add(interfaceC0099wz);
        }
    }

    public void m68j6(T t) {
        byte[] bArrJ6 = this.f22DW.j6(t);
        m59j6(bArrJ6.length);
        this.f24Hw.m239j6(bArrJ6);
    }

    public void m69j6(List<File> list) {
        this.f24Hw.m238j6(list);
    }

    protected int m70v5() {
        return 8000;
    }
}
