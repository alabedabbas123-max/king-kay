package abcd;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

public abstract class AbstractC0038FL extends EL {

    protected Vector f199j6 = new Vector();

    protected AbstractC0038FL() {
    }

    protected AbstractC0038FL(qL qLVar) {
        this.f199j6.addElement(qLVar);
    }

    protected AbstractC0038FL(rL rLVar) {
        for (int i = 0; i != rLVar.j6(); i++) {
            this.f199j6.addElement(rLVar.j6(i));
        }
    }

    protected AbstractC0038FL(qL[] qLVarArr) {
        for (int i = 0; i != qLVarArr.length; i++) {
            this.f199j6.addElement(qLVarArr[i]);
        }
    }

    public static AbstractC0038FL m355j6(LL ll, boolean z) {
        if (z) {
            if (!ll.we()) {
                throw new IllegalArgumentException("object implicit - explicit expected.");
            }
            EL elU7 = ll.u7();
            elU7.DW();
            return m356j6((Object) elU7);
        }
        if (ll.we()) {
            return ll instanceof YL ? new UL(ll.u7()) : new EM(ll.u7());
        }
        if (ll.u7() instanceof AbstractC0038FL) {
            return (AbstractC0038FL) ll.u7();
        }
        throw new IllegalArgumentException("unknown object in getInstance: " + ll.getClass().getName());
    }

    public static AbstractC0038FL m356j6(Object obj) {
        if (obj == null || (obj instanceof AbstractC0038FL)) {
            return (AbstractC0038FL) obj;
        }
        if (obj instanceof InterfaceC0081GL) {
            return m356j6((Object) ((InterfaceC0081GL) obj).DW());
        }
        if (obj instanceof byte[]) {
            try {
                return m356j6((Object) EL.j6((byte[]) obj));
            } catch (IOException e) {
                throw new IllegalArgumentException("failed to construct sequence from byte[]: " + e.getMessage());
            }
        }
        if (obj instanceof qL) {
            EL elDW = ((qL) obj).DW();
            if (elDW instanceof AbstractC0038FL) {
                return (AbstractC0038FL) elDW;
            }
        }
        throw new IllegalArgumentException("unknown object in getInstance: " + obj.getClass().getName());
    }

    private qL m357j6(Enumeration enumeration) {
        return (qL) enumeration.nextElement();
    }

    public qL[] m358EQ() {
        qL[] qLVarArr = new qL[m364tp()];
        for (int i = 0; i != m364tp(); i++) {
            qLVarArr[i] = m362j6(i);
        }
        return qLVarArr;
    }

    EL m359VH() {
        tM tMVar = new tM();
        tMVar.f199j6 = this.f199j6;
        return tMVar;
    }

    boolean m360Zo() {
        return true;
    }

    EL m361gn() {
        EM em = new EM();
        em.f199j6 = this.f199j6;
        return em;
    }

    public int hashCode() {
        Enumeration enumerationM365u7 = m365u7();
        int iM364tp = m364tp();
        while (enumerationM365u7.hasMoreElements()) {
            iM364tp = (iM364tp * 17) ^ m357j6(enumerationM365u7).hashCode();
        }
        return iM364tp;
    }

    public qL m362j6(int i) {
        return (qL) this.f199j6.elementAt(i);
    }

    boolean m363j6(EL el) {
        if (!(el instanceof AbstractC0038FL)) {
            return false;
        }
        AbstractC0038FL abstractC0038FL = (AbstractC0038FL) el;
        if (m364tp() != abstractC0038FL.m364tp()) {
            return false;
        }
        Enumeration enumerationM365u7 = m365u7();
        Enumeration enumerationM365u8 = abstractC0038FL.m365u7();
        while (enumerationM365u7.hasMoreElements()) {
            qL qLVarM357j6 = m357j6(enumerationM365u7);
            qL qLVarM357j7 = m357j6(enumerationM365u8);
            EL elDW = qLVarM357j6.DW();
            EL elDW2 = qLVarM357j7.DW();
            if (elDW != elDW2 && !elDW.equals(elDW2)) {
                return false;
            }
        }
        return true;
    }

    public String toString() {
        return this.f199j6.toString();
    }

    public int m364tp() {
        return this.f199j6.size();
    }

    public Enumeration m365u7() {
        return this.f199j6.elements();
    }
}
