package abcd;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import com.aide.common.ma;
import com.aide.ui.U;
import java.math.BigInteger;
import java.util.Date;

@xu
public class C0003rh extends ma {

    @uu
    private static boolean f10VH;

    @InterfaceC0101tu
    private static boolean f11Zo;

    @InterfaceC0016ru(field = -3097312497375352368L)
    private String f12EQ;

    @InterfaceC0016ru(field = 1646899450280302640L)
    private a f13gn;

    @InterfaceC0016ru(field = 3714767747166659601L)
    private String f14tp;

    @InterfaceC0016ru(field = 1663393257271961853L)
    private CharSequence f15u7;

    public interface a {
        void m88j6(boolean z, String str);
    }

    static {
        wu.j6(C0003rh.class, 570958555126909067L, 570958555126909067L);
    }

    public C0003rh(String str, String str2, String str3, a aVar) {
        try {
            if (f11Zo) {
                wu.j6(-58103162200349085L, (Object) null, str, str2, str3, aVar);
            }
            this.f15u7 = str;
            this.f12EQ = str2;
            this.f14tp = str3;
            this.f13gn = aVar;
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -58103162200349085L, (Object) null, str, str2, str3, aVar);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 6889585926751959904L)
    public void m60DW(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-2921395968523535616L, this, alertDialog);
            }
            InputMethodManager inputMethodManager = (InputMethodManager) alertDialog.getContext().getSystemService("input_method");
            inputMethodManager.hideSoftInputFromWindow(m68U2(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m84v5(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m77j3(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m74aM(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m75er(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m61EQ(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m70Ws(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m64J0(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m83u7(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m80lg(alertDialog).getWindowToken(), 0);
            inputMethodManager.hideSoftInputFromWindow(m69VH(alertDialog).getWindowToken(), 0);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -2921395968523535616L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -2385989018343730425L)
    private EditText m61EQ(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-954561341241826065L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreName);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -954561341241826065L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -1427299092932691195L)
    public void m62FH(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(1327163876020088477L, this, alertDialog);
            }
            String strM66Mr = m66Mr(alertDialog);
            BigInteger bigInteger = BigInteger.ONE;
            String strM63Hw = m63Hw(alertDialog);
            U.j6(new qh(this, strM66Mr, m67QX(alertDialog), strM63Hw, m67QX(alertDialog), new Date(), new Date(System.currentTimeMillis() + (((long) m81rN(alertDialog)) * 31536000000L)), bigInteger, m82tp(alertDialog), m85we(alertDialog), m65J8(alertDialog), m76gn(alertDialog), m73a8(alertDialog), m72Zo(alertDialog)));
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 1327163876020088477L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -1051873170851904687L)
    private String m63Hw(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(39354419913805817L, this, alertDialog);
            }
            return m84v5(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 39354419913805817L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -2970835056011249893L)
    private EditText m64J0(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-3173741928503173101L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreOrganization);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -3173741928503173101L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 40081365516300291L)
    private String m65J8(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-1580144667537984053L, this, alertDialog);
            }
            return m70Ws(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -1580144667537984053L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 15549895966954180L)
    private String m66Mr(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-5122548082567647564L, this, alertDialog);
            }
            return m68U2(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -5122548082567647564L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 680720132582765184L)
    private String m67QX(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(813534989046649408L, this, alertDialog);
            }
            return m77j3(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 813534989046649408L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -2320893560256460623L)
    private EditText m68U2(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-922651158293970687L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystorePath);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -922651158293970687L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -1695426915671515776L)
    private EditText m69VH(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(1205083892986867056L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreCountry);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 1205083892986867056L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 2769040807497675256L)
    private EditText m70Ws(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-768590386549048032L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreOrganizationalUnit);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -768590386549048032L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 3366550914960961752L)
    private String m71XL(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-647006229061864208L, this, alertDialog);
            }
            return m74aM(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -647006229061864208L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 518173262568870417L)
    private String m72Zo(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-594061320860409207L, this, alertDialog);
            }
            return m69VH(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -594061320860409207L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -822389887291286556L)
    private String m73a8(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(112449284067021700L, this, alertDialog);
            }
            return m80lg(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 112449284067021700L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -3483383981477383305L)
    private EditText m74aM(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(2381288683859117063L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystorePassword2);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 2381288683859117063L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -1846300353548245272L)
    private EditText m75er(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-403346432161697728L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreValidity);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -403346432161697728L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 1313307645035191148L)
    private String m76gn(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(1148106482757580012L, this, alertDialog);
            }
            return m83u7(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 1148106482757580012L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 5538169492134630813L)
    private EditText m77j3(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-3539060210161209411L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystorePassword);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -3539060210161209411L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -2253710304931857511L)
    private EditText m80lg(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(533699287818600881L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreState);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 533699287818600881L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 2752373511361579575L)
    private int m81rN(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-1700181441206012625L, this, alertDialog);
            }
            try {
                return Integer.parseInt(m75er(alertDialog).getText().toString().trim());
            } catch (NumberFormatException unused) {
                return 0;
            }
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -1700181441206012625L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 588842031307012704L)
    private String m82tp(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(1232354463437978600L, this, alertDialog);
            }
            return m61EQ(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 1232354463437978600L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 2886593429845302861L)
    private EditText m83u7(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(3106608217135157805L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreLocation);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 3106608217135157805L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 46347621939896660L)
    private EditText m84v5(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(1917094992085727348L, this, alertDialog);
            }
            return (EditText) alertDialog.findViewById(com.aide.pro.R.id.createkeystoreAlias);
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 1917094992085727348L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -3080236751416757776L)
    private String m85we(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(-1316555455924435320L, this, alertDialog);
            }
            return m64J0(alertDialog).getText().toString().trim();
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, -1316555455924435320L, this, alertDialog);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = -2781519187215238224L)
    protected Dialog m86j6(Activity activity) {
        try {
            if (f11Zo) {
                wu.j6(1979613089118669400L, this, activity);
            }
            View viewInflate = LayoutInflater.from(activity).inflate(com.aide.pro.R.layout.createkeystore, (ViewGroup) null);
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle(com.aide.pro.R.string.dialog_title_create_keystore).setView(viewInflate).setCancelable(true).setPositiveButton(com.aide.pro.R.string.dialog_bt_create_keystore, (DialogInterface.OnClickListener) new mh(this)).setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) new lh(this));
            AlertDialog alertDialogCreate = builder.create();
            TextWatcher nhVar = new nh(this, alertDialogCreate);
            EditText editText = (EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystorePath);
            editText.addTextChangedListener(nhVar);
            EditText editText2 = (EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreAlias);
            editText2.addTextChangedListener(nhVar);
            EditText editText3 = (EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystorePassword);
            editText3.addTextChangedListener(nhVar);
            EditText editText4 = (EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystorePassword2);
            editText4.addTextChangedListener(nhVar);
            ((EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreValidity)).addTextChangedListener(nhVar);
            ((EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreName)).addTextChangedListener(nhVar);
            ((EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreOrganizationalUnit)).addTextChangedListener(nhVar);
            ((EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreOrganization)).addTextChangedListener(nhVar);
            ((EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreState)).addTextChangedListener(nhVar);
            ((EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreLocation)).addTextChangedListener(nhVar);
            ((EditText) viewInflate.findViewById(com.aide.pro.R.id.createkeystoreCountry)).addTextChangedListener(nhVar);
            editText.setText(this.f15u7);
            editText2.setText(this.f12EQ);
            editText3.setText(this.f14tp);
            editText4.setText(this.f14tp);
            alertDialogCreate.setOnShowListener(new oh(this));
            return alertDialogCreate;
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 1979613089118669400L, this, activity);
            }
            throw th;
        }
    }

    @InterfaceC0059su(method = 386151563015636465L)
    protected void m87j6(AlertDialog alertDialog) {
        try {
            if (f11Zo) {
                wu.j6(2639250644443242777L, this, alertDialog);
            }
            Button button = alertDialog.getButton(-1);
            if (button != null) {
                String strM66Mr = m66Mr(alertDialog);
                button.setEnabled(Vl.U2(strM66Mr) && !Vl.Hw(strM66Mr) && m82tp(alertDialog).length() > 0 && m81rN(alertDialog) >= 20 && m63Hw(alertDialog).length() > 0 && m67QX(alertDialog).length() >= 2 && m67QX(alertDialog).equals(m71XL(alertDialog)));
            }
        } catch (Throwable th) {
            if (f10VH) {
                wu.j6(th, 2639250644443242777L, this, alertDialog);
            }
            throw th;
        }
    }
}
