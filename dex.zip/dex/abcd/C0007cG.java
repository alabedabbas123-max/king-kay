package abcd;

public class C0007cG extends iG {
    protected C0007cG(YD yd) {
        super(yd);
    }

    public final int m45aM() {
        return 3;
    }

    void m46j6(qG qGVar) throws fD {
        if (!qGVar.DW.DW(this)) {
            throw new fD(this, m45aM());
        }
        ((iG) this).EQ |= 1;
    }
}
