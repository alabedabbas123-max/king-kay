package abcd;

import com.aide.engine.service.Native;

@xu
public class C0001Hd implements ra {

    @uu
    private static boolean f22DW;

    @tu
    private static boolean f23j6;

    @ru(field = 2185860116372735328L)
    private int f24BT;

    @ru(field = 3855311534835578211L)
    private int f25EQ;

    @ru(field = -355717794143175264L)
    private final Ba f26FH;

    @ru(field = 2370694176864096096L)
    private final Ga f27Hw;

    @ru(field = 4812791696074571373L)
    private int f28I;

    @ru(field = -5409817797813721528L)
    private int f29J0;

    @ru(field = -4520258140006426932L)
    private int f30J8;

    @ru(field = -7775995933624677095L)
    private int f31KD;

    @ru(field = -676922568627822067L)
    private int f32Mr;

    @ru(field = -5008399065669723839L)
    private int f33Mz;

    @ru(field = -2093976295205012100L)
    private int f34P8;

    @ru(field = -7926373800154485947L)
    private int f35QX;

    @ru(field = 524571899713247664L)
    private int f36Qq;

    @ru(field = -2062318871863901064L)
    private int f37SI;

    @ru(field = -5224546340440703328L)
    private int f38Sf;

    @ru(field = -3751563847929237693L)
    private int f39U2;

    @ru(field = -6430868340920584356L)
    private final boolean f40VH;

    @ru(field = -3031619243835197389L)
    private int f41Ws;

    @ru(field = -496776406879928439L)
    private int f42XL;

    @ru(field = -2415889179544105817L)
    private final boolean f43Zo;

    @ru(field = -5900086868821676211L)
    private int f44a8;

    @ru(field = 354869021199580720L)
    private int f45aM;

    @ru(field = -6637953879012014895L)
    private int f46ca;

    @ru(field = 517868100931334548L)
    private int f47cb;

    @ru(field = 2561424524617545691L)
    private int f48cn;

    @ru(field = 213071244165734448L)
    private int f49dx;

    @ru(field = -2949391963093977856L)
    private int f50ef;

    @ru(field = 4606573591707494232L)
    private int f51ei;

    @ru(field = 8911020497722883L)
    private int f52er;

    @ru(field = 1663247801238712409L)
    private int f53g3;

    @ru(field = 4360572212610294107L)
    private int f54gW;

    @ru(field = 4960938217857425979L)
    private int f55gn;

    @ru(field = -1940903551874132336L)
    private int f56j3;

    @ru(field = 2997174933707940533L)
    private int f57lg;

    @ru(field = 1162511896906227111L)
    private int f58nw;

    @ru(field = 1472900449567109640L)
    private int f59rN;

    @ru(field = 2166855551109944032L)
    private int f60ro;

    @ru(field = 3628334777956671033L)
    private int f61sG;

    @ru(field = 970077208792444395L)
    private int f62sh;

    @ru(field = -3386776932445323765L)
    private int f63tp;

    @ru(field = 4577023956995421280L)
    private int f64u7;

    @ru(field = 2236676134779574072L)
    private final na f65v5;

    @ru(field = 538455752255354115L)
    private int f66vJ;

    @ru(field = 5213631969351604393L)
    private int f67vy;

    @ru(field = -1168613131478470601L)
    private int f68we;

    @ru(field = 3623358105285785317L)
    private int f69x9;

    @ru(field = -5605704026381645197L)
    private int f70yS;

    static {
        wu.j6(C0001Hd.class, 422897820772727925L, 422897820772727925L);
    }

    public C0001Hd(La la, na naVar) {
        try {
            if (f23j6) {
                wu.j6(947856695163848625L, (Object) null, la, naVar);
            }
            this.f43Zo = true;
            this.f40VH = true;
            this.f26FH = la.a8;
            this.f27Hw = la.j3;
            this.f65v5 = naVar;
            this.f55gn = this.f27Hw.j6("length");
            this.f64u7 = this.f27Hw.j6("clone");
            this.f25EQ = this.f27Hw.j6("lang");
            this.f56j3 = this.f27Hw.j6("Array");
            this.f68we = this.f27Hw.j6("java");
            this.f30J8 = this.f27Hw.j6("Number");
            this.f42XL = this.f27Hw.j6("Boolean");
            this.f39U2 = this.f27Hw.j6("Long");
            this.f44a8 = this.f27Hw.j6("Integer");
            this.f57lg = this.f27Hw.j6("Short");
            this.f59rN = this.f27Hw.j6("Character");
            this.f52er = this.f27Hw.j6("Override");
            this.f70yS = this.f27Hw.j6("Byte");
            this.f54gW = this.f27Hw.j6("Float");
            this.f24BT = this.f27Hw.j6("Double");
            this.f67vy = this.f27Hw.j6("Void");
            this.f34P8 = this.f27Hw.j6("Cloneable");
            this.f51ei = this.f27Hw.j6("String");
            this.f58nw = this.f27Hw.j6("Class");
            this.f37SI = this.f27Hw.j6("Exception");
            this.f31KD = this.f27Hw.j6("Throwable");
            this.f60ro = this.f27Hw.j6("RuntimeException");
            this.f48cn = this.f27Hw.j6("Error");
            this.f29J0 = this.f27Hw.j6("System");
            this.f62sh = this.f27Hw.j6("getClass");
            this.f45aM = this.f27Hw.j6("Object");
            this.f32Mr = this.f27Hw.j6("Iterable");
            this.f41Ws = this.f27Hw.j6("util");
            this.f47cb = this.f27Hw.j6("Enum");
            this.f35QX = this.f27Hw.j6("Collection");
            this.f61sG = this.f27Hw.j6("io");
            this.f49dx = this.f27Hw.j6("Serializable");
            this.f63tp = this.f27Hw.j6("Invoke");
            this.f38Sf = this.f27Hw.j6("hashCode");
            this.f50ef = this.f27Hw.j6("equals");
            this.f66vJ = this.f27Hw.j6("finalize");
            this.f53g3 = this.f27Hw.j6("toString");
            this.f33Mz = this.f27Hw.j6("junit");
            this.f28I = this.f27Hw.j6("framework");
            this.f46ca = this.f27Hw.j6("TestCase");
            this.f69x9 = this.f27Hw.j6("package-info");
            this.f36Qq = this.f27Hw.j6("AutoCloseable");
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 947856695163848625L, (Object) null, la, naVar);
            }
            throw th;
        }
    }

    @su(method = 5016253434558866148L)
    private boolean m18EQ(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(-1401901710813751939L, this, da, ya, ya2);
            }
            if (!ya.cn() && !ya2.cn()) {
                return false;
            }
            C0127Kb c0127Kb = new C0127Kb();
            if (ya.P8() && ya2.P8() && m22j6(da, ya, ya2, c0127Kb)) {
                return true;
            }
            if (ya.P8()) {
                Yb ybSy = ((Oa) ya).sy();
                ybSy.Hw.DW();
                while (ybSy.Hw.j6()) {
                    Ya ya3 = (Ya) ybSy.Hw.FH();
                    c0127Kb.m1102j6();
                    if (ya3.P8() && ya2.P8() && m22j6(da, ya3, ya2, c0127Kb)) {
                        return true;
                    }
                }
            }
            if (ya.rN()) {
                Yb ybXa = ((ua) ya).Xa();
                ybXa.Hw.DW();
                while (ybXa.Hw.j6()) {
                    Ya ya4 = (Ya) ybXa.Hw.FH();
                    c0127Kb.m1102j6();
                    if (ya4.P8() && ya2.P8() && m22j6(da, ya4, ya2, c0127Kb)) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1401901710813751939L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    @su(method = 6437528051975317125L)
    private int m19j6(int i, int i2) {
        try {
            if (f23j6) {
                wu.j6(2297892959900356500L, this, new Integer(i), new Integer(i2));
            }
            return Native.j6.a(i, i2);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 2297892959900356500L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = -101723486906108151L)
    private Ya m20j6(Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(-3277141962448918464L, this, ya, ya2);
            }
            int iDx = ya.dx();
            int iDx2 = ya2.dx();
            int iM19j6 = m19j6(iDx, iDx2);
            if (iM19j6 == 7) {
                return m118we();
            }
            if (iM19j6 == iDx) {
                return ya;
            }
            if (iM19j6 == iDx2) {
                return ya2;
            }
            throw new jc();
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -3277141962448918464L, this, ya, ya2);
            }
            throw th;
        }
    }

    @su(method = 2831809058291934840L)
    private void m21j6(Da da, Yb<C0041Ia> yb, Ya ya, Ya[] yaArr, int i, int i2, Ya[] yaArr2, int i3, int i4, boolean z, boolean z2, Yb<C0041Ia> yb2) {
        if (f23j6) {
            wu.j6(4789692264060366025L, this, new Object[]{da, yb, ya, yaArr, new Integer(i), new Integer(i2), yaArr2, new Integer(i3), new Integer(i4), new Boolean(z), new Boolean(z2), yb2});
        }
        yb2.j6();
        ((Yb) yb).Hw.DW();
        while (((Yb) yb).Hw.j6()) {
            C0041Ia c0041Ia = (C0041Ia) ((Yb) yb).Hw.FH();
            if (m97j6(da, c0041Ia, ya, yaArr, i, i2, yaArr2, i3, i4, z, z2)) {
                yb2.DW(c0041Ia);
            }
        }
    }

    @su(method = 454533514552411896L)
    private boolean m22j6(Da da, Ya ya, Ya ya2, C0127Kb c0127Kb) {
        try {
            if (f23j6) {
                wu.j6(-314246750511830741L, this, da, ya, ya2, c0127Kb);
            }
            if (ya.BT()) {
                if (ya == ya2) {
                    return true;
                }
                if (c0127Kb.m1097DW(ya.EQ()) && c0127Kb.m1098FH(ya.EQ()) != ya2.EQ()) {
                    return false;
                }
                c0127Kb.m1096DW(ya.EQ(), ya2.EQ());
                return true;
            }
            if (ya2.BT()) {
                if (ya == ya2) {
                    return true;
                }
                if (c0127Kb.m1097DW(ya2.EQ()) && c0127Kb.m1098FH(ya2.EQ()) != ya.EQ()) {
                    return false;
                }
                c0127Kb.m1096DW(ya2.EQ(), ya.EQ());
                return true;
            }
            if (ya.lg() && ya2.lg()) {
                return m22j6(da, ((sa) ya).sy(), ((sa) ya2).sy(), c0127Kb);
            }
            if (!ya.P8() || !ya2.P8()) {
                return ya.FH(da, this.f65v5, ya2);
            }
            if (((Oa) ya).aj() != ((Oa) ya2).aj()) {
                return false;
            }
            int[] iArrQq = ((Oa) ya).Qq();
            int[] iArrQq2 = ((Oa) ya2).Qq();
            Ya[] yaArrX9 = ((Oa) ya).x9();
            Ya[] yaArrX10 = ((Oa) ya2).x9();
            for (int i = 0; i < iArrQq2.length; i++) {
                int i2 = iArrQq[i];
                if (i2 == 0) {
                    int i3 = iArrQq2[i];
                    if (i3 == 0) {
                        if (!m22j6(da, yaArrX9[i], yaArrX10[i], c0127Kb)) {
                            return false;
                        }
                    } else if (i3 == 1 || i3 == 2) {
                        if (!m22j6(da, yaArrX9[i], yaArrX10[i], c0127Kb)) {
                            return false;
                        }
                    } else if (i3 == 3 && !m22j6(da, yaArrX10[i], yaArrX9[i], c0127Kb)) {
                        return false;
                    }
                } else {
                    if (i2 == 1 || i2 == 2) {
                        int i4 = iArrQq2[i];
                        if (i4 != 0) {
                            if (i4 != 1 && i4 != 2) {
                                if (i4 == 3) {
                                    return false;
                                }
                            } else if (!m22j6(da, yaArrX9[i], yaArrX10[i], c0127Kb)) {
                            }
                        }
                        return false;
                    }
                    if (i2 == 3) {
                        int i5 = iArrQq2[i];
                        if (i5 == 0) {
                            return false;
                        }
                        if (i5 == 1 || i5 == 2) {
                            try {
                                return yaArrX10[i] == m58P8(da);
                            } catch (jc unused) {
                                continue;
                            }
                        } else if (i5 == 3 && !m22j6(da, yaArrX10[i], yaArrX9[i], c0127Kb)) {
                            return false;
                        }
                    }
                }
            }
            return true;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -314246750511830741L, this, da, ya, ya2, c0127Kb);
            }
            throw th;
        }
    }

    @su(method = -2821424207543381720L)
    private boolean m23tp(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(-1567721693838191187L, this, da, ya, ya2);
            }
            if (ya2.P8()) {
                if (ya.rN()) {
                    return !ya.Hw(da, this.f65v5, ya2);
                }
                if (ya.P8()) {
                    ua uaVarAj = ((Oa) ya).aj();
                    ua uaVarAj2 = ((Oa) ya2).aj();
                    Yb ybXa = uaVarAj2.Xa();
                    ybXa.Hw.DW();
                    while (ybXa.Hw.j6()) {
                        Oa oa = (Ya) ybXa.Hw.FH();
                        if (oa.P8() && oa.aj() == uaVarAj) {
                            int iJw = uaVarAj2.jw();
                            for (int i = 0; i < iJw; i++) {
                                try {
                                    if (!oa.j6(uaVarAj2.Hw(i))) {
                                        return true;
                                    }
                                } catch (jc unused) {
                                }
                            }
                        }
                    }
                }
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1567721693838191187L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    @su(method = -5919804066568158044L)
    private boolean m24u7(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(4107478050691590159L, this, da, ya, ya2);
            }
            return Native.j6.b(ya.dx(), ya2.dx());
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 4107478050691590159L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public ua m25BT(Da da) {
        try {
            if (f23j6) {
                wu.j6(-2301312434828420431L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f67vy, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -2301312434828420431L, this, da);
            }
            throw th;
        }
    }

    public long m26DW(String str) {
        try {
            if (f23j6) {
                wu.j6(-1646296287944574500L, this, str);
            }
            try {
                if (str.contains("_")) {
                    str = str.replace("_", "");
                }
                return this.f26FH.j6(Double.parseDouble(str));
            } catch (NumberFormatException unused) {
                throw new jc();
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1646296287944574500L, this, str);
            }
            throw th;
        }
    }

    public Ya m27DW(Da da, int i, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(3898847118397774920L, this, da, new Integer(i), ya, ya2);
            }
            try {
                switch (i) {
                    case 1:
                        if (ya != m75ei(da) || ya2.dx() == 1) {
                            return (ya2 != m75ei(da) || ya.dx() == 1) ? m87j6(da, i, ya, ya2) : ya2;
                        }
                        return ya;
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        return m87j6(da, i, ya, ya2);
                    case 6:
                    case 7:
                    case 8:
                        if (this.f43Zo && m46FH(ya)) {
                            ya = m28DW(da, ya);
                        }
                        if (this.f43Zo && m46FH(ya2)) {
                            ya2 = m28DW(da, ya2);
                        }
                        if (ya.dx() == 11) {
                            if (ya2.dx() == 11) {
                                return m113v5();
                            }
                            throw new jc();
                        }
                        if (ya2.dx() == 11) {
                            if (ya.dx() == 11) {
                                return m113v5();
                            }
                            throw new jc();
                        }
                        Ya yaM87j6 = m87j6(da, i, ya, ya2);
                        if (yaM87j6.dx() == 13) {
                            throw new jc();
                        }
                        if (yaM87j6.dx() != 14) {
                            return yaM87j6;
                        }
                        throw new jc();
                    case 9:
                    case 10:
                        if (m37DW(ya) != m37DW(ya2)) {
                            if (!this.f43Zo) {
                                throw new jc();
                            }
                            try {
                                if (!m37DW(ya)) {
                                    ya = m28DW(da, ya);
                                }
                                if (!m37DW(ya2)) {
                                    ya2 = m28DW(da, ya2);
                                }
                                return m27DW(da, i, ya, ya2);
                            } catch (jc unused) {
                            }
                        }
                        if (!ya.DW(da, this.f65v5, ya2) && !ya2.DW(da, this.f65v5, ya) && !ya.sh().DW(da, this.f65v5, ya2.sh()) && !ya2.sh().DW(da, this.f65v5, ya.sh())) {
                            throw new jc();
                        }
                        return m113v5();
                    case 11:
                    case 12:
                    case 13:
                    case 14:
                        m87j6(da, i, ya, ya2);
                        return m113v5();
                    case 15:
                    case 16:
                        if (this.f43Zo && m46FH(ya)) {
                            ya = m28DW(da, ya);
                        }
                        if (this.f43Zo && m46FH(ya2)) {
                            ya2 = m28DW(da, ya2);
                        }
                        if (ya.dx() != 11) {
                            throw new jc();
                        }
                        if (ya2.dx() == 11) {
                            return m113v5();
                        }
                        throw new jc();
                    case 17:
                    case 18:
                    case 19:
                        if (this.f43Zo && m46FH(ya)) {
                            ya = m28DW(da, ya);
                        }
                        if (this.f43Zo && m46FH(ya2)) {
                            ya2 = m28DW(da, ya2);
                        }
                        int iDx = ya2.dx();
                        if (iDx == 3 || iDx == 4 || iDx == 5 || iDx == 7 || iDx == 9 || iDx == 12) {
                            int iDx2 = ya.dx();
                            if (iDx2 != 3 && iDx2 != 4 && iDx2 != 5 && iDx2 != 7) {
                                if (iDx2 == 9) {
                                    return ya;
                                }
                                if (iDx2 == 12) {
                                }
                            }
                            return m118we();
                        }
                        throw new jc();
                    case 20:
                    case 21:
                    case 23:
                    case 24:
                    default:
                        throw new jc();
                    case 22:
                        if (ya2.FH(da, this.f65v5, ya)) {
                            return ya;
                        }
                        throw new jc();
                    case 25:
                    case 26:
                    case 27:
                    case 28:
                        if (m27DW(da, 3, ya, ya2).DW(da, this.f65v5, ya)) {
                            return ya;
                        }
                        throw new jc();
                    case 29:
                        if (m27DW(da, 1, ya, ya2).DW(da, this.f65v5, ya)) {
                            return ya;
                        }
                        throw new jc();
                    case 30:
                    case 31:
                    case 32:
                        if (m27DW(da, 7, ya, ya2).DW(da, this.f65v5, ya)) {
                            return ya;
                        }
                        throw new jc();
                    case 33:
                    case 34:
                    case 35:
                        if (m27DW(da, 17, ya, ya2).DW(da, this.f65v5, ya)) {
                            return ya;
                        }
                        throw new jc();
                }
            } catch (jc unused2) {
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 3898847118397774920L, this, da, new Integer(i), ya, ya2);
            }
            throw th;
        }
    }

    public Ya m28DW(Da da, Ya ya) {
        try {
            if (f23j6) {
                wu.j6(6202582094188052496L, this, da, ya);
            }
            if (ya == m79gn(da)) {
                return m113v5();
            }
            if (ya == m111u7(da)) {
                return m69Zo();
            }
            if (ya == m109tp(da)) {
                return m62VH();
            }
            if (ya == m76er(da)) {
                return m67XL();
            }
            if (ya == m74aM(da)) {
                return m118we();
            }
            if (ya == m57Mr(da)) {
                return m54J8();
            }
            if (ya == m68XL(da)) {
                return m38EQ();
            }
            if (ya == m53J0(da)) {
                return m108tp();
            }
            throw new jc();
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 6202582094188052496L, this, da, ya);
            }
            throw th;
        }
    }

    public Ya m29DW(Da da, Ya ya, Ya ya2) {
        Ya yaM28DW;
        Ya yaM28DW2;
        try {
            if (f23j6) {
                wu.j6(1086344541115759692L, this, da, ya, ya2);
            }
            if (ya.DW(ya2)) {
                return ya;
            }
            if (this.f43Zo && ya.dx() == 2 && m37DW(ya2)) {
                return m89j6(da, ya2);
            }
            if (this.f43Zo && ya2.dx() == 2 && m37DW(ya)) {
                return m89j6(da, ya);
            }
            int iDx = ya.dx();
            if (iDx == 3 || iDx == 4) {
                int iDx2 = ya2.dx();
                if (iDx2 != 5) {
                    return iDx2 != 12 ? m87j6(da, 9, ya, ya2) : m69Zo();
                }
                return m67XL();
            }
            if (iDx == 5) {
                int iDx3 = ya2.dx();
                return (iDx3 == 3 || iDx3 == 4 || iDx3 == 12) ? m67XL() : m87j6(da, 9, ya, ya2);
            }
            if (iDx != 7 && iDx != 9) {
                switch (iDx) {
                    case 12:
                        int iDx4 = ya2.dx();
                        if (iDx4 == 3 || iDx4 == 4) {
                            return m69Zo();
                        }
                        return iDx4 != 5 ? m87j6(da, 9, ya, ya2) : m67XL();
                    case 13:
                    case 14:
                        break;
                    default:
                        if (ya.dx() == 2 && m46FH(ya2)) {
                            return ya2;
                        }
                        if (ya2.dx() == 2 && m46FH(ya)) {
                            return ya;
                        }
                        if (ya.FH(da, this.f65v5, ya2)) {
                            return ya2;
                        }
                        if (ya2.FH(da, this.f65v5, ya)) {
                            return ya;
                        }
                        if (this.f43Zo) {
                            try {
                                yaM28DW = m46FH(ya) ? m28DW(da, ya) : ya;
                                break;
                            } catch (jc unused) {
                            }
                            try {
                                yaM28DW2 = m46FH(ya2) ? m28DW(da, ya2) : ya2;
                                break;
                            } catch (jc unused2) {
                            }
                            if (yaM28DW.FH(da, this.f65v5, yaM28DW2)) {
                                return yaM28DW2;
                            }
                            if (yaM28DW2.FH(da, this.f65v5, yaM28DW)) {
                                return yaM28DW;
                            }
                        }
                        if (this.f43Zo && ((ya.rN() || ya.P8()) && ((ya2.rN() || ya2.P8()) && ya.sh() == m39EQ(da) && ya2.sh() == m39EQ(da)))) {
                            return m39EQ(da).j6(new Ya[]{m58P8(da)}, new int[]{1});
                        }
                        if (this.f43Zo && m46FH(ya) && m46FH(ya2)) {
                            return ya.j6(da, this.f65v5, ya2);
                        }
                        if (this.f43Zo && m46FH(ya) && m37DW(ya2)) {
                            return ya.j6(da, this.f65v5, m89j6(da, ya2));
                        }
                        if (this.f43Zo && m37DW(ya) && m46FH(ya2)) {
                            return m89j6(da, ya).j6(da, this.f65v5, ya2);
                        }
                        throw new jc();
                }
            }
            return m87j6(da, 9, ya, ya2);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 1086344541115759692L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public ua m30DW(Da da) {
        try {
            if (f23j6) {
                wu.j6(100574493778771967L, this, da);
            }
            return m58P8(da);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 100574493778771967L, this, da);
            }
            throw th;
        }
    }

    public boolean m31DW() {
        try {
            if (!f23j6) {
                return true;
            }
            wu.j6(-202835989354801500L, this);
            return true;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -202835989354801500L, this);
            }
            throw th;
        }
    }

    public boolean m32DW(Da da, C0041Ia c0041Ia) {
        try {
            if (f23j6) {
                wu.j6(-233395373154865260L, this, da, c0041Ia);
            }
            ua uaVarM448FH = c0041Ia.m448FH();
            Yb<C0041Ia> ybM459Sf = c0041Ia.m459Sf();
            ((Yb) ybM459Sf).Hw.DW();
            while (((Yb) ybM459Sf).Hw.j6()) {
                if (!m34DW(da, uaVarM448FH, c0041Ia, (C0041Ia) ((Yb) ybM459Sf).Hw.FH())) {
                    return false;
                }
            }
            return true;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -233395373154865260L, this, da, c0041Ia);
            }
            throw th;
        }
    }

    public boolean m33DW(Da da, C0041Ia c0041Ia, C0041Ia c0041Ia2, Ya ya, int i) {
        try {
            if (f23j6) {
                wu.j6(111886137971088064L, this, da, c0041Ia, c0041Ia2, ya, new Integer(i));
            }
            if (this.f43Zo) {
                return m96j6(da, c0041Ia, c0041Ia2, ya, i) && !m96j6(da, c0041Ia2, c0041Ia, ya, i);
            }
            return m96j6(da, c0041Ia, c0041Ia2, ya, i);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 111886137971088064L, this, da, c0041Ia, c0041Ia2, ya, new Integer(i));
            }
            throw th;
        }
    }

    public boolean m34DW(Da da, ua uaVar, C0041Ia c0041Ia, C0041Ia c0041Ia2) {
        try {
            if (f23j6) {
                wu.j6(2619159873134866640L, this, da, uaVar, c0041Ia, c0041Ia2);
            }
            try {
                Ya yaGj = uaVar.Gj();
                if (!this.f43Zo) {
                    return c0041Ia2.m474ca().DW(c0041Ia.m474ca());
                }
                if (c0041Ia2.m474ca() == c0041Ia.m474ca()) {
                    return true;
                }
                Ya yaM446FH = c0041Ia.m446FH(yaGj);
                Ya yaM446FH2 = c0041Ia2.m446FH(yaGj);
                if (yaM446FH.j6(yaM446FH2, c0041Ia, c0041Ia2)) {
                    return true;
                }
                if (m46FH(yaM446FH)) {
                    return yaM446FH.I() ? yaM446FH.sh().FH(da, this.f65v5, yaM446FH2.sh()) : yaM446FH.FH(da, this.f65v5, yaM446FH2);
                }
                return false;
            } catch (jc unused) {
                return true;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 2619159873134866640L, this, da, uaVar, c0041Ia, c0041Ia2);
            }
            throw th;
        }
    }

    public boolean m35DW(Da da, ua uaVar, ua uaVar2) {
        try {
            if (f23j6) {
                wu.j6(-6273399176372828739L, this, da, uaVar, uaVar2);
            }
            if (uaVar == uaVar2 || uaVar2.v5(uaVar)) {
                return true;
            }
            if (uaVar2.w9()) {
                return m35DW(da, uaVar, uaVar2.FH());
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -6273399176372828739L, this, da, uaVar, uaVar2);
            }
            throw th;
        }
    }

    public boolean m36DW(C0041Ia c0041Ia) {
        try {
            if (f23j6) {
                wu.j6(-102616576541091063L, this, c0041Ia);
            }
            return c0041Ia.m521we() == this.f64u7 && c0041Ia.m519vJ() == 0;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -102616576541091063L, this, c0041Ia);
            }
            throw th;
        }
    }

    public boolean m37DW(Ya ya) {
        try {
            if (f23j6) {
                wu.j6(670826870382682035L, this, ya);
            }
            int iDx = ya.dx();
            return (iDx == 1 || iDx == 2 || iDx == 16) ? false : true;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 670826870382682035L, this, ya);
            }
            throw th;
        }
    }

    public Ra m38EQ() {
        try {
            if (f23j6) {
                wu.j6(2729335772747195904L, this);
            }
            return this.f26FH.j6(this.f65v5, 6);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 2729335772747195904L, this);
            }
            throw th;
        }
    }

    public ua m39EQ(Da da) {
        try {
            if (f23j6) {
                wu.j6(-2474784181664443309L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f58nw, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -2474784181664443309L, this, da);
            }
            throw th;
        }
    }

    public long m40FH(String str) {
        try {
            if (f23j6) {
                wu.j6(-1830947503020064065L, this, str);
            }
            try {
                if (str.contains("_")) {
                    str = str.replace("_", "");
                }
                return this.f26FH.j6(mc.j6() != null ? mc.j6().j6(str) : (float) Double.parseDouble(str));
            } catch (NumberFormatException unused) {
                throw new jc();
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1830947503020064065L, this, str);
            }
            throw th;
        }
    }

    public boolean m41FH() {
        try {
            if (f23j6) {
                wu.j6(-7479949753656937375L, this);
            }
            return this.f43Zo;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -7479949753656937375L, this);
            }
            throw th;
        }
    }

    public boolean m42FH(Da da) {
        try {
            if (f23j6) {
                wu.j6(3136904564310717485L, this, da);
            }
            try {
                return m106lg(da).FH(da, this.f65v5, this.f32Mr, true, 0, m106lg(da));
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 3136904564310717485L, this, da);
            }
            throw th;
        }
    }

    public boolean m43FH(Da da, Ya ya) {
        try {
            if (f23j6) {
                wu.j6(-173981183415309095L, this, da, ya);
            }
            return ya == m111u7(da) || ya == m109tp(da) || ya == m76er(da) || ya == m74aM(da) || ya == m57Mr(da);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -173981183415309095L, this, da, ya);
            }
            throw th;
        }
    }

    public boolean m44FH(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(337264750858714867L, this, da, ya, ya2);
            }
            if (this.f43Zo && m71Zo(da, ya, ya2)) {
                return true;
            }
            if (this.f43Zo && m51Hw(da, ya, ya2)) {
                return true;
            }
            try {
                if (ya2.DW(ya)) {
                    return true;
                }
                switch (ya.dx()) {
                    case 1:
                    case 11:
                        return false;
                    case 2:
                        return m46FH(ya2);
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 8:
                    case 9:
                    case 10:
                    case 12:
                    case 13:
                    case 14:
                        switch (ya2.dx()) {
                            case 3:
                            case 4:
                            case 5:
                            case 6:
                            case 7:
                            case 8:
                            case 9:
                            case 10:
                            case 12:
                            case 13:
                            case 14:
                                return true;
                            case 11:
                            default:
                                return false;
                        }
                    default:
                        if (!m46FH(ya2)) {
                            return false;
                        }
                        if (ya.cn()) {
                            ya = ya.cb();
                        }
                        if (ya2 == m58P8(da)) {
                            return true;
                        }
                        if (ya.g3() && (ya2.g3() || !ya2.ca())) {
                            return true;
                        }
                        if (ya2.g3() && !ya.ca()) {
                            return true;
                        }
                        if (!ya.rN()) {
                            if (ya.P8()) {
                                if (ya2.rN()) {
                                    return m44FH(da, ya.sh(), ya2);
                                }
                                if (ya2.P8()) {
                                    return m44FH(da, ya.sh(), ya2.sh());
                                }
                                return true;
                            }
                            if (ya.lg()) {
                                if (ya2.rN()) {
                                    if (ya2 == m119we(da) || ya2 == m70Zo(da)) {
                                        return true;
                                    }
                                } else {
                                    if (ya2.P8()) {
                                        return false;
                                    }
                                    if (ya2.lg()) {
                                        Ya yaSy = ((sa) ya).sy();
                                        if (!m46FH(yaSy)) {
                                            return false;
                                        }
                                        Ya yaSy2 = ((sa) ya2).sy();
                                        if (m46FH(yaSy2)) {
                                            return m44FH(da, yaSy, yaSy2);
                                        }
                                        return false;
                                    }
                                }
                            }
                            return true;
                        }
                        if (ya == m58P8(da)) {
                            return true;
                        }
                        if (ya2.rN()) {
                            if (((ua) ya).v5((ua) ya2) || ((ua) ya2).v5((ua) ya)) {
                                return true;
                            }
                        } else {
                            if (!ya2.lg()) {
                                if (ya2.P8()) {
                                    return m44FH(da, ya, ya2.sh());
                                }
                                return true;
                            }
                            if (ya == m119we(da) || ya == m70Zo(da)) {
                                return true;
                            }
                        }
                        return false;
                }
            } catch (jc unused) {
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 337264750858714867L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public boolean m45FH(C0041Ia c0041Ia) {
        try {
            if (f23j6) {
                wu.j6(172849194591025960L, this, c0041Ia);
            }
            if (c0041Ia.m511mb()) {
                return false;
            }
            int iM519vJ = c0041Ia.m519vJ();
            for (int i = 0; i < iM519vJ; i++) {
                try {
                    Ya yaM482gn = c0041Ia.m482gn(i);
                    if (yaM482gn.sh() != yaM482gn) {
                        return true;
                    }
                } catch (jc unused) {
                }
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 172849194591025960L, this, c0041Ia);
            }
            throw th;
        }
    }

    public boolean m46FH(Ya ya) {
        try {
            if (f23j6) {
                wu.j6(-511265486403527975L, this, ya);
            }
            int iDx = ya.dx();
            return (iDx == 1 || iDx == 2 || iDx != 16) ? false : true;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -511265486403527975L, this, ya);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0079 A[Catch: Throwable -> 0x0103, TryCatch #0 {Throwable -> 0x0103, blocks: (B:3:0x0007, B:5:0x000b, B:6:0x000e, B:8:0x0014, B:9:0x001a, B:11:0x0024, B:14:0x002e, B:16:0x0036, B:19:0x0040, B:21:0x0048, B:23:0x004f, B:25:0x0055, B:27:0x0063, B:29:0x0068, B:30:0x006d, B:31:0x0072, B:32:0x0073, B:33:0x0078, B:72:0x00fc, B:34:0x0079, B:37:0x0080, B:39:0x0086, B:47:0x00a0, B:48:0x00a5, B:49:0x00a6, B:50:0x00ab, B:51:0x00b0, B:52:0x00b1, B:53:0x00b6, B:55:0x00b9, B:56:0x00be, B:58:0x00c0, B:60:0x00c6, B:62:0x00d2, B:63:0x00d7, B:64:0x00dc, B:65:0x00dd, B:67:0x00e3, B:69:0x00f1, B:70:0x00f6, B:71:0x00fb), top: B:81:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:36:0x007f  */
    /* JADX WARN: Code duplicated, block: B:39:0x0086 A[Catch: Throwable -> 0x0103, TryCatch #0 {Throwable -> 0x0103, blocks: (B:3:0x0007, B:5:0x000b, B:6:0x000e, B:8:0x0014, B:9:0x001a, B:11:0x0024, B:14:0x002e, B:16:0x0036, B:19:0x0040, B:21:0x0048, B:23:0x004f, B:25:0x0055, B:27:0x0063, B:29:0x0068, B:30:0x006d, B:31:0x0072, B:32:0x0073, B:33:0x0078, B:72:0x00fc, B:34:0x0079, B:37:0x0080, B:39:0x0086, B:47:0x00a0, B:48:0x00a5, B:49:0x00a6, B:50:0x00ab, B:51:0x00b0, B:52:0x00b1, B:53:0x00b6, B:55:0x00b9, B:56:0x00be, B:58:0x00c0, B:60:0x00c6, B:62:0x00d2, B:63:0x00d7, B:64:0x00dc, B:65:0x00dd, B:67:0x00e3, B:69:0x00f1, B:70:0x00f6, B:71:0x00fb), top: B:81:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:41:0x0094  */
    /* JADX WARN: Code duplicated, block: B:43:0x0099  */
    /* JADX WARN: Code duplicated, block: B:55:0x00b9 A[Catch: Throwable -> 0x0103, TryCatch #0 {Throwable -> 0x0103, blocks: (B:3:0x0007, B:5:0x000b, B:6:0x000e, B:8:0x0014, B:9:0x001a, B:11:0x0024, B:14:0x002e, B:16:0x0036, B:19:0x0040, B:21:0x0048, B:23:0x004f, B:25:0x0055, B:27:0x0063, B:29:0x0068, B:30:0x006d, B:31:0x0072, B:32:0x0073, B:33:0x0078, B:72:0x00fc, B:34:0x0079, B:37:0x0080, B:39:0x0086, B:47:0x00a0, B:48:0x00a5, B:49:0x00a6, B:50:0x00ab, B:51:0x00b0, B:52:0x00b1, B:53:0x00b6, B:55:0x00b9, B:56:0x00be, B:58:0x00c0, B:60:0x00c6, B:62:0x00d2, B:63:0x00d7, B:64:0x00dc, B:65:0x00dd, B:67:0x00e3, B:69:0x00f1, B:70:0x00f6, B:71:0x00fb), top: B:81:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:86:0x00b1 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:0x00ab A[SYNTHETIC] */
    public long m47Hw(String str) {
        int i;
        int i2;
        int iDigit;
        try {
            if (f23j6) {
                wu.j6(-411528338342595320L, this, str);
            }
            if (str.contains("_")) {
                str = str.replace("_", "");
            }
            int i3 = 2;
            int i4 = 0;
            if (str.startsWith("0x") || str.startsWith("0X")) {
                while (i3 < str.length()) {
                    int i5 = i3 + 1;
                    int iDigit2 = Character.digit(str.charAt(i3), 16);
                    if (iDigit2 < 0) {
                        throw new jc();
                    }
                    i4 = (i4 * 16) + iDigit2;
                    i3 = i5;
                }
            } else if (str.startsWith("0b") || str.startsWith("0B")) {
                int i6 = 2;
                while (i6 < str.length()) {
                    int i7 = i6 + 1;
                    int iDigit3 = Character.digit(str.charAt(i6), 2);
                    if (iDigit3 < 0) {
                        throw new jc();
                    }
                    i4 = (i4 * 2) + iDigit3;
                    i6 = i7;
                }
            } else if (str.startsWith("0")) {
                int i8 = 1;
                if (str.length() > 1) {
                    while (i8 < str.length()) {
                        int i9 = i8 + 1;
                        int iDigit4 = Character.digit(str.charAt(i8), 8);
                        if (iDigit4 < 0) {
                            throw new jc();
                        }
                        if (((-536870912) & i4) != 0) {
                            throw new jc();
                        }
                        i4 = (i4 * 8) + iDigit4;
                        i8 = i9;
                    }
                } else {
                    if (str.length() > 0) {
                        throw new jc();
                    }
                    i = 0;
                    while (i4 < str.length()) {
                        i2 = i4 + 1;
                        iDigit = Character.digit(str.charAt(i4), 10);
                        if (iDigit >= 0) {
                            throw new jc();
                        }
                        if (i <= 214748364) {
                            throw new jc();
                        }
                        if (i == 214748364 && iDigit == 9) {
                            throw new jc();
                        }
                        i = (i * 10) + iDigit;
                        i4 = i2;
                    }
                    i4 = i;
                }
            } else {
                if (str.length() > 0) {
                    throw new jc();
                }
                i = 0;
                while (i4 < str.length()) {
                    i2 = i4 + 1;
                    iDigit = Character.digit(str.charAt(i4), 10);
                    if (iDigit >= 0) {
                        throw new jc();
                    }
                    if (i <= 214748364) {
                        throw new jc();
                    }
                    if (i == 214748364) {
                        throw new jc();
                    }
                    i = (i * 10) + iDigit;
                    i4 = i2;
                }
                i4 = i;
            }
            return this.f26FH.DW(i4);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -411528338342595320L, this, str);
            }
            throw th;
        }
    }

    public boolean m48Hw() {
        try {
            if (!f23j6) {
                return false;
            }
            wu.j6(148891811601863737L, this);
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 148891811601863737L, this);
            }
            throw th;
        }
    }

    public boolean m49Hw(Da da) {
        try {
            if (f23j6) {
                wu.j6(-572956165732160595L, this, da);
            }
            try {
                return m110u7().j6(da, this.f68we, true).j6(da, this.f41Ws, true).FH(da, this.f65v5, this.f35QX, true, 0, m106lg(da));
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -572956165732160595L, this, da);
            }
            throw th;
        }
    }

    public boolean m50Hw(Da da, Ya ya) {
        try {
            if (f23j6) {
                wu.j6(-1816087593783843765L, this, da, ya);
            }
            try {
                return (ya.FH(da, this.f65v5, m66Ws(da)) || ya.FH(da, this.f65v5, m107rN(da))) ? false : true;
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1816087593783843765L, this, da, ya);
            }
            throw th;
        }
    }

    public boolean m51Hw(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(-5689588592900839400L, this, da, ya, ya2);
            }
            try {
                if (m37DW(ya) && m46FH(ya2)) {
                    return m89j6(da, ya).FH(da, this.f65v5, ya2);
                }
                return false;
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -5689588592900839400L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public int m52J0() {
        try {
            if (f23j6) {
                wu.j6(5028736898365951803L, this);
            }
            return this.f55gn;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 5028736898365951803L, this);
            }
            throw th;
        }
    }

    public ua m53J0(Da da) {
        try {
            if (f23j6) {
                wu.j6(-201717445479253172L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f24BT, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -201717445479253172L, this, da);
            }
            throw th;
        }
    }

    public Ra m54J8() {
        try {
            if (f23j6) {
                wu.j6(-431355372832652352L, this);
            }
            return this.f26FH.j6(this.f65v5, 5);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -431355372832652352L, this);
            }
            throw th;
        }
    }

    public ua m55J8(Da da) {
        try {
            if (f23j6) {
                wu.j6(383658446940704160L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f47cb, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 383658446940704160L, this, da);
            }
            throw th;
        }
    }

    public int m56Mr() {
        try {
            if (f23j6) {
                wu.j6(6258289192686507659L, this);
            }
            return this.f62sh;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 6258289192686507659L, this);
            }
            throw th;
        }
    }

    public ua m57Mr(Da da) {
        try {
            if (f23j6) {
                wu.j6(140840785115382719L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f39U2, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 140840785115382719L, this, da);
            }
            throw th;
        }
    }

    public ua m58P8(Da da) {
        try {
            if (f23j6) {
                wu.j6(183262513288536416L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f45aM, true, 0, m110u7());
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 183262513288536416L, this, da);
            }
            throw th;
        }
    }

    public int m59QX() {
        try {
            if (f23j6) {
                wu.j6(63702468435394733L, this);
            }
            return this.f69x9;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 63702468435394733L, this);
            }
            throw th;
        }
    }

    public ua m60QX(Da da) {
        try {
            if (f23j6) {
                wu.j6(-2830472899996781756L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f37SI, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -2830472899996781756L, this, da);
            }
            throw th;
        }
    }

    public ua m61U2(Da da) {
        try {
            if (f23j6) {
                wu.j6(252591299745998400L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f45aM, true, 0, m110u7());
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 252591299745998400L, this, da);
            }
            throw th;
        }
    }

    public Ra m62VH() {
        try {
            if (f23j6) {
                wu.j6(2341789914925480240L, this);
            }
            return this.f26FH.j6(this.f65v5, 3);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 2341789914925480240L, this);
            }
            throw th;
        }
    }

    public ua m63VH(Da da) {
        try {
            if (f23j6) {
                wu.j6(293746845690287716L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f36Qq, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 293746845690287716L, this, da);
            }
            throw th;
        }
    }

    public boolean m64VH(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(-2259116821872606752L, this, da, ya, ya2);
            }
            return ya2.gW() || ya2.ei() || m23tp(da, ya, ya2);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -2259116821872606752L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public Ra m65Ws() {
        try {
            if (f23j6) {
                wu.j6(1347988151330109225L, this);
            }
            return this.f26FH.j6(this.f65v5, 9);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 1347988151330109225L, this);
            }
            throw th;
        }
    }

    public ua m66Ws(Da da) {
        try {
            if (f23j6) {
                wu.j6(-77143216730564001L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f48cn, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -77143216730564001L, this, da);
            }
            throw th;
        }
    }

    public Ra m67XL() {
        try {
            if (f23j6) {
                wu.j6(-851875001801430468L, this);
            }
            return this.f26FH.j6(this.f65v5, 2);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -851875001801430468L, this);
            }
            throw th;
        }
    }

    public ua m68XL(Da da) {
        try {
            if (f23j6) {
                wu.j6(1241282171875150071L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f54gW, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 1241282171875150071L, this, da);
            }
            throw th;
        }
    }

    public Ra m69Zo() {
        try {
            if (f23j6) {
                wu.j6(3676900032286353368L, this);
            }
            return this.f26FH.j6(this.f65v5, 1);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 3676900032286353368L, this);
            }
            throw th;
        }
    }

    public ua m70Zo(Da da) {
        try {
            if (f23j6) {
                wu.j6(1580907649352842944L, this, da);
            }
            return m110u7().j6(da, this.f68we, true).j6(da, this.f61sG, true).DW(da, this.f65v5, this.f49dx, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 1580907649352842944L, this, da);
            }
            throw th;
        }
    }

    public boolean m71Zo(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(791522069855529015L, this, da, ya, ya2);
            }
            try {
                if (!m37DW(ya2) || !m46FH(ya)) {
                    return false;
                }
                if (this.f40VH && ya == m61U2(da)) {
                    return true;
                }
                return m28DW(da, ya).FH(da, this.f65v5, ya2);
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 791522069855529015L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public ua m72a8(Da da) {
        try {
            if (f23j6) {
                wu.j6(-100680621250083425L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f52er, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -100680621250083425L, this, da);
            }
            throw th;
        }
    }

    public Ra m73aM() {
        try {
            if (f23j6) {
                wu.j6(1581031148865909999L, this);
            }
            return this.f26FH.j6(this.f65v5, 10);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 1581031148865909999L, this);
            }
            throw th;
        }
    }

    public ua m74aM(Da da) {
        try {
            if (f23j6) {
                wu.j6(-723890293947959535L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f44a8, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -723890293947959535L, this, da);
            }
            throw th;
        }
    }

    public ua m75ei(Da da) {
        try {
            if (f23j6) {
                wu.j6(-4072931506610024676L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f51ei, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -4072931506610024676L, this, da);
            }
            throw th;
        }
    }

    public ua m76er(Da da) {
        try {
            if (f23j6) {
                wu.j6(-3191057488582873267L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f57lg, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -3191057488582873267L, this, da);
            }
            throw th;
        }
    }

    public ua m77gW(Da da) {
        try {
            if (f23j6) {
                wu.j6(-4255699955177550399L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f31KD, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -4255699955177550399L, this, da);
            }
            throw th;
        }
    }

    public int m78gn() {
        try {
            if (f23j6) {
                wu.j6(-5047044231176646360L, this);
            }
            return this.f64u7;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -5047044231176646360L, this);
            }
            throw th;
        }
    }

    public ua m79gn(Da da) {
        try {
            if (f23j6) {
                wu.j6(629401065901844737L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f42XL, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 629401065901844737L, this, da);
            }
            throw th;
        }
    }

    public boolean m80gn(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(459257003538281931L, this, da, ya, ya2);
            }
            if (ya2.P8() && ya.rN()) {
                return ya.I() || !ya.Hw(da, this.f65v5, ya2);
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 459257003538281931L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public Ra m81j3() {
        try {
            if (f23j6) {
                wu.j6(-2614238087263873056L, this);
            }
            return this.f26FH.j6(this.f65v5, 8);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -2614238087263873056L, this);
            }
            throw th;
        }
    }

    public ua m82j3(Da da) {
        try {
            if (f23j6) {
                wu.j6(3497072737124753433L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f32Mr, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 3497072737124753433L, this, da);
            }
            throw th;
        }
    }

    public int m83j6(int i) {
        try {
            if (f23j6) {
                wu.j6(6795501511661500239L, this, i);
            }
            return Native.j6.c(i);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 6795501511661500239L, this, new Integer(i));
            }
            throw th;
        }
    }

    public int m84j6(Na na, int i) {
        try {
            if (!f23j6) {
                return 16;
            }
            wu.j6(-489125864656042688L, this, na, new Integer(i));
            return 16;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -489125864656042688L, this, na, new Integer(i));
            }
            throw th;
        }
    }

    public long m85j6(String str) {
        try {
            if (f23j6) {
                wu.j6(-1426544508690298467L, this, str);
            }
            return this.f26FH.DW(str.charAt(1));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1426544508690298467L, this, str);
            }
            throw th;
        }
    }

    public Ya m86j6(Da da, int i, Ya ya) {
        try {
            if (f23j6) {
                wu.j6(423096548385537792L, this, da, new Integer(i), ya);
            }
            if (this.f43Zo && m46FH(ya)) {
                ya = m28DW(da, ya);
            }
            if (i == 1 || i == 2) {
                int iDx = ya.dx();
                if (iDx != 3 && iDx != 4 && iDx != 5 && iDx != 7) {
                    if (iDx != 9) {
                        switch (iDx) {
                            case 12:
                                break;
                            case 13:
                            case 14:
                                break;
                            default:
                                throw new jc();
                        }
                    }
                    return ya;
                }
                return m118we();
            }
            if (i == 20) {
                int iDx2 = ya.dx();
                if (iDx2 != 3 && iDx2 != 4 && iDx2 != 5 && iDx2 != 7) {
                    if (iDx2 == 9) {
                        return ya;
                    }
                    if (iDx2 != 12) {
                        throw new jc();
                    }
                }
                return m118we();
            }
            if (i == 21) {
                if (ya.dx() == 11) {
                    return ya;
                }
                throw new jc();
            }
            if (i != 23 && i != 24) {
                throw new jc();
            }
            int iDx3 = ya.dx();
            if (iDx3 != 3 && iDx3 != 4 && iDx3 != 5 && iDx3 != 7 && iDx3 != 9) {
                switch (iDx3) {
                    case 12:
                    case 13:
                    case 14:
                        break;
                    default:
                        throw new jc();
                }
            }
            return ya;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 423096548385537792L, this, da, new Integer(i), ya);
            }
            throw th;
        }
    }

    public Ya m87j6(Da da, int i, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(-5525979960234323457L, this, da, new Integer(i), ya, ya2);
            }
            if (this.f43Zo && m46FH(ya)) {
                ya = m28DW(da, ya);
            }
            if (this.f43Zo && m46FH(ya2)) {
                ya2 = m28DW(da, ya2);
            }
            return m20j6(ya, ya2);
        } catch (Throwable th) {
            Ya ya3 = ya;
            Ya ya4 = ya2;
            if (f22DW) {
                wu.j6(th, -5525979960234323457L, this, da, new Integer(i), ya3, ya4);
            }
            throw th;
        }
    }

    public Ya m88j6(Da da, int i, Ya ya, Ya ya2, long j) {
        int iDx;
        int iDx2;
        try {
            if (f23j6) {
                wu.j6(-7251632342198880837L, this, da, new Integer(i), ya, ya2, new Long(j));
            }
            if (i != 22) {
                return m27DW(da, i, ya, ya2);
            }
            int iDx3 = ya.dx();
            if (iDx3 == 3) {
                int iDx4 = ya2.dx();
                if (iDx4 == 3 || iDx4 == 4 || iDx4 == 5 || iDx4 == 7 || iDx4 == 12) {
                    if (this.f26FH.Hw(j) > 127 || this.f26FH.Hw(j) < -128) {
                        throw new jc();
                    }
                    return ya;
                }
            } else if (iDx3 == 4) {
                int iDx5 = ya2.dx();
                if (iDx5 == 3 || iDx5 == 4 || iDx5 == 5 || iDx5 == 7 || iDx5 == 12) {
                    if (this.f26FH.Hw(j) > 255 || this.f26FH.Hw(j) < 0) {
                        throw new jc();
                    }
                    return ya;
                }
            } else if (iDx3 == 5) {
                int iDx6 = ya2.dx();
                if (iDx6 == 3 || iDx6 == 4 || iDx6 == 5 || iDx6 == 7 || iDx6 == 12) {
                    if (this.f26FH.Hw(j) > 32767 || this.f26FH.Hw(j) < -32768) {
                        throw new jc();
                    }
                    return ya;
                }
            } else if (iDx3 == 12 && ((iDx2 = ya2.dx()) == 3 || iDx2 == 4 || iDx2 == 5 || iDx2 == 7 || iDx2 == 12)) {
                if (this.f26FH.Hw(j) > 65535 || this.f26FH.Hw(j) < 0) {
                    throw new jc();
                }
                return ya;
            }
            if (ya2.FH(da, this.f65v5, ya)) {
                return ya;
            }
            if (this.f43Zo) {
                if (m51Hw(da, ya2, ya)) {
                    return ya;
                }
                try {
                    if (ya == m109tp(da)) {
                        int iDx7 = ya2.dx();
                        if (iDx7 == 3 || iDx7 == 4 || iDx7 == 5 || iDx7 == 7 || iDx7 == 12) {
                            if (this.f26FH.Hw(j) > 65535 || this.f26FH.Hw(j) < 0) {
                                throw new jc();
                            }
                            return ya;
                        }
                    } else if (ya == m109tp(da)) {
                        int iDx8 = ya2.dx();
                        if (iDx8 == 3 || iDx8 == 4 || iDx8 == 5 || iDx8 == 7 || iDx8 == 12) {
                            if (this.f26FH.Hw(j) > 32767 || this.f26FH.Hw(j) < -32768) {
                                throw new jc();
                            }
                            return ya;
                        }
                    } else if (ya == m111u7(da)) {
                        int iDx9 = ya2.dx();
                        if (iDx9 == 3 || iDx9 == 4 || iDx9 == 5 || iDx9 == 7 || iDx9 == 12) {
                            if (this.f26FH.Hw(j) > 127 || this.f26FH.Hw(j) < -128) {
                                throw new jc();
                            }
                            return ya;
                        }
                    } else if (ya == m76er(da) && ((iDx = ya2.dx()) == 3 || iDx == 4 || iDx == 5 || iDx == 7 || iDx == 12)) {
                        if (this.f26FH.Hw(j) > 32767 || this.f26FH.Hw(j) < -32768) {
                            throw new jc();
                        }
                        return ya;
                    }
                } catch (jc unused) {
                }
            }
            throw new jc();
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -7251632342198880837L, this, da, new Integer(i), ya, ya2, new Long(j));
            }
            throw th;
        }
    }

    public Ya m89j6(Da da, Ya ya) {
        try {
            if (f23j6) {
                wu.j6(-1342773364141417823L, this, da, ya);
            }
            int iDx = ya.dx();
            if (iDx == 3) {
                return m111u7(da);
            }
            if (iDx == 5) {
                return m76er(da);
            }
            if (iDx == 7) {
                return m74aM(da);
            }
            if (iDx == 9) {
                return m57Mr(da);
            }
            switch (iDx) {
                case 11:
                    return m79gn(da);
                case 12:
                    return m109tp(da);
                case 13:
                    return m68XL(da);
                case 14:
                    return m53J0(da);
                default:
                    throw new jc();
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1342773364141417823L, this, da, ya);
            }
            throw th;
        }
    }

    public Ya m90j6(Da da, Ya ya, Ya ya2, long j) {
        try {
            if (f23j6) {
                wu.j6(-435982975228674863L, this, da, ya, ya2, new Long(j));
            }
            if (ya2.dx() == 7) {
                int iDx = ya.dx();
                if (iDx != 3) {
                    if (iDx != 4) {
                        if (iDx != 5) {
                            if (iDx == 12 && this.f26FH.Hw(j) >= 0 && this.f26FH.Hw(j) <= 65535) {
                                return m62VH();
                            }
                        } else if (this.f26FH.Hw(j) >= -32768 && this.f26FH.Hw(j) <= 32767) {
                            return m67XL();
                        }
                    } else if (this.f26FH.Hw(j) >= 0 && this.f26FH.Hw(j) <= 255) {
                        return m69Zo();
                    }
                } else if (this.f26FH.Hw(j) >= -128 && this.f26FH.Hw(j) <= 127) {
                    return m69Zo();
                }
            }
            return m29DW(da, ya, ya2);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -435982975228674863L, this, da, ya, ya2, new Long(j));
            }
            throw th;
        }
    }

    public Yb<Ya> m91j6(Da da, sa saVar) {
        try {
            if (!f23j6) {
                return null;
            }
            wu.j6(271797098705915512L, this, da, saVar);
            return null;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 271797098705915512L, this, da, saVar);
            }
            throw th;
        }
    }

    public ua m92j6(Da da) {
        try {
            if (f23j6) {
                wu.j6(-2775294244048774175L, this, da);
            }
            return m58P8(da);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -2775294244048774175L, this, da);
            }
            throw th;
        }
    }

    public void m93j6(Da da, Yb<C0041Ia> yb, Ya ya, Ya[] yaArr, int i, int i2, Ya[] yaArr2, int i3, int i4, boolean z, Yb<C0041Ia> yb2) {
        if (f23j6) {
            wu.j6(-1556709956865746676L, this, new Object[]{da, yb, ya, yaArr, new Integer(i), new Integer(i2), yaArr2, new Integer(i3), new Integer(i4), new Boolean(z), yb2});
        }
        m21j6(da, yb, ya, yaArr, i, i2, yaArr2, i3, i4, true, true, yb2);
        if (yb2.Hw() == 0) {
            m21j6(da, yb, ya, yaArr, i, i2, yaArr2, i3, i4, false, true, yb2);
        }
        if (z) {
            return;
        }
        if (yb2.Hw() == 0) {
            m21j6(da, yb, ya, yaArr, i, i2, yaArr2, i3, i4, true, false, yb2);
        }
        if (yb2.Hw() == 0) {
            m21j6(da, yb, ya, yaArr, i, i2, yaArr2, i3, i4, false, false, yb2);
        }
    }

    public boolean m94j6() {
        try {
            if (!f23j6) {
                return false;
            }
            wu.j6(5325639814368072081L, this);
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 5325639814368072081L, this);
            }
            throw th;
        }
    }

    public boolean m95j6(Da da, C0041Ia c0041Ia) {
        try {
            if (f23j6) {
                wu.j6(517636193792481605L, this, da, c0041Ia);
            }
            ua uaVarM448FH = c0041Ia.m448FH();
            Yb<C0041Ia> ybM459Sf = c0041Ia.m459Sf();
            ((Yb) ybM459Sf).Hw.DW();
            while (((Yb) ybM459Sf).Hw.j6()) {
                if (!m100j6(da, uaVarM448FH, c0041Ia, (C0041Ia) ((Yb) ybM459Sf).Hw.FH())) {
                    return false;
                }
            }
            return true;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 517636193792481605L, this, da, c0041Ia);
            }
            throw th;
        }
    }

    public boolean m96j6(Da da, C0041Ia c0041Ia, C0041Ia c0041Ia2, Ya ya, int i) {
        try {
            if (f23j6) {
                wu.j6(-3355525528615597444L, this, da, c0041Ia, c0041Ia2, ya, new Integer(i));
            }
            try {
                int iM519vJ = c0041Ia.m519vJ();
                int iM519vJ2 = c0041Ia2.m519vJ();
                int i2 = 0;
                while (i2 < i) {
                    Ya yaM447FH = i2 >= iM519vJ ? c0041Ia.m447FH(ya, iM519vJ - 1) : c0041Ia.m447FH(ya, i2);
                    Ya yaM447FH2 = i2 >= iM519vJ2 ? c0041Ia2.m447FH(ya, iM519vJ2 - 1) : c0041Ia2.m447FH(ya, i2);
                    if ((yaM447FH.gW() || !yaM447FH2.gW()) && !yaM447FH.DW(yaM447FH2, c0041Ia, c0041Ia2)) {
                        if (i2 >= iM519vJ - 1 && c0041Ia.m457OW() && yaM447FH.lg()) {
                            yaM447FH = ((sa) yaM447FH).sy();
                        }
                        if (i2 >= iM519vJ2 - 1 && c0041Ia2.m457OW() && yaM447FH2.lg()) {
                            yaM447FH2 = ((sa) yaM447FH2).sy();
                        }
                        if (!m99j6(da, yaM447FH, yaM447FH2, false)) {
                            return false;
                        }
                    }
                    i2++;
                }
                return this.f43Zo || c0041Ia.m448FH().FH(da, this.f65v5, c0041Ia2.m448FH());
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -3355525528615597444L, this, da, c0041Ia, c0041Ia2, ya, new Integer(i));
            }
            throw th;
        }
    }

    public boolean m97j6(Da da, C0041Ia c0041Ia, Ya ya, Ya[] yaArr, int i, int i2, Ya[] yaArr2, int i3, int i4, boolean z, boolean z2) {
        int iM519vJ;
        int iM519vJ2;
        if (f23j6) {
            wu.j6(1105420854437800260L, this, new Object[]{da, c0041Ia, ya, yaArr, new Integer(i), new Integer(i2), yaArr2, new Integer(i3), new Integer(i4), new Boolean(z), new Boolean(z2)});
        }
        try {
            Ya yaCb = ya.cb();
            if ((i4 > 0 && c0041Ia.m437DW(yaCb) != i4) || i2 < (iM519vJ2 = (iM519vJ = c0041Ia.m519vJ()) - 1)) {
                return false;
            }
            if (i2 != iM519vJ && (z || !c0041Ia.m457OW())) {
                return false;
            }
            int i5 = iM519vJ2;
            if (m104j6(c0041Ia, yaCb, yaArr, i, i2)) {
                return false;
            }
            if (!z && c0041Ia.m457OW()) {
                for (int i6 = 0; i6 < i5; i6++) {
                    Ya yaM447FH = c0041Ia.m447FH(yaCb, i6);
                    if (c0041Ia.m437DW(yaCb) > 0) {
                        if (!m99j6(da, yaArr[i6 + i].cb().sh(), yaM447FH.sh(), z2)) {
                            return false;
                        }
                    } else if (!m99j6(da, yaArr[i6 + i].cb(), yaM447FH, z2)) {
                        return false;
                    }
                }
                sa saVarM447FH = c0041Ia.m447FH(yaCb, i5);
                if (!saVarM447FH.lg()) {
                    return false;
                }
                if (iM519vJ == i2 && m99j6(da, yaArr[i5 + i].cb(), (Ya) saVarM447FH, z2)) {
                    return true;
                }
                Ya yaSy = saVarM447FH.sy();
                if (yaSy.gW()) {
                    return true;
                }
                while (i5 < i2) {
                    if (!m99j6(da, yaArr[i5 + i].cb(), yaSy, z2)) {
                        return false;
                    }
                    i5++;
                }
                return true;
            }
            if (c0041Ia.m437DW(yaCb) > 0) {
                return c0041Ia.m441DW(da, this.f65v5, yaCb, yaArr, i, i2, yaArr2, i3, i4);
            }
            for (int i7 = 0; i7 < iM519vJ; i7++) {
                if (!m99j6(da, yaArr[i7 + i].cb(), c0041Ia.m447FH(yaCb, i7), z2)) {
                    if (this.f43Zo) {
                        boolean zI = yaCb.I();
                        for (int i8 = 0; i8 < iM519vJ; i8++) {
                            if (c0041Ia.m447FH(yaCb, i8).I()) {
                                zI = true;
                            }
                        }
                        if (zI) {
                            for (int i9 = 0; i9 < iM519vJ; i9++) {
                                Ya yaM447FH2 = c0041Ia.m447FH(yaCb, i9);
                                Ya yaSh = yaM447FH2.sh();
                                Ya yaCb2 = yaArr[i9 + i].cb();
                                Ya yaSh2 = yaCb2.sh();
                                if ((yaM447FH2.P8() && yaCb2.P8()) || !m99j6(da, yaSh2, yaSh, z2)) {
                                    return false;
                                }
                            }
                            return true;
                        }
                    }
                    return false;
                }
            }
            return true;
        } catch (jc unused) {
            return false;
        }
    }

    public boolean m98j6(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(446489800724943360L, this, da, ya, ya2);
            }
            if (this.f43Zo && m51Hw(da, ya, ya2)) {
                return true;
            }
            if ((this.f43Zo && m71Zo(da, ya, ya2)) || ya2.DW(ya) || m24u7(da, ya, ya2)) {
                return true;
            }
            if (ya.dx() == 2) {
                return m46FH(ya2);
            }
            try {
                if (ya2 == m58P8(da) && m46FH(ya)) {
                    return true;
                }
            } catch (jc unused) {
            }
            if (ya.lg()) {
                try {
                    if (ya2 == m119we(da) || ya2 == m70Zo(da)) {
                        return true;
                    }
                } catch (jc unused2) {
                }
                if (!ya2.lg() || ((sa) ya).Qq() != ((sa) ya2).Qq()) {
                    return false;
                }
                Ya yaSy = ((sa) ya).sy();
                Ya yaSy2 = ((sa) ya2).sy();
                if (yaSy2.DW(yaSy)) {
                    return true;
                }
                if (m46FH(yaSy) && m46FH(yaSy2)) {
                    return yaSy.FH(da, this.f65v5, yaSy2);
                }
                return false;
            }
            if (ya.rN()) {
                if (!ya2.rN()) {
                    if (ya2.P8()) {
                        if (ya == ((Oa) ya2).aj() || ya.Hw(da, this.f65v5, ya2) || ya.Hw(da, this.f65v5, ((Oa) ya2).aj())) {
                            return true;
                        }
                        if (ya.I() && ((ua) ya).v5(((Oa) ya2).aj())) {
                            return true;
                        }
                        return m18EQ(da, ya, ya2);
                    }
                    if (ya2.BT()) {
                        return true;
                    }
                } else if (((ua) ya).v5((ua) ya2)) {
                    return true;
                }
            } else if (!ya.P8()) {
                try {
                    if (ya.ei()) {
                        int iQq = ((Pa) ya).Qq();
                        for (int i = 0; i < iQq; i++) {
                            if (((Pa) ya).j6(i).FH(da, this.f65v5, ya2)) {
                                return true;
                            }
                        }
                    } else if (ya.gW()) {
                        int iM731x9 = ((C0083Ja) ya).m731x9();
                        for (int i2 = 0; i2 < iM731x9; i2++) {
                            if (((C0083Ja) ya).m722j6(i2).FH(da, this.f65v5, ya2)) {
                                return true;
                            }
                        }
                    } else if (ya.BT()) {
                        return m46FH(ya2);
                    }
                } catch (jc unused3) {
                }
            } else if (ya2.rN()) {
                ua uaVarAj = ((Oa) ya).aj();
                if (uaVarAj == ya2 || uaVarAj.CU().j6(ya2)) {
                    return true;
                }
            } else {
                if (ya2.P8()) {
                    if (ya.Hw(da, this.f65v5, ya2)) {
                        return true;
                    }
                    return m18EQ(da, ya, ya2);
                }
                if (ya2.BT()) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 446489800724943360L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public boolean m99j6(Da da, Ya ya, Ya ya2, boolean z) {
        try {
            if (f23j6) {
                wu.j6(4782067981148819979L, this, da, ya, ya2, new Boolean(z));
            }
            if (!z || m37DW(ya2) == m37DW(ya)) {
                return ya.FH(da, this.f65v5, ya2);
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 4782067981148819979L, this, da, ya, ya2, new Boolean(z));
            }
            throw th;
        }
    }

    public boolean m100j6(Da da, ua uaVar, C0041Ia c0041Ia, C0041Ia c0041Ia2) {
        try {
            if (f23j6) {
                wu.j6(2600089995632751621L, this, da, uaVar, c0041Ia, c0041Ia2);
            }
            try {
                Ya yaGj = uaVar.Gj();
                int iM475cb = c0041Ia.m475cb();
                int iM475cb2 = c0041Ia2.m475cb();
                for (int i = 0; i < iM475cb; i++) {
                    Ya yaM438DW = c0041Ia.m438DW(i);
                    if (m50Hw(da, yaM438DW)) {
                        int i2 = 0;
                        while (true) {
                            if (i2 >= iM475cb2) {
                                int i3 = 0;
                                while (true) {
                                    if (i3 >= iM475cb2) {
                                        if (this.f43Zo) {
                                            for (int i4 = 0; i4 < iM475cb2; i4++) {
                                                if (yaM438DW.j6(c0041Ia2.m487j6(i4, yaGj), c0041Ia, c0041Ia2)) {
                                                    break;
                                                }
                                            }
                                        }
                                        return false;
                                    }
                                    if (yaM438DW.FH(da, this.f65v5, c0041Ia2.m487j6(i3, yaGj))) {
                                        break;
                                    }
                                    i3++;
                                }
                            } else {
                                if (yaM438DW == c0041Ia2.m487j6(i2, yaGj)) {
                                    break;
                                }
                                i2++;
                            }
                        }
                    }
                }
                return true;
            } catch (jc unused) {
                return true;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 2600089995632751621L, this, da, uaVar, c0041Ia, c0041Ia2);
            }
            throw th;
        }
    }

    public boolean m101j6(Da da, ua uaVar, ua uaVar2) {
        try {
            if (f23j6) {
                wu.j6(-471089297573884425L, this, da, uaVar, uaVar2);
            }
            if (uaVar == uaVar2) {
                return true;
            }
            if (uaVar2.w9()) {
                return m101j6(da, uaVar, uaVar2.FH());
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -471089297573884425L, this, da, uaVar, uaVar2);
            }
            throw th;
        }
    }

    public boolean m102j6(C0041Ia c0041Ia) {
        try {
            if (f23j6) {
                wu.j6(4852037308337956972L, this, c0041Ia);
            }
            Yb<C0041Ia> ybM459Sf = c0041Ia.m459Sf();
            ((Yb) ybM459Sf).Hw.DW();
            while (((Yb) ybM459Sf).Hw.j6()) {
                if (!m103j6(c0041Ia, (C0041Ia) ((Yb) ybM459Sf).Hw.FH())) {
                    return false;
                }
            }
            return true;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 4852037308337956972L, this, c0041Ia);
            }
            throw th;
        }
    }

    public boolean m103j6(C0041Ia c0041Ia, C0041Ia c0041Ia2) {
        try {
            if (f23j6) {
                wu.j6(-5708438154857869325L, this, c0041Ia, c0041Ia2);
            }
            int iM465XL = c0041Ia2.m465XL();
            int iM465XL2 = c0041Ia.m465XL();
            if (Ma.XL(iM465XL) || Ma.aM(iM465XL) != Ma.aM(iM465XL2)) {
                return false;
            }
            if (Ma.J8(iM465XL)) {
                return Ma.J8(iM465XL2);
            }
            if (Ma.gn(iM465XL)) {
                return true;
            }
            if (Ma.J0(iM465XL)) {
                return Ma.J8(iM465XL2) || Ma.J0(iM465XL2);
            }
            return !Ma.gn(iM465XL2);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -5708438154857869325L, this, c0041Ia, c0041Ia2);
            }
            throw th;
        }
    }

    public boolean m104j6(C0041Ia c0041Ia, Ya ya, Ya[] yaArr, int i, int i2) {
        Ya yaDW;
        try {
            if (f23j6) {
                wu.j6(568845868685567352L, this, c0041Ia, ya, yaArr, new Integer(i), new Integer(i2));
            }
            if (!ya.rN()) {
                if (ya.P8()) {
                    yaDW = ((Oa) ya).aj().DW(c0041Ia);
                }
                return false;
            }
            yaDW = ((ua) ya).DW(c0041Ia);
            int iM519vJ = c0041Ia.m519vJ();
            for (int i3 = 0; i3 < iM519vJ; i3++) {
                try {
                    Ya yaM482gn = c0041Ia.m482gn(i3);
                    if (yaM482gn.ei() && yaDW.P8() && ya.P8()) {
                        Pa paJ6 = ((Oa) yaDW).j6(yaM482gn, false);
                        if (paJ6.ei() && paJ6.sy() == ((Oa) ya).aj() && ((((Oa) ya).Qq()[paJ6.x9()] == 2 || ((Oa) ya).Qq()[paJ6.x9()] == 1) && i2 > i3 && yaArr[i + i3].dx() != 2)) {
                            return true;
                        }
                    }
                } catch (jc unused) {
                }
            }
            return false;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 568845868685567352L, this, c0041Ia, ya, yaArr, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m105j6(Ya ya) {
        try {
            if (f23j6) {
                wu.j6(4510619099607252291L, this, ya);
            }
            return (ya.XL() & 536870912) != 0;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 4510619099607252291L, this, ya);
            }
            throw th;
        }
    }

    public Na m106lg(Da da) {
        try {
            if (f23j6) {
                wu.j6(-3625422009915968381L, this, da);
            }
            return m110u7().j6(da, this.f68we, true).j6(da, this.f25EQ, true);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -3625422009915968381L, this, da);
            }
            throw th;
        }
    }

    public ua m107rN(Da da) {
        try {
            if (f23j6) {
                wu.j6(2307048071158434960L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f60ro, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 2307048071158434960L, this, da);
            }
            throw th;
        }
    }

    public Ra m108tp() {
        try {
            if (f23j6) {
                wu.j6(4475491407319704247L, this);
            }
            return this.f26FH.j6(this.f65v5, 7);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 4475491407319704247L, this);
            }
            throw th;
        }
    }

    public ua m109tp(Da da) {
        try {
            if (f23j6) {
                wu.j6(2705714331141893280L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f59rN, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 2705714331141893280L, this, da);
            }
            throw th;
        }
    }

    public Na m110u7() {
        try {
            if (f23j6) {
                wu.j6(632518917573756248L, this);
            }
            return this.f26FH.FH();
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 632518917573756248L, this);
            }
            throw th;
        }
    }

    public ua m111u7(Da da) {
        try {
            if (f23j6) {
                wu.j6(-1955764027069214361L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f70yS, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1955764027069214361L, this, da);
            }
            throw th;
        }
    }

    public long m112v5(String str) {
        long j;
        try {
            if (f23j6) {
                wu.j6(114249266945786133L, this, str);
            }
            if (str.contains("_")) {
                str = str.replace("_", "");
            }
            int i = 2;
            if (str.startsWith("0x") || str.startsWith("0X")) {
                j = 0;
                while (i < str.length() - 1) {
                    int i2 = i + 1;
                    int iDigit = Character.digit(str.charAt(i), 16);
                    if (iDigit < 0) {
                        throw new jc();
                    }
                    j = (j * 16) + ((long) iDigit);
                    i = i2;
                }
            } else if (str.startsWith("0b") || str.startsWith("0B")) {
                j = 0;
                int i3 = 2;
                while (i3 < str.length() - 1) {
                    int i4 = i3 + 1;
                    int iDigit2 = Character.digit(str.charAt(i3), 2);
                    if (iDigit2 < 0) {
                        throw new jc();
                    }
                    j = (j * 2) + ((long) iDigit2);
                    i3 = i4;
                }
            } else if (str.startsWith("0") && str.length() > 1) {
                j = 0;
                int i5 = 1;
                while (i5 < str.length() - 1) {
                    int i6 = i5 + 1;
                    int iDigit3 = Character.digit(str.charAt(i5), 8);
                    if (iDigit3 < 0) {
                        throw new jc();
                    }
                    if (((-2305843009213693952L) & j) != 0) {
                        throw new jc();
                    }
                    j = (j * 8) + ((long) iDigit3);
                    i5 = i6;
                }
            } else {
                if (str.length() <= 0) {
                    throw new jc();
                }
                int i7 = 0;
                j = 0;
                while (i7 < str.length() - 1) {
                    int i8 = i7 + 1;
                    int iDigit4 = Character.digit(str.charAt(i7), 10);
                    if (iDigit4 < 0) {
                        throw new jc();
                    }
                    if (j > 922337203685477580L) {
                        throw new jc();
                    }
                    if (j == 922337203685477580L && iDigit4 == 9) {
                        throw new jc();
                    }
                    j = (j * 10) + ((long) iDigit4);
                    i7 = i8;
                }
            }
            this.f26FH.Zo(j);
            return j;
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 114249266945786133L, this, str);
            }
            throw th;
        }
    }

    public Ra m113v5() {
        try {
            if (f23j6) {
                wu.j6(-1194237711927369948L, this);
            }
            return this.f26FH.j6(this.f65v5, 0);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1194237711927369948L, this);
            }
            throw th;
        }
    }

    public ua m114v5(Da da) {
        try {
            if (f23j6) {
                wu.j6(-150917889851504357L, this, da);
            }
            return m110u7().j6(da, this.f33Mz, true).j6(da, this.f28I, true).DW(da, this.f65v5, this.f46ca, true, 0, m110u7());
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -150917889851504357L, this, da);
            }
            throw th;
        }
    }

    public boolean m115v5(Da da, Ya ya) {
        try {
            if (f23j6) {
                wu.j6(-7647613301286101929L, this, da, ya);
            }
            try {
                return ya.FH(da, this.f65v5, m77gW(da));
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -7647613301286101929L, this, da, ya);
            }
            throw th;
        }
    }

    public boolean m116v5(Da da, Ya ya, Ya ya2) {
        try {
            if (f23j6) {
                wu.j6(-1439883094543351217L, this, da, ya, ya2);
            }
            if (m37DW(ya) && m37DW(ya2)) {
                return true;
            }
            if (!this.f43Zo) {
                return false;
            }
            if (!m37DW(ya) && !m37DW(ya2)) {
                return false;
            }
            try {
                if (this.f43Zo && m46FH(ya)) {
                    ya = m28DW(da, ya);
                }
                if (this.f43Zo && m46FH(ya2)) {
                    m28DW(da, ya2);
                }
                return true;
            } catch (jc unused) {
                return false;
            }
        } catch (Throwable th) {
            Ya ya3 = ya;
            if (f22DW) {
                wu.j6(th, -1439883094543351217L, this, da, ya3, ya2);
            }
            throw th;
        }
    }

    public ua m117vy(Da da) {
        try {
            if (f23j6) {
                wu.j6(188291633364736153L, this, da);
            }
            return m110u7().j6(da, this.f68we, true).j6(da, this.f41Ws, true).DW(da, this.f65v5, this.f35QX, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, 188291633364736153L, this, da);
            }
            throw th;
        }
    }

    public Ra m118we() {
        try {
            if (f23j6) {
                wu.j6(-1014366696405269025L, this);
            }
            return this.f26FH.j6(this.f65v5, 4);
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -1014366696405269025L, this);
            }
            throw th;
        }
    }

    public ua m119we(Da da) {
        try {
            if (f23j6) {
                wu.j6(-854734630643648640L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f34P8, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -854734630643648640L, this, da);
            }
            throw th;
        }
    }

    public ua m120yS(Da da) {
        try {
            if (f23j6) {
                wu.j6(-2063283123764537020L, this, da);
            }
            return m106lg(da).DW(da, this.f65v5, this.f51ei, true, 0, m106lg(da));
        } catch (Throwable th) {
            if (f22DW) {
                wu.j6(th, -2063283123764537020L, this, da);
            }
            throw th;
        }
    }
}
