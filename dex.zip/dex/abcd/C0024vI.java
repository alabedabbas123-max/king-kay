package abcd;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;

public class C0024vI implements ZI {

    private final HJ f49DW;

    private final Session f50j6;

    private class a extends Process {

        private final int f51DW;

        private InputStream f52FH;

        private OutputStream f53Hw;

        private ChannelExec f55j6;

        private InputStream f56v5;

        private a(String str, int i) throws yD {
            this.f51DW = i;
            try {
                this.f55j6 = C0024vI.this.f50j6.FH("exec");
                this.f55j6.DW(str);
                m100DW();
                this.f55j6.j6(this.f51DW > 0 ? this.f51DW * 1000 : 0);
                if (this.f55j6.J0()) {
                } else {
                    throw new yD(C0024vI.this.f49DW, "connection failed");
                }
            } catch (JSchException e) {
                throw new yD(C0024vI.this.f49DW, e.getMessage(), e);
            }
        }

        a(C0024vI c0024vI, String str, int i, a aVar) {
            this(str, i);
        }

        private void m100DW() {
            this.f52FH = this.f55j6.gn();
            OutputStream outputStreamU7 = this.f55j6.u7();
            if (this.f51DW <= 0) {
                this.f53Hw = outputStreamU7;
            } else {
                PipedInputStream pipedInputStream = new PipedInputStream();
                YK yk = new YK(pipedInputStream, outputStreamU7);
                uI uIVar = new uI(this, pipedInputStream, yk);
                yk.start();
                this.f53Hw = uIVar;
            }
            this.f56v5 = this.f55j6.aM();
        }

        private boolean m102j6() {
            return this.f55j6.Zo() < 0 && this.f55j6.J0();
        }

        @Override
        public void destroy() {
            if (this.f55j6.J0()) {
                this.f55j6.DW();
            }
        }

        @Override
        public int exitValue() {
            if (m102j6()) {
                throw new IllegalStateException();
            }
            return this.f55j6.Zo();
        }

        @Override
        public InputStream getErrorStream() {
            return this.f56v5;
        }

        @Override
        public InputStream getInputStream() {
            return this.f52FH;
        }

        @Override
        public OutputStream getOutputStream() {
            return this.f53Hw;
        }

        @Override
        public int waitFor() throws InterruptedException {
            while (m102j6()) {
                Thread.sleep(100L);
            }
            return exitValue();
        }
    }

    public C0024vI(Session session, HJ hj) {
        this.f50j6 = session;
        this.f49DW = hj;
    }

    public void disconnect() {
        if (this.f50j6.tp()) {
            this.f50j6.j6();
        }
    }

    public Channel m98j6() {
        return this.f50j6.FH("sftp");
    }

    public Process m99j6(String str, int i) {
        return new a(this, str, i, null);
    }
}
