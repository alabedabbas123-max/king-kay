package abcd;

public abstract class AbstractC0025CC {
    public abstract int m123j6();
}
