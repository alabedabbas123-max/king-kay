package abcd;

@xu
class C0005oc extends AbstractC0048pc {

    @uu
    private static boolean f31Zo;

    @tu
    private static boolean f32v5;

    static {
        wu.j6(C0005oc.class, 6961425216133458609L, -362198004114028544L);
    }

    C0005oc() {
    }

    @Override
    @su(method = -665451922478599980L)
    public boolean mo20j6(String str, String str2) {
        try {
            if (f32v5) {
                wu.j6(2838271493419175280L, this, str, str2);
            }
            return str.toLowerCase().endsWith(str2.substring(1, str2.length()).toLowerCase());
        } catch (Throwable th) {
            if (f31Zo) {
                wu.j6(th, 2838271493419175280L, this, str, str2);
            }
            throw th;
        }
    }
}
