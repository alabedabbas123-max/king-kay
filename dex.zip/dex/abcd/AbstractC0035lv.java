package abcd;

import com.appfour.backbone.api.objects.EventData;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class AbstractC0035lv extends jw implements com.appfour.backbone.api.runtime.a {

    private Object f272v5;

    @FunctionalInterface
    public interface a {
        EventData getValue();
    }

    public EventData m228j6(Object obj, a aVar) {
        try {
            this.f272v5 = obj;
            return aVar.getValue();
        } finally {
            this.f272v5 = null;
        }
    }

    public Class<?> m229j6(long j) {
        return Ev.j6(j);
    }

    public <T> T m230j6(Class<T> cls) {
        return (T) Ev.j6(this.f272v5, cls);
    }

    public Object m231j6(Object obj, long j, long j2) {
        try {
            Field fieldJ6 = Ev.j6(j, j2);
            if (fieldJ6 == null) {
                throw new IllegalAccessError("Field not found");
            }
            fieldJ6.setAccessible(true);
            return fieldJ6.get(obj);
        } catch (Exception e) {
            throw new IllegalAccessError(e.getMessage());
        }
    }

    public Object m232j6(Object obj, Object[] objArr, long j, long j2) {
        try {
            Method methodDW = Ev.DW(j, j2);
            if (methodDW != null) {
                methodDW.setAccessible(true);
                return methodDW.invoke(obj, objArr);
            }
        } catch (Exception unused) {
        }
        throw new IllegalAccessError("Invocation failed");
    }

    public boolean m233j6(Object obj, long j) {
        return Ev.DW(obj, j);
    }
}
