package abcd;

import com.appfour.backbone.api.closures.OnEnterClosure5;
import com.appfour.backbone.api.objects.EventData;

class C0012Tu implements lv.a {

    final Object[] f27DW;

    final C0055Uu f28FH;

    final Object f29j6;

    C0012Tu(C0055Uu c0055Uu, Object obj, Object[] objArr) {
        this.f28FH = c0055Uu;
        this.f29j6 = obj;
        this.f27DW = objArr;
    }

    public EventData getValue() {
        OnEnterClosure5 onEnterClosure5 = this.f28FH.f137DW;
        Object obj = this.f29j6;
        Object[] objArr = this.f27DW;
        return onEnterClosure5.getValue(obj, objArr[1], objArr[2], objArr[3], objArr[4], objArr[5]);
    }
}
