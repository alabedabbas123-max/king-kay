package abcd;

enum C0016Eq extends er {
    C0016Eq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
