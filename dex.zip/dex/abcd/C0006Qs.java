package abcd;

import java.util.HashMap;

public final class C0006Qs implements InterfaceC0048Rs, Comparable<C0006Qs> {

    public static final C0006Qs f15BT;

    public static final C0006Qs f20J0;

    public static final C0006Qs f21J8;

    public static final C0006Qs f22KD;

    public static final C0006Qs f23Mr;

    public static final C0006Qs f24P8;

    public static final C0006Qs f25QX;

    public static final C0006Qs f26SI;

    public static final C0006Qs f27U2;

    public static final C0006Qs f29Ws;

    public static final C0006Qs f30XL;

    public static final C0006Qs f32a8;

    public static final C0006Qs f33aM;

    public static final C0006Qs f34cn;

    public static final C0006Qs f35ei;

    public static final C0006Qs f36er;

    public static final C0006Qs f37gW;

    public static final C0006Qs f39j3;

    public static final C0006Qs f41lg;

    public static final C0006Qs f42nw;

    public static final C0006Qs f43rN;

    public static final C0006Qs f44ro;

    public static final C0006Qs f45sh;

    public static final C0006Qs f49vy;

    public static final C0006Qs f51yS;

    private C0006Qs f52Sf;

    private final String f53cb;

    private final int f54dx;

    private String f55ef;

    private C0006Qs f56g3;

    private final int f57sG;

    private C0006Qs f58vJ;

    private static final HashMap<String, C0006Qs> f40j6 = new HashMap<>(500);

    public static final C0006Qs f16DW = new C0006Qs("Z", 1);

    public static final C0006Qs f18FH = new C0006Qs("B", 2);

    public static final C0006Qs f19Hw = new C0006Qs("C", 3);

    public static final C0006Qs f48v5 = new C0006Qs("D", 4);

    public static final C0006Qs f31Zo = new C0006Qs("F", 5);

    public static final C0006Qs f28VH = new C0006Qs("I", 6);

    public static final C0006Qs f38gn = new C0006Qs("J", 7);

    public static final C0006Qs f47u7 = new C0006Qs("S", 8);

    public static final C0006Qs f46tp = new C0006Qs("V", 0);

    public static final C0006Qs f17EQ = new C0006Qs("<null>", 9);

    public static final C0006Qs f50we = new C0006Qs("<addr>", 10);

    static {
        m41DW(f16DW);
        m41DW(f18FH);
        m41DW(f19Hw);
        m41DW(f48v5);
        m41DW(f31Zo);
        m41DW(f28VH);
        m41DW(f38gn);
        m41DW(f47u7);
        f20J0 = m44j6("Ljava/lang/annotation/Annotation;");
        f21J8 = m44j6("Ljava/lang/Class;");
        f29Ws = m44j6("Ljava/lang/Cloneable;");
        f25QX = m44j6("Ljava/lang/Object;");
        f30XL = m44j6("Ljava/io/Serializable;");
        f33aM = m44j6("Ljava/lang/String;");
        f39j3 = m44j6("Ljava/lang/Throwable;");
        f23Mr = m44j6("Ljava/lang/Boolean;");
        f27U2 = m44j6("Ljava/lang/Byte;");
        f32a8 = m44j6("Ljava/lang/Character;");
        f41lg = m44j6("Ljava/lang/Double;");
        f43rN = m44j6("Ljava/lang/Float;");
        f36er = m44j6("Ljava/lang/Integer;");
        f51yS = m44j6("Ljava/lang/Long;");
        f37gW = m44j6("Ljava/lang/Short;");
        f15BT = m44j6("Ljava/lang/Void;");
        f49vy = f16DW.m46Hw();
        f24P8 = f18FH.m46Hw();
        f35ei = f19Hw.m46Hw();
        f42nw = f48v5.m46Hw();
        f26SI = f31Zo.m46Hw();
        f22KD = f28VH.m46Hw();
        f44ro = f38gn.m46Hw();
        f34cn = f25QX.m46Hw();
        f45sh = f47u7.m46Hw();
    }

    private C0006Qs(String str, int i) {
        this(str, i, -1);
    }

    private C0006Qs(String str, int i, int i2) {
        if (str == null) {
            throw new NullPointerException("descriptor == null");
        }
        if (i < 0 || i >= 11) {
            throw new IllegalArgumentException("bad basicType");
        }
        if (i2 < -1) {
            throw new IllegalArgumentException("newAt < -1");
        }
        this.f53cb = str;
        this.f54dx = i;
        this.f57sG = i2;
        this.f52Sf = null;
        this.f58vJ = null;
        this.f56g3 = null;
    }

    private static C0006Qs m41DW(C0006Qs c0006Qs) {
        synchronized (f40j6) {
            String strM47J8 = c0006Qs.m47J8();
            C0006Qs c0006Qs2 = f40j6.get(strM47J8);
            if (c0006Qs2 != null) {
                return c0006Qs2;
            }
            f40j6.put(strM47J8, c0006Qs);
            return c0006Qs;
        }
    }

    public static C0006Qs m42DW(String str) {
        if (str == null) {
            throw new NullPointerException("name == null");
        }
        if (str.startsWith("[")) {
            return m44j6(str);
        }
        return m44j6('L' + str + ';');
    }

    public static C0006Qs m43FH(String str) {
        try {
            return str.equals("V") ? f46tp : m44j6(str);
        } catch (NullPointerException unused) {
            throw new NullPointerException("descriptor == null");
        }
    }

    public static C0006Qs m44j6(String str) {
        C0006Qs c0006Qs;
        synchronized (f40j6) {
            c0006Qs = f40j6.get(str);
        }
        if (c0006Qs != null) {
            return c0006Qs;
        }
        try {
            char cCharAt = str.charAt(0);
            if (cCharAt == '[') {
                return m44j6(str.substring(1)).m46Hw();
            }
            int length = str.length();
            if (cCharAt == 'L') {
                int i = length - 1;
                if (str.charAt(i) == ';') {
                    for (int i2 = 1; i2 < i; i2++) {
                        char cCharAt2 = str.charAt(i2);
                        if (cCharAt2 != '(' && cCharAt2 != ')' && cCharAt2 != '.') {
                            if (cCharAt2 == '/') {
                                if (i2 == 1 || i2 == i || str.charAt(i2 - 1) == '/') {
                                    throw new IllegalArgumentException("bad descriptor: " + str);
                                }
                            } else if (cCharAt2 == ';' || cCharAt2 == '[') {
                            }
                        }
                        throw new IllegalArgumentException("bad descriptor: " + str);
                    }
                    return m41DW(new C0006Qs(str, 9));
                }
            }
            throw new IllegalArgumentException("bad descriptor: " + str);
        } catch (IndexOutOfBoundsException unused) {
            throw new IllegalArgumentException("descriptor is empty");
        } catch (NullPointerException unused2) {
            throw new NullPointerException("descriptor == null");
        }
    }

    public boolean m45BT() {
        switch (this.f54dx) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
                return true;
            default:
                return false;
        }
    }

    public C0006Qs m46Hw() {
        if (this.f52Sf == null) {
            this.f52Sf = m41DW(new C0006Qs('[' + this.f53cb, 9));
        }
        return this.f52Sf;
    }

    public String m47J8() {
        return this.f53cb;
    }

    @Override
    public int mo48Mr() {
        int i = this.f54dx;
        if (i == 1 || i == 2 || i == 3 || i == 6 || i == 8) {
            return 6;
        }
        return i;
    }

    public boolean m49P8() {
        return this.f57sG >= 0;
    }

    @Override
    public C0006Qs mo50U2() {
        int i = this.f54dx;
        return (i == 1 || i == 2 || i == 3 || i == 6 || i == 8) ? f28VH : this;
    }

    public String m51VH() {
        if (this.f55ef == null) {
            if (!m63vy()) {
                throw new IllegalArgumentException("not an object type: " + this.f53cb);
            }
            if (this.f53cb.charAt(0) == '[') {
                this.f55ef = this.f53cb;
            } else {
                String str = this.f53cb;
                this.f55ef = str.substring(1, str.length() - 1);
            }
        }
        return this.f55ef;
    }

    public C0006Qs m52Ws() {
        C0006Qs c0006Qs = this.f56g3;
        if (c0006Qs != null) {
            return c0006Qs;
        }
        throw new IllegalArgumentException("initialized type: " + this.f53cb);
    }

    public int m53Zo() {
        int i = this.f54dx;
        return (i == 4 || i == 7) ? 2 : 1;
    }

    @Override
    public boolean mo54a8() {
        return false;
    }

    public String m55aM() {
        switch (this.f54dx) {
            case 0:
                return "void";
            case 1:
                return "boolean";
            case 2:
                return "byte";
            case 3:
                return "char";
            case 4:
                return "double";
            case 5:
                return "float";
            case 6:
                return "int";
            case 7:
                return "long";
            case 8:
                return "short";
            case 9:
                if (!m61lg()) {
                    return m51VH().replace("/", ".");
                }
                return m64we().m55aM() + "[]";
            default:
                return this.f53cb;
        }
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0006Qs) {
            return this.f53cb.equals(((C0006Qs) obj).f53cb);
        }
        return false;
    }

    public boolean m56er() {
        int i = this.f54dx;
        return (i == 4 || i == 7) ? false : true;
    }

    public boolean m57gW() {
        int i = this.f54dx;
        return i == 1 || i == 2 || i == 3 || i == 6 || i == 8;
    }

    @Override
    public C0006Qs getType() {
        return this;
    }

    public int hashCode() {
        return this.f53cb.hashCode();
    }

    @Override
    public int mo58j3() {
        return this.f54dx;
    }

    @Override
    public int compareTo(C0006Qs c0006Qs) {
        return this.f53cb.compareTo(c0006Qs.f53cb);
    }

    public C0006Qs m60j6(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("newAt < 0");
        }
        if (!m63vy()) {
            throw new IllegalArgumentException("not a reference type: " + this.f53cb);
        }
        if (m49P8()) {
            throw new IllegalArgumentException("already uninitialized: " + this.f53cb);
        }
        C0006Qs c0006Qs = new C0006Qs('N' + Yt.v5(i) + this.f53cb, 9, i);
        c0006Qs.f56g3 = this;
        return m41DW(c0006Qs);
    }

    public boolean m61lg() {
        return this.f53cb.charAt(0) == '[';
    }

    public boolean m62rN() {
        return m61lg() || equals(f17EQ);
    }

    public String toString() {
        return this.f53cb;
    }

    public boolean m63vy() {
        return this.f54dx == 9;
    }

    public C0006Qs m64we() {
        if (this.f58vJ == null) {
            if (this.f53cb.charAt(0) != '[') {
                throw new IllegalArgumentException("not an array type: " + this.f53cb);
            }
            this.f58vJ = m44j6(this.f53cb.substring(1));
        }
        return this.f58vJ;
    }

    public boolean m65yS() {
        int i = this.f54dx;
        return i == 4 || i == 7;
    }
}
