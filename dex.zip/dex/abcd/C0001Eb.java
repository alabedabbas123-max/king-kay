package abcd;

@xu
class C0001Eb {
    static {
        wu.j6(C0001Eb.class, 322898086603826664L, -2154024114230876931L);
    }
}
