package abcd;

class C0013yH {

    static final b<C0013yH> f23j6 = new xH();

    private final int f24DW;

    private final boolean f25FH;

    private final boolean f26Hw;

    private C0013yH(gE gEVar) {
        this.f24DW = ((jE) gEVar.j6(jE.j6)).j6();
        this.f25FH = gEVar.j6("core", "fsyncobjectfiles", false);
        this.f26Hw = gEVar.j6("core", "fsyncreffiles", false);
    }

    C0013yH(gE gEVar, C0013yH c0013yH) {
        this(gEVar);
    }

    boolean m42DW() {
        return this.f25FH;
    }

    boolean m43FH() {
        return this.f26Hw;
    }

    int m44j6() {
        return this.f24DW;
    }
}
