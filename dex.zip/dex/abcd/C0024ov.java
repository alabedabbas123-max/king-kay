package abcd;

import com.appfour.backbone.api.closures.OnTouchClosure;
import com.appfour.backbone.api.objects.EventData;
import com.appfour.backbone.api.objects.UserTouchAction;

class C0024ov implements jv {

    final Bv f368DW;

    final OnTouchClosure f369j6;

    C0024ov(Bv bv, OnTouchClosure onTouchClosure) {
        this.f368DW = bv;
        this.f369j6 = onTouchClosure;
    }

    public EventData m100j6(Object[] objArr) {
        return this.f369j6.getValue((UserTouchAction) objArr[0]);
    }
}
