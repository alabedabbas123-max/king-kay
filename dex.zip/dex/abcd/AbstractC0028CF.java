package abcd;

public abstract class AbstractC0028CF extends wF {

    private mG f93gn;

    protected AbstractC0028CF(UE ue) {
        super(ue);
    }

    public void m127DW(YD yd) {
        if (yd != null) {
            this.f93gn = ((wF) this).FH.gn(yd);
        } else {
            this.f93gn = null;
        }
    }

    public boolean m128j6(YD... ydArr) {
        if (ydArr.length != 2) {
            return false;
        }
        return super.j6(ydArr);
    }

    protected TJ m129v5() {
        mG mGVar = this.f93gn;
        return mGVar != null ? j6(mGVar) : DW(0, 1);
    }
}
