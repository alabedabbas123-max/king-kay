package abcd;

@xu
public class C0024ie implements ga {

    @uu
    private static boolean f95DW;

    @tu
    private static boolean f96j6;

    @ru(field = -2457218520314231219L)
    private final Ca f97FH;

    @ru(field = -2121646051574835371L)
    private final Ga f98Hw;

    @ru(field = -387692083319208915L)
    private Wb f99VH;

    @ru(field = 362066278402030291L)
    private Sa f100Zo;

    @ru(field = 884599727032315696L)
    private int f101gn;

    @ru(field = 363864991901141100L)
    private boolean f102v5;

    static {
        wu.j6(C0024ie.class, -6303342884220565261L, -6303342884220565261L);
    }

    public C0024ie(Ca ca, Ga ga) {
        try {
            if (f96j6) {
                wu.j6(4532839849691056320L, (Object) null, ca, ga);
            }
            this.f97FH = ca;
            this.f98Hw = ga;
            this.f99VH = new Wb();
            this.f101gn = ga.j6("xmlns");
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 4532839849691056320L, (Object) null, ca, ga);
            }
            throw th;
        }
    }

    @su(method = -4175114510377022997L)
    private void m97DW(int i) {
        try {
            if (f96j6) {
                wu.j6(-1416187240993763056L, this, i);
            }
            if (this.f100Zo.P8(i) == 18 || this.f100Zo.P8(i) == 14) {
                m103j6(i);
            }
            int iWe = this.f100Zo.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m97DW(this.f100Zo.Zo(i, i2));
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -1416187240993763056L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 264670858506603315L)
    private void m98FH(int i) {
        try {
            if (f96j6) {
                wu.j6(-316926377553091236L, this, i);
            }
            if (this.f100Zo.P8(i) != 218) {
                for (int i2 = 0; i2 < this.f100Zo.we(i); i2++) {
                    m98FH(this.f100Zo.Zo(i, i2));
                }
                return;
            }
            int iZo = this.f100Zo.Zo(i, 0);
            int iZo2 = this.f100Zo.Zo(i, 2);
            int iEr = this.f100Zo.er(i);
            if (this.f100Zo.P8(iEr) == 203) {
                if (this.f100Zo.XL(iZo) == this.f101gn) {
                    this.f99VH.j6(this.f100Zo.XL(iZo2), iEr);
                    this.f100Zo.v5(iZo2, 4, iEr);
                } else if (this.f100Zo.XL(iZo) == this.f98Hw.j6("") && this.f100Zo.XL(iZo2) == this.f101gn) {
                    this.f99VH.j6(this.f98Hw.j6(""), iEr);
                    this.f100Zo.v5(iZo, 4, iEr);
                }
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -316926377553091236L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -4347713830487704192L)
    private void m99Hw(int i) {
        try {
            if (f96j6) {
                wu.j6(1496776533644234979L, this, i);
            }
            int iP8 = this.f100Zo.P8(i);
            if (iP8 == 217) {
                int iZo = this.f100Zo.Zo(i, 0);
                this.f100Zo.Zo(i, 2);
                int iP9 = this.f100Zo.P8(this.f100Zo.er(i));
                if ((iP9 == 200 || iP9 == 201 || iP9 == 207) && this.f99VH.j6(this.f100Zo.XL(iZo))) {
                    this.f100Zo.v5(iZo, 5, this.f99VH.DW(this.f100Zo.XL(iZo)));
                    return;
                }
                return;
            }
            if (iP8 != 218) {
                for (int i2 = 0; i2 < this.f100Zo.we(i); i2++) {
                    m99Hw(this.f100Zo.Zo(i, i2));
                }
                return;
            }
            int iZo2 = this.f100Zo.Zo(i, 0);
            int iZo3 = this.f100Zo.Zo(i, 2);
            if (this.f100Zo.P8(this.f100Zo.er(i)) == 203 && this.f100Zo.XL(iZo2) != this.f101gn) {
                if ((this.f100Zo.XL(iZo2) == this.f98Hw.j6("") && this.f100Zo.XL(iZo3) == this.f101gn) || this.f100Zo.XL(iZo2) == this.f98Hw.j6("") || !this.f99VH.j6(this.f100Zo.XL(iZo2))) {
                    return;
                }
                this.f100Zo.v5(iZo2, 5, this.f99VH.DW(this.f100Zo.XL(iZo2)));
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 1496776533644234979L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 1875900523109946235L)
    private void m100VH(int i) {
        try {
            if (f96j6) {
                wu.j6(644393957173794152L, this, i);
            }
            this.f97FH.j6(this.f100Zo.VH(), this.f100Zo.J8(), this.f100Zo.vy(i), this.f100Zo.BT(i), this.f100Zo.QX(i), this.f100Zo.Ws(i), "", "Delete");
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 644393957173794152L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 2515049541353134453L)
    private void m101Zo(int i) {
        try {
            if (f96j6) {
                wu.j6(-4339375957432340520L, this, i);
            }
            int iP8 = this.f100Zo.P8(i);
            if (iP8 != 50) {
                if (iP8 == 200 && this.f100Zo.XG(i)) {
                    int iZo = this.f100Zo.Zo(i, 1);
                    int iXL = this.f100Zo.XL(this.f100Zo.Zo(iZo, 0));
                    int iXL2 = this.f100Zo.XL(this.f100Zo.Zo(iZo, 2));
                    int iZo2 = this.f100Zo.Zo(this.f100Zo.er(i), 2);
                    m105j6(iZo2, "Unexpected closing tag </" + (iXL == this.f98Hw.j6("") ? this.f98Hw.j6(iXL2) : this.f98Hw.j6(iXL) + ":" + this.f98Hw.j6(iXL2)) + ">");
                    m100VH(iZo2);
                }
            } else if (!this.f100Zo.XG(i)) {
                int iP9 = this.f100Zo.P8(this.f100Zo.er(i));
                if (iP9 == 203) {
                    m105j6(i, "Invalid character in attribute name");
                } else if (iP9 == 204) {
                    m105j6(i, "Invalid character in attribute value");
                    m102gn(i);
                }
            }
            for (int i2 = 0; i2 < this.f100Zo.we(i); i2++) {
                m101Zo(this.f100Zo.Zo(i, i2));
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -4339375957432340520L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -374554006911359640L)
    private void m102gn(int i) {
        try {
            if (f96j6) {
                wu.j6(162441715432599911L, this, i);
            }
            this.f97FH.j6(this.f100Zo.VH(), this.f100Zo.J8(), this.f100Zo.vy(i), this.f100Zo.BT(i), this.f100Zo.QX(i), this.f100Zo.Ws(i), '\"' + this.f98Hw.j6(this.f100Zo.XL(i)) + '\"', "Surround with quotes");
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 162441715432599911L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 7855499971035481257L)
    private void m103j6(int i) {
        try {
            if (f96j6) {
                wu.j6(-7176068216373796388L, this, i);
            }
            try {
                if (this.f100Zo.U2(i) == 9) {
                    if (this.f100Zo.Mr(i)[this.f100Zo.a8(i)] == '#') {
                        m104j6(i, (int) Long.parseLong(this.f100Zo.lg(i).substring(1), 16));
                    }
                } else if (this.f100Zo.U2(i) == 7 && this.f100Zo.Mr(i)[this.f100Zo.a8(i)] == '#') {
                    m104j6(i, (-16777216) | ((int) Long.parseLong(this.f100Zo.lg(i).substring(1), 16)));
                }
            } catch (Exception unused) {
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -7176068216373796388L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 1645507869708877225L)
    private void m104j6(int i, int i2) {
        try {
            if (f96j6) {
                wu.j6(-262769859159566724L, this, new Integer(i), new Integer(i2));
            }
            this.f97FH.j6(this.f100Zo.VH(), this.f100Zo.J8(), this.f100Zo.vy(i), this.f100Zo.BT(i), this.f100Zo.QX(i), this.f100Zo.Ws(i), i2);
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -262769859159566724L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = -3802245027703540623L)
    private void m105j6(int i, String str) {
        try {
            if (f96j6) {
                wu.j6(6481589472545114560L, this, new Integer(i), str);
            }
            this.f97FH.DW(this.f100Zo.VH(), this.f100Zo.J8(), this.f100Zo.vy(i), this.f100Zo.BT(i), this.f100Zo.QX(i), this.f100Zo.Ws(i), str, 0);
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 6481589472545114560L, this, new Integer(i), str);
            }
            throw th;
        }
    }

    @su(method = -1465376136458753895L)
    private void m106v5(int i) {
        try {
            if (f96j6) {
                wu.j6(4098308378943511932L, this, i);
            }
            int iP8 = this.f100Zo.P8(i);
            int i2 = 0;
            if (iP8 == 200 || iP8 == 201) {
                for (int i3 = 0; i3 < this.f100Zo.we(i); i3++) {
                    m98FH(this.f100Zo.Zo(i, i3));
                }
                while (i2 < this.f100Zo.we(i)) {
                    m99Hw(this.f100Zo.Zo(i, i2));
                    i2++;
                }
                return;
            }
            if (iP8 != 211) {
                while (i2 < this.f100Zo.we(i)) {
                    m106v5(this.f100Zo.Zo(i, i2));
                    i2++;
                }
            } else {
                this.f99VH.DW();
                while (i2 < this.f100Zo.we(i)) {
                    m106v5(this.f100Zo.Zo(i, i2));
                    i2++;
                }
                this.f99VH.FH();
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 4098308378943511932L, this, new Integer(i));
            }
            throw th;
        }
    }

    public void m107DW(Sa sa) {
        try {
            if (f96j6) {
                wu.j6(5534975060369763700L, this, sa);
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 5534975060369763700L, this, sa);
            }
            throw th;
        }
    }

    public void m108DW(Sa sa, int i) {
        try {
            if (f96j6) {
                wu.j6(-2565173158668832005L, this, sa, new Integer(i));
            }
            m111Hw(sa);
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -2565173158668832005L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    public void m109FH(Sa sa) {
        try {
            if (f96j6) {
                wu.j6(-680506452741300768L, this, sa);
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -680506452741300768L, this, sa);
            }
            throw th;
        }
    }

    public void m110FH(Sa sa, int i) {
        try {
            if (f96j6) {
                wu.j6(-2231287000311332457L, this, sa, new Integer(i));
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -2231287000311332457L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    public void m111Hw(Sa sa) {
        try {
            if (f96j6) {
                wu.j6(-3278294815952505024L, this, sa);
            }
            try {
                this.f100Zo = sa;
                m106v5(sa.aM());
                this.f100Zo = null;
            } finally {
                this.f99VH.j6();
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -3278294815952505024L, this, sa);
            }
            throw th;
        }
    }

    public Ya m112j6(Sa sa, int i, int i2, String str) {
        try {
            if (!f96j6) {
                return null;
            }
            wu.j6(9466891099700145L, this, sa, new Integer(i), new Integer(i2), str);
            return null;
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 9466891099700145L, this, sa, new Integer(i), new Integer(i2), str);
            }
            throw th;
        }
    }

    public void m113j6(Sa sa) {
        try {
            if (f96j6) {
                wu.j6(-2028451740229514963L, this, sa);
            }
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, -2028451740229514963L, this, sa);
            }
            throw th;
        }
    }

    public void m114j6(Sa sa, int i) {
        try {
            if (f96j6) {
                wu.j6(3160985893982847933L, this, sa, new Integer(i));
            }
            m111Hw(sa);
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 3160985893982847933L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    public void m115j6(Sa sa, bc bcVar) {
        try {
            if (f96j6) {
                wu.j6(3173125330205744304L, this, sa, bcVar);
            }
            m111Hw(sa);
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 3173125330205744304L, this, sa, bcVar);
            }
            throw th;
        }
    }

    public void m116j6(Sa sa, boolean z) {
        try {
            if (f96j6) {
                wu.j6(392270810860227195L, this, sa, new Boolean(z));
            }
            this.f102v5 = z;
            this.f100Zo = sa;
            m101Zo(sa.aM());
            m97DW(sa.aM());
            this.f100Zo = null;
        } catch (Throwable th) {
            if (f95DW) {
                wu.j6(th, 392270810860227195L, this, sa, new Boolean(z));
            }
            throw th;
        }
    }
}
