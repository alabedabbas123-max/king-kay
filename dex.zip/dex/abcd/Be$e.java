package abcd;

@xu
public class Be$e extends Be$i {

    @uu
    private static boolean f458VH;

    @tu
    private static boolean f459Zo;

    public String f460gn;

    static {
        wu.j6(Be$e.class, 2890643331385433200L, 2890643331385433200L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$e(int i) {
        super(i);
        try {
            if (f459Zo) {
                wu.j6(190653905838385840L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f458VH) {
                wu.j6(th, 190653905838385840L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }

    public String m1279j6(String str) {
        try {
            if (f459Zo) {
                wu.j6(1533854226629754332L, this, str);
            }
            return Vl.VH(str, this.f460gn);
        } catch (Throwable th) {
            if (f458VH) {
                wu.j6(th, 1533854226629754332L, this, str);
            }
            throw th;
        }
    }
}
