package abcd;

enum C0010XE extends iF {
    C0010XE(String str, int i) {
        super(str, i, (iF) null);
    }

    public boolean m37Hw() {
        return true;
    }
}
