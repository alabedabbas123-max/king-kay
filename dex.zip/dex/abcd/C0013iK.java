package abcd;

public class C0013iK extends AbstractC0057jK {

    private final int f44FH;

    public C0013iK(int i) {
        this.f44FH = i;
    }

    @Override
    public AbstractC0057jK m694clone() {
        return this;
    }

    @Override
    public boolean mo68j6() {
        return false;
    }

    @Override
    public boolean mo69j6(YJ yj) {
        QC qcJ8;
        RC rcJ6 = yj.j6(this.f44FH, RC.class);
        return rcJ6 == null || (qcJ8 = rcJ6.J8()) == null || !qcJ8.we();
    }

    @Override
    public String toString() {
        return "SkipWorkTree(" + this.f44FH + ")";
    }
}
