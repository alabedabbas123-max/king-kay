package abcd;

import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class C0013cM extends EL implements KL {

    private static final char[] f39j6 = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    protected byte[] f40DW;

    protected int f41FH;

    public C0013cM(qL qLVar) {
        try {
            this.f40DW = qLVar.DW().j6("DER");
            this.f41FH = 0;
        } catch (IOException e) {
            throw new IllegalArgumentException("Error processing object : " + e.toString());
        }
    }

    public C0013cM(byte[] bArr) {
        this(bArr, 0);
    }

    public C0013cM(byte[] bArr, int i) {
        this.f40DW = bArr;
        this.f41FH = i;
    }

    static C0013cM m68DW(byte[] bArr) {
        if (bArr.length < 1) {
            throw new IllegalArgumentException("truncated BIT STRING detected");
        }
        byte b = bArr[0];
        byte[] bArr2 = new byte[bArr.length - 1];
        if (bArr2.length != 0) {
            System.arraycopy(bArr, 1, bArr2, 0, bArr.length - 1);
        }
        return new C0013cM(bArr2, b);
    }

    static C0013cM m69j6(int i, InputStream inputStream) throws IOException {
        if (i < 1) {
            throw new IllegalArgumentException("truncated BIT STRING detected");
        }
        int i2 = inputStream.read();
        byte[] bArr = new byte[i - 1];
        if (bArr.length == 0 || XP.j6(inputStream, bArr) == bArr.length) {
            return new C0013cM(bArr, i2);
        }
        throw new EOFException("EOF encountered in middle of BIT STRING");
    }

    public static C0013cM m70j6(LL ll, boolean z) {
        AL alU7 = ll.u7();
        return (z || (alU7 instanceof C0013cM)) ? m71j6(alU7) : m68DW(alU7.u7());
    }

    public static C0013cM m71j6(Object obj) {
        if (obj == null || (obj instanceof C0013cM)) {
            return (C0013cM) obj;
        }
        throw new IllegalArgumentException("illegal object in getInstance: " + obj.getClass().getName());
    }

    boolean m72Zo() {
        return false;
    }

    public String getString() {
        StringBuffer stringBuffer = new StringBuffer("#");
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            new CL(byteArrayOutputStream).j6(this);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            for (int i = 0; i != byteArray.length; i++) {
                stringBuffer.append(f39j6[(byteArray[i] >>> 4) & 15]);
                stringBuffer.append(f39j6[byteArray[i] & 15]);
            }
            return stringBuffer.toString();
        } catch (IOException unused) {
            throw new RuntimeException("internal error encoding BitString");
        }
    }

    public int hashCode() {
        return this.f41FH ^ OP.DW(this.f40DW);
    }

    void m73j6(CL cl) {
        byte[] bArr = new byte[m76u7().length + 1];
        bArr[0] = (byte) m75tp();
        System.arraycopy(m76u7(), 0, bArr, 1, bArr.length - 1);
        cl.j6(3, bArr);
    }

    protected boolean m74j6(EL el) {
        if (!(el instanceof C0013cM)) {
            return false;
        }
        C0013cM c0013cM = (C0013cM) el;
        return this.f41FH == c0013cM.f41FH && OP.j6(this.f40DW, c0013cM.f40DW);
    }

    public String toString() {
        return getString();
    }

    public int m75tp() {
        return this.f41FH;
    }

    public byte[] m76u7() {
        return this.f40DW;
    }

    int m77v5() {
        return OM.j6(this.f40DW.length + 1) + 1 + this.f40DW.length + 1;
    }
}
