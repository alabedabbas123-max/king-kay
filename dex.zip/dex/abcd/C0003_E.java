package abcd;

enum C0003_E extends iF {
    C0003_E(String str, int i) {
        super(str, i, (iF) null);
    }

    public boolean m3Hw() {
        return false;
    }
}
