package abcd;

import com.aide.common.ab;
import com.aide.ui.U;
import java.io.File;
import java.io.IOException;

@xu
class C0019lf implements ab<String> {

    @uu
    private static boolean f218DW;

    @tu
    private static boolean f219j6;

    final String f220FH;

    @vu
    final C0062mf f221Hw;

    static {
        wu.j6(C0019lf.class, -149619975250772417L, -469788443675121908L);
    }

    C0019lf(C0062mf c0062mf, String str) {
        this.f221Hw = c0062mf;
        this.f220FH = str;
    }

    @su(method = -5359679873219174468L)
    public void m109j6(String str) {
        try {
            if (f219j6) {
                wu.j6(247270443696710409L, this, str);
            }
            try {
                String str2 = this.f220FH + File.separator + str;
                Vl.DW(str2);
                U.vy().er();
                U.J8().m315Hw();
                U.tp().FH(str2);
                U.lg().j6(new Tl(str2, 1, 1, 1, 1));
            } catch (IOException e) {
                com.aide.common.ma.j6(U.lg(), "Create File", e);
            }
        } catch (Throwable th) {
            if (f218DW) {
                wu.j6(th, 247270443696710409L, this, str);
            }
            throw th;
        }
    }
}
