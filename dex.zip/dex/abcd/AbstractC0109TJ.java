package abcd;

public abstract class AbstractC0109TJ {

    protected static final byte[] f534j6 = new byte[20];

    final AbstractC0109TJ f535DW;

    AbstractC0109TJ f536FH;

    int f537Hw;

    protected final int f538VH;

    protected byte[] f539Zo;

    protected int f540gn;

    protected int f541v5;

    protected AbstractC0109TJ() {
        this.f535DW = null;
        this.f539Zo = new byte[128];
        this.f538VH = 0;
    }

    protected AbstractC0109TJ(AbstractC0109TJ abstractC0109TJ) {
        this.f535DW = abstractC0109TJ;
        this.f539Zo = abstractC0109TJ.f539Zo;
        this.f538VH = abstractC0109TJ.f540gn + 1;
        try {
            this.f539Zo[this.f538VH - 1] = 47;
        } catch (ArrayIndexOutOfBoundsException unused) {
            m787DW(abstractC0109TJ.f540gn);
            this.f539Zo[this.f538VH - 1] = 47;
        }
    }

    protected AbstractC0109TJ(AbstractC0109TJ abstractC0109TJ, byte[] bArr, int i) {
        this.f535DW = abstractC0109TJ;
        this.f539Zo = bArr;
        this.f538VH = i;
    }

    protected AbstractC0109TJ(byte[] bArr) {
        this.f535DW = null;
        if (bArr == null || bArr.length <= 0) {
            this.f539Zo = new byte[128];
            this.f538VH = 0;
            return;
        }
        this.f540gn = bArr.length;
        this.f539Zo = new byte[Math.max(128, this.f540gn + 1)];
        System.arraycopy(bArr, 0, this.f539Zo, 0, this.f540gn);
        byte[] bArr2 = this.f539Zo;
        int i = this.f540gn;
        if (bArr2[i - 1] != 47) {
            this.f540gn = i + 1;
            bArr2[i] = 47;
        }
        this.f538VH = this.f540gn;
    }

    private void m782DW(int i, int i2) {
        byte[] bArr = this.f539Zo;
        byte[] bArr2 = new byte[i];
        System.arraycopy(bArr, 0, bArr2, 0, i2);
        for (AbstractC0109TJ abstractC0109TJ = this; abstractC0109TJ != null && abstractC0109TJ.f539Zo == bArr; abstractC0109TJ = abstractC0109TJ.f535DW) {
            abstractC0109TJ.f539Zo = bArr2;
        }
    }

    private static int m783Hw(int i) {
        return rE.j6.j6(i) ? 47 : 0;
    }

    private static int m784j6(AbstractC0109TJ abstractC0109TJ, AbstractC0109TJ abstractC0109TJ2) {
        while (true) {
            AbstractC0109TJ abstractC0109TJ3 = abstractC0109TJ.f535DW;
            abstractC0109TJ2 = abstractC0109TJ2.f535DW;
            if (abstractC0109TJ3 == null || abstractC0109TJ2 == null) {
                return 0;
            }
            if (abstractC0109TJ3.f536FH == abstractC0109TJ2.f536FH) {
                return abstractC0109TJ.f538VH;
            }
            abstractC0109TJ = abstractC0109TJ3;
        }
    }

    private int m785j6(byte[] bArr, int i, int i2, int i3, int i4) {
        int iM783Hw;
        int iM783Hw2;
        byte[] bArr2 = this.f539Zo;
        int i5 = this.f540gn;
        while (i4 < i5 && i < i2) {
            int i6 = (bArr2[i4] & 255) - (bArr[i] & 255);
            if (i6 != 0) {
                return i6;
            }
            i4++;
            i++;
        }
        if (i4 < i5) {
            iM783Hw = bArr2[i4] & 255;
            iM783Hw2 = m783Hw(i3);
        } else {
            if (i < i2) {
                return m783Hw(this.f541v5) - (bArr[i] & 255);
            }
            iM783Hw = m783Hw(this.f541v5);
            iM783Hw2 = m783Hw(i3);
        }
        return iM783Hw - iM783Hw2;
    }

    public int m786DW(AbstractC0109TJ abstractC0109TJ) {
        return m792j6(abstractC0109TJ, abstractC0109TJ.f541v5);
    }

    protected void m787DW(int i) {
        m782DW(this.f539Zo.length << 1, i);
    }

    public abstract boolean mo153DW();

    public void mo154EQ() {
        while (!mo156FH()) {
            mo161j6(1);
        }
    }

    public abstract void mo155FH(int i);

    public abstract boolean mo156FH();

    public rE m788Hw() {
        return rE.DW(this.f541v5);
    }

    public void m789J0() {
    }

    public int m790VH() {
        return this.f541v5;
    }

    public String m791Zo() {
        return YJ.DW(this);
    }

    public abstract boolean mo158gn();

    int m792j6(AbstractC0109TJ abstractC0109TJ, int i) {
        int iM784j6 = m784j6(this, abstractC0109TJ);
        return m785j6(abstractC0109TJ.f539Zo, iM784j6, abstractC0109TJ.f540gn, i, iM784j6);
    }

    public int m793j6(byte[] bArr, int i, int i2, int i3) {
        return m785j6(bArr, i, i2, i3, 0);
    }

    public abstract AbstractC0109TJ mo159j6(IE ie);

    public AbstractC0109TJ m794j6(IE ie, uE uEVar) {
        return mo159j6(ie);
    }

    public VJ mo160j6() {
        return new VJ(this);
    }

    public abstract void mo161j6(int i);

    protected void m795j6(int i, int i2) {
        byte[] bArr = this.f539Zo;
        if (bArr.length >= i) {
            return;
        }
        int length = bArr.length;
        while (length < i && length > 0) {
            length <<= 1;
        }
        m782DW(length, i2);
    }

    public void m796j6(uE uEVar) {
        uEVar.Hw(mo163u7(), mo162tp());
    }

    public boolean m797j6(AbstractC0109TJ abstractC0109TJ) {
        return yE.j6(mo163u7(), mo162tp(), abstractC0109TJ.mo163u7(), abstractC0109TJ.mo162tp());
    }

    public abstract int mo162tp();

    public abstract byte[] mo163u7();

    public yE m798v5() {
        return yE.Hw(mo163u7(), mo162tp());
    }

    public void m799we() {
        mo155FH(1);
    }
}
