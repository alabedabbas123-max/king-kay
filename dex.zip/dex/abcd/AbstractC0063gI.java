package abcd;

import java.text.MessageFormat;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0063gI extends cI implements LI {

    private boolean f260Mr;

    private boolean f261U2;

    private boolean f262a8;

    private final boolean f263aM;

    private long f264er;

    private boolean f265j3;

    private boolean f266lg;

    private boolean f267rN;

    public AbstractC0063gI(BI bi) {
        super(bi);
        this.f263aM = ((cI) this).Zo.J8();
    }

    private void m240DW(Map<String, YI> map) throws nD, yD {
        int iIndexOf;
        boolean z;
        String strM244we = m244we();
        if (!strM244we.startsWith("unpack ")) {
            throw new nD(((cI) this).v5, MessageFormat.format(JGitText.j6().unexpectedReportLine, strM244we));
        }
        String strSubstring = strM244we.substring(7);
        if (!strSubstring.equals("ok")) {
            throw new yD(((cI) this).v5, MessageFormat.format(JGitText.j6().errorOccurredDuringUnpackingOnTheRemoteEnd, strSubstring));
        }
        while (true) {
            String strDW = ((cI) this).we.DW();
            if (strDW == DI.j6) {
                for (YI yi : map.values()) {
                    if (yi.Hw() == YI.a.gn) {
                        throw new nD(MessageFormat.format(JGitText.j6().expectedReportForRefNotReceived, ((cI) this).v5, yi.FH()));
                    }
                }
                return;
            }
            if (strDW.startsWith("ok ")) {
                iIndexOf = strDW.length();
                z = true;
            } else {
                iIndexOf = strDW.startsWith("ng ") ? strDW.indexOf(" ", 3) : -1;
                z = false;
            }
            if (iIndexOf == -1) {
                throw new nD(MessageFormat.format(JGitText.j6().unexpectedReportLine2, ((cI) this).v5, strDW));
            }
            String strSubstring2 = strDW.substring(3, iIndexOf);
            String strSubstring3 = z ? null : strDW.substring(iIndexOf + 1);
            YI yi2 = map.get(strSubstring2);
            if (yi2 == null) {
                throw new nD(MessageFormat.format(JGitText.j6().unexpectedRefReport, ((cI) this).v5, strSubstring2));
            }
            if (z) {
                yi2.j6(YI.a.u7);
            } else {
                yi2.j6(YI.a.Zo);
                yi2.j6(strSubstring3);
            }
        }
    }

    private String m241j6(LE le) {
        StringBuilder sb = new StringBuilder();
        this.f260Mr = j6(sb, "report-status");
        this.f265j3 = j6(sb, "delete-refs");
        this.f262a8 = j6(sb, "ofs-delta");
        this.f261U2 = j6(sb, "side-band-64k");
        if (this.f261U2) {
            ((cI) this).tp = new _I(((cI) this).tp, le, VH());
            ((cI) this).we = new DI(((cI) this).tp);
        }
        if (sb.length() > 0) {
            sb.setCharAt(0, (char) 0);
        }
        return sb.toString();
    }

    private void m242j6(Collection<YI> collection, LE le) throws yD {
        String strM241j6 = m241j6(le);
        for (YI yi : collection) {
            if (this.f265j3 || !yi.VH()) {
                StringBuilder sb = new StringBuilder();
                ME ref = getRef(yi.FH());
                sb.append((ref == null ? yE.Ws() : ref.DW()).we());
                sb.append(' ');
                sb.append(yi.DW().we());
                sb.append(' ');
                sb.append(yi.FH());
                if (!this.f266lg) {
                    this.f266lg = true;
                    sb.append(strM241j6);
                }
                ((cI) this).J0.j6(sb.toString());
                yi.j6(YI.a.gn);
                if (!yi.VH()) {
                    this.f267rN = true;
                }
            } else {
                yi.j6(YI.a.Hw);
            }
        }
        if (le.isCancelled()) {
            throw new yD(((cI) this).v5, JGitText.j6().pushCancelled);
        }
        ((cI) this).J0.j6();
        ((cI) this).J8 = false;
    }

    private void m243j6(Map<String, YI> map, LE le) {
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        TH th = new TH(((cI) this).Zo.Zo(), ((cI) this).Hw.j3());
        try {
            Iterator it = DW().iterator();
            while (it.hasNext()) {
                hashSet.add(((ME) it.next()).DW());
            }
            hashSet.addAll(((cI) this).XL);
            for (YI yi : map.values()) {
                if (!yE.Ws().DW(yi.DW())) {
                    hashSet2.add(yi.DW());
                }
            }
            th.v5(true);
            th.Hw(this.f263aM);
            th.FH(false);
            th.j6(this.f262a8);
            th.j6(le, hashSet2, hashSet);
            th.j6(le, le, ((cI) this).EQ);
            th.VH();
            this.f264er = th.v5().DW();
        } catch (Throwable th2) {
            th.VH();
            throw th2;
        }
    }

    private String m244we() {
        _K _k = ((cI) this).VH;
        if (_k == null) {
            return ((cI) this).we.DW();
        }
        int iJ6 = _k.j6();
        try {
            ((cI) this).VH.j6(Math.max((int) Math.min(this.f264er, 28800000L), iJ6) * 10);
            return ((cI) this).we.DW();
        } finally {
            ((cI) this).VH.j6(iJ6);
        }
    }

    protected void m245DW(LE le, Map<String, YI> map) {
        int i;
        try {
            try {
                m242j6(map.values(), le);
                if (this.f267rN) {
                    m243j6(map, le);
                }
                if (this.f266lg) {
                    if (this.f260Mr) {
                        m240DW(map);
                    }
                    if (this.f261U2 && (i = ((cI) this).tp.read()) >= 0) {
                        throw new yD(((cI) this).v5, MessageFormat.format(JGitText.j6().expectedEOFReceived, Character.valueOf((char) i)));
                    }
                }
                close();
            } catch (Exception e) {
                throw new yD(((cI) this).v5, e.getMessage(), e);
            } catch (yD e2) {
                throw e2;
            }
        } catch (Throwable th) {
            close();
            throw th;
        }
    }

    public void m246j6(LE le, Map<String, YI> map) {
        gn();
        m245DW(le, map);
    }

    protected yD m247tp() {
        try {
            ((cI) this).Zo.QX().close();
        } catch (C0102hD e) {
            return e;
        } catch (jD | yD unused) {
        }
        return new yD(((cI) this).v5, JGitText.j6().pushNotPermitted);
    }
}
