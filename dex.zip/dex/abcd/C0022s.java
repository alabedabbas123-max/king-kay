package abcd;

public class C0022s<F, S> {

    public final S f51DW;

    public final F f52j6;

    public C0022s(F f, S s) {
        this.f52j6 = f;
        this.f51DW = s;
    }

    private static boolean m177j6(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0022s)) {
            return false;
        }
        C0022s c0022s = (C0022s) obj;
        return m177j6(c0022s.f52j6, this.f52j6) && m177j6(c0022s.f51DW, this.f51DW);
    }

    public int hashCode() {
        F f = this.f52j6;
        int iHashCode = f == null ? 0 : f.hashCode();
        S s = this.f51DW;
        return iHashCode ^ (s != null ? s.hashCode() : 0);
    }

    public String toString() {
        return "Pair{" + String.valueOf(this.f52j6) + " " + String.valueOf(this.f51DW) + "}";
    }
}
