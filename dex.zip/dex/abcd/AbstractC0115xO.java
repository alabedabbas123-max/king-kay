package abcd;

public abstract class AbstractC0115xO implements tO {

    private int f350DW;

    private long f351FH;

    private byte[] f352j6;

    protected AbstractC0115xO() {
        this.f352j6 = new byte[4];
        this.f350DW = 0;
    }

    protected AbstractC0115xO(AbstractC0115xO abstractC0115xO) {
        this.f352j6 = new byte[abstractC0115xO.f352j6.length];
        byte[] bArr = abstractC0115xO.f352j6;
        System.arraycopy(bArr, 0, this.f352j6, 0, bArr.length);
        this.f350DW = abstractC0115xO.f350DW;
        this.f351FH = abstractC0115xO.f351FH;
    }

    protected abstract void m502DW(byte[] bArr, int i);

    public void m503FH() {
        long j = this.f351FH << 3;
        m505j6((byte) -128);
        while (this.f350DW != 0) {
            m505j6((byte) 0);
        }
        m506j6(j);
        m504Hw();
    }

    protected abstract void m504Hw();

    public void m505j6(byte b) {
        byte[] bArr = this.f352j6;
        int i = this.f350DW;
        this.f350DW = i + 1;
        bArr[i] = b;
        if (this.f350DW == bArr.length) {
            m502DW(bArr, 0);
            this.f350DW = 0;
        }
        this.f351FH++;
    }

    protected abstract void m506j6(long j);

    public void reset() {
        this.f351FH = 0L;
        this.f350DW = 0;
        int i = 0;
        while (true) {
            byte[] bArr = this.f352j6;
            if (i >= bArr.length) {
                return;
            }
            bArr[i] = 0;
            i++;
        }
    }

    public void update(byte[] bArr, int i, int i2) {
        while (this.f350DW != 0 && i2 > 0) {
            m505j6(bArr[i]);
            i++;
            i2--;
        }
        while (i2 > this.f352j6.length) {
            m502DW(bArr, i);
            byte[] bArr2 = this.f352j6;
            i += bArr2.length;
            i2 -= bArr2.length;
            this.f351FH += (long) bArr2.length;
        }
        while (i2 > 0) {
            m505j6(bArr[i]);
            i++;
            i2--;
        }
    }
}
