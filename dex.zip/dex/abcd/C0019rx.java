package abcd;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

public class C0019rx implements IInterface {

    private final String f46DW;

    private final IBinder f47j6;

    protected C0019rx(IBinder iBinder, String str) {
        this.f47j6 = iBinder;
        this.f46DW = str;
    }

    @Override
    public IBinder asBinder() {
        return this.f47j6;
    }

    protected final Parcel m172j6(int i, Parcel parcel) {
        Parcel parcelObtain = Parcel.obtain();
        try {
            try {
                this.f47j6.transact(i, parcel, parcelObtain, 0);
                parcelObtain.readException();
                parcel.recycle();
                return parcelObtain;
            } catch (RuntimeException e) {
                parcelObtain.recycle();
                throw e;
            }
        } catch (Throwable th) {
            parcel.recycle();
            throw th;
        }
    }

    protected final Parcel m173v5() {
        Parcel parcelObtain = Parcel.obtain();
        parcelObtain.writeInterfaceToken(this.f46DW);
        return parcelObtain;
    }
}
