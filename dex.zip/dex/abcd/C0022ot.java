package abcd;

import java.util.ArrayList;
import java.util.List;

public final class C0022ot extends vt {

    private final int f362FH;

    private final ArrayList<a> f363Hw;

    private cs f364v5;

    private static class a {

        public final int f365DW;

        public final int f366FH;

        public bs f367j6;

        public a(bs bsVar, int i, int i2) {
            this.f367j6 = bsVar;
            this.f365DW = i;
            this.f366FH = i2;
        }
    }

    public interface b {
        void m99j6(C0022ot c0022ot);
    }

    public C0022ot(int i, tt ttVar) {
        super(bs.j6(i, Qs.tp), ttVar);
        this.f363Hw = new ArrayList<>();
        this.f362FH = i;
    }

    public C0022ot(bs bsVar, tt ttVar) {
        super(bsVar, ttVar);
        this.f363Hw = new ArrayList<>();
        this.f362FH = bsVar.we();
    }

    public void m81DW(bs bsVar) {
        ArrayList arrayList = new ArrayList();
        for (a aVar : this.f363Hw) {
            if (aVar.f367j6.we() == bsVar.we()) {
                arrayList.add(aVar);
            }
        }
        this.f363Hw.removeAll(arrayList);
        this.f364v5 = null;
    }

    public final void m82DW(AbstractC0107qt abstractC0107qt) {
        for (a aVar : this.f363Hw) {
            bs bsVar = aVar.f367j6;
            aVar.f367j6 = abstractC0107qt.m557j6(bsVar);
            if (bsVar != aVar.f367j6) {
                DW().v5().j6(this, bsVar, aVar.f367j6);
            }
        }
        this.f364v5 = null;
    }

    public boolean m83EQ() {
        return nt.DW() && FH() != null;
    }

    public int m84FH(int i) {
        return this.f363Hw.get(i).f365DW;
    }

    public boolean m85XL() {
        return true;
    }

    public String m86aM() {
        return m88j6((String) null);
    }

    public C0022ot clone() {
        throw new UnsupportedOperationException("can't clone phi");
    }

    public vt m905clone() {
        clone();
        throw null;
    }

    public Object m906clone() {
        clone();
        throw null;
    }

    public Tr m87gn() {
        return null;
    }

    protected final String m88j6(String str) {
        StringBuffer stringBuffer = new StringBuffer(80);
        stringBuffer.append(hs.j6);
        stringBuffer.append(": phi");
        if (str != null) {
            stringBuffer.append("(");
            stringBuffer.append(str);
            stringBuffer.append(")");
        }
        bs bsVarU7 = u7();
        if (bsVarU7 == null) {
            stringBuffer.append(" .");
        } else {
            stringBuffer.append(" ");
            stringBuffer.append(bsVarU7.aM());
        }
        stringBuffer.append(" <-");
        int size = m97tp().size();
        if (size == 0) {
            stringBuffer.append(" .");
        } else {
            for (int i = 0; i < size; i++) {
                stringBuffer.append(" ");
                stringBuffer.append(this.f364v5.get(i).aM() + "[b=" + Yt.v5(this.f363Hw.get(i).f366FH) + "]");
            }
        }
        return stringBuffer.toString();
    }

    public List<tt> m89j6(int i, yt ytVar) {
        ArrayList arrayList = new ArrayList();
        for (a aVar : this.f363Hw) {
            if (aVar.f367j6.we() == i) {
                arrayList.add(ytVar.DW().get(aVar.f365DW));
            }
        }
        return arrayList;
    }

    public void m90j6(Rs rs, Vr vr) {
        j6(bs.FH(u7().we(), rs, vr));
    }

    public void m91j6(bs bsVar, tt ttVar) {
        this.f363Hw.add(new a(bsVar, ttVar.DW(), ttVar.EQ()));
        this.f364v5 = null;
    }

    public void m92j6(vt.a aVar) {
        aVar.j6(this);
    }

    public void m93j6(yt ytVar) {
        for (a aVar : this.f363Hw) {
            aVar.f367j6 = aVar.f367j6.j6(ytVar.FH(aVar.f367j6.we()).u7().getType());
        }
        this.f364v5 = null;
    }

    public boolean m94j6() {
        return false;
    }

    public Tr m95lg() {
        throw new IllegalArgumentException("Cannot convert phi insns to rop form");
    }

    public int m96rN() {
        return this.f362FH;
    }

    public cs m97tp() {
        cs csVar = this.f364v5;
        if (csVar != null) {
            return csVar;
        }
        if (this.f363Hw.size() == 0) {
            return cs.FH;
        }
        int size = this.f363Hw.size();
        this.f364v5 = new cs(size);
        for (int i = 0; i < size; i++) {
            this.f364v5.j6(i, this.f363Hw.get(i).f367j6);
        }
        this.f364v5.we();
        return this.f364v5;
    }

    public es m98v5() {
        return null;
    }
}
