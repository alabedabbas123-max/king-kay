package abcd;

@xu
public class C0022ic extends RuntimeException {
    static {
        wu.j6(C0022ic.class, 17510710866536208L, 17510710866536208L);
    }
}
