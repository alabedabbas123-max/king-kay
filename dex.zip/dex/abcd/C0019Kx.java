package abcd;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

final class C0019Kx extends WeakReference<Throwable> {

    private final int f93j6;

    public C0019Kx(Throwable th, ReferenceQueue<Throwable> referenceQueue) {
        super(th, referenceQueue);
        if (th == null) {
            throw new NullPointerException("The referent cannot be null");
        }
        this.f93j6 = System.identityHashCode(th);
    }

    public final boolean equals(Object obj) {
        if (obj != null && obj.getClass() == C0019Kx.class) {
            if (this == obj) {
                return true;
            }
            C0019Kx c0019Kx = (C0019Kx) obj;
            if (this.f93j6 == c0019Kx.f93j6 && get() == c0019Kx.get()) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f93j6;
    }
}
