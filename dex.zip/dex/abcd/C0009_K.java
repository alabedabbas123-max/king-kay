package abcd;

import java.io.FilterInputStream;
import java.io.InputStream;
import java.io.InterruptedIOException;
import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public class C0009_K extends FilterInputStream {

    private int f72DW;

    private final VK f73j6;

    public C0009_K(InputStream inputStream, VK vk) {
        super(inputStream);
        this.f73j6 = vk;
    }

    private void m103DW() {
        this.f73j6.j6(this.f72DW);
    }

    private void m104FH() {
        this.f73j6.j6();
    }

    private static InterruptedIOException m105Hw() {
        return new InterruptedIOException(JGitText.j6().readTimedOut);
    }

    public int m106j6() {
        return this.f72DW;
    }

    public void m107j6(int i) {
        if (i < 0) {
            throw new IllegalArgumentException(MessageFormat.format(JGitText.j6().invalidTimeout, Integer.valueOf(i)));
        }
        this.f72DW = i;
    }

    @Override
    public int read() {
        try {
            try {
                m103DW();
                int i = super.read();
                m104FH();
                return i;
            } catch (InterruptedIOException unused) {
                throw m105Hw();
            }
        } catch (Throwable th) {
            m104FH();
            throw th;
        }
    }

    @Override
    public int read(byte[] bArr) {
        return read(bArr, 0, bArr.length);
    }

    @Override
    public int read(byte[] bArr, int i, int i2) {
        try {
            try {
                m103DW();
                int i3 = super.read(bArr, i, i2);
                m104FH();
                return i3;
            } catch (InterruptedIOException unused) {
                throw m105Hw();
            }
        } catch (Throwable th) {
            m104FH();
            throw th;
        }
    }

    @Override
    public long skip(long j) {
        try {
            try {
                m103DW();
                long jSkip = super.skip(j);
                m104FH();
                return jSkip;
            } catch (InterruptedIOException unused) {
                throw m105Hw();
            }
        } catch (Throwable th) {
            m104FH();
            throw th;
        }
    }
}
