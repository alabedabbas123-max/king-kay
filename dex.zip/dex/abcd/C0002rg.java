package abcd;

import com.aide.ui.U;

@xu
public class C0002rg implements Yl, Wl {

    @uu
    private static boolean f8DW;

    @InterfaceC0101tu
    private static boolean f9j6;

    static {
        wu.j6(C0002rg.class, -1401119370987670173L, -1401119370987670173L);
    }

    public C0002rg() {
        try {
            if (f9j6) {
                wu.j6(-584371484952783667L, (Object) null);
            }
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, -584371484952783667L, (Object) null);
            }
            throw th;
        }
    }

    public com.aide.common.u m56FH() {
        try {
            if (f9j6) {
                wu.j6(6278032869521920944L, this);
            }
            return new com.aide.common.u(10, false, true, false);
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 6278032869521920944L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f9j6) {
                return "Show Search Results";
            }
            wu.j6(975461979278795337L, this);
            return "Show Search Results";
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 975461979278795337L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (!f9j6) {
                return true;
            }
            wu.j6(3624096995026951845L, this);
            return true;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 3624096995026951845L, this);
            }
            throw th;
        }
    }

    public int m57j6() {
        try {
            if (!f9j6) {
                return com.aide.pro.R.id.mainMenuOpenSearchBrowser;
            }
            wu.j6(1735118752928967147L, this);
            return com.aide.pro.R.id.mainMenuOpenSearchBrowser;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 1735118752928967147L, this);
            }
            throw th;
        }
    }

    public boolean m58run() {
        try {
            if (f9j6) {
                wu.j6(2364573371752429959L, this);
            }
            U.lg().dx();
            return true;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 2364573371752429959L, this);
            }
            throw th;
        }
    }
}
