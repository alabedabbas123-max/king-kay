package abcd;

@xu
public class C0025Xd extends tc {

    @tu
    private static boolean f85lg;

    @uu
    private static boolean f86rN;

    @ru(field = 1482325749263350700L)
    private final Ba f87BT;

    @ru(field = 4057709509978666344L)
    private int f88P8;

    @ru(field = 2186861539525305533L)
    private int f89ei;

    @ru(field = -2480977363090951817L)
    private final ae f90er;

    @ru(field = -2978511404265211400L)
    private final Ga f91gW;

    @ru(field = 315867439609905735L)
    private int f92nw;

    @ru(field = -337637070837045849L)
    private int[] f93vy;

    @ru(field = 2353579206246657920L)
    private final Ca f94yS;

    @xu
    private static class a extends tc.a {

        @tu
        private static boolean f95FH;

        @uu
        private static boolean f96Hw;

        static {
            wu.j6(a.class, 1018680395917475832L, 1018680395917475832L);
        }

        @su(method = -457099987224437952L)
        private a() {
            try {
                if (f95FH) {
                    wu.j6(3921893410869760808L, (Object) null);
                }
            } catch (Throwable th) {
                if (f96Hw) {
                    wu.j6(th, 3921893410869760808L, (Object) null);
                }
                throw th;
            }
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        a(Wd wd) {
            this();
            try {
                if (f95FH) {
                    wu.j6(773359522475163744L, (Object) null, wd);
                }
            } catch (Throwable th) {
                if (f96Hw) {
                    wu.j6(th, 773359522475163744L, (Object) null, wd);
                }
                throw th;
            }
        }
    }

    static {
        wu.j6(C0025Xd.class, -560053395789920331L, -560053395789920331L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public C0025Xd(Ga ga, Ca ca, Ba ba, ae aeVar) {
        super(ga, ca, ba, aeVar, 223, 0);
        try {
            if (f85lg) {
                wu.j6(8062090950365162269L, (Object) null, ga, ca, ba, aeVar);
            }
            this.f93vy = new int[1000];
            this.f88P8 = 0;
            this.f94yS = ca;
            this.f91gW = ga;
            this.f87BT = ba;
            this.f90er = aeVar;
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 8062090950365162269L, (Object) null, ga, ca, ba, aeVar);
            }
            throw th;
        }
    }

    @su(method = 490658260639514103L)
    private void m128DW(boolean z) {
        try {
            if (f85lg) {
                wu.j6(-468393707572183835L, this, z);
            }
            int i = ((tc) this).we;
            if (i != 21 && i != 22 && i != 58) {
                int i2 = 1;
                if (i == 59) {
                    Hw();
                    if (((tc) this).we != 8) {
                        throw new tc.a();
                    }
                    m129EQ();
                    int i3 = 2;
                    while (((tc) this).we == 71) {
                        Hw();
                        Hw(12);
                        if (((tc) this).we != 1) {
                            throw new tc.a();
                        }
                        Hw();
                        Hw(13);
                        if (((tc) this).we != 8) {
                            throw new tc.a();
                        }
                        m129EQ();
                        Hw(204, 5);
                        i3++;
                    }
                    if (((tc) this).we == 92) {
                        Hw();
                        if (((tc) this).we != 8) {
                            throw new tc.a();
                        }
                        m129EQ();
                        Hw(205, 2);
                        i3++;
                    }
                    Hw(150, i3);
                    return;
                }
                if (i == 79) {
                    Hw();
                    m133J8();
                    m145lg();
                    Hw(142, 3);
                    return;
                }
                if (i == 80) {
                    Hw();
                    Hw(12);
                    m133J8();
                    Hw(13);
                    m128DW(false);
                    Hw(137, 5);
                    return;
                }
                if (i != 105) {
                    if (i == 106) {
                        Hw();
                        Hw(12);
                        m133J8();
                        Hw(13);
                        m128DW(false);
                        Hw(212, 5);
                        return;
                    }
                    switch (i) {
                        case 1:
                            if (Zo(1) != 26) {
                                m133J8();
                                m145lg();
                                Hw(146, 2);
                                return;
                            } else {
                                Hw();
                                Hw();
                                m128DW(false);
                                Hw(148, 3);
                                return;
                            }
                        case 2:
                        case 3:
                        case 4:
                        case 5:
                        case 6:
                        case 7:
                            break;
                        case 8:
                            m129EQ();
                            return;
                        default:
                            switch (i) {
                                case 10:
                                case 12:
                                case 24:
                                case 34:
                                case 74:
                                case 118:
                                    break;
                                case 14:
                                    Hw();
                                    Hw(134, 1);
                                    return;
                                case 61:
                                    Hw();
                                    m133J8();
                                    Hw(26);
                                    Hw(143, 3);
                                    return;
                                case 85:
                                    Hw();
                                    if (((tc) this).we != 14 && ((tc) this).we != 9 && !m141aM()) {
                                        m133J8();
                                        m145lg();
                                        Hw(141, 3);
                                        return;
                                    }
                                    m145lg();
                                    Hw(141, 2);
                                    return;
                                case 87:
                                    Hw();
                                    Hw(12);
                                    m133J8();
                                    Hw(13);
                                    if (((tc) this).we != 8) {
                                        throw new tc.a();
                                    }
                                    m129EQ();
                                    Hw(147, 5);
                                    return;
                                case 90:
                                    Hw();
                                    Hw(26);
                                    Hw(144, 2);
                                    return;
                                default:
                                    switch (i) {
                                        case 26:
                                            if (!z || Zo(1) != 2) {
                                                throw new a(null);
                                            }
                                            Hw();
                                            Hw();
                                            Hw(213, 2);
                                            return;
                                        case 27:
                                        case 28:
                                            break;
                                        default:
                                            switch (i) {
                                                case 54:
                                                    Hw();
                                                    m128DW(false);
                                                    if (((tc) this).we != 80) {
                                                        throw new tc.a();
                                                    }
                                                    Hw();
                                                    Hw(12);
                                                    m133J8();
                                                    Hw(13);
                                                    m145lg();
                                                    Hw(145, 7);
                                                    return;
                                                case 55:
                                                    Hw();
                                                    Hw(12);
                                                    m133J8();
                                                    Hw(13);
                                                    m128DW(false);
                                                    if (((tc) this).we != 63) {
                                                        Hw(135, 5);
                                                        return;
                                                    }
                                                    Hw();
                                                    m128DW(false);
                                                    Hw(136, 7);
                                                    return;
                                                case 56:
                                                    Hw();
                                                    Hw(12);
                                                    if (((tc) this).we == 14) {
                                                        Hw();
                                                        Hw(201, 1);
                                                    } else {
                                                        if (((tc) this).we == 98 && Zo(1) == 1 && Zo(2) == 114) {
                                                            Hw();
                                                            if (((tc) this).we != 1) {
                                                                throw new tc.a();
                                                            }
                                                            Hw();
                                                            Hw(200, 1);
                                                            Hw(151, 2);
                                                            Hw(114);
                                                            m133J8();
                                                            Hw(13);
                                                            m128DW(false);
                                                            Hw(211, 7);
                                                            return;
                                                        }
                                                        if (((tc) this).we == 1 && Zo(1) == 114) {
                                                            m146rN();
                                                            Hw(114);
                                                            m133J8();
                                                            Hw(13);
                                                            m128DW(false);
                                                            Hw(211, 7);
                                                            return;
                                                        }
                                                        if (((tc) this).we == 98) {
                                                            m131Hw(false);
                                                            Hw(201, 1);
                                                        } else {
                                                            m138Ws();
                                                            int i4 = 2;
                                                            while (((tc) this).we == 15) {
                                                                Hw();
                                                                m138Ws();
                                                                i4 += 2;
                                                            }
                                                            m145lg();
                                                            Hw(201, i4);
                                                        }
                                                    }
                                                    if (((tc) this).we == 14) {
                                                        Hw();
                                                        Hw(203, 1);
                                                    } else {
                                                        m133J8();
                                                        m145lg();
                                                        Hw(203, 2);
                                                    }
                                                    if (((tc) this).we == 13) {
                                                        Hw(202, 0);
                                                    } else {
                                                        m138Ws();
                                                        while (((tc) this).we == 15) {
                                                            Hw();
                                                            m138Ws();
                                                            i2 += 2;
                                                        }
                                                        Hw(202, i2);
                                                    }
                                                    Hw(13);
                                                    m128DW(false);
                                                    Hw(149, 7);
                                                    return;
                                                default:
                                                    switch (i) {
                                                        case 66:
                                                        case 67:
                                                        case 68:
                                                        case 69:
                                                            break;
                                                        case 70:
                                                            Hw();
                                                            if (((tc) this).we != 1 || m141aM()) {
                                                                m145lg();
                                                                Hw(138, 2);
                                                                return;
                                                            } else {
                                                                Hw();
                                                                m145lg();
                                                                Hw(138, 3);
                                                                return;
                                                            }
                                                        default:
                                                            switch (i) {
                                                                case 96:
                                                                    Hw();
                                                                    if (((tc) this).we != 1 || m141aM()) {
                                                                        m145lg();
                                                                        Hw(139, 2);
                                                                        return;
                                                                    } else {
                                                                        Hw();
                                                                        m145lg();
                                                                        Hw(139, 3);
                                                                        return;
                                                                    }
                                                                case 97:
                                                                    if (z) {
                                                                        Hw();
                                                                        if (((tc) this).we != 1) {
                                                                            throw new tc.a();
                                                                        }
                                                                        Hw();
                                                                        m136U2();
                                                                        m129EQ();
                                                                        int i5 = this.f89ei;
                                                                        this.f89ei = i5 + 1;
                                                                        j6(125, false, 4, i5);
                                                                    } else {
                                                                        m133J8();
                                                                    }
                                                                    m144j6(false);
                                                                    Hw(146, 2);
                                                                    return;
                                                                case 98:
                                                                    m131Hw(z);
                                                                    return;
                                                                default:
                                                                    throw new a(null);
                                                            }
                                                    }
                                                    break;
                                            }
                                            break;
                                    }
                                    break;
                            }
                            break;
                    }
                }
            }
            m133J8();
            m145lg();
            Hw(146, 2);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -468393707572183835L, this, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 1102554681265615424L)
    private void m129EQ() {
        try {
            if (f85lg) {
                wu.j6(-1973403558503155272L, this);
            }
            Hw();
            int iM130FH = m130FH(false);
            Hw(9);
            Hw(133, iM130FH + 2);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -1973403558503155272L, this);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:53:0x00f4 A[Catch: Throwable -> 0x0150, FALL_THROUGH, TryCatch #0 {Throwable -> 0x0150, blocks: (B:3:0x0009, B:5:0x000d, B:7:0x0012, B:11:0x001a, B:13:0x0021, B:60:0x0141, B:62:0x0145, B:17:0x002a, B:19:0x002f, B:21:0x0036, B:23:0x003c, B:33:0x005f, B:34:0x0062, B:35:0x0065, B:58:0x0124, B:37:0x006a, B:39:0x0076, B:41:0x0082, B:43:0x0090, B:45:0x00a4, B:47:0x00b0, B:48:0x00c2, B:57:0x0122, B:49:0x00c9, B:51:0x00d5, B:52:0x00e7, B:53:0x00f4, B:55:0x0100, B:56:0x0112, B:59:0x012d, B:20:0x0033), top: B:72:0x0009, inners: #1 }] */
    /* JADX WARN: Code duplicated, block: B:55:0x0100 A[Catch: Throwable -> 0x0150, TryCatch #0 {Throwable -> 0x0150, blocks: (B:3:0x0009, B:5:0x000d, B:7:0x0012, B:11:0x001a, B:13:0x0021, B:60:0x0141, B:62:0x0145, B:17:0x002a, B:19:0x002f, B:21:0x0036, B:23:0x003c, B:33:0x005f, B:34:0x0062, B:35:0x0065, B:58:0x0124, B:37:0x006a, B:39:0x0076, B:41:0x0082, B:43:0x0090, B:45:0x00a4, B:47:0x00b0, B:48:0x00c2, B:57:0x0122, B:49:0x00c9, B:51:0x00d5, B:52:0x00e7, B:53:0x00f4, B:55:0x0100, B:56:0x0112, B:59:0x012d, B:20:0x0033), top: B:72:0x0009, inners: #1 }] */
    @su(method = -2064006232655188464L)
    private int m130FH(boolean z) {
        try {
            if (f85lg) {
                wu.j6(1477388613432675888L, this, z);
            }
            int i = 0;
            while (true) {
                int i2 = ((tc) this).we;
                if (i2 != 0 && i2 != 9) {
                    int i3 = ((tc) this).J0;
                    int i4 = ((tc) this).a8 + 1;
                    try {
                        m128DW(z);
                        i++;
                    } catch (tc.a e) {
                        if (e instanceof a) {
                            DW();
                        } else {
                            m132J0();
                        }
                        int i5 = ((tc) this).a8;
                        int i6 = i;
                        for (int i7 = i4; i7 <= i5; i7++) {
                            int iP8 = ((tc) this).EQ.P8(((tc) this).U2[i7]);
                            if (iP8 != 159 && iP8 != 161 && iP8 != 168 && iP8 != 165 && iP8 != 166) {
                                switch (iP8) {
                                    default:
                                        switch (iP8) {
                                            case 175:
                                            case 176:
                                            case 177:
                                                break;
                                            default:
                                                switch (iP8) {
                                                    case 201:
                                                    case 202:
                                                    case 203:
                                                        if (((tc) this).EQ.we(((tc) this).U2[i7]) > 1 || (((tc) this).EQ.we(((tc) this).U2[i7]) == 1 && ((tc) this).EQ.P8(((tc) this).U2[i7]) == 202)) {
                                                            int iZo = ((tc) this).EQ.Zo(((tc) this).U2[i7], 0);
                                                            if (((tc) this).EQ.P8(iZo) == 151) {
                                                                ((tc) this).a8++;
                                                                if (((tc) this).a8 >= ((tc) this).U2.length) {
                                                                    int[] iArr = new int[(((tc) this).U2.length * 2) + 1];
                                                                    System.arraycopy(((tc) this).U2, 0, iArr, 0, ((tc) this).U2.length);
                                                                    ((tc) this).U2 = iArr;
                                                                }
                                                                ((tc) this).U2[((tc) this).a8] = iZo;
                                                            } else {
                                                                ((tc) this).a8++;
                                                                if (((tc) this).a8 >= ((tc) this).U2.length) {
                                                                    int[] iArr2 = new int[(((tc) this).U2.length * 2) + 1];
                                                                    System.arraycopy(((tc) this).U2, 0, iArr2, 0, ((tc) this).U2.length);
                                                                    ((tc) this).U2 = iArr2;
                                                                }
                                                                ((tc) this).U2[((tc) this).a8] = iZo;
                                                                FH(14);
                                                                Hw(146, 2);
                                                            }
                                                            i6++;
                                                        }
                                                        break;
                                                }
                                                break;
                                        }
                                    case 170:
                                    case 171:
                                    case 172:
                                        ((tc) this).a8++;
                                        if (((tc) this).a8 >= ((tc) this).U2.length) {
                                            int[] iArr3 = new int[(((tc) this).U2.length * 2) + 1];
                                            System.arraycopy(((tc) this).U2, 0, iArr3, 0, ((tc) this).U2.length);
                                            ((tc) this).U2 = iArr3;
                                        }
                                        ((tc) this).U2[((tc) this).a8] = ((tc) this).U2[i7];
                                        FH(14);
                                        Hw(146, 2);
                                        i6++;
                                        break;
                                }
                            } else {
                                ((tc) this).a8++;
                                if (((tc) this).a8 >= ((tc) this).U2.length) {
                                    int[] iArr4 = new int[(((tc) this).U2.length * 2) + 1];
                                    System.arraycopy(((tc) this).U2, 0, iArr4, 0, ((tc) this).U2.length);
                                    ((tc) this).U2 = iArr4;
                                }
                                ((tc) this).U2[((tc) this).a8] = ((tc) this).U2[i7];
                                FH(14);
                                Hw(146, 2);
                                i6++;
                            }
                        }
                        System.arraycopy(((tc) this).U2, i5 + 1, ((tc) this).U2, i4, ((tc) this).a8 - i5);
                        ((tc) this).a8 -= (i5 - i4) + 1;
                        i = i6;
                    }
                    if (((tc) this).J0 == i3) {
                        v5();
                    }
                }
            }
            return i;
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 1477388613432675888L, this, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 7049986995708393792L)
    private void m131Hw(boolean z) {
        try {
            if (f85lg) {
                wu.j6(-2771858147401183680L, this, z);
            }
            Hw(98);
            if (((tc) this).we != 1) {
                throw new tc.a();
            }
            Hw();
            if (((tc) this).we == 17) {
                Hw();
                int i = ((tc) this).a8;
                try {
                    m138Ws();
                } catch (tc.a unused) {
                    ((tc) this).a8 = i;
                    FH(66);
                }
                if (z) {
                    int i2 = this.f89ei;
                    this.f89ei = i2 + 1;
                    j6(207, false, 3, i2);
                } else {
                    Hw(200, 3);
                }
            } else if (z) {
                int i3 = this.f89ei;
                this.f89ei = i3 + 1;
                j6(207, false, 1, i3);
            } else {
                Hw(200, 1);
            }
            int i4 = 3;
            while (((tc) this).we == 15) {
                Hw();
                if (((tc) this).we != 1) {
                    throw new tc.a();
                }
                Hw();
                if (((tc) this).we == 17) {
                    Hw();
                    m138Ws();
                    if (z) {
                        int i5 = this.f89ei;
                        this.f89ei = i5 + 1;
                        j6(207, false, 3, i5);
                    } else {
                        Hw(200, 3);
                    }
                } else if (z) {
                    int i6 = this.f89ei;
                    this.f89ei = i6 + 1;
                    j6(207, false, 1, i6);
                } else {
                    Hw(200, 1);
                }
                i4 += 2;
            }
            m145lg();
            if (z) {
                Hw(152, i4);
            } else {
                Hw(151, i4);
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -2771858147401183680L, this, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 2417095490109906312L)
    private void m132J0() {
        try {
            if (f85lg) {
                wu.j6(-2998904588715574080L, this);
            }
            j6("The unexpected end of expression");
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -2998904588715574080L, this);
            }
            throw th;
        }
    }

    @su(method = -641789298382609935L)
    private void m133J8() {
        try {
            if (f85lg) {
                wu.j6(-1712393505246089809L, this);
            }
            m138Ws();
            int i = 1;
            while (((tc) this).we == 15) {
                Hw();
                m138Ws();
                i += 2;
            }
            if (i > 1) {
                Hw(178, i);
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -1712393505246089809L, this);
            }
            throw th;
        }
    }

    @su(method = 1406854867984795320L)
    private void m134Mr() {
        try {
            if (f85lg) {
                wu.j6(1276743246748913664L, this);
            }
            Hw(8);
            int i = 2;
            if (((tc) this).we == 9) {
                Hw();
                Hw(140, 2);
                return;
            }
            do {
                switch (((tc) this).we) {
                    case 1:
                        m143j3();
                        break;
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        Hw();
                        break;
                    default:
                        throw new tc.a();
                }
                if (((tc) this).we == 17) {
                    Hw();
                } else {
                    Hw(26);
                }
                m138Ws();
                i += 3;
                if (((tc) this).we == 15) {
                    Hw();
                    i++;
                }
                Hw(9);
                Hw(140, i);
            } while (((tc) this).we != 9);
            Hw(9);
            Hw(140, i);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 1276743246748913664L, this);
            }
            throw th;
        }
    }

    @su(method = 2658915360574871711L)
    private void m135QX() {
        try {
            if (f85lg) {
                wu.j6(-685029495872330231L, this);
            }
            Hw();
            if (((tc) this).we != 1) {
                m136U2();
                m129EQ();
                Hw(124, 3);
            } else {
                Hw();
                m136U2();
                m129EQ();
                Hw(124, 4);
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -685029495872330231L, this);
            }
            throw th;
        }
    }

    @su(method = 1794970020560298131L)
    private void m136U2() {
        try {
            if (f85lg) {
                wu.j6(493818644006086945L, this);
            }
            Hw();
            int i = 2;
            if (((tc) this).we == 13) {
                Hw();
                Hw(190, 2);
                return;
            }
            while (((tc) this).we == 1) {
                Hw();
                Hw(191, 1);
                int i2 = i + 1;
                int i3 = ((tc) this).we;
                if (i3 == 13) {
                    Hw();
                    Hw(190, i2);
                    return;
                } else if (i3 != 15) {
                    Hw(13);
                    Hw(190, i2);
                    return;
                } else {
                    Hw();
                    i = i2 + 1;
                }
            }
            throw new tc.a();
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 493818644006086945L, this);
            }
            throw th;
        }
    }

    @su(method = -910649815541507875L)
    private void m137VH() {
        try {
            if (f85lg) {
                wu.j6(3044427610429468599L, this);
            }
            while (true) {
                int i = ((tc) this).we;
                if (i == 10) {
                    int i2 = 4;
                    Hw();
                    m138Ws();
                    while (((tc) this).we == 15) {
                        Hw();
                        m138Ws();
                        i2 += 2;
                    }
                    Hw(11);
                    Hw(165, i2);
                } else if (i == 12) {
                    m142gn();
                    Hw(175, 2);
                } else {
                    if (i != 16) {
                        return;
                    }
                    Hw();
                    if (((tc) this).we != 1) {
                        throw new tc.a();
                    }
                    m143j3();
                    Hw(159, 3);
                }
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 3044427610429468599L, this);
            }
            throw th;
        }
    }

    @su(method = -159423876478428720L)
    private void m138Ws() {
        try {
            if (f85lg) {
                wu.j6(-923673959786017692L, this);
            }
            m146rN();
            m140a8();
            m139XL();
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -923673959786017692L, this);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:19:0x003c A[Catch: a -> 0x0112, Throwable -> 0x0116, FALL_THROUGH, TryCatch #0 {a -> 0x0112, blocks: (B:8:0x0010, B:12:0x0021, B:13:0x0024, B:14:0x0027, B:15:0x002a, B:17:0x002f, B:19:0x003c, B:21:0x0043, B:22:0x0056, B:24:0x006a, B:32:0x00aa, B:36:0x00b5, B:37:0x00b8, B:38:0x00bb, B:39:0x00be, B:42:0x00c5, B:44:0x00dd, B:45:0x00df, B:46:0x00e2, B:47:0x00ee, B:49:0x0106, B:25:0x007e, B:27:0x0084, B:30:0x008d, B:31:0x00a4), top: B:61:0x0010, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:21:0x0043 A[Catch: a -> 0x0112, Throwable -> 0x0116, TryCatch #0 {a -> 0x0112, blocks: (B:8:0x0010, B:12:0x0021, B:13:0x0024, B:14:0x0027, B:15:0x002a, B:17:0x002f, B:19:0x003c, B:21:0x0043, B:22:0x0056, B:24:0x006a, B:32:0x00aa, B:36:0x00b5, B:37:0x00b8, B:38:0x00bb, B:39:0x00be, B:42:0x00c5, B:44:0x00dd, B:45:0x00df, B:46:0x00e2, B:47:0x00ee, B:49:0x0106, B:25:0x007e, B:27:0x0084, B:30:0x008d, B:31:0x00a4), top: B:61:0x0010, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:25:0x007e A[Catch: a -> 0x0112, Throwable -> 0x0116, TryCatch #0 {a -> 0x0112, blocks: (B:8:0x0010, B:12:0x0021, B:13:0x0024, B:14:0x0027, B:15:0x002a, B:17:0x002f, B:19:0x003c, B:21:0x0043, B:22:0x0056, B:24:0x006a, B:32:0x00aa, B:36:0x00b5, B:37:0x00b8, B:38:0x00bb, B:39:0x00be, B:42:0x00c5, B:44:0x00dd, B:45:0x00df, B:46:0x00e2, B:47:0x00ee, B:49:0x0106, B:25:0x007e, B:27:0x0084, B:30:0x008d, B:31:0x00a4), top: B:61:0x0010, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:27:0x0084 A[Catch: a -> 0x0112, Throwable -> 0x0116, TRY_LEAVE, TryCatch #0 {a -> 0x0112, blocks: (B:8:0x0010, B:12:0x0021, B:13:0x0024, B:14:0x0027, B:15:0x002a, B:17:0x002f, B:19:0x003c, B:21:0x0043, B:22:0x0056, B:24:0x006a, B:32:0x00aa, B:36:0x00b5, B:37:0x00b8, B:38:0x00bb, B:39:0x00be, B:42:0x00c5, B:44:0x00dd, B:45:0x00df, B:46:0x00e2, B:47:0x00ee, B:49:0x0106, B:25:0x007e, B:27:0x0084, B:30:0x008d, B:31:0x00a4), top: B:61:0x0010, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:34:0x00b1 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:42:0x00c5 A[Catch: a -> 0x0112, Throwable -> 0x0116, TryCatch #0 {a -> 0x0112, blocks: (B:8:0x0010, B:12:0x0021, B:13:0x0024, B:14:0x0027, B:15:0x002a, B:17:0x002f, B:19:0x003c, B:21:0x0043, B:22:0x0056, B:24:0x006a, B:32:0x00aa, B:36:0x00b5, B:37:0x00b8, B:38:0x00bb, B:39:0x00be, B:42:0x00c5, B:44:0x00dd, B:45:0x00df, B:46:0x00e2, B:47:0x00ee, B:49:0x0106, B:25:0x007e, B:27:0x0084, B:30:0x008d, B:31:0x00a4), top: B:61:0x0010, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:46:0x00e2 A[Catch: a -> 0x0112, Throwable -> 0x0116, TryCatch #0 {a -> 0x0112, blocks: (B:8:0x0010, B:12:0x0021, B:13:0x0024, B:14:0x0027, B:15:0x002a, B:17:0x002f, B:19:0x003c, B:21:0x0043, B:22:0x0056, B:24:0x006a, B:32:0x00aa, B:36:0x00b5, B:37:0x00b8, B:38:0x00bb, B:39:0x00be, B:42:0x00c5, B:44:0x00dd, B:45:0x00df, B:46:0x00e2, B:47:0x00ee, B:49:0x0106, B:25:0x007e, B:27:0x0084, B:30:0x008d, B:31:0x00a4), top: B:61:0x0010, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:49:0x0106 A[Catch: a -> 0x0112, Throwable -> 0x0116, TRY_LEAVE, TryCatch #0 {a -> 0x0112, blocks: (B:8:0x0010, B:12:0x0021, B:13:0x0024, B:14:0x0027, B:15:0x002a, B:17:0x002f, B:19:0x003c, B:21:0x0043, B:22:0x0056, B:24:0x006a, B:32:0x00aa, B:36:0x00b5, B:37:0x00b8, B:38:0x00bb, B:39:0x00be, B:42:0x00c5, B:44:0x00dd, B:45:0x00df, B:46:0x00e2, B:47:0x00ee, B:49:0x0106, B:25:0x007e, B:27:0x0084, B:30:0x008d, B:31:0x00a4), top: B:61:0x0010, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:68:0x00c3 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:76:0x006a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:77:0x00a4 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:81:0x0010 A[EDGE_INSN: B:81:0x0010->B:79:0x0010 BREAK  A[LOOP:2: B:41:0x00c3->B:89:0x00c3], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:82:0x0010 A[EDGE_INSN: B:82:0x0010->B:79:0x0010 BREAK  A[LOOP:2: B:41:0x00c3->B:89:0x00c3], SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:87:0x00ee A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:88:0x00dd A[SYNTHETIC] */
    @su(method = 299785771832634189L)
    private void m139XL() {
        int i;
        try {
            if (f85lg) {
                wu.j6(5728797401255770807L, this);
            }
            int i2 = this.f88P8;
            int i3 = 0;
            while (true) {
                try {
                    int i4 = ((tc) this).we;
                    if (i4 != 23 && i4 != 25 && i4 != 27) {
                        switch (i4) {
                            default:
                                switch (i4) {
                                    default:
                                        switch (i4) {
                                            default:
                                                switch (i4) {
                                                    case 114:
                                                    case 115:
                                                    case 116:
                                                        break;
                                                    default:
                                                        for (int i5 = 0; i5 < i3; i5++) {
                                                            this.f88P8--;
                                                            Hw(172, 3);
                                                        }
                                                        return;
                                                }
                                            case 35:
                                            case 36:
                                            case 37:
                                            case 38:
                                            case 39:
                                            case 40:
                                            case 41:
                                            case 42:
                                            case 43:
                                            case 44:
                                            case 45:
                                            case 46:
                                            case 47:
                                            case 48:
                                            case 49:
                                            case 50:
                                            case 51:
                                            case 52:
                                            case 53:
                                                if (this.f88P8 >= this.f93vy.length) {
                                                    int[] iArr = new int[(this.f93vy.length * 2) + 1];
                                                    System.arraycopy(this.f93vy, 0, iArr, 0, this.f93vy.length);
                                                    this.f93vy = iArr;
                                                }
                                                this.f93vy[this.f88P8] = ((tc) this).we;
                                                this.f88P8++;
                                                i3++;
                                                if (((tc) this).we == 25) {
                                                    Hw();
                                                    m138Ws();
                                                    Hw(26);
                                                    Hw(210, 3);
                                                    m146rN();
                                                } else if (((tc) this).we == 17) {
                                                    Hw();
                                                    int i6 = ((tc) this).a8;
                                                    try {
                                                        m146rN();
                                                    } catch (tc.a unused) {
                                                        ((tc) this).a8 = i6;
                                                        FH(66);
                                                        this.f88P8--;
                                                        i3--;
                                                        Hw(172, 3);
                                                        m149we();
                                                    }
                                                } else {
                                                    Hw();
                                                    m146rN();
                                                }
                                                m140a8();
                                                i = ((tc) this).we;
                                                if (i == 23 && i != 25 && i != 27) {
                                                    switch (i) {
                                                        case 17:
                                                        case 18:
                                                        case 19:
                                                        case 20:
                                                        case 21:
                                                            break;
                                                        default:
                                                            switch (i) {
                                                                case 29:
                                                                case 30:
                                                                case 31:
                                                                case 32:
                                                                case 33:
                                                                    break;
                                                                default:
                                                                    switch (i) {
                                                                        case 35:
                                                                        case 36:
                                                                        case 37:
                                                                        case 38:
                                                                        case 39:
                                                                        case 40:
                                                                        case 41:
                                                                        case 42:
                                                                        case 43:
                                                                        case 44:
                                                                        case 45:
                                                                        case 46:
                                                                        case 47:
                                                                        case 48:
                                                                        case 49:
                                                                        case 50:
                                                                        case 51:
                                                                        case 52:
                                                                        case 53:
                                                                            break;
                                                                        default:
                                                                            switch (i) {
                                                                                case 114:
                                                                                case 115:
                                                                                case 116:
                                                                                    break;
                                                                                default:
                                                                                    continue;
                                                                            }
                                                                            break;
                                                                    }
                                                                    break;
                                                            }
                                                            break;
                                                    }
                                                    break;
                                                }
                                                while (i3 > 0) {
                                                    if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) != this.f90er.ei(((tc) this).we)) {
                                                        if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) <= this.f90er.ei(((tc) this).we)) {
                                                        }
                                                        this.f88P8--;
                                                        i3--;
                                                        Hw(172, 3);
                                                        break;
                                                    } else {
                                                        switch (((tc) this).we) {
                                                            case 17:
                                                            case 20:
                                                            case 23:
                                                            case 25:
                                                            case 29:
                                                            case 31:
                                                            case 33:
                                                            case 37:
                                                            case 40:
                                                            case 43:
                                                            case 47:
                                                            case 52:
                                                            case 53:
                                                                continue;
                                                                continue;
                                                                continue;
                                                                continue;
                                                                break;
                                                            default:
                                                                this.f88P8--;
                                                                i3--;
                                                                Hw(172, 3);
                                                                break;
                                                        }
                                                    }
                                                }
                                                break;
                                        }
                                    case 29:
                                    case 30:
                                    case 31:
                                    case 32:
                                    case 33:
                                        if (this.f88P8 >= this.f93vy.length) {
                                            int[] iArr2 = new int[(this.f93vy.length * 2) + 1];
                                            System.arraycopy(this.f93vy, 0, iArr2, 0, this.f93vy.length);
                                            this.f93vy = iArr2;
                                        }
                                        this.f93vy[this.f88P8] = ((tc) this).we;
                                        this.f88P8++;
                                        i3++;
                                        if (((tc) this).we == 25) {
                                            Hw();
                                            m138Ws();
                                            Hw(26);
                                            Hw(210, 3);
                                            m146rN();
                                        } else if (((tc) this).we == 17) {
                                            Hw();
                                            int i7 = ((tc) this).a8;
                                            m146rN();
                                        } else {
                                            Hw();
                                            m146rN();
                                        }
                                        m140a8();
                                        i = ((tc) this).we;
                                        if (i == 23) {
                                        }
                                        while (i3 > 0) {
                                            if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) != this.f90er.ei(((tc) this).we)) {
                                                if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) <= this.f90er.ei(((tc) this).we)) {
                                                    this.f88P8--;
                                                    i3--;
                                                    Hw(172, 3);
                                                }
                                                break;
                                            } else {
                                                switch (((tc) this).we) {
                                                    case 17:
                                                    case 20:
                                                    case 23:
                                                    case 25:
                                                    case 29:
                                                    case 31:
                                                    case 33:
                                                    case 37:
                                                    case 40:
                                                    case 43:
                                                    case 47:
                                                    case 52:
                                                    case 53:
                                                        continue;
                                                        continue;
                                                        continue;
                                                        continue;
                                                        break;
                                                    default:
                                                        this.f88P8--;
                                                        i3--;
                                                        Hw(172, 3);
                                                        break;
                                                }
                                            }
                                        }
                                        break;
                                }
                            case 17:
                            case 18:
                            case 19:
                            case 20:
                            case 21:
                                if (this.f88P8 >= this.f93vy.length) {
                                    int[] iArr3 = new int[(this.f93vy.length * 2) + 1];
                                    System.arraycopy(this.f93vy, 0, iArr3, 0, this.f93vy.length);
                                    this.f93vy = iArr3;
                                }
                                this.f93vy[this.f88P8] = ((tc) this).we;
                                this.f88P8++;
                                i3++;
                                if (((tc) this).we == 25) {
                                    Hw();
                                    m138Ws();
                                    Hw(26);
                                    Hw(210, 3);
                                    m146rN();
                                } else if (((tc) this).we == 17) {
                                    Hw();
                                    int i8 = ((tc) this).a8;
                                    m146rN();
                                } else {
                                    Hw();
                                    m146rN();
                                }
                                m140a8();
                                i = ((tc) this).we;
                                if (i == 23) {
                                }
                                while (i3 > 0) {
                                    if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) != this.f90er.ei(((tc) this).we)) {
                                        if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) <= this.f90er.ei(((tc) this).we)) {
                                            this.f88P8--;
                                            i3--;
                                            Hw(172, 3);
                                        }
                                        break;
                                    } else {
                                        switch (((tc) this).we) {
                                            case 17:
                                            case 20:
                                            case 23:
                                            case 25:
                                            case 29:
                                            case 31:
                                            case 33:
                                            case 37:
                                            case 40:
                                            case 43:
                                            case 47:
                                            case 52:
                                            case 53:
                                                continue;
                                                continue;
                                                continue;
                                                continue;
                                                break;
                                            default:
                                                this.f88P8--;
                                                i3--;
                                                Hw(172, 3);
                                                break;
                                        }
                                    }
                                }
                                break;
                        }
                    }
                    if (this.f88P8 >= this.f93vy.length) {
                        int[] iArr4 = new int[(this.f93vy.length * 2) + 1];
                        System.arraycopy(this.f93vy, 0, iArr4, 0, this.f93vy.length);
                        this.f93vy = iArr4;
                    }
                    this.f93vy[this.f88P8] = ((tc) this).we;
                    this.f88P8++;
                    i3++;
                    if (((tc) this).we == 25) {
                        Hw();
                        m138Ws();
                        Hw(26);
                        Hw(210, 3);
                        m146rN();
                    } else if (((tc) this).we == 17) {
                        Hw();
                        int i9 = ((tc) this).a8;
                        m146rN();
                    } else {
                        Hw();
                        m146rN();
                    }
                    m140a8();
                    i = ((tc) this).we;
                    if (i == 23) {
                    }
                    while (i3 > 0) {
                        if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) != this.f90er.ei(((tc) this).we)) {
                            switch (((tc) this).we) {
                                case 17:
                                case 20:
                                case 23:
                                case 25:
                                case 29:
                                case 31:
                                case 33:
                                case 37:
                                case 40:
                                case 43:
                                case 47:
                                case 52:
                                case 53:
                                    continue;
                                    continue;
                                    continue;
                                    continue;
                                    break;
                                default:
                                    this.f88P8--;
                                    i3--;
                                    Hw(172, 3);
                                    break;
                            }
                        } else {
                            if (this.f90er.ei(this.f93vy[this.f88P8 - 1]) <= this.f90er.ei(((tc) this).we)) {
                                break;
                            }
                            this.f88P8--;
                            i3--;
                            Hw(172, 3);
                        }
                    }
                } catch (tc.a e) {
                    this.f88P8 = i2;
                    throw e;
                }
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 5728797401255770807L, this);
            }
            throw th;
        }
    }

    @su(method = 4074532736402944784L)
    private void m140a8() {
        try {
            if (f85lg) {
                wu.j6(7534545935375686480L, this);
            }
            while (true) {
                int i = ((tc) this).we;
                if (i == 22 || i == 28) {
                    Hw();
                    Hw(171, 2);
                } else {
                    if (i != 103) {
                        return;
                    }
                    Hw();
                    m138Ws();
                    Hw(177, 3);
                }
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 7534545935375686480L, this);
            }
            throw th;
        }
    }

    @su(method = -5847427185910239475L)
    private boolean m141aM() {
        try {
            if (f85lg) {
                wu.j6(-1634404971317449337L, this);
            }
            return ((tc) this).J0 > 0 && ((tc) this).aM[((tc) this).J0 - 1] != ((tc) this).XL[((tc) this).J0];
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -1634404971317449337L, this);
            }
            throw th;
        }
    }

    @su(method = -691751059474571411L)
    private void m142gn() {
        try {
            if (f85lg) {
                wu.j6(2014709798797824275L, this);
            }
            Hw();
            if (((tc) this).we == 13) {
                Hw();
                Hw(197, 2);
                return;
            }
            int i = 3;
            int i2 = ((tc) this).a8;
            try {
                m138Ws();
            } catch (tc.a unused) {
                ((tc) this).a8 = i2;
                FH(66);
                m149we();
            }
            while (((tc) this).we == 15) {
                Hw();
                int i3 = ((tc) this).a8;
                try {
                    m138Ws();
                } catch (tc.a unused2) {
                    ((tc) this).a8 = i3;
                    FH(66);
                    m149we();
                }
                i += 2;
            }
            Hw(13);
            Hw(197, i);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 2014709798797824275L, this);
            }
            throw th;
        }
    }

    @su(method = 7672547529960985441L)
    private void m143j3() {
        try {
            if (f85lg) {
                wu.j6(-7626934055731183381L, this);
            }
            ((tc) this).a8++;
            if (((tc) this).a8 >= ((tc) this).U2.length) {
                int[] iArr = new int[(((tc) this).U2.length * 2) + 1];
                System.arraycopy(((tc) this).U2, 0, iArr, 0, ((tc) this).U2.length);
                ((tc) this).U2 = iArr;
            }
            int[] iArr2 = ((tc) this).U2;
            int i = ((tc) this).a8;
            Sa sa = ((tc) this).EQ;
            int i2 = ((tc) this).we;
            int i3 = ((tc) this).QX[((tc) this).J0];
            int i4 = ((tc) this).XL[((tc) this).J0];
            int i5 = ((tc) this).j3[((tc) this).J0];
            int i6 = ((tc) this).aM[((tc) this).J0];
            int i7 = ((tc) this).Mr[((tc) this).J0];
            int i8 = this.f92nw;
            this.f92nw = i8 + 1;
            iArr2[i] = sa.j6(i2, false, i3, i4, i5, i6, i7, i8);
            if (((tc) this).J0 < ((tc) this).J8) {
                ((tc) this).J0++;
                ((tc) this).we = ((tc) this).Ws[((tc) this).J0];
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -7626934055731183381L, this);
            }
            throw th;
        }
    }

    @su(method = -846860444850224259L)
    private void m144j6(boolean z) {
        try {
            if (f85lg) {
                wu.j6(-1353542241383681909L, this, z);
            }
            if (((tc) this).we == 14) {
                Hw();
                return;
            }
            if (z) {
                VH(14);
            }
            FH(14);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -1353542241383681909L, this, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 3813705449697334456L)
    private void m145lg() {
        try {
            if (f85lg) {
                wu.j6(-1462718844586587580L, this);
            }
            m144j6(true);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -1462718844586587580L, this);
            }
            throw th;
        }
    }

    @su(method = 2780200118036388520L)
    private void m146rN() {
        try {
            if (f85lg) {
                wu.j6(4190658156859015392L, this);
            }
            int i = 0;
            while (true) {
                int i2 = ((tc) this).we;
                if (i2 != 21 && i2 != 22 && i2 != 24 && i2 != 34 && i2 != 27 && i2 != 28) {
                    break;
                }
                Hw();
                i++;
            }
            if (((tc) this).we == 12) {
                Hw();
                m133J8();
                Hw(13);
                Hw(168, 3);
            } else {
                m147tp();
            }
            m137VH();
            for (int i3 = 0; i3 < i; i3++) {
                Hw(170, 2);
            }
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 4190658156859015392L, this);
            }
            throw th;
        }
    }

    @su(method = -3186790039037851487L)
    private void m147tp() {
        try {
            if (f85lg) {
                wu.j6(-1317330291135662449L, this);
            }
            int i = ((tc) this).we;
            if (i == 10) {
                m148u7();
                return;
            }
            if (i == 58) {
                Hw();
                m146rN();
                Hw(176, 2);
                return;
            }
            if (i != 74) {
                if (i == 97) {
                    m135QX();
                    return;
                }
                if (i == 105) {
                    Hw();
                    m138Ws();
                    Hw(173, 2);
                    return;
                }
                if (i == 118) {
                    Hw();
                    m138Ws();
                    Hw(163, 2);
                    return;
                }
                switch (i) {
                    case 1:
                        Hw();
                        Hw(161, 1);
                        return;
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                        break;
                    case 8:
                        m134Mr();
                        return;
                    default:
                        switch (i) {
                            case 66:
                            case 68:
                                break;
                            case 67:
                                if (Zo(1) == 12) {
                                    DW(199, false, 0);
                                }
                                Hw();
                                Hw(166, 1);
                                return;
                            case 69:
                                Hw();
                                m138Ws();
                                Hw(164, 2);
                                return;
                            default:
                                throw new tc.a();
                        }
                        break;
                }
            }
            Hw();
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -1317330291135662449L, this);
            }
            throw th;
        }
    }

    @su(method = 1071706129588402448L)
    private void m148u7() {
        try {
            if (f85lg) {
                wu.j6(-2006130334670693616L, this);
            }
            Hw(10);
            int i = 2;
            if (((tc) this).we == 11) {
                Hw();
                Hw(196, 2);
                return;
            }
            do {
                m138Ws();
                i++;
                if (((tc) this).we != 15) {
                    break;
                }
                Hw();
                i++;
            } while (((tc) this).we != 11);
            Hw(11);
            Hw(196, i);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -2006130334670693616L, this);
            }
            throw th;
        }
    }

    @su(method = -1203633148467692029L)
    private void m149we() {
        try {
            if (f85lg) {
                wu.j6(511642300735123593L, this);
            }
            j6("The unexpected end of expression");
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, 511642300735123593L, this);
            }
            throw th;
        }
    }

    @su(method = -2955364340325122904L)
    protected void m150j6() {
        try {
            if (f85lg) {
                wu.j6(-1103387147823781152L, this);
            }
            j6(223, false, m130FH(true), 0);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -1103387147823781152L, this);
            }
            throw th;
        }
    }

    public void m151j6(Wa wa, Da da, boolean z, Sa sa) {
        try {
            if (f85lg) {
                wu.j6(-178410662473771152L, this, wa, da, new Boolean(z), sa);
            }
            this.f89ei = 2;
            this.f92nw = 100000;
            super.j6(wa, da, z, sa);
        } catch (Throwable th) {
            if (f86rN) {
                wu.j6(th, -178410662473771152L, this, wa, da, new Boolean(z), sa);
            }
            throw th;
        }
    }
}
