package abcd;

import org.eclipse.jgit.JGitText;

public class C0006iD extends IllegalStateException {
    public C0006iD() {
        super(JGitText.j6().bareRepositoryNoWorkdirAndIndex);
    }
}
