package abcd;

public abstract class AbstractC0008Bm extends Am {

    private final Qm f43DW;

    public AbstractC0008Bm(String str, Qm qm) throws iu {
        super(str);
        try {
            if (qm.Zo()) {
                throw new iu("localVariables.isMutable()");
            }
            this.f43DW = qm;
        } catch (NullPointerException unused) {
            throw new NullPointerException("localVariables == null");
        }
    }

    public final int m43Hw() {
        return (this.f43DW.size() * 10) + 8;
    }

    public final Qm m44j6() {
        return this.f43DW;
    }
}
