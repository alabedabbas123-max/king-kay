package abcd;

public abstract class AbstractC0061Fs extends Ms {

    private final Hs f356DW;

    private final Ks f357j6;

    AbstractC0061Fs(Ks ks, Hs hs) {
        if (ks == null) {
            throw new NullPointerException("definingClass == null");
        }
        if (hs == null) {
            throw new NullPointerException("nat == null");
        }
        this.f357j6 = ks;
        this.f356DW = hs;
    }

    protected int m644DW(ms msVar) {
        AbstractC0061Fs abstractC0061Fs = (AbstractC0061Fs) msVar;
        int iJ6 = this.f357j6.j6(abstractC0061Fs.f357j6);
        return iJ6 != 0 ? iJ6 : this.f356DW.J8().j6(abstractC0061Fs.f356DW.J8());
    }

    public final boolean m645Hw() {
        return false;
    }

    public final Ks m646VH() {
        return this.f357j6;
    }

    public final String m647aM() {
        return this.f357j6.aM() + '.' + this.f356DW.aM();
    }

    public final boolean equals(Object obj) {
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        AbstractC0061Fs abstractC0061Fs = (AbstractC0061Fs) obj;
        return this.f357j6.equals(abstractC0061Fs.f357j6) && this.f356DW.equals(abstractC0061Fs.f356DW);
    }

    public final int hashCode() {
        return (this.f357j6.hashCode() * 31) ^ this.f356DW.hashCode();
    }

    public final String toString() {
        return Zo() + '{' + m647aM() + '}';
    }

    public final Hs m648we() {
        return this.f356DW;
    }
}
