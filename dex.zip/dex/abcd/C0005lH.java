package abcd;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Iterator;
import org.eclipse.jgit.JGitText;

public class C0005lH {

    private final int[] f11DW;

    private final long[] f12FH;

    private final int[] f13Hw;

    private final bH f14j6;

    private final int[] f15v5;

    public C0005lH(bH bHVar) {
        int i;
        this.f14j6 = bHVar;
        long jJ6 = this.f14j6.j6();
        long jDW = this.f14j6.DW();
        long j = jJ6 - jDW;
        if (j > 2147483647L || jDW > 2147483647L || jJ6 > 4294967295L) {
            throw new IllegalArgumentException(JGitText.j6().hugeIndexesAreNotSupportedByJgitYet);
        }
        this.f11DW = new int[(int) j];
        this.f12FH = new long[(int) jDW];
        this.f13Hw = new int[this.f11DW.length];
        this.f15v5 = new int[this.f12FH.length];
        Iterator it = this.f14j6.iterator();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (it.hasNext()) {
            long jJ7 = ((bH.b) it.next()).j6();
            if (jJ7 < 2147483647L) {
                this.f11DW[i4] = (int) jJ7;
                i4++;
            } else {
                this.f12FH[i3] = jJ7;
                i3++;
            }
        }
        Arrays.sort(this.f11DW);
        Arrays.sort(this.f12FH);
        Iterator it2 = this.f14j6.iterator();
        while (it2.hasNext()) {
            long jJ8 = ((bH.b) it2.next()).j6();
            if (jJ8 < 2147483647L) {
                i = i2 + 1;
                this.f13Hw[Arrays.binarySearch(this.f11DW, (int) jJ8)] = i2;
            } else {
                i = i2 + 1;
                this.f15v5[Arrays.binarySearch(this.f12FH, jJ8)] = i2;
            }
            i2 = i;
        }
    }

    public long m13j6(long j, long j2) throws YC {
        if (j > 2147483647L) {
            int iBinarySearch = Arrays.binarySearch(this.f12FH, j);
            if (iBinarySearch < 0) {
                throw new YC(MessageFormat.format(JGitText.j6().cantFindObjectInReversePackIndexForTheSpecifiedOffset, Long.valueOf(j)));
            }
            int i = iBinarySearch + 1;
            long[] jArr = this.f12FH;
            return i == jArr.length ? j2 : jArr[i];
        }
        int iBinarySearch2 = Arrays.binarySearch(this.f11DW, (int) j);
        if (iBinarySearch2 < 0) {
            throw new YC(MessageFormat.format(JGitText.j6().cantFindObjectInReversePackIndexForTheSpecifiedOffset, Long.valueOf(j)));
        }
        int i2 = iBinarySearch2 + 1;
        int[] iArr = this.f11DW;
        if (i2 != iArr.length) {
            return iArr[i2];
        }
        long[] jArr2 = this.f12FH;
        return jArr2.length > 0 ? jArr2[0] : j2;
    }

    public yE m14j6(long j) {
        if (j <= 2147483647L) {
            int iBinarySearch = Arrays.binarySearch(this.f11DW, (int) j);
            if (iBinarySearch < 0) {
                return null;
            }
            return this.f14j6.v5(this.f13Hw[iBinarySearch]);
        }
        int iBinarySearch2 = Arrays.binarySearch(this.f12FH, j);
        if (iBinarySearch2 < 0) {
            return null;
        }
        return this.f14j6.v5(this.f15v5[iBinarySearch2]);
    }
}
