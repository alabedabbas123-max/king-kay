package abcd;

import org.eclipse.jgit.JGitText;

public abstract class AbstractC0054dJ extends fJ {

    private AbstractC0010cJ f199Mr;

    private ZI f200U2;

    protected AbstractC0054dJ(UE ue, HJ hj) {
        super(ue, hj);
        this.f199Mr = AbstractC0010cJ.m55j6();
    }

    public void m302DW() {
        ZI zi = this.f200U2;
        if (zi != null) {
            try {
                this.f199Mr.m58j6(zi);
            } finally {
                this.f200U2 = null;
            }
        }
    }

    protected ZI m303aM() {
        ZI zi = this.f200U2;
        if (zi != null) {
            return zi;
        }
        this.f200U2 = this.f199Mr.m57j6(((jJ) this).Zo, FH(), ((jJ) this).v5.gn(), gn() > 0 ? gn() * 1000 : 0);
        return this.f200U2;
    }

    public void m304j6(AbstractC0010cJ abstractC0010cJ) {
        if (abstractC0010cJ == null) {
            throw new NullPointerException(JGitText.j6().theFactoryMustNotBeNull);
        }
        if (this.f200U2 != null) {
            throw new IllegalStateException(JGitText.j6().anSSHSessionHasBeenAlreadyCreated);
        }
        this.f199Mr = abstractC0010cJ;
    }
}
