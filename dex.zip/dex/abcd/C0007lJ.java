package abcd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;
import org.eclipse.jgit.JGitText;

public class C0007lJ extends sI implements SJ {

    static final DJ f20Mr = new kJ();

    private final _H f21U2;

    private final String f22a8;

    private final String f23lg;

    class a extends RJ {

        private final String f24DW;

        private final String f26j6;

        a(String str, String str2) {
            this.f26j6 = str;
            this.f24DW = str2;
        }

        private String m30gn(String str) {
            if (str.endsWith("/")) {
                str = str.substring(0, str.length() - 1);
            }
            String strSubstring = this.f24DW;
            while (str.startsWith("../")) {
                strSubstring = strSubstring.substring(0, strSubstring.lastIndexOf(47));
                str = str.substring(3);
            }
            return String.valueOf(strSubstring) + "/" + str;
        }

        private ME.a m31j6(ME me) {
            return (me == null || me.j6() != ME.a.FH) ? ME.a.DW : ME.a.Hw;
        }

        private ME m32j6(TreeMap<String, ME> treeMap, String str) throws yD {
            String str2 = "../" + str;
            try {
                BufferedReader bufferedReaderZo = Zo(str2);
                try {
                    String line = bufferedReaderZo.readLine();
                    bufferedReaderZo.close();
                    if (line == null) {
                        throw new yD(m36Hw(), MessageFormat.format(JGitText.j6().transportExceptionEmptyRef, str));
                    }
                    if (!line.startsWith("ref: ")) {
                        if (!yE.DW(line)) {
                            throw new yD(m36Hw(), MessageFormat.format(JGitText.j6().transportExceptionBadRef, str, line));
                        }
                        BE.c cVar = new BE.c(m31j6(treeMap.get(str)), str, yE.j6(line));
                        treeMap.put(cVar.getName(), cVar);
                        return cVar;
                    }
                    String strSubstring = line.substring(5);
                    ME cVar2 = treeMap.get(strSubstring);
                    if (cVar2 == null) {
                        cVar2 = m32j6(treeMap, strSubstring);
                    }
                    if (cVar2 == null) {
                        cVar2 = new BE.c(ME.a.j6, strSubstring, (yE) null);
                    }
                    kF kFVar = new kF(str, cVar2);
                    treeMap.put(kFVar.getName(), kFVar);
                    return kFVar;
                } catch (Throwable th) {
                    bufferedReaderZo.close();
                    throw th;
                }
            } catch (FileNotFoundException unused) {
                return null;
            } catch (IOException e) {
                throw new yD(m36Hw(), MessageFormat.format(JGitText.j6().transportExceptionReadRef, str2), e);
            }
        }

        private void m33j6(TreeMap<String, ME> treeMap) throws yD {
            try {
                Iterator it = C0007lJ.this.f21U2.FH(C0007lJ.this.f22a8, m30gn("../refs")).iterator();
                while (it.hasNext()) {
                    m32j6(treeMap, "refs/" + ((String) it.next()));
                }
            } catch (IOException e) {
                throw new yD(m36Hw(), JGitText.j6().cannotListRefs, e);
            }
        }

        Collection<RJ> m34DW() {
            try {
                return VH("info/alternates");
            } catch (FileNotFoundException unused) {
                return null;
            }
        }

        Collection<String> m35FH() {
            HashSet<String> hashSet = new HashSet();
            hashSet.addAll(C0007lJ.this.f21U2.FH(C0007lJ.this.f22a8, m30gn("pack")));
            ArrayList arrayList = new ArrayList();
            for (String str : hashSet) {
                if (str.startsWith("pack-") && str.endsWith(".pack")) {
                    if (hashSet.contains(String.valueOf(str.substring(0, str.length() - 5)) + ".idx")) {
                        arrayList.add(str);
                    }
                }
            }
            return arrayList;
        }

        HJ m36Hw() {
            return new HJ().Hw("amazon-s3").j6(this.f26j6).FH("/" + this.f24DW);
        }

        RJ.a m37Hw(String str) throws IOException {
            URLConnection uRLConnectionDW = C0007lJ.this.f21U2.DW(C0007lJ.this.f22a8, m30gn(str));
            InputStream inputStream = uRLConnectionDW.getInputStream();
            InputStream inputStreamJ6 = C0007lJ.this.f21U2.j6(uRLConnectionDW);
            int contentLength = uRLConnectionDW.getContentLength();
            if (inputStream != inputStreamJ6) {
                contentLength = -1;
            }
            return new RJ.a(inputStreamJ6, contentLength);
        }

        OutputStream m38j6(String str, LE le, String str2) {
            return C0007lJ.this.f21U2.j6(C0007lJ.this.f22a8, m30gn(str), le, str2);
        }

        void m39j6() {
        }

        void m40j6(String str) {
            C0007lJ.this.f21U2.j6(C0007lJ.this.f22a8, m30gn(str));
        }

        void m41j6(String str, byte[] bArr) {
            C0007lJ.this.f21U2.j6(C0007lJ.this.f22a8, m30gn(str), bArr);
        }

        RJ m42v5(String str) {
            return C0007lJ.this.new a(this.f26j6, m30gn(str));
        }

        Map<String, ME> m43v5() throws yD {
            TreeMap<String, ME> treeMap = new TreeMap<>();
            j6(treeMap);
            m33j6(treeMap);
            m32j6(treeMap, "HEAD");
            return treeMap;
        }
    }

    C0007lJ(UE ue, HJ hj) {
        super(ue, hj);
        this.f21U2 = new _H(m24aM());
        this.f22a8 = hj.j6();
        String strHw = hj.Hw();
        strHw = strHw.startsWith("/") ? strHw.substring(1) : strHw;
        this.f23lg = strHw.endsWith("/") ? strHw.substring(0, strHw.length() - 1) : strHw;
    }

    private Properties m24aM() {
        if (((jJ) this).v5.VH() != null) {
            File file = new File(((jJ) this).v5.VH(), ((jJ) this).Zo.gn());
            if (file.isFile()) {
                return m26j6(file);
            }
        }
        File file2 = new File(((jJ) this).v5.gn().Zo(), ((jJ) this).Zo.gn());
        if (file2.isFile()) {
            return m26j6(file2);
        }
        Properties properties = new Properties();
        properties.setProperty("accesskey", ((jJ) this).Zo.gn());
        properties.setProperty("secretkey", ((jJ) this).Zo.FH());
        return properties;
    }

    private static Properties m26j6(File file) throws jD {
        try {
            return _H.j6(file);
        } catch (IOException e) {
            throw new jD(MessageFormat.format(JGitText.j6().cannotReadFile, file), e);
        }
    }

    public void m27DW() {
    }

    public InterfaceC0092nI m28QX() {
        a aVar = new a(this.f22a8, String.valueOf(this.f23lg) + "/objects");
        OJ oj = new OJ(this, aVar);
        oj.j6(aVar.m43v5());
        return oj;
    }

    public LI m29XL() {
        a aVar = new a(this.f22a8, String.valueOf(this.f23lg) + "/objects");
        QJ qj = new QJ(this, aVar);
        qj.j6(aVar.m43v5());
        return qj;
    }
}
