package abcd;

public class C0010Qw extends Jw {
}
