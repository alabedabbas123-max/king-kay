package abcd;

public abstract class AbstractC0052jF extends gE {
    public AbstractC0052jF(gE gEVar) {
        super(gEVar);
    }

    public abstract void m276v5();
}
