package abcd;

public abstract class AbstractC0020fJ extends jJ {
    protected AbstractC0020fJ(UE ue, HJ hj) {
        super(ue, hj);
    }
}
