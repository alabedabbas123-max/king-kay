package abcd;

import java.util.ArrayList;

public final class C0001Nn extends qo {

    private final ms f3VH;

    private final ArrayList<ms> f4Zo;

    private final int f5gn;

    private final int f6u7;

    private final Sn f7v5;

    public C0001Nn(hs hsVar, Sn sn, ArrayList<ms> arrayList, ms msVar) {
        super(hsVar, cs.FH);
        if (sn == null) {
            throw new NullPointerException("user == null");
        }
        if (arrayList == null) {
            throw new NullPointerException("values == null");
        }
        if (arrayList.size() <= 0) {
            throw new IllegalArgumentException("Illegal number of init values");
        }
        this.f3VH = msVar;
        if (msVar == Ks.J0 || msVar == Ks.we) {
            this.f5gn = 1;
        } else if (msVar == Ks.j3 || msVar == Ks.J8) {
            this.f5gn = 2;
        } else if (msVar == Ks.aM || msVar == Ks.QX) {
            this.f5gn = 4;
        } else {
            if (msVar != Ks.XL && msVar != Ks.Ws) {
                throw new IllegalArgumentException("Unexpected constant type");
            }
            this.f5gn = 8;
        }
        this.f7v5 = sn;
        this.f4Zo = arrayList;
        this.f6u7 = arrayList.size();
    }

    public int m14DW() {
        return (((this.f6u7 * this.f5gn) + 1) / 2) + 4;
    }

    public Vn m15j6(cs csVar) {
        return new C0001Nn(VH(), this.f7v5, this.f4Zo, this.f3VH);
    }

    protected String m16j6() {
        StringBuffer stringBuffer = new StringBuffer(100);
        int size = this.f4Zo.size();
        for (int i = 0; i < size; i++) {
            stringBuffer.append("\n    ");
            stringBuffer.append(i);
            stringBuffer.append(": ");
            stringBuffer.append(this.f4Zo.get(i).aM());
        }
        return stringBuffer.toString();
    }

    protected String m17j6(boolean z) {
        int iFH = this.f7v5.FH();
        StringBuffer stringBuffer = new StringBuffer(100);
        int size = this.f4Zo.size();
        stringBuffer.append("fill-array-data-payload // for fill-array-data @ ");
        stringBuffer.append(Yt.v5(iFH));
        for (int i = 0; i < size; i++) {
            stringBuffer.append("\n  ");
            stringBuffer.append(i);
            stringBuffer.append(": ");
            stringBuffer.append(this.f4Zo.get(i).aM());
        }
        return stringBuffer.toString();
    }

    public void m18j6(Lt lt) {
        int size = this.f4Zo.size();
        lt.writeShort(768);
        lt.writeShort(this.f5gn);
        lt.writeInt(this.f6u7);
        int i = this.f5gn;
        if (i == 1) {
            for (int i2 = 0; i2 < size; i2++) {
                lt.writeByte((byte) this.f4Zo.get(i2).Ws());
            }
        } else if (i == 2) {
            for (int i3 = 0; i3 < size; i3++) {
                lt.writeShort((short) this.f4Zo.get(i3).Ws());
            }
        } else if (i == 4) {
            for (int i4 = 0; i4 < size; i4++) {
                lt.writeInt(this.f4Zo.get(i4).Ws());
            }
        } else if (i == 8) {
            for (int i5 = 0; i5 < size; i5++) {
                lt.writeLong(this.f4Zo.get(i5).lg());
            }
        }
        if (this.f5gn != 1 || size % 2 == 0) {
            return;
        }
        lt.writeByte(0);
    }
}
