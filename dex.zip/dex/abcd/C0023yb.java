package abcd;

import abcd.Aa;

@xu
public class C0023yb<E extends Aa> {

    @uu
    private static boolean f63DW;

    @tu
    private static boolean f64j6;

    @ru(field = -2510487540499569500L)
    private int[] f65EQ;

    public final yb<E>.a f66FH;

    @ru(field = -279245768758236252L)
    private final Ba f67Hw;

    @ru(field = 5104161043012864224L)
    private int[] f68VH;

    @ru(field = 4077961008736936475L)
    private int[] f69Zo;

    @ru(field = -983839462391291625L)
    private int[] f70gn;

    @ru(field = 3304758390261823825L)
    private int[] f71tp;

    @ru(field = -1517517138304414608L)
    private int[] f72u7;

    @ru(field = -1639865249189478819L)
    private int[] f73v5;

    @ru(field = -3160406126651166828L)
    private int f74we;

    @xu
    public class a {

        @uu
        private static boolean f75DW;

        @tu
        private static boolean f76j6;

        @ru(field = -2421158694521612265L)
        private int f77FH;

        @vu
        final C0023yb f78Hw;

        static {
            wu.j6(a.class, 2976095549421543132L, 2976095549421543132L);
        }

        @su(method = -7520719832321529L)
        private a(C0023yb c0023yb) {
            try {
                if (f76j6) {
                    wu.j6(-650137682411319808L, (Object) null, c0023yb);
                }
                this.f78Hw = c0023yb;
                this.f77FH = 0;
            } catch (Throwable th) {
                if (f75DW) {
                    wu.j6(th, -650137682411319808L, (Object) null, c0023yb);
                }
                throw th;
            }
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        a(C0023yb c0023yb, xb xbVar) {
            this(c0023yb);
            try {
                if (f76j6) {
                    wu.j6(17646037302713061L, (Object) null, c0023yb, xbVar);
                }
            } catch (Throwable th) {
                if (f75DW) {
                    wu.j6(th, 17646037302713061L, (Object) null, c0023yb, xbVar);
                }
                throw th;
            }
        }
    }

    static {
        wu.j6(C0023yb.class, 2412108700048208304L, 2412108700048208304L);
    }

    public C0023yb(Ba ba) {
        xb xbVar = null;
        try {
            if (f64j6) {
                wu.j6(-191451201406700495L, (Object) null, ba);
            }
            this.f66FH = new a(this, xbVar);
            this.f73v5 = new int[3000];
            this.f69Zo = new int[3000];
            this.f68VH = new int[3000];
            this.f70gn = new int[1000];
            this.f72u7 = new int[1000];
            this.f71tp = new int[1000];
            this.f65EQ = new int[1000];
            this.f74we = 0;
            this.f67Hw = ba;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -191451201406700495L, (Object) null, ba);
            }
            throw th;
        }
    }

    @su(method = -895119657797265008L)
    private void m96Hw() {
        try {
            if (f64j6) {
                wu.j6(-1948981486404678093L, this);
            }
            int[] iArr = new int[(this.f73v5.length * 2) + 1];
            int[] iArr2 = new int[(this.f73v5.length * 2) + 1];
            int[] iArr3 = new int[(this.f73v5.length * 2) + 1];
            for (int i = 0; i < this.f74we; i++) {
                int i2 = this.f70gn[i];
                if (i2 != 0) {
                    int i3 = this.f72u7[i];
                    int i4 = this.f71tp[i];
                    int length = (Integer.MAX_VALUE & i2) % iArr.length;
                    while (iArr[length] != 0) {
                        length++;
                        if (length >= iArr.length) {
                            length = 0;
                        }
                    }
                    iArr[length] = i2;
                    iArr2[length] = i4;
                    iArr3[length] = i3;
                }
            }
            this.f73v5 = iArr;
            this.f68VH = iArr3;
            this.f69Zo = iArr2;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -1948981486404678093L, this);
            }
            throw th;
        }
    }

    @su(method = -881973718615840885L)
    private void m97v5() {
        try {
            if (f64j6) {
                wu.j6(-1942447477616393604L, this);
            }
            int[] iArr = new int[(this.f70gn.length * 2) + 1];
            System.arraycopy(this.f70gn, 0, iArr, 0, this.f70gn.length);
            this.f70gn = iArr;
            int[] iArr2 = new int[(this.f72u7.length * 2) + 1];
            System.arraycopy(this.f72u7, 0, iArr2, 0, this.f72u7.length);
            this.f72u7 = iArr2;
            int[] iArr3 = new int[(this.f71tp.length * 2) + 1];
            System.arraycopy(this.f71tp, 0, iArr3, 0, this.f71tp.length);
            this.f71tp = iArr3;
            int[] iArr4 = new int[(this.f65EQ.length * 2) + 1];
            System.arraycopy(this.f65EQ, 0, iArr4, 0, this.f65EQ.length);
            this.f65EQ = iArr4;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -1942447477616393604L, this);
            }
            throw th;
        }
    }

    public E m98DW(int i, int i2) {
        int i3;
        try {
            if (f64j6) {
                wu.j6(-3731759404714780748L, this, new Integer(i), new Integer(i2));
            }
            int[] iArr = this.f73v5;
            int length = iArr.length;
            int i4 = (Integer.MAX_VALUE & i) % length;
            int i5 = -1;
            do {
                i3 = iArr[i4];
                if (i3 == i && this.f68VH[i4] == i2) {
                    i5 = this.f69Zo[i4];
                }
                i4++;
                if (i4 >= length) {
                    i4 = 0;
                }
            } while (i3 != 0);
            return (E) this.f67Hw.FH(i5);
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -3731759404714780748L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m99DW() {
        try {
            if (f64j6) {
                wu.j6(-3222138507580938875L, this);
            }
            if (this.f70gn.length <= this.f74we) {
                m97v5();
            }
            this.f70gn[this.f74we] = 0;
            this.f74we++;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -3222138507580938875L, this);
            }
            throw th;
        }
    }

    public void m100FH() {
        int i;
        try {
            if (f64j6) {
                wu.j6(2272221747373726560L, this);
            }
            int[] iArr = this.f73v5;
            int length = iArr.length;
            this.f74we--;
            int i2 = this.f70gn[this.f74we];
            while (i2 != 0) {
                int i3 = (Integer.MAX_VALUE & i2) % length;
                int i4 = -1;
                do {
                    i = iArr[i3];
                    if (i == i2) {
                        i4 = i3;
                    }
                    i3++;
                    if (i3 >= length) {
                        i3 = 0;
                    }
                } while (i != 0);
                if (i4 != -1) {
                    iArr[i4] = 0;
                }
                this.f74we--;
                i2 = this.f70gn[this.f74we];
            }
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, 2272221747373726560L, this);
            }
            throw th;
        }
    }

    public void m101j6() {
        try {
            if (f64j6) {
                wu.j6(-236768840178953715L, this);
            }
            if (this.f74we > 0) {
                for (int i = 0; i < this.f73v5.length; i++) {
                    this.f73v5[i] = 0;
                }
            }
            this.f74we = 0;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -236768840178953715L, this);
            }
            throw th;
        }
    }

    public void m102j6(int i, E e, int i2) {
        try {
            if (f64j6) {
                wu.j6(-844519042696398525L, this, new Integer(i), e, new Integer(i2));
            }
            if (this.f73v5.length < this.f74we * 3) {
                m96Hw();
            }
            if (this.f70gn.length <= this.f74we) {
                m97v5();
            }
            this.f70gn[this.f74we] = i;
            this.f72u7[this.f74we] = i2;
            this.f71tp[this.f74we] = this.f67Hw.Hw(e);
            this.f74we++;
            int[] iArr = this.f73v5;
            int length = iArr.length;
            int i3 = (Integer.MAX_VALUE & i) % length;
            while (iArr[i3] != 0) {
                i3++;
                if (i3 >= length) {
                    i3 = 0;
                }
            }
            iArr[i3] = i;
            this.f69Zo[i3] = this.f67Hw.Hw(e);
            this.f68VH[i3] = i2;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -844519042696398525L, this, new Integer(i), e, new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m103j6(int i, int i2) {
        int i3;
        try {
            if (f64j6) {
                wu.j6(720261031918800395L, this, new Integer(i), new Integer(i2));
            }
            int[] iArr = this.f73v5;
            int length = iArr.length;
            int i4 = (Integer.MAX_VALUE & i) % length;
            do {
                i3 = iArr[i4];
                if (i3 == i && this.f68VH[i4] == i2) {
                    return true;
                }
                i4++;
                if (i4 >= length) {
                    i4 = 0;
                }
            } while (i3 != 0);
            return false;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, 720261031918800395L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }
}
