package abcd;

@xu
public class Be$a {

    @uu
    private static boolean f440DW;

    @tu
    private static boolean f441j6;

    public String f442FH;

    public String f443Hw;

    public String f444VH;

    public String f445Zo;

    public String f446gn;

    @vu
    final Be f447u7;

    public String f448v5;

    static {
        wu.j6(Be$a.class, 5106420208944380596L, 5106420208944380596L);
    }

    public Be$a(Be be) {
        try {
            if (f441j6) {
                wu.j6(-1617378437766414001L, (Object) null, be);
            }
            this.f447u7 = be;
        } catch (Throwable th) {
            if (f440DW) {
                wu.j6(th, -1617378437766414001L, (Object) null, be);
            }
            throw th;
        }
    }
}
