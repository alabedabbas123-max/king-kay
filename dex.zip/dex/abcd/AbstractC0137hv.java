package abcd;

import com.appfour.backbone.api.closures.OnExceptionClosure0;
import com.appfour.backbone.api.closures.OnExceptionClosure1;
import com.appfour.backbone.api.closures.OnExceptionClosure2;
import com.appfour.backbone.api.closures.OnExceptionClosure3;
import com.appfour.backbone.api.closures.OnExceptionClosure4;
import com.appfour.backbone.api.closures.OnExceptionClosure5;
import com.appfour.backbone.api.define.DefineHook;

public abstract class AbstractC0137hv extends yu {

    private Class<? extends Throwable> f735DW;

    private long f736FH;

    private long f737Hw;

    private boolean f738Zo;

    private long f739v5 = -1;

    public Class<? extends Throwable> m778FH() {
        return this.f735DW;
    }

    public long m779Hw() {
        return this.f736FH;
    }

    public boolean m780VH() {
        return this.f738Zo;
    }

    public long m781Zo() {
        return this.f739v5;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <C, E extends Throwable> DefineHook onExceptionIn(long j, long j2, Class<E> cls, long j3, OnExceptionClosure0<C, E> onExceptionClosure0) {
        this.f738Zo = true;
        this.f735DW = cls;
        this.f736FH = j3;
        this.f737Hw = j;
        this.f739v5 = j2;
        ((yu) this).j6 = onExceptionClosure0 == null ? null : new Xu(this, j, onExceptionClosure0);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <C, T0, E extends Throwable> DefineHook onExceptionIn(long j, long j2, Class<E> cls, long j3, OnExceptionClosure1<C, E, T0> onExceptionClosure1) {
        this.f738Zo = true;
        this.f735DW = cls;
        this.f736FH = j3;
        this.f737Hw = j;
        this.f739v5 = j2;
        ((yu) this).j6 = onExceptionClosure1 == null ? null : new Zu(this, j, onExceptionClosure1);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <C, T0, T1, E extends Throwable> DefineHook onExceptionIn(long j, long j2, Class<E> cls, long j3, OnExceptionClosure2<C, E, T0, T1> onExceptionClosure2) {
        this.f738Zo = true;
        this.f735DW = cls;
        this.f736FH = j3;
        this.f737Hw = j;
        this.f739v5 = j2;
        ((yu) this).j6 = onExceptionClosure2 == null ? null : new av(this, j, onExceptionClosure2);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <C, T0, T1, T2, E extends Throwable> DefineHook onExceptionIn(long j, long j2, Class<E> cls, long j3, OnExceptionClosure3<C, E, T0, T1, T2> onExceptionClosure3) {
        this.f738Zo = true;
        this.f735DW = cls;
        this.f736FH = j3;
        this.f737Hw = j;
        this.f739v5 = j2;
        ((yu) this).j6 = onExceptionClosure3 == null ? null : new cv(this, j, onExceptionClosure3);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <C, T0, T1, T2, T3, E extends Throwable> DefineHook onExceptionIn(long j, long j2, Class<E> cls, long j3, OnExceptionClosure4<C, E, T0, T1, T2, T3> onExceptionClosure4) {
        this.f738Zo = true;
        this.f735DW = cls;
        this.f736FH = j3;
        this.f737Hw = j;
        this.f739v5 = j2;
        ((yu) this).j6 = onExceptionClosure4 == null ? null : new C0005ev(this, j, onExceptionClosure4);
        return j6();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public <C, T0, T1, T2, T3, T4, E extends Throwable> DefineHook onExceptionIn(long j, long j2, Class<E> cls, long j3, OnExceptionClosure5<C, E, T0, T1, T2, T3, T4> onExceptionClosure5) {
        this.f738Zo = true;
        this.f735DW = cls;
        this.f736FH = j3;
        this.f737Hw = j;
        this.f739v5 = j2;
        ((yu) this).j6 = onExceptionClosure5 == null ? null : new C0093gv(this, j, onExceptionClosure5);
        return j6();
    }

    public <C, E extends Throwable> DefineHook onExceptionIn(Class<C> cls, String str, Class<E> cls2, OnExceptionClosure0<C, E> onExceptionClosure0) {
        return j6();
    }

    public <C, T0, E extends Throwable> DefineHook onExceptionIn(Class<C> cls, String str, Class<T0> cls2, Class<E> cls3, OnExceptionClosure1<C, E, T0> onExceptionClosure1) {
        return j6();
    }

    public <C, T0, T1, E extends Throwable> DefineHook onExceptionIn(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, Class<E> cls4, OnExceptionClosure2<C, E, T0, T1> onExceptionClosure2) {
        return j6();
    }

    public <C, T0, T1, T2, E extends Throwable> DefineHook onExceptionIn(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, Class<T2> cls4, Class<E> cls5, OnExceptionClosure3<C, E, T0, T1, T2> onExceptionClosure3) {
        return j6();
    }

    public <C, T0, T1, T2, T3, E extends Throwable> DefineHook onExceptionIn(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, Class<T2> cls4, Class<T3> cls5, Class<E> cls6, OnExceptionClosure4<C, E, T0, T1, T2, T3> onExceptionClosure4) {
        return j6();
    }

    public <C, T0, T1, T2, T3, T4, E extends Throwable> DefineHook onExceptionIn(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, Class<T2> cls4, Class<T3> cls5, Class<T4> cls6, Class<E> cls7, OnExceptionClosure5<C, E, T0, T1, T2, T3, T4> onExceptionClosure5) {
        return j6();
    }

    public long m782v5() {
        return this.f737Hw;
    }
}
