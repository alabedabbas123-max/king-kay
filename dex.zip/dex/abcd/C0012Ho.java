package abcd;

import java.util.BitSet;

public final class C0012Ho extends ao {

    public static final ao f96DW = new C0012Ho();

    private C0012Ho() {
    }

    public BitSet m162FH(Vn vn) {
        cs csVarGn = vn.gn();
        BitSet bitSet = new BitSet(3);
        bitSet.set(0, ao.Hw(csVarGn.get(0).we()));
        bitSet.set(1, ao.Hw(csVarGn.get(1).we()));
        bitSet.set(2, ao.Hw(csVarGn.get(2).we()));
        return bitSet;
    }

    public boolean m163VH(Vn vn) {
        cs csVarGn = vn.gn();
        return (vn instanceof mo) && csVarGn.size() == 3 && ao.Hw(csVarGn.get(0).we()) && ao.Hw(csVarGn.get(1).we()) && ao.Hw(csVarGn.get(2).we());
    }

    public String m164Zo(Vn vn) {
        cs csVarGn = vn.gn();
        return csVarGn.get(0).lg() + ", " + csVarGn.get(1).lg() + ", " + csVarGn.get(2).lg();
    }

    public int m165j6() {
        return 2;
    }

    public String m166j6(Vn vn, boolean z) {
        return "";
    }

    public void m167j6(Lt lt, Vn vn) {
        cs csVarGn = vn.gn();
        ao.j6(lt, ao.j6(vn, csVarGn.get(0).we()), ao.j6(csVarGn.get(1).we(), csVarGn.get(2).we()));
    }
}
