package abcd;

public abstract class AbstractC0010cJ {

    private static AbstractC0010cJ f33j6 = new mI();

    public static AbstractC0010cJ m55j6() {
        return f33j6;
    }

    public static void m56j6(AbstractC0010cJ abstractC0010cJ) {
        if (abstractC0010cJ != null) {
            f33j6 = abstractC0010cJ;
        } else {
            f33j6 = new mI();
        }
    }

    public abstract ZI m57j6(HJ hj, kI kIVar, pK pKVar, int i);

    public void m58j6(ZI zi) {
        zi.disconnect();
    }
}
