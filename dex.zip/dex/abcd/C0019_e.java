package abcd;

import com.aide.common.ma;
import com.aide.ui.U;
import com.s1243808733.aide.FileTabListener;

@xu
public class C0019_e implements InterfaceC0026_l {

    @uu
    private static boolean f146DW;

    @tu
    private static boolean f147j6;

    static {
        wu.j6(C0019_e.class, 86708045681377899L, 86708045681377899L);
    }

    public C0019_e() {
        try {
            if (f147j6) {
                wu.j6(1376884223088937673L, (Object) null);
            }
        } catch (Throwable th) {
            if (f146DW) {
                wu.j6(th, 1376884223088937673L, (Object) null);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f147j6) {
                wu.j6(-610495631830798875L, this);
            }
            return U.er().tp();
        } catch (Throwable th) {
            if (f146DW) {
                wu.j6(th, -610495631830798875L, this);
            }
            throw th;
        }
    }

    public int m177j6() {
        try {
            if (!f147j6) {
                return com.aide.pro.R.id.editorMenuClose;
            }
            wu.j6(2377579153998010299L, this);
            return com.aide.pro.R.id.editorMenuClose;
        } catch (Throwable th) {
            if (f146DW) {
                wu.j6(th, 2377579153998010299L, this);
            }
            throw th;
        }
    }

    @Override
    public boolean mo178j6(boolean z) {
        try {
            if (f147j6) {
                wu.j6(349285953593365035L, this, z);
            }
            return (z || !isEnabled() || U.dx()) ? false : true;
        } catch (Throwable th) {
            if (f146DW) {
                wu.j6(th, 349285953593365035L, this, new Boolean(z));
            }
            throw th;
        }
    }

    public boolean m179run() {
        return FileTabListener.editorMenuClose(this);
    }

    public boolean run_() {
        try {
            if (f147j6) {
                wu.j6(723512440035809655L, this);
            }
            String strDW = U.er().DW();
            if (U.er().DW(strDW).J0()) {
                ma.j6(U.lg(), com.aide.pro.R.string.dialog_close_file_title, com.aide.pro.R.string.dialog_close_file_message, new Ze(this, strDW), (Runnable) null);
                return true;
            }
            U.er().j6(strDW);
            return true;
        } catch (Throwable th) {
            if (f146DW) {
                wu.j6(th, 723512440035809655L, this);
            }
            throw th;
        }
    }
}
