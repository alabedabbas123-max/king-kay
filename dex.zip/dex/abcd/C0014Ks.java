package abcd;

import java.util.HashMap;

public final class C0014Ks extends AbstractC0099Ms {

    private final Qs f83Mr;

    private Js f84U2;

    private static final HashMap<Qs, C0014Ks> f78j6 = new HashMap<>(100);

    public static final C0014Ks f64DW = m105DW(Qs.QX);

    public static final C0014Ks f66FH = m105DW(Qs.Mr);

    public static final C0014Ks f67Hw = m105DW(Qs.U2);

    public static final C0014Ks f81v5 = m105DW(Qs.a8);

    public static final C0014Ks f74Zo = m105DW(Qs.lg);

    public static final C0014Ks f71VH = m105DW(Qs.rN);

    public static final C0014Ks f76gn = m105DW(Qs.yS);

    public static final C0014Ks f80u7 = m105DW(Qs.er);

    public static final C0014Ks f79tp = m105DW(Qs.gW);

    public static final C0014Ks f65EQ = m105DW(Qs.BT);

    public static final C0014Ks f82we = m105DW(Qs.vy);

    public static final C0014Ks f68J0 = m105DW(Qs.P8);

    public static final C0014Ks f69J8 = m105DW(Qs.ei);

    public static final C0014Ks f72Ws = m105DW(Qs.nw);

    public static final C0014Ks f70QX = m105DW(Qs.SI);

    public static final C0014Ks f73XL = m105DW(Qs.ro);

    public static final C0014Ks f75aM = m105DW(Qs.KD);

    public static final C0014Ks f77j3 = m105DW(Qs.sh);

    public C0014Ks(Qs qs) {
        if (qs == null) {
            throw new NullPointerException("type == null");
        }
        if (qs == Qs.EQ) {
            throw new UnsupportedOperationException("KNOWN_NULL is not representable");
        }
        this.f83Mr = qs;
        this.f84U2 = null;
    }

    public static C0014Ks m105DW(Qs qs) {
        C0014Ks c0014Ks;
        synchronized (f78j6) {
            c0014Ks = f78j6.get(qs);
            if (c0014Ks == null) {
                c0014Ks = new C0014Ks(qs);
                f78j6.put(qs, c0014Ks);
            }
        }
        return c0014Ks;
    }

    public static C0014Ks m106j6(Qs qs) {
        switch (qs.j3()) {
            case 0:
                return f65EQ;
            case 1:
                return f66FH;
            case 2:
                return f67Hw;
            case 3:
                return f81v5;
            case 4:
                return f74Zo;
            case 5:
                return f71VH;
            case 6:
                return f80u7;
            case 7:
                return f76gn;
            case 8:
                return f79tp;
            default:
                throw new IllegalArgumentException("not primitive: " + qs);
        }
    }

    protected int m107DW(ms msVar) {
        return this.f83Mr.J8().compareTo(((C0014Ks) msVar).f83Mr.J8());
    }

    public boolean m108Hw() {
        return false;
    }

    public Qs m109VH() {
        return this.f83Mr;
    }

    public String m110Zo() {
        return "type";
    }

    public String m111aM() {
        return this.f83Mr.aM();
    }

    public boolean equals(Object obj) {
        return (obj instanceof C0014Ks) && this.f83Mr == ((C0014Ks) obj).f83Mr;
    }

    public Qs getType() {
        return Qs.J8;
    }

    public int hashCode() {
        return this.f83Mr.hashCode();
    }

    public String toString() {
        return "type{" + m111aM() + '}';
    }

    public Js m112we() {
        if (this.f84U2 == null) {
            this.f84U2 = new Js(this.f83Mr.J8());
        }
        return this.f84U2;
    }
}
