package abcd;

import java.util.ArrayList;

public abstract class AbstractC0055Fm implements Tm {

    private Rs[] f320DW;

    private boolean f321EQ;

    private int f322FH;

    private Qs f323Hw;

    private Rs[] f324J0;

    private int f325J8;

    private int f326VH;

    private ms f327Zo;

    private cn f328gn;

    private final Os f329j6;

    private int f330tp;

    private ArrayList<ms> f331u7;

    private int f332v5;

    private bs f333we;

    public AbstractC0055Fm(Os os) {
        if (os == null) {
            throw new NullPointerException("prototype == null");
        }
        this.f329j6 = os;
        this.f320DW = new Rs[10];
        this.f324J0 = new Rs[6];
        m599j6();
    }

    public static void m585j6(Rs rs, Rs rs2) throws an {
        throw new an("local variable type mismatch: attempt to set or access a value of type " + rs.aM() + " using a local variable of type " + rs2.aM() + ". This is symptomatic of .class transformation tools that ignore local variable information.");
    }

    public Os m586DW() {
        return this.f329j6;
    }

    protected final bs m587DW(boolean z) throws an {
        if (this.f333we == null) {
            return null;
        }
        if (this.f325J8 != 1) {
            StringBuilder sb = new StringBuilder();
            sb.append("local target with ");
            sb.append(this.f325J8 == 0 ? "no" : "multiple");
            sb.append(" results");
            throw new an(sb.toString());
        }
        Rs rs = this.f324J0[0];
        Qs type = rs.getType();
        Qs type2 = this.f333we.getType();
        if (type == type2) {
            return z ? this.f333we.j6(rs) : this.f333we;
        }
        if (!Um.j6(type2, type)) {
            m585j6((Rs) type, (Rs) type2);
            throw null;
        }
        if (type2 == Qs.QX) {
            this.f333we = this.f333we.j6(rs);
        }
        return this.f333we;
    }

    public final void m588DW(int i) {
        this.f332v5 = i;
    }

    public final void m589DW(Om om, int i) {
        m599j6();
        this.f320DW[0] = om.DW().get(i);
        this.f322FH = 1;
        this.f330tp = i;
    }

    protected final void m590DW(Rs rs) {
        if (rs == null) {
            throw new NullPointerException("result == null");
        }
        this.f324J0[0] = rs;
        this.f325J8 = 1;
    }

    protected final int m591EQ() {
        return this.f330tp;
    }

    protected final int m592FH() {
        return this.f322FH;
    }

    protected final Rs m593FH(int i) {
        if (i >= this.f322FH) {
            throw new IllegalArgumentException("n >= argCount");
        }
        try {
            return this.f320DW[i];
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new IllegalArgumentException("n < 0");
        }
    }

    protected final Rs m594Hw(int i) {
        if (i >= this.f325J8) {
            throw new IllegalArgumentException("n >= resultCount");
        }
        try {
            return this.f324J0[i];
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new IllegalArgumentException("n < 0");
        }
    }

    protected final void m595Hw() {
        this.f325J8 = 0;
    }

    protected final int m596VH() {
        return this.f332v5;
    }

    protected final ms m597Zo() {
        return this.f327Zo;
    }

    protected final int m598gn() {
        return this.f326VH;
    }

    public final void m599j6() {
        this.f322FH = 0;
        this.f323Hw = null;
        this.f332v5 = 0;
        this.f327Zo = null;
        this.f326VH = 0;
        this.f328gn = null;
        this.f331u7 = null;
        this.f330tp = -1;
        this.f321EQ = false;
        this.f333we = null;
        this.f325J8 = -1;
    }

    public final void m600j6(int i) {
        this.f326VH = i;
    }

    public final void m601j6(int i, Qs qs, Vr vr) {
        this.f333we = bs.FH(i, qs, vr);
    }

    protected final void m602j6(Om om) throws an {
        int i = this.f325J8;
        if (i < 0) {
            throw new an("results never set");
        }
        if (i == 0) {
            return;
        }
        if (this.f333we != null) {
            om.DW().j6(m587DW(false));
            return;
        }
        Nm nmFH = om.FH();
        for (int i2 = 0; i2 < this.f325J8; i2++) {
            if (this.f321EQ) {
                nmFH.yS();
            }
            nmFH.j6(this.f324J0[i2]);
        }
    }

    public final void m603j6(Om om, int i) {
        Nm nmFH = om.FH();
        m599j6();
        if (i > this.f320DW.length) {
            this.f320DW = new Rs[i + 10];
        }
        for (int i2 = i - 1; i2 >= 0; i2--) {
            this.f320DW[i2] = nmFH.er();
        }
        this.f322FH = i;
    }

    public void m604j6(Om om, Os os) throws an {
        Ps psVH = os.VH();
        int size = psVH.size();
        m603j6(om, size);
        for (int i = 0; i < size; i++) {
            if (!Um.j6(psVH.getType(i), this.f320DW[i])) {
                throw new an("at stack depth " + ((size - 1) - i) + ", expected type " + psVH.getType(i).aM() + " but found " + this.f320DW[i].getType().aM());
            }
        }
    }

    public final void m605j6(Om om, Qs qs) throws an {
        m603j6(om, 1);
        if (Um.j6(qs, this.f320DW[0])) {
            return;
        }
        throw new an("expected type " + qs.aM() + " but found " + this.f320DW[0].getType().aM());
    }

    public final void m606j6(Om om, Qs qs, Qs qs2) throws an {
        m603j6(om, 2);
        if (!Um.j6(qs, this.f320DW[0])) {
            throw new an("expected type " + qs.aM() + " but found " + this.f320DW[0].getType().aM());
        }
        if (Um.j6(qs2, this.f320DW[1])) {
            return;
        }
        throw new an("expected type " + qs2.aM() + " but found " + this.f320DW[1].getType().aM());
    }

    public final void m607j6(Om om, Qs qs, Qs qs2, Qs qs3) throws an {
        m603j6(om, 3);
        if (!Um.j6(qs, this.f320DW[0])) {
            throw new an("expected type " + qs.aM() + " but found " + this.f320DW[0].getType().aM());
        }
        if (!Um.j6(qs2, this.f320DW[1])) {
            throw new an("expected type " + qs2.aM() + " but found " + this.f320DW[1].getType().aM());
        }
        if (Um.j6(qs3, this.f320DW[2])) {
            return;
        }
        throw new an("expected type " + qs3.aM() + " but found " + this.f320DW[2].getType().aM());
    }

    public final void m608j6(Qs qs) {
        this.f323Hw = qs;
    }

    protected final void m609j6(Rs rs) {
        if (rs == null) {
            throw new NullPointerException("result == null");
        }
        Rs[] rsArr = this.f324J0;
        int i = this.f325J8;
        rsArr[i] = rs;
        this.f325J8 = i + 1;
    }

    public final void m610j6(cn cnVar) {
        if (cnVar == null) {
            throw new NullPointerException("cases == null");
        }
        this.f328gn = cnVar;
    }

    public final void m611j6(ms msVar) {
        if (msVar == null) {
            throw new NullPointerException("cst == null");
        }
        this.f327Zo = msVar;
    }

    public final void m612j6(ArrayList<ms> arrayList) {
        this.f331u7 = arrayList;
    }

    public final void m613j6(boolean z) {
        this.f321EQ = z;
    }

    protected final ArrayList<ms> m614tp() {
        return this.f331u7;
    }

    protected final Qs m615u7() {
        return this.f323Hw;
    }

    protected final cn m616v5() {
        return this.f328gn;
    }

    protected final int m617we() throws an {
        int i = this.f325J8;
        if (i >= 0) {
            return i;
        }
        throw new an("results never set");
    }
}
