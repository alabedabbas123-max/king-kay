package abcd;

import abcd.AbstractC0025CC;

public abstract class AbstractC0068DC<S extends AbstractC0025CC> {
    public abstract int m386j6(S s, int i);

    public jC m387j6(S s, S s2, jC jCVar) {
        int i;
        while (true) {
            int i2 = jCVar.j6;
            if (i2 >= jCVar.DW || (i = jCVar.FH) >= jCVar.Hw || !m388j6(s, i2, s2, i)) {
                break;
            }
            jCVar.j6++;
            jCVar.FH++;
        }
        while (true) {
            int i3 = jCVar.j6;
            int i4 = jCVar.DW;
            if (i3 >= i4) {
                break;
            }
            int i5 = jCVar.FH;
            int i6 = jCVar.Hw;
            if (i5 >= i6 || !m388j6(s, i4 - 1, s2, i6 - 1)) {
                break;
            }
            jCVar.DW--;
            jCVar.Hw--;
        }
        return jCVar;
    }

    public abstract boolean m388j6(S s, int i, S s2, int i2);
}
