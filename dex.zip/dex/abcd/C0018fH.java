package abcd;

import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.Set;
import org.eclipse.jgit.JGitText;

class C0018fH extends bH {

    private static final int[] f100DW = new int[0];

    private static final byte[] f101FH = new byte[0];

    private long f102Hw;

    private byte[][] f103VH;

    private int[][] f104Zo;

    private byte[][] f105gn;

    private byte[] f106u7;

    private final long[] f107v5;

    private class a extends bH.a {

        private int f108Hw;

        private int f110v5;

        private a() {
            super(C0018fH.this);
        }

        a(C0018fH c0018fH, a aVar) {
            this();
        }

        protected bH.b m67j6() {
            return new eH(this);
        }

        public bH.b next() {
            while (this.f108Hw < C0018fH.this.f104Zo.length) {
                int i = this.f110v5;
                int[][] iArr = C0018fH.this.f104Zo;
                int i2 = this.f108Hw;
                if (i < iArr[i2].length) {
                    long jFH = FK.FH(C0018fH.this.f103VH[this.f108Hw], (this.f110v5 / 5) * 4);
                    if ((2147483648L & jFH) != 0) {
                        jFH = FK.Hw(C0018fH.this.f106u7, ((int) (jFH & (-2147483649L))) * 8);
                    }
                    bH.b bVar = ((bH.a) this).j6;
                    bVar.DW = jFH;
                    this.f110v5 += 5;
                    ((bH.a) this).DW++;
                    return bVar;
                }
                this.f110v5 = 0;
                this.f108Hw = i2 + 1;
            }
            throw new NoSuchElementException();
        }
    }

    C0018fH(InputStream inputStream) throws IOException {
        long j;
        byte[] bArr = new byte[1024];
        BK.j6(inputStream, bArr, 0, bArr.length);
        this.f107v5 = new long[256];
        for (int i = 0; i < 256; i++) {
            this.f107v5[i] = FK.FH(bArr, i * 4);
        }
        this.f102Hw = this.f107v5[255];
        this.f104Zo = new int[256][];
        this.f103VH = new byte[256][];
        this.f105gn = new byte[256][];
        for (int i2 = 0; i2 < 256; i2++) {
            if (i2 == 0) {
                j = this.f107v5[i2];
            } else {
                long[] jArr = this.f107v5;
                j = jArr[i2] - jArr[i2 - 1];
            }
            if (j == 0) {
                this.f104Zo[i2] = f100DW;
                byte[][] bArr2 = this.f103VH;
                byte[] bArr3 = f101FH;
                bArr2[i2] = bArr3;
                this.f105gn[i2] = bArr3;
            } else {
                long j2 = 20 * j;
                if (j2 > 2147483647L) {
                    throw new IOException(JGitText.j6().indexFileIsTooLargeForJgit);
                }
                int i3 = (int) j2;
                byte[] bArr4 = new byte[i3];
                int[] iArr = new int[i3 >>> 2];
                BK.j6(inputStream, bArr4, 0, bArr4.length);
                for (int i4 = 0; i4 < iArr.length; i4++) {
                    iArr[i4] = FK.j6(bArr4, i4 << 2);
                }
                this.f104Zo[i2] = iArr;
                int i5 = (int) (j * 4);
                this.f103VH[i2] = new byte[i5];
                this.f105gn[i2] = new byte[i5];
            }
        }
        for (int i6 = 0; i6 < 256; i6++) {
            byte[][] bArr5 = this.f105gn;
            BK.j6(inputStream, bArr5[i6], 0, bArr5[i6].length);
        }
        int i7 = 0;
        int i8 = 0;
        while (i8 < 256) {
            byte[] bArr6 = this.f103VH[i8];
            BK.j6(inputStream, bArr6, 0, bArr6.length);
            int i9 = i7;
            for (int i10 = 0; i10 < bArr6.length; i10 += 4) {
                if (bArr6[i10] < 0) {
                    i9++;
                }
            }
            i8++;
            i7 = i9;
        }
        if (i7 > 0) {
            this.f106u7 = new byte[i7 * 8];
            byte[] bArr7 = this.f106u7;
            BK.j6(inputStream, bArr7, 0, bArr7.length);
        } else {
            this.f106u7 = f101FH;
        }
        ((bH) this).j6 = new byte[20];
        byte[] bArr8 = ((bH) this).j6;
        BK.j6(inputStream, bArr8, 0, bArr8.length);
    }

    private static int m57Zo(int i) {
        return (i << 2) + i;
    }

    private int m58j6(YD yd, int i) {
        int[] iArr = this.f104Zo[i];
        int length = this.f103VH[i].length >>> 2;
        if (length == 0) {
            return -1;
        }
        int i2 = 0;
        do {
            int i3 = (i2 + length) >>> 1;
            int iJ6 = yd.j6(iArr, (i3 << 2) + i3);
            if (iJ6 < 0) {
                length = i3;
            } else {
                if (iJ6 == 0) {
                    return i3;
                }
                i2 = i3 + 1;
            }
        } while (i2 < length);
        return -1;
    }

    public long m60DW() {
        return this.f106u7.length / 8;
    }

    public long m61DW(YD yd) {
        int iZo = yd.Zo();
        int iM58j6 = m58j6(yd, iZo);
        if (iM58j6 == -1) {
            return -1L;
        }
        long jFH = FK.FH(this.f103VH[iZo], iM58j6 << 2);
        return (2147483648L & jFH) != 0 ? FK.Hw(this.f106u7, ((int) (jFH & (-2147483649L))) * 8) : jFH;
    }

    public boolean m62FH() {
        return true;
    }

    public Iterator<bH.b> iterator() {
        return new a(this, null);
    }

    public long m63j6() {
        return this.f102Hw;
    }

    public long m64j6(YD yd) throws C0014fD {
        int iZo = yd.Zo();
        int iM58j6 = m58j6(yd, iZo);
        if (iM58j6 != -1) {
            return FK.FH(this.f105gn[iZo], iM58j6 << 2);
        }
        throw new C0014fD(yd.Hw(), "unknown");
    }

    public yE m65j6(long j) {
        int iBinarySearch = Arrays.binarySearch(this.f107v5, 1 + j);
        if (iBinarySearch >= 0) {
            long j2 = this.f107v5[iBinarySearch];
            while (iBinarySearch > 0 && j2 == this.f107v5[iBinarySearch - 1]) {
                iBinarySearch--;
            }
        } else {
            iBinarySearch = -(iBinarySearch + 1);
        }
        int i = (int) (j - (iBinarySearch > 0 ? this.f107v5[iBinarySearch - 1] : 0L));
        return yE.DW(this.f104Zo[iBinarySearch], (i << 2) + i);
    }

    public void m66j6(Set<yE> set, WD wd, int i) {
        int[] iArr = this.f104Zo[wd.j6()];
        int length = this.f103VH[wd.j6()].length >>> 2;
        if (length == 0) {
            return;
        }
        int i2 = 0;
        int i3 = length;
        do {
            int i4 = (i2 + i3) >>> 1;
            int iJ6 = wd.j6(iArr, m57Zo(i4));
            if (iJ6 < 0) {
                i3 = i4;
            } else {
                if (iJ6 == 0) {
                    while (i4 > 0 && wd.j6(iArr, m57Zo(i4 - 1)) == 0) {
                        i4--;
                    }
                    while (i4 < length && wd.j6(iArr, m57Zo(i4)) == 0) {
                        set.add(yE.DW(iArr, m57Zo(i4)));
                        if (set.size() > i) {
                            return;
                        } else {
                            i4++;
                        }
                    }
                    return;
                }
                i2 = i4 + 1;
            }
        } while (i2 < i3);
    }
}
