package abcd;

@xu
class C0020cc {
    static {
        wu.j6(C0020cc.class, 4379644660961656000L, 1837284117958018821L);
    }
}
