package abcd;

import java.io.StringWriter;
import java.util.Collection;
import java.util.Iterator;

public abstract class AbstractC0061SE {

    private final Collection<ME> f261j6;

    public AbstractC0061SE(KK<ME> kk) {
        this.f261j6 = kk.j6();
    }

    public AbstractC0061SE(Collection<ME> collection) {
        this.f261j6 = NE.j6(collection);
    }

    public void m304DW() {
        boolean z;
        Iterator<ME> it = this.f261j6.iterator();
        while (true) {
            if (!it.hasNext()) {
                z = false;
                break;
            }
            ME next = it.next();
            if (next.j6().Zo() && next.Hw()) {
                z = true;
                break;
            }
        }
        StringWriter stringWriter = new StringWriter();
        if (z) {
            stringWriter.write("# pack-refs with:");
            if (z) {
                stringWriter.write(" peeled");
            }
            stringWriter.write(10);
        }
        char[] cArr = new char[40];
        for (ME me : this.f261j6) {
            if (me.j6() == ME.a.FH) {
                me.DW().j6(cArr, stringWriter);
                stringWriter.write(32);
                stringWriter.write(me.getName());
                stringWriter.write(10);
                if (me.FH() != null) {
                    stringWriter.write(94);
                    me.FH().j6(cArr, stringWriter);
                    stringWriter.write(10);
                }
            }
        }
        m306j6("packed-refs", hE.j6(stringWriter.toString()));
    }

    public void m305j6() {
        StringWriter stringWriter = new StringWriter();
        char[] cArr = new char[40];
        for (ME me : this.f261j6) {
            if (!"HEAD".equals(me.getName())) {
                me.DW().j6(cArr, stringWriter);
                stringWriter.write(9);
                stringWriter.write(me.getName());
                stringWriter.write(10);
                if (me.FH() != null) {
                    me.FH().j6(cArr, stringWriter);
                    stringWriter.write(9);
                    stringWriter.write(me.getName());
                    stringWriter.write("^{}\n");
                }
            }
        }
        m306j6("info/refs", hE.j6(stringWriter.toString()));
    }

    protected abstract void m306j6(String str, byte[] bArr);
}
