package abcd;

import java.io.IOException;
import java.io.InputStream;

class C0010_L extends InputStream {

    private boolean f74DW = true;

    private InputStream f75FH;

    private final JL f76j6;

    C0010_L(JL jl) {
        this.f76j6 = jl;
    }

    @Override
    public int read() throws IOException {
        BL blJ6;
        if (this.f75FH == null) {
            if (!this.f74DW || (blJ6 = this.f76j6.j6()) == null) {
                return -1;
            }
            this.f74DW = false;
            this.f75FH = blJ6.FH();
        }
        while (true) {
            int i = this.f75FH.read();
            if (i >= 0) {
                return i;
            }
            BL blJ7 = this.f76j6.j6();
            if (blJ7 == null) {
                this.f75FH = null;
                return -1;
            }
            this.f75FH = blJ7.FH();
        }
    }

    @Override
    public int read(byte[] bArr, int i, int i2) throws IOException {
        BL blJ6;
        int i3 = 0;
        if (this.f75FH == null) {
            if (!this.f74DW || (blJ6 = this.f76j6.j6()) == null) {
                return -1;
            }
            this.f74DW = false;
            this.f75FH = blJ6.FH();
        }
        while (true) {
            int i4 = this.f75FH.read(bArr, i + i3, i2 - i3);
            if (i4 >= 0) {
                i3 += i4;
                if (i3 == i2) {
                    return i3;
                }
            } else {
                BL blJ7 = this.f76j6.j6();
                if (blJ7 == null) {
                    this.f75FH = null;
                    if (i3 < 1) {
                        return -1;
                    }
                    return i3;
                }
                this.f75FH = blJ7.FH();
            }
        }
    }
}
