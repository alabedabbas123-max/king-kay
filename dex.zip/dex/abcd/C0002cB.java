package abcd;

import java.io.File;

public class C0002cB {

    private final UE f4j6;

    public C0002cB(UE ue) {
        if (ue == null) {
            throw new NullPointerException();
        }
        this.f4j6 = ue;
    }

    public static XA m13VH() {
        return new XA();
    }

    public static C0002cB m14j6(UE ue) {
        return new C0002cB(ue);
    }

    public static C0002cB m15j6(File file) {
        return m16j6(file, pK.j6);
    }

    public static C0002cB m16j6(File file, pK pKVar) {
        WE.a aVarFH = WE.a.FH(file, pKVar);
        VE ve = new VE();
        ve.j6(pKVar);
        VE ve2 = ve;
        ve2.FH(aVarFH.j6());
        VE ve3 = ve2;
        ve3.j6(true);
        return m14j6(ve3.j6());
    }

    public static CallableC0090eB m17tp() {
        return new CallableC0090eB();
    }

    public _A m18DW() {
        return new _A(this.f4j6);
    }

    public hB m19EQ() {
        return new hB(this.f4j6);
    }

    public aB m20FH() {
        return new aB(this.f4j6);
    }

    public gB m21Hw() {
        return new gB(this.f4j6);
    }

    public qB m22J0() {
        return new qB(this.f4j6);
    }

    public sB m23J8() {
        return new sB(this.f4j6);
    }

    public EB m24QX() {
        return new EB(this.f4j6);
    }

    public CB m25Ws() {
        return new CB(this.f4j6);
    }

    public SA m26Zo() {
        return new SA(this.f4j6);
    }

    public ZA m27gn() {
        return new ZA(this.f4j6);
    }

    public OA m28j6() {
        return new OA(this.f4j6);
    }

    public UE m29u7() {
        return this.f4j6;
    }

    public QA m30v5() {
        return new QA(this.f4j6);
    }

    public iB m31we() {
        return new iB(this.f4j6);
    }
}
