package abcd;

import com.aide.engine.FindResult;
import com.aide.ui.U;
import java.util.ArrayList;
import java.util.List;

@InterfaceC0137xu
public class C0000ul {

    @InterfaceC0009uu
    private static boolean f0DW;

    @tu
    private static boolean f1j6;

    @ru(field = 727527645743019660L)
    private int f2EQ;

    @ru(field = -1074014339816821968L)
    private List<FindResult> f3FH;

    @ru(field = -3929665307059597609L)
    private boolean f4Hw;

    @ru(field = -3413761660257400071L)
    private a f5J0;

    @ru(field = -1351764914835114384L)
    private boolean f6VH;

    @ru(field = -2699332450921890160L)
    private boolean f7Zo;

    @ru(field = 947675270592004360L)
    private String f8gn;

    @ru(field = 4249362788529679787L)
    private int f9tp;

    @ru(field = -1686215764559727121L)
    private int f10u7;

    @ru(field = 2983126752894608768L)
    private boolean f11v5;

    @ru(field = 3668638987906411680L)
    private int f12we;

    static {
        C0094wu.m394j6((Class<?>) C0000ul.class, -401236586759554245L, -401236586759554245L);
    }

    public C0000ul() {
        try {
            if (f1j6) {
                C0094wu.m382j6(943162524528792723L, (Object) null);
            }
            this.f3FH = new ArrayList();
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m400j6(th, 943162524528792723L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -665385804484466045L)
    public void m3Hw() {
        try {
            if (f1j6) {
                C0094wu.m382j6(602290304690186899L, this);
            }
            U.j6(new tl(this));
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m400j6(th, 602290304690186899L, this);
            }
            throw th;
        }
    }

    @su(method = 3712063703949270008L)
    private void m10j6(String str, int i, int i2, int i3, int i4, String str2, boolean z, boolean z2, boolean z3) {
        if (f1j6) {
            C0094wu.m390j6(1358185863777172344L, (Object) this, new Object[]{str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4), str2, new Boolean(z), new Boolean(z2), new Boolean(z3)});
        }
        this.f11v5 = z2;
        this.f7Zo = z;
        this.f6VH = z3;
        this.f10u7 = i;
        this.f9tp = i2;
        this.f2EQ = i3;
        this.f12we = i4;
        if (str2 == null || str2.length() < 3) {
            str2 = null;
        }
        this.f8gn = str2;
        U.lg().cb();
        U.EQ().v5(str, i, i2);
    }

    @su(method = 3893593419164041488L)
    public void m14v5() {
        try {
            if (f1j6) {
                C0094wu.m382j6(-2023513627252101024L, this);
            }
            this.f4Hw = true;
            m3Hw();
            U.lg().dx();
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m400j6(th, -2023513627252101024L, this);
            }
            throw th;
        }
    }

    public void m16DW() {
        try {
            if (f1j6) {
                C0094wu.m382j6(-2526652222906125328L, this);
            }
            U.EQ().j6(new pl(this));
            U.EQ().j6(new sl(this));
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m400j6(th, -2526652222906125328L, this);
            }
            throw th;
        }
    }

    public void m17DW(String str, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                C0094wu.m388j6(2215858010610177441L, this, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            m10j6(str, i, i2, i3, i4, null, true, false, false);
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m405j6(th, 2215858010610177441L, this, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m18FH(String str, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                C0094wu.m388j6(4268466649707687900L, this, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            m10j6(str, i, i2, i3, i4, null, false, true, true);
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m405j6(th, 4268466649707687900L, this, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public boolean m19FH() {
        try {
            if (f1j6) {
                C0094wu.m382j6(-2757678240363661664L, this);
            }
            return this.f4Hw;
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m400j6(th, -2757678240363661664L, this);
            }
            throw th;
        }
    }

    public List<FindResult> m20j6() {
        try {
            if (f1j6) {
                C0094wu.m382j6(1631899450615509L, this);
            }
            return this.f3FH;
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m400j6(th, 1631899450615509L, this);
            }
            throw th;
        }
    }

    public void m21j6(a aVar) {
        try {
            if (f1j6) {
                C0094wu.m384j6(-1037406692596609511L, this, aVar);
            }
            this.f5J0 = aVar;
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m401j6(th, -1037406692596609511L, this, aVar);
            }
            throw th;
        }
    }

    public void m22j6(String str) {
        try {
            if (f1j6) {
                C0094wu.m384j6(-4706379728078244075L, this, str);
            }
            m14v5();
            U.EQ().DW(str);
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m401j6(th, -4706379728078244075L, this, str);
            }
            throw th;
        }
    }

    public void m23j6(String str, int i, int i2, int i3, int i4) {
        try {
            if (f1j6) {
                C0094wu.m388j6(5506611013244720784L, this, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            m10j6(str, i, i2, i3, i4, null, true, false, true);
        } catch (Throwable th) {
            if (f0DW) {
                C0094wu.m405j6(th, 5506611013244720784L, this, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m24j6(String str, int i, int i2, int i3, int i4, String str2) {
        if (f1j6) {
            C0094wu.m390j6(-2618739448797595976L, (Object) this, new Object[]{str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4), str2});
        }
        m10j6(str, i, i2, i3, i4, str2, false, false, true);
    }
}
