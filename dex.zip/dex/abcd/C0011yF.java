package abcd;

public class C0011yF extends vF {

    private final int f16VH;

    private final String f17Zo;

    static class a extends wF {

        private final int f18gn;

        protected a(UE ue, int i) {
            super(ue);
            this.f18gn = i;
        }

        public C0010yE m38FH() {
            return ((wF) this).VH[this.f18gn];
        }

        protected boolean m39Hw() {
            return this.f18gn < ((wF) this).VH.length;
        }
    }

    protected C0011yF(String str, int i) {
        this.f17Zo = str;
        this.f16VH = i;
    }

    public wF m36j6(UE ue) {
        return new a(ue, this.f16VH);
    }

    public String m37j6() {
        return this.f17Zo;
    }
}
