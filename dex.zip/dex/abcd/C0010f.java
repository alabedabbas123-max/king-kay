package abcd;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

class C0010f extends Drawable implements Drawable.Callback, e, i {

    static final PorterDuff.Mode f67j6 = PorterDuff.Mode.SRC_IN;

    private int f68DW;

    private PorterDuff.Mode f69FH;

    private boolean f70Hw;

    Drawable f71VH;

    private boolean f72Zo;

    a f73v5;

    protected static abstract class a extends Drawable.ConstantState {

        Drawable.ConstantState f74DW;

        ColorStateList f75FH;

        PorterDuff.Mode f76Hw;

        int f77j6;

        a(a aVar, Resources resources) {
            this.f75FH = null;
            this.f76Hw = C0010f.f67j6;
            if (aVar != null) {
                this.f77j6 = aVar.f77j6;
                this.f74DW = aVar.f74DW;
                this.f75FH = aVar.f75FH;
                this.f76Hw = aVar.f76Hw;
            }
        }

        @Override
        public int getChangingConfigurations() {
            int i = this.f77j6;
            Drawable.ConstantState constantState = this.f74DW;
            return i | (constantState != null ? constantState.getChangingConfigurations() : 0);
        }

        boolean m36j6() {
            return this.f74DW != null;
        }

        @Override
        public Drawable newDrawable() {
            return newDrawable(null);
        }

        @Override
        public abstract Drawable newDrawable(Resources resources);
    }

    private static class b extends a {
        b(a aVar, Resources resources) {
            super(aVar, resources);
        }

        @Override
        public Drawable newDrawable(Resources resources) {
            return new C0010f(this, resources);
        }
    }

    C0010f(a aVar, Resources resources) {
        this.f73v5 = aVar;
        m30j6(resources);
    }

    C0010f(Drawable drawable) {
        this.f73v5 = mo32DW();
        m34j6(drawable);
    }

    private void m30j6(Resources resources) {
        Drawable.ConstantState constantState;
        a aVar = this.f73v5;
        if (aVar == null || (constantState = aVar.f74DW) == null) {
            return;
        }
        m34j6(m33j6(constantState, resources));
    }

    private boolean m31j6(int[] iArr) {
        if (!mo35j6()) {
            return false;
        }
        a aVar = this.f73v5;
        ColorStateList colorStateList = aVar.f75FH;
        PorterDuff.Mode mode = aVar.f76Hw;
        if (colorStateList == null || mode == null) {
            this.f70Hw = false;
            clearColorFilter();
        } else {
            int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
            if (!this.f70Hw || colorForState != this.f68DW || mode != this.f69FH) {
                setColorFilter(colorForState, mode);
                this.f68DW = colorForState;
                this.f69FH = mode;
                this.f70Hw = true;
                return true;
            }
        }
        return false;
    }

    a mo32DW() {
        return new b(this.f73v5, null);
    }

    @Override
    public void draw(Canvas canvas) {
        this.f71VH.draw(canvas);
    }

    @Override
    public int getChangingConfigurations() {
        int changingConfigurations = super.getChangingConfigurations();
        a aVar = this.f73v5;
        return changingConfigurations | (aVar != null ? aVar.getChangingConfigurations() : 0) | this.f71VH.getChangingConfigurations();
    }

    @Override
    public Drawable.ConstantState getConstantState() {
        a aVar = this.f73v5;
        if (aVar == null || !aVar.m36j6()) {
            return null;
        }
        this.f73v5.f77j6 = getChangingConfigurations();
        return this.f73v5;
    }

    @Override
    public Drawable getCurrent() {
        return this.f71VH.getCurrent();
    }

    @Override
    public int getIntrinsicHeight() {
        return this.f71VH.getIntrinsicHeight();
    }

    @Override
    public int getIntrinsicWidth() {
        return this.f71VH.getIntrinsicWidth();
    }

    @Override
    public int getMinimumHeight() {
        return this.f71VH.getMinimumHeight();
    }

    @Override
    public int getMinimumWidth() {
        return this.f71VH.getMinimumWidth();
    }

    @Override
    public int getOpacity() {
        return this.f71VH.getOpacity();
    }

    @Override
    public boolean getPadding(Rect rect) {
        return this.f71VH.getPadding(rect);
    }

    @Override
    public int[] getState() {
        return this.f71VH.getState();
    }

    @Override
    public Region getTransparentRegion() {
        return this.f71VH.getTransparentRegion();
    }

    @Override
    public void invalidateDrawable(Drawable drawable) {
        invalidateSelf();
    }

    @Override
    public boolean isStateful() {
        a aVar;
        ColorStateList colorStateList = (!mo35j6() || (aVar = this.f73v5) == null) ? null : aVar.f75FH;
        return (colorStateList != null && colorStateList.isStateful()) || this.f71VH.isStateful();
    }

    protected Drawable m33j6(Drawable.ConstantState constantState, Resources resources) {
        return constantState.newDrawable(resources);
    }

    public final void m34j6(Drawable drawable) {
        Drawable drawable2 = this.f71VH;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f71VH = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            setVisible(drawable.isVisible(), true);
            setState(drawable.getState());
            setLevel(drawable.getLevel());
            setBounds(drawable.getBounds());
            a aVar = this.f73v5;
            if (aVar != null) {
                aVar.f74DW = drawable.getConstantState();
            }
        }
        invalidateSelf();
    }

    protected boolean mo35j6() {
        return true;
    }

    @Override
    public void jumpToCurrentState() {
        this.f71VH.jumpToCurrentState();
    }

    @Override
    public Drawable mutate() {
        if (!this.f72Zo && super.mutate() == this) {
            this.f73v5 = mo32DW();
            Drawable drawable = this.f71VH;
            if (drawable != null) {
                drawable.mutate();
            }
            a aVar = this.f73v5;
            if (aVar != null) {
                Drawable drawable2 = this.f71VH;
                aVar.f74DW = drawable2 != null ? drawable2.getConstantState() : null;
            }
            this.f72Zo = true;
        }
        return this;
    }

    @Override
    protected void onBoundsChange(Rect rect) {
        Drawable drawable = this.f71VH;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    @Override
    protected boolean onLevelChange(int i) {
        return this.f71VH.setLevel(i);
    }

    @Override
    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
        scheduleSelf(runnable, j);
    }

    @Override
    public void setAlpha(int i) {
        this.f71VH.setAlpha(i);
    }

    @Override
    public void setChangingConfigurations(int i) {
        this.f71VH.setChangingConfigurations(i);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        this.f71VH.setColorFilter(colorFilter);
    }

    @Override
    public void setDither(boolean z) {
        this.f71VH.setDither(z);
    }

    @Override
    public void setFilterBitmap(boolean z) {
        this.f71VH.setFilterBitmap(z);
    }

    @Override
    public boolean setState(int[] iArr) {
        return m31j6(iArr) || this.f71VH.setState(iArr);
    }

    @Override
    public void setTint(int i) {
        setTintList(ColorStateList.valueOf(i));
    }

    @Override
    public void setTintList(ColorStateList colorStateList) {
        this.f73v5.f75FH = colorStateList;
        m31j6(getState());
    }

    @Override
    public void setTintMode(PorterDuff.Mode mode) {
        this.f73v5.f76Hw = mode;
        m31j6(getState());
    }

    @Override
    public boolean setVisible(boolean z, boolean z2) {
        return super.setVisible(z, z2) || this.f71VH.setVisible(z, z2);
    }

    @Override
    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        unscheduleSelf(runnable);
    }
}
