package abcd;

import java.util.Stack;
import java.util.zip.CRC32;

@xu
public class C0003Ed implements oa {

    @ru(field = 3041280489136891165L)
    private static byte[] f60DW;

    @ru(field = 1437007584002047885L)
    private static int f61FH;

    @tu
    private static boolean f62Hw;

    @ru(field = 2234508202096251807L)
    private static CRC32 f63j6;

    @uu
    private static boolean f64v5;

    @ru(field = -3285169429536322035L)
    private final Hd f65EQ;

    @ru(field = 1990096013818232576L)
    private final yd f66J0;

    @ru(field = 2705305200299439309L)
    private Stack<a> f67J8;

    @ru(field = 4068231616958490660L)
    private final dd f68VH;

    @ru(field = 2684948959920432621L)
    private final La f69Zo;

    @ru(field = 1671118944696052352L)
    private final C0000Ea f70gn;

    @ru(field = 3001199379553005963L)
    private final Va f71tp;

    @ru(field = -4159115496545453408L)
    private final C0086Ga f72u7;

    @ru(field = 2949109271225880672L)
    private final Ba f73we;

    @xu
    private static class a {

        @uu
        private static boolean f74DW;

        @tu
        private static boolean f75j6;

        @ru(field = -1962063656900539720L)
        private C0131a f76FH;

        @ru(field = 2418689543906551733L)
        private C0003Ed f77Hw;

        @ru(field = 4122338315635028576L)
        private Hd f78VH;

        @ru(field = 249177642975191897L)
        private Ba f79Zo;

        @ru(field = -510722662181201207L)
        private Sa f80v5;

        @xu
        private class C0131a {

            @uu
            private static boolean f81DW;

            @tu
            private static boolean f82j6;

            @ru(field = 62997566814534891L)
            private Ab<ua> f83EQ;

            @ru(field = 6445822643321565559L)
            private Na f84FH;

            @ru(field = 4944264020244096544L)
            private ua f85Hw;

            @ru(field = 5298291938817285617L)
            private Ab<Ya> f86J0;

            @ru(field = 8033626686150082263L)
            private Cb f87J8;

            @vu
            final a f88QX;

            @ru(field = -4184405259401402976L)
            private Hb<ua> f89VH;

            @ru(field = 5058340922028445331L)
            private Cb f90Ws;

            @ru(field = 2784760654197079989L)
            private yb<Ya> f91Zo;

            @ru(field = 1058726483205037257L)
            private Ab<Na> f92gn;

            @ru(field = -1220647896420917649L)
            private Hb<Aa> f93tp;

            @ru(field = -6751143962123532495L)
            private Ab<ua> f94u7;

            @ru(field = -3595377576065040920L)
            private int f95v5;

            @ru(field = 3934275059057466833L)
            private Ab<ua> f96we;

            static {
                wu.j6(C0131a.class, 3506781404509494111L, 3506781404509494111L);
            }

            @su(method = 1361161482026479371L)
            public C0131a(a aVar, Ba ba) {
                try {
                    if (f82j6) {
                        wu.j6(-900155176395174915L, (Object) null, aVar, ba);
                    }
                    this.f88QX = aVar;
                    this.f91Zo = new yb(ba);
                    this.f89VH = new C0130Hb(ba);
                    this.f92gn = new Ab(ba);
                    this.f94u7 = new Ab(ba);
                    this.f93tp = new C0130Hb(ba);
                    this.f83EQ = new Ab(ba);
                    this.f96we = new Ab(ba);
                    this.f86J0 = new Ab(ba);
                    this.f87J8 = new Cb();
                    this.f90Ws = new Cb();
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -900155176395174915L, (Object) null, aVar, ba);
                    }
                    throw th;
                }
            }

            @su(method = -2829382934016801448L)
            public Aa m157DW(int i, int i2) {
                try {
                    if (f82j6) {
                        wu.j6(879706330188382153L, this, new Integer(i), new Integer(i2));
                    }
                    int iM1122DW = this.f89VH.m1122DW(i);
                    if (iM1122DW == 1) {
                        return this.f89VH.m1126FH(i);
                    }
                    if (iM1122DW > 1) {
                        throw new gc();
                    }
                    if (this.f93tp.m1130j6(i)) {
                        Aa aaM1126FH = this.f93tp.m1126FH(i);
                        if (aaM1126FH.rN()) {
                            return aaM1126FH;
                        }
                    }
                    if (this.f84FH.FH(this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8(), i, true, i2, this.f84FH)) {
                        try {
                            return this.f84FH.DW(this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8(), i, true, i2, this.f84FH);
                        } catch (jc unused) {
                        }
                    }
                    for (int i3 = 0; i3 < this.f94u7.Hw(); i3++) {
                        if (this.f94u7.j6(i3).j6(i, true)) {
                            try {
                                return this.f94u7.j6(i3).DW(i, true, i2, m171Zo(), this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8());
                            } catch (jc unused2) {
                                continue;
                            }
                        }
                    }
                    ua uaVarDW = null;
                    for (int i4 = 0; i4 < this.f92gn.Hw(); i4++) {
                        if (this.f92gn.j6(i4).FH(this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8(), i, true, i2, this.f84FH)) {
                            try {
                                uaVarDW = this.f92gn.j6(i4).DW(this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8(), i, true, i2, this.f84FH);
                            } catch (jc unused3) {
                            }
                        }
                    }
                    if (uaVarDW != null) {
                        return uaVarDW;
                    }
                    try {
                        return this.f88QX.f78VH.u7().j6(this.f88QX.f80v5.VH(), i, true);
                    } catch (jc unused4) {
                        for (int i5 = 0; i5 < this.f83EQ.Hw(); i5++) {
                            try {
                                ua uaVarDW2 = this.f83EQ.j6(i5).DW(i, true, i2, this.f88QX.f76FH.m170VH(), this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8());
                                if (uaVarDW2.sE()) {
                                    return uaVarDW2;
                                }
                            } catch (gc | jc unused5) {
                            }
                        }
                        throw new jc();
                    }
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 879706330188382153L, this, new Integer(i), new Integer(i2));
                    }
                    throw th;
                }
            }

            @su(method = -3101980274208902969L)
            public void m158DW() {
                try {
                    if (f82j6) {
                        wu.j6(-3706345888850387520L, this);
                    }
                    this.f95v5 = 0;
                    this.f85Hw = null;
                    this.f84FH = null;
                    this.f89VH.m1127j6();
                    this.f92gn.j6();
                    this.f94u7.j6();
                    this.f93tp.m1127j6();
                    this.f83EQ.j6();
                    this.f87J8.j6();
                    this.f96we.j6();
                    this.f86J0.j6();
                    this.f90Ws.j6();
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -3706345888850387520L, this);
                    }
                    throw th;
                }
            }

            @su(method = -1694757031428696000L)
            public void m159DW(int i, ua uaVar) {
                try {
                    if (f82j6) {
                        wu.j6(6109301091382442657L, this, new Integer(i), uaVar);
                    }
                    if (this.f91Zo.j6(i, this.f95v5)) {
                        return;
                    }
                    this.f91Zo.j6(i, uaVar.Gj(), this.f95v5);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 6109301091382442657L, this, new Integer(i), uaVar);
                    }
                    throw th;
                }
            }

            @su(method = -111054218808078336L)
            public void m160DW(Na na) {
                try {
                    if (f82j6) {
                        wu.j6(1581737304069780573L, this, na);
                    }
                    this.f92gn.j6(na);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 1581737304069780573L, this, na);
                    }
                    throw th;
                }
            }

            @su(method = 1453711785005633055L)
            public void m161DW(ua uaVar) {
                try {
                    if (f82j6) {
                        wu.j6(-429602356770991872L, this, uaVar);
                    }
                    this.f94u7.j6(uaVar);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -429602356770991872L, this, uaVar);
                    }
                    throw th;
                }
            }

            @su(method = -1580550433290344175L)
            public void m162EQ() {
                try {
                    if (f82j6) {
                        wu.j6(-2325539640033896000L, this);
                    }
                    this.f90Ws.FH();
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -2325539640033896000L, this);
                    }
                    throw th;
                }
            }

            @su(method = -33976326097704655L)
            public Aa m163FH(int i, int i2) {
                try {
                    if (f82j6) {
                        wu.j6(63893661930100296L, this, new Integer(i), new Integer(i2));
                    }
                    for (int iHw = this.f86J0.Hw() - 1; iHw >= 0; iHw--) {
                        if (this.f86J0.j6(iHw) == null) {
                            int iDW = this.f87J8.DW(iHw);
                            if (this.f91Zo.j6(i, iDW)) {
                                return this.f91Zo.DW(i, iDW);
                            }
                        } else if (this.f96we.j6(iHw).j6(i, true)) {
                            try {
                                return this.f86J0.j6(iHw).j6(i, true, i2, this.f88QX.f76FH.m171Zo(), this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8());
                            } catch (jc unused) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    }
                    return m157DW(i, i2);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 63893661930100296L, this, new Integer(i), new Integer(i2));
                    }
                    throw th;
                }
            }

            @su(method = 4337744173600770688L)
            public void m164FH() {
                try {
                    if (f82j6) {
                        wu.j6(-226561355752718505L, this);
                    }
                    m174j6();
                    this.f96we.FH((Aa) null);
                    this.f86J0.FH((Aa) null);
                    Cb cb = this.f87J8;
                    int i = this.f95v5 + 1;
                    this.f95v5 = i;
                    cb.FH(i);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -226561355752718505L, this);
                    }
                    throw th;
                }
            }

            @su(method = 6831662613561244228L)
            public void m165FH(int i, ua uaVar) {
                try {
                    if (f82j6) {
                        wu.j6(4042811853452863029L, this, new Integer(i), uaVar);
                    }
                    if (this.f89VH.m1130j6(i)) {
                        return;
                    }
                    this.f89VH.m1124DW(i, uaVar);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 4042811853452863029L, this, new Integer(i), uaVar);
                    }
                    throw th;
                }
            }

            @su(method = 4059485698900785981L)
            public void m166FH(ua uaVar) {
                try {
                    if (f82j6) {
                        wu.j6(-5077022481966971840L, this, uaVar);
                    }
                    this.f83EQ.j6(uaVar);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -5077022481966971840L, this, uaVar);
                    }
                    throw th;
                }
            }

            @su(method = 3014401153779558633L)
            public void m167Hw() {
                try {
                    if (f82j6) {
                        wu.j6(-3230286943723434344L, this);
                    }
                    m174j6();
                    this.f96we.FH((Aa) null);
                    this.f86J0.FH((Aa) null);
                    Cb cb = this.f87J8;
                    int i = this.f95v5 + 1;
                    this.f95v5 = i;
                    cb.FH(i);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -3230286943723434344L, this);
                    }
                    throw th;
                }
            }

            @su(method = -7621820051948047076L)
            public void m168Hw(int i, ua uaVar) {
                try {
                    if (f82j6) {
                        wu.j6(-5079375304528003941L, this, new Integer(i), uaVar);
                    }
                    if (this.f89VH.m1130j6(i)) {
                        return;
                    }
                    this.f89VH.m1124DW(i, uaVar);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -5079375304528003941L, this, new Integer(i), uaVar);
                    }
                    throw th;
                }
            }

            @su(method = -6264891856401208296L)
            public void m169J0() {
                try {
                    if (f82j6) {
                        wu.j6(2949324095759111301L, this);
                    }
                    this.f87J8.FH();
                    this.f96we.FH();
                    this.f86J0.FH();
                    this.f95v5--;
                    m182u7();
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 2949324095759111301L, this);
                    }
                    throw th;
                }
            }

            @su(method = -2160438028182008013L)
            public Na m170VH() {
                try {
                    if (f82j6) {
                        wu.j6(6724187775350924816L, this);
                    }
                    return this.f84FH;
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 6724187775350924816L, this);
                    }
                    throw th;
                }
            }

            @su(method = 1481020098942601008L)
            public Aa m171Zo() {
                try {
                    if (f82j6) {
                        wu.j6(-3550943156975618549L, this);
                    }
                    return this.f85Hw != null ? this.f85Hw : this.f84FH;
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -3550943156975618549L, this);
                    }
                    throw th;
                }
            }

            @su(method = -4373030203255140873L)
            public boolean m172gn() {
                try {
                    if (f82j6) {
                        wu.j6(-2538489544656572928L, this);
                    }
                    return Ma.aM(this.f90Ws.DW());
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -2538489544656572928L, this);
                    }
                    throw th;
                }
            }

            @su(method = -514703061357251472L)
            public Aa m173j6(int i, int i2) {
                try {
                    if (f82j6) {
                        wu.j6(-943510285265897991L, this, new Integer(i), new Integer(i2));
                    }
                    for (int iHw = this.f96we.Hw() - 1; iHw >= 0; iHw--) {
                        if (this.f96we.j6(iHw) == null) {
                            int iDW = this.f87J8.DW(iHw);
                            if (this.f91Zo.j6(i, iDW)) {
                                return this.f91Zo.DW(i, iDW);
                            }
                        } else if (this.f96we.j6(iHw).j6(i, true)) {
                            try {
                                return this.f96we.j6(iHw).DW(i, true, i2, m183v5(), this.f88QX.f80v5.VH(), this.f88QX.f80v5.J8());
                            } catch (jc unused) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    }
                    return m157DW(i, i2);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -943510285265897991L, this, new Integer(i), new Integer(i2));
                    }
                    throw th;
                }
            }

            @su(method = 3224501001353008448L)
            public void m174j6() {
                try {
                    if (f82j6) {
                        wu.j6(-2936527268598223545L, this);
                    }
                    this.f91Zo.DW();
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -2936527268598223545L, this);
                    }
                    throw th;
                }
            }

            @su(method = -932532218833582713L)
            public void m175j6(int i) {
                try {
                    if (f82j6) {
                        wu.j6(959826786037730400L, this, i);
                    }
                    this.f90Ws.FH(i);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 959826786037730400L, this, new Integer(i));
                    }
                    throw th;
                }
            }

            @su(method = -1152043318756898268L)
            public void m176j6(int i, Aa aa) {
                try {
                    if (f82j6) {
                        wu.j6(403112126032176573L, this, new Integer(i), aa);
                    }
                    if (this.f93tp.m1130j6(i)) {
                        return;
                    }
                    this.f93tp.m1124DW(i, aa);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 403112126032176573L, this, new Integer(i), aa);
                    }
                    throw th;
                }
            }

            @su(method = 221014843611586905L)
            public void m177j6(int i, Ya ya) {
                try {
                    if (f82j6) {
                        wu.j6(-365131509035696312L, this, new Integer(i), ya);
                    }
                    if (this.f91Zo.j6(i, this.f95v5)) {
                        return;
                    }
                    this.f91Zo.j6(i, ya, this.f95v5);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -365131509035696312L, this, new Integer(i), ya);
                    }
                    throw th;
                }
            }

            @su(method = 815050567535072708L)
            public void m178j6(int i, ua uaVar) {
                try {
                    if (f82j6) {
                        wu.j6(85736779093552975L, this, new Integer(i), uaVar);
                    }
                    if (this.f91Zo.j6(i, this.f95v5)) {
                        return;
                    }
                    this.f91Zo.j6(i, uaVar, this.f95v5);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 85736779093552975L, this, new Integer(i), uaVar);
                    }
                    throw th;
                }
            }

            @su(method = -460137924992805245L)
            public void m179j6(Na na) {
                try {
                    if (f82j6) {
                        wu.j6(-2981653586614029268L, this, na);
                    }
                    this.f84FH = na;
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -2981653586614029268L, this, na);
                    }
                    throw th;
                }
            }

            @su(method = -4477772808411398496L)
            public void m180j6(ua uaVar) {
                try {
                    if (f82j6) {
                        wu.j6(-1021928850899176025L, this, uaVar);
                    }
                    this.f85Hw = uaVar;
                    this.f96we.FH(uaVar);
                    this.f86J0.FH(uaVar.Gj());
                    this.f87J8.FH(-1);
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, -1021928850899176025L, this, uaVar);
                    }
                    throw th;
                }
            }

            @su(method = -2964272564936540132L)
            public void m181tp() {
                try {
                    if (f82j6) {
                        wu.j6(3786259856409106689L, this);
                    }
                    this.f87J8.FH();
                    this.f96we.FH();
                    this.f86J0.FH();
                    int iHw = this.f96we.Hw() - 1;
                    while (iHw >= 0 && this.f96we.j6(iHw) == null) {
                        iHw--;
                    }
                    if (iHw >= 0) {
                        this.f85Hw = this.f96we.j6(iHw);
                    } else {
                        this.f85Hw = null;
                    }
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 3786259856409106689L, this);
                    }
                    throw th;
                }
            }

            @su(method = 469656140705803815L)
            public void m182u7() {
                try {
                    if (f82j6) {
                        wu.j6(2640609548056876464L, this);
                    }
                    this.f91Zo.FH();
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 2640609548056876464L, this);
                    }
                    throw th;
                }
            }

            @su(method = 3667050680382474539L)
            public ua m183v5() {
                try {
                    if (f82j6) {
                        wu.j6(763092606013320960L, this);
                    }
                    return this.f85Hw;
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 763092606013320960L, this);
                    }
                    throw th;
                }
            }

            @su(method = -1251435377303092389L)
            public void m184we() {
                try {
                    if (f82j6) {
                        wu.j6(3392097131663972592L, this);
                    }
                    this.f87J8.FH();
                    this.f96we.FH();
                    this.f86J0.FH();
                    this.f95v5--;
                    m182u7();
                } catch (Throwable th) {
                    if (f81DW) {
                        wu.j6(th, 3392097131663972592L, this);
                    }
                    throw th;
                }
            }
        }

        static {
            wu.j6(a.class, 1328135661568060568L, 1328135661568060568L);
        }

        @su(method = -8176670205695877795L)
        public a(C0003Ed c0003Ed, Ba ba) {
            try {
                if (f75j6) {
                    wu.j6(-457845839623811165L, (Object) null, c0003Ed, ba);
                }
                this.f76FH = new C0131a(this, ba);
                this.f77Hw = c0003Ed;
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -457845839623811165L, (Object) null, c0003Ed, ba);
                }
                throw th;
            }
        }

        @su(method = -1524356277484583171L)
        private void m96BT(int i) {
            try {
                if (f75j6) {
                    wu.j6(-768923513637048525L, this, i);
                }
                ua uaVarU7 = this.f78VH.u7();
                int iWe = this.f80v5.we(i);
                for (int i2 = 1; i2 < iWe - 2; i2 += 2) {
                    int iXL = this.f80v5.XL(this.f80v5.Zo(i, i2));
                    try {
                        uaVarU7 = uaVarU7.rN() ? uaVarU7.DW(iXL, true, 0, this.f76FH.m170VH(), this.f80v5.VH(), this.f80v5.J8()) : ((Na) uaVarU7).j6(this.f80v5.VH(), this.f80v5.J8(), iXL, true, 0, (Na) uaVarU7);
                    } catch (jc | gc unused) {
                        return;
                    }
                }
                if (uaVarU7.rN()) {
                    this.f76FH.m161DW(uaVarU7);
                } else {
                    this.f76FH.m160DW((Na) uaVarU7);
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -768923513637048525L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -729818562056474557L)
        private void m98DW(int i) {
            try {
                if (f75j6) {
                    wu.j6(-89491892699568615L, this, i);
                }
                int iWe = this.f80v5.we(i);
                for (int i2 = 1; i2 < iWe; i2 += 2) {
                    int iZo = this.f80v5.Zo(i, i2);
                    int iXL = this.f80v5.XL(this.f80v5.Zo(iZo, 0));
                    try {
                        this.f76FH.m177j6(iXL, this.f79Zo.Hw(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo)));
                    } catch (jc unused) {
                    }
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -89491892699568615L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -316935035122202952L)
        private void m99DW(int i, ua uaVar) {
            try {
                if (f75j6) {
                    wu.j6(-1247311511009544324L, this, new Integer(i), uaVar);
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (uaVar.DW(uaVarJ6)) {
                        m113J8(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 2));
                        this.f76FH.m180j6(uaVarJ6);
                        if (uaVarJ6 == uaVar) {
                            try {
                                if (this.f80v5.we(i) != 7) {
                                    Ya yaM129gn = m129gn(this.f80v5.Zo(i, 2));
                                    if (yaM129gn.g3()) {
                                        this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                                    }
                                    this.f79Zo.j6(uaVarJ6, yaM129gn);
                                } else {
                                    this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                                }
                            } catch (jc unused) {
                            }
                        }
                        if (this.f80v5.we(i) == 7) {
                            m113J8(uaVar, this.f80v5.Zo(i, 0));
                        }
                        m113J8(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                        this.f76FH.m181tp();
                    }
                } catch (jc unused2) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1247311511009544324L, this, new Integer(i), uaVar);
                }
                throw th;
            }
        }

        @su(method = 7632584217622029243L)
        private void m100DW(Ia ia, int i) throws Throwable {
            int iBT;
            int iVy;
            int iBT2;
            int i2;
            try {
                if (f75j6) {
                    try {
                        wu.j6(235914662656322325L, this, ia, new Integer(i));
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, 235914662656322325L, this, ia, new Integer(i));
                        }
                        throw th;
                    }
                }
                int iVy2 = this.f80v5.vy(this.f80v5.Zo(i, 0));
                int iBT3 = this.f80v5.BT(this.f80v5.Zo(i, 0));
                int iWs = this.f80v5.Ws(this.f80v5.Zo(i, 0));
                int iZo = this.f80v5.Zo(this.f80v5.er(i), 0);
                int iM141tp = m141tp(iZo);
                if (iM141tp != -1) {
                    int iVy3 = this.f80v5.vy(iM141tp);
                    iBT = this.f80v5.BT(iM141tp);
                    iVy = this.f80v5.QX(iM141tp);
                    i2 = iVy3;
                    iBT2 = this.f80v5.Ws(iM141tp);
                } else {
                    int iVy4 = this.f80v5.vy(iZo);
                    iBT = this.f80v5.BT(iZo);
                    iVy = this.f80v5.vy(iZo);
                    iBT2 = this.f80v5.BT(iZo);
                    i2 = iVy4;
                }
                int iQX = this.f80v5.QX(this.f80v5.j3(this.f80v5.er(i)));
                int iWs2 = this.f80v5.Ws(this.f80v5.j3(this.f80v5.er(i)));
                int iQX2 = this.f80v5.QX(this.f80v5.er(i));
                int iWs3 = this.f80v5.Ws(this.f80v5.er(i));
                this.f79Zo.j6(ia, iVy2, iBT3, iWs, i2, iBT, iVy, iBT2, iQX, iWs2, iQX2, iWs3);
            } catch (Throwable th2) {
                th = th2;
            }
        }

        @su(method = 3263933917438197019L)
        private void m101DW(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-1797777555476483475L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 129) {
                            this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    if (this.f80v5.P8(i) == 129) {
                        this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m167Hw();
                    m98DW(this.f80v5.Zo(i, 3));
                    if (uaVarJ6 == uaVar) {
                        int iZo = this.f80v5.Zo(i, 3);
                        int iWe = this.f80v5.we(iZo);
                        int i2 = 1;
                        int i3 = 0;
                        while (i2 < iWe) {
                            try {
                                int iZo2 = this.f80v5.Zo(iZo, i2);
                                Pa paHw = this.f79Zo.Hw(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2));
                                int iWe2 = this.f80v5.we(iZo2);
                                for (int i4 = 2; i4 < iWe2; i4 += 2) {
                                    Pa paM129gn = m129gn(this.f80v5.Zo(iZo2, i4));
                                    if ((paM129gn.rN() || paM129gn.P8() || paM129gn.ei() || paM129gn.gW()) && (!paM129gn.ei() || paM129gn.sy() != uaVarJ6 || paM129gn.aj() < i3)) {
                                        this.f79Zo.j6(paHw, paM129gn);
                                    }
                                }
                            } catch (jc unused) {
                            }
                            i2 += 2;
                            i3++;
                        }
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m107FH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                    this.f76FH.m169J0();
                } catch (jc unused2) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1797777555476483475L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        /* JADX WARN: Code duplicated, block: B:33:0x00af A[Catch: jc -> 0x00ca, Throwable -> 0x00e0, TRY_LEAVE, TryCatch #0 {Throwable -> 0x00e0, blocks: (B:3:0x0005, B:5:0x0009, B:6:0x000c, B:29:0x003f, B:34:0x00ca, B:36:0x00d3, B:30:0x005b, B:31:0x0077, B:32:0x0093, B:33:0x00af), top: B:47:0x0005 }] */
        /* JADX WARN: Failed to find 'out' block for switch in B:27:0x003a. Please report as an issue. */
        @su(method = 3083482378821551479L)
        private void m102EQ(int i) {
            try {
                if (f75j6) {
                    wu.j6(3684128940076339209L, this, i);
                }
                int iP8 = this.f80v5.P8(i);
                try {
                    if (iP8 == 120 || iP8 == 121) {
                        m146v5(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), i);
                    } else if (iP8 == 123) {
                        m137j6(this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), i);
                    } else if (iP8 == 124) {
                        m106FH(this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), i);
                    } else if (iP8 == 128 || iP8 == 129) {
                        m146v5(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), i);
                    } else if (iP8 == 177) {
                        m109Hw(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), i);
                    } else if (iP8 != 194) {
                        if (iP8 != 227 && iP8 != 228) {
                            switch (iP8) {
                            }
                        }
                        m146v5(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), i);
                    } else {
                        m100DW(this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), i);
                    }
                } catch (jc unused) {
                }
                int iWe = this.f80v5.we(i);
                for (int i2 = 0; i2 < iWe; i2++) {
                    m102EQ(this.f80v5.Zo(i, i2));
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 3684128940076339209L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -2595814132689803805L)
        private void m103EQ(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(6789424825031882925L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 128) {
                            this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    if (this.f80v5.P8(i) == 128) {
                        this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m167Hw();
                    m98DW(this.f80v5.Zo(i, 3));
                    if (uaVarJ6 == uaVar) {
                        int iZo = this.f80v5.Zo(i, 4);
                        if (this.f80v5.we(iZo) != 0) {
                            try {
                                this.f79Zo.j6(uaVarJ6, m129gn(this.f80v5.Zo(iZo, 1)));
                            } catch (jc unused) {
                            }
                        } else if (uaVarJ6 != this.f78VH.P8(this.f80v5.VH())) {
                            this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                        }
                        int iZo2 = this.f80v5.Zo(i, 5);
                        int iWe = this.f80v5.we(iZo2);
                        for (int i2 = 1; i2 < iWe; i2 += 2) {
                            try {
                                this.f79Zo.j6(uaVarJ6, m129gn(this.f80v5.Zo(iZo2, i2)));
                            } catch (jc unused2) {
                            }
                        }
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m113J8(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                    this.f76FH.m169J0();
                } catch (jc unused3) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 6789424825031882925L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -4139517930881179293L)
        private void m105FH(int i) {
            try {
                if (f75j6) {
                    wu.j6(439899037484711161L, this, i);
                }
                int iWe = this.f80v5.we(i);
                for (int i2 = 0; i2 < iWe; i2++) {
                    int iZo = this.f80v5.Zo(i, i2);
                    if (this.f80v5.P8(iZo) == 120 || this.f80v5.P8(iZo) == 220 || this.f80v5.P8(iZo) == 121) {
                        try {
                            this.f76FH.m165FH(this.f80v5.XL(this.f80v5.Zo(iZo, 2)), this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo)));
                        } catch (jc unused) {
                        }
                    }
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 439899037484711161L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 286075449003289852L)
        private void m106FH(Ia ia, int i) throws Throwable {
            int iBT;
            int iVy;
            int iBT2;
            int i2;
            try {
                if (f75j6) {
                    try {
                        wu.j6(5816761043033788808L, this, ia, new Integer(i));
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, 5816761043033788808L, this, ia, new Integer(i));
                        }
                        throw th;
                    }
                }
                int iVy2 = this.f80v5.vy(this.f80v5.Zo(i, 4));
                int iBT3 = this.f80v5.BT(this.f80v5.Zo(i, 4));
                int iWs = this.f80v5.Ws(this.f80v5.Zo(i, 4));
                int iZo = this.f80v5.Zo(i, 0);
                int iM141tp = m141tp(iZo);
                if (iM141tp != -1) {
                    int iVy3 = this.f80v5.vy(iM141tp);
                    iBT = this.f80v5.BT(iM141tp);
                    iVy = this.f80v5.QX(iM141tp);
                    i2 = iVy3;
                    iBT2 = this.f80v5.Ws(iM141tp);
                } else {
                    int iVy4 = this.f80v5.vy(iZo);
                    iBT = this.f80v5.BT(iZo);
                    iVy = this.f80v5.vy(iZo);
                    iBT2 = this.f80v5.BT(iZo);
                    i2 = iVy4;
                }
                this.f79Zo.j6(ia, iVy2, iBT3, iWs, i2, iBT, iVy, iBT2, this.f80v5.sh(i) ? this.f80v5.QX(this.f80v5.j3(i)) : this.f80v5.vy(i), this.f80v5.sh(i) ? this.f80v5.Ws(this.f80v5.j3(i)) : this.f80v5.BT(i), this.f80v5.QX(i), this.f80v5.Ws(i));
                m148we(this.f80v5.Zo(i, 1));
            } catch (Throwable th2) {
                th = th2;
            }
        }

        @su(method = -604061115126548373L)
        private void m107FH(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-1315803820425109455L, this, uaVar, new Integer(i));
                }
                int iP8 = this.f80v5.P8(i);
                if (iP8 != 120) {
                    if (iP8 != 121) {
                        int i2 = 0;
                        if (iP8 == 123 || iP8 == 124) {
                            this.f76FH.m164FH();
                            m135j6(this.f80v5.Zo(i, 1));
                            int iWe = this.f80v5.we(i);
                            while (i2 < iWe) {
                                m107FH(uaVar, this.f80v5.Zo(i, i2));
                                i2++;
                            }
                            this.f76FH.m184we();
                            return;
                        }
                        if (iP8 == 133) {
                            this.f76FH.m174j6();
                            int iWe2 = this.f80v5.we(i);
                            while (i2 < iWe2) {
                                m107FH(uaVar, this.f80v5.Zo(i, i2));
                                i2++;
                            }
                            this.f76FH.m182u7();
                            return;
                        }
                        if (iP8 == 177) {
                            try {
                                m107FH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 2));
                                ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                                if (uaVar.DW(uaVarJ6)) {
                                    this.f76FH.m180j6(uaVarJ6);
                                    if (this.f80v5.we(i) == 7) {
                                        m107FH(uaVar, this.f80v5.Zo(i, 0));
                                    }
                                    m107FH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                                    this.f76FH.m181tp();
                                    return;
                                }
                                return;
                            } catch (jc unused) {
                                return;
                            }
                        }
                        if (iP8 != 227) {
                            if (iP8 != 228) {
                                switch (iP8) {
                                    case 126:
                                    case 127:
                                        this.f76FH.m164FH();
                                        int iWe3 = this.f80v5.we(i);
                                        while (i2 < iWe3) {
                                            m107FH(uaVar, this.f80v5.Zo(i, i2));
                                            i2++;
                                        }
                                        this.f76FH.m184we();
                                        return;
                                    case 128:
                                        break;
                                    case 129:
                                        break;
                                    default:
                                        switch (iP8) {
                                            case 220:
                                            case 221:
                                            case 222:
                                                return;
                                            case 223:
                                                m108Hw(this.f80v5.Zo(i, 0));
                                                int iWe4 = this.f80v5.we(i);
                                                for (int i3 = 1; i3 < iWe4; i3++) {
                                                    m147vy(this.f80v5.Zo(i, i3));
                                                }
                                                m105FH(i);
                                                for (int i4 = 1; i4 < iWe4; i4++) {
                                                    int iZo = this.f80v5.Zo(i, i4);
                                                    if (this.f80v5.P8(iZo) == 120 || this.f80v5.P8(iZo) == 220 || this.f80v5.P8(iZo) == 121) {
                                                        m107FH(uaVar, this.f80v5.Zo(i, i4));
                                                    }
                                                }
                                                return;
                                            default:
                                                int iWe5 = this.f80v5.we(i);
                                                while (i2 < iWe5) {
                                                    m107FH(uaVar, this.f80v5.Zo(i, i2));
                                                    i2++;
                                                }
                                                return;
                                        }
                                }
                            }
                        }
                    }
                    m101DW(uaVar, i);
                    return;
                }
                m138j6(uaVar, i);
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1315803820425109455L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -53459540817925471L)
        private Na m108Hw(int i) {
            try {
                if (f75j6) {
                    wu.j6(-813994073969484077L, this, i);
                }
                Na naU7 = this.f78VH.u7();
                int iWe = this.f80v5.we(i);
                for (int i2 = 2; i2 < iWe - 1; i2 += 2) {
                    naU7 = naU7.j6(this.f80v5.XL(this.f80v5.Zo(i, i2)));
                }
                this.f76FH.m179j6(naU7);
                return naU7;
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -813994073969484077L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -208804164801179172L)
        private void m109Hw(ua uaVar, int i) throws Throwable {
            try {
                if (f75j6) {
                    try {
                        wu.j6(3418412738726599968L, this, uaVar, new Integer(i));
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, 3418412738726599968L, this, uaVar, new Integer(i));
                        }
                        throw th;
                    }
                }
                this.f79Zo.j6(uaVar, this.f80v5.vy(this.f80v5.Zo(i, 2)), this.f80v5.BT(this.f80v5.Zo(i, 2)), this.f80v5.Ws(this.f80v5.Zo(i, 2)), 0, 0, 0, 0, 0, 0, 0, 0);
            } catch (Throwable th2) {
                th = th2;
            }
        }

        @su(method = -331510780238816400L)
        private void m110J0(int i) {
            try {
                if (f75j6) {
                    wu.j6(-237443602261747136L, this, i);
                }
                int iWe = this.f80v5.we(i);
                for (int i2 = 1; i2 < iWe; i2 += 2) {
                    try {
                        int iZo = this.f80v5.Zo(i, i2);
                        this.f79Zo.j6(this.f79Zo.Hw(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo)), this.f80v5.vy(iZo), this.f80v5.BT(iZo), this.f80v5.Ws(iZo));
                    } catch (jc unused) {
                    }
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -237443602261747136L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 3230431542430304800L)
        private void m111J0(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-2052979800297444224L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 129) {
                            this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    if (this.f80v5.P8(i) == 129) {
                        this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m167Hw();
                    m98DW(this.f80v5.Zo(i, 3));
                    if (uaVarJ6 == uaVar) {
                        int iZo = this.f80v5.Zo(i, 4);
                        int iWe = this.f80v5.we(iZo);
                        if (iWe != 0) {
                            for (int i2 = 1; i2 < iWe; i2 += 2) {
                                try {
                                    this.f79Zo.j6(uaVarJ6, m129gn(this.f80v5.Zo(iZo, i2)));
                                } catch (jc unused) {
                                }
                            }
                        } else if (uaVarJ6 != this.f78VH.P8(this.f80v5.VH())) {
                            this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                        }
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m113J8(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                    this.f76FH.m169J0();
                } catch (jc unused2) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -2052979800297444224L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -2076221758508093000L)
        private void m112J8(int i) {
            try {
                if (f75j6) {
                    wu.j6(1076849830279043396L, this, i);
                }
                int iP8 = this.f80v5.P8(i);
                if (iP8 != 120 && iP8 != 121) {
                    if (iP8 == 123) {
                        m116QX(i);
                        return;
                    }
                    if (iP8 == 124) {
                        m117U2(i);
                        return;
                    }
                    if (iP8 == 163) {
                        this.f76FH.m175j6(64);
                        m112J8(this.f80v5.Zo(i, 2));
                        this.f76FH.m162EQ();
                        return;
                    }
                    if (iP8 == 164) {
                        this.f76FH.m175j6(64);
                        if (this.f80v5.we(i) == 4) {
                            m112J8(this.f80v5.Zo(i, 2));
                        } else {
                            m112J8(this.f80v5.Zo(i, 0));
                            m112J8(this.f80v5.Zo(i, 4));
                        }
                        this.f76FH.m162EQ();
                        return;
                    }
                    if (iP8 == 177) {
                        m112J8(this.f80v5.Zo(i, this.f80v5.we(i) - 2));
                        ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i), this.f76FH.m170VH(), this.f76FH.m183v5(), this.f76FH.m172gn(), true);
                        this.f76FH.m180j6(uaVarJ6);
                        m109Hw(uaVarJ6, i);
                        m112J8(this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                        this.f76FH.m181tp();
                        return;
                    }
                    if (iP8 != 227 && iP8 != 228) {
                        if (iP8 == 245) {
                            m124a8(i);
                            return;
                        }
                        if (iP8 == 246) {
                            m114Mr(i);
                            return;
                        }
                        switch (iP8) {
                            case 126:
                                m121XL(i);
                                return;
                            case 127:
                                this.f76FH.m175j6(m118VH(this.f80v5.Zo(i, 0)));
                                m112J8(this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                                this.f76FH.m162EQ();
                                return;
                            default:
                                switch (iP8) {
                                    case 220:
                                        break;
                                    case 221:
                                        break;
                                    case 222:
                                        break;
                                    case 223:
                                        this.f79Zo.j6(m108Hw(this.f80v5.Zo(i, 0)), this.f80v5.VH(), this.f80v5.J8());
                                        int iWe = this.f80v5.we(i);
                                        for (int i2 = 1; i2 < iWe; i2++) {
                                            m112J8(this.f80v5.Zo(i, i2));
                                        }
                                        return;
                                    default:
                                        int iWe2 = this.f80v5.we(i);
                                        for (int i3 = 0; i3 < iWe2; i3++) {
                                            m112J8(this.f80v5.Zo(i, i3));
                                        }
                                        return;
                                }
                            case 128:
                            case 129:
                                m125aM(i);
                                return;
                        }
                    }
                    m131j3(i);
                    return;
                }
                m120Ws(i);
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 1076849830279043396L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -1159586773064746800L)
        private void m113J8(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-1795032697448384184L, this, uaVar, new Integer(i));
                }
                int iP8 = this.f80v5.P8(i);
                if (iP8 != 120) {
                    if (iP8 != 121) {
                        int i2 = 0;
                        if (iP8 == 123 || iP8 == 124) {
                            this.f76FH.m164FH();
                            m135j6(this.f80v5.Zo(i, 1));
                            int iWe = this.f80v5.we(i);
                            while (i2 < iWe) {
                                m113J8(uaVar, this.f80v5.Zo(i, i2));
                                i2++;
                            }
                            this.f76FH.m184we();
                            return;
                        }
                        if (iP8 == 133) {
                            this.f76FH.m174j6();
                            int iWe2 = this.f80v5.we(i);
                            while (i2 < iWe2) {
                                m113J8(uaVar, this.f80v5.Zo(i, i2));
                                i2++;
                            }
                            this.f76FH.m182u7();
                            return;
                        }
                        if (iP8 == 177) {
                            m99DW(i, uaVar);
                            return;
                        }
                        if (iP8 != 227) {
                            if (iP8 != 228) {
                                switch (iP8) {
                                    case 126:
                                    case 127:
                                        this.f76FH.m164FH();
                                        int iWe3 = this.f80v5.we(i);
                                        while (i2 < iWe3) {
                                            m113J8(uaVar, this.f80v5.Zo(i, i2));
                                            i2++;
                                        }
                                        this.f76FH.m184we();
                                        return;
                                    case 128:
                                        break;
                                    case 129:
                                        break;
                                    default:
                                        switch (iP8) {
                                            case 220:
                                            case 221:
                                            case 222:
                                                m149we(uaVar, i);
                                                return;
                                            case 223:
                                                m108Hw(this.f80v5.Zo(i, 0));
                                                int iWe4 = this.f80v5.we(i);
                                                for (int i3 = 1; i3 < iWe4; i3++) {
                                                    m147vy(this.f80v5.Zo(i, i3));
                                                }
                                                m105FH(i);
                                                for (int i4 = 1; i4 < iWe4; i4++) {
                                                    int iZo = this.f80v5.Zo(i, i4);
                                                    if (this.f80v5.P8(iZo) == 120 || this.f80v5.P8(iZo) == 220 || this.f80v5.P8(iZo) == 121) {
                                                        m113J8(uaVar, this.f80v5.Zo(i, i4));
                                                    }
                                                }
                                                return;
                                            default:
                                                int iWe5 = this.f80v5.we(i);
                                                while (i2 < iWe5) {
                                                    m113J8(uaVar, this.f80v5.Zo(i, i2));
                                                    i2++;
                                                }
                                                return;
                                        }
                                }
                            }
                        }
                    }
                    m111J0(uaVar, i);
                    return;
                }
                m103EQ(uaVar, i);
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1795032697448384184L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 5537865865212400752L)
        private void m114Mr(int i) {
            try {
                if (f75j6) {
                    wu.j6(4151675423452818712L, this, i);
                }
                m123Zo(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i), this.f76FH.m170VH(), 0, this.f76FH.m183v5(), m118VH(this.f80v5.Zo(i, 0)) | 33554432, this.f80v5.XL(this.f80v5.Zo(i, 4)), 0), i);
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 4151675423452818712L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 1145168049531282603L)
        private void m115P8(int i) {
            try {
                if (f75j6) {
                    wu.j6(168565404422498013L, this, i);
                }
                ua uaVarU7 = this.f78VH.u7();
                int iWe = this.f80v5.we(i) - 2;
                ua uaVarDW = uaVarU7;
                for (int i2 = 2; i2 < iWe; i2 += 2) {
                    int iXL = this.f80v5.XL(this.f80v5.Zo(i, i2));
                    try {
                        uaVarDW = uaVarDW.rN() ? uaVarDW.DW(iXL, true, 0, this.f76FH.m170VH(), this.f80v5.VH(), this.f80v5.J8()) : ((Na) uaVarDW).j6(this.f80v5.VH(), this.f80v5.J8(), iXL, true, 0, (Na) uaVarDW);
                    } catch (jc | gc unused) {
                        return;
                    }
                }
                if (uaVarDW.rN()) {
                    int iXL2 = this.f80v5.XL(this.f80v5.Zo(i, this.f80v5.we(i) - 2));
                    try {
                        Aa aaDW = uaVarDW.DW(iXL2, true, 0, this.f76FH.m170VH(), this.f80v5.VH(), this.f80v5.J8());
                        if (aaDW.sE()) {
                            this.f76FH.m176j6(iXL2, aaDW);
                        }
                    } catch (gc | jc unused2) {
                    }
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 168565404422498013L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 4995044506838326751L)
        private void m116QX(int i) throws Throwable {
            int i2;
            boolean z;
            try {
                if (f75j6) {
                    wu.j6(-149821681392464463L, this, i);
                }
                int iM118VH = m118VH(this.f80v5.Zo(i, 0));
                if ((iM118VH & 1) == 0 && (iM118VH & 4) == 0) {
                    iM118VH |= 32;
                }
                int i3 = iM118VH;
                this.f76FH.m175j6(i3);
                int iWe = this.f80v5.we(this.f80v5.Zo(i, 4)) / 2;
                int iZo = this.f80v5.Zo(i, 3);
                int iWe2 = this.f80v5.we(iZo) == 2 ? 0 : (this.f80v5.we(iZo) - 1) / 2;
                if (this.f80v5.we(iZo) > 2) {
                    int iZo2 = this.f80v5.Zo(this.f80v5.Zo(iZo, this.f80v5.we(iZo) - 2), 2);
                    z = this.f80v5.we(iZo2) > 0 && this.f80v5.P8(this.f80v5.Zo(iZo2, this.f80v5.we(iZo2) - 1)) == 108;
                } else {
                    z = false;
                }
                int iZo3 = this.f80v5.Zo(i, 1);
                int iWe3 = this.f80v5.we(iZo3);
                try {
                    Ia iaJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i), this.f76FH.m183v5(), i3, (iWe3 - 1) / 2, iWe2, z, iWe);
                    if (this.f80v5.we(iZo) > 2) {
                        int iWe4 = this.f80v5.we(iZo);
                        int i4 = 1;
                        int i5 = 0;
                        while (i4 < iWe4) {
                            this.f79Zo.j6(iaJ6, 0, this.f80v5.XL(this.f80v5.Zo(this.f80v5.Zo(iZo, i4), 3)), i5);
                            i4 += 2;
                            i5++;
                        }
                    }
                    int i6 = 0;
                    for (int i7 = 1; i7 < iWe3; i7 += 2) {
                        int iZo4 = this.f80v5.Zo(iZo3, i7);
                        if (this.f80v5.we(iZo4) != 3) {
                            int iWe5 = (this.f80v5.we(iZo4) - 1) / 2;
                        }
                        this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo4), iaJ6, i6, this.f80v5.XL(this.f80v5.Zo(iZo4, 0)));
                        i6++;
                    }
                    i2 = i;
                    try {
                        m112J8(this.f80v5.Zo(i2, this.f80v5.we(i2) - 1));
                        this.f76FH.m162EQ();
                        m137j6(iaJ6, i2);
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, -149821681392464463L, this, new Integer(i2));
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    i2 = i;
                }
            } catch (Throwable th3) {
                th = th3;
                i2 = i;
            }
        }

        @su(method = -487650302892811236L)
        private void m117U2(int i) throws Throwable {
            int i2;
            boolean z;
            try {
                if (f75j6) {
                    wu.j6(316406721248413024L, this, i);
                }
                int iM118VH = m118VH(this.f80v5.Zo(i, 0)) & (-769);
                if (!Ma.aM(iM118VH)) {
                    iM118VH |= 98304;
                }
                if ((iM118VH & 1) == 0 && (iM118VH & 4) == 0) {
                    iM118VH |= 32;
                }
                this.f76FH.m175j6(iM118VH);
                if (this.f76FH.m183v5().g3()) {
                    iM118VH |= 16385;
                }
                int i3 = iM118VH;
                int iM143u7 = m143u7(this.f80v5.Zo(i, 0));
                int iWe = this.f80v5.we(this.f80v5.Zo(i, 7)) / 2;
                int iZo = this.f80v5.Zo(i, 5);
                int iWe2 = this.f80v5.we(iZo) == 2 ? 0 : (this.f80v5.we(iZo) - 1) / 2;
                if (this.f80v5.we(iZo) > 2) {
                    int iZo2 = this.f80v5.Zo(this.f80v5.Zo(iZo, this.f80v5.we(iZo) - 2), 2);
                    z = this.f80v5.we(iZo2) > 0 && this.f80v5.P8(this.f80v5.Zo(iZo2, this.f80v5.we(iZo2) - 1)) == 108;
                } else {
                    z = false;
                }
                int iZo3 = this.f80v5.Zo(i, 1);
                int iWe3 = this.f80v5.we(iZo3);
                int i4 = iZo3;
                try {
                    Ia iaJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i), this.f76FH.m183v5(), i3, this.f80v5.XL(this.f80v5.Zo(i, 4)), (iWe3 - 1) / 2, iWe2, z, false, iWe);
                    this.f79Zo.j6(iaJ6, iM143u7);
                    if (this.f80v5.we(iZo) > 2) {
                        int iWe4 = this.f80v5.we(iZo);
                        int i5 = 1;
                        int i6 = 0;
                        while (i5 < iWe4) {
                            this.f79Zo.j6(iaJ6, 0, this.f80v5.XL(this.f80v5.Zo(this.f80v5.Zo(iZo, i5), 3)), i6);
                            i5 += 2;
                            i6++;
                        }
                    }
                    int i7 = 1;
                    int i8 = 0;
                    while (i7 < iWe3) {
                        int i9 = i4;
                        int iZo4 = this.f80v5.Zo(i9, i7);
                        if (this.f80v5.we(iZo4) != 3) {
                            int iWe5 = (this.f80v5.we(iZo4) - 1) / 2;
                        }
                        this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo4), iaJ6, i8, this.f80v5.XL(this.f80v5.Zo(iZo4, 0)));
                        i8++;
                        i7 += 2;
                        i4 = i9;
                    }
                    i2 = i;
                    try {
                        m112J8(this.f80v5.Zo(i2, this.f80v5.we(i2) - 1));
                        this.f76FH.m162EQ();
                        m106FH(iaJ6, i2);
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, 316406721248413024L, this, new Integer(i2));
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    i2 = i;
                }
            } catch (Throwable th3) {
                th = th3;
                i2 = i;
            }
        }

        @su(method = 3106430338060222833L)
        private int m118VH(int i) {
            int i2;
            try {
                if (f75j6) {
                    wu.j6(1573813511687610579L, this, i);
                }
                int iWe = this.f80v5.we(i);
                int i3 = 0;
                for (int i4 = 0; i4 < iWe; i4++) {
                    int iP8 = this.f80v5.P8(this.f80v5.Zo(i, i4));
                    if (iP8 == 75) {
                        i2 = 896;
                    } else if (iP8 == 86) {
                        i2 = 64;
                    } else if (iP8 == 104) {
                        i2 = 2048;
                    } else if (iP8 == 115) {
                        i2 = 536870912;
                    } else if (iP8 == 83) {
                        i2 = 524288;
                    } else if (iP8 == 84) {
                        i2 = 1;
                    } else if (iP8 == 94) {
                        i2 = 4;
                    } else if (iP8 == 95) {
                        i2 = 16384;
                    } else if (iP8 == 97) {
                        i2 = 8192;
                    } else if (iP8 == 98) {
                        i2 = 1024;
                    } else if (iP8 != 100) {
                        i2 = iP8 != 101 ? 0 : 4096;
                    } else {
                        i2 = 8;
                    }
                    i3 |= i2;
                }
                return i3;
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 1573813511687610579L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -2460669699637781760L)
        private void m119VH(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-472064890402959308L, this, uaVar, new Integer(i));
                }
                int iP8 = this.f80v5.P8(i);
                if (iP8 != 120) {
                    if (iP8 != 121) {
                        int i2 = 0;
                        if (iP8 != 123 && iP8 != 124) {
                            if (iP8 == 133) {
                                this.f76FH.m174j6();
                                int iWe = this.f80v5.we(i);
                                while (i2 < iWe) {
                                    m119VH(uaVar, this.f80v5.Zo(i, i2));
                                    i2++;
                                }
                                this.f76FH.m182u7();
                                return;
                            }
                            if (iP8 == 177) {
                                m136j6(i, uaVar);
                                return;
                            }
                            if (iP8 != 227) {
                                if (iP8 != 228) {
                                    switch (iP8) {
                                        case 126:
                                        case 127:
                                            break;
                                        case 128:
                                            break;
                                        case 129:
                                            break;
                                        default:
                                            switch (iP8) {
                                                case 220:
                                                case 221:
                                                case 222:
                                                    m144u7(uaVar, i);
                                                    return;
                                                case 223:
                                                    m108Hw(this.f80v5.Zo(i, 0));
                                                    int iWe2 = this.f80v5.we(i);
                                                    for (int i3 = 1; i3 < iWe2; i3++) {
                                                        m147vy(this.f80v5.Zo(i, i3));
                                                    }
                                                    m105FH(i);
                                                    for (int i4 = 1; i4 < iWe2; i4++) {
                                                        int iZo = this.f80v5.Zo(i, i4);
                                                        if (this.f80v5.P8(iZo) == 120 || this.f80v5.P8(iZo) == 220 || this.f80v5.P8(iZo) == 121) {
                                                            m119VH(uaVar, this.f80v5.Zo(i, i4));
                                                        }
                                                    }
                                                    return;
                                                default:
                                                    int iWe3 = this.f80v5.we(i);
                                                    while (i2 < iWe3) {
                                                        m119VH(uaVar, this.f80v5.Zo(i, i2));
                                                        i2++;
                                                    }
                                                    return;
                                            }
                                    }
                                }
                            }
                        }
                        this.f76FH.m164FH();
                        int iWe4 = this.f80v5.we(i);
                        while (i2 < iWe4) {
                            m119VH(uaVar, this.f80v5.Zo(i, i2));
                            i2++;
                        }
                        this.f76FH.m184we();
                        return;
                    }
                    m142tp(uaVar, i);
                    return;
                }
                m130gn(uaVar, i);
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -472064890402959308L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        /* JADX WARN: Code duplicated, block: B:20:0x005b  */
        /* JADX WARN: Code duplicated, block: B:21:0x005e A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:22:0x0060  */
        /* JADX WARN: Code duplicated, block: B:23:0x0063 A[Catch: Throwable -> 0x011c, TryCatch #0 {Throwable -> 0x011c, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0030, B:13:0x003f, B:15:0x0043, B:17:0x0047, B:18:0x0049, B:24:0x0068, B:28:0x00a8, B:30:0x00bc, B:34:0x00e2, B:33:0x00d8, B:35:0x0104, B:23:0x0063, B:10:0x0032), top: B:44:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:26:0x00a5  */
        /* JADX WARN: Code duplicated, block: B:27:0x00a7  */
        /* JADX WARN: Code duplicated, block: B:30:0x00bc A[Catch: Throwable -> 0x011c, TryCatch #0 {Throwable -> 0x011c, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0030, B:13:0x003f, B:15:0x0043, B:17:0x0047, B:18:0x0049, B:24:0x0068, B:28:0x00a8, B:30:0x00bc, B:34:0x00e2, B:33:0x00d8, B:35:0x0104, B:23:0x0063, B:10:0x0032), top: B:44:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:32:0x00d6  */
        /* JADX WARN: Code duplicated, block: B:33:0x00d8 A[Catch: Throwable -> 0x011c, TryCatch #0 {Throwable -> 0x011c, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0030, B:13:0x003f, B:15:0x0043, B:17:0x0047, B:18:0x0049, B:24:0x0068, B:28:0x00a8, B:30:0x00bc, B:34:0x00e2, B:33:0x00d8, B:35:0x0104, B:23:0x0063, B:10:0x0032), top: B:44:0x0009 }] */
        @su(method = -708583376865541311L)
        private void m120Ws(int i) {
            int iZo;
            int iWe;
            int i2;
            boolean z;
            ua uaVarJ6;
            int i3;
            int i4;
            int iZo2;
            int i5;
            try {
                if (f75j6) {
                    wu.j6(-6303660014840131341L, this, i);
                }
                int iZo3 = this.f80v5.Zo(i, 2);
                int iM118VH = m118VH(this.f80v5.Zo(i, 0)) & (-769);
                if (this.f80v5.P8(i) != 121) {
                    i5 = this.f80v5.P8(i) == 220 ? 268435456 : 134217728;
                    if ((iM118VH & 1) == 0 && (iM118VH & 4) == 0) {
                        iM118VH |= 32;
                    }
                    int i6 = iM118VH;
                    iZo = this.f80v5.Zo(i, 3);
                    iWe = this.f80v5.we(iZo);
                    if (iWe == 0) {
                        i2 = 0;
                    } else if (iWe == 3) {
                        i2 = 1;
                    } else {
                        i2 = (iWe - 1) / 2;
                    }
                    Ba ba = this.f79Zo;
                    Da daVH = this.f80v5.VH();
                    na naVarJ8 = this.f80v5.J8();
                    int iJ8 = this.f80v5.J8(i);
                    Na naM170VH = this.f76FH.m170VH();
                    int iXL = this.f80v5.XL(iZo3);
                    if (this.f80v5.we(this.f80v5.Zo(i, 4)) + this.f80v5.we(this.f80v5.Zo(i, 5)) > 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    uaVarJ6 = ba.j6(daVH, naVarJ8, iJ8, naM170VH, i2, i6, iXL, z, false, false);
                    i3 = 1;
                    i4 = 0;
                    while (i3 < iWe) {
                        iZo2 = this.f80v5.Zo(iZo, i3);
                        int iXL2 = this.f80v5.XL(this.f80v5.Zo(iZo2, 0));
                        if (this.f80v5.we(iZo2) == 3) {
                            int iWe2 = (this.f80v5.we(iZo2) - 1) / 2;
                        }
                        this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2), uaVarJ6, i4, iXL2);
                        i3 += 2;
                        i4++;
                    }
                    m146v5(uaVarJ6, i);
                    this.f76FH.m180j6(uaVarJ6);
                    m112J8(this.f80v5.Zo(i, 6));
                    this.f76FH.m181tp();
                }
                iM118VH |= i5;
                if ((iM118VH & 1) == 0) {
                    iM118VH |= 32;
                }
                int i7 = iM118VH;
                iZo = this.f80v5.Zo(i, 3);
                iWe = this.f80v5.we(iZo);
                if (iWe == 0) {
                    i2 = 0;
                } else if (iWe == 3) {
                    i2 = 1;
                } else {
                    i2 = (iWe - 1) / 2;
                }
                Ba ba2 = this.f79Zo;
                Da daVH2 = this.f80v5.VH();
                na naVarJ9 = this.f80v5.J8();
                int iJ9 = this.f80v5.J8(i);
                Na naM170VH2 = this.f76FH.m170VH();
                int iXL3 = this.f80v5.XL(iZo3);
                if (this.f80v5.we(this.f80v5.Zo(i, 4)) + this.f80v5.we(this.f80v5.Zo(i, 5)) > 0) {
                    z = true;
                } else {
                    z = false;
                }
                uaVarJ6 = ba2.j6(daVH2, naVarJ9, iJ9, naM170VH2, i2, i7, iXL3, z, false, false);
                i3 = 1;
                i4 = 0;
                while (i3 < iWe) {
                    iZo2 = this.f80v5.Zo(iZo, i3);
                    int iXL4 = this.f80v5.XL(this.f80v5.Zo(iZo2, 0));
                    if (this.f80v5.we(iZo2) == 3) {
                        int iWe3 = (this.f80v5.we(iZo2) - 1) / 2;
                    }
                    this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2), uaVarJ6, i4, iXL4);
                    i3 += 2;
                    i4++;
                }
                m146v5(uaVarJ6, i);
                this.f76FH.m180j6(uaVarJ6);
                m112J8(this.f80v5.Zo(i, 6));
                this.f76FH.m181tp();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -6303660014840131341L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -188545822526362160L)
        private void m121XL(int i) {
            try {
                if (f75j6) {
                    wu.j6(399545536886047680L, this, i);
                }
                int iM118VH = m118VH(this.f80v5.Zo(i, 0)) & (-129);
                if (this.f76FH.m183v5().g3()) {
                    iM118VH |= 577;
                }
                if ((iM118VH & 1) == 0 && (iM118VH & 4) == 0) {
                    iM118VH |= 32;
                }
                this.f76FH.m175j6(iM118VH);
                int iWe = this.f80v5.we(i);
                for (int i2 = 3; i2 < iWe; i2 += 2) {
                    int iZo = this.f80v5.Zo(i, i2);
                    boolean z = this.f80v5.we(iZo) > 2;
                    iM118VH = z ? iM118VH & (-257) : iM118VH & (-513);
                    m100DW(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo), this.f76FH.m183v5(), iM118VH, this.f80v5.XL(this.f80v5.Zo(iZo, 0)), z, false, false, false), iZo);
                    m112J8(iZo);
                }
                this.f76FH.m162EQ();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 399545536886047680L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 455733181239017136L)
        private ua m122Zo(int i) {
            try {
                if (f75j6) {
                    wu.j6(-2754335424848965248L, this, i);
                }
                int iXL = this.f80v5.XL(this.f80v5.Zo(i, 0));
                int iMax = Math.max(0, (this.f80v5.we(this.f80v5.Zo(i, 1)) - 2) / 3);
                try {
                    ua uaVarM173j6 = this.f76FH.m173j6(iXL, iMax);
                    int iWe = this.f80v5.we(i);
                    for (int i2 = 3; i2 < iWe; i2 += 3) {
                        int iXL2 = this.f80v5.XL(this.f80v5.Zo(i, i2));
                        this.f80v5.Zo(i, i2 + 1);
                        try {
                            try {
                                uaVarM173j6 = uaVarM173j6.rN() ? uaVarM173j6.DW(iXL2, true, iMax, this.f76FH.m171Zo(), this.f80v5.VH(), this.f80v5.J8()) : ((Na) uaVarM173j6).j6(this.f80v5.VH(), this.f80v5.J8(), iXL2, true, iMax, this.f76FH.m170VH());
                            } catch (gc unused) {
                                this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                                throw new jc();
                            }
                        } catch (jc unused2) {
                            this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                            throw new jc();
                        }
                    }
                    if (uaVarM173j6.rN()) {
                        return uaVarM173j6;
                    }
                    this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                    throw new jc();
                } catch (gc unused3) {
                    this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                    throw new jc();
                } catch (jc unused4) {
                    this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                    throw new jc();
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -2754335424848965248L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 1090818556278719768L)
        private void m123Zo(ua uaVar, int i) throws Throwable {
            int iBT;
            int iVy;
            int iBT2;
            int i2;
            try {
                if (f75j6) {
                    try {
                        wu.j6(-74751305308982636L, this, uaVar, new Integer(i));
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, -74751305308982636L, this, uaVar, new Integer(i));
                        }
                        throw th;
                    }
                }
                int iVy2 = this.f80v5.vy(this.f80v5.Zo(i, 4));
                int iBT3 = this.f80v5.BT(this.f80v5.Zo(i, 4));
                int iWs = this.f80v5.Ws(this.f80v5.Zo(i, 4));
                int iZo = this.f80v5.Zo(i, 0);
                int iM141tp = m141tp(iZo);
                if (iM141tp != -1) {
                    int iVy3 = this.f80v5.vy(iM141tp);
                    iBT = this.f80v5.BT(iM141tp);
                    iVy = this.f80v5.QX(iM141tp);
                    i2 = iVy3;
                    iBT2 = this.f80v5.Ws(iM141tp);
                } else {
                    int iVy4 = this.f80v5.vy(iZo);
                    iBT = this.f80v5.BT(iZo);
                    iVy = this.f80v5.vy(iZo);
                    iBT2 = this.f80v5.BT(iZo);
                    i2 = iVy4;
                }
                this.f79Zo.j6(uaVar, iVy2, iBT3, iWs, i2, iBT, iVy, iBT2, this.f80v5.sh(i) ? this.f80v5.QX(this.f80v5.j3(i)) : this.f80v5.vy(i), this.f80v5.sh(i) ? this.f80v5.Ws(this.f80v5.j3(i)) : this.f80v5.BT(i), this.f80v5.QX(i), this.f80v5.Ws(i));
            } catch (Throwable th2) {
                th = th2;
            }
        }

        @su(method = 228857100902795175L)
        private void m124a8(int i) {
            try {
                if (f75j6) {
                    wu.j6(8153173485050466709L, this, i);
                }
                m123Zo(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i), this.f76FH.m170VH(), 0, m118VH(this.f80v5.Zo(i, 0)) | 33554432, this.f80v5.XL(this.f80v5.Zo(i, 4)), 0), i);
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 8153173485050466709L, this, new Integer(i));
                }
                throw th;
            }
        }

        /* JADX WARN: Code duplicated, block: B:16:0x0052  */
        /* JADX WARN: Code duplicated, block: B:17:0x0055 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:18:0x0057  */
        /* JADX WARN: Code duplicated, block: B:19:0x005a A[Catch: Throwable -> 0x0122, TryCatch #0 {Throwable -> 0x0122, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0030, B:14:0x0041, B:20:0x005f, B:24:0x00ad, B:26:0x00c1, B:30:0x00e8, B:29:0x00de, B:31:0x010a, B:19:0x005a, B:11:0x0033), top: B:40:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:22:0x00aa  */
        /* JADX WARN: Code duplicated, block: B:23:0x00ac  */
        /* JADX WARN: Code duplicated, block: B:26:0x00c1 A[Catch: Throwable -> 0x0122, TryCatch #0 {Throwable -> 0x0122, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0030, B:14:0x0041, B:20:0x005f, B:24:0x00ad, B:26:0x00c1, B:30:0x00e8, B:29:0x00de, B:31:0x010a, B:19:0x005a, B:11:0x0033), top: B:40:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:28:0x00dc  */
        /* JADX WARN: Code duplicated, block: B:29:0x00de A[Catch: Throwable -> 0x0122, TryCatch #0 {Throwable -> 0x0122, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0030, B:14:0x0041, B:20:0x005f, B:24:0x00ad, B:26:0x00c1, B:30:0x00e8, B:29:0x00de, B:31:0x010a, B:19:0x005a, B:11:0x0033), top: B:40:0x0009 }] */
        @su(method = -3246795407365605900L)
        private void m125aM(int i) {
            int iZo;
            int iWe;
            int i2;
            boolean z;
            ua uaVarJ6;
            int i3;
            int i4;
            int iZo2;
            int i5;
            try {
                if (f75j6) {
                    wu.j6(109480057839688248L, this, i);
                }
                int iZo3 = this.f80v5.Zo(i, 2);
                int iM118VH = m118VH(this.f80v5.Zo(i, 0)) & (-769);
                if (this.f80v5.P8(i) != 129) {
                    i5 = this.f80v5.P8(i) == 222 ? 268435520 : 134217728;
                    int i6 = iM118VH;
                    iZo = this.f80v5.Zo(i, 3);
                    iWe = this.f80v5.we(iZo);
                    if (iWe == 0) {
                        i2 = 0;
                    } else if (iWe == 3) {
                        i2 = 1;
                    } else {
                        i2 = (iWe - 1) / 2;
                    }
                    Ba ba = this.f79Zo;
                    Da daVH = this.f80v5.VH();
                    na naVarJ8 = this.f80v5.J8();
                    int iJ8 = this.f80v5.J8(i);
                    Na naM170VH = this.f76FH.m170VH();
                    ua uaVarM183v5 = this.f76FH.m183v5();
                    int iXL = this.f80v5.XL(iZo3);
                    boolean zM172gn = this.f76FH.m172gn();
                    if (this.f80v5.we(this.f80v5.Zo(i, 4)) + this.f80v5.we(this.f80v5.Zo(i, 5)) > 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    uaVarJ6 = ba.j6(daVH, naVarJ8, iJ8, naM170VH, i2, uaVarM183v5, i6, iXL, zM172gn, z);
                    i3 = 1;
                    i4 = 0;
                    while (i3 < iWe) {
                        iZo2 = this.f80v5.Zo(iZo, i3);
                        int iXL2 = this.f80v5.XL(this.f80v5.Zo(iZo2, 0));
                        if (this.f80v5.we(iZo2) == 3) {
                            int iWe2 = (this.f80v5.we(iZo2) - 1) / 2;
                        }
                        this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2), uaVarJ6, i4, iXL2);
                        i3 += 2;
                        i4++;
                    }
                    m146v5(uaVarJ6, i);
                    this.f76FH.m180j6(uaVarJ6);
                    m112J8(this.f80v5.Zo(i, 6));
                    this.f76FH.m181tp();
                }
                iM118VH |= i5;
                int i7 = iM118VH;
                iZo = this.f80v5.Zo(i, 3);
                iWe = this.f80v5.we(iZo);
                if (iWe == 0) {
                    i2 = 0;
                } else if (iWe == 3) {
                    i2 = 1;
                } else {
                    i2 = (iWe - 1) / 2;
                }
                Ba ba2 = this.f79Zo;
                Da daVH2 = this.f80v5.VH();
                na naVarJ9 = this.f80v5.J8();
                int iJ9 = this.f80v5.J8(i);
                Na naM170VH2 = this.f76FH.m170VH();
                ua uaVarM183v6 = this.f76FH.m183v5();
                int iXL3 = this.f80v5.XL(iZo3);
                boolean zM172gn2 = this.f76FH.m172gn();
                if (this.f80v5.we(this.f80v5.Zo(i, 4)) + this.f80v5.we(this.f80v5.Zo(i, 5)) > 0) {
                    z = true;
                } else {
                    z = false;
                }
                uaVarJ6 = ba2.j6(daVH2, naVarJ9, iJ9, naM170VH2, i2, uaVarM183v6, i7, iXL3, zM172gn2, z);
                i3 = 1;
                i4 = 0;
                while (i3 < iWe) {
                    iZo2 = this.f80v5.Zo(iZo, i3);
                    int iXL4 = this.f80v5.XL(this.f80v5.Zo(iZo2, 0));
                    if (this.f80v5.we(iZo2) == 3) {
                        int iWe3 = (this.f80v5.we(iZo2) - 1) / 2;
                    }
                    this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2), uaVarJ6, i4, iXL4);
                    i3 += 2;
                    i4++;
                }
                m146v5(uaVarJ6, i);
                this.f76FH.m180j6(uaVarJ6);
                m112J8(this.f80v5.Zo(i, 6));
                this.f76FH.m181tp();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 109480057839688248L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -2687572438967835717L)
        private void m126ei(int i) {
            try {
                if (f75j6) {
                    wu.j6(3176811033249796257L, this, i);
                }
                ua uaVarU7 = this.f78VH.u7();
                int iWe = this.f80v5.we(i);
                ua uaVarDW = uaVarU7;
                for (int i2 = 2; i2 < iWe - 2; i2 += 2) {
                    int iXL = this.f80v5.XL(this.f80v5.Zo(i, i2));
                    try {
                        uaVarDW = uaVarDW.rN() ? uaVarDW.DW(iXL, true, 0, this.f76FH.m170VH(), this.f80v5.VH(), this.f80v5.J8()) : ((Na) uaVarDW).j6(this.f80v5.VH(), this.f80v5.J8(), iXL, true, 0, (Na) uaVarDW);
                    } catch (jc | gc unused) {
                        return;
                    }
                }
                if (uaVarDW.rN()) {
                    this.f76FH.m166FH(uaVarDW);
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 3176811033249796257L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -594676655242730580L)
        private void m127er(int i) {
            try {
                if (f75j6) {
                    wu.j6(-5673529924896062112L, this, i);
                }
                this.f76FH.m164FH();
                try {
                    Ya yaM134j6 = m134j6(m129gn(this.f80v5.Zo(i, 1)), this.f80v5.Zo(i, 2));
                    int iWe = this.f80v5.we(i);
                    for (int i2 = 3; i2 < iWe; i2 += 2) {
                        int iZo = this.f80v5.Zo(i, i2);
                        try {
                            this.f79Zo.j6(this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo)), m134j6(yaM134j6, this.f80v5.Zo(iZo, 1)));
                        } catch (jc unused) {
                        }
                        m139lg(iZo);
                    }
                } catch (jc unused2) {
                }
                this.f76FH.m184we();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -5673529924896062112L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -4749236237967165615L)
        private void m128gW(int i) {
            try {
                if (f75j6) {
                    wu.j6(3071746049294282195L, this, i);
                }
                ua uaVarU7 = this.f78VH.u7();
                int iWe = this.f80v5.we(i);
                for (int i2 = 1; i2 < iWe; i2 += 2) {
                    int iXL = this.f80v5.XL(this.f80v5.Zo(i, i2));
                    try {
                        uaVarU7 = uaVarU7.rN() ? uaVarU7.DW(iXL, true, 0, this.f76FH.m170VH(), this.f80v5.VH(), this.f80v5.J8()) : ((Na) uaVarU7).j6(this.f80v5.VH(), this.f80v5.J8(), iXL, true, 0, (Na) uaVarU7);
                    } catch (jc | gc unused) {
                        return;
                    }
                }
                if (uaVarU7.rN()) {
                    this.f76FH.m168Hw(this.f80v5.XL(this.f80v5.Zo(i, this.f80v5.we(i) - 2)), uaVarU7);
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 3071746049294282195L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -1177441604008577635L)
        private Ya m129gn(int i) {
            try {
                if (f75j6) {
                    wu.j6(47850241039732219L, this, i);
                }
                int iP8 = this.f80v5.P8(this.f80v5.Zo(i, 0));
                if (iP8 == 57) {
                    return this.f78VH.we();
                }
                if (iP8 == 60) {
                    return this.f78VH.Zo();
                }
                if (iP8 == 62) {
                    return this.f78VH.VH();
                }
                if (iP8 == 65) {
                    return this.f78VH.J8();
                }
                if (iP8 == 69) {
                    return this.f78VH.j3();
                }
                if (iP8 == 81) {
                    return this.f78VH.tp();
                }
                if (iP8 == 89) {
                    return this.f78VH.v5();
                }
                if (iP8 == 114) {
                    return this.f78VH.aM();
                }
                if (iP8 != 76) {
                    return iP8 != 77 ? m145v5(i) : this.f78VH.XL();
                }
                return this.f78VH.EQ();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 47850241039732219L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 4397411827645025401L)
        private void m130gn(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-779060889972301181L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!this.f79Zo.j6() && !uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 128) {
                            this.f76FH.m178j6(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    this.f79Zo.DW(uaVarJ6);
                    int iZo = this.f80v5.Zo(i, 4);
                    if (this.f80v5.we(iZo) == 0) {
                        try {
                            if (uaVarJ6 != this.f78VH.P8(this.f80v5.VH())) {
                                this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                            }
                        } catch (jc unused) {
                        }
                    } else {
                        try {
                            this.f79Zo.j6(uaVarJ6, m122Zo(this.f80v5.Zo(iZo, 1)));
                        } catch (jc unused2) {
                            this.f79Zo.j6(uaVarJ6);
                        }
                    }
                    int iZo2 = this.f80v5.Zo(i, 5);
                    int iWe = this.f80v5.we(iZo2);
                    for (int i2 = 1; i2 < iWe; i2 += 2) {
                        try {
                            this.f79Zo.j6(uaVarJ6, m122Zo(this.f80v5.Zo(iZo2, i2)));
                        } catch (jc unused3) {
                        }
                    }
                    this.f79Zo.FH(uaVarJ6);
                    if (this.f80v5.P8(i) == 128) {
                        this.f76FH.m178j6(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m119VH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                } catch (jc unused4) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -779060889972301181L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        /* JADX WARN: Code duplicated, block: B:15:0x004d A[Catch: Throwable -> 0x013e, TryCatch #0 {Throwable -> 0x013e, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0031, B:13:0x0041, B:15:0x004d, B:16:0x004f, B:18:0x005b, B:19:0x005d, B:21:0x0061, B:23:0x0065, B:24:0x0067, B:30:0x0086, B:34:0x00cc, B:36:0x00dd, B:40:0x0104, B:39:0x00fa, B:41:0x0126, B:29:0x0081, B:10:0x0033), top: B:50:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:18:0x005b A[Catch: Throwable -> 0x013e, TryCatch #0 {Throwable -> 0x013e, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0031, B:13:0x0041, B:15:0x004d, B:16:0x004f, B:18:0x005b, B:19:0x005d, B:21:0x0061, B:23:0x0065, B:24:0x0067, B:30:0x0086, B:34:0x00cc, B:36:0x00dd, B:40:0x0104, B:39:0x00fa, B:41:0x0126, B:29:0x0081, B:10:0x0033), top: B:50:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:26:0x0079  */
        /* JADX WARN: Code duplicated, block: B:27:0x007c A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:28:0x007e  */
        /* JADX WARN: Code duplicated, block: B:29:0x0081 A[Catch: Throwable -> 0x013e, TryCatch #0 {Throwable -> 0x013e, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0031, B:13:0x0041, B:15:0x004d, B:16:0x004f, B:18:0x005b, B:19:0x005d, B:21:0x0061, B:23:0x0065, B:24:0x0067, B:30:0x0086, B:34:0x00cc, B:36:0x00dd, B:40:0x0104, B:39:0x00fa, B:41:0x0126, B:29:0x0081, B:10:0x0033), top: B:50:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:32:0x00c9  */
        /* JADX WARN: Code duplicated, block: B:33:0x00cb  */
        /* JADX WARN: Code duplicated, block: B:36:0x00dd A[Catch: Throwable -> 0x013e, TryCatch #0 {Throwable -> 0x013e, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0031, B:13:0x0041, B:15:0x004d, B:16:0x004f, B:18:0x005b, B:19:0x005d, B:21:0x0061, B:23:0x0065, B:24:0x0067, B:30:0x0086, B:34:0x00cc, B:36:0x00dd, B:40:0x0104, B:39:0x00fa, B:41:0x0126, B:29:0x0081, B:10:0x0033), top: B:50:0x0009 }] */
        /* JADX WARN: Code duplicated, block: B:38:0x00f8  */
        /* JADX WARN: Code duplicated, block: B:39:0x00fa A[Catch: Throwable -> 0x013e, TryCatch #0 {Throwable -> 0x013e, blocks: (B:3:0x0009, B:5:0x000d, B:6:0x0010, B:9:0x0031, B:13:0x0041, B:15:0x004d, B:16:0x004f, B:18:0x005b, B:19:0x005d, B:21:0x0061, B:23:0x0065, B:24:0x0067, B:30:0x0086, B:34:0x00cc, B:36:0x00dd, B:40:0x0104, B:39:0x00fa, B:41:0x0126, B:29:0x0081, B:10:0x0033), top: B:50:0x0009 }] */
        @su(method = -446807589719369085L)
        private void m131j3(int i) {
            int iZo;
            int iWe;
            int i2;
            boolean z;
            ua uaVarJ6;
            int i3;
            int i4;
            int iZo2;
            int i5;
            try {
                if (f75j6) {
                    wu.j6(-4168303780499509755L, this, i);
                }
                int iZo3 = this.f80v5.Zo(i, 2);
                int iM118VH = m118VH(this.f80v5.Zo(i, 0)) & (-769);
                if (this.f80v5.P8(i) != 228) {
                    i5 = this.f80v5.P8(i) == 221 ? 268435520 : 134217792;
                    if (this.f76FH.m183v5().g3()) {
                        iM118VH |= 65;
                    }
                    if (this.f76FH.m183v5().vJ()) {
                        iM118VH |= 64;
                    }
                    if ((iM118VH & 1) == 0 && (iM118VH & 4) == 0) {
                        iM118VH |= 32;
                    }
                    int i6 = iM118VH;
                    iZo = this.f80v5.Zo(i, 3);
                    iWe = this.f80v5.we(iZo);
                    if (iWe == 0) {
                        i2 = 0;
                    } else if (iWe == 3) {
                        i2 = 1;
                    } else {
                        i2 = (iWe - 1) / 2;
                    }
                    Ba ba = this.f79Zo;
                    Da daVH = this.f80v5.VH();
                    na naVarJ8 = this.f80v5.J8();
                    int iJ8 = this.f80v5.J8(i);
                    Na naM170VH = this.f76FH.m170VH();
                    ua uaVarM183v5 = this.f76FH.m183v5();
                    int iXL = this.f80v5.XL(iZo3);
                    if (this.f80v5.we(this.f80v5.Zo(i, 4)) + this.f80v5.we(this.f80v5.Zo(i, 5)) > 0) {
                        z = true;
                    } else {
                        z = false;
                    }
                    uaVarJ6 = ba.j6(daVH, naVarJ8, iJ8, naM170VH, i2, uaVarM183v5, i6, iXL, z);
                    i3 = 1;
                    i4 = 0;
                    while (i3 < iWe) {
                        iZo2 = this.f80v5.Zo(iZo, i3);
                        int iXL2 = this.f80v5.XL(this.f80v5.Zo(iZo2, 0));
                        if (this.f80v5.we(iZo2) == 3) {
                            int iWe2 = (this.f80v5.we(iZo2) - 1) / 2;
                        }
                        this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2), uaVarJ6, i4, iXL2);
                        i3 += 2;
                        i4++;
                    }
                    m146v5(uaVarJ6, i);
                    this.f76FH.m180j6(uaVarJ6);
                    m112J8(this.f80v5.Zo(i, 6));
                    this.f76FH.m181tp();
                }
                iM118VH |= i5;
                if (this.f76FH.m183v5().g3()) {
                    iM118VH |= 65;
                }
                if (this.f76FH.m183v5().vJ()) {
                    iM118VH |= 64;
                }
                if ((iM118VH & 1) == 0) {
                    iM118VH |= 32;
                }
                int i7 = iM118VH;
                iZo = this.f80v5.Zo(i, 3);
                iWe = this.f80v5.we(iZo);
                if (iWe == 0) {
                    i2 = 0;
                } else if (iWe == 3) {
                    i2 = 1;
                } else {
                    i2 = (iWe - 1) / 2;
                }
                Ba ba2 = this.f79Zo;
                Da daVH2 = this.f80v5.VH();
                na naVarJ9 = this.f80v5.J8();
                int iJ9 = this.f80v5.J8(i);
                Na naM170VH2 = this.f76FH.m170VH();
                ua uaVarM183v6 = this.f76FH.m183v5();
                int iXL3 = this.f80v5.XL(iZo3);
                if (this.f80v5.we(this.f80v5.Zo(i, 4)) + this.f80v5.we(this.f80v5.Zo(i, 5)) > 0) {
                    z = true;
                } else {
                    z = false;
                }
                uaVarJ6 = ba2.j6(daVH2, naVarJ9, iJ9, naM170VH2, i2, uaVarM183v6, i7, iXL3, z);
                i3 = 1;
                i4 = 0;
                while (i3 < iWe) {
                    iZo2 = this.f80v5.Zo(iZo, i3);
                    int iXL4 = this.f80v5.XL(this.f80v5.Zo(iZo2, 0));
                    if (this.f80v5.we(iZo2) == 3) {
                        int iWe3 = (this.f80v5.we(iZo2) - 1) / 2;
                    }
                    this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2), uaVarJ6, i4, iXL4);
                    i3 += 2;
                    i4++;
                }
                m146v5(uaVarJ6, i);
                this.f76FH.m180j6(uaVarJ6);
                m112J8(this.f80v5.Zo(i, 6));
                this.f76FH.m181tp();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -4168303780499509755L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -5626788504907806715L)
        private Aa m132j6(Aa aa, int i) {
            try {
                if (f75j6) {
                    wu.j6(-812774475603598413L, this, aa, new Integer(i));
                }
                if (aa.P8()) {
                    Aa aaAj = ((Oa) aa).aj();
                    if (!aaAj.pO() && !aaAj.w9()) {
                        aa = aaAj;
                    }
                }
                int iWe = this.f80v5.we(i);
                if (iWe == 0) {
                    if (!aa.P8()) {
                        return aa;
                    }
                    ua uaVarAj = ((Oa) aa).aj();
                    return uaVarAj.jw() == 0 ? aa : uaVarAj;
                }
                if (iWe == 2) {
                    return aa;
                }
                int i2 = (iWe - 1) / 4;
                if (!aa.rN() && !aa.P8()) {
                    return aa;
                }
                ua uaVarAj2 = aa.P8() ? ((Oa) aa).aj() : (ua) aa;
                if (i2 != uaVarAj2.jw()) {
                    return aa;
                }
                Ya[] yaArr = new Ya[i2];
                int[] iArr = new int[i2];
                int i3 = 0;
                for (int i4 = 1; i4 < iWe; i4 += 4) {
                    try {
                        yaArr[i3] = m134j6(m129gn(this.f80v5.Zo(i, i4 + 1)), this.f80v5.Zo(i, i4 + 2));
                        iArr[i3] = 0;
                        int iZo = this.f80v5.Zo(i, i4);
                        if (this.f80v5.we(iZo) > 0) {
                            if (this.f80v5.we(iZo) == 1) {
                                iArr[i3] = 1;
                                yaArr[i3] = uaVarAj2.Hw(i3).sh().sh();
                            } else {
                                int iP8 = this.f80v5.P8(this.f80v5.Zo(iZo, 1));
                                if (iP8 == 78) {
                                    iArr[i3] = 3;
                                    if (uaVarAj2.Hw(i3).sh() == yaArr[i3]) {
                                        iArr[i3] = 0;
                                    }
                                } else if (iP8 == 91) {
                                    iArr[i3] = 2;
                                    if (uaVarAj2.Hw(i3).sh() == yaArr[i3]) {
                                        iArr[i3] = 1;
                                    }
                                }
                            }
                        }
                        if (!this.f78VH.FH(yaArr[i3])) {
                            return aa;
                        }
                        i3++;
                    } catch (jc unused) {
                        return aa;
                    }
                }
                return aa.rN() ? ((ua) aa).j6(yaArr, iArr) : ((Oa) aa).j6(yaArr, iArr);
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -812774475603598413L, this, aa, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -1718435109002621100L)
        private Ya m134j6(Ya ya, int i) {
            try {
                if (f75j6) {
                    wu.j6(2183856281979465240L, this, ya, new Integer(i));
                }
                int iWe = this.f80v5.we(i);
                if (iWe > 0 && this.f80v5.P8(this.f80v5.Zo(i, iWe - 1)) == 108) {
                    iWe--;
                    ya = this.f79Zo.j6(ya, 1);
                }
                for (int i2 = iWe - 2; i2 >= 0; i2 -= 3) {
                    ya = this.f79Zo.j6(ya, this.f80v5.we(this.f80v5.Zo(i, i2)) + 1);
                }
                return ya;
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 2183856281979465240L, this, ya, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -1940303976789580752L)
        private void m135j6(int i) {
            try {
                if (f75j6) {
                    wu.j6(4053177779478804068L, this, i);
                }
                int iWe = this.f80v5.we(i);
                for (int i2 = 1; i2 < iWe; i2 += 2) {
                    int iZo = this.f80v5.Zo(i, i2);
                    int iXL = this.f80v5.XL(this.f80v5.Zo(iZo, 0));
                    try {
                        this.f76FH.m177j6(iXL, this.f79Zo.FH(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo)));
                    } catch (jc unused) {
                    }
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 4053177779478804068L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -6808065289881454144L)
        private void m136j6(int i, ua uaVar) {
            try {
                if (f75j6) {
                    wu.j6(4944880074003935272L, this, new Integer(i), uaVar);
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (this.f79Zo.j6() || uaVar.DW(uaVarJ6)) {
                        m119VH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 2));
                        this.f79Zo.DW(uaVarJ6);
                        try {
                            if (this.f80v5.we(i) != 7) {
                                ua uaVarM122Zo = m122Zo(this.f80v5.Zo(i, 2));
                                if (uaVarM122Zo.g3()) {
                                    this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                                }
                                this.f79Zo.j6(uaVarJ6, uaVarM122Zo);
                            } else {
                                this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                            }
                        } catch (jc unused) {
                            this.f79Zo.j6(uaVarJ6);
                        }
                        this.f79Zo.FH(uaVarJ6);
                        this.f76FH.m180j6(uaVarJ6);
                        if (this.f80v5.we(i) == 7) {
                            m119VH(uaVar, this.f80v5.Zo(i, 0));
                        }
                        m119VH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                        this.f76FH.m181tp();
                    }
                } catch (jc unused2) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 4944880074003935272L, this, new Integer(i), uaVar);
                }
                throw th;
            }
        }

        @su(method = -1107370205580200727L)
        private void m137j6(Ia ia, int i) throws Throwable {
            int iBT;
            int iVy;
            int iBT2;
            int i2;
            try {
                if (f75j6) {
                    try {
                        wu.j6(1572368172388249223L, this, ia, new Integer(i));
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, 1572368172388249223L, this, ia, new Integer(i));
                        }
                        throw th;
                    }
                }
                int iVy2 = this.f80v5.vy(this.f80v5.Zo(i, 2));
                int iBT3 = this.f80v5.BT(this.f80v5.Zo(i, 2));
                int iWs = this.f80v5.Ws(this.f80v5.Zo(i, 2));
                int iZo = this.f80v5.Zo(i, 0);
                int iM141tp = m141tp(iZo);
                if (iM141tp != -1) {
                    int iVy3 = this.f80v5.vy(iM141tp);
                    iBT = this.f80v5.BT(iM141tp);
                    iVy = this.f80v5.QX(iM141tp);
                    i2 = iVy3;
                    iBT2 = this.f80v5.Ws(iM141tp);
                } else {
                    int iVy4 = this.f80v5.vy(iZo);
                    iBT = this.f80v5.BT(iZo);
                    iVy = this.f80v5.vy(iZo);
                    iBT2 = this.f80v5.BT(iZo);
                    i2 = iVy4;
                }
                this.f79Zo.j6(ia, iVy2, iBT3, iWs, i2, iBT, iVy, iBT2, this.f80v5.sh(i) ? this.f80v5.QX(this.f80v5.j3(i)) : this.f80v5.vy(i), this.f80v5.sh(i) ? this.f80v5.Ws(this.f80v5.j3(i)) : this.f80v5.BT(i), this.f80v5.QX(i), this.f80v5.Ws(i));
                m148we(this.f80v5.Zo(i, 1));
            } catch (Throwable th2) {
                th = th2;
            }
        }

        @su(method = 1354338174193347480L)
        private void m138j6(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-5029206147914737068L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 128) {
                            this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    if (this.f80v5.P8(i) == 128) {
                        this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m167Hw();
                    m98DW(this.f80v5.Zo(i, 3));
                    if (uaVarJ6 == uaVar) {
                        int iZo = this.f80v5.Zo(i, 3);
                        int iWe = this.f80v5.we(iZo);
                        int i2 = 1;
                        int i3 = 0;
                        while (i2 < iWe) {
                            try {
                                int iZo2 = this.f80v5.Zo(iZo, i2);
                                Pa paHw = this.f79Zo.Hw(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2));
                                int iWe2 = this.f80v5.we(iZo2);
                                for (int i4 = 2; i4 < iWe2; i4 += 2) {
                                    Pa paM129gn = m129gn(this.f80v5.Zo(iZo2, i4));
                                    if ((paM129gn.rN() || paM129gn.P8() || paM129gn.ei() || paM129gn.gW()) && (!paM129gn.ei() || paM129gn.sy() != uaVarJ6 || paM129gn.aj() < i3)) {
                                        this.f79Zo.j6(paHw, paM129gn);
                                    }
                                }
                            } catch (jc unused) {
                            }
                            i2 += 2;
                            i3++;
                        }
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m107FH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                    this.f76FH.m169J0();
                } catch (jc unused2) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -5029206147914737068L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 265246641132670208L)
        private void m139lg(int i) {
            try {
                if (f75j6) {
                    wu.j6(-713453350214033000L, this, i);
                }
                int iP8 = this.f80v5.P8(i);
                try {
                    if (iP8 != 120 && iP8 != 121) {
                        if (iP8 == 123) {
                            m140rN(i);
                            return;
                        }
                        if (iP8 == 124) {
                            m150yS(i);
                            return;
                        }
                        int i2 = 0;
                        if (iP8 == 133) {
                            this.f76FH.m174j6();
                            int iWe = this.f80v5.we(i);
                            while (i2 < iWe) {
                                m139lg(this.f80v5.Zo(i, i2));
                                i2++;
                            }
                            this.f76FH.m182u7();
                            return;
                        }
                        if (iP8 == 177) {
                            m139lg(this.f80v5.Zo(i, this.f80v5.we(i) - 2));
                            this.f76FH.m180j6(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)));
                            if (this.f80v5.we(i) == 7) {
                                m139lg(this.f80v5.Zo(i, 0));
                            }
                            m139lg(this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                            this.f76FH.m181tp();
                            return;
                        }
                        if (iP8 != 227 && iP8 != 228) {
                            if (iP8 == 245 || iP8 == 246) {
                                this.f79Zo.DW(this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i)), m134j6(m129gn(this.f80v5.Zo(i, 2)), this.f80v5.Zo(i, 3)));
                                return;
                            }
                            switch (iP8) {
                                case 126:
                                    m127er(i);
                                    return;
                                case 127:
                                    this.f76FH.m164FH();
                                    int iWe2 = this.f80v5.we(i);
                                    while (i2 < iWe2) {
                                        m139lg(this.f80v5.Zo(i, i2));
                                        i2++;
                                    }
                                    this.f76FH.m184we();
                                    return;
                                case 128:
                                case 129:
                                    break;
                                default:
                                    switch (iP8) {
                                        case 220:
                                        case 221:
                                            break;
                                        case 222:
                                            break;
                                        case 223:
                                            m108Hw(this.f80v5.Zo(i, 0));
                                            int iWe3 = this.f80v5.we(i);
                                            for (int i3 = 1; i3 < iWe3; i3++) {
                                                m147vy(this.f80v5.Zo(i, i3));
                                            }
                                            m105FH(i);
                                            for (int i4 = 1; i4 < iWe3; i4++) {
                                                int iZo = this.f80v5.Zo(i, i4);
                                                if (this.f80v5.P8(iZo) == 120 || this.f80v5.P8(iZo) == 220 || this.f80v5.P8(iZo) == 245 || this.f80v5.P8(iZo) == 121) {
                                                    m139lg(this.f80v5.Zo(i, i4));
                                                }
                                            }
                                            return;
                                        default:
                                            int iWe4 = this.f80v5.we(i);
                                            while (i2 < iWe4) {
                                                m139lg(this.f80v5.Zo(i, i2));
                                                i2++;
                                            }
                                            return;
                                    }
                                    break;
                            }
                            ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                            this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            this.f76FH.m167Hw();
                            m98DW(this.f80v5.Zo(i, 3));
                            this.f76FH.m180j6(uaVarJ6);
                            m139lg(this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                            this.f76FH.m181tp();
                            this.f76FH.m169J0();
                            return;
                        }
                    }
                    ua uaVarJ7 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    this.f76FH.m167Hw();
                    m98DW(this.f80v5.Zo(i, 3));
                    this.f76FH.m180j6(uaVarJ7);
                    m139lg(this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                    this.f76FH.m169J0();
                } catch (jc unused) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -713453350214033000L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -641454789166420063L)
        private void m140rN(int i) {
            try {
                if (f75j6) {
                    wu.j6(2262817563778248555L, this, i);
                }
                this.f76FH.m164FH();
                m135j6(this.f80v5.Zo(i, 1));
                try {
                    Ia iaDW = this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    int iZo = this.f80v5.Zo(i, 1);
                    int iWe = this.f80v5.we(iZo);
                    int i2 = 1;
                    int i3 = 0;
                    while (true) {
                        if (i2 >= iWe) {
                            break;
                        }
                        int iZo2 = this.f80v5.Zo(iZo, i2);
                        try {
                            Ja jaFH = this.f79Zo.FH(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2));
                            int iWe2 = this.f80v5.we(iZo2);
                            for (int i4 = 2; i4 < iWe2; i4 += 2) {
                                Ja jaM129gn = m129gn(this.f80v5.Zo(iZo2, i4));
                                if ((jaM129gn.rN() || jaM129gn.P8() || jaM129gn.ei() || jaM129gn.gW()) && (!jaM129gn.gW() || jaM129gn.Qq() != iaDW || jaM129gn.sy() < i3)) {
                                    this.f79Zo.j6(jaFH, jaM129gn);
                                }
                            }
                        } catch (jc unused) {
                        }
                        i2 += 2;
                        i3++;
                    }
                    int iZo3 = this.f80v5.Zo(i, 3);
                    int iWe3 = this.f80v5.we(iZo3);
                    if (iWe3 > 2) {
                        int i5 = 0;
                        for (int i6 = 1; i6 < iWe3 - 1; i6 += 2) {
                            int iZo4 = this.f80v5.Zo(iZo3, i6);
                            if (this.f80v5.P8(iZo4) != 16) {
                                try {
                                    this.f79Zo.DW(iaDW, m134j6(m134j6(m129gn(this.f80v5.Zo(iZo4, 1)), this.f80v5.Zo(iZo4, 2)), this.f80v5.Zo(iZo4, 4)), i5);
                                } catch (jc unused2) {
                                }
                                i5++;
                            }
                        }
                    }
                    int iZo5 = this.f80v5.Zo(i, 4);
                    int iWe4 = this.f80v5.we(iZo5);
                    int i7 = 0;
                    for (int i8 = 1; i8 < iWe4; i8 += 2) {
                        try {
                            Ya yaM129gn = m129gn(this.f80v5.Zo(iZo5, i8));
                            if (yaM129gn.rN() || yaM129gn.gW() || yaM129gn.ei()) {
                                this.f79Zo.j6(iaDW, yaM129gn, i7);
                            }
                        } catch (jc unused3) {
                        }
                        i7++;
                    }
                } catch (jc unused4) {
                }
                m139lg(this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                this.f76FH.m184we();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 2262817563778248555L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 2569837661060805000L)
        private int m141tp(int i) {
            try {
                if (f75j6) {
                    wu.j6(-1167353194737132720L, this, i);
                }
                int iWe = this.f80v5.we(i);
                for (int i2 = 0; i2 < iWe; i2++) {
                    int iZo = this.f80v5.Zo(i, i2);
                    int iP8 = this.f80v5.P8(iZo);
                    if (iP8 == 84 || iP8 == 94 || iP8 == 100) {
                        return iZo;
                    }
                }
                return -1;
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1167353194737132720L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -197176666088494404L)
        private void m142tp(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-860377289067633168L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!this.f79Zo.j6() && !uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 129) {
                            this.f76FH.m178j6(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    this.f79Zo.DW(uaVarJ6);
                    int iZo = this.f80v5.Zo(i, 4);
                    int iWe = this.f80v5.we(iZo);
                    if (iWe != 0) {
                        for (int i2 = 1; i2 < iWe; i2 += 2) {
                            try {
                                this.f79Zo.j6(uaVarJ6, m122Zo(this.f80v5.Zo(iZo, i2)));
                            } catch (jc unused) {
                                this.f79Zo.j6(uaVarJ6);
                            }
                        }
                    }
                    try {
                        if (uaVarJ6 != this.f78VH.P8(this.f80v5.VH())) {
                            this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                        }
                    } catch (jc unused2) {
                    }
                    this.f79Zo.FH(uaVarJ6);
                    if (this.f80v5.P8(i) == 129) {
                        this.f76FH.m178j6(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m119VH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                } catch (jc unused3) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -860377289067633168L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -712937064985149567L)
        private int m143u7(int i) {
            try {
                if (f75j6) {
                    wu.j6(1998975352385499243L, this, i);
                }
                int iWe = this.f80v5.we(i);
                int i2 = 0;
                for (int i3 = 0; i3 < iWe; i3++) {
                    int iP8 = this.f80v5.P8(this.f80v5.Zo(i, i3));
                    if (iP8 != 106) {
                        switch (iP8) {
                            case 113:
                                i2 = 5;
                                break;
                        }
                    }
                }
                return i2;
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 1998975352385499243L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 4176943353670624828L)
        private void m144u7(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-1648746106567315184L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!this.f79Zo.j6() && !uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 222) {
                            this.f76FH.m178j6(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    this.f79Zo.DW(uaVarJ6);
                    int iZo = this.f80v5.Zo(i, 4);
                    if (this.f80v5.we(iZo) == 0) {
                        try {
                            if (uaVarJ6 != this.f78VH.P8(this.f80v5.VH())) {
                                this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                            }
                        } catch (jc unused) {
                        }
                    } else {
                        try {
                            this.f79Zo.j6(uaVarJ6, m122Zo(this.f80v5.Zo(iZo, 1)));
                        } catch (jc unused2) {
                            this.f79Zo.j6(uaVarJ6);
                        }
                    }
                    int iZo2 = this.f80v5.Zo(i, 5);
                    int iWe = this.f80v5.we(iZo2);
                    for (int i2 = 1; i2 < iWe; i2 += 2) {
                        try {
                            this.f79Zo.j6(uaVarJ6, m122Zo(this.f80v5.Zo(iZo2, i2)));
                        } catch (jc unused3) {
                        }
                    }
                    this.f79Zo.FH(uaVarJ6);
                    if (this.f80v5.P8(i) == 222) {
                        this.f76FH.m178j6(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m119VH(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                } catch (jc unused4) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1648746106567315184L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 5369362125896099485L)
        private Ya m145v5(int i) {
            int i2;
            Aa aaSh;
            try {
                if (f75j6) {
                    wu.j6(804972838065738195L, this, i);
                }
                try {
                    Na naM132j6 = m132j6(this.f76FH.m163FH(this.f80v5.XL(this.f80v5.Zo(i, 0)), Math.max(0, (this.f80v5.we(this.f80v5.Zo(i, 1)) - 2) / 3)), this.f80v5.Zo(i, 1));
                    int iWe = this.f80v5.we(i);
                    Na naM132j7 = naM132j6;
                    for (int i3 = 3; i3 < iWe; i3 += 3) {
                        int iXL = this.f80v5.XL(this.f80v5.Zo(i, i3));
                        int i4 = i3 + 1;
                        int iMax = Math.max(0, (this.f80v5.we(this.f80v5.Zo(i, i4)) - 2) / 3);
                        try {
                            if (naM132j7.vy()) {
                                i2 = i4;
                                aaSh = naM132j7.j6(this.f80v5.VH(), this.f80v5.J8(), iXL, true, iMax, this.f76FH.m170VH());
                            } else {
                                i2 = i4;
                                Aa aaJ6 = ((Ya) naM132j7).j6(iXL, true, iMax, this.f76FH.m171Zo(), this.f80v5.VH(), this.f80v5.J8());
                                aaSh = (iMax == 0 && ((Ya) naM132j7).rN() && ((ua) naM132j7).jw() > 0) ? aaJ6.sh() : aaJ6;
                            }
                            naM132j7 = m132j6(aaSh, this.f80v5.Zo(i, i2));
                        } catch (gc unused) {
                            this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                            throw new jc();
                        } catch (jc unused2) {
                            this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                            throw new jc();
                        }
                    }
                    if (!naM132j7.vy()) {
                        return (Ya) naM132j7;
                    }
                    this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                    throw new jc();
                } catch (gc unused3) {
                    this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                    throw new jc();
                } catch (jc unused4) {
                    this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8());
                    throw new jc();
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 804972838065738195L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 4368630540297922353L)
        private void m146v5(ua uaVar, int i) throws Throwable {
            int iBT;
            int iVy;
            int iBT2;
            int i2;
            try {
                if (f75j6) {
                    try {
                        wu.j6(1648181664569374815L, this, uaVar, new Integer(i));
                    } catch (Throwable th) {
                        th = th;
                        if (f74DW) {
                            wu.j6(th, 1648181664569374815L, this, uaVar, new Integer(i));
                        }
                        throw th;
                    }
                }
                int iVy2 = this.f80v5.vy(this.f80v5.Zo(i, 2));
                int iBT3 = this.f80v5.BT(this.f80v5.Zo(i, 2));
                int iWs = this.f80v5.Ws(this.f80v5.Zo(i, 2));
                int iZo = this.f80v5.Zo(i, 0);
                int iM141tp = m141tp(iZo);
                if (iM141tp != -1) {
                    int iVy3 = this.f80v5.vy(iM141tp);
                    iBT = this.f80v5.BT(iM141tp);
                    iVy = this.f80v5.QX(iM141tp);
                    i2 = iVy3;
                    iBT2 = this.f80v5.Ws(iM141tp);
                } else {
                    int iVy4 = this.f80v5.vy(iZo);
                    iBT = this.f80v5.BT(iZo);
                    iVy = this.f80v5.vy(iZo);
                    iBT2 = this.f80v5.BT(iZo);
                    i2 = iVy4;
                }
                this.f79Zo.j6(uaVar, iVy2, iBT3, iWs, i2, iBT, iVy, iBT2, this.f80v5.sh(i) ? this.f80v5.QX(this.f80v5.j3(i)) : this.f80v5.vy(i), this.f80v5.sh(i) ? this.f80v5.Ws(this.f80v5.j3(i)) : this.f80v5.BT(i), this.f80v5.QX(i), this.f80v5.Ws(i));
                m110J0(this.f80v5.Zo(i, 3));
            } catch (Throwable th2) {
                th = th2;
            }
        }

        @su(method = -5007733629113112416L)
        private void m147vy(int i) {
            try {
                if (f75j6) {
                    wu.j6(5849940736645733284L, this, i);
                }
                int iP8 = this.f80v5.P8(i);
                if (iP8 == 213) {
                    m115P8(i);
                    return;
                }
                if (iP8 == 214) {
                    m126ei(i);
                } else if (iP8 == 225) {
                    m128gW(i);
                } else {
                    if (iP8 != 226) {
                        return;
                    }
                    m96BT(i);
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 5849940736645733284L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -5466988460352777501L)
        private void m148we(int i) {
            try {
                if (f75j6) {
                    wu.j6(1955628520678583697L, this, i);
                }
                int iWe = this.f80v5.we(i);
                for (int i2 = 1; i2 < iWe; i2 += 2) {
                    try {
                        int iZo = this.f80v5.Zo(i, i2);
                        this.f79Zo.j6(this.f79Zo.FH(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo)), this.f80v5.vy(iZo), this.f80v5.BT(iZo), this.f80v5.Ws(iZo));
                    } catch (jc unused) {
                    }
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 1955628520678583697L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = 1797675993496675144L)
        private void m149we(ua uaVar, int i) {
            try {
                if (f75j6) {
                    wu.j6(-424280099723261600L, this, uaVar, new Integer(i));
                }
                try {
                    ua uaVarJ6 = this.f79Zo.j6(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    if (!uaVar.DW(uaVarJ6)) {
                        if (this.f80v5.P8(i) == 222) {
                            this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                            return;
                        }
                        return;
                    }
                    if (this.f80v5.P8(i) == 222) {
                        this.f76FH.m159DW(this.f80v5.XL(this.f80v5.Zo(i, 2)), uaVarJ6);
                    }
                    this.f76FH.m167Hw();
                    m98DW(this.f80v5.Zo(i, 3));
                    if (uaVarJ6 == uaVar) {
                        int iZo = this.f80v5.Zo(i, 4);
                        if (this.f80v5.we(iZo) != 0) {
                            try {
                                this.f79Zo.j6(uaVarJ6, m129gn(this.f80v5.Zo(iZo, 1)));
                            } catch (jc unused) {
                            }
                        } else if (uaVarJ6 != this.f78VH.P8(this.f80v5.VH())) {
                            this.f79Zo.j6(uaVarJ6, this.f78VH.P8(this.f80v5.VH()));
                        }
                        int iZo2 = this.f80v5.Zo(i, 5);
                        int iWe = this.f80v5.we(iZo2);
                        for (int i2 = 1; i2 < iWe; i2 += 2) {
                            try {
                                this.f79Zo.j6(uaVarJ6, m129gn(this.f80v5.Zo(iZo2, i2)));
                            } catch (jc unused2) {
                            }
                        }
                    }
                    this.f76FH.m180j6(uaVarJ6);
                    m113J8(uaVar, this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                    this.f76FH.m181tp();
                    this.f76FH.m169J0();
                } catch (jc unused3) {
                }
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -424280099723261600L, this, uaVar, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -786167176983573600L)
        private void m150yS(int i) {
            try {
                if (f75j6) {
                    wu.j6(-7127952963498674304L, this, i);
                }
                this.f76FH.m164FH();
                m135j6(this.f80v5.Zo(i, 1));
                try {
                    Ya yaM134j6 = m134j6(m134j6(m129gn(this.f80v5.Zo(i, 2)), this.f80v5.Zo(i, 3)), this.f80v5.Zo(i, 6));
                    Ia iaDW = this.f79Zo.DW(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(i));
                    this.f79Zo.j6(iaDW, yaM134j6);
                    int iZo = this.f80v5.Zo(i, 1);
                    int iWe = this.f80v5.we(iZo);
                    int i2 = 1;
                    int i3 = 0;
                    while (i2 < iWe) {
                        int iZo2 = this.f80v5.Zo(iZo, i2);
                        try {
                            Ja jaFH = this.f79Zo.FH(this.f80v5.VH(), this.f80v5.J8(), this.f80v5.J8(iZo2));
                            int iWe2 = this.f80v5.we(iZo2);
                            for (int i4 = 2; i4 < iWe2; i4 += 2) {
                                Ja jaM129gn = m129gn(this.f80v5.Zo(iZo2, i4));
                                if ((jaM129gn.rN() || jaM129gn.P8() || jaM129gn.ei() || jaM129gn.gW()) && (!jaM129gn.gW() || jaM129gn.Qq() != iaDW || jaM129gn.sy() < i3)) {
                                    this.f79Zo.j6(jaFH, jaM129gn);
                                }
                            }
                        } catch (jc unused) {
                        }
                        i2 += 2;
                        i3++;
                    }
                    int iZo3 = this.f80v5.Zo(i, 5);
                    int iWe3 = this.f80v5.we(iZo3);
                    if (iWe3 > 2) {
                        int i5 = 0;
                        for (int i6 = 1; i6 < iWe3 - 1; i6 += 2) {
                            int iZo4 = this.f80v5.Zo(iZo3, i6);
                            if (this.f80v5.P8(iZo4) != 16) {
                                try {
                                    this.f79Zo.DW(iaDW, m134j6(m134j6(m129gn(this.f80v5.Zo(iZo4, 1)), this.f80v5.Zo(iZo4, 2)), this.f80v5.Zo(iZo4, 4)), i5);
                                } catch (jc unused2) {
                                }
                                i5++;
                            }
                        }
                    }
                    int iZo5 = this.f80v5.Zo(i, 7);
                    int iWe4 = this.f80v5.we(iZo5);
                    int i7 = 0;
                    for (int i8 = 1; i8 < iWe4; i8 += 2) {
                        try {
                            Ya yaM129gn = m129gn(this.f80v5.Zo(iZo5, i8));
                            if (yaM129gn.rN() || yaM129gn.gW() || yaM129gn.ei()) {
                                this.f79Zo.j6(iaDW, yaM129gn, i7);
                            }
                        } catch (jc unused3) {
                        }
                        i7++;
                    }
                } catch (jc unused4) {
                }
                m139lg(this.f80v5.Zo(i, this.f80v5.we(i) - 1));
                this.f76FH.m184we();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -7127952963498674304L, this, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -2251432763554434361L)
        public void m151DW(Ba ba, Hd hd, Sa sa) {
            try {
                if (f75j6) {
                    wu.j6(-684058785770853203L, this, ba, hd, sa);
                }
                this.f79Zo = ba;
                this.f78VH = hd;
                this.f80v5 = sa;
                this.f76FH.m158DW();
                if (!sa.j3()) {
                    m139lg(sa.aM());
                }
                this.f80v5 = null;
                this.f76FH.m158DW();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -684058785770853203L, this, ba, hd, sa);
                }
                throw th;
            }
        }

        @su(method = -7579246400169885045L)
        public void m152DW(Ba ba, Hd hd, ua uaVar, Sa sa) {
            try {
                if (f75j6) {
                    wu.j6(5034023988659469873L, this, ba, hd, uaVar, sa);
                }
                this.f79Zo = ba;
                this.f80v5 = sa;
                this.f78VH = hd;
                this.f76FH.m158DW();
                if (sa.aM() != -1) {
                    m119VH(uaVar, sa.aM());
                }
                this.f80v5 = null;
                this.f76FH.m158DW();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 5034023988659469873L, this, ba, hd, uaVar, sa);
                }
                throw th;
            }
        }

        @su(method = 1032972464535263593L)
        public void m153FH(Ba ba, Hd hd, ua uaVar, Sa sa) {
            try {
                if (f75j6) {
                    wu.j6(-1085234276896454097L, this, ba, hd, uaVar, sa);
                }
                this.f79Zo = ba;
                this.f80v5 = sa;
                this.f78VH = hd;
                this.f76FH.m158DW();
                m113J8(uaVar, sa.aM());
                this.f80v5 = null;
                this.f76FH.m158DW();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1085234276896454097L, this, ba, hd, uaVar, sa);
                }
                throw th;
            }
        }

        @su(method = 1487780448067540809L)
        protected void m154j6(Ba ba, Hd hd, Sa sa) {
            try {
                if (f75j6) {
                    wu.j6(4386492536778310983L, this, ba, hd, sa);
                }
                this.f79Zo = ba;
                this.f80v5 = sa;
                this.f78VH = hd;
                this.f76FH.m158DW();
                if (!sa.j3()) {
                    m112J8(sa.aM());
                }
                this.f80v5 = null;
                this.f76FH.m158DW();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 4386492536778310983L, this, ba, hd, sa);
                }
                throw th;
            }
        }

        @su(method = 829797919211474080L)
        public void m155j6(Ba ba, Hd hd, ua uaVar, Sa sa) {
            try {
                if (f75j6) {
                    wu.j6(-1177701099137549772L, this, ba, hd, uaVar, sa);
                }
                this.f79Zo = ba;
                this.f80v5 = sa;
                this.f78VH = hd;
                this.f76FH.m158DW();
                if (!sa.j3()) {
                    m107FH(uaVar, sa.aM());
                }
                this.f80v5 = null;
                this.f76FH.m158DW();
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, -1177701099137549772L, this, ba, hd, uaVar, sa);
                }
                throw th;
            }
        }

        @su(method = -1787677810218567057L)
        protected void m156j6(Ba ba, Sa sa) {
            try {
                if (f75j6) {
                    wu.j6(2326563601193078317L, this, ba, sa);
                }
                this.f79Zo = ba;
                this.f80v5 = sa;
                m102EQ(sa.aM());
                this.f80v5 = null;
            } catch (Throwable th) {
                if (f74DW) {
                    wu.j6(th, 2326563601193078317L, this, ba, sa);
                }
                throw th;
            }
        }
    }

    static {
        try {
            wu.j6(C0003Ed.class, -44742421209227520L, -44742421209227520L);
            if (f62Hw) {
                wu.j6(842171544878327776L, (Object) null);
            }
            f63j6 = new CRC32();
            f60DW = new byte[1024];
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 842171544878327776L, (Object) null);
            }
            throw th;
        }
    }

    public C0003Ed(La la, yd ydVar) {
        try {
            if (f62Hw) {
                wu.j6(56891630768605137L, (Object) null, la, ydVar);
            }
            this.f67J8 = new Stack<>();
            this.f69Zo = la;
            this.f73we = la.a8;
            this.f70gn = la.Mr;
            this.f72u7 = la.j3;
            this.f71tp = la.U2;
            this.f65EQ = ydVar.FH();
            this.f68VH = ydVar.Hw();
            this.f66J0 = ydVar;
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 56891630768605137L, (Object) null, la, ydVar);
            }
            throw th;
        }
    }

    @su(method = 2685905680251000941L)
    private static void m74DW() {
        try {
            if (f62Hw) {
                wu.j6(843551488984873900L, (Object) null);
            }
            f63j6.update(f60DW, 0, f61FH);
            f61FH = 0;
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 843551488984873900L, (Object) null);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:29:0x0048 A[Catch: Throwable -> 0x008f, TryCatch #0 {Throwable -> 0x008f, blocks: (B:2:0x0000, B:4:0x0004, B:5:0x0011, B:30:0x007e, B:32:0x0084, B:26:0x003f, B:27:0x0043, B:29:0x0048), top: B:42:0x0000 }] */
    @su(method = -267454393895411069L)
    private void m75DW(Sa sa, int i) {
        try {
            if (f62Hw) {
                wu.j6(-1911518324843404464L, this, sa, new Integer(i));
            }
            int iP8 = sa.P8(i);
            if (iP8 == 120 || iP8 == 121) {
                m77FH(sa, sa.Zo(i, 0));
                m77FH(sa, sa.Zo(i, 1));
                m77FH(sa, sa.Zo(i, 2));
                m77FH(sa, sa.Zo(i, 3));
                m77FH(sa, sa.Zo(i, 4));
                m77FH(sa, sa.Zo(i, 5));
                m80j6(sa.J8(i));
            } else {
                if (iP8 == 133) {
                    return;
                }
                if (iP8 == 224) {
                    m77FH(sa, i);
                } else if (iP8 == 220 || iP8 == 221 || iP8 == 227 || iP8 == 228) {
                    m77FH(sa, sa.Zo(i, 0));
                    m77FH(sa, sa.Zo(i, 1));
                    m77FH(sa, sa.Zo(i, 2));
                    m77FH(sa, sa.Zo(i, 3));
                    m77FH(sa, sa.Zo(i, 4));
                    m77FH(sa, sa.Zo(i, 5));
                    m80j6(sa.J8(i));
                } else if (iP8 == 245 || iP8 == 246) {
                    m77FH(sa, i);
                }
            }
            int iWe = sa.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m75DW(sa, sa.Zo(i, i2));
            }
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -1911518324843404464L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -2145134705998607739L)
    private long m76FH() {
        try {
            if (f62Hw) {
                wu.j6(-2171154221229601664L, this);
            }
            m74DW();
            return f63j6.getValue();
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -2171154221229601664L, this);
            }
            throw th;
        }
    }

    @su(method = 980174154058728784L)
    private void m77FH(Sa sa, int i) {
        try {
            if (f62Hw) {
                wu.j6(2686635156343683083L, this, sa, new Integer(i));
            }
            m80j6(sa.we(i));
            m80j6(sa.P8(i));
            switch (sa.P8(i)) {
                case 1:
                    m80j6(sa.XL(i));
                    break;
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    int iA8 = sa.a8(i);
                    int iU2 = sa.U2(i);
                    char[] cArrMr = sa.Mr(i);
                    int i2 = iA8;
                    int i3 = 0;
                    int i4 = 0;
                    while (i3 < iU2) {
                        i4 = (i4 * 31) + cArrMr[i2];
                        i3++;
                        i2++;
                    }
                    m80j6(i4);
                    break;
            }
            int iWe = sa.we(i);
            for (int i5 = 0; i5 < iWe; i5++) {
                m77FH(sa, sa.Zo(i, i5));
            }
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 2686635156343683083L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -1356369473049388165L)
    private a m78Hw() {
        try {
            if (f62Hw) {
                wu.j6(-2576369147761420224L, this);
            }
            return this.f67J8.empty() ? new a(this, this.f73we) : this.f67J8.pop();
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -2576369147761420224L, this);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:45:0x010a A[Catch: Throwable -> 0x013c, FALL_THROUGH, TRY_LEAVE, TryCatch #0 {Throwable -> 0x013c, blocks: (B:2:0x0000, B:4:0x0004, B:5:0x0011, B:7:0x0019, B:8:0x0023, B:30:0x0058, B:31:0x005b, B:32:0x005e, B:34:0x0063, B:35:0x0068, B:36:0x006d, B:37:0x0072, B:38:0x0077, B:39:0x0083, B:40:0x008c, B:42:0x0093, B:43:0x009d, B:44:0x00df, B:45:0x010a), top: B:54:0x0000 }] */
    @su(method = -4121390872480991995L)
    private void m79Hw(Sa sa, int i) {
        try {
            if (f62Hw) {
                wu.j6(-1080013719948408336L, this, sa, new Integer(i));
            }
            int iWe = sa.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m79Hw(sa, sa.Zo(i, i2));
            }
            int iP8 = sa.P8(i);
            if (iP8 != 120 && iP8 != 121) {
                if (iP8 == 123) {
                    m77FH(sa, sa.Zo(i, 0));
                    m77FH(sa, sa.Zo(i, 1));
                    m77FH(sa, sa.Zo(i, 2));
                    m77FH(sa, sa.Zo(i, 3));
                    m77FH(sa, sa.Zo(i, 4));
                    m80j6(sa.J8(i));
                    return;
                }
                if (iP8 == 124) {
                    m77FH(sa, sa.Zo(i, 0));
                    m77FH(sa, sa.Zo(i, 1));
                    m77FH(sa, sa.Zo(i, 2));
                    m77FH(sa, sa.Zo(i, 3));
                    m77FH(sa, sa.Zo(i, 4));
                    m77FH(sa, sa.Zo(i, 5));
                    m77FH(sa, sa.Zo(i, 6));
                    m77FH(sa, sa.Zo(i, 7));
                    m80j6(sa.J8(i));
                    return;
                }
                if (iP8 == 177) {
                    for (int i3 = 0; i3 < sa.we(i) - 2; i3++) {
                        m77FH(sa, sa.Zo(i, i3));
                    }
                    return;
                }
                if (iP8 == 194) {
                    m80j6(sa.J8(i));
                    return;
                }
                if (iP8 == 208) {
                    m77FH(sa, i);
                    m80j6(sa.J8(i));
                    return;
                }
                if (iP8 != 213 && iP8 != 214) {
                    if (iP8 == 245 || iP8 == 246) {
                        m77FH(sa, i);
                        return;
                    }
                    switch (iP8) {
                        case 126:
                            m77FH(sa, i);
                            return;
                        case 127:
                            m80j6(1);
                            return;
                        default:
                            switch (iP8) {
                                default:
                                    switch (iP8) {
                                        case 224:
                                        case 225:
                                        case 226:
                                            break;
                                        case 227:
                                        case 228:
                                            break;
                                        default:
                                            return;
                                    }
                                case 220:
                                case 221:
                                case 222:
                                    m77FH(sa, sa.Zo(i, 0));
                                    m77FH(sa, sa.Zo(i, 1));
                                    m77FH(sa, sa.Zo(i, 2));
                                    m77FH(sa, sa.Zo(i, 3));
                                    m77FH(sa, sa.Zo(i, 4));
                                    m77FH(sa, sa.Zo(i, 5));
                                    m80j6(sa.J8(i));
                            }
                        case 128:
                        case 129:
                            m77FH(sa, sa.Zo(i, 0));
                            m77FH(sa, sa.Zo(i, 1));
                            m77FH(sa, sa.Zo(i, 2));
                            m77FH(sa, sa.Zo(i, 3));
                            m77FH(sa, sa.Zo(i, 4));
                            m77FH(sa, sa.Zo(i, 5));
                            m80j6(sa.J8(i));
                    }
                }
                m77FH(sa, i);
                return;
            }
            m77FH(sa, sa.Zo(i, 0));
            m77FH(sa, sa.Zo(i, 1));
            m77FH(sa, sa.Zo(i, 2));
            m77FH(sa, sa.Zo(i, 3));
            m77FH(sa, sa.Zo(i, 4));
            m77FH(sa, sa.Zo(i, 5));
            m80j6(sa.J8(i));
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -1080013719948408336L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -3556833240754319617L)
    private static void m80j6(int i) {
        try {
            if (f62Hw) {
                wu.j6(-1434048426280991056L, (Object) null, i);
            }
            if (f61FH + 4 > f60DW.length) {
                m74DW();
            }
            byte[] bArr = f60DW;
            int i2 = f61FH;
            f61FH = i2 + 1;
            bArr[i2] = (byte) (i & 255);
            byte[] bArr2 = f60DW;
            int i3 = f61FH;
            f61FH = i3 + 1;
            bArr2[i3] = (byte) ((i >> 8) & 255);
            byte[] bArr3 = f60DW;
            int i4 = f61FH;
            f61FH = i4 + 1;
            bArr3[i4] = (byte) ((i >> 16) & 255);
            byte[] bArr4 = f60DW;
            int i5 = f61FH;
            f61FH = i5 + 1;
            bArr4[i5] = (byte) ((i >> 24) & 255);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -1434048426280991056L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 899126569392754068L)
    private void m81j6(a aVar) {
        try {
            if (f62Hw) {
                wu.j6(2739063344457800115L, this, aVar);
            }
            this.f67J8.push(aVar);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 2739063344457800115L, this, aVar);
            }
            throw th;
        }
    }

    @su(method = -330686844717815760L)
    private boolean m82j6(Sa sa, int i) {
        try {
            if (f62Hw) {
                wu.j6(-711620779735990305L, this, sa, new Integer(i));
            }
            int iP8 = sa.P8(sa.er(sa.er(sa.er(i))));
            if (iP8 != 121 && iP8 != 228) {
                int iWe = sa.we(i);
                for (int i2 = 0; i2 < iWe; i2++) {
                    if (sa.P8(sa.Zo(i, i2)) == 94) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -711620779735990305L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -2863733226073055525L)
    private static void m83v5() {
        try {
            if (f62Hw) {
                wu.j6(-3763851575571445280L, (Object) null);
            }
            f63j6.reset();
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -3763851575571445280L, (Object) null);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:32:0x0055 A[Catch: Throwable -> 0x016b, TryCatch #0 {Throwable -> 0x016b, blocks: (B:2:0x0000, B:4:0x0004, B:5:0x0011, B:29:0x004b, B:48:0x015a, B:50:0x0160, B:31:0x0050, B:32:0x0055, B:34:0x005f, B:36:0x0093, B:38:0x0099, B:40:0x00a3, B:41:0x00af, B:43:0x00b9, B:44:0x00fb, B:46:0x0105, B:47:0x0129), top: B:60:0x0000 }] */
    /* JADX WARN: Code duplicated, block: B:34:0x005f A[Catch: Throwable -> 0x016b, TryCatch #0 {Throwable -> 0x016b, blocks: (B:2:0x0000, B:4:0x0004, B:5:0x0011, B:29:0x004b, B:48:0x015a, B:50:0x0160, B:31:0x0050, B:32:0x0055, B:34:0x005f, B:36:0x0093, B:38:0x0099, B:40:0x00a3, B:41:0x00af, B:43:0x00b9, B:44:0x00fb, B:46:0x0105, B:47:0x0129), top: B:60:0x0000 }] */
    /* JADX WARN: Code duplicated, block: B:35:0x0092 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:36:0x0093 A[Catch: Throwable -> 0x016b, TryCatch #0 {Throwable -> 0x016b, blocks: (B:2:0x0000, B:4:0x0004, B:5:0x0011, B:29:0x004b, B:48:0x015a, B:50:0x0160, B:31:0x0050, B:32:0x0055, B:34:0x005f, B:36:0x0093, B:38:0x0099, B:40:0x00a3, B:41:0x00af, B:43:0x00b9, B:44:0x00fb, B:46:0x0105, B:47:0x0129), top: B:60:0x0000 }] */
    /* JADX WARN: Code duplicated, block: B:47:0x0129 A[Catch: Throwable -> 0x016b, TryCatch #0 {Throwable -> 0x016b, blocks: (B:2:0x0000, B:4:0x0004, B:5:0x0011, B:29:0x004b, B:48:0x015a, B:50:0x0160, B:31:0x0050, B:32:0x0055, B:34:0x005f, B:36:0x0093, B:38:0x0099, B:40:0x00a3, B:41:0x00af, B:43:0x00b9, B:44:0x00fb, B:46:0x0105, B:47:0x0129), top: B:60:0x0000 }] */
    @su(method = 660680414789091496L)
    private void m84v5(Sa sa, int i) {
        try {
            if (f62Hw) {
                wu.j6(-4379502112731540091L, this, sa, new Integer(i));
            }
            int iP8 = sa.P8(i);
            if (iP8 == 120 || iP8 == 121) {
                m77FH(sa, sa.Zo(i, 0));
                m77FH(sa, sa.Zo(i, 1));
                m77FH(sa, sa.Zo(i, 2));
                m77FH(sa, sa.Zo(i, 3));
                m77FH(sa, sa.Zo(i, 4));
                m77FH(sa, sa.Zo(i, 5));
                m80j6(sa.J8(i));
            } else if (iP8 != 123) {
                if (iP8 != 124) {
                    if (iP8 != 126) {
                        if (iP8 == 133) {
                            return;
                        }
                        if (iP8 == 213 || iP8 == 214) {
                            m77FH(sa, i);
                        } else if (iP8 == 220) {
                            m77FH(sa, sa.Zo(i, 0));
                            m77FH(sa, sa.Zo(i, 1));
                            m77FH(sa, sa.Zo(i, 2));
                            m77FH(sa, sa.Zo(i, 3));
                            m77FH(sa, sa.Zo(i, 4));
                            m77FH(sa, sa.Zo(i, 5));
                            m80j6(sa.J8(i));
                        } else if (iP8 == 221) {
                            if (!m82j6(sa, sa.Zo(i, 0))) {
                                return;
                            }
                            m77FH(sa, sa.Zo(i, 0));
                            m77FH(sa, sa.Zo(i, 1));
                            m77FH(sa, sa.Zo(i, 2));
                            m77FH(sa, sa.Zo(i, 3));
                            m77FH(sa, sa.Zo(i, 4));
                            m77FH(sa, sa.Zo(i, 5));
                            m80j6(sa.J8(i));
                        } else if (iP8 != 245 && iP8 != 246) {
                            switch (iP8) {
                                case 224:
                                case 225:
                                case 226:
                                    m77FH(sa, i);
                                    break;
                                case 227:
                                case 228:
                                    if (!m82j6(sa, sa.Zo(i, 0))) {
                                        return;
                                    }
                                    m77FH(sa, sa.Zo(i, 0));
                                    m77FH(sa, sa.Zo(i, 1));
                                    m77FH(sa, sa.Zo(i, 2));
                                    m77FH(sa, sa.Zo(i, 3));
                                    m77FH(sa, sa.Zo(i, 4));
                                    m77FH(sa, sa.Zo(i, 5));
                                    m80j6(sa.J8(i));
                                    break;
                            }
                        } else {
                            m77FH(sa, i);
                        }
                    } else if (!m82j6(sa, sa.Zo(i, 0))) {
                        m77FH(sa, i);
                        m80j6(sa.J8(i));
                    }
                } else if (!m82j6(sa, sa.Zo(i, 0))) {
                    m77FH(sa, sa.Zo(i, 0));
                    m77FH(sa, sa.Zo(i, 1));
                    m77FH(sa, sa.Zo(i, 2));
                    m77FH(sa, sa.Zo(i, 3));
                    m77FH(sa, sa.Zo(i, 4));
                    m77FH(sa, sa.Zo(i, 5));
                    m77FH(sa, sa.Zo(i, 6));
                    m77FH(sa, sa.Zo(i, 7));
                    m80j6(sa.J8(i));
                }
            } else if (!m82j6(sa, sa.Zo(i, 0))) {
                m77FH(sa, sa.Zo(i, 0));
                m77FH(sa, sa.Zo(i, 2));
                m77FH(sa, sa.Zo(i, 3));
                m77FH(sa, sa.Zo(i, 4));
                m80j6(sa.J8(i));
            }
            int iWe = sa.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m84v5(sa, sa.Zo(i, i2));
            }
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -4379502112731540091L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    public long mo70DW(Sa sa) {
        try {
            if (f62Hw) {
                wu.j6(-6547349728265042763L, this, sa);
            }
            m83v5();
            m79Hw(sa, sa.aM());
            return m76FH();
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -6547349728265042763L, this, sa);
            }
            throw th;
        }
    }

    public void m85DW(Da da) {
        try {
            if (f62Hw) {
                wu.j6(-1744781023444055513L, this, da);
            }
            Sa saJ6 = this.f71tp.j6(da, this.f66J0);
            a aVarM78Hw = m78Hw();
            aVarM78Hw.m154j6(this.f73we, this.f65EQ, saJ6);
            m81j6(aVarM78Hw);
            this.f71tp.j6(saJ6);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -1744781023444055513L, this, da);
            }
            throw th;
        }
    }

    public void m86DW(ua uaVar) {
        try {
            if (f62Hw) {
                wu.j6(4653424439260335725L, this, uaVar);
            }
            this.f73we.DW(uaVar);
            try {
                if (uaVar != this.f65EQ.P8(uaVar.Zo())) {
                    this.f73we.j6(uaVar, this.f65EQ.P8(uaVar.Zo()));
                }
            } catch (jc unused) {
            }
            this.f73we.FH(uaVar);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 4653424439260335725L, this, uaVar);
            }
            throw th;
        }
    }

    public void m87FH(Da da) {
        try {
            if (f62Hw) {
                wu.j6(-3593085983955051888L, this, da);
            }
            Sa saDW = this.f71tp.DW(da, this.f66J0);
            a aVarM78Hw = m78Hw();
            aVarM78Hw.m156j6(this.f73we, saDW);
            m81j6(aVarM78Hw);
            this.f71tp.j6(saDW);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -3593085983955051888L, this, da);
            }
            throw th;
        }
    }

    public void m88FH(Sa sa) {
        try {
            if (f62Hw) {
                wu.j6(4647448810390954624L, this, sa);
            }
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 4647448810390954624L, this, sa);
            }
            throw th;
        }
    }

    public void m89FH(ua uaVar) {
        try {
            if (f62Hw) {
                wu.j6(-683810120140564024L, this, uaVar);
            }
            Sa saDW = this.f71tp.DW(uaVar.Zo(), this.f66J0);
            a aVarM78Hw = m78Hw();
            aVarM78Hw.m153FH(this.f73we, this.f65EQ, uaVar, saDW);
            m81j6(aVarM78Hw);
            this.f71tp.j6(saDW);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -683810120140564024L, this, uaVar);
            }
            throw th;
        }
    }

    public long mo71Hw(Sa sa) {
        try {
            if (f62Hw) {
                wu.j6(23406198400240465L, this, sa);
            }
            m83v5();
            m75DW(sa, sa.aM());
            return m76FH();
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 23406198400240465L, this, sa);
            }
            throw th;
        }
    }

    public void mo72Hw(Da da) {
        try {
            if (f62Hw) {
                wu.j6(-607707095180050892L, this, da);
            }
            if (this.f73we.j6(da, this.f66J0)) {
                m85DW(da);
            }
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -607707095180050892L, this, da);
            }
            throw th;
        }
    }

    public void m90Hw(ua uaVar) {
        try {
            if (f62Hw) {
                wu.j6(-4655051014851320217L, this, uaVar);
            }
            Sa saDW = this.f71tp.DW(uaVar.Zo(), this.f66J0);
            a aVarM78Hw = m78Hw();
            aVarM78Hw.m155j6(this.f73we, this.f65EQ, uaVar, saDW);
            m81j6(aVarM78Hw);
            this.f71tp.j6(saDW);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -4655051014851320217L, this, uaVar);
            }
            throw th;
        }
    }

    public long m91j6(Sa sa) {
        try {
            if (!f62Hw) {
                return 0L;
            }
            wu.j6(-8448603628585543683L, this, sa);
            return 0L;
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -8448603628585543683L, this, sa);
            }
            throw th;
        }
    }

    @su(method = -3356529656004999120L)
    protected void m92j6() {
        try {
            if (f62Hw) {
                wu.j6(1928514329923619277L, this);
            }
            this.f67J8 = new Stack<>();
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 1928514329923619277L, this);
            }
            throw th;
        }
    }

    public void m93j6(Da da) {
        try {
            if (f62Hw) {
                wu.j6(714235778262435451L, this, da);
            }
            Sa saDW = this.f71tp.DW(da, this.f66J0);
            a aVarM78Hw = m78Hw();
            aVarM78Hw.m151DW(this.f73we, this.f65EQ, saDW);
            m81j6(aVarM78Hw);
            this.f71tp.j6(saDW);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 714235778262435451L, this, da);
            }
            throw th;
        }
    }

    public void m94j6(Ia ia) {
        try {
            if (f62Hw) {
                wu.j6(2019061614440644596L, this, ia);
            }
            this.f68VH.j6(ia);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 2019061614440644596L, this, ia);
            }
            throw th;
        }
    }

    public void m95j6(ua uaVar) {
        try {
            if (f62Hw) {
                wu.j6(-5445695198898456624L, this, uaVar);
            }
            Sa saDW = this.f71tp.DW(uaVar.Zo(), this.f66J0);
            a aVarM78Hw = m78Hw();
            aVarM78Hw.m152DW(this.f73we, this.f65EQ, uaVar, saDW);
            m81j6(aVarM78Hw);
            this.f71tp.j6(saDW);
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, -5445695198898456624L, this, uaVar);
            }
            throw th;
        }
    }

    public long mo73v5(Sa sa) {
        try {
            if (f62Hw) {
                wu.j6(2107901572044249500L, this, sa);
            }
            m83v5();
            m84v5(sa, sa.aM());
            return m76FH();
        } catch (Throwable th) {
            if (f64v5) {
                wu.j6(th, 2107901572044249500L, this, sa);
            }
            throw th;
        }
    }
}
