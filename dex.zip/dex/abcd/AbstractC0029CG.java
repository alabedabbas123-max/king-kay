package abcd;

import java.security.MessageDigest;
import java.util.zip.Inflater;

abstract class AbstractC0029CG {

    protected final long f94DW;

    protected final long f95FH;

    protected final aH f96j6;

    protected AbstractC0029CG(aH aHVar, long j, int i) {
        this.f96j6 = aHVar;
        this.f94DW = j;
        this.f95FH = this.f94DW + ((long) i);
    }

    final int m130j6() {
        return (int) (this.f95FH - this.f94DW);
    }

    protected abstract int m131j6(int i, Inflater inflater);

    protected abstract int m132j6(int i, byte[] bArr, int i2, int i3);

    final int m133j6(long j, Inflater inflater) {
        return m131j6((int) (j - this.f94DW), inflater);
    }

    final int m134j6(long j, byte[] bArr, int i, int i2) {
        return m132j6((int) (j - this.f94DW), bArr, i, i2);
    }

    abstract void m135j6(OH oh, long j, int i, MessageDigest messageDigest);

    final boolean m136j6(aH aHVar, long j) {
        return this.f96j6 == aHVar && this.f94DW <= j && j < this.f95FH;
    }
}
