package abcd;

import abcd.Gp;
import java.util.Iterator;
import java.util.List;

public final class C0007Tp<T extends Gp> extends Gp {

    private final List<T> f19Zo;

    private final wp f20v5;

    public C0007Tp(wp wpVar, List<T> list) {
        super(m41j6((List<? extends Gp>) list), m39DW(list));
        if (wpVar == null) {
            throw new NullPointerException("itemType == null");
        }
        this.f19Zo = list;
        this.f20v5 = wpVar;
    }

    private static int m39DW(List<? extends Gp> list) {
        return (list.size() * list.get(0).VH()) + m41j6(list);
    }

    private int m40Mr() {
        return J8();
    }

    private static int m41j6(List<? extends Gp> list) {
        try {
            return Math.max(4, list.get(0).J8());
        } catch (IndexOutOfBoundsException unused) {
            throw new IllegalArgumentException("items.size() == 0");
        } catch (NullPointerException unused2) {
            throw new NullPointerException("items == null");
        }
    }

    protected void m42DW(Kp kp, int i) {
        int iM40Mr = i + m40Mr();
        int i2 = -1;
        boolean z = true;
        int iJ6 = iM40Mr;
        int iJ8 = -1;
        for (T t : this.f19Zo) {
            int iVH = t.VH();
            if (z) {
                iJ8 = t.J8();
                i2 = iVH;
                z = false;
            } else {
                if (iVH != i2) {
                    throw new UnsupportedOperationException("item size mismatch");
                }
                if (t.J8() != iJ8) {
                    throw new UnsupportedOperationException("item alignment mismatch");
                }
            }
            iJ6 = t.j6(kp, iJ6) + iVH;
        }
    }

    protected void m43DW(jp jpVar, Lt lt) {
        int size = this.f19Zo.size();
        if (lt.Hw()) {
            lt.j6(0, Ws() + " " + Zo());
            StringBuilder sb = new StringBuilder();
            sb.append("  size: ");
            sb.append(Yt.gn(size));
            lt.j6(4, sb.toString());
        }
        lt.writeInt(size);
        Iterator<T> it = this.f19Zo.iterator();
        while (it.hasNext()) {
            it.next().j6(jpVar, lt);
        }
    }

    public wp m44Hw() {
        return this.f20v5;
    }

    public final String m45aM() {
        StringBuffer stringBuffer = new StringBuffer(100);
        stringBuffer.append("{");
        boolean z = true;
        for (T t : this.f19Zo) {
            if (z) {
                z = false;
            } else {
                stringBuffer.append(", ");
            }
            stringBuffer.append(t.aM());
        }
        stringBuffer.append("}");
        return stringBuffer.toString();
    }

    public final List<T> m46j3() {
        return this.f19Zo;
    }

    public void m47j6(jp jpVar) {
        Iterator<T> it = this.f19Zo.iterator();
        while (it.hasNext()) {
            it.next().j6(jpVar);
        }
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer(100);
        stringBuffer.append(C0007Tp.class.getName());
        stringBuffer.append(this.f19Zo);
        return stringBuffer.toString();
    }
}
