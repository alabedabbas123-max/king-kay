package abcd;

import java.util.ArrayList;
import java.util.List;

public class C0014RA {

    private final a f93Hw;

    private final List<String> f94Zo;

    private final List<String> f95v5;

    public static final C0014RA f92j6 = new C0014RA(a.OK, null);

    public static final C0014RA f90DW = new C0014RA(a.ERROR, null);

    public static final C0014RA f91FH = new C0014RA(a.NOT_TRIED, null);

    public enum a {
        NOT_TRIED,
        OK,
        CONFLICTS,
        NONDELETED,
        ERROR;

        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            int length = aVarArrValuesCustom.length;
            a[] aVarArr = new a[length];
            System.arraycopy(aVarArrValuesCustom, 0, aVarArr, 0, length);
            return aVarArr;
        }
    }

    C0014RA(a aVar, List<String> list) {
        this.f93Hw = aVar;
        if (aVar == a.CONFLICTS) {
            this.f95v5 = list;
        } else {
            this.f95v5 = new ArrayList(0);
        }
        if (aVar == a.NONDELETED) {
            this.f94Zo = list;
        } else {
            this.f94Zo = new ArrayList(0);
        }
    }

    public a m151j6() {
        return this.f93Hw;
    }
}
