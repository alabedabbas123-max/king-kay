package abcd;

public class C0016RC extends AbstractC0109TJ {

    private final int f102EQ;

    private final byte[] f103J0;

    protected int f104J8;

    protected QC f105QX;

    private int f106Ws;

    protected C0102TC f107XL;

    private final C0102TC f108tp;

    protected final KC f109u7;

    private final int f110we;

    public C0016RC(KC kc) {
        this.f109u7 = kc;
        this.f108tp = kc.j6(true);
        this.f102EQ = 0;
        this.f110we = this.f108tp.m695DW();
        this.f103J0 = new byte[20];
        if (mo153DW()) {
            return;
        }
        m152Ws();
    }

    C0016RC(C0016RC c0016rc, C0102TC c0102tc) {
        super(c0016rc, c0016rc.f539Zo, c0016rc.f540gn + 1);
        this.f109u7 = c0016rc.f109u7;
        this.f108tp = c0102tc;
        this.f102EQ = c0016rc.f104J8;
        this.f110we = this.f102EQ + this.f108tp.m695DW();
        this.f103J0 = c0016rc.f103J0;
        this.f104J8 = c0016rc.f104J8;
        m152Ws();
    }

    private void m152Ws() {
        this.f105QX = this.f109u7.j6(this.f104J8);
        byte[] bArr = this.f105QX.Hw;
        if (this.f106Ws != this.f108tp.m698j6()) {
            C0102TC c0102tcM699j6 = this.f108tp.m699j6(this.f106Ws);
            if (c0102tcM699j6.m703j6(bArr, this.f538VH, bArr.length)) {
                this.f107XL = c0102tcM699j6;
                this.f106Ws++;
                if (c0102tcM699j6.m697Hw()) {
                    c0102tcM699j6.m696FH().DW(this.f103J0, 0);
                }
                this.f541v5 = rE.j6.DW();
                this.f539Zo = bArr;
                this.f540gn = this.f538VH + c0102tcM699j6.m704v5();
                return;
            }
        }
        this.f541v5 = this.f105QX.Zo();
        this.f539Zo = bArr;
        this.f540gn = bArr.length;
        this.f107XL = null;
    }

    @Override
    public boolean mo153DW() {
        return this.f104J8 == this.f110we;
    }

    @Override
    public void mo154EQ() {
        if (mo156FH()) {
            return;
        }
        this.f104J8 = this.f102EQ;
        if (mo153DW()) {
            return;
        }
        m152Ws();
    }

    @Override
    public void mo155FH(int i) {
        while (true) {
            i--;
            if (i < 0) {
                return;
            }
            C0102TC c0102tc = this.f107XL;
            if (c0102tc != null) {
                this.f104J8 += c0102tc.m695DW();
            } else {
                this.f104J8++;
            }
            if (mo153DW()) {
                return;
            } else {
                m152Ws();
            }
        }
    }

    @Override
    public boolean mo156FH() {
        return this.f104J8 == this.f102EQ;
    }

    public QC m157J8() {
        if (this.f107XL == null) {
            return this.f105QX;
        }
        return null;
    }

    @Override
    public boolean mo158gn() {
        C0102TC c0102tc = this.f107XL;
        if (c0102tc != null) {
            return c0102tc.m697Hw();
        }
        return this.f105QX != null;
    }

    @Override
    public AbstractC0109TJ mo159j6(IE ie) throws ZC {
        C0102TC c0102tc = this.f107XL;
        if (c0102tc != null) {
            return new C0016RC(this, c0102tc);
        }
        throw new ZC(m798v5(), "tree");
    }

    @Override
    public VJ mo160j6() {
        byte[] bArr = new byte[Math.max(this.f540gn + 1, 128)];
        System.arraycopy(this.f539Zo, 0, bArr, 0, this.f540gn);
        int i = this.f540gn;
        bArr[i] = 47;
        return new VJ(this, bArr, i + 1);
    }

    @Override
    public void mo161j6(int i) {
        while (true) {
            i--;
            if (i < 0) {
                return;
            }
            if (this.f107XL != null) {
                this.f106Ws--;
            }
            this.f104J8--;
            m152Ws();
            C0102TC c0102tc = this.f107XL;
            if (c0102tc != null) {
                this.f104J8 -= c0102tc.m695DW() - 1;
            }
        }
    }

    @Override
    public int mo162tp() {
        QC qc;
        if (this.f107XL == null && (qc = this.f105QX) != null) {
            return qc.u7();
        }
        return 0;
    }

    @Override
    public byte[] mo163u7() {
        C0102TC c0102tc = this.f107XL;
        if (c0102tc != null) {
            return c0102tc.m697Hw() ? this.f103J0 : AbstractC0109TJ.f534j6;
        }
        QC qc = this.f105QX;
        return qc != null ? qc.gn() : AbstractC0109TJ.f534j6;
    }
}
