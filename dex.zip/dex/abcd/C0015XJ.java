package abcd;

public class C0015XJ extends C0058YJ {

    private static final int f69we = rE.j6.DW();

    private boolean f70J0;

    private TJ f71J8;

    public C0015XJ(IE ie) {
        super(ie);
    }

    public C0015XJ(UE ue) {
        this(ue.j3());
    }

    private TJ m94FH(TJ tj) {
        TJ tj2 = null;
        for (TJ tj3 : this.f233v5) {
            if (tj3.FH != tj && !tj3.DW()) {
                while (true) {
                    int iJ6 = tj3.j6(tj, f69we);
                    if (iJ6 >= 0) {
                        if (iJ6 != 0) {
                            int i = tj3.Hw;
                            if (i == 0) {
                                break;
                            }
                            tj3.j6(i);
                            tj3.Hw = 0;
                            break;
                        }
                        tj3.FH = tj;
                        tj2 = tj3;
                        break;
                    }
                    tj3.Hw++;
                    tj3.FH(1);
                    if (tj3.DW()) {
                        tj3.j6(tj3.Hw);
                        tj3.Hw = 0;
                        break;
                    }
                }
            }
        }
        if (tj2 == null) {
            return tj;
        }
        for (TJ tj4 : this.f233v5) {
            if (tj4.FH == tj) {
                tj4.FH = tj2;
            }
        }
        if (this.f71J8 == null) {
            this.f71J8 = tj2;
        }
        return tj2;
    }

    private static boolean m95Hw(TJ tj) {
        return rE.j6.j6(tj.v5);
    }

    private TJ m96XL() {
        this.f70J0 = true;
        TJ tj = this.f233v5[0];
        int i = 0;
        while (tj.DW()) {
            i++;
            TJ[] tjArr = this.f233v5;
            if (i >= tjArr.length) {
                break;
            }
            tj = tjArr[i];
        }
        if (tj.DW()) {
            return tj;
        }
        tj.FH = tj;
        TJ tj2 = tj;
        boolean z = false;
        while (true) {
            i++;
            TJ[] tjArr2 = this.f233v5;
            if (i >= tjArr2.length) {
                break;
            }
            TJ tj3 = tjArr2[i];
            if (!tj3.DW()) {
                int iDW = tj3.DW(tj2);
                if (iDW < 0) {
                    if (this.f70J0 && m95Hw(tj2) && !m95Hw(tj3) && m97j6(tj2, tj3)) {
                        tj3.FH = tj2;
                        z = true;
                    } else {
                        this.f70J0 = false;
                        tj3.FH = tj3;
                        tj2 = tj3;
                    }
                } else if (iDW == 0) {
                    tj3.FH = tj2;
                } else if (this.f70J0 && m95Hw(tj3) && !m95Hw(tj2) && m97j6(tj3, tj2)) {
                    for (int i2 = 0; i2 < i; i2++) {
                        TJ tj4 = this.f233v5[i2];
                        if (tj4.FH == tj2) {
                            tj4.FH = tj3;
                        }
                    }
                    tj3.FH = tj3;
                    tj2 = tj3;
                    z = true;
                } else {
                    this.f70J0 = false;
                }
            }
        }
        if (z && this.f70J0 && this.f71J8 == null) {
            this.f71J8 = tj2;
        }
        return tj2;
    }

    private static boolean m97j6(TJ tj, TJ tj2) {
        return tj.j6(tj2, f69we) == 0;
    }

    private boolean m98v5(TJ tj) {
        for (TJ tj2 : this.f233v5) {
            if (tj2.FH != tj && !tj2.FH()) {
                int i = 0;
                do {
                    i++;
                    tj2.j6(1);
                    int iJ6 = tj2.j6(tj, 0);
                    if (iJ6 == 0) {
                        tj2.FH(i);
                        return true;
                    }
                    if (iJ6 < 0) {
                        break;
                    }
                } while (!tj2.FH());
                tj2.FH(i);
            }
        }
        return false;
    }

    public boolean m99QX() {
        return this.f71J8 != null;
    }

    @Override
    void mo100Ws() {
        TJ tj = this.f225EQ;
        int i = 0;
        while (true) {
            TJ[] tjArr = this.f233v5;
            if (i >= tjArr.length) {
                break;
            }
            TJ tj2 = tjArr[i];
            if (tj2.FH == tj) {
                int i2 = tj2.Hw;
                if (i2 == 0) {
                    tj2.we();
                } else {
                    tj2.j6(i2);
                    tj2.Hw = 0;
                }
                tj2.FH = null;
            }
            i++;
        }
        if (tj == this.f71J8) {
            this.f71J8 = null;
        }
    }

    @Override
    TJ mo101tp() {
        while (true) {
            TJ tjM96XL = m96XL();
            if (this.f70J0) {
                return tjM96XL;
            }
            if (!m95Hw(tjM96XL)) {
                return m94FH(tjM96XL);
            }
            if (!m98v5(tjM96XL)) {
                return tjM96XL;
            }
            for (TJ tj : this.f233v5) {
                if (tj.FH == tjM96XL) {
                    tj.FH(1);
                    tj.FH = null;
                }
            }
        }
    }

    @Override
    void mo102we() {
        TJ tj = this.f225EQ;
        int i = 0;
        while (true) {
            TJ[] tjArr = this.f233v5;
            if (i >= tjArr.length) {
                break;
            }
            TJ tj2 = tjArr[i];
            if (tj2.FH == tj) {
                int i2 = tj2.Hw;
                if (i2 == 0) {
                    tj2.FH(1);
                } else {
                    tj2.j6(i2);
                    tj2.Hw = 0;
                }
                tj2.FH = null;
            }
            i++;
        }
        if (tj == this.f71J8) {
            this.f71J8 = null;
        }
    }
}
