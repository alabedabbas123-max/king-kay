package abcd;

import java.util.Arrays;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0055jI {

    private final boolean f217DW;

    private final String f218j6;

    public static class a extends AbstractC0055jI {

        private char[] f219FH;

        public a(String str, boolean z) {
            super(str, z);
        }

        public void m280DW() {
            char[] cArr = this.f219FH;
            if (cArr != null) {
                Arrays.fill(cArr, (char) 0);
                this.f219FH = null;
            }
        }

        public char[] m281FH() {
            return this.f219FH;
        }

        public void m282j6(char[] cArr) {
            m280DW();
            if (cArr != null) {
                this.f219FH = new char[cArr.length];
                System.arraycopy(cArr, 0, this.f219FH, 0, cArr.length);
            }
        }
    }

    public static class b extends AbstractC0055jI {
        public b(String str) {
            super(str, false);
        }
    }

    public static class c extends a {
        public c() {
            super(JGitText.j6().credentialPassword, true);
        }

        public c(String str) {
            super(str, true);
        }
    }

    public static class d extends AbstractC0055jI {

        private String f220FH;

        public d(String str, boolean z) {
            super(str, z);
        }

        public String m283DW() {
            return this.f220FH;
        }

        public void m284j6(String str) {
            this.f220FH = str;
        }
    }

    public static class e extends d {
        public e() {
            super(JGitText.j6().credentialUsername, false);
        }
    }

    public static class f extends AbstractC0055jI {

        private boolean f221FH;

        public f(String str) {
            super(str, false);
        }

        public boolean m285DW() {
            return this.f221FH;
        }

        public void m286j6(boolean z) {
            this.f221FH = z;
        }
    }

    public AbstractC0055jI(String str, boolean z) {
        this.f218j6 = str;
        this.f217DW = z;
    }

    public String m279j6() {
        return this.f218j6;
    }
}
