package abcd;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;
import org.eclipse.jgit.JGitText;

class C0025vJ extends DJ {
    C0025vJ() {
    }

    public jJ m103DW(HJ hj, UE ue, String str) {
        return new C0110xJ(ue, hj);
    }

    public String m104DW() {
        return JGitText.j6().transportProtoFTP;
    }

    public Set<DJ.a> m105FH() {
        return Collections.unmodifiableSet(EnumSet.of(DJ.a.j6, DJ.a.DW, DJ.a.Hw));
    }

    public Set<DJ.a> m106Hw() {
        return Collections.unmodifiableSet(EnumSet.of(DJ.a.FH, DJ.a.v5));
    }

    public Set<String> m107v5() {
        return Collections.singleton("ftp");
    }
}
