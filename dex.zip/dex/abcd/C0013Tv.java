package abcd;

import java.util.zip.CRC32;

class C0013Tv extends ThreadLocal<CRC32> {
    C0013Tv() {
    }

    @Override
    public CRC32 initialValue() {
        return new CRC32();
    }
}
