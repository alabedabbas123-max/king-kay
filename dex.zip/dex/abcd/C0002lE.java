package abcd;

class C0002lE extends rE {
    C0002lE(int i, int i2) {
        super(i, i2, (rE) null);
    }

    public boolean m1j6(int i) {
        return (i & 61440) == 40960;
    }
}
