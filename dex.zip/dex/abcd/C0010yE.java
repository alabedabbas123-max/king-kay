package abcd;

import java.io.Serializable;

public class C0010yE extends YD implements Serializable {

    private static final C0010yE f14gn = new C0010yE(0, 0, 0, 0, 0);

    private static final String f15u7 = f14gn.we();

    C0010yE(int i, int i2, int i3, int i4, int i5) {
        ((YD) this).FH = i;
        ((YD) this).Hw = i2;
        ((YD) this).v5 = i3;
        ((YD) this).Zo = i4;
        ((YD) this).VH = i5;
    }

    protected C0010yE(YD yd) {
        ((YD) this).FH = yd.FH;
        ((YD) this).Hw = yd.Hw;
        ((YD) this).v5 = yd.v5;
        ((YD) this).Zo = yd.Zo;
        ((YD) this).VH = yd.VH;
    }

    public static final C0010yE m25DW(int[] iArr, int i) {
        return new C0010yE(iArr[i], iArr[i + 1], iArr[i + 2], iArr[i + 3], iArr[i + 4]);
    }

    public static final boolean m26DW(String str) {
        if (str.length() != 40) {
            return false;
        }
        for (int i = 0; i < 40; i++) {
            try {
                IK.j6((byte) str.charAt(i));
            } catch (ArrayIndexOutOfBoundsException unused) {
                return false;
            }
        }
        return true;
    }

    public static final C0010yE m27Hw(byte[] bArr, int i) {
        return new C0010yE(FK.j6(bArr, i), FK.j6(bArr, i + 4), FK.j6(bArr, i + 8), FK.j6(bArr, i + 12), FK.j6(bArr, i + 16));
    }

    public static final C0010yE m28Ws() {
        return f14gn;
    }

    private static final C0010yE m29Zo(byte[] bArr, int i) throws aD {
        try {
            return new C0010yE(IK.gn(bArr, i), IK.gn(bArr, i + 8), IK.gn(bArr, i + 16), IK.gn(bArr, i + 24), IK.gn(bArr, i + 32));
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new aD(bArr, i, 40);
        }
    }

    public static C0010yE m30j6(String str) {
        if (str.length() == 40) {
            return m29Zo(hE.DW(str), 0);
        }
        throw new IllegalArgumentException("Invalid id: " + str);
    }

    public static final C0010yE m31j6(byte[] bArr) {
        return m27Hw(bArr, 0);
    }

    public static final String m32j6(C0010yE c0010yE) {
        return c0010yE != null ? c0010yE.we() : f15u7;
    }

    public static boolean m33j6(byte[] bArr, int i, byte[] bArr2, int i2) {
        return bArr[i] == bArr2[i2] && bArr[i + 1] == bArr2[i2 + 1] && bArr[i + 2] == bArr2[i2 + 2] && bArr[i + 3] == bArr2[i2 + 3] && bArr[i + 4] == bArr2[i2 + 4] && bArr[i + 5] == bArr2[i2 + 5] && bArr[i + 6] == bArr2[i2 + 6] && bArr[i + 7] == bArr2[i2 + 7] && bArr[i + 8] == bArr2[i2 + 8] && bArr[i + 9] == bArr2[i2 + 9] && bArr[i + 10] == bArr2[i2 + 10] && bArr[i + 11] == bArr2[i2 + 11] && bArr[i + 12] == bArr2[i2 + 12] && bArr[i + 13] == bArr2[i2 + 13] && bArr[i + 14] == bArr2[i2 + 14] && bArr[i + 15] == bArr2[i2 + 15] && bArr[i + 16] == bArr2[i2 + 16] && bArr[i + 17] == bArr2[i2 + 17] && bArr[i + 18] == bArr2[i2 + 18] && bArr[i + 19] == bArr2[i2 + 19];
    }

    public static final C0010yE m34v5(byte[] bArr, int i) {
        return m29Zo(bArr, i);
    }

    public C0010yE m35J8() {
        return this;
    }
}
