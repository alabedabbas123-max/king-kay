package abcd;

public final class C0006To extends ao {

    public static final ao f18DW = new C0006To();

    private C0006To() {
    }

    public boolean m34VH(AbstractC0091Vn abstractC0091Vn) {
        return true;
    }

    public String m35Zo(AbstractC0091Vn abstractC0091Vn) {
        throw new RuntimeException("unsupported");
    }

    public int m36j6() {
        throw new RuntimeException("unsupported");
    }

    public String m37j6(AbstractC0091Vn abstractC0091Vn, boolean z) {
        throw new RuntimeException("unsupported");
    }

    public void m38j6(Lt lt, AbstractC0091Vn abstractC0091Vn) {
        throw new RuntimeException("unsupported");
    }
}
