package abcd;

import java.lang.reflect.Field;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public abstract class AbstractC0075GF {
    private Locale effectiveLocale;
    private ResourceBundle resourceBundle;

    void m689j6(Locale locale) throws xD, wD {
        Class<?> cls = getClass();
        try {
            this.resourceBundle = ResourceBundle.getBundle(cls.getName(), locale);
            this.effectiveLocale = this.resourceBundle.getLocale();
            for (Field field : cls.getFields()) {
                if (field.getType().equals(String.class)) {
                    try {
                        field.set(this, this.resourceBundle.getString(field.getName()));
                    } catch (IllegalAccessException e) {
                        throw new Error(e);
                    } catch (IllegalArgumentException e2) {
                        throw new Error(e2);
                    } catch (MissingResourceException e3) {
                        throw new xD(cls, locale, field.getName(), e3);
                    }
                }
            }
        } catch (MissingResourceException e4) {
            throw new wD(cls, locale, e4);
        }
    }
}
