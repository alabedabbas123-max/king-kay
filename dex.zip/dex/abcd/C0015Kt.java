package abcd;

import java.util.ArrayList;
import java.util.Iterator;

public class C0015Kt {

    private final boolean f85DW;

    private final Ft f86FH;

    private final yt f87j6;

    private static class a implements ot.b {

        private final ArrayList<tt> f88j6;

        public a(ArrayList<tt> arrayList) {
            this.f88j6 = arrayList;
        }

        public void m122j6(ot otVar) {
            cs csVarTp = otVar.tp();
            bs bsVarU7 = otVar.u7();
            int size = csVarTp.size();
            for (int i = 0; i < size; i++) {
                this.f88j6.get(otVar.FH(i)).DW(bsVarU7, csVarTp.get(i));
            }
        }
    }

    private C0015Kt(yt ytVar, boolean z) {
        this.f85DW = z;
        this.f87j6 = ytVar;
        this.f86FH = Ht.j6(ytVar);
    }

    private Or m113DW() {
        ArrayList<tt> arrayListDW = this.f87j6.DW();
        tt ttVarZo = this.f87j6.Zo();
        this.f87j6.j6();
        int i = 0;
        Or or = new Or(this.f87j6.FH() - ((ttVarZo == null || !ttVarZo.aM()) ? 0 : 1));
        for (tt ttVar : arrayListDW) {
            if (ttVar.aM() && ttVar != ttVarZo) {
                or.j6(i, m117j6(ttVar));
                i++;
            }
        }
        if (ttVarZo == null || ttVarZo.FH().size() == 0) {
            return or;
        }
        throw new RuntimeException("Exit block must have no insns when leaving SSA form");
    }

    private void m114DW(tt ttVar) {
        ArrayList arrayListFH = ttVar.FH();
        es esVarV5 = ((vt) arrayListFH.get(arrayListFH.size() - 1)).v5();
        if (esVarV5.DW() != 2 && esVarV5 != gs.GK) {
            throw new RuntimeException("Exit predecessor must end in valid exit statement.");
        }
    }

    private void m115FH() {
        int iGn = this.f87j6.gn();
        Ts ts = new Ts(this.f87j6.u7());
        int iU7 = this.f87j6.u7();
        for (int i = 0; i < iU7; i++) {
            if (i < iGn) {
                ts.j6(i, (iU7 - iGn) + i, 1);
            } else {
                ts.j6(i, i - iGn, 1);
            }
        }
        this.f87j6.j6(ts);
    }

    private void m116Hw() {
        this.f87j6.j6(false, new Jt(this, this.f87j6.DW()));
    }

    private Nr m117j6(tt ttVar) {
        au auVarJ0 = ttVar.J0();
        int iTp = ttVar.tp();
        tt ttVarZo = this.f87j6.Zo();
        if (auVarJ0.Hw(ttVarZo == null ? -1 : ttVarZo.EQ())) {
            if (auVarJ0.size() > 1) {
                throw new RuntimeException("Exit predecessor must have no other successors" + Yt.v5(ttVar.EQ()));
            }
            auVarJ0 = au.DW;
            m114DW(ttVar);
            iTp = -1;
        }
        auVarJ0.we();
        return new Nr(ttVar.EQ(), m118j6(ttVar.FH()), auVarJ0, iTp);
    }

    private Ur m118j6(ArrayList<vt> arrayList) {
        int size = arrayList.size();
        Ur ur = new Ur(size);
        for (int i = 0; i < size; i++) {
            ur.j6(i, arrayList.get(i).lg());
        }
        ur.we();
        return ur;
    }

    private fs m119j6() {
        Dt dt = new Dt(this.f87j6, this.f86FH, this.f85DW);
        qt qtVarJ6 = dt.j6();
        this.f87j6.QX();
        this.f87j6.j6(qtVarJ6);
        m121v5();
        if (dt.DW()) {
            m115FH();
        }
        m116Hw();
        Or orM113DW = m113DW();
        yt ytVar = this.f87j6;
        return new Et(new fs(orM113DW, ytVar.j6(ytVar.v5()))).j6();
    }

    public static fs m120j6(yt ytVar, boolean z) {
        return new C0015Kt(ytVar, z).m119j6();
    }

    private void m121v5() {
        ArrayList<tt> arrayListDW = this.f87j6.DW();
        for (tt ttVar : arrayListDW) {
            ttVar.j6(new a(arrayListDW));
            ttVar.j3();
        }
        Iterator it = arrayListDW.iterator();
        while (it.hasNext()) {
            ((tt) it.next()).Mr();
        }
    }
}
