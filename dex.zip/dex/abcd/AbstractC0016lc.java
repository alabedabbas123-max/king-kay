package abcd;

import java.io.File;

@xu
public abstract class AbstractC0016lc {

    @ru(field = -1866576513991797627L)
    private static AbstractC0016lc f193DW;

    @tu
    private static boolean f194FH;

    @uu
    private static boolean f195Hw;

    @ru(field = 1775813849288939775L)
    private static Object f196j6;

    static {
        try {
            wu.j6(AbstractC0016lc.class, 1067082844909081120L, 1067082844909081120L);
            if (f194FH) {
                wu.j6(3176102765441174928L, (Object) null);
            }
            f196j6 = new Object();
        } catch (Throwable th) {
            if (f195Hw) {
                wu.j6(th, 3176102765441174928L, (Object) null);
            }
            throw th;
        }
    }

    public AbstractC0016lc() {
        try {
            if (f194FH) {
                wu.j6(267002143026857037L, (Object) null);
            }
        } catch (Throwable th) {
            if (f195Hw) {
                wu.j6(th, 267002143026857037L, (Object) null);
            }
            throw th;
        }
    }

    public static AbstractC0016lc m101j6() {
        AbstractC0016lc abstractC0016lc;
        try {
            if (f194FH) {
                wu.j6(-1705772020450490709L, (Object) null);
            }
            synchronized (f196j6) {
                abstractC0016lc = f193DW;
            }
            return abstractC0016lc;
        } catch (Throwable th) {
            if (f195Hw) {
                wu.j6(th, -1705772020450490709L, (Object) null);
            }
            throw th;
        }
    }

    public abstract boolean m102j6(File file, long j);
}
