package abcd;

import java.io.IOException;
import java.io.OutputStream;

public abstract class AbstractC0119rE {

    private final byte[] f676VH;

    private final int f677gn;

    private final int f678u7;

    public static final AbstractC0119rE f674j6 = new kE(16384, 2);

    public static final AbstractC0119rE f670DW = new lE(40960, 3);

    public static final AbstractC0119rE f671FH = new mE(33188, 3);

    public static final AbstractC0119rE f672Hw = new nE(33261, 3);

    public static final AbstractC0119rE f675v5 = new oE(57344, 1);

    public static final AbstractC0119rE f673Zo = new C0034pE(0, -1);

    private AbstractC0119rE(int i, int i2) {
        this.f677gn = i;
        this.f678u7 = i2;
        int i3 = 0;
        if (i == 0) {
            this.f676VH = new byte[]{48};
            return;
        }
        byte[] bArr = new byte[10];
        int length = bArr.length;
        while (i != 0) {
            length--;
            bArr[length] = (byte) ((i & 7) + 48);
            i >>= 3;
        }
        this.f676VH = new byte[bArr.length - length];
        while (true) {
            byte[] bArr2 = this.f676VH;
            if (i3 >= bArr2.length) {
                return;
            }
            bArr2[i3] = bArr[length + i3];
            i3++;
        }
    }

    AbstractC0119rE(int i, int i2, AbstractC0119rE abstractC0119rE) {
        this(i, i2);
    }

    public static final AbstractC0119rE m622DW(int i) {
        int i2 = 61440 & i;
        if (i2 != 0) {
            if (i2 == 16384) {
                return f674j6;
            }
            if (i2 == 32768) {
                return (i & 73) != 0 ? f672Hw : f671FH;
            }
            if (i2 == 40960) {
                return f670DW;
            }
            if (i2 == 57344) {
                return f675v5;
            }
        } else if (i == 0) {
            return f673Zo;
        }
        return new C0076qE(i, -1, i);
    }

    public int m623DW() {
        return this.f677gn;
    }

    public int m624FH() {
        return this.f678u7;
    }

    public int m625j6() {
        return this.f676VH.length;
    }

    public void m626j6(OutputStream outputStream) throws IOException {
        outputStream.write(this.f676VH);
    }

    public void m627j6(byte[] bArr, int i) {
        byte[] bArr2 = this.f676VH;
        System.arraycopy(bArr2, 0, bArr, i, bArr2.length);
    }

    public abstract boolean mo142j6(int i);

    public String toString() {
        return Integer.toOctalString(this.f677gn);
    }
}
