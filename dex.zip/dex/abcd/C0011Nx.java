package abcd;

public final class C0011Nx implements com.google.android.gms.common.api.a.d.e {

    public static final C0011Nx f20j6;

    private final boolean f21DW = false;

    private final boolean f22FH = false;

    private final String f23Hw = null;

    private final boolean f28v5 = false;

    private final boolean f24VH = false;

    private final String f25Zo = null;

    private final Long f26gn = null;

    private final Long f27u7 = null;

    public static final class a {
    }

    static {
        new a();
        f20j6 = new C0011Nx(false, false, null, false, null, false, null, null);
    }

    private C0011Nx(boolean z, boolean z2, String str, boolean z3, String str2, boolean z4, Long l, Long l2) {
    }

    public final String m48DW() {
        return this.f25Zo;
    }

    public final Long m49FH() {
        return this.f27u7;
    }

    public final String m50Hw() {
        return this.f23Hw;
    }

    public final boolean m51VH() {
        return this.f21DW;
    }

    public final boolean m52Zo() {
        return this.f22FH;
    }

    public final boolean m53gn() {
        return this.f24VH;
    }

    public final Long m54j6() {
        return this.f26gn;
    }

    public final boolean m55v5() {
        return this.f28v5;
    }
}
