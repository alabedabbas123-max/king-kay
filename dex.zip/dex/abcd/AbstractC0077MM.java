package abcd;

import java.io.InputStream;

abstract class AbstractC0077MM extends InputStream {

    private int f348DW;

    protected final InputStream f349j6;

    AbstractC0077MM(InputStream inputStream, int i) {
        this.f349j6 = inputStream;
        this.f348DW = i;
    }

    int m412j6() {
        return this.f348DW;
    }

    protected void m413j6(boolean z) {
        JM jm = this.f349j6;
        if (jm instanceof JM) {
            jm.DW(z);
        }
    }
}
