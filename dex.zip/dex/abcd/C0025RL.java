package abcd;

import java.util.Enumeration;

class C0025RL implements Enumeration {

    final C0068SL f152DW;

    int f153j6 = 0;

    C0025RL(C0068SL c0068sl) {
        this.f152DW = c0068sl;
    }

    @Override
    public boolean hasMoreElements() {
        return this.f153j6 < this.f152DW.f321DW.length;
    }

    @Override
    public Object nextElement() {
        AL[] alArr = this.f152DW.f321DW;
        int i = this.f153j6;
        this.f153j6 = i + 1;
        return alArr[i];
    }
}
