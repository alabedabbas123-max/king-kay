package abcd;

import java.util.Collection;

public abstract class AbstractC0011Kp {

    private final jp f58DW;

    private final int f59FH;

    private int f60Hw;

    private final String f61j6;

    private boolean f62v5;

    public AbstractC0011Kp(String str, jp jpVar, int i) {
        if (jpVar == null) {
            throw new NullPointerException("file == null");
        }
        m86FH(i);
        this.f61j6 = str;
        this.f58DW = jpVar;
        this.f59FH = i;
        this.f60Hw = -1;
        this.f62v5 = false;
    }

    public static void m86FH(int i) {
        if (i <= 0 || (i & (i - 1)) != 0) {
            throw new IllegalArgumentException("invalid alignment");
        }
    }

    public final int m87DW(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("fileOffset < 0");
        }
        if (this.f60Hw >= 0) {
            throw new RuntimeException("fileOffset already set");
        }
        int i2 = this.f59FH - 1;
        int i3 = (i + i2) & (i2 ^ (-1));
        this.f60Hw = i3;
        return i3;
    }

    public final jp m88DW() {
        return this.f58DW;
    }

    public final void m89DW(InterfaceC0057Lt interfaceC0057Lt) {
        m93VH();
        m99j6(interfaceC0057Lt);
        int iV5 = interfaceC0057Lt.v5();
        int i = this.f60Hw;
        if (i < 0) {
            this.f60Hw = iV5;
        } else if (i != iV5) {
            throw new RuntimeException("alignment mismatch: for " + this + ", at " + iV5 + ", but expected " + this.f60Hw);
        }
        if (interfaceC0057Lt.m309Hw()) {
            if (this.f61j6 != null) {
                interfaceC0057Lt.m311j6(0, "\n" + this.f61j6 + ":");
            } else if (iV5 != 0) {
                interfaceC0057Lt.m311j6(0, "\n");
            }
        }
        m91FH(interfaceC0057Lt);
    }

    public final int m90FH() {
        int i = this.f60Hw;
        if (i >= 0) {
            return i;
        }
        throw new RuntimeException("fileOffset not set");
    }

    protected abstract void m91FH(InterfaceC0057Lt interfaceC0057Lt);

    public abstract Collection<? extends vp> m92Hw();

    protected final void m93VH() {
        if (!this.f62v5) {
            throw new RuntimeException("not prepared");
        }
    }

    protected abstract void m94Zo();

    protected final void m95gn() {
        if (this.f62v5) {
            throw new RuntimeException("already prepared");
        }
    }

    public final int m96j6() {
        return this.f59FH;
    }

    public final int m97j6(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("relative < 0");
        }
        int i2 = this.f60Hw;
        if (i2 >= 0) {
            return i2 + i;
        }
        throw new RuntimeException("fileOffset not yet set");
    }

    public abstract int m98j6(vp vpVar);

    protected final void m99j6(InterfaceC0057Lt interfaceC0057Lt) {
        interfaceC0057Lt.Hw(this.f59FH);
    }

    public abstract int m100u7();

    public final void m101v5() {
        m95gn();
        m94Zo();
        this.f62v5 = true;
    }
}
