package abcd;

import java.util.BitSet;

public abstract class AbstractC0091Vn {

    private final Xn f245DW;

    private final hs f246FH;

    private final cs f247Hw;

    private int f248j6;

    public AbstractC0091Vn(Xn xn, hs hsVar, cs csVar) {
        if (xn == null) {
            throw new NullPointerException("opcode == null");
        }
        if (hsVar == null) {
            throw new NullPointerException("position == null");
        }
        if (csVar == null) {
            throw new NullPointerException("registers == null");
        }
        this.f248j6 = -1;
        this.f245DW = xn;
        this.f246FH = hsVar;
        this.f247Hw = csVar;
    }

    public static mo m560j6(hs hsVar, bs bsVar, bs bsVar2) {
        Xn xn;
        boolean z = bsVar.Hw() == 1;
        boolean zVy = bsVar.getType().vy();
        int iWe = bsVar.we();
        if ((bsVar2.we() | iWe) < 16) {
            if (zVy) {
                xn = Yn.tp;
            } else {
                xn = z ? Yn.Hw : Yn.VH;
            }
        } else if (iWe < 256) {
            if (zVy) {
                xn = Yn.EQ;
            } else {
                xn = z ? Yn.v5 : Yn.gn;
            }
        } else if (zVy) {
            xn = Yn.we;
        } else {
            xn = z ? Yn.Zo : Yn.u7;
        }
        return new mo(xn, hsVar, cs.j6(bsVar, bsVar2));
    }

    public abstract int m561DW();

    public abstract AbstractC0091Vn m562DW(int i);

    public AbstractC0091Vn m563DW(BitSet bitSet) {
        if (!m580tp() || bitSet.get(0)) {
            return null;
        }
        bs bsVar = this.f247Hw.get(0);
        return m560j6(this.f246FH, bsVar, bsVar.FH(0));
    }

    public final String m564EQ() {
        int i = this.f248j6;
        return i != -1 ? String.format("%04x", Integer.valueOf(i)) : Yt.gn(System.identityHashCode(this));
    }

    public final int m565FH() {
        int i = this.f248j6;
        if (i >= 0) {
            return i;
        }
        throw new RuntimeException("address not yet known");
    }

    public AbstractC0091Vn m566FH(BitSet bitSet) {
        return m573j6(this.f247Hw.j6(0, m580tp(), bitSet));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v2, types: [int] */
    /* JADX WARN: Type inference failed for: r6v0, types: [java.util.BitSet] */
    public final int m567Hw(BitSet bitSet) {
        ?? M580tp = m580tp();
        int size = this.f247Hw.size();
        int iHw = 0;
        int iHw2 = (M580tp == 0 || bitSet.get(0)) ? 0 : this.f247Hw.get(0).Hw();
        while (M580tp < size) {
            if (!bitSet.get(M580tp)) {
                iHw += this.f247Hw.get((int) M580tp).Hw();
            }
            M580tp++;
        }
        return Math.max(iHw, iHw2);
    }

    public AbstractC0091Vn m568Hw() {
        return m573j6(this.f247Hw.j6(0, m580tp(), (BitSet) null));
    }

    public final hs m569VH() {
        return this.f246FH;
    }

    public final Xn m570Zo() {
        return this.f245DW;
    }

    public final cs m571gn() {
        return this.f247Hw;
    }

    public abstract AbstractC0091Vn m572j6(Xn xn);

    public abstract AbstractC0091Vn m573j6(cs csVar);

    public AbstractC0091Vn m574j6(BitSet bitSet) {
        cs csVar = this.f247Hw;
        boolean z = bitSet.get(0);
        if (m580tp()) {
            bitSet.set(0);
        }
        cs csVarJ6 = csVar.j6(bitSet);
        if (m580tp()) {
            bitSet.set(0, z);
        }
        if (csVarJ6.size() == 0) {
            return null;
        }
        return new _n(this.f246FH, csVarJ6);
    }

    protected abstract String m575j6();

    public final String m576j6(String str, int i, boolean z) {
        String strM577j6 = m577j6(z);
        if (strM577j6 == null) {
            return null;
        }
        String str2 = str + m564EQ() + ": ";
        int length = str2.length();
        return mu.j6(str2, length, "", strM577j6, i == 0 ? strM577j6.length() : i - length);
    }

    protected abstract String m577j6(boolean z);

    public final void m578j6(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("address < 0");
        }
        this.f248j6 = i;
    }

    public abstract void m579j6(Lt lt);

    public final String toString() {
        boolean z;
        StringBuffer stringBuffer = new StringBuffer(100);
        stringBuffer.append(m564EQ());
        stringBuffer.append(' ');
        stringBuffer.append(this.f246FH);
        stringBuffer.append(": ");
        stringBuffer.append(this.f245DW.FH());
        if (this.f247Hw.size() != 0) {
            stringBuffer.append(this.f247Hw.j6(" ", ", ", (String) null));
            z = true;
        } else {
            z = false;
        }
        String strM575j6 = m575j6();
        if (strM575j6 != null) {
            if (z) {
                stringBuffer.append(',');
            }
            stringBuffer.append(' ');
            stringBuffer.append(strM575j6);
        }
        return stringBuffer.toString();
    }

    public final boolean m580tp() {
        return this.f245DW.VH();
    }

    public final boolean m581u7() {
        return this.f248j6 >= 0;
    }

    public final int m582v5() {
        return m565FH() + m561DW();
    }
}
