package abcd;

public abstract class AbstractC0051Cm extends Am {

    private final Kr f211DW;

    private final int f212FH;

    public AbstractC0051Cm(String str, Kr kr, int i) throws iu {
        super(str);
        try {
            if (kr.Zo()) {
                throw new iu("parameterAnnotations.isMutable()");
            }
            this.f211DW = kr;
            this.f212FH = i;
        } catch (NullPointerException unused) {
            throw new NullPointerException("parameterAnnotations == null");
        }
    }

    public final int m357Hw() {
        return this.f212FH + 6;
    }

    public final Kr m358j6() {
        return this.f211DW;
    }
}
