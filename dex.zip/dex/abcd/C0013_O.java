package abcd;

import java.security.MessageDigest;
import java.security.Signature;

public class C0013_O implements InterfaceC0057aP {
    @Override
    public MessageDigest mo109DW(String str) {
        return MessageDigest.getInstance(str);
    }

    @Override
    public Signature mo110j6(String str) {
        return Signature.getInstance(str);
    }
}
