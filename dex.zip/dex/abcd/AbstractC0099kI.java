package abcd;

import java.util.List;

public abstract class AbstractC0099kI {

    private static volatile AbstractC0099kI f376j6;

    public static AbstractC0099kI m497j6() {
        return f376j6;
    }

    public abstract boolean m498DW();

    public void m499j6(HJ hj) {
    }

    public boolean m500j6(HJ hj, List<AbstractC0055jI> list) {
        return m501j6(hj, (AbstractC0055jI[]) list.toArray(new AbstractC0055jI[list.size()]));
    }

    public abstract boolean m501j6(HJ hj, AbstractC0055jI... abstractC0055jIArr);

    public abstract boolean m502j6(AbstractC0055jI... abstractC0055jIArr);
}
