package abcd;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.zip.GZIPInputStream;

public class C0023Hz {

    private String f146EQ;

    public final URL f148Hw;

    private boolean f149VH;

    private e f150Zo;

    private final String f154v5;

    private int f155we;

    private static final String[] f145j6 = new String[0];

    private static b f144DW = b.f158j6;

    private HttpURLConnection f147FH = null;

    private boolean f151gn = true;

    private boolean f153u7 = false;

    private int f152tp = 8192;

    protected static abstract class a<V> extends d<V> {

        private final boolean f156DW;

        private final Closeable f157j6;

        protected a(Closeable closeable, boolean z) {
            this.f157j6 = closeable;
            this.f156DW = z;
        }

        protected void m279j6() throws IOException {
            Closeable closeable = this.f157j6;
            if (closeable instanceof Flushable) {
                ((Flushable) closeable).flush();
            }
            if (!this.f156DW) {
                this.f157j6.close();
            } else {
                try {
                    this.f157j6.close();
                } catch (IOException unused) {
                }
            }
        }
    }

    public interface b {

        public static final b f158j6 = new C0065Iz();

        HttpURLConnection mo280j6(URL url);

        HttpURLConnection mo281j6(URL url, Proxy proxy);
    }

    public static class c extends RuntimeException {
        protected c(IOException iOException) {
            super(iOException);
        }

        @Override
        public IOException getCause() {
            return (IOException) super.getCause();
        }
    }

    protected static abstract class d<V> implements Callable<V> {
        protected d() {
        }

        protected abstract V m282DW();

        @Override
        public V call() throws Throwable {
            Throwable th;
            boolean z = true;
            try {
                try {
                    V vM282DW = m282DW();
                    try {
                        m283j6();
                        return vM282DW;
                    } catch (IOException e) {
                        throw new c(e);
                    }
                } catch (Throwable th2) {
                    th = th2;
                    try {
                        m283j6();
                    } catch (IOException e2) {
                        if (!z) {
                            throw new c(e2);
                        }
                    }
                    throw th;
                }
            } catch (c e3) {
                throw e3;
            } catch (IOException e4) {
                throw new c(e4);
            } catch (Throwable th3) {
                th = th3;
                z = false;
                m283j6();
                throw th;
            }
        }

        protected abstract void m283j6();
    }

    public static class e extends BufferedOutputStream {

        private final CharsetEncoder f159j6;

        public e(OutputStream outputStream, String str, int i) {
            super(outputStream, i);
            this.f159j6 = Charset.forName(C0023Hz.m233Zo(str)).newEncoder();
        }

        public e m284j6(String str) throws IOException {
            ByteBuffer byteBufferEncode = this.f159j6.encode(CharBuffer.wrap(str));
            super.write(byteBufferEncode.array(), 0, byteBufferEncode.limit());
            return this;
        }
    }

    public C0023Hz(CharSequence charSequence, String str) {
        try {
            this.f148Hw = new URL(charSequence.toString());
            this.f154v5 = str;
        } catch (MalformedURLException e2) {
            throw new c(e2);
        }
    }

    public static C0023Hz m226DW(CharSequence charSequence, Map<?, ?> map, boolean z) {
        String strM237j6 = m237j6(charSequence, map);
        if (z) {
            strM237j6 = m227DW((CharSequence) strM237j6);
        }
        return m230Hw((CharSequence) strM237j6);
    }

    public static String m227DW(CharSequence charSequence) {
        int i;
        try {
            URL url = new URL(charSequence.toString());
            String host = url.getHost();
            int port = url.getPort();
            if (port != -1) {
                host = host + ':' + Integer.toString(port);
            }
            try {
                String aSCIIString = new URI(url.getProtocol(), host, url.getPath(), url.getQuery(), url.getRef()).toASCIIString();
                int iIndexOf = aSCIIString.indexOf(63);
                if (iIndexOf <= 0 || (i = iIndexOf + 1) >= aSCIIString.length()) {
                    return aSCIIString;
                }
                return aSCIIString.substring(0, i) + aSCIIString.substring(i).replace("+", "%2B").replace("#", "%23");
            } catch (URISyntaxException e2) {
                IOException iOException = new IOException("Parsing URI failed");
                iOException.initCause(e2);
                throw new c(iOException);
            }
        } catch (IOException e3) {
            throw new c(e3);
        }
    }

    private static StringBuilder m228DW(String str, StringBuilder sb) {
        if (str.indexOf(58) + 2 == str.lastIndexOf(47)) {
            sb.append('/');
        }
        return sb;
    }

    public static C0023Hz m229FH(CharSequence charSequence) {
        return new C0023Hz(charSequence, "GET");
    }

    public static C0023Hz m230Hw(CharSequence charSequence) {
        return new C0023Hz(charSequence, "POST");
    }

    private HttpURLConnection m231QX() {
        try {
            HttpURLConnection httpURLConnectionMo281j6 = this.f146EQ != null ? f144DW.mo281j6(this.f148Hw, m232XL()) : f144DW.mo280j6(this.f148Hw);
            httpURLConnectionMo281j6.setRequestMethod(this.f154v5);
            return httpURLConnectionMo281j6;
        } catch (IOException e2) {
            throw new c(e2);
        }
    }

    private Proxy m232XL() {
        return new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.f146EQ, this.f155we));
    }

    public static String m233Zo(String str) {
        return (str == null || str.length() <= 0) ? "UTF-8" : str;
    }

    public static C0023Hz m235j6(CharSequence charSequence) {
        return new C0023Hz(charSequence, "DELETE");
    }

    public static C0023Hz m236j6(CharSequence charSequence, Map<?, ?> map, boolean z) {
        String strM237j6 = m237j6(charSequence, map);
        if (z) {
            strM237j6 = m227DW((CharSequence) strM237j6);
        }
        return m229FH((CharSequence) strM237j6);
    }

    public static String m237j6(CharSequence charSequence, Map<?, ?> map) {
        String string = charSequence.toString();
        if (map == null || map.isEmpty()) {
            return string;
        }
        StringBuilder sb = new StringBuilder(string);
        m228DW(string, sb);
        m239j6(string, sb);
        Iterator<Map.Entry<?, ?>> it = map.entrySet().iterator();
        Map.Entry<?, ?> next = it.next();
        sb.append(next.getKey().toString());
        sb.append('=');
        Object value = next.getValue();
        if (value != null) {
            sb.append(value);
        }
        while (it.hasNext()) {
            sb.append('&');
            Map.Entry<?, ?> next2 = it.next();
            sb.append(next2.getKey().toString());
            sb.append('=');
            Object value2 = next2.getValue();
            if (value2 != null) {
                sb.append(value2);
            }
        }
        return sb.toString();
    }

    private static StringBuilder m239j6(String str, StringBuilder sb) {
        int iIndexOf = str.indexOf(63);
        int length = sb.length() - 1;
        if (iIndexOf == -1) {
            sb.append('?');
        } else if (iIndexOf < length && str.charAt(length) != '&') {
            sb.append('&');
        }
        return sb;
    }

    public static C0023Hz m240v5(CharSequence charSequence) {
        return new C0023Hz(charSequence, "PUT");
    }

    protected C0023Hz m241DW(String str, String str2, String str3) {
        StringBuilder sb = new StringBuilder();
        sb.append("form-data; name=\"");
        sb.append(str);
        if (str2 != null) {
            sb.append("\"; filename=\"");
            sb.append(str2);
        }
        sb.append('\"');
        m258Zo("Content-Disposition", sb.toString());
        if (str3 != null) {
            m258Zo("Content-Type", str3);
        }
        m257Zo("\r\n");
        return this;
    }

    public BufferedInputStream m242DW() {
        return new BufferedInputStream(m253J8(), this.f152tp);
    }

    public String m243DW(String str) {
        ByteArrayOutputStream byteArrayOutputStreamM248FH = m248FH();
        try {
            m262j6(m242DW(), byteArrayOutputStreamM248FH);
            return byteArrayOutputStreamM248FH.toString(m233Zo(str));
        } catch (IOException e2) {
            throw new c(e2);
        }
    }

    protected String m244DW(String str, String str2) {
        String strTrim;
        int length;
        if (str != null && str.length() != 0) {
            int length2 = str.length();
            int iIndexOf = str.indexOf(59) + 1;
            if (iIndexOf != 0 && iIndexOf != length2) {
                int iIndexOf2 = str.indexOf(59, iIndexOf);
                if (iIndexOf2 == -1) {
                    iIndexOf2 = length2;
                }
                while (iIndexOf < iIndexOf2) {
                    int iIndexOf3 = str.indexOf(61, iIndexOf);
                    if (iIndexOf3 != -1 && iIndexOf3 < iIndexOf2 && str2.equals(str.substring(iIndexOf, iIndexOf3).trim()) && (length = (strTrim = str.substring(iIndexOf3 + 1, iIndexOf2).trim()).length()) != 0) {
                        if (length > 2 && '\"' == strTrim.charAt(0)) {
                            int i = length - 1;
                            if ('\"' == strTrim.charAt(i)) {
                                return strTrim.substring(1, i);
                            }
                        }
                        return strTrim;
                    }
                    iIndexOf = iIndexOf2 + 1;
                    iIndexOf2 = str.indexOf(59, iIndexOf);
                    if (iIndexOf2 == -1) {
                        iIndexOf2 = length2;
                    }
                }
            }
        }
        return null;
    }

    public String m245EQ() {
        return m273tp().getRequestMethod();
    }

    public C0023Hz m246FH(String str) {
        m264j6(str, (String) null);
        return this;
    }

    public C0023Hz m247FH(String str, String str2) {
        m273tp().setRequestProperty(str, str2);
        return this;
    }

    protected ByteArrayOutputStream m248FH() {
        int iM274u7 = m274u7();
        return iM274u7 > 0 ? new ByteArrayOutputStream(iM274u7) : new ByteArrayOutputStream();
    }

    public String m249Hw() {
        return m251Hw("Content-Type", "charset");
    }

    public String m250Hw(String str) {
        m256Zo();
        return m273tp().getHeaderField(str);
    }

    public String m251Hw(String str, String str2) {
        return m244DW(m250Hw(str), str2);
    }

    protected C0023Hz m252J0() throws IOException {
        if (this.f149VH) {
            this.f150Zo.m284j6("\r\n--00content0boundary00\r\n");
        } else {
            this.f149VH = true;
            m246FH("multipart/form-data; boundary=00content0boundary00");
            m278we();
            this.f150Zo.m284j6("--00content0boundary00\r\n");
        }
        return this;
    }

    public InputStream m253J8() {
        InputStream inputStream;
        if (m254VH() < 400) {
            try {
                inputStream = m273tp().getInputStream();
            } catch (IOException e2) {
                throw new c(e2);
            }
        } else {
            inputStream = m273tp().getErrorStream();
            if (inputStream == null) {
                try {
                    inputStream = m273tp().getInputStream();
                } catch (IOException e3) {
                    throw new c(e3);
                }
            }
        }
        if (!this.f153u7 || !"gzip".equals(m259gn())) {
            return inputStream;
        }
        try {
            return new GZIPInputStream(inputStream);
        } catch (IOException e4) {
            throw new c(e4);
        }
    }

    public int m254VH() {
        try {
            m276v5();
            return m273tp().getResponseCode();
        } catch (IOException e2) {
            throw new c(e2);
        }
    }

    public URL m255Ws() {
        return m273tp().getURL();
    }

    protected C0023Hz m256Zo() {
        try {
            m276v5();
            return this;
        } catch (IOException e2) {
            throw new c(e2);
        }
    }

    public C0023Hz m257Zo(CharSequence charSequence) {
        try {
            m278we();
            this.f150Zo.m284j6(charSequence.toString());
            return this;
        } catch (IOException e2) {
            throw new c(e2);
        }
    }

    public C0023Hz m258Zo(String str, String str2) {
        m257Zo((CharSequence) str);
        m257Zo(": ");
        m257Zo((CharSequence) str2);
        m257Zo("\r\n");
        return this;
    }

    public String m259gn() {
        return m250Hw("Content-Encoding");
    }

    public int m260j6(String str, int i) {
        m256Zo();
        return m273tp().getHeaderFieldInt(str, i);
    }

    public C0023Hz m261j6(int i) {
        m273tp().setConnectTimeout(i);
        return this;
    }

    protected C0023Hz m262j6(InputStream inputStream, OutputStream outputStream) {
        return (C0023Hz) new Gz(this, inputStream, this.f151gn, inputStream, outputStream).call();
    }

    public C0023Hz m263j6(String str, Number number) {
        m265j6(str, (String) null, number);
        return this;
    }

    public C0023Hz m264j6(String str, String str2) {
        if (str2 == null || str2.length() <= 0) {
            m247FH("Content-Type", str);
            return this;
        }
        m247FH("Content-Type", str + "; charset=" + str2);
        return this;
    }

    public C0023Hz m265j6(String str, String str2, Number number) {
        m266j6(str, str2, number != null ? number.toString() : null);
        return this;
    }

    public C0023Hz m266j6(String str, String str2, String str3) {
        m269j6(str, str2, (String) null, str3);
        return this;
    }

    public C0023Hz m267j6(String str, String str2, String str3, File file) throws Throwable {
        BufferedInputStream bufferedInputStream = null;
        try {
            try {
                BufferedInputStream bufferedInputStream2 = new BufferedInputStream(new FileInputStream(file));
                try {
                    m268j6(str, str2, str3, bufferedInputStream2);
                    try {
                        bufferedInputStream2.close();
                    } catch (IOException unused) {
                    }
                    return this;
                } catch (IOException e2) {
                    e = e2;
                    bufferedInputStream = bufferedInputStream2;
                    throw new c(e);
                } catch (Throwable th) {
                    th = th;
                    bufferedInputStream = bufferedInputStream2;
                    if (bufferedInputStream != null) {
                        try {
                            bufferedInputStream.close();
                        } catch (IOException unused2) {
                        }
                    }
                    throw th;
                }
            } catch (IOException e3) {
                e = e3;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    public C0023Hz m268j6(String str, String str2, String str3, InputStream inputStream) {
        try {
            m252J0();
            m241DW(str, str2, str3);
            m262j6(inputStream, this.f150Zo);
            return this;
        } catch (IOException e2) {
            throw new c(e2);
        }
    }

    public C0023Hz m269j6(String str, String str2, String str3, String str4) {
        try {
            m252J0();
            m241DW(str, str2, str3);
            this.f150Zo.m284j6(str4);
            return this;
        } catch (IOException e2) {
            throw new c(e2);
        }
    }

    public C0023Hz m270j6(Map.Entry<String, String> entry) {
        m247FH(entry.getKey(), entry.getValue());
        return this;
    }

    public C0023Hz m271j6(boolean z) {
        m273tp().setUseCaches(z);
        return this;
    }

    public String m272j6() {
        return m243DW(m249Hw());
    }

    public String toString() {
        return m245EQ() + ' ' + m255Ws();
    }

    public HttpURLConnection m273tp() {
        if (this.f147FH == null) {
            this.f147FH = m231QX();
        }
        return this.f147FH;
    }

    public int m274u7() {
        return m275v5("Content-Length");
    }

    public int m275v5(String str) {
        return m260j6(str, -1);
    }

    protected C0023Hz m276v5() throws IOException {
        e eVar = this.f150Zo;
        if (eVar == null) {
            return this;
        }
        if (this.f149VH) {
            eVar.m284j6("\r\n--00content0boundary00--\r\n");
        }
        if (this.f151gn) {
            try {
                this.f150Zo.close();
            } catch (IOException unused) {
            }
        } else {
            this.f150Zo.close();
        }
        this.f150Zo = null;
        return this;
    }

    public C0023Hz m277v5(String str, String str2) {
        m266j6(str, (String) null, str2);
        return this;
    }

    protected C0023Hz m278we() {
        if (this.f150Zo != null) {
            return this;
        }
        m273tp().setDoOutput(true);
        this.f150Zo = new e(m273tp().getOutputStream(), m244DW(m273tp().getRequestProperty("Content-Type"), "charset"), this.f152tp);
        return this;
    }
}
