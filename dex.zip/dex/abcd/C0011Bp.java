package abcd;

public final class C0011Bp extends yp {
    public C0011Bp(qs qsVar) {
        super(qsVar);
    }

    protected int m56DW(jp jpVar) {
        return jpVar.EQ().j6(m59U2().J8());
    }

    public wp m57Hw() {
        return wp.Zo;
    }

    protected String m58Mr() {
        return "proto_idx";
    }

    public qs m59U2() {
        return j3();
    }

    public void m60j6(jp jpVar) {
        super.j6(jpVar);
        jpVar.EQ().DW(m59U2().J8());
    }
}
