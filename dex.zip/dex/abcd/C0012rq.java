package abcd;

enum C0012rq extends er {
    C0012rq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
