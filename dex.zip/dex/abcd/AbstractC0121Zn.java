package abcd;

public abstract class AbstractC0121Zn extends Vn {
    public AbstractC0121Zn(C0035Xn c0035Xn, hs hsVar, cs csVar) {
        super(c0035Xn, hsVar, csVar);
    }

    public final int m782DW() {
        return Zo().m221DW().j6();
    }

    public final Vn m783DW(int i) {
        return j6(gn().v5(i));
    }

    protected final String m784j6(boolean z) {
        return Zo().m221DW().DW(this, z);
    }

    public final void m785j6(Lt lt) {
        Zo().m221DW().j6(lt, this);
    }
}
