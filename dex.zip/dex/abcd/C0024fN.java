package abcd;

public class C0024fN extends kM {
    public C0024fN(kM kMVar) {
        super(kMVar.getString());
    }

    public String toString() {
        return "NetscapeRevocationURL: " + getString();
    }
}
