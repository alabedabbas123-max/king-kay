package abcd;

@xu
public class C0016_b {

    public static final C0105bc f101DW;

    @tu
    private static boolean f102FH;

    @uu
    private static boolean f103Hw;

    @ru(field = 2333952093605259375L)
    private static final int[] f104j6;

    @ru(field = -1671342222453146737L)
    private int f105EQ;

    @ru(field = -2595259278179703905L)
    private int[] f106VH;

    @ru(field = 3339345495065876261L)
    private final Ea f107Zo;

    @ru(field = -2789425391358217280L)
    private int[] f108gn;

    @ru(field = 3122957734060419960L)
    private int f109tp;

    @ru(field = -2673030183025669964L)
    private int f110u7;

    public final a f111v5;

    @xu
    public class a {

        @uu
        private static boolean f112DW;

        @tu
        private static boolean f113j6;

        @ru(field = 390685072692224800L)
        private int f114FH;

        @ru(field = 971401635445095975L)
        private int f115Hw;

        @vu
        final C0016_b f116v5;

        static {
            wu.j6(a.class, 662139315901330176L, 662139315901330176L);
        }

        @su(method = -72628576590775389L)
        private a(C0016_b c0016_b) {
            try {
                if (f113j6) {
                    wu.j6(-334151378866724832L, (Object) null, c0016_b);
                }
                this.f116v5 = c0016_b;
                this.f114FH = 0;
            } catch (Throwable th) {
                if (f112DW) {
                    wu.j6(th, -334151378866724832L, (Object) null, c0016_b);
                }
                throw th;
            }
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        a(C0016_b c0016_b, Zb zb) {
            this(c0016_b);
            try {
                if (f113j6) {
                    wu.j6(139459785525098000L, (Object) null, c0016_b, zb);
                }
            } catch (Throwable th) {
                if (f112DW) {
                    wu.j6(th, 139459785525098000L, (Object) null, c0016_b, zb);
                }
                throw th;
            }
        }

        public void m133DW() {
            try {
                if (f113j6) {
                    wu.j6(-205351636672305936L, this);
                }
                this.f114FH = 0;
            } catch (Throwable th) {
                if (f112DW) {
                    wu.j6(th, -205351636672305936L, this);
                }
                throw th;
            }
        }

        public Da m134FH() {
            try {
                if (f113j6) {
                    wu.j6(-542859407813092176L, this);
                }
                return this.f116v5.f107Zo.Hw(this.f115Hw);
            } catch (Throwable th) {
                if (f112DW) {
                    wu.j6(th, -542859407813092176L, this);
                }
                throw th;
            }
        }

        public boolean m135j6() {
            try {
                if (f113j6) {
                    wu.j6(464504306972715840L, this);
                }
                while (this.f114FH < this.f116v5.f106VH.length) {
                    this.f115Hw = this.f116v5.f106VH[this.f114FH];
                    this.f114FH++;
                    if (this.f115Hw != 0 && this.f115Hw != Integer.MIN_VALUE) {
                        if (this.f115Hw == Integer.MAX_VALUE) {
                            this.f115Hw = 0;
                        }
                        return true;
                    }
                }
                return false;
            } catch (Throwable th) {
                if (f112DW) {
                    wu.j6(th, 464504306972715840L, this);
                }
                throw th;
            }
        }
    }

    static {
        try {
            wu.j6(C0016_b.class, 1717438685724287680L, 1717438685724287680L);
            if (f102FH) {
                wu.j6(-3022269036190830840L, (Object) null);
            }
            f104j6 = new int[]{5, 11, 17, 37, 67, 131, 257, 521, 1031, 2053, 4099, 8209, 16411, 32771, 65537, 131101, 262147, 524309, 1048583, 2097169, 4194319, 8388617, 16777259, 33554467, 67108879, 134217757, 268435459, 536870923, 1073741827, 2147383649};
            f101DW = new C0105bc();
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -3022269036190830840L, (Object) null);
            }
            throw th;
        }
    }

    public C0016_b(Ea ea) {
        Zb zb = null;
        try {
            if (f102FH) {
                wu.j6(2998680942378555651L, (Object) null, ea);
            }
            this.f111v5 = new a(this, zb);
            this.f107Zo = ea;
            this.f105EQ = 1;
            this.f106VH = new int[f104j6[this.f105EQ]];
            this.f110u7 = 0;
            this.f109tp = 0;
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 2998680942378555651L, (Object) null, ea);
            }
            throw th;
        }
    }

    public C0016_b(Ea ea, ec ecVar) {
        try {
            Zb zb = null;
            if (f102FH) {
                wu.j6(-3044723276893776765L, (Object) null, ea, ecVar);
            }
            this.f111v5 = new a(this, zb);
            this.f107Zo = ea;
            int i = ecVar.readInt();
            this.f105EQ = ecVar.readInt();
            this.f106VH = new int[f104j6[this.f105EQ]];
            this.f110u7 = 0;
            this.f109tp = 0;
            for (int i2 = 0; i2 < i; i2++) {
                m121DW(ecVar.readInt());
            }
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -3044723276893776765L, (Object) null, ea, ecVar);
            }
            throw th;
        }
    }

    @su(method = -7308225661967176636L)
    private void m121DW(int i) {
        try {
            if (f102FH) {
                wu.j6(4206087795882556976L, this, i);
            }
            if (i == 0) {
                i = Integer.MAX_VALUE;
            }
            int i2 = Integer.MAX_VALUE & i;
            int length = i2 % this.f106VH.length;
            int length2 = (i2 % (this.f106VH.length - 2)) + 1;
            int i3 = this.f106VH[length];
            int length3 = length;
            int i4 = -1;
            while (i3 != 0) {
                if (i3 == i) {
                    return;
                }
                if (i3 == Integer.MIN_VALUE) {
                    i4 = length3;
                }
                length3 = (length3 + length2) % this.f106VH.length;
                i3 = this.f106VH[length3];
            }
            if (i4 != -1) {
                length3 = i4;
            }
            this.f106VH[length3] = i;
            if (i4 == -1) {
                this.f110u7++;
            }
            this.f109tp++;
            if (this.f110u7 * 2 > this.f106VH.length) {
                m122Hw();
            }
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 4206087795882556976L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -3056300047891616491L)
    private void m122Hw() {
        int[] iArr;
        try {
            if (f102FH) {
                wu.j6(-1423856421812070981L, this);
            }
            if (this.f109tp * 2 > this.f106VH.length) {
                this.f105EQ++;
                this.f108gn = null;
                iArr = new int[f104j6[this.f105EQ]];
            } else if (this.f108gn == null || this.f108gn.length != this.f106VH.length) {
                this.f108gn = this.f106VH;
                iArr = new int[f104j6[this.f105EQ]];
            } else {
                iArr = this.f108gn;
                for (int i = 0; i < iArr.length; i++) {
                    iArr[i] = 0;
                }
                this.f108gn = this.f106VH;
            }
            int i2 = 0;
            for (int i3 = 0; i3 < this.f106VH.length; i3++) {
                int i4 = this.f106VH[i3];
                if (i4 != 0 && i4 != Integer.MIN_VALUE) {
                    int i5 = Integer.MAX_VALUE & i4;
                    int length = (i5 % (iArr.length - 2)) + 1;
                    int length2 = i5 % iArr.length;
                    while (iArr[length2] != 0) {
                        length2 = (length2 + length) % iArr.length;
                    }
                    iArr[length2] = i4;
                    i2++;
                }
            }
            this.f106VH = iArr;
            this.f110u7 = i2;
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -1423856421812070981L, this);
            }
            throw th;
        }
    }

    public Da m124DW() {
        try {
            if (f102FH) {
                wu.j6(701975799965414920L, this);
            }
            int i = 0;
            int i2 = 0;
            while (i2 < this.f106VH.length) {
                int i3 = this.f106VH[i2];
                i2++;
                if (i3 != 0 && i3 != Integer.MIN_VALUE) {
                    if (i3 != Integer.MAX_VALUE) {
                        i = i3;
                    }
                    return this.f107Zo.Hw(i);
                }
            }
            return null;
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 701975799965414920L, this);
            }
            throw th;
        }
    }

    public void m125DW(Da da) {
        try {
            if (f102FH) {
                wu.j6(-6671820574459799408L, this, da);
            }
            m121DW(this.f107Zo.VH(da));
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -6671820574459799408L, this, da);
            }
            throw th;
        }
    }

    public int m126FH() {
        try {
            if (f102FH) {
                wu.j6(-1137530722301540613L, this);
            }
            return this.f109tp;
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -1137530722301540613L, this);
            }
            throw th;
        }
    }

    public void m127FH(Da da) {
        try {
            if (f102FH) {
                wu.j6(291803823277001105L, this, da);
            }
            int iVH = this.f107Zo.VH(da);
            if (iVH == 0) {
                iVH = Integer.MAX_VALUE;
            }
            int i = Integer.MAX_VALUE & iVH;
            int length = i % this.f106VH.length;
            int length2 = (i % (this.f106VH.length - 2)) + 1;
            int i2 = this.f106VH[length];
            while (i2 != iVH) {
                if (i2 == 0) {
                    return;
                }
                length = (length + length2) % this.f106VH.length;
                i2 = this.f106VH[length];
            }
            this.f106VH[length] = Integer.MIN_VALUE;
            this.f109tp--;
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 291803823277001105L, this, da);
            }
            throw th;
        }
    }

    public void m128FH(C0016_b c0016_b) {
        try {
            if (f102FH) {
                wu.j6(6455872537627456319L, this, c0016_b);
            }
            for (int i = 0; i < c0016_b.f106VH.length; i++) {
                int i2 = c0016_b.f106VH[i];
                if (i2 == Integer.MAX_VALUE) {
                    m121DW(0);
                } else if (i2 != 0 && i2 != Integer.MIN_VALUE) {
                    m121DW(i2);
                }
            }
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 6455872537627456319L, this, c0016_b);
            }
            throw th;
        }
    }

    public boolean equals(Object obj) {
        try {
            if (f102FH) {
                wu.j6(172440942628475880L, this, obj);
            }
            if (!(obj instanceof C0105bc)) {
                return false;
            }
            C0105bc c0105bc = (C0105bc) obj;
            if (c0105bc.m686Hw() != m126FH()) {
                return false;
            }
            for (int i = 0; i < this.f106VH.length; i++) {
                int i2 = this.f106VH[i];
                if (i2 != 0 && i2 != Integer.MIN_VALUE) {
                    if (i2 == Integer.MAX_VALUE) {
                        i2 = 0;
                    }
                    if (!c0105bc.m689j6(i2)) {
                        return false;
                    }
                }
            }
            return true;
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 172440942628475880L, this, obj);
            }
            throw th;
        }
    }

    public void m129j6() {
        try {
            if (f102FH) {
                wu.j6(-754158966417287771L, this);
            }
            if (this.f110u7 > 0) {
                for (int i = 0; i < this.f106VH.length; i++) {
                    this.f106VH[i] = 0;
                }
                this.f110u7 = 0;
                this.f109tp = 0;
            }
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -754158966417287771L, this);
            }
            throw th;
        }
    }

    public void m130j6(fc fcVar) {
        try {
            if (f102FH) {
                wu.j6(-7773237639901596072L, this, fcVar);
            }
            fcVar.writeInt(this.f109tp);
            fcVar.writeInt(this.f105EQ);
            for (int i = 0; i < this.f106VH.length; i++) {
                int i2 = this.f106VH[i];
                if (i2 != 0 && i2 != Integer.MIN_VALUE) {
                    fcVar.writeInt(this.f106VH[i]);
                }
            }
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -7773237639901596072L, this, fcVar);
            }
            throw th;
        }
    }

    public boolean m131j6(int i) {
        try {
            if (f102FH) {
                wu.j6(-392242372711352152L, this, i);
            }
            if (i == 0) {
                i = Integer.MAX_VALUE;
            }
            int i2 = Integer.MAX_VALUE & i;
            int length = (i2 % (this.f106VH.length - 2)) + 1;
            int length2 = i2 % this.f106VH.length;
            int i3 = this.f106VH[length2];
            while (i3 != i) {
                if (i3 == 0) {
                    return false;
                }
                length2 = (length2 + length) % this.f106VH.length;
                i3 = this.f106VH[length2];
            }
            return true;
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, -392242372711352152L, this, new Integer(i));
            }
            throw th;
        }
    }

    public boolean m132j6(Da da) {
        try {
            if (f102FH) {
                wu.j6(138272374666265868L, this, da);
            }
            return m131j6(this.f107Zo.VH(da));
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 138272374666265868L, this, da);
            }
            throw th;
        }
    }

    public String toString() {
        try {
            if (f102FH) {
                wu.j6(1636535381058871180L, this);
            }
            String str = "{";
            for (int i = 0; i < this.f106VH.length; i++) {
                int i2 = this.f106VH[i];
                if (i2 != 0 && i2 != Integer.MIN_VALUE) {
                    if (i2 == Integer.MAX_VALUE) {
                        i2 = 0;
                    }
                    str = str + i2 + " " + this.f107Zo.Hw(i2).XL() + ", ";
                }
            }
            return str + "}";
        } catch (Throwable th) {
            if (f103Hw) {
                wu.j6(th, 1636535381058871180L, this);
            }
            throw th;
        }
    }
}
