package abcd;

import java.io.IOException;

public class C0017XL implements IL {

    private JL f72j6;

    C0017XL(JL jl) {
        this.f72j6 = jl;
    }

    public EL m103DW() throws DL {
        try {
            return m104j6();
        } catch (IOException e) {
            throw new DL(e.getMessage(), e);
        }
    }

    public EL m104j6() {
        return new WL(this.f72j6.DW());
    }
}
