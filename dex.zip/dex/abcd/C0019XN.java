package abcd;

public class C0019XN extends Exception {

    Exception f74j6;

    public C0019XN(String str, Exception exc) {
        super(str);
        this.f74j6 = exc;
    }

    @Override
    public Throwable getCause() {
        return this.f74j6;
    }
}
