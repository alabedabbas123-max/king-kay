package abcd;

import com.aide.common.u;
import com.aide.ui.U;

@xu
public class C0020_f implements InterfaceC0026_l, Wl {

    @uu
    private static boolean f148DW;

    @tu
    private static boolean f149j6;

    static {
        wu.j6(C0020_f.class, 159627396122716900L, 159627396122716900L);
    }

    public C0020_f() {
        try {
            if (f149j6) {
                wu.j6(3777433522515034380L, (Object) null);
            }
        } catch (Throwable th) {
            if (f148DW) {
                wu.j6(th, 3777433522515034380L, (Object) null);
            }
            throw th;
        }
    }

    public u m180FH() {
        try {
            if (f149j6) {
                wu.j6(-1315197207611726208L, this);
            }
            return new u(42, false, true, false);
        } catch (Throwable th) {
            if (f148DW) {
                wu.j6(th, -1315197207611726208L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f149j6) {
                return "GoTo Line";
            }
            wu.j6(1970667451257564235L, this);
            return "GoTo Line";
        } catch (Throwable th) {
            if (f148DW) {
                wu.j6(th, 1970667451257564235L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f149j6) {
                wu.j6(-342945233979105285L, this);
            }
            return U.er().tp();
        } catch (Throwable th) {
            if (f148DW) {
                wu.j6(th, -342945233979105285L, this);
            }
            throw th;
        }
    }

    public int m181j6() {
        try {
            if (!f149j6) {
                return com.aide.pro.R.id.mainMenuGotoLine;
            }
            wu.j6(4511260786745788677L, this);
            return com.aide.pro.R.id.mainMenuGotoLine;
        } catch (Throwable th) {
            if (f148DW) {
                wu.j6(th, 4511260786745788677L, this);
            }
            throw th;
        }
    }

    @Override
    public boolean mo178j6(boolean z) {
        try {
            if (f149j6) {
                wu.j6(-801918321579619911L, this, z);
            }
            return !U.lg().rN();
        } catch (Throwable th) {
            if (f148DW) {
                wu.j6(th, -801918321579619911L, this, new Boolean(z));
            }
            throw th;
        }
    }

    public boolean m182run() {
        try {
            if (f149j6) {
                wu.j6(1409053148001329289L, this);
            }
            U.lg().cn();
            return true;
        } catch (Throwable th) {
            if (f148DW) {
                wu.j6(th, 1409053148001329289L, this);
            }
            throw th;
        }
    }
}
