package abcd;

import com.appfour.backbone.api.closures.OnEnterClosure0;
import com.appfour.backbone.api.objects.EventData;

class C0016Ku implements jv {

    final OnEnterClosure0 f89DW;

    final Vu f90FH;

    final long f91j6;

    C0016Ku(Vu vu, long j, OnEnterClosure0 onEnterClosure0) {
        this.f90FH = vu;
        this.f91j6 = j;
        this.f89DW = onEnterClosure0;
    }

    public EventData m123j6(Object[] objArr) {
        Object objJ6 = Ev.j6(objArr[0], this.f91j6);
        return C0102Mv.m546XL().j6(objJ6, new Ju(this, objJ6));
    }
}
