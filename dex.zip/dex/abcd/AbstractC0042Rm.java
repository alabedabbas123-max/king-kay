package abcd;

public abstract class AbstractC0042Rm extends hu implements lu {
    protected AbstractC0042Rm(boolean z) {
        super(z);
    }

    public abstract void mo267DW(C0006Qs c0006Qs);

    public abstract InterfaceC0048Rs mo268get(int i);

    public abstract AbstractC0042Rm mo269j6(AbstractC0042Rm abstractC0042Rm);

    public abstract C0085Sm mo270j6(AbstractC0042Rm abstractC0042Rm, int i);

    public abstract void mo271j6(int i, InterfaceC0048Rs interfaceC0048Rs);

    public abstract void mo272j6(Vt vt);

    public abstract void mo273j6(bs bsVar);

    public abstract AbstractC0042Rm mo274lg();

    protected abstract Vm mo275rN();
}
