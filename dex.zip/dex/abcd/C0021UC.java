package abcd;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Collection;
import org.eclipse.jgit.JGitText;

public class C0021UC extends IOException {

    private final Collection<yE> f46DW;

    private final C0108WD f47j6;

    public C0021UC(C0108WD c0108wd, Collection<yE> collection) {
        super(MessageFormat.format(JGitText.j6().ambiguousObjectAbbreviation, c0108wd.m647Hw()));
        this.f47j6 = c0108wd;
        this.f46DW = collection;
    }
}
