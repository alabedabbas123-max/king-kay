package abcd;

class C0016vA implements tA {
    C0016vA() {
    }

    public void m72DW(String str) {
    }

    public void m73FH(String str) {
    }

    public void m74Hw(String str) {
    }

    public boolean isDebugEnabled() {
        return false;
    }

    public void m75j6(String str) {
    }

    public void m76j6(String str, Throwable th) {
    }
}
