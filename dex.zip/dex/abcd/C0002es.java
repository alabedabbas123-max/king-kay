package abcd;

public final class C0002es {

    private final Qs f42DW;

    private final Ss f43FH;

    private final Ss f44Hw;

    private final String f45VH;

    private final boolean f46Zo;

    private final int f47j6;

    private final int f48v5;

    public C0002es(int i, Qs qs, Ss ss, int i2, String str) {
        this(i, qs, ss, Ps.FH, i2, false, str);
    }

    public C0002es(int i, Qs qs, Ss ss, Ss ss2, int i2, boolean z, String str) {
        if (qs == null) {
            throw new NullPointerException("result == null");
        }
        if (ss == null) {
            throw new NullPointerException("sources == null");
        }
        if (ss2 == null) {
            throw new NullPointerException("exceptions == null");
        }
        if (i2 < 1 || i2 > 6) {
            throw new IllegalArgumentException("bogus branchingness");
        }
        if (ss2.size() != 0 && i2 != 6) {
            throw new IllegalArgumentException("exceptions / branchingness mismatch");
        }
        this.f47j6 = i;
        this.f42DW = qs;
        this.f43FH = ss;
        this.f44Hw = ss2;
        this.f48v5 = i2;
        this.f46Zo = z;
        this.f45VH = str;
    }

    public C0002es(int i, Qs qs, Ss ss, Ss ss2, String str) {
        this(i, qs, ss, ss2, 6, false, str);
    }

    public C0002es(int i, Qs qs, Ss ss, String str) {
        this(i, qs, ss, Ps.FH, 1, false, str);
    }

    public C0002es(int i, Ss ss, Ss ss2) {
        this(i, Qs.tp, ss, ss2, 6, true, null);
    }

    public int m0DW() {
        return this.f48v5;
    }

    public String m1FH() {
        String str = this.f45VH;
        return str != null ? str : toString();
    }

    public int m2Hw() {
        return this.f47j6;
    }

    public boolean m3VH() {
        return this.f46Zo;
    }

    public Ss m4Zo() {
        return this.f43FH;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0002es)) {
            return false;
        }
        C0002es c0002es = (C0002es) obj;
        return this.f47j6 == c0002es.f47j6 && this.f48v5 == c0002es.f48v5 && this.f42DW == c0002es.f42DW && this.f43FH.equals(c0002es.f43FH) && this.f44Hw.equals(c0002es.f44Hw);
    }

    public boolean m5gn() {
        int i = this.f47j6;
        if (i == 14 || i == 16) {
            return true;
        }
        switch (i) {
            case 20:
            case 21:
            case 22:
                return true;
            default:
                return false;
        }
    }

    public int hashCode() {
        return (((((((this.f47j6 * 31) + this.f48v5) * 31) + this.f42DW.hashCode()) * 31) + this.f43FH.hashCode()) * 31) + this.f44Hw.hashCode();
    }

    public final boolean m6j6() {
        return this.f44Hw.size() != 0;
    }

    public String toString() {
        StringBuffer stringBuffer = new StringBuffer(40);
        stringBuffer.append("Rop{");
        stringBuffer.append(_r.DW(this.f47j6));
        if (this.f42DW != Qs.tp) {
            stringBuffer.append(" ");
            stringBuffer.append(this.f42DW);
        } else {
            stringBuffer.append(" .");
        }
        stringBuffer.append(" <-");
        int size = this.f43FH.size();
        if (size == 0) {
            stringBuffer.append(" .");
        } else {
            for (int i = 0; i < size; i++) {
                stringBuffer.append(' ');
                stringBuffer.append(this.f43FH.getType(i));
            }
        }
        if (this.f46Zo) {
            stringBuffer.append(" call");
        }
        int size2 = this.f44Hw.size();
        if (size2 != 0) {
            stringBuffer.append(" throws");
            for (int i2 = 0; i2 < size2; i2++) {
                stringBuffer.append(' ');
                if (this.f44Hw.getType(i2) == Qs.j3) {
                    stringBuffer.append("<any>");
                } else {
                    stringBuffer.append(this.f44Hw.getType(i2));
                }
            }
        } else {
            int i3 = this.f48v5;
            if (i3 == 1) {
                stringBuffer.append(" flows");
            } else if (i3 == 2) {
                stringBuffer.append(" returns");
            } else if (i3 == 3) {
                stringBuffer.append(" gotos");
            } else if (i3 == 4) {
                stringBuffer.append(" ifs");
            } else if (i3 != 5) {
                stringBuffer.append(" " + Yt.Hw(this.f48v5));
            } else {
                stringBuffer.append(" switches");
            }
        }
        stringBuffer.append('}');
        return stringBuffer.toString();
    }

    public Qs m7v5() {
        return this.f42DW;
    }
}
