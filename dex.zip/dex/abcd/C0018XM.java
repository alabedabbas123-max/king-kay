package abcd;

public class C0018XM extends yL implements pL {

    private qL f73j6;

    public C0018XM(AL al) {
        this.f73j6 = new yM(false, 0, al);
    }

    public C0018XM(EL el) {
        this.f73j6 = el;
    }

    public C0018XM(VM vm) {
        this.f73j6 = vm;
    }

    public static C0018XM m105j6(Object obj) {
        if (obj == null || (obj instanceof C0018XM)) {
            return (C0018XM) obj;
        }
        if (obj instanceof VM) {
            return new C0018XM((VM) obj);
        }
        if (obj instanceof AL) {
            return new C0018XM((AL) obj);
        }
        if (obj instanceof EL) {
            return new C0018XM((EL) obj);
        }
        throw new IllegalArgumentException("Illegal object in SignerIdentifier: " + obj.getClass().getName());
    }

    public EL m106DW() {
        return this.f73j6.DW();
    }

    public boolean m107v5() {
        return this.f73j6 instanceof LL;
    }
}
