package abcd;

enum C0014Hq extends er {
    C0014Hq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
