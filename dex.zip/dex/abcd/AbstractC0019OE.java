package abcd;

import java.util.Map;

public abstract class AbstractC0019OE {

    protected static final String[] f61j6 = {"", "refs/", "refs/tags/", "refs/heads/", "refs/remotes/"};

    public abstract Map<String, ME> m91DW(String str);

    public abstract void m92DW();

    public abstract boolean m93FH(String str);

    public abstract ME m94j6(ME me);

    public abstract ME m95j6(String str);

    public abstract RE m96j6(String str, boolean z);

    public abstract void m97j6();
}
