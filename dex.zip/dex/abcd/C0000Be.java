package abcd;

import com.aide.common.h;
import groovyjarjarantlr.collections.AST;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import org.codehaus.groovy.antlr.SourceBuffer;
import org.codehaus.groovy.antlr.UnicodeEscapingReader;
import org.codehaus.groovy.antlr.parser.GroovyLexer;
import org.codehaus.groovy.antlr.parser.GroovyRecognizer;

@xu
public class C0000Be extends Si<C0000Be> {

    @uu
    private static boolean f0VH;

    @tu
    private static boolean f1Zo;

    public int f2EQ;

    public List<i> f3J0;

    public List<i> f4J8;

    public h f5Mr;

    public int f6QX;

    public Map<String, j> f7U2;

    public List<i> f8Ws;

    public List<b> f9XL;

    public List<b> f10aM;

    public String f11gn;

    public List<b> f12j3;

    public int f13tp;

    public a f14u7;

    public SortedMap<String, a> f15we;

    static {
        wu.j6(C0000Be.class, 1286736540757565680L, 1286736540757565680L);
    }

    public C0000Be() {
        try {
            if (f1Zo) {
                wu.j6(4295612260233985280L, (Object) null);
            }
            this.f14u7 = new a(this);
            this.f13tp = -1;
            this.f2EQ = -1;
            this.f15we = new TreeMap();
            this.f3J0 = new ArrayList();
            this.f4J8 = new ArrayList();
            this.f8Ws = new ArrayList();
            this.f6QX = -1;
            this.f9XL = new ArrayList();
            this.f10aM = new ArrayList();
            this.f12j3 = new ArrayList();
            this.f7U2 = new HashMap();
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 4295612260233985280L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -100839688189588600L)
    private C0000Be(String str) {
        try {
            if (f1Zo) {
                wu.j6(-2071928834764619200L, (Object) null, str);
            }
            this.f14u7 = new a(this);
            this.f13tp = -1;
            this.f2EQ = -1;
            this.f15we = new TreeMap();
            this.f3J0 = new ArrayList();
            this.f4J8 = new ArrayList();
            this.f8Ws = new ArrayList();
            this.f6QX = -1;
            this.f9XL = new ArrayList();
            this.f10aM = new ArrayList();
            this.f12j3 = new ArrayList();
            this.f7U2 = new HashMap();
            try {
                FileReader fileReader = new FileReader(str);
                SourceBuffer sourceBuffer = new SourceBuffer();
                UnicodeEscapingReader unicodeEscapingReader = new UnicodeEscapingReader(fileReader, sourceBuffer);
                GroovyLexer groovyLexer = new GroovyLexer(unicodeEscapingReader);
                unicodeEscapingReader.j6(groovyLexer);
                GroovyRecognizer groovyRecognizerJ6 = GroovyRecognizer.j6(groovyLexer);
                groovyRecognizerJ6.j6(sourceBuffer);
                groovyRecognizerJ6.cb();
                fileReader.close();
                for (AST astDW = groovyRecognizerJ6.DW(); astDW != null; astDW = m10Zo(astDW)) {
                    m6FH(astDW, "");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -2071928834764619200L, (Object) null, str);
            }
            throw th;
        }
    }

    @su(method = -7179625226708456205L)
    private int m0DW(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(-5329485076578877016L, this, ast);
            }
            AST astM10Zo = m10Zo(m22v5(m22v5(ast)));
            return astM10Zo == null ? ast.aM() : astM10Zo.aM();
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -5329485076578877016L, this, ast);
            }
            throw th;
        }
    }

    @su(method = -1354111218991793795L)
    private String m1DW(String str, int i) {
        try {
            if (f1Zo) {
                wu.j6(569395112634206592L, this, str, new Integer(i));
            }
            String[] strArrSplit = str.split("\\.");
            if (strArrSplit.length <= i) {
                return null;
            }
            String str2 = "";
            for (int i2 = i; i2 < strArrSplit.length; i2++) {
                if (str2.length() > 0) {
                    str2 = str2 + ".";
                }
                str2 = str2 + strArrSplit[i2];
            }
            return str2;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 569395112634206592L, this, str, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -51819695781453060L)
    private Map<String, String> m2DW(AST ast, String str) {
        try {
            if (f1Zo) {
                wu.j6(-7706120763755659553L, this, ast, str);
            }
            AST astM10Zo = m10Zo(m22v5(m22v5(ast)));
            if (m21u7(astM10Zo) != 33 || m21u7(m22v5(astM10Zo)) != 27 || !str.equals(m11gn(m22v5(m22v5(astM10Zo))))) {
                return null;
            }
            HashMap map = new HashMap();
            for (AST astM22v5 = m22v5(m10Zo(m22v5(m22v5(astM10Zo)))); astM22v5 != null; astM22v5 = m10Zo(astM22v5)) {
                if (m21u7(astM22v5) == 54) {
                    String strM11gn = m11gn(m22v5(astM22v5));
                    AST astM22v6 = m22v5(m10Zo(m22v5(astM22v5)));
                    if (m21u7(astM22v6) == 57) {
                        map.put(strM11gn, m11gn(m22v5(m22v5(m22v5(astM22v6)))));
                    } else {
                        map.put(strM11gn, m11gn(astM22v6));
                    }
                }
            }
            return map;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -7706120763755659553L, this, ast, str);
            }
            throw th;
        }
    }

    @su(method = -1006810929411975240L)
    private void m3DW(AST ast, String str, int i) {
        try {
            if (f1Zo) {
                wu.j6(-706228985396337313L, this, ast, str, new Integer(i));
            }
            String strM13j6 = m13j6(str, i);
            if (!this.f7U2.containsKey(strM13j6)) {
                this.f7U2.put(strM13j6, new j(this));
            }
            String strM1DW = m1DW(str, i + 1);
            if (strM1DW != null) {
                m17j6(ast, strM1DW, this.f7U2.get(strM13j6));
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -706228985396337313L, this, ast, str, new Integer(i));
            }
            throw th;
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @su(method = -843716835962748865L)
    private void m4DW(AST ast, String str, List<i> list) {
        try {
            if (f1Zo) {
                wu.j6(5378452948754511368L, this, ast, str, list);
            }
            list.add(new m(ast.aM(), "https://dl.google.com/dl/android/maven2"));
            byte b = -1;
            switch (str.hashCode()) {
                case -1844260212:
                    if (str.equals("maven.url")) {
                        b = 3;
                    }
                    break;
                case -1777904321:
                    if (str.equals("jcenter")) {
                        b = 1;
                    }
                    break;
                case -1349030688:
                    if (str.equals("flatDir.dirs")) {
                        b = 2;
                    }
                    break;
                case -138026646:
                    if (str.equals("mavenCentral")) {
                        b = 0;
                    }
                    break;
            }
            if (b == 0) {
                list.add(new m(ast.aM(), "http://repo.maven.apache.org/maven2"));
                return;
            }
            if (b == 1) {
                list.add(new m(ast.aM(), "https://jcenter.bintray.com"));
                return;
            }
            if (b != 2) {
                if (b != 3) {
                    return;
                }
                list.add(new m(ast.aM(), m7Hw(ast)));
            } else {
                e eVar = new e(ast.aM());
                eVar.gn = m7Hw(ast);
                list.add(eVar);
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 5378452948754511368L, this, ast, str, list);
            }
            throw th;
        }
    }

    @su(method = -1646303968781143888L)
    private String m5FH(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(231631582846535895L, this, ast);
            }
            if (m21u7(ast) != 28) {
                return null;
            }
            if (m21u7(m22v5(ast)) == 27 || m21u7(m22v5(ast)) == 124) {
                return m9VH(m22v5(m22v5(ast)));
            }
            return null;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 231631582846535895L, this, ast);
            }
            throw th;
        }
    }

    @su(method = 8822841499678421313L)
    private void m6FH(AST ast, String str) {
        try {
            if (f1Zo) {
                wu.j6(618915073926966824L, this, ast, str);
            }
            String strM5FH = m5FH(ast);
            if (strM5FH == null) {
                return;
            }
            if (str.length() != 0) {
                strM5FH = str + "." + strM5FH;
            }
            switch (strM5FH) {
                case "android":
                case "model.android":
                    this.f13tp = m0DW(ast);
                    break;
                case "android.compileSdkVersion":
                case "model.android.compileSdkVersion":
                    this.f11gn = m7Hw(ast);
                    break;
                case "android.productFlavors":
                case "model.android.productFlavors":
                    this.f2EQ = m0DW(ast);
                    break;
                case "dependencies":
                    this.f6QX = m0DW(ast);
                    break;
                default:
                    if (m20j6(strM5FH, "android.defaultConfig")) {
                        m16j6(ast, m1DW(strM5FH, 2), this.f14u7);
                        break;
                    } else {
                        if (m20j6(strM5FH, "model.android.defaultConfig")) {
                            m16j6(ast, m1DW(strM5FH, 3), this.f14u7);
                        } else if (m20j6(strM5FH, "model.android.defaultConfig.with")) {
                            m16j6(ast, m1DW(strM5FH, 4), this.f14u7);
                        } else if (m20j6(strM5FH, "android.productFlavors")) {
                            m15j6(ast, strM5FH, 2);
                        } else if (m20j6(strM5FH, "model.android.productFlavors")) {
                            m15j6(ast, strM5FH, 3);
                        } else if (m20j6(strM5FH, "android.signingConfigs")) {
                            m3DW(ast, strM5FH, 2);
                        } else if (m20j6(strM5FH, "model.android.signingConfigs")) {
                            m3DW(ast, strM5FH, 3);
                        } else if (m20j6(strM5FH, "dependencies")) {
                            m18j6(ast, m1DW(strM5FH, 1), this.f9XL);
                        } else if (m20j6(strM5FH, "subprojects.dependencies")) {
                            m18j6(ast, m1DW(strM5FH, 2), this.f10aM);
                        } else if (m20j6(strM5FH, "allprojects.dependencies")) {
                            m18j6(ast, m1DW(strM5FH, 2), this.f12j3);
                        } else if (m20j6(strM5FH, "repositories")) {
                            m4DW(ast, m1DW(strM5FH, 1), this.f3J0);
                        } else if (m20j6(strM5FH, "subprojects.repositories")) {
                            m4DW(ast, m1DW(strM5FH, 2), this.f8Ws);
                        } else if (m20j6(strM5FH, "allprojects.repositories")) {
                            m4DW(ast, m1DW(strM5FH, 2), this.f4J8);
                        }
                        break;
                    }
                    break;
            }
            Iterator<AST> it = m14j6(ast).iterator();
            while (it.hasNext()) {
                m6FH(it.next(), strM5FH);
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 618915073926966824L, this, ast, str);
            }
            throw th;
        }
    }

    @su(method = 158827010830106073L)
    private String m7Hw(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(-5866436128366238416L, this, ast);
            }
            AST astM10Zo = m10Zo(m22v5(m22v5(ast)));
            if (m21u7(astM10Zo) != 88 && m21u7(astM10Zo) != 199) {
                if (m21u7(astM10Zo) == 33) {
                    return m21u7(m22v5(astM10Zo)) == 28 ? m11gn(m22v5(m22v5(astM10Zo))) : m11gn(m22v5(astM10Zo));
                }
                return null;
            }
            return m11gn(astM10Zo);
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -5866436128366238416L, this, ast);
            }
            throw th;
        }
    }

    @su(method = 4656644305554862080L)
    private void m8J0(String str) {
        try {
            if (f1Zo) {
                wu.j6(-94593132100887129L, this, str);
            }
            m19j6("\t" + str, "dependencies", this.f6QX);
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -94593132100887129L, this, str);
            }
            throw th;
        }
    }

    @su(method = -1936096713192763212L)
    private String m9VH(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(-4327957185510312655L, this, ast);
            }
            if (m21u7(ast) != 90) {
                return m11gn(ast);
            }
            AST astM22v5 = m22v5(ast);
            return m9VH(astM22v5) + "." + m11gn(m10Zo(astM22v5));
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -4327957185510312655L, this, ast);
            }
            throw th;
        }
    }

    @su(method = 3889559935012124376L)
    private static AST m10Zo(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(3204003455159863735L, (Object) null, ast);
            }
            if (ast == null) {
                return null;
            }
            return ast.getNextSibling();
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 3204003455159863735L, (Object) null, ast);
            }
            throw th;
        }
    }

    @su(method = 326642875763936100L)
    private static String m11gn(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(-7055095270116926989L, (Object) null, ast);
            }
            if (ast == null) {
                return null;
            }
            return ast.getText();
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -7055095270116926989L, (Object) null, ast);
            }
            throw th;
        }
    }

    @su(method = 6059247112536834789L)
    private String m12j6(AST ast, String str) {
        try {
            if (f1Zo) {
                wu.j6(3295877861031193600L, this, ast, str);
            }
            AST astM10Zo = m10Zo(m22v5(m22v5(ast)));
            if (m21u7(astM10Zo) != 33 || m21u7(m22v5(astM10Zo)) != 27 || !str.equals(m11gn(m22v5(m22v5(astM10Zo))))) {
                return null;
            }
            AST astM22v5 = m22v5(m10Zo(m22v5(m22v5(astM10Zo))));
            if (m21u7(astM22v5) == 28) {
                return m11gn(m22v5(astM22v5));
            }
            return null;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 3295877861031193600L, this, ast, str);
            }
            throw th;
        }
    }

    @su(method = -3620299408080907057L)
    private String m13j6(String str, int i) {
        try {
            if (f1Zo) {
                wu.j6(-2348781690214816884L, this, str, new Integer(i));
            }
            String[] strArrSplit = str.split("\\.");
            if (strArrSplit.length > i) {
                return strArrSplit[i];
            }
            return null;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -2348781690214816884L, this, str, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -4304460119280255676L)
    private List<AST> m14j6(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(4000950265450891585L, this, ast);
            }
            ArrayList arrayList = new ArrayList();
            for (AST astM22v5 = m22v5(m10Zo(m22v5(m22v5(ast)))); astM22v5 != null; astM22v5 = m10Zo(astM22v5)) {
                if (m21u7(astM22v5) == 28) {
                    arrayList.add(astM22v5);
                }
            }
            return arrayList;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 4000950265450891585L, this, ast);
            }
            throw th;
        }
    }

    @su(method = 125017814798993571L)
    private void m15j6(AST ast, String str, int i) {
        try {
            if (f1Zo) {
                wu.j6(6367764524688151200L, this, ast, str, new Integer(i));
            }
            String strM13j6 = m13j6(str, i);
            if (!this.f15we.containsKey(strM13j6)) {
                this.f15we.put(strM13j6, new a(this));
            }
            String strM1DW = m1DW(str, i + 1);
            if (strM1DW != null) {
                m16j6(ast, strM1DW, this.f15we.get(strM13j6));
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 6367764524688151200L, this, ast, str, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 420219240647807157L)
    private void m16j6(AST ast, String str, a aVar) {
        try {
            if (f1Zo) {
                wu.j6(3793982689365377336L, this, ast, str, aVar);
            }
            switch (str) {
                case "minSdkVersion":
                case "minSdkVersion.apiLevel":
                    aVar.FH = m7Hw(ast);
                    return;
                case "targetSdkVersion":
                case "targetSdkVersion.apiLevel":
                    aVar.Hw = m7Hw(ast);
                    return;
                case "versionCode":
                    aVar.Zo = m7Hw(ast);
                    return;
                case "versionName":
                    aVar.v5 = m7Hw(ast);
                    return;
                case "packageName":
                    aVar.VH = m7Hw(ast);
                    return;
                case "applicationId":
                    aVar.VH = m7Hw(ast);
                    return;
                case "multiDexEnabled":
                    aVar.gn = m7Hw(ast);
                    return;
                default:
                    return;
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 3793982689365377336L, this, ast, str, aVar);
            }
            throw th;
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @su(method = 500282480585286583L)
    private void m17j6(AST ast, String str, j jVar) {
        try {
            if (f1Zo) {
                wu.j6(-4378578537138425604L, this, ast, str, jVar);
            }
            byte b = -1;
            switch (str.hashCode()) {
                case -996366692:
                    if (str.equals("storePassword")) {
                        b = 3;
                    }
                    break;
                case -45289958:
                    if (str.equals("keyPassword")) {
                        b = 2;
                    }
                    break;
                case 473180977:
                    if (str.equals("keyAlias")) {
                        b = 1;
                    }
                    break;
                case 1691552253:
                    if (str.equals("storeFile")) {
                        b = 0;
                    }
                    break;
            }
            if (b == 0) {
                jVar.FH = m12j6(ast, "file");
                return;
            }
            if (b == 1) {
                jVar.Hw = m7Hw(ast);
            } else if (b == 2) {
                jVar.v5 = m7Hw(ast);
            } else {
                if (b != 3) {
                    return;
                }
                jVar.Zo = m7Hw(ast);
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -4378578537138425604L, this, ast, str, jVar);
            }
            throw th;
        }
    }

    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    @su(method = 2385861603729716480L)
    private void m18j6(AST ast, String str, List<b> list) {
        Map<String, String> mapM2DW;
        try {
            if (f1Zo) {
                wu.j6(-5517500361644114175L, this, ast, str, list);
            }
            byte b = -1;
            switch (str.hashCode()) {
                case -1913967790:
                    if (str.equals("androidTestCompile")) {
                        b = 2;
                    }
                    break;
                case 96794:
                    if (str.equals("api")) {
                        b = 4;
                    }
                    break;
                case 557892929:
                    if (str.equals("testCompile")) {
                        b = 1;
                    }
                    break;
                case 950491699:
                    if (str.equals("compile")) {
                        b = 5;
                    }
                    break;
                case 1223343650:
                    if (str.equals("wearApp")) {
                        b = 0;
                    }
                    break;
                case 1683336114:
                    if (str.equals("implementation")) {
                        b = 3;
                    }
                    break;
            }
            if (b == 0) {
                String strM12j6 = m12j6(ast, "project");
                if (strM12j6 == null && (mapM2DW = m2DW(ast, "project")) != null && mapM2DW.containsKey("path")) {
                    strM12j6 = mapM2DW.get("path");
                }
                if (strM12j6 == null) {
                    list.add(new l(ast.aM()));
                    return;
                } else {
                    this.f5Mr = new h(ast.aM());
                    this.f5Mr.gn = strM12j6;
                    return;
                }
            }
            if (b == 1 || b == 2) {
                list.add(new k(ast.aM()));
                return;
            }
            if (b != 3 && b != 4 && b != 5) {
                list.add(new l(ast.aM()));
                return;
            }
            String strM12j7 = m12j6(ast, "project");
            if (strM12j7 != null) {
                h hVar = new h(ast.aM());
                list.add(hVar);
                hVar.gn = strM12j7;
                return;
            }
            String strM12j8 = m12j6(ast, "files");
            if (strM12j8 != null) {
                c cVar = new c(ast.aM());
                list.add(cVar);
                cVar.gn = strM12j8;
                return;
            }
            Map<String, String> mapM2DW2 = m2DW(ast, "fileTree");
            if (mapM2DW2 != null) {
                d dVar = new d(ast.aM());
                list.add(dVar);
                dVar.gn = mapM2DW2.get("dir");
                dVar.u7 = mapM2DW2.get("include");
                return;
            }
            String strM7Hw = m7Hw(ast);
            if (strM7Hw == null) {
                list.add(new l(ast.aM()));
                return;
            }
            g gVar = new g(ast.aM());
            list.add(gVar);
            gVar.we = strM7Hw;
            String[] strArrSplit = strM7Hw.split(":");
            if (strArrSplit.length > 0) {
                gVar.gn = strArrSplit[0];
            }
            if (strArrSplit.length > 1) {
                gVar.u7 = strArrSplit[1];
            }
            if (strArrSplit.length > 2) {
                String str2 = strArrSplit[2];
                if (str2.indexOf("@") < 0) {
                    gVar.tp = str2;
                } else {
                    gVar.tp = str2.substring(0, str2.indexOf("@"));
                    gVar.EQ = str2.substring(str2.indexOf("@") + 1);
                }
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -5517500361644114175L, this, ast, str, list);
            }
            throw th;
        }
    }

    @su(method = 4597366328078322465L)
    private void m19j6(String str, String str2, int i) {
        try {
            if (f1Zo) {
                wu.j6(-1919821800456425772L, this, str, str2, new Integer(i));
            }
            try {
                ArrayList arrayList = new ArrayList();
                BufferedReader bufferedReader = new BufferedReader(new FileReader(((Si) this).v5));
                int i2 = 1;
                while (true) {
                    String line = bufferedReader.readLine();
                    if (line == null) {
                        break;
                    }
                    arrayList.add(line);
                    if (i2 == i) {
                        arrayList.add(str);
                    }
                    i2++;
                }
                if (i < 0) {
                    arrayList.add(str2 + " {");
                    arrayList.add(str);
                    arrayList.add("}");
                }
                bufferedReader.close();
                FileWriter fileWriter = new FileWriter(((Si) this).v5);
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    fileWriter.write((String) it.next());
                    fileWriter.write("\n");
                }
                fileWriter.close();
            } catch (IOException e) {
                h.DW(e);
            }
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -1919821800456425772L, this, str, str2, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 619002590164349040L)
    private boolean m20j6(String str, String str2) {
        try {
            if (f1Zo) {
                wu.j6(360695396428775855L, this, str, str2);
            }
            return str.startsWith(str2 + ".");
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 360695396428775855L, this, str, str2);
            }
            throw th;
        }
    }

    @su(method = -481899317211900245L)
    private static int m21u7(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(2929658879113422528L, (Object) null, ast);
            }
            if (ast == null) {
                return 0;
            }
            return ast.getType();
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 2929658879113422528L, (Object) null, ast);
            }
            throw th;
        }
    }

    @su(method = 3184165110682800923L)
    private static AST m22v5(AST ast) {
        try {
            if (f1Zo) {
                wu.j6(2418502154847056660L, (Object) null, ast);
            }
            if (ast == null) {
                return null;
            }
            return ast.getFirstChild();
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 2418502154847056660L, (Object) null, ast);
            }
            throw th;
        }
    }

    @su(method = 223896890801975035L)
    public C0000Be m24DW(String str) {
        try {
            if (f1Zo) {
                wu.j6(-6829940143184617536L, this, str);
            }
            return new C0000Be(str);
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -6829940143184617536L, this, str);
            }
            throw th;
        }
    }

    public String m25EQ(String str) {
        try {
            if (f1Zo) {
                wu.j6(-4814713408812496720L, this, str);
            }
            return (str == null || !this.f15we.containsKey(str) || this.f15we.get(str).v5 == null) ? this.f14u7.v5 : this.f15we.get(str).v5;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -4814713408812496720L, this, str);
            }
            throw th;
        }
    }

    public void m26FH(String str) {
        try {
            if (f1Zo) {
                wu.j6(-2676146857279896627L, this, str);
            }
            m8J0("api project('" + (":" + Vl.FH(Vl.EQ(Vl.EQ(((Si) this).v5)), str).replace("/", ":")) + "')");
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -2676146857279896627L, this, str);
            }
            throw th;
        }
    }

    public void m27Hw(String str) {
        try {
            if (f1Zo) {
                wu.j6(6030914371349911640L, this, str);
            }
            m8J0("api '" + str + "'");
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 6030914371349911640L, this, str);
            }
            throw th;
        }
    }

    public String m28VH(String str) {
        try {
            if (f1Zo) {
                wu.j6(-4314136344502868299L, this, str);
            }
            return (str == null || !this.f15we.containsKey(str) || this.f15we.get(str).FH == null) ? this.f14u7.FH : this.f15we.get(str).FH;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -4314136344502868299L, this, str);
            }
            throw th;
        }
    }

    public String m29Zo(String str) {
        try {
            if (f1Zo) {
                wu.j6(3564388611711902876L, this, str);
            }
            return (str == null || !this.f15we.containsKey(str) || this.f15we.get(str).VH == null) ? this.f14u7.VH : this.f15we.get(str).VH;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 3564388611711902876L, this, str);
            }
            throw th;
        }
    }

    public j m30gn(String str) {
        try {
            if (f1Zo) {
                wu.j6(5849870081758724140L, this, str);
            }
            if (str == null) {
                return null;
            }
            return this.f7U2.get(str);
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 5849870081758724140L, this, str);
            }
            throw th;
        }
    }

    public String m31tp(String str) {
        try {
            if (f1Zo) {
                wu.j6(73518745279428840L, this, str);
            }
            return (str == null || !this.f15we.containsKey(str) || this.f15we.get(str).Zo == null) ? this.f14u7.Zo : this.f15we.get(str).Zo;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 73518745279428840L, this, str);
            }
            throw th;
        }
    }

    public String m32u7(String str) {
        try {
            if (f1Zo) {
                wu.j6(3477512129983491552L, this, str);
            }
            return (str == null || !this.f15we.containsKey(str) || this.f15we.get(str).Hw == null) ? this.f14u7.Hw : this.f15we.get(str).Hw;
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, 3477512129983491552L, this, str);
            }
            throw th;
        }
    }

    public void m33v5(String str) {
        try {
            if (f1Zo) {
                wu.j6(-419629430739220605L, this, str);
            }
            String str2 = "\t\t" + str + " {\n\t\t}";
            if (this.f2EQ != -1) {
                m19j6(str2, "", this.f2EQ);
                return;
            }
            m19j6("\tproductFlavors {\n" + str2 + "\n\t}\n", "android", this.f13tp);
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -419629430739220605L, this, str);
            }
            throw th;
        }
    }

    public boolean m34we(String str) {
        try {
            if (f1Zo) {
                wu.j6(-4021315468514186808L, this, str);
            }
            return (str == null || !this.f15we.containsKey(str) || this.f15we.get(str).gn == null) ? "true".equals(this.f14u7.gn) : "true".equals(this.f15we.get(str).gn);
        } catch (Throwable th) {
            if (f0VH) {
                wu.j6(th, -4021315468514186808L, this, str);
            }
            throw th;
        }
    }
}
