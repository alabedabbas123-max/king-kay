package abcd;

import com.appfour.backbone.api.define.DefineHook;
import com.appfour.backbone.api.define.DefineHookRuntime;
import com.appfour.backbone.api.objects.EventData;

public abstract class AbstractC0042yu implements DefineHook, DefineHookRuntime {

    protected jv f219j6;

    public jv m312DW() {
        return this.f219j6;
    }

    protected abstract DefineHook m313j6();

    protected abstract void m314j6(long j, EventData eventData);

    protected abstract void m315j6(long j, Throwable th);
}
