package abcd;

import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;

public class C0023Ex {

    private static final ClassLoader f155j6 = C0023Ex.class.getClassLoader();

    private C0023Ex() {
    }

    public static <T extends Parcelable> T m269j6(Parcel parcel, Parcelable.Creator<T> creator) {
        if (parcel.readInt() == 0) {
            return null;
        }
        return creator.createFromParcel(parcel);
    }

    public static void m270j6(Parcel parcel, IInterface iInterface) {
        if (iInterface == null) {
            parcel.writeStrongBinder(null);
        } else {
            parcel.writeStrongBinder(iInterface.asBinder());
        }
    }

    public static void m271j6(Parcel parcel, Parcelable parcelable) {
        if (parcelable == null) {
            parcel.writeInt(0);
        } else {
            parcel.writeInt(1);
            parcelable.writeToParcel(parcel, 0);
        }
    }

    public static void m272j6(Parcel parcel, boolean z) {
        parcel.writeInt(z ? 1 : 0);
    }

    public static boolean m273j6(Parcel parcel) {
        return parcel.readInt() != 0;
    }
}
