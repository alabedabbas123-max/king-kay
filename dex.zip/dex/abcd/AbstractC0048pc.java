package abcd;

@xu
public abstract class AbstractC0048pc {

    @ru(field = -3872150778830458320L)
    private static AbstractC0048pc f456DW;

    @tu
    private static boolean f457FH;

    @uu
    private static boolean f458Hw;

    @ru(field = -822963041728163184L)
    private static Object f459j6;

    static {
        try {
            wu.j6(AbstractC0048pc.class, 6961425216133458609L, 6961425216133458609L);
            if (f457FH) {
                wu.j6(-1279487899409338355L, (Object) null);
            }
            f459j6 = new Object();
            f456DW = new C0005oc();
        } catch (Throwable th) {
            if (f458Hw) {
                wu.j6(th, -1279487899409338355L, (Object) null);
            }
            throw th;
        }
    }

    public AbstractC0048pc() {
        try {
            if (f457FH) {
                wu.j6(-3252117149220783907L, (Object) null);
            }
        } catch (Throwable th) {
            if (f458Hw) {
                wu.j6(th, -3252117149220783907L, (Object) null);
            }
            throw th;
        }
    }

    public static AbstractC0048pc m263j6() {
        AbstractC0048pc abstractC0048pc;
        try {
            if (f457FH) {
                wu.j6(3836405997313653904L, (Object) null);
            }
            synchronized (f459j6) {
                abstractC0048pc = f456DW;
            }
            return abstractC0048pc;
        } catch (Throwable th) {
            if (f458Hw) {
                wu.j6(th, 3836405997313653904L, (Object) null);
            }
            throw th;
        }
    }

    public abstract boolean mo20j6(String str, String str2);
}
