package abcd;

import java.security.PrivilegedAction;

class C0002oP implements PrivilegedAction {

    final C0045pP f30j6;

    C0002oP(C0045pP c0045pP) {
        this.f30j6 = c0045pP;
    }

    @Override
    public Object run() {
        this.f30j6.m200DW();
        return null;
    }
}
