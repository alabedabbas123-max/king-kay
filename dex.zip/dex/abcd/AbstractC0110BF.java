package abcd;

public abstract class AbstractC0110BF extends vF {
    public abstract CF m1019j6(UE ue);
}
