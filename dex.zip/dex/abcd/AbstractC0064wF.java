package abcd;

import java.io.IOException;
import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0064wF {

    protected final IE f139DW;

    protected final qG f140FH;

    private EE f141Hw;

    protected mG[] f142VH;

    protected dG[] f143Zo;

    protected final UE f144j6;

    protected iG[] f145v5;

    protected AbstractC0064wF(UE ue) {
        this.f144j6 = ue;
        this.f139DW = this.f144j6.j3();
        this.f140FH = new qG(this.f139DW);
    }

    protected TJ m257DW(int i, int i2) throws IOException, ZC {
        dG dGVarM263j6 = m263j6(i, i2);
        return dGVarM263j6 == null ? new VJ() : m262j6((YD) dGVarM263j6.yS());
    }

    public UE m258DW() {
        return this.f144j6;
    }

    public abstract yE m259FH();

    protected abstract boolean m260Hw();

    public EE m261j6() {
        if (this.f141Hw == null) {
            this.f141Hw = m258DW().aM();
        }
        return this.f141Hw;
    }

    protected TJ m262j6(YD yd) {
        return new UJ((byte[]) null, this.f139DW, yd);
    }

    public dG m263j6(int i, int i2) throws IOException, ZC {
        dG[] dGVarArr = this.f143Zo;
        if (dGVarArr[i] == null) {
            throw new ZC(this.f145v5[i], "commit");
        }
        if (dGVarArr[i2] == null) {
            throw new ZC(this.f145v5[i2], "commit");
        }
        this.f140FH.we();
        this.f140FH.j6(yG.Hw);
        this.f140FH.DW(this.f143Zo[i]);
        this.f140FH.DW(this.f143Zo[i2]);
        dG dGVarTp = this.f140FH.tp();
        if (dGVarTp == null) {
            return null;
        }
        dG dGVarTp2 = this.f140FH.tp();
        if (dGVarTp2 == null) {
            return dGVarTp;
        }
        throw new IOException(MessageFormat.format(JGitText.j6().multipleMergeBasesFor, this.f143Zo[i].we(), this.f143Zo[i2].we(), dGVarTp.we(), dGVarTp2.we()));
    }

    public boolean m264j6(YD... ydArr) {
        YD[] ydArr2;
        this.f145v5 = new iG[ydArr.length];
        int i = 0;
        for (int i2 = 0; i2 < ydArr.length; i2++) {
            this.f145v5[i2] = this.f140FH.Zo(ydArr[i2]);
        }
        this.f143Zo = new dG[this.f145v5.length];
        int i3 = 0;
        while (true) {
            ydArr2 = this.f145v5;
            if (i3 >= ydArr2.length) {
                break;
            }
            try {
                this.f143Zo[i3] = this.f140FH.VH(ydArr2[i3]);
            } catch (ZC unused) {
                this.f143Zo[i3] = null;
            }
            i3++;
        }
        this.f142VH = new mG[ydArr2.length];
        while (true) {
            YD[] ydArr3 = this.f145v5;
            if (i >= ydArr3.length) {
                try {
                    break;
                } finally {
                    EE ee = this.f141Hw;
                    if (ee != null) {
                        ee.Hw();
                    }
                    this.f139DW.FH();
                }
            }
            this.f142VH[i] = this.f140FH.gn(ydArr3[i]);
            i++;
        }
        boolean zM260Hw = m260Hw();
        if (zM260Hw && this.f141Hw != null) {
            this.f141Hw.FH();
        }
        return zM260Hw;
    }
}
