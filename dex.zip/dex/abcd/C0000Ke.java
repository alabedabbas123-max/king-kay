package abcd;

import com.aide.common.na;
import java.io.IOException;
import java.io.OutputStreamWriter;

@xu
public class C0000Ke {

    @uu
    private static boolean f0DW;

    @tu
    private static boolean f1j6;

    static {
        wu.j6(C0000Ke.class, 923036074386573539L, 923036074386573539L);
    }

    public C0000Ke() {
        try {
            if (f1j6) {
                wu.j6(-4224916339600595499L, (Object) null);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -4224916339600595499L, (Object) null);
            }
            throw th;
        }
    }

    public static String m0j6(String str) {
        try {
            if (f1j6) {
                wu.j6(1517005023151267440L, (Object) null, str);
            }
            return str + "/raw/wearable_app.apk";
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1517005023151267440L, (Object) null, str);
            }
            throw th;
        }
    }

    public static boolean m1j6(String str, String str2, String str3, String str4) {
        try {
            if (f1j6) {
                wu.j6(-437176524350347264L, (Object) null, str, str2, str3, str4);
            }
            String str5 = (((("<wearableApp package=\"" + str2 + "\">\n") + "\t<versionCode>" + str3 + "</versionCode>\n") + "\t<versionName>" + str4 + "</versionName>\n") + "\t<rawPathResId>wearable_app</rawPathResId>\n") + "</wearableApp>";
            try {
                OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new na(str + "/xml/wearable_app_desc.xml"));
                outputStreamWriter.write(str5);
                outputStreamWriter.close();
                return true;
            } catch (IOException e) {
                e.printStackTrace();
                return false;
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -437176524350347264L, (Object) null, str, str2, str3, str4);
            }
            throw th;
        }
    }
}
