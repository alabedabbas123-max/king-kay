package abcd;

class C0022RI implements b<C0065SI.a> {
    C0022RI() {
    }

    public C0065SI.a m204j6(gE gEVar) {
        return new C0065SI.a(gEVar);
    }
}
