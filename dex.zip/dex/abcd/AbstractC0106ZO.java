package abcd;

public abstract class AbstractC0106ZO {
    public static long m603DW(byte[] bArr, int i) {
        int iM606j6 = m606j6(bArr, i);
        return (((long) m606j6(bArr, i + 4)) & 4294967295L) | ((((long) iM606j6) & 4294967295L) << 32);
    }

    public static void m604DW(int i, byte[] bArr, int i2) {
        bArr[i2] = (byte) i;
        int i3 = i2 + 1;
        bArr[i3] = (byte) (i >>> 8);
        int i4 = i3 + 1;
        bArr[i4] = (byte) (i >>> 16);
        bArr[i4 + 1] = (byte) (i >>> 24);
    }

    public static void m605DW(long j, byte[] bArr, int i) {
        m604DW((int) (4294967295L & j), bArr, i);
        m604DW((int) (j >>> 32), bArr, i + 4);
    }

    public static int m606j6(byte[] bArr, int i) {
        int i2 = bArr[i] << 24;
        int i3 = i + 1;
        int i4 = i2 | ((bArr[i3] & 255) << 16);
        int i5 = i3 + 1;
        return (bArr[i5 + 1] & 255) | i4 | ((bArr[i5] & 255) << 8);
    }

    public static void m607j6(int i, byte[] bArr, int i2) {
        bArr[i2] = (byte) (i >>> 24);
        int i3 = i2 + 1;
        bArr[i3] = (byte) (i >>> 16);
        int i4 = i3 + 1;
        bArr[i4] = (byte) (i >>> 8);
        bArr[i4 + 1] = (byte) i;
    }

    public static void m608j6(long j, byte[] bArr, int i) {
        m607j6((int) (j >>> 32), bArr, i);
        m607j6((int) (j & 4294967295L), bArr, i + 4);
    }
}
