package abcd;

import java.util.BitSet;

public final class C0003uo extends ao {

    public static final ao f13DW = new C0003uo();

    private C0003uo() {
    }

    public BitSet m26FH(Vn vn) {
        cs csVarGn = vn.gn();
        BitSet bitSet = new BitSet(1);
        bitSet.set(0, ao.v5(csVarGn.get(0).we()));
        return bitSet;
    }

    public boolean m27VH(Vn vn) {
        cs csVarGn = vn.gn();
        if (!(vn instanceof Tn) || csVarGn.size() != 1 || !ao.v5(csVarGn.get(0).we())) {
            return false;
        }
        Ds dsWe = ((Tn) vn).we();
        if (!(dsWe instanceof Ds)) {
            return false;
        }
        Ds ds = dsWe;
        return ds.J8() && ao.DW(ds.Ws());
    }

    public String m28Zo(Vn vn) {
        return vn.gn().get(0).lg() + ", " + ao.j6(((Tn) vn).we());
    }

    public int m29j6() {
        return 1;
    }

    public String m30j6(Vn vn, boolean z) {
        return ao.j6(((Tn) vn).we(), 4);
    }

    public void m31j6(Lt lt, Vn vn) {
        ao.j6(lt, ao.j6(vn, ao.DW(vn.gn().get(0).we(), ((Tn) vn).we().Ws() & 15)));
    }
}
