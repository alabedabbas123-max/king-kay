package abcd;

import java.util.AbstractList;

class C0000eq extends AbstractList<String> {

    final iq f0j6;

    C0000eq(iq iqVar) {
        this.f0j6 = iqVar;
    }

    @Override
    public String get(int i) {
        iq.j6(i, iq.j6(this.f0j6).FH.DW);
        return (String) iq.FH(this.f0j6).get(((Integer) iq.DW(this.f0j6).get(i)).intValue());
    }

    @Override
    public int size() {
        return iq.j6(this.f0j6).FH.DW;
    }
}
