package abcd;

import com.aide.common.u;
import com.aide.ui.U;

@xu
public class C0003Hf implements _l, Wl {

    @uu
    private static boolean f74DW;

    @tu
    private static boolean f75j6;

    static {
        wu.j6(C0003Hf.class, 2397962029714200101L, 2397962029714200101L);
    }

    public C0003Hf() {
        try {
            if (f75j6) {
                wu.j6(-832772384792246976L, (Object) null);
            }
        } catch (Throwable th) {
            if (f74DW) {
                wu.j6(th, -832772384792246976L, (Object) null);
            }
            throw th;
        }
    }

    public u m126FH() {
        try {
            if (f75j6) {
                wu.j6(1817243934918193125L, this);
            }
            return new u(34, false, true, false);
        } catch (Throwable th) {
            if (f74DW) {
                wu.j6(th, 1817243934918193125L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f75j6) {
                return "LogCat - Filter by Process";
            }
            wu.j6(-2728868209644465152L, this);
            return "LogCat - Filter by Process";
        } catch (Throwable th) {
            if (f74DW) {
                wu.j6(th, -2728868209644465152L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f75j6) {
                wu.j6(531183703994843780L, this);
            }
            return m128j6(false);
        } catch (Throwable th) {
            if (f74DW) {
                wu.j6(th, 531183703994843780L, this);
            }
            throw th;
        }
    }

    public int m127j6() {
        try {
            if (!f75j6) {
                return com.aide.pro.R.id.logcatMenuFilterByProcess;
            }
            wu.j6(-4661642295206537760L, this);
            return com.aide.pro.R.id.logcatMenuFilterByProcess;
        } catch (Throwable th) {
            if (f74DW) {
                wu.j6(th, -4661642295206537760L, this);
            }
            throw th;
        }
    }

    public boolean m128j6(boolean z) {
        try {
            if (f75j6) {
                wu.j6(1113400936222936320L, this, z);
            }
            return !U.j6.equals("com.aide.web");
        } catch (Throwable th) {
            if (f74DW) {
                wu.j6(th, 1113400936222936320L, this, new Boolean(z));
            }
            throw th;
        }
    }

    public boolean m129run() {
        try {
            if (f75j6) {
                wu.j6(-1306491938306740440L, this);
            }
            U.lg().Mr().u7();
            return true;
        } catch (Throwable th) {
            if (f74DW) {
                wu.j6(th, -1306491938306740440L, this);
            }
            throw th;
        }
    }
}
