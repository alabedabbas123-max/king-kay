package abcd;

import com.aide.common.u;
import com.aide.ui.U;

@xu
public class C0021_g implements Wl {

    @uu
    private static boolean f150DW;

    @tu
    private static boolean f151j6;

    static {
        wu.j6(C0021_g.class, 4839221975418944545L, 4839221975418944545L);
    }

    public C0021_g() {
        try {
            if (f151j6) {
                wu.j6(2761894049953643605L, (Object) null);
            }
        } catch (Throwable th) {
            if (f150DW) {
                wu.j6(th, 2761894049953643605L, (Object) null);
            }
            throw th;
        }
    }

    public u m183FH() {
        try {
            if (f151j6) {
                wu.j6(-1596218008254015200L, this);
            }
            return new u(61, false, false, false);
        } catch (Throwable th) {
            if (f150DW) {
                wu.j6(th, -1596218008254015200L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f151j6) {
                return "Code Completion";
            }
            wu.j6(-1443076353377275057L, this);
            return "Code Completion";
        } catch (Throwable th) {
            if (f150DW) {
                wu.j6(th, -1443076353377275057L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f151j6) {
                wu.j6(3075952568390260047L, this);
            }
            return U.er().tp();
        } catch (Throwable th) {
            if (f150DW) {
                wu.j6(th, 3075952568390260047L, this);
            }
            throw th;
        }
    }

    public boolean m184run() {
        try {
            if (f151j6) {
                wu.j6(-1908244350440729535L, this);
            }
            U.lg().J8().gW();
            return true;
        } catch (Throwable th) {
            if (f150DW) {
                wu.j6(th, -1908244350440729535L, this);
            }
            throw th;
        }
    }
}
