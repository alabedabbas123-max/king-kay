package abcd;

import java.util.BitSet;
import java.util.Iterator;
import java.util.List;

public class C0017Ht {

    private final BitSet f106DW;

    private final int f107FH;

    private final yt f108Hw;

    private int f109VH;

    private tt f110Zo;

    private a f111gn;

    private final BitSet f112j6;

    private final Ft f113v5;

    private enum a {
        LIVE_IN_AT_STATEMENT,
        LIVE_OUT_AT_STATEMENT,
        LIVE_OUT_AT_BLOCK,
        DONE
    }

    private C0017Ht(yt ytVar, int i, Ft ft) {
        int size = ytVar.DW().size();
        this.f108Hw = ytVar;
        this.f107FH = i;
        this.f112j6 = new BitSet(size);
        this.f106DW = new BitSet(size);
        this.f113v5 = ft;
    }

    private void m187DW() {
        while (true) {
            a aVar = this.f111gn;
            if (aVar == a.DONE) {
                return;
            }
            int i = Gt.j6[aVar.ordinal()];
            if (i == 1) {
                this.f111gn = a.DONE;
                m188FH();
            } else if (i == 2) {
                this.f111gn = a.DONE;
                m192v5();
            } else if (i == 3) {
                this.f111gn = a.DONE;
                m189Hw();
            }
        }
    }

    private void m188FH() {
        int i = this.f109VH;
        if (i != 0) {
            this.f109VH = i - 1;
            this.f111gn = a.LIVE_OUT_AT_STATEMENT;
        } else {
            this.f110Zo.j6(this.f107FH);
            this.f106DW.or(this.f110Zo.VH());
        }
    }

    private void m189Hw() {
        if (this.f112j6.get(this.f110Zo.DW())) {
            return;
        }
        this.f112j6.set(this.f110Zo.DW());
        this.f110Zo.DW(this.f107FH);
        this.f109VH = this.f110Zo.FH().size() - 1;
        this.f111gn = a.LIVE_OUT_AT_STATEMENT;
    }

    public static Ft m190j6(yt ytVar) {
        int iU7 = ytVar.u7();
        Ft ft = new Ft(iU7);
        for (int i = 0; i < iU7; i++) {
            new C0017Ht(ytVar, i, ft).m193j6();
        }
        m191j6(ytVar, ft);
        return ft;
    }

    private static void m191j6(yt ytVar, Ft ft) {
        Iterator it = ytVar.DW().iterator();
        while (it.hasNext()) {
            List listZo = ((tt) it.next()).Zo();
            int size = listZo.size();
            for (int i = 0; i < size; i++) {
                for (int i2 = 0; i2 < size; i2++) {
                    if (i != i2) {
                        ft.j6(((vt) listZo.get(i)).u7().we(), ((vt) listZo.get(i2)).u7().we());
                    }
                }
            }
        }
    }

    private void m192v5() {
        vt vtVar = (vt) this.f110Zo.FH().get(this.f109VH);
        bs bsVarU7 = vtVar.u7();
        if (vtVar.DW(this.f107FH)) {
            return;
        }
        if (bsVarU7 != null) {
            this.f113v5.j6(this.f107FH, bsVarU7.we());
        }
        this.f111gn = a.LIVE_IN_AT_STATEMENT;
    }

    public void m193j6() {
        for (ot otVar : this.f108Hw.Hw(this.f107FH)) {
            this.f111gn = a.DONE;
            if (otVar instanceof ot) {
                Iterator it = otVar.j6(this.f107FH, this.f108Hw).iterator();
                while (it.hasNext()) {
                    this.f110Zo = (tt) it.next();
                    this.f111gn = a.LIVE_OUT_AT_BLOCK;
                    m187DW();
                }
            } else {
                this.f110Zo = otVar.DW();
                this.f109VH = this.f110Zo.FH().indexOf(otVar);
                if (this.f109VH < 0) {
                    throw new RuntimeException("insn not found in it's own block");
                }
                this.f111gn = a.LIVE_IN_AT_STATEMENT;
                m187DW();
            }
        }
        while (true) {
            int iNextSetBit = this.f106DW.nextSetBit(0);
            if (iNextSetBit < 0) {
                return;
            }
            this.f110Zo = (tt) this.f108Hw.DW().get(iNextSetBit);
            this.f106DW.clear(iNextSetBit);
            this.f111gn = a.LIVE_OUT_AT_BLOCK;
            m187DW();
        }
    }
}
