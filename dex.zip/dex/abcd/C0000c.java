package abcd;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class C0000c<K, V> implements Iterable<Map.Entry<K, V>> {

    private c<K, V> f0DW;

    private WeakHashMap<f<K, V>, Boolean> f1FH = new WeakHashMap<>();

    private int f2Hw = 0;

    private c<K, V> f3j6;

    public c<K, V>.d m1DW() {
        f<K, V> dVar = new d<>(this, (b) null);
        this.f1FH.put(dVar, false);
        return dVar;
    }

    public Map.Entry<K, V> m2FH() {
        return this.f0DW;
    }

    public Iterator<Map.Entry<K, V>> descendingIterator() {
        f<K, V> bVar = new b<>(this.f0DW, this.f3j6);
        this.f1FH.put(bVar, false);
        return bVar;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0000c)) {
            return false;
        }
        C0000c c0000c = (C0000c) obj;
        if (size() != c0000c.size()) {
            return false;
        }
        Iterator<Map.Entry<K, V>> it = iterator();
        Iterator<Map.Entry<K, V>> it2 = c0000c.iterator();
        while (it.hasNext() && it2.hasNext()) {
            Map.Entry<K, V> next = it.next();
            Map.Entry<K, V> next2 = it2.next();
            if ((next == null && next2 != null) || (next != null && !next.equals(next2))) {
                return false;
            }
        }
        return (it.hasNext() || it2.hasNext()) ? false : true;
    }

    @Override
    public Iterator<Map.Entry<K, V>> iterator() {
        f<K, V> aVar = new a<>(this.f3j6, this.f0DW);
        this.f1FH.put(aVar, false);
        return aVar;
    }

    public Map.Entry<K, V> m3j6() {
        return this.f3j6;
    }

    public int size() {
        return this.f2Hw;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Iterator<Map.Entry<K, V>> it = iterator();
        while (it.hasNext()) {
            sb.append(it.next().toString());
            if (it.hasNext()) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
