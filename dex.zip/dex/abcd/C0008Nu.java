package abcd;

import com.appfour.backbone.api.closures.OnEnterClosure2;
import com.appfour.backbone.api.objects.EventData;

class C0008Nu implements lv.a {

    final Object[] f16DW;

    final C0051Ou f17FH;

    final Object f18j6;

    C0008Nu(C0051Ou c0051Ou, Object obj, Object[] objArr) {
        this.f17FH = c0051Ou;
        this.f18j6 = obj;
        this.f16DW = objArr;
    }

    public EventData getValue() {
        OnEnterClosure2 onEnterClosure2 = this.f17FH.f257DW;
        Object obj = this.f18j6;
        Object[] objArr = this.f16DW;
        return onEnterClosure2.getValue(obj, objArr[1], objArr[2]);
    }
}
