package abcd;

class C0018vC extends zC {
    C0018vC() {
    }

    protected int m78j6(byte[] bArr, int i, int i2) {
        int i3 = 5381;
        while (i < i2) {
            byte b = bArr[i];
            if (!HK.j6(b)) {
                i3 = (i3 << 5) + i3 + (b & 255);
            }
            i++;
        }
        return i3;
    }

    public boolean m79j6(tC tCVar, int i, tC tCVar2, int i2) {
        int i3 = i + 1;
        int i4 = i2 + 1;
        int iDW = tCVar.FH.DW(i3);
        int iDW2 = tCVar2.FH.DW(i4);
        int iDW3 = tCVar.FH.DW(i3 + 1);
        int iDW4 = tCVar2.FH.DW(i4 + 1);
        int iDW5 = HK.DW(tCVar.DW, iDW, iDW3);
        int iDW6 = HK.DW(tCVar2.DW, iDW2, iDW4);
        while (iDW < iDW5 && iDW2 < iDW6) {
            byte b = tCVar.DW[iDW];
            byte b2 = tCVar2.DW[iDW2];
            while (iDW < iDW5 - 1 && HK.j6(b)) {
                iDW++;
                b = tCVar.DW[iDW];
            }
            while (iDW2 < iDW6 - 1 && HK.j6(b2)) {
                iDW2++;
                b2 = tCVar2.DW[iDW2];
            }
            if (b != b2) {
                return false;
            }
            iDW++;
            iDW2++;
        }
        return iDW == iDW5 && iDW2 == iDW6;
    }
}
