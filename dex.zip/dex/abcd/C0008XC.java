package abcd;

public class C0008XC extends Exception {
    public C0008XC(String str) {
        super(str);
    }

    public C0008XC(String str, Throwable th) {
        super(str, th);
    }
}
