package abcd;

public abstract class AbstractC0107qt {
    public abstract int m556j6();

    public abstract bs m557j6(bs bsVar);

    public final cs m558j6(cs csVar) {
        int size = csVar.size();
        cs csVar2 = new cs(size);
        for (int i = 0; i < size; i++) {
            csVar2.j6(i, m557j6(csVar.get(i)));
        }
        csVar2.we();
        return csVar2.equals(csVar) ? csVar : csVar2;
    }
}
