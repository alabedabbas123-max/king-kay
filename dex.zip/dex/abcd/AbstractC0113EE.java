package abcd;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.security.MessageDigest;

public abstract class AbstractC0113EE {

    private byte[] f520DW;

    private final MessageDigest f521j6 = hE.j6();

    public static class a extends AbstractC0113EE {
        @Override
        public void mo729FH() {
        }

        @Override
        public void mo730Hw() {
        }

        @Override
        public AI mo731j6(InputStream inputStream) {
            throw new UnsupportedOperationException();
        }

        @Override
        public yE mo732j6(int i, long j, InputStream inputStream) {
            throw new UnsupportedOperationException();
        }
    }

    protected AbstractC0113EE() {
    }

    public yE m726DW(int i, byte[] bArr) {
        return m727DW(i, bArr, 0, bArr.length);
    }

    public yE m727DW(int i, byte[] bArr, int i2, int i3) {
        return mo732j6(i, i3, new ByteArrayInputStream(bArr, i2, i3));
    }

    protected MessageDigest m728DW() {
        this.f521j6.reset();
        return this.f521j6;
    }

    public abstract void mo729FH();

    public abstract void mo730Hw();

    public abstract AI mo731j6(InputStream inputStream);

    public abstract yE mo732j6(int i, long j, InputStream inputStream);

    public yE m733j6(int i, byte[] bArr) {
        return m734j6(i, bArr, 0, bArr.length);
    }

    public yE m734j6(int i, byte[] bArr, int i2, int i3) {
        MessageDigest messageDigestM728DW = m728DW();
        messageDigestM728DW.update(hE.j6(i));
        messageDigestM728DW.update((byte) 32);
        messageDigestM728DW.update(hE.j6(i3));
        messageDigestM728DW.update((byte) 0);
        messageDigestM728DW.update(bArr, i2, i3);
        return yE.j6(messageDigestM728DW.digest());
    }

    public final yE m735j6(fE fEVar) {
        return m726DW(1, fEVar.j6());
    }

    public final yE m736j6(mF mFVar) {
        return mFVar.j6(this);
    }

    protected byte[] m737j6() {
        if (this.f520DW == null) {
            this.f520DW = new byte[8192];
        }
        return this.f520DW;
    }
}
