package abcd;

public final class C0015om extends Am {

    private final Dm f87DW;

    public C0015om(Dm dm) throws iu {
        super("InnerClasses");
        try {
            if (dm.Zo()) {
                throw new iu("innerClasses.isMutable()");
            }
            this.f87DW = dm;
        } catch (NullPointerException unused) {
            throw new NullPointerException("innerClasses == null");
        }
    }

    public int m49Hw() {
        return (this.f87DW.size() * 8) + 8;
    }

    public Dm m50j6() {
        return this.f87DW;
    }
}
