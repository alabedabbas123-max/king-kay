package abcd;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;

public abstract class AbstractC0108TI {

    private boolean f530Zo;

    private UE f532v5;

    private final StringBuilder f531j6 = new StringBuilder(100);

    private final char[] f526DW = new char[40];

    private final Set<String> f527FH = new LinkedHashSet();

    private final Set<yE> f528Hw = new HashSet();

    private boolean f529VH = true;

    public static class a extends AbstractC0108TI {

        private final EI f533gn;

        public a(EI ei) {
            this.f533gn = ei;
        }

        @Override
        protected void mo775j6() {
            this.f533gn.j6();
        }

        @Override
        protected void mo779j6(CharSequence charSequence) {
            this.f533gn.j6(charSequence.toString());
        }
    }

    private Iterable<ME> m770DW(Map<String, ME> map) {
        return ((map instanceof MK) || ((map instanceof SortedMap) && ((SortedMap) map).comparator() == null)) ? map.values() : NE.j6(map.values());
    }

    private void m771DW(YD yd, String str) {
        this.f528Hw.add(yd.J8());
        m778j6(yd, str);
    }

    private void m772FH(YD yd, String str) {
        if (this.f528Hw.contains(yd)) {
            return;
        }
        m771DW(yd, str);
    }

    public boolean m773DW() {
        return this.f529VH;
    }

    public Set<yE> m774j6(Map<String, ME> map) {
        Iterator<ME> it = m770DW(map).iterator();
        while (it.hasNext()) {
            ME next = it.next();
            if (next.DW() != null) {
                m771DW(next.DW(), next.getName());
                if (this.f530Zo) {
                    if (!next.Hw()) {
                        UE ue = this.f532v5;
                        if (ue != null) {
                            next = ue.j6(next);
                        }
                    }
                    if (next.FH() != null) {
                        m771DW(next.FH(), String.valueOf(next.getName()) + "^{}");
                    }
                }
            }
        }
        return this.f528Hw;
    }

    protected abstract void mo775j6();

    public void m776j6(UE ue) {
        this.f532v5 = ue;
    }

    public void m777j6(YD yd) {
        m772FH(yd, ".have");
    }

    public void m778j6(YD yd, String str) {
        this.f531j6.setLength(0);
        yd.j6(this.f526DW, this.f531j6);
        this.f531j6.append(' ');
        this.f531j6.append(str);
        if (this.f529VH) {
            this.f529VH = false;
            if (!this.f527FH.isEmpty()) {
                this.f531j6.append((char) 0);
                for (String str2 : this.f527FH) {
                    this.f531j6.append(' ');
                    this.f531j6.append(str2);
                }
                this.f531j6.append(' ');
            }
        }
        this.f531j6.append('\n');
        mo779j6(this.f531j6);
    }

    protected abstract void mo779j6(CharSequence charSequence);

    public void m780j6(String str) {
        this.f527FH.add(str);
    }

    public void m781j6(boolean z) {
        this.f530Zo = z;
    }
}
