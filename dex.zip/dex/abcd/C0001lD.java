package abcd;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import org.eclipse.jgit.JGitText;

public class C0001lD extends IOException {
    public C0001lD(File file) {
        this(file.getAbsolutePath());
    }

    public C0001lD(String str) {
        super(MessageFormat.format(JGitText.j6().packFileInvalid, str));
    }
}
