package abcd;

import android.R;
import android.os.Handler;
import com.appfour.backbone.api.Api;
import com.appfour.backbone.api.runtime.RuntimeDebug;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipFile;

public class C0025ow {

    private static long f370DW;

    private static Handler f371EQ;

    private static String f372FH;

    private static String f373Hw;

    private static boolean f378tp;

    private static boolean f379u7;

    private static final List<lw> f377j6 = new ArrayList();

    private static Object f380v5 = new Object();

    private static Object f375Zo = new Object();

    private static Object f374VH = new Object();

    private static Object f376gn = new Object();

    private static void m102DW(File file) {
        if (!file.isDirectory()) {
            file.delete();
            return;
        }
        for (File file2 : file.listFiles()) {
            m102DW(file2);
        }
        file.delete();
    }

    public static void m103DW(ClassLoader classLoader, List<String> list) {
        ArrayList arrayList = new ArrayList();
        m116j6(classLoader, arrayList, list);
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            m114j6((Class<?>) it.next());
        }
    }

    public static void m104DW(ClassLoader classLoader, boolean z) {
        try {
            ArrayList arrayList = new ArrayList();
            ArrayList arrayList2 = new ArrayList();
            Mv.XL().j6(new nw(classLoader, arrayList2), arrayList);
            m118j6(arrayList, arrayList2, z);
        } catch (Throwable th) {
            yw.j6("Probe loading", th);
        }
    }

    public static ClassLoader m106FH(File file) {
        try {
            File file2 = new File(file.getParentFile(), file.getName() + ".dex");
            ZipFile zipFile = new ZipFile(file);
            InputStream inputStream = zipFile.getInputStream(zipFile.getEntry("classes.dex"));
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            byte[] bArr = new byte[16000];
            while (true) {
                int i = inputStream.read(bArr);
                if (i == -1) {
                    zipFile.close();
                    fileOutputStream.close();
                    File file3 = new File(file.getParentFile(), file.getName() + ".opt");
                    m102DW(file3);
                    file3.mkdirs();
                    return new kw(file2.getPath(), file3.getPath(), (String) null, wu.j6().getClassLoader(), true);
                }
                fileOutputStream.write(bArr, 0, i);
            }
        } catch (IOException e) {
            yw.j6("Error loading probes", e);
            return null;
        }
    }

    public static void m108VH() {
        synchronized (f374VH) {
            f374VH.notifyAll();
        }
    }

    private static File m110gn() {
        try {
            File file = new File(rw.FH(), sw.j6() ? "dev.builtin.apk" : "public.builtin.apk");
            if (file.exists() && file.lastModified() == f370DW) {
                return file;
            }
            file.delete();
            InputStream resourceAsStream = wu.j6().getClassLoader().getResourceAsStream(sw.j6() ? "dev.probes" : "public.probes");
            if (resourceAsStream == null) {
                return null;
            }
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[16000];
            while (true) {
                int i = resourceAsStream.read(bArr);
                if (i == -1) {
                    break;
                }
                fileOutputStream.write(bArr, 0, i);
            }
            fileOutputStream.close();
            if (file.exists()) {
                file.setLastModified(f370DW);
                return file;
            }
        } catch (IOException unused) {
        }
        return null;
    }

    public static void m113j6(lw lwVar, long j, Throwable th) {
        iw.j6(lwVar, j, th);
        if (sw.j6()) {
            xw.j6(lwVar.DW().hashCode() + 346546, R.drawable.stat_notify_error, "backbone probes event error: " + lwVar.DW() + ": " + th);
        }
    }

    private static void m114j6(Class<?> cls) {
        Object objNewInstance;
        yw.j6("Probes", "Opening " + cls);
        try {
            Constructor<?> declaredConstructor = cls.getDeclaredConstructor(new Class[0]);
            if (declaredConstructor != null) {
                declaredConstructor.setAccessible(true);
                objNewInstance = declaredConstructor.newInstance(new Object[0]);
            } else {
                objNewInstance = null;
            }
        } catch (Exception unused) {
        }
        try {
            Method declaredMethod = cls.getDeclaredMethod("define", new Class[0]);
            if (declaredMethod.getParameterTypes().length == 0 && "void".equals(declaredMethod.getReturnType().getSimpleName()) && !declaredMethod.isSynthetic()) {
                if ((declaredMethod.getModifiers() & 8) != 0) {
                    yw.j6("Probes", "Opening " + declaredMethod);
                    declaredMethod.setAccessible(true);
                    declaredMethod.invoke(null, new Object[0]);
                    return;
                }
                if (objNewInstance != null) {
                    yw.j6("Probes", "Opening " + declaredMethod);
                    declaredMethod.setAccessible(true);
                    declaredMethod.invoke(objNewInstance, new Object[0]);
                }
            }
        } catch (Exception unused2) {
        }
    }

    private static void m116j6(ClassLoader classLoader, List<Class<?>> list, List<String> list2) {
        if (classLoader == null) {
            return;
        }
        try {
            Class<?> clsLoadClass = classLoader.loadClass("probes");
            String[] strArr = (String[]) clsLoadClass.getDeclaredField("classes").get(null);
            for (String str : strArr) {
                if (!"DefaultProbes".equals(str)) {
                    list.add(classLoader.loadClass(str.replace('/', '.')));
                }
            }
            for (String str2 : strArr) {
                if ("DefaultProbes".equals(str2)) {
                    list.add(classLoader.loadClass(str2.replace('/', '.')));
                }
            }
            list2.addAll(Arrays.asList((String[]) clsLoadClass.getDeclaredField("strings").get(null)));
        } catch (ClassNotFoundException unused) {
            list.add(classLoader.loadClass("DefaultProbes"));
        }
    }

    private static void m118j6(List<lw> list, List<String> list2, boolean z) {
        long jMax;
        synchronized (f380v5) {
            yw.j6("Probes", "Opening probes " + list.size());
            Mv.XL().j6(list2);
            Iterator<lw> it = f377j6.iterator();
            while (it.hasNext()) {
                kv.DW(it.next().j6());
            }
            f377j6.clear();
            long lastUpdateTime = (!z || Api.hasBeenUpdated()) ? Api.getLastUpdateTime() : 0L;
            long jDW = kv.DW();
            if (!z) {
                kv.j6();
            }
            for (lw lwVar : list) {
                f377j6.add(lwVar);
                if (!rw.DW(lwVar)) {
                    if (z) {
                        jMax = lastUpdateTime;
                    } else {
                        Iterator it2 = lwVar.j6().iterator();
                        jMax = lastUpdateTime;
                        while (it2.hasNext()) {
                            jMax = Math.max(kv.j6((iv) it2.next(), jDW, lastUpdateTime), jMax);
                        }
                    }
                    rw.j6(lwVar);
                    iw.j6(lwVar, jDW, jMax);
                }
            }
            for (lw lwVar2 : list) {
                if (lwVar2.FH()) {
                    kv.j6(lwVar2.j6());
                }
            }
        }
    }

    public static void m119j6(boolean z, long j, String str, String str2) {
        f371EQ = new Handler();
        f370DW = j;
        f373Hw = str;
        f372FH = str2;
        synchronized (f376gn) {
            new Thread((Runnable) new mw(str, str2, j)).start();
            if (z) {
                long jCurrentTimeMillis = System.currentTimeMillis();
                try {
                    try {
                        f379u7 = true;
                        f376gn.wait(1000L);
                        RuntimeDebug.initialProbeLoadAttempted = true;
                        RuntimeDebug.initialProbeLoadTime = System.currentTimeMillis() - jCurrentTimeMillis;
                        RuntimeDebug.initialProbeLoadSuccess = f378tp;
                        yw.j6("Probes", "Waited for load " + RuntimeDebug.initialProbeLoadTime + "ms");
                    } catch (InterruptedException e) {
                        yw.j6("Probes", "Unexpected InterruptedException", e);
                    }
                    f379u7 = false;
                } catch (Throwable th) {
                    f379u7 = false;
                    throw th;
                }
            }
            File fileM123u7 = m123u7();
            File fileM110gn = m110gn();
            if (fileM123u7.exists() && fileM123u7.lastModified() > j) {
                yw.j6("Probes", "Opening downloaded probes " + fileM123u7);
                m104DW(m106FH(fileM123u7), z);
            } else if (fileM110gn != null) {
                yw.j6("Probes", "Opening built-in probes " + fileM110gn.getName());
                m104DW(m106FH(fileM110gn), z);
            } else {
                yw.j6("Probes", "Opening no probes");
                m104DW((ClassLoader) null, z);
            }
        }
    }

    public static boolean m120j6(String str) {
        Iterator<lw> it = f377j6.iterator();
        while (it.hasNext()) {
            if (it.next().DW().equals(str)) {
                return true;
            }
        }
        return false;
    }

    public static File m122tp() {
        return new File(rw.FH(), sw.j6() ? "dev.download.apk" : "public.download.apk");
    }

    public static File m123u7() {
        return new File(rw.FH(), sw.j6() ? "dev.current.apk" : "public.current.apk");
    }
}
