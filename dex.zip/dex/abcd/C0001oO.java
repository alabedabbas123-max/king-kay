package abcd;

public class C0001oO {

    private InterfaceC0086qO f28DW;

    private InterfaceC0086qO f29j6;

    public C0001oO(InterfaceC0086qO interfaceC0086qO, InterfaceC0086qO interfaceC0086qO2) {
        this.f29j6 = interfaceC0086qO;
        this.f28DW = interfaceC0086qO2;
    }

    public InterfaceC0086qO m0DW() {
        return this.f29j6;
    }

    public InterfaceC0086qO m1j6() {
        return this.f28DW;
    }
}
