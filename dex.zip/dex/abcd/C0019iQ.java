package abcd;

public class C0019iQ {

    private static C0019iQ f55j6 = new C0019iQ();

    public static C0019iQ m78j6() {
        return f55j6;
    }
}
