package abcd;

@xu
public class C0024I {

    @uu
    private static boolean f160DW;

    @tu
    private static boolean f161j6;

    @ru(field = -884991752254346400L)
    private final ea f162FH;

    @ru(field = 3189801506849063509L)
    private final Ga f163Hw;

    @ru(field = -577742219567428320L)
    private final Va f164VH;

    @ru(field = -623178862047885405L)
    private final Ba f165Zo;

    @ru(field = -1059795212860183445L)
    private final Q f166gn;

    @ru(field = -3297354211059744577L)
    private final Ea f167v5;

    static {
        wu.j6(C0024I.class, 3759880163513944539L, 3759880163513944539L);
    }

    public C0024I(ea eaVar) {
        try {
            if (f161j6) {
                wu.j6(-1256096129761533405L, (Object) null, eaVar);
            }
            this.f162FH = eaVar;
            this.f163Hw = ((La) eaVar).j3;
            this.f167v5 = ((La) eaVar).Mr;
            this.f165Zo = ((La) eaVar).a8;
            this.f164VH = ((La) eaVar).U2;
            this.f166gn = eaVar.nw;
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -1256096129761533405L, (Object) null, eaVar);
            }
            throw th;
        }
    }

    @su(method = 43227628363739448L)
    private _b m285j6(boolean z) {
        try {
            if (f161j6) {
                wu.j6(-720247626787709673L, this, z);
            }
            if (z) {
                _b _bVar = new _b(this.f167v5);
                _bVar.FH(this.f167v5.Zo());
                return _bVar;
            }
            _b _bVar2 = new _b(this.f167v5);
            _bVar2.FH(this.f167v5.u7());
            return _bVar2;
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -720247626787709673L, this, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 3683782242036515100L)
    private void m286j6(Sa sa, int i, Aa aa, _b _bVar, boolean z) {
        C0041Ia c0041Ia;
        C0041Ia c0041Ia2;
        try {
            if (f161j6) {
                wu.j6(-1377753804210256635L, this, sa, new Integer(i), aa, _bVar, new Boolean(z));
            }
            _bVar.v5.DW();
            while (_bVar.v5.j6() && !((La) this.f162FH).J8.x9()) {
                Da daFH = _bVar.v5.FH();
                if ((daFH.BT() && this.f166gn.DW(daFH, i)) || (!daFH.BT() && this.f166gn.FH(daFH, i))) {
                    Yb ybJ6 = this.f165Zo.j6(daFH);
                    ybJ6.Hw.DW();
                    while (ybJ6.Hw.j6()) {
                        Aa aaFH = ybJ6.Hw.FH();
                        if (aaFH.yS() && ((C0041Ia) aaFH).m512oY() && (c0041Ia2 = (C0041Ia) aaFH) != aa && c0041Ia2.m476cn().j6(aa)) {
                            ((La) this.f162FH).EQ.j6(c0041Ia2);
                        }
                        if (aaFH.yS() && ((C0041Ia) aaFH).m484hz() && (c0041Ia = (C0041Ia) aaFH) != aa && c0041Ia.m476cn().j6(aa)) {
                            ((La) this.f162FH).EQ.j6(c0041Ia);
                        }
                    }
                }
            }
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -1377753804210256635L, this, sa, new Integer(i), aa, _bVar, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 428269494419704304L)
    private void m287j6(Sa sa, int i, ua uaVar, _b _bVar, boolean z, boolean z2, boolean z3) {
        if (f161j6) {
            wu.j6(-746674962164500923L, this, new Object[]{sa, new Integer(i), uaVar, _bVar, new Boolean(z), new Boolean(z2), new Boolean(z3)});
        }
        _bVar.v5.DW();
        while (_bVar.v5.j6() && !((La) this.f162FH).J8.x9()) {
            Da daFH = _bVar.v5.FH();
            if ((daFH.BT() && this.f166gn.j6(daFH, i)) || (!daFH.BT() && this.f166gn.FH(daFH, i))) {
                Yb ybJ6 = this.f165Zo.j6(daFH);
                ybJ6.Hw.DW();
                while (ybJ6.Hw.j6()) {
                    Aa aaFH = ybJ6.Hw.FH();
                    if (aaFH.yS() && ((C0041Ia) aaFH).m512oY()) {
                        try {
                            C0041Ia c0041Ia = (C0041Ia) aaFH;
                            int iM519vJ = c0041Ia.m519vJ();
                            for (int i2 = 0; i2 < iM519vJ; i2++) {
                                if (m290j6(c0041Ia.m482gn(i2), uaVar) && ((z2 && Ma.tp(c0041Ia.m461VH(i2))) || Ma.QX(c0041Ia.m461VH(i2)) || (z3 && !Ma.tp(c0041Ia.m461VH(i2))))) {
                                    ((La) this.f162FH).EQ.j6(c0041Ia);
                                }
                            }
                        } catch (jc unused) {
                        }
                    } else if (aaFH.yS() && ((C0041Ia) aaFH).m484hz()) {
                        C0041Ia c0041Ia2 = (C0041Ia) aaFH;
                        if (c0041Ia2.m509ko() && c0041Ia2.m462WB() && c0041Ia2.m474ca().sh().DW(uaVar)) {
                            ((La) this.f162FH).EQ.j6(c0041Ia2);
                        }
                    }
                }
            }
        }
    }

    @su(method = -595890058784609239L)
    private void m288j6(Sa sa, bc bcVar, ua uaVar, Yb<ua> yb, Yb<ua> yb2, Yb<ua> yb3, _b _bVar, Yb<Aa> yb4, boolean z) {
        if (f161j6) {
            wu.j6(-452783270425521408L, this, new Object[]{sa, bcVar, uaVar, yb, yb2, yb3, _bVar, yb4, new Boolean(z)});
        }
        _bVar.v5.DW();
        while (_bVar.v5.j6() && !((La) this.f162FH).J8.x9()) {
            Da daFH = _bVar.v5.FH();
            if ((daFH.BT() && this.f166gn.j6(daFH, bcVar)) || (!daFH.BT() && this.f166gn.DW(daFH, bcVar))) {
                Yb ybJ6 = this.f165Zo.j6(daFH);
                ybJ6.Hw.DW();
                while (ybJ6.Hw.j6()) {
                    Aa aaFH = ybJ6.Hw.FH();
                    if (aaFH.rN()) {
                        Aa aa = (ua) aaFH;
                        ((Yb) yb).Hw.DW();
                        while (((Yb) yb).Hw.j6()) {
                            if (aa != ((Yb) yb).Hw.FH() && aa.CU().j6(((Yb) yb).Hw.FH()) && !yb3.j6(aa)) {
                                yb2.DW(aa);
                                yb3.DW(aa);
                            }
                        }
                    } else if (aaFH.yS() && ((C0041Ia) aaFH).m512oY()) {
                        try {
                            C0041Ia c0041Ia = (C0041Ia) aaFH;
                            if (yb.j6(c0041Ia.m474ca().sh()) || m290j6(c0041Ia.m474ca(), uaVar)) {
                                if (!yb4.j6(c0041Ia)) {
                                    yb4.DW(c0041Ia);
                                    ((La) this.f162FH).EQ.j6(c0041Ia);
                                }
                            }
                        } catch (jc unused) {
                        }
                    } else if (aaFH.yS() && ((C0041Ia) aaFH).m484hz()) {
                        C0041Ia c0041Ia2 = (C0041Ia) aaFH;
                        if ((c0041Ia2.m509ko() && yb.j6(c0041Ia2.m474ca().sh())) || m290j6(c0041Ia2.m474ca(), uaVar)) {
                            if (!yb4.j6(c0041Ia2)) {
                                yb4.DW(c0041Ia2);
                                ((La) this.f162FH).EQ.j6(c0041Ia2);
                            }
                        }
                    }
                }
            }
        }
    }

    @su(method = 1414712404373959800L)
    private void m289j6(bc bcVar, Yb<ua> yb, Yb<ua> yb2, Yb<ua> yb3, _b _bVar, boolean z) {
        if (f161j6) {
            wu.j6(-5485120401291433399L, this, new Object[]{bcVar, yb, yb2, yb3, _bVar, new Boolean(z)});
        }
        _bVar.v5.DW();
        while (_bVar.v5.j6() && !((La) this.f162FH).J8.x9()) {
            Da daFH = _bVar.v5.FH();
            if ((daFH.BT() && this.f166gn.j6(daFH, bcVar)) || (!daFH.BT() && this.f166gn.DW(daFH, bcVar))) {
                Yb ybJ6 = this.f165Zo.j6(daFH);
                ybJ6.Hw.DW();
                while (ybJ6.Hw.j6()) {
                    Aa aaFH = ybJ6.Hw.FH();
                    if (aaFH.rN()) {
                        Aa aa = (ua) aaFH;
                        ((Yb) yb).Hw.DW();
                        while (((Yb) yb).Hw.j6()) {
                            if (aa != ((Yb) yb).Hw.FH() && aa.CU().j6(((Yb) yb).Hw.FH()) && !yb3.j6(aa)) {
                                ((La) this.f162FH).EQ.j6(aa);
                                yb2.DW(aa);
                                yb3.DW(aa);
                            }
                        }
                    }
                }
            }
        }
    }

    @su(method = 3679533286230641476L)
    private boolean m290j6(Ya ya, ua uaVar) {
        try {
            if (f161j6) {
                wu.j6(-836975771980721893L, this, ya, uaVar);
            }
            if (ya.DW(uaVar) || ya.sh().DW(uaVar)) {
                return true;
            }
            if (ya.lg()) {
                return m290j6(((sa) ya).x9(), uaVar);
            }
            if (ya.P8()) {
                for (Ya ya2 : ((Oa) ya).x9()) {
                    if (m290j6(ya2, uaVar)) {
                        return true;
                    }
                }
            }
            return false;
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -836975771980721893L, this, ya, uaVar);
            }
            throw th;
        }
    }

    public void m291DW(Da da, int i, int i2, boolean z) {
        try {
            if (f161j6) {
                wu.j6(-882633010032976680L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            ((La) this.f162FH).EQ.j6();
            Sa saJ6 = this.f164VH.j6(da, i, i2);
            int iU7 = saJ6.u7(i, i2);
            if (iU7 != -1) {
                saJ6.J8().Hw().DW(saJ6, iU7);
                int iXL = saJ6.XL(iU7);
                if (saJ6.Zo(iU7) != 0) {
                    ua uaVarV5 = saJ6.v5(iU7);
                    if (uaVarV5.yS() && ((C0041Ia) uaVarV5).m464XG()) {
                        uaVarV5 = ((C0041Ia) uaVarV5).m448FH();
                    }
                    if (uaVarV5.rN()) {
                        ((La) this.f162FH).EQ.j6("Methods taking " + uaVarV5.VH());
                        m287j6(saJ6, iXL, uaVarV5, m285j6(uaVarV5.Zo().BT() || !z), z, false, true);
                    }
                }
            }
            this.f164VH.j6(saJ6);
            ((La) this.f162FH).EQ.DW();
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -882633010032976680L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            throw th;
        }
    }

    public void m292FH(Da da, int i, int i2, boolean z) {
        try {
            if (f161j6) {
                wu.j6(-1886052346286588673L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            ((La) this.f162FH).EQ.j6();
            Sa saJ6 = this.f164VH.j6(da, i, i2);
            int iU7 = saJ6.u7(i, i2);
            if (iU7 != -1) {
                saJ6.J8().Hw().DW(saJ6, iU7);
                int iXL = saJ6.XL(iU7);
                if (saJ6.Zo(iU7) != 0) {
                    Aa aaV5 = saJ6.v5(iU7);
                    if (aaV5.yS() && ((C0041Ia) aaV5).m512oY()) {
                        ((La) this.f162FH).EQ.j6("Methods overriding " + aaV5.VH());
                        m286j6(saJ6, iXL, aaV5, m285j6(aaV5.Zo().BT() || !z), z);
                    } else if (aaV5.yS() && ((C0041Ia) aaV5).m484hz()) {
                        ((La) this.f162FH).EQ.j6("Properties overriding " + aaV5.VH());
                        m286j6(saJ6, iXL, aaV5, m285j6(aaV5.Zo().BT() || !z), z);
                    }
                }
            }
            this.f164VH.j6(saJ6);
            ((La) this.f162FH).EQ.DW();
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -1886052346286588673L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            throw th;
        }
    }

    public void m293Hw(Da da, int i, int i2, boolean z) {
        try {
            if (f161j6) {
                wu.j6(-5164143301857873240L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            ((La) this.f162FH).EQ.j6();
            Sa saJ6 = this.f164VH.j6(da, i, i2);
            int iU7 = saJ6.u7(i, i2);
            if (iU7 != -1) {
                saJ6.J8().Hw().DW(saJ6, iU7);
                if (saJ6.Zo(iU7) != 0) {
                    ua uaVarV5 = saJ6.v5(iU7);
                    if (uaVarV5.yS() && ((C0041Ia) uaVarV5).m464XG()) {
                        uaVarV5 = ((C0041Ia) uaVarV5).m448FH();
                    }
                    if (uaVarV5.rN()) {
                        ((La) this.f162FH).EQ.j6("Inheritors of " + uaVarV5.VH());
                        _b _bVarM285j6 = m285j6(uaVarV5.Zo().BT() || !z);
                        bc bcVar = new bc();
                        Yb yb = new Yb(this.f165Zo);
                        Yb yb2 = new Yb(this.f165Zo);
                        Yb yb3 = new Yb(this.f165Zo);
                        yb2.DW(uaVarV5);
                        while (true) {
                            yb3.j6();
                            bcVar.j6();
                            yb2.Hw.DW();
                            while (yb2.Hw.j6()) {
                                bcVar.DW(yb2.Hw.FH().we());
                            }
                            Yb yb4 = yb3;
                            Yb yb5 = yb2;
                            m289j6(bcVar, yb2, yb3, yb, _bVarM285j6, z);
                            yb5.j6();
                            yb5.FH(yb4);
                            if (yb4.Hw() == 0) {
                                break;
                            }
                            yb2 = yb5;
                            yb3 = yb4;
                        }
                    }
                }
            }
            this.f164VH.j6(saJ6);
            ((La) this.f162FH).EQ.DW();
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -5164143301857873240L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            throw th;
        }
    }

    public void m294j6(Da da, int i, int i2) {
        try {
            if (f161j6) {
                wu.j6(-211848059725856541L, this, da, new Integer(i), new Integer(i2));
            }
            ((La) this.f162FH).EQ.j6();
            Sa saJ6 = this.f164VH.j6(da, i, i2);
            int iU7 = saJ6.u7(i, i2);
            if (iU7 != -1) {
                saJ6.J8().Hw().DW(saJ6, iU7);
                saJ6.XL(iU7);
                if (saJ6.Zo(iU7) != 0) {
                    Aa aaV5 = saJ6.v5(iU7);
                    if (aaV5.yS() && ((C0041Ia) aaV5).m512oY()) {
                        ((La) this.f162FH).EQ.j6("Overridden methods of " + aaV5.VH());
                        Yb<C0041Ia> ybM459Sf = ((C0041Ia) aaV5).m459Sf();
                        ((Yb) ybM459Sf).Hw.DW();
                        while (((Yb) ybM459Sf).Hw.j6()) {
                            C0041Ia c0041Ia = (C0041Ia) ((Yb) ybM459Sf).Hw.FH();
                            if (c0041Ia != aaV5) {
                                ((La) this.f162FH).EQ.j6(c0041Ia);
                            }
                        }
                    } else if (aaV5.yS() && ((C0041Ia) aaV5).m484hz()) {
                        ((La) this.f162FH).EQ.j6("Overridden properties of " + aaV5.VH());
                        Yb<C0041Ia> ybM459Sf2 = ((C0041Ia) aaV5).m459Sf();
                        ((Yb) ybM459Sf2).Hw.DW();
                        while (((Yb) ybM459Sf2).Hw.j6()) {
                            C0041Ia c0041Ia2 = (C0041Ia) ((Yb) ybM459Sf2).Hw.FH();
                            if (c0041Ia2 != aaV5) {
                                ((La) this.f162FH).EQ.j6(c0041Ia2);
                            }
                        }
                    }
                }
            }
            this.f164VH.j6(saJ6);
            ((La) this.f162FH).EQ.DW();
        } catch (Throwable th) {
            if (f160DW) {
                wu.j6(th, -211848059725856541L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m295j6(Da da, int i, int i2, boolean z) throws Throwable {
        try {
            if (f161j6) {
                wu.j6(118702887397009800L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
            }
            ((La) this.f162FH).EQ.j6();
            try {
                Sa saJ6 = this.f164VH.j6(da, i, i2);
                int iU7 = saJ6.u7(i, i2);
                if (iU7 != -1) {
                    saJ6.J8().Hw().DW(saJ6, iU7);
                    int iZo = saJ6.Zo(iU7);
                    int iXL = saJ6.XL(iU7);
                    if (iZo != 0) {
                        ua uaVarV5 = saJ6.v5(iU7);
                        if (uaVarV5.yS() && ((C0041Ia) uaVarV5).m464XG()) {
                            uaVarV5 = ((C0041Ia) uaVarV5).m448FH();
                        }
                        ua uaVar = uaVarV5;
                        if (uaVar.rN()) {
                            ((La) this.f162FH).EQ.j6("Methods returning " + uaVar.VH());
                            Yb yb = new Yb(((La) this.f162FH).a8);
                            _b _bVarM285j6 = m285j6(uaVar.Zo().BT() || !z);
                            bc bcVar = new bc();
                            Yb yb2 = new Yb(this.f165Zo);
                            Yb yb3 = new Yb(this.f165Zo);
                            Yb yb4 = new Yb(this.f165Zo);
                            yb3.DW(uaVar);
                            while (true) {
                                yb4.j6();
                                bcVar.j6();
                                yb3.Hw.DW();
                                while (yb3.Hw.j6()) {
                                    bcVar.DW(yb3.Hw.FH().we());
                                }
                                Yb yb5 = yb4;
                                Yb yb6 = yb3;
                                Yb yb7 = yb2;
                                bc bcVar2 = bcVar;
                                Yb yb8 = yb;
                                m288j6(saJ6, bcVar, uaVar, yb3, yb4, yb2, _bVarM285j6, yb, z);
                                yb6.j6();
                                yb6.FH(yb5);
                                if (yb5.Hw() == 0) {
                                    break;
                                }
                                yb3 = yb6;
                                yb4 = yb5;
                                yb2 = yb7;
                                bcVar = bcVar2;
                                yb = yb8;
                            }
                            m287j6(saJ6, iXL, uaVar, _bVarM285j6, z, true, false);
                        }
                    }
                }
                this.f164VH.j6(saJ6);
                ((La) this.f162FH).EQ.DW();
            } catch (Throwable th) {
                th = th;
                if (f160DW) {
                    wu.j6(th, 118702887397009800L, this, da, new Integer(i), new Integer(i2), new Boolean(z));
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
