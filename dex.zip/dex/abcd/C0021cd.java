package abcd;

@xu
public class C0021cd {

    @uu
    private static boolean f63DW;

    @tu
    private static boolean f64j6;

    @ru(field = 103992830767946611L)
    private final La f65FH;

    @ru(field = -3417549030329440840L)
    private final yd f66Hw;

    @ru(field = 3334583485697315976L)
    private Yb<ua> f67Zo;

    @ru(field = 3721802357976431547L)
    private final Hd f68v5;

    static {
        wu.j6(C0021cd.class, -1595680503914442828L, -1595680503914442828L);
    }

    public C0021cd(La la, yd ydVar, Hd hd) {
        try {
            if (f64j6) {
                wu.j6(-6383341444506575013L, (Object) null, la, ydVar, hd);
            }
            this.f65FH = la;
            this.f66Hw = ydVar;
            this.f68v5 = hd;
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -6383341444506575013L, (Object) null, la, ydVar, hd);
            }
            throw th;
        }
    }

    @su(method = -571247119242875160L)
    private void m104DW(Sa sa, int i, String str) {
        try {
            if (f64j6) {
                wu.j6(221222261530273200L, this, sa, new Integer(i), str);
            }
            this.f65FH.gn.j6(sa.VH(), sa.QX(i), sa.Ws(i), sa.QX(i), sa.Ws(i), str);
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, 221222261530273200L, this, sa, new Integer(i), str);
            }
            throw th;
        }
    }

    @su(method = -770624755709990699L)
    private void m105FH(Sa sa, int i, String str) {
        try {
            if (f64j6) {
                wu.j6(8316019787100711L, this, sa, new Integer(i), str);
            }
            if (sa.XG(i)) {
                return;
            }
            this.f65FH.gn.j6(sa.VH(), sa.vy(i), sa.BT(i), sa.QX(i), sa.Ws(i), str);
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, 8316019787100711L, this, sa, new Integer(i), str);
            }
            throw th;
        }
    }

    @su(method = 1441794305857159056L)
    private void m106Hw(Sa sa, int i, String str) {
        try {
            if (f64j6) {
                wu.j6(7613045680373985816L, this, sa, new Integer(i), str);
            }
            if (sa.vy(i) != sa.QX(i) || sa.BT(i) != sa.Ws(i)) {
                str = str.trim();
            }
            m105FH(sa, i, str);
        } catch (Throwable th) {
            String str2 = str;
            if (f63DW) {
                wu.j6(th, 7613045680373985816L, this, sa, new Integer(i), str2);
            }
            throw th;
        }
    }

    @su(method = 165640401617673800L)
    private void m107j6(Sa sa, int i) {
        try {
            if (f64j6) {
                wu.j6(244532469758567316L, this, sa, new Integer(i));
            }
            String str = "";
            try {
                switch (sa.P8(i)) {
                    case 1:
                        if (sa.Zo(i) == 27 && sa.XL(i) == this.f65FH.j3.j6("length")) {
                            m105FH(sa, i, "Length");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("out")) {
                            m105FH(sa, i, "@out");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("in")) {
                            m105FH(sa, i, "@in");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("namespace")) {
                            m105FH(sa, i, "@namespace");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("operator")) {
                            m105FH(sa, i, "@operator");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("lock")) {
                            m105FH(sa, i, "@lock");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("string")) {
                            m105FH(sa, i, "str");
                            return;
                        }
                        if ((sa.Zo(i) != 8 && sa.Zo(i) != 9 && sa.Zo(i) != 10 && sa.Zo(i) != 17 && sa.Zo(i) != 22 && sa.Zo(i) != 23 && sa.Zo(i) != 24 && sa.Zo(i) != 25) || sa.v5(i).Zo().BT()) {
                            if (sa.Zo(i) != 20 && sa.Zo(i) != 19) {
                                if (sa.Zo(i) == 16) {
                                    Ia iaV5 = sa.v5(i);
                                    if (iaV5.mb()) {
                                        ua uaVarFH = iaV5.FH();
                                        if (this.f67Zo.j6(uaVarFH)) {
                                            m109j6(sa, i, uaVarFH.a8() + ".");
                                            return;
                                        }
                                        return;
                                    }
                                    return;
                                }
                                return;
                            }
                            String strJ6 = this.f65FH.j3.j6(sa.XL(i));
                            if (strJ6.length() > 0) {
                                String str2 = Character.toUpperCase(strJ6.charAt(0)) + strJ6.substring(1, strJ6.length());
                                if (strJ6.equals(str2)) {
                                    return;
                                }
                                m105FH(sa, i, str2);
                                return;
                            }
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("Reader")) {
                            m105FH(sa, i, "TextReader");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("ArrayList")) {
                            m105FH(sa, i, "List");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("Vector")) {
                            m105FH(sa, i, "List");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("Map")) {
                            m105FH(sa, i, "Dictionary");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("HashMap")) {
                            m105FH(sa, i, "Dictionary");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("File")) {
                            m105FH(sa, i, "Path");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("Long")) {
                            m105FH(sa, i, "long");
                            return;
                        }
                        if (sa.XL(i) == this.f65FH.j3.j6("Integer")) {
                            m105FH(sa, i, "int");
                            return;
                        } else if (sa.XL(i) == this.f65FH.j3.j6("StringBuffer")) {
                            m105FH(sa, i, "StringBuilder");
                            return;
                        } else {
                            if (sa.XL(i) == this.f65FH.j3.j6("InputStream")) {
                                m105FH(sa, i, "Stream");
                                return;
                            }
                            return;
                        }
                    case 60:
                        m105FH(sa, i, "sbyte");
                        return;
                    case 78:
                        if (sa.XG(i)) {
                            return;
                        }
                        m105FH(sa, i, "base");
                        return;
                    case 89:
                        m105FH(sa, i, "bool");
                        return;
                    case 103:
                        m105FH(sa, i, "is");
                        return;
                    case 104:
                        m105FH(sa, i, "lock");
                        return;
                    case 120:
                    case 227:
                        ua uaVarJ6 = this.f65FH.a8.j6(sa.VH(), sa.J8(), sa.J8(i));
                        m107j6(sa, sa.Zo(i, sa.we(i) - 1));
                        int iZo = sa.Zo(i, 5);
                        int iZo2 = sa.Zo(i, 4);
                        if (sa.we(iZo2) > 0) {
                            if (sa.we(iZo) > 0) {
                                m105FH(sa, sa.Zo(iZo, 0), ",");
                            }
                            m105FH(sa, sa.Zo(iZo2, 0), ":");
                        } else if (sa.we(iZo) > 0) {
                            m105FH(sa, sa.Zo(iZo, 0), ":");
                        }
                        m107j6(sa, sa.Zo(i, 3));
                        str = Ma.J8(uaVarJ6.XL()) ? "public " : "";
                        if (Ma.J0(uaVarJ6.XL())) {
                            str = str + "public ";
                        }
                        if (Ma.XL(uaVarJ6.XL())) {
                            str = str + "sealed ";
                        }
                        m106Hw(sa, sa.Zo(i, 0), str);
                        return;
                    case 124:
                        Ia iaDW = this.f65FH.a8.DW(sa.VH(), sa.J8(), sa.J8(i));
                        for (int iWe = sa.we(i) - 1; iWe >= 1; iWe--) {
                            m107j6(sa, sa.Zo(i, iWe));
                        }
                        if (!iaDW.FH().g3()) {
                            str = Ma.J0(iaDW.XL()) ? "protected " : "";
                            if (Ma.gn(iaDW.XL())) {
                                str = str + "private ";
                            }
                            if (Ma.J8(iaDW.XL())) {
                                str = str + "public ";
                            }
                            if (Ma.we(iaDW.XL())) {
                                str = str + "internal ";
                            }
                            if (Ma.aM(iaDW.XL())) {
                                str = str + "static ";
                            }
                            if (Ma.j6(iaDW.XL())) {
                                str = str + "abstract ";
                            } else if (iaDW.sy()) {
                                str = str + "override ";
                            } else if (!Ma.XL(iaDW.XL()) && !Ma.aM(iaDW.XL()) && !Ma.gn(iaDW.XL())) {
                                str = str + "virtual ";
                            }
                        }
                        m106Hw(sa, sa.Zo(i, 0), str);
                        return;
                    case 126:
                        Ia iaDW2 = this.f65FH.a8.DW(sa.VH(), sa.J8(), sa.J8(sa.Zo(i, 3)));
                        for (int iWe2 = sa.we(i) - 1; iWe2 >= 1; iWe2--) {
                            m107j6(sa, sa.Zo(i, iWe2));
                        }
                        str = Ma.J0(iaDW2.XL()) ? "protected " : "";
                        if (Ma.gn(iaDW2.XL())) {
                            str = str + "private ";
                        }
                        if (Ma.J8(iaDW2.XL())) {
                            str = str + "public ";
                        }
                        if (Ma.we(iaDW2.XL())) {
                            str = str + "internal ";
                        }
                        if (Ma.Hw(iaDW2.XL()) && Ma.aM(iaDW2.XL())) {
                            str = str + "const ";
                        } else if (Ma.Hw(iaDW2.XL()) && !Ma.aM(iaDW2.XL())) {
                            str = str + "readonly ";
                        } else if (Ma.aM(iaDW2.XL())) {
                            str = str + "static ";
                        }
                        m106Hw(sa, sa.Zo(i, 0), str);
                        return;
                    case 180:
                        if (sa.ro(i) && sa.u7(i) == this.f68v5.ei(sa.VH())) {
                            m105FH(sa, i, "string");
                            return;
                        }
                        for (int iWe3 = sa.we(i) - 1; iWe3 >= 0; iWe3--) {
                            m107j6(sa, sa.Zo(i, iWe3));
                        }
                        return;
                    case 195:
                        m105FH(sa, i, "");
                        return;
                    case 208:
                        if (sa.we(i) > 1) {
                            m108j6(sa, sa.Zo(i, 1), sa.Zo(i, sa.we(i) - 1), "");
                            return;
                        }
                        return;
                    case 211:
                        m107j6(sa, sa.Zo(i, sa.we(i) - 1));
                        m107j6(sa, sa.Zo(i, sa.we(i) - 3));
                        m105FH(sa, sa.Zo(i, sa.we(i) - 4), "in");
                        for (int iWe4 = sa.we(i) - 5; iWe4 >= 1; iWe4--) {
                            m107j6(sa, sa.Zo(i, iWe4));
                        }
                        m105FH(sa, sa.Zo(i, 0), "foreach");
                        return;
                    case 213:
                    case 214:
                        m105FH(sa, i, "");
                        return;
                    case 225:
                        if (sa.XG(i)) {
                            return;
                        }
                        m105FH(sa, sa.Zo(i, 0), "using");
                        return;
                    case 226:
                        if (sa.XG(i)) {
                            return;
                        }
                        m108j6(sa, sa.Zo(i, sa.we(i) - 3), sa.Zo(i, sa.we(i) - 2), "");
                        m105FH(sa, sa.Zo(i, 0), "using");
                        return;
                    case 230:
                        m105FH(sa, i, "");
                        return;
                    default:
                        for (int iWe5 = sa.we(i) - 1; iWe5 >= 0; iWe5--) {
                            m107j6(sa, sa.Zo(i, iWe5));
                        }
                        return;
                }
            } catch (jc unused) {
            }
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, 244532469758567316L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 69694953771841384L)
    private void m108j6(Sa sa, int i, int i2, String str) {
        try {
            if (f64j6) {
                wu.j6(8106363743677126164L, this, sa, new Integer(i), new Integer(i2), str);
            }
            this.f65FH.gn.j6(sa.VH(), sa.vy(i), sa.BT(i), sa.QX(i2), sa.Ws(i2), str);
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, 8106363743677126164L, this, sa, new Integer(i), new Integer(i2), str);
            }
            throw th;
        }
    }

    @su(method = 229983596541304725L)
    private void m109j6(Sa sa, int i, String str) {
        try {
            if (f64j6) {
                wu.j6(-39093188860916325L, this, sa, new Integer(i), str);
            }
            this.f65FH.gn.j6(sa.VH(), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), str);
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -39093188860916325L, this, sa, new Integer(i), str);
            }
            throw th;
        }
    }

    public void m110j6(Da da, String str) {
        try {
            if (f64j6) {
                wu.j6(-3381069999300397497L, this, da, str);
            }
            Sa saDW = this.f65FH.U2.DW(da, this.f66Hw);
            this.f66Hw.Hw().m352DW(saDW);
            this.f67Zo = new Yb(this.f65FH.a8);
            int iWe = saDW.we(saDW.aM());
            for (int i = 0; i < iWe; i++) {
                int iZo = saDW.Zo(saDW.aM(), i);
                if (saDW.P8(iZo) == 214) {
                    int iZo2 = saDW.Zo(iZo, saDW.we(iZo) - 4);
                    if (saDW.Zo(iZo2) == 8) {
                        this.f67Zo.DW(saDW.v5(iZo2));
                    }
                }
            }
            int iZo3 = saDW.Zo(saDW.aM(), 0);
            if (saDW.we(iZo3) > 0) {
                m104DW(saDW, saDW.aM(), "\n}");
            }
            m107j6(saDW, saDW.aM());
            if (saDW.we(iZo3) > 0) {
                m104DW(saDW, iZo3, " {\nusing System;\nusing System.IO;\nusing System.Text;\nusing System.Collections.Generic;\n");
                m105FH(saDW, saDW.Zo(iZo3, saDW.we(iZo3) - 1), "");
                m105FH(saDW, saDW.Zo(iZo3, 1), "namespace");
            }
            this.f65FH.U2.j6(saDW);
        } catch (Throwable th) {
            if (f63DW) {
                wu.j6(th, -3381069999300397497L, this, da, str);
            }
            throw th;
        }
    }
}
