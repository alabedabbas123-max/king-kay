package abcd;

import com.aide.common.h;
import com.aide.common.ma;
import com.aide.engine.Modification;
import com.aide.ui.U;
import com.aide.ui.aa;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

@xu
public class C0014ol {

    @uu
    private static boolean f85DW;

    @tu
    private static boolean f86j6;

    static {
        wu.j6(C0014ol.class, -1401858080030435915L, -1401858080030435915L);
    }

    public C0014ol() {
        try {
            if (f86j6) {
                wu.j6(3074699047031413017L, (Object) null);
            }
        } catch (Throwable th) {
            if (f85DW) {
                wu.j6(th, 3074699047031413017L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = 52244996607952165L)
    public void m45DW(List<Modification> list) {
        Xj xjEQ;
        try {
            if (f86j6) {
                wu.j6(8759941853249604240L, this, list);
            }
            try {
                try {
                    U.EQ().we();
                    boolean z = false;
                    for (int i = 0; i < list.size(); i++) {
                        Modification modification = list.get(i);
                        int iTp = modification.tp();
                        if (iTp == 0) {
                            try {
                                U.er().v5(modification.v5()).j6(modification.u7(), modification.gn(), modification.Hw(), modification.FH(), modification.VH(), modification.EQ(), modification.v5().equals(U.er().DW()));
                            } catch (IOException e) {
                                ma.j6(U.lg(), "Modify Files", e);
                            }
                        } else if (iTp == 1) {
                            try {
                                String strV5 = modification.v5();
                                String str = Vl.EQ(strV5) + File.separator + modification.VH();
                                Vl.Zo(strV5, str);
                                U.er().j6(strV5, str);
                                U.tp().DW(Vl.EQ(strV5));
                                z = true;
                            } catch (IOException e2) {
                                ma.j6(U.lg(), "Modify Files", e2);
                            }
                        } else if (iTp == 2) {
                            U.EQ().gn();
                            List listDW = U.EQ().DW(modification.v5(), modification.u7(), modification.Hw(), aa.cn());
                            if (listDW != null) {
                                for (int size = listDW.size() - 1; size >= 0; size--) {
                                    list.add(i + 1, (Modification) listDW.get(size));
                                }
                            }
                            U.EQ().we();
                        } else if (iTp == 3) {
                            try {
                                U.er().v5(modification.v5()).j6(modification.u7(), modification.gn(), modification.Hw(), modification.FH(), modification.DW(), modification.j6());
                            } catch (IOException e3) {
                                ma.j6(U.lg(), "Modify Files", e3);
                            }
                        } else if (iTp == 7) {
                            try {
                                U.er().v5(modification.v5()).DW(modification.u7(), modification.gn(), modification.Hw(), modification.FH(), modification.DW(), modification.j6());
                            } catch (IOException e4) {
                                ma.j6(U.lg(), "Modify Files", e4);
                            }
                        } else if (iTp == 8) {
                            U.lg().j6(new Tl(modification.v5(), modification.u7(), modification.gn(), modification.Hw(), modification.FH()), false);
                        } else if (iTp == 11) {
                            try {
                                U.er().v5(modification.v5()).j6(modification.u7(), modification.Zo());
                            } catch (IOException e5) {
                                ma.j6(U.lg(), "Modify Files", e5);
                            }
                        } else if (iTp == 12) {
                            try {
                                Vl.a8(Vl.EQ(modification.v5()));
                                Vl.j6(modification.v5(), modification.VH());
                                U.er().v5(modification.v5());
                            } catch (IOException e6) {
                                ma.j6(U.lg(), "Modify Files", e6);
                            }
                        }
                    }
                    try {
                        U.er().J0();
                    } catch (IOException e7) {
                        ma.j6(U.lg(), "Modify Files", e7);
                    }
                    if (z) {
                        U.vy().er();
                        U.J8().Hw();
                    }
                    U.EQ().VH();
                    xjEQ = U.EQ();
                } catch (Throwable th) {
                    U.EQ().gn();
                    throw th;
                }
            } catch (Throwable th2) {
                h.j6(th2);
                xjEQ = U.EQ();
            }
            xjEQ.gn();
        } catch (Throwable th3) {
            if (f85DW) {
                wu.j6(th3, 8759941853249604240L, this, list);
            }
            throw th3;
        }
    }

    public void m47j6() {
        try {
            if (f86j6) {
                wu.j6(-3705311679461573176L, this);
            }
            U.EQ().j6(new ml(this));
        } catch (Throwable th) {
            if (f85DW) {
                wu.j6(th, -3705311679461573176L, this);
            }
            throw th;
        }
    }

    public void m48j6(List<Modification> list) {
        try {
            if (f86j6) {
                wu.j6(-4627938854537139501L, this, list);
            }
            U.lg().Hw();
            if (list == null) {
                return;
            }
            HashSet hashSet = new HashSet();
            boolean z = false;
            for (Modification modification : list) {
                int iTp = modification.tp();
                if (iTp == 0 || iTp == 3 || iTp == 7 || iTp == 11 || iTp == 12) {
                    hashSet.add(modification.v5());
                    if (!modification.v5().equals(U.er().DW())) {
                        z = true;
                    }
                }
            }
            if (!z) {
                m45DW(list);
                return;
            }
            ArrayList arrayList = new ArrayList();
            Iterator it = hashSet.iterator();
            while (it.hasNext()) {
                arrayList.add(Vl.tp((String) it.next()));
            }
            ma.j6(U.lg(), com.aide.pro.R.string.dialog_modify_title, com.aide.pro.R.string.dialog_modify_message, arrayList, new nl(this, list), (Runnable) null);
        } catch (Throwable th) {
            if (f85DW) {
                wu.j6(th, -4627938854537139501L, this, list);
            }
            throw th;
        }
    }
}
