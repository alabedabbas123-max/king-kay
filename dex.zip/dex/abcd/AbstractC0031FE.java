package abcd;

import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;

public abstract class AbstractC0031FE {

    public static class a extends AbstractC0031FE {

        private final byte[] f182DW;

        private final int f183j6;

        public a(int i, byte[] bArr) {
            this.f183j6 = i;
            this.f182DW = bArr;
        }

        @Override
        public long mo326DW() {
            return mo331j6().length;
        }

        @Override
        public int mo328FH() {
            return this.f183j6;
        }

        @Override
        public boolean mo329Hw() {
            return false;
        }

        @Override
        public byte[] mo331j6() {
            return this.f182DW;
        }

        @Override
        public JE mo333v5() {
            return new JE.b(this);
        }
    }

    private static byte[] m325j6(byte[] bArr) {
        byte[] bArr2 = new byte[bArr.length];
        System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        return bArr2;
    }

    public abstract long mo326DW();

    public byte[] m327DW(int i) throws IOException {
        if (!mo329Hw()) {
            return mo331j6();
        }
        JE jeMo333v5 = mo333v5();
        try {
            long jJ6 = jeMo333v5.j6();
            long j = i;
            if (j < jJ6) {
                throw new cD.b(j, jJ6);
            }
            if (2147483647L < jJ6) {
                throw new cD.a();
            }
            try {
                byte[] bArr = new byte[(int) jJ6];
                BK.j6(jeMo333v5, bArr, 0, bArr.length);
                jeMo333v5.close();
                return bArr;
            } catch (OutOfMemoryError e) {
                throw new cD.c(e);
            }
        } catch (Throwable th) {
            jeMo333v5.close();
            throw th;
        }
    }

    public abstract int mo328FH();

    public abstract boolean mo329Hw();

    public void m330j6(OutputStream outputStream) throws IOException {
        if (!mo329Hw()) {
            outputStream.write(mo331j6());
            return;
        }
        JE jeMo333v5 = mo333v5();
        try {
            long jJ6 = jeMo333v5.j6();
            byte[] bArr = new byte[8192];
            long j = 0;
            while (j < jJ6) {
                int i = jeMo333v5.read(bArr);
                if (i < 0) {
                    throw new EOFException();
                }
                outputStream.write(bArr, 0, i);
                j += (long) i;
            }
            if (jeMo333v5.read() >= 0) {
                throw new EOFException();
            }
            jeMo333v5.close();
        } catch (Throwable th) {
            jeMo333v5.close();
            throw th;
        }
    }

    public abstract byte[] mo331j6();

    public final byte[] m332j6(int i) throws cD.c {
        try {
            return m325j6(m327DW(i));
        } catch (OutOfMemoryError e) {
            throw new cD.c(e);
        }
    }

    public abstract JE mo333v5();
}
