package abcd;

public final class C0016Hs extends ms {

    public static final C0016Hs f103j6 = new C0016Hs(new C0101Js("TYPE"), new C0101Js("Ljava/lang/Class;"));

    private final C0101Js f104DW;

    private final C0101Js f105FH;

    public C0016Hs(C0101Js c0101Js, C0101Js c0101Js2) {
        if (c0101Js == null) {
            throw new NullPointerException("name == null");
        }
        if (c0101Js2 == null) {
            throw new NullPointerException("descriptor == null");
        }
        this.f104DW = c0101Js;
        this.f105FH = c0101Js2;
    }

    protected int m178DW(ms msVar) {
        C0016Hs c0016Hs = (C0016Hs) msVar;
        int iJ6 = this.f104DW.j6(c0016Hs.f104DW);
        return iJ6 != 0 ? iJ6 : this.f105FH.j6(c0016Hs.f105FH);
    }

    public boolean m179Hw() {
        return false;
    }

    public C0101Js m180J8() {
        return this.f104DW;
    }

    public C0101Js m181VH() {
        return this.f105FH;
    }

    public final boolean m182Ws() {
        return this.f104DW.m977we().equals("<clinit>");
    }

    public String m183Zo() {
        return "nat";
    }

    public String m184aM() {
        return this.f104DW.m974aM() + ':' + this.f105FH.m974aM();
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0016Hs)) {
            return false;
        }
        C0016Hs c0016Hs = (C0016Hs) obj;
        return this.f104DW.equals(c0016Hs.f104DW) && this.f105FH.equals(c0016Hs.f105FH);
    }

    public int hashCode() {
        return (this.f104DW.hashCode() * 31) ^ this.f105FH.hashCode();
    }

    public final boolean m185lg() {
        return this.f104DW.m977we().equals("<init>");
    }

    public String toString() {
        return "nat{" + m184aM() + '}';
    }

    public Qs m186we() {
        return Qs.j6(this.f105FH.m977we());
    }
}
