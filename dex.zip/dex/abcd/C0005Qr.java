package abcd;

public final class C0005Qr implements ls {

    private final boolean f14FH;

    public static final C0005Qr f13j6 = new C0005Qr();

    public static final C0005Qr f12DW = new C0005Qr(true);

    private C0005Qr() {
        this.f14FH = false;
    }

    private C0005Qr(boolean z) {
        this.f14FH = z;
    }

    private int m37j6(cs csVar) {
        int size = csVar.size();
        int iHw = 0;
        for (int i = 0; i < size; i++) {
            iHw += csVar.get(i).Hw();
        }
        return iHw;
    }

    public int m38j6() {
        return 16;
    }

    public boolean m39j6(es esVar, bs bsVar, bs bsVar2) {
        if (bsVar.getType() != C0006Qs.f28VH) {
            return false;
        }
        if (!(bsVar2.J8() instanceof ys)) {
            if ((bsVar.J8() instanceof ys) && esVar.Hw() == 15) {
                return bsVar.J8().VH();
            }
            return false;
        }
        ys ysVarJ8 = bsVar2.J8();
        switch (esVar.Hw()) {
            case 14:
            case 16:
            case 17:
            case 18:
            case 20:
            case 21:
            case 22:
                return ysVarJ8.VH();
            case 15:
                return ys.j6(-ysVarJ8.rN()).VH();
            case 19:
            default:
                return false;
            case 23:
            case 24:
            case 25:
                return ysVarJ8.we();
        }
    }

    public boolean m40j6(es esVar, cs csVar) {
        return !this.f14FH && esVar.VH() && m37j6(csVar) >= 6;
    }
}
