package abcd;

public class C0020vE implements LE {

    public static final C0020vE f34j6 = new C0020vE();

    private C0020vE() {
    }

    public boolean isCancelled() {
        return false;
    }

    public void m81j6() {
    }

    public void m82j6(String str, int i) {
    }

    public void start(int i) {
    }

    public void update(int i) {
    }
}
