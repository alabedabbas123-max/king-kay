package abcd;

public final class C0021os extends ms {

    private final Hr f361j6;

    public C0021os(Hr hr) {
        if (hr == null) {
            throw new NullPointerException("annotation == null");
        }
        hr.Ws();
        this.f361j6 = hr;
    }

    protected int m76DW(ms msVar) {
        return this.f361j6.j6(((C0021os) msVar).f361j6);
    }

    public boolean m77Hw() {
        return false;
    }

    public Hr m78VH() {
        return this.f361j6;
    }

    public String m79Zo() {
        return "annotation";
    }

    public String m80aM() {
        return this.f361j6.toString();
    }

    public boolean equals(Object obj) {
        if (obj instanceof C0021os) {
            return this.f361j6.equals(((C0021os) obj).f361j6);
        }
        return false;
    }

    public int hashCode() {
        return this.f361j6.hashCode();
    }

    public String toString() {
        return this.f361j6.toString();
    }
}
