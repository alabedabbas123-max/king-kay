package abcd;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@xu
public class C0018ca {

    @uu
    private static boolean f52DW;

    @tu
    private static boolean f53j6;

    @ru(field = -1420197080429944196L)
    private final C0106ea f54FH;

    @ru(field = 1535582088253125792L)
    private List<String> f55Hw;

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unexpected branching in enum static init block */
    @xu
    private static final class a {

        @ru(field = 1318322202870435900L)
        public static final a f56DW;

        @ru(field = 5771517785451500820L)
        public static final a f57FH;

        @ru(field = 253668929672137807L)
        public static final a f58Hw;

        @uu
        private static boolean f59VH;

        @tu
        private static boolean f60Zo;

        @ru(field = -1278772349581971965L)
        public static final a f61j6;

        private static final a[] f62v5;

        static {
            try {
                wu.j6(a.class, 4820548802342387328L, 4820548802342387328L);
                if (f60Zo) {
                    wu.j6(-440410237080866745L, (Object) null);
                }
                f61j6 = new a("START", 0);
                f56DW = new a("DOLLAR_READ", 1);
                f57FH = new a("DOLLAR_NUMBER_READ", 2);
                f58Hw = new a("DOLLAR_PAREN_READ", 3);
                f62v5 = new a[]{f61j6, f56DW, f57FH, f58Hw};
            } catch (Throwable th) {
                if (f59VH) {
                    wu.j6(th, -440410237080866745L, (Object) null);
                }
                throw th;
            }
        }

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        @su(method = -118229739546468643L)
        private a(String str, int i) {
            super(str, i);
            try {
                if (f60Zo) {
                    wu.j6(1298458570599949248L, (Object) null, str, new Integer(i));
                }
            } catch (Throwable th) {
                if (f59VH) {
                    wu.j6(th, 1298458570599949248L, (Object) null, str, new Integer(i));
                }
                throw th;
            }
        }

        @su(method = -764531088161789052L)
        public static a valueOf(String str) {
            try {
                if (f60Zo) {
                    wu.j6(245931603353716811L, (Object) null, str);
                }
                return (a) Enum.valueOf(a.class, str);
            } catch (Throwable th) {
                if (f59VH) {
                    wu.j6(th, 245931603353716811L, (Object) null, str);
                }
                throw th;
            }
        }

        @su(method = 1853150766664029184L)
        public static a[] values() {
            try {
                if (f60Zo) {
                    wu.j6(2377543822108765865L, (Object) null);
                }
                return (a[]) f62v5.clone();
            } catch (Throwable th) {
                if (f59VH) {
                    wu.j6(th, 2377543822108765865L, (Object) null);
                }
                throw th;
            }
        }
    }

    static {
        wu.j6(C0018ca.class, 340607572698323840L, 340607572698323840L);
    }

    public C0018ca(C0106ea c0106ea) {
        try {
            if (f53j6) {
                wu.j6(-1779991663647602448L, (Object) null, c0106ea);
            }
            this.f54FH = c0106ea;
        } catch (Throwable th) {
            if (f52DW) {
                wu.j6(th, -1779991663647602448L, (Object) null, c0106ea);
            }
            throw th;
        }
    }

    @su(method = -1472725045402226016L)
    private List<Integer> m87DW(String str) {
        try {
            if (f53j6) {
                wu.j6(-35370548446501285L, this, str);
            }
            ArrayList arrayList = new ArrayList();
            a aVar = a.f61j6;
            StringBuffer stringBuffer = new StringBuffer();
            a aVar2 = aVar;
            for (int i = 0; i < str.length(); i++) {
                char cCharAt = str.charAt(i);
                int i2 = ba.j6[aVar2.ordinal()];
                if (i2 != 1) {
                    if (i2 != 2) {
                        if (i2 != 3) {
                            if (i2 == 4 && cCharAt == ')') {
                                aVar2 = a.f57FH;
                            }
                        } else if (cCharAt == '$') {
                            if (stringBuffer.length() > 0) {
                                try {
                                    arrayList.add(Integer.valueOf(Integer.parseInt(stringBuffer.toString())));
                                } catch (NumberFormatException unused) {
                                }
                            }
                            aVar2 = a.f61j6;
                        } else if (cCharAt == '(') {
                            aVar2 = a.f58Hw;
                        }
                    } else if (cCharAt == '$') {
                        if (stringBuffer.length() > 0) {
                            try {
                                arrayList.add(Integer.valueOf(Integer.parseInt(stringBuffer.toString())));
                            } catch (NumberFormatException unused2) {
                            }
                        }
                        aVar2 = a.f61j6;
                    } else if (cCharAt == '(') {
                        aVar2 = a.f58Hw;
                    } else if (cCharAt < '0' || cCharAt > '9') {
                        aVar2 = a.f57FH;
                    } else {
                        stringBuffer.append(cCharAt);
                    }
                } else if (cCharAt == '$') {
                    stringBuffer.setLength(0);
                    aVar2 = a.f56DW;
                }
            }
            Collections.sort(arrayList);
            return arrayList;
        } catch (Throwable th) {
            if (f52DW) {
                wu.j6(th, -35370548446501285L, this, str);
            }
            throw th;
        }
    }

    @su(method = 5138338570135835075L)
    private int m88FH(String str) {
        try {
            if (f53j6) {
                wu.j6(60144035012393200L, this, str);
            }
            try {
                return str.indexOf(61) == -1 ? Integer.parseInt(str) : Integer.parseInt(str.substring(0, str.indexOf(61)));
            } catch (NumberFormatException unused) {
                return 0;
            }
        } catch (Throwable th) {
            if (f52DW) {
                wu.j6(th, 60144035012393200L, this, str);
            }
            throw th;
        }
    }

    @su(method = 1577985851696311795L)
    private String m89j6(String str) {
        try {
            if (f53j6) {
                wu.j6(2117559930838360020L, this, str);
            }
            return (str.startsWith("$") && str.endsWith("$")) ? str.substring(1, str.length() - 1) : "";
        } catch (Throwable th) {
            if (f52DW) {
                wu.j6(th, 2117559930838360020L, this, str);
            }
            throw th;
        }
    }

    @su(method = 4825787225887631723L)
    private List<String> m91j6(String str, int i, Map<String, String> map, Da da, int i2, int i3, na naVar) {
        int i4;
        int iLastIndexOf;
        List<String> listM93j6;
        if (f53j6) {
            wu.j6(-3328253741340620528L, this, new Object[]{str, new Integer(i), map, da, new Integer(i2), new Integer(i3), naVar});
        }
        String strSubstring = str;
        while (true) {
            int iLastIndexOf2 = strSubstring.lastIndexOf(36);
            if (iLastIndexOf2 == -1 || (iLastIndexOf = strSubstring.lastIndexOf(36, (i4 = iLastIndexOf2 - 1))) == -1) {
                break;
            }
            int iLastIndexOf3 = iLastIndexOf;
            while (iLastIndexOf3 != -1 && strSubstring.lastIndexOf(41, i4) >= iLastIndexOf3 && strSubstring.lastIndexOf(40, i4) < iLastIndexOf3) {
                iLastIndexOf3 = strSubstring.lastIndexOf(36, iLastIndexOf3 - 1);
            }
            String strSubstring2 = strSubstring.substring(iLastIndexOf3 + 1, iLastIndexOf2);
            if (m88FH(strSubstring2) == i && (listM93j6 = m93j6(strSubstring2, map, da, i2, i3, naVar)) != null) {
                return listM93j6;
            }
            strSubstring = strSubstring.substring(0, iLastIndexOf3);
        }
        return Collections.EMPTY_LIST;
    }

    @su(method = 335884553739459185L)
    private List<String> m92j6(String str, List<String> list, Da da, int i, int i2, na naVar) {
        if (f53j6) {
            wu.j6(6723055715128127960L, this, new Object[]{str, list, da, new Integer(i), new Integer(i2), naVar});
        }
        this.f55Hw = new ArrayList();
        naVar.u7().j6(new aa(this), da, i, i2, str, list);
        return this.f55Hw;
    }

    @su(method = 2914420775136453632L)
    private List<String> m93j6(String str, Map<String, String> map, Da da, int i, int i2, na naVar) {
        if (f53j6) {
            wu.j6(-4492688182664606281L, this, new Object[]{str, map, da, new Integer(i), new Integer(i2), naVar});
        }
        if (str.indexOf(61) == -1) {
            return null;
        }
        String strSubstring = str.substring(str.indexOf(61) + 1, str.length());
        if (strSubstring.indexOf(40) == -1) {
            return null;
        }
        String strSubstring2 = strSubstring.substring(0, strSubstring.indexOf(40));
        String strSubstring3 = strSubstring.substring(strSubstring.indexOf(40) + 1, strSubstring.length() - 1);
        ArrayList arrayList = new ArrayList();
        if (strSubstring3.length() > 0) {
            while (strSubstring3.indexOf(44) != -1) {
                String strSubstring4 = strSubstring3.substring(0, strSubstring3.indexOf(44));
                if (map.containsKey(m89j6(strSubstring4))) {
                    strSubstring4 = map.get(m89j6(strSubstring4));
                }
                arrayList.add(strSubstring4);
                strSubstring3 = strSubstring3.substring(strSubstring3.indexOf(44) + 1, strSubstring3.length());
            }
            if (map.containsKey(m89j6(strSubstring3))) {
                strSubstring3 = map.get(m89j6(strSubstring3));
            }
            arrayList.add(strSubstring3);
        }
        return m92j6(strSubstring2, arrayList, da, i, i2, naVar);
    }

    public int m94j6(Map<String, String> map, String str, int i, int i2, Da da, int i3, int i4) {
        int iIntValue;
        int i5;
        int i6;
        int i7;
        if (f53j6) {
            iIntValue = i;
            i5 = i2;
            wu.j6(63504214519713200L, this, new Object[]{map, str, new Integer(iIntValue), new Integer(i5), da, new Integer(i3), new Integer(i4)});
        } else {
            iIntValue = i;
            i5 = i2;
        }
        Sa saFH = ((La) this.f54FH).U2.FH(da, i3, i4);
        if (saFH.J8().u7() == null) {
            return i5;
        }
        int i8 = i5;
        for (Integer num : m87DW(str)) {
            if (iIntValue == -1) {
                iIntValue = num.intValue();
            }
            if (num.intValue() >= iIntValue) {
                i6 = iIntValue;
                i7 = i8;
                List<String> listM91j6 = m91j6(str, num.intValue(), map, da, i3, i4, saFH.J8());
                if (listM91j6.isEmpty()) {
                    map.put(num + "", "V" + num);
                } else if (num.intValue() == i6) {
                    i8 = i7 >= listM91j6.size() ? 0 : i7;
                    map.put(num + "", listM91j6.get(i8));
                } else {
                    map.put(num + "", listM91j6.get(0));
                    i8 = i7;
                }
                iIntValue = i6;
            } else {
                i6 = iIntValue;
                i7 = i8;
            }
            i8 = i7;
            iIntValue = i6;
        }
        return i8;
    }
}
