package abcd;

public abstract class AbstractC0091eC {

    private static int[] f372DW;

    private static int[] f373j6;

    public enum a {
        MYERS,
        HISTOGRAM;

        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            int length = aVarArrValuesCustom.length;
            a[] aVarArr = new a[length];
            System.arraycopy(aVarArrValuesCustom, 0, aVarArr, 0, length);
            return aVarArr;
        }
    }

    static int[] m453DW() {
        int[] iArr = f372DW;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[jC.a.values().length];
        try {
            iArr2[jC.a.DW.ordinal()] = 2;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[jC.a.Hw.ordinal()] = 4;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[jC.a.j6.ordinal()] = 1;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[jC.a.FH.ordinal()] = 3;
        } catch (NoSuchFieldError unused4) {
        }
        f372DW = iArr2;
        return iArr2;
    }

    public static AbstractC0091eC m454j6(a aVar) {
        int i = m456j6()[aVar.ordinal()];
        if (i == 1) {
            return sC.j6;
        }
        if (i == 2) {
            return new oC();
        }
        throw new IllegalArgumentException();
    }

    private static <S extends CC> jC m455j6(S s, S s2) {
        return new jC(0, s.j6(), 0, s2.j6());
    }

    static int[] m456j6() {
        int[] iArr = f373j6;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[a.valuesCustom().length];
        try {
            iArr2[a.HISTOGRAM.ordinal()] = 2;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[a.MYERS.ordinal()] = 1;
        } catch (NoSuchFieldError unused2) {
        }
        f373j6 = iArr2;
        return iArr2;
    }

    public abstract <S extends CC> kC m457DW(DC<? super S> dc, S s, S s2);

    public <S extends CC> kC m458j6(DC<? super S> dc, S s, S s2) {
        jC jCVarJ6 = dc.j6(s, s2, m455j6(s, s2));
        int i = m453DW()[jCVarJ6.gn().ordinal()];
        if (i == 1 || i == 2) {
            return kC.j6(jCVarJ6);
        }
        if (i != 3) {
            if (i == 4) {
                return new kC(0);
            }
            throw new IllegalStateException();
        }
        HC hc = new HC(dc);
        GC gcJ6 = GC.j6(s, jCVarJ6);
        GC gcDW = GC.DW(s2, jCVarJ6);
        kC kCVarM457DW = m457DW(hc, gcJ6, gcDW);
        GC.j6(kCVarM457DW, gcJ6, gcDW);
        jC jCVar = (jC) kCVarM457DW.get(kCVarM457DW.size() - 1);
        if (jCVar.gn() == jC.a.j6) {
            while (jCVar.Hw < s2.j6() && dc.j6(s2, jCVar.FH, s2, jCVar.Hw)) {
                jCVar.j6++;
                jCVar.DW++;
                jCVar.FH++;
                jCVar.Hw++;
            }
        }
        return kCVarM457DW;
    }
}
