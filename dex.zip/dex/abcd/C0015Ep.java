package abcd;

class C0015Ep {

    static final int[] f139j6 = new int[C0058Fp.a.values().length];

    static {
        try {
            f139j6[C0058Fp.a.INSTANCE.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            f139j6[C0058Fp.a.TYPE.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
    }
}
