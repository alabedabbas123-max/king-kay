package abcd;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.util.Pair;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputConnectionWrapper;
import android.view.inputmethod.InputMethodManager;
import android.widget.PopupWindow;
import com.appfour.backbone.api.objects.UserActionWindow;
import com.appfour.backbone.api.objects.UserInputAction;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class C0019Hv {

    private static Field f121DW;

    private static Object f122FH;

    private static Field f123Hw;

    private static Runnable f124VH;

    private static Handler f125Zo;

    private static Activity f126gn;

    private static List<Pair<View, UserActionWindow>> f127j6 = new ArrayList();

    private static a f128u7;

    private static Object f129v5;

    private static class a extends InputConnectionWrapper {
        public a(InputConnection inputConnection, boolean z) {
            super(inputConnection, z);
        }

        private void m219j6() {
            UserActionWindow userActionWindowM206gn = C0019Hv.m206gn();
            if (userActionWindowM206gn != null) {
                Qv.DW(new UserInputAction(userActionWindowM206gn, false));
            }
        }

        @Override
        public boolean commitText(CharSequence charSequence, int i) {
            m219j6();
            return super.commitText(charSequence, i);
        }

        @Override
        public boolean setComposingText(CharSequence charSequence, int i) {
            m219j6();
            return super.setComposingText(charSequence, i);
        }
    }

    private static Window m195DW(View view) {
        try {
            try {
                Field declaredField = Class.forName("com.android.internal.policy.DecorView").getDeclaredField("mWindow");
                declaredField.setAccessible(true);
                return (Window) declaredField.get(view);
            } catch (Exception unused) {
                return null;
            }
        } catch (Exception unused2) {
            Field declaredField2 = view.getClass().getDeclaredField("this$0");
            declaredField2.setAccessible(true);
            return (Window) declaredField2.get(view);
        }
    }

    public static boolean m197DW(Intent intent) {
        return intent != null && "android.intent.action.MAIN".equals(intent.getAction()) && intent.getCategories() != null && intent.getCategories().contains("android.intent.category.LAUNCHER");
    }

    private static List<View> m198EQ() {
        ArrayList arrayList = new ArrayList();
        Object obj = null;
        try {
            if (f121DW != null) {
                obj = f121DW.get(f122FH);
            } else if (f123Hw != null) {
                obj = f123Hw.get(f129v5);
            }
            List<View> arrayList2 = new ArrayList();
            if (obj instanceof List) {
                arrayList2 = (List) obj;
            } else if (obj instanceof View[]) {
                arrayList2 = Arrays.asList((View[]) obj);
            }
            for (View view : arrayList2) {
                if (m202Hw(view)) {
                    arrayList.add(view);
                }
            }
        } catch (IllegalAccessException unused) {
        }
        return arrayList;
    }

    private static boolean m200FH(View view) {
        Window windowM195DW = m195DW(view);
        return windowM195DW != null && m210j6(windowM195DW, null, view).getType() == 0;
    }

    private static boolean m202Hw(View view) {
        if (!view.isShown()) {
            return false;
        }
        Activity activityM208j6 = m208j6(view.getContext());
        return activityM208j6 == null || activityM208j6.getWindow().getDecorView().isShown();
    }

    public static void m203J0() {
        List<View> listM198EQ = m198EQ();
        List<Pair<View, UserActionWindow>> list = f127j6;
        boolean z = false;
        for (int size = list.size() - 1; size >= 0; size--) {
            View view = (View) list.get(size).first;
            Iterator<View> it = listM198EQ.iterator();
            do {
                if (!it.hasNext()) {
                    m212j6((UserActionWindow) list.get(size).second);
                    z = true;
                    break;
                }
            } while (it.next() != view);
        }
        ArrayList arrayList = new ArrayList();
        for (View view2 : listM198EQ) {
            if (m200FH(view2)) {
                Iterator<Pair<View, UserActionWindow>> it2 = f127j6.iterator();
                while (true) {
                    if (it2.hasNext()) {
                        Pair<View, UserActionWindow> next = it2.next();
                        if (next.first == view2) {
                            arrayList.add(Pair.create(view2, next.second));
                            break;
                        }
                    } else {
                        arrayList.add(Pair.create(view2, m217v5(view2)));
                        z = true;
                        break;
                    }
                }
            }
        }
        for (View view3 : listM198EQ) {
            if (!m200FH(view3)) {
                Iterator<Pair<View, UserActionWindow>> it3 = f127j6.iterator();
                while (true) {
                    if (it3.hasNext()) {
                        Pair<View, UserActionWindow> next2 = it3.next();
                        if (next2.first == view3) {
                            arrayList.add(Pair.create(view3, next2.second));
                            break;
                        }
                    } else {
                        arrayList.add(Pair.create(view3, m217v5(view3)));
                        z = true;
                        break;
                    }
                }
            }
        }
        if (z) {
            f127j6 = new ArrayList(arrayList);
        }
    }

    public static UserActionWindow m206gn() {
        if (f126gn == null) {
            return null;
        }
        for (Pair<View, UserActionWindow> pair : f127j6) {
            if (((UserActionWindow) pair.second).getType() != 0 && ((UserActionWindow) pair.second).getActivity() == f126gn) {
                return (UserActionWindow) pair.second;
            }
        }
        for (Pair<View, UserActionWindow> pair2 : f127j6) {
            if (((UserActionWindow) pair2.second).getActivity() == f126gn) {
                return (UserActionWindow) pair2.second;
            }
        }
        return null;
    }

    private static Activity m208j6(Context context) {
        if (context instanceof Activity) {
            return (Activity) context;
        }
        if (context instanceof ContextWrapper) {
            return m208j6(((ContextWrapper) context).getBaseContext());
        }
        return null;
    }

    private static PopupWindow m209j6(View view) {
        try {
            Field declaredField = view.getClass().getDeclaredField("this$0");
            declaredField.setAccessible(true);
            return (PopupWindow) declaredField.get(view);
        } catch (Exception unused) {
            return null;
        }
    }

    private static UserActionWindow m210j6(Window window, PopupWindow popupWindow, View view) {
        Activity activity = (window == null || !(window.getContext() instanceof Activity)) ? null : (Activity) window.getContext();
        Activity activityM208j6 = m208j6(view.getContext());
        int i = 3;
        if (activity != null) {
            i = 0;
        } else if (window == null && popupWindow == null) {
            if ((view.getLayoutParams() instanceof WindowManager.LayoutParams) && "Toast".equals(((WindowManager.LayoutParams) view.getLayoutParams()).getTitle())) {
                i = 4;
            }
        } else if (window != null) {
            i = 1;
        } else if (popupWindow != null) {
            i = 2;
        }
        if (activityM208j6 != null) {
            activity = activityM208j6;
        }
        return new UserActionWindow(activity, i, view);
    }

    private static void m212j6(UserActionWindow userActionWindow) {
        kv.FH(userActionWindow);
    }

    public static void m214tp() {
        f125Zo.removeCallbacks(f124VH);
        f125Zo.post(f124VH);
    }

    public static void m215u7() {
        Application applicationJ6 = wu.j6();
        try {
            if (Build.VERSION.SDK_INT >= 17) {
                Class<?> cls = Class.forName("android.view.WindowManagerGlobal");
                f122FH = cls.getMethod("getInstance", new Class[0]).invoke(null, new Object[0]);
                f121DW = cls.getDeclaredField("mViews");
                f121DW.setAccessible(true);
            } else if (Build.VERSION.SDK_INT >= 14 && Build.VERSION.SDK_INT < 17) {
                Class<?> cls2 = Class.forName("android.view.WindowManagerImpl");
                f129v5 = cls2.getMethod("getDefault", new Class[0]).invoke(null, new Object[0]);
                f123Hw = cls2.getDeclaredField("mViews");
                f123Hw.setAccessible(true);
            }
        } catch (Throwable unused) {
        }
        f125Zo = new Handler();
        f124VH = new Fv();
        f125Zo.post(f124VH);
        applicationJ6.registerActivityLifecycleCallbacks(new Gv());
    }

    private static UserActionWindow m217v5(View view) {
        Window windowM195DW = m195DW(view);
        if (windowM195DW != null) {
            UserActionWindow userActionWindowM210j6 = m210j6(windowM195DW, null, view);
            kv.Hw(userActionWindowM210j6);
            Qv.j6(windowM195DW, userActionWindowM210j6);
            return userActionWindowM210j6;
        }
        PopupWindow popupWindowM209j6 = m209j6(view);
        if (popupWindowM209j6 != null) {
            UserActionWindow userActionWindowM210j7 = m210j6(null, popupWindowM209j6, view);
            kv.Hw(userActionWindowM210j7);
            Qv.j6(popupWindowM209j6, userActionWindowM210j7);
            return userActionWindowM210j7;
        }
        UserActionWindow userActionWindowM210j8 = m210j6(null, null, view);
        kv.Hw(userActionWindowM210j8);
        Qv.j6(view, userActionWindowM210j8);
        return userActionWindowM210j8;
    }

    public static void m218we() {
        try {
            InputMethodManager inputMethodManager = (InputMethodManager) wu.j6().getSystemService("input_method");
            Field declaredField = inputMethodManager.getClass().getDeclaredField("mServedInputConnectionWrapper");
            declaredField.setAccessible(true);
            Object obj = declaredField.get(inputMethodManager);
            if (obj != null) {
                Field declaredField2 = obj.getClass().getSuperclass().getDeclaredField("mInputConnection");
                declaredField2.setAccessible(true);
                if (declaredField2.getType() == WeakReference.class) {
                    WeakReference weakReference = (WeakReference) declaredField2.get(obj);
                    if (weakReference != null && weakReference.get() != null && !(weakReference.get() instanceof a)) {
                        f128u7 = new a((InputConnection) weakReference.get(), true);
                        declaredField2.set(obj, new WeakReference(f128u7));
                    }
                } else {
                    InputConnection inputConnection = (InputConnection) declaredField2.get(obj);
                    if (inputConnection != null && !(inputConnection instanceof a)) {
                        f128u7 = new a(inputConnection, true);
                        declaredField2.set(obj, f128u7);
                    }
                }
            }
        } catch (Exception unused) {
        }
    }
}
