package abcd;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Vector;

public abstract class AbstractC0124HL extends EL {

    private Vector f708j6 = new Vector();

    private boolean f707DW = false;

    protected AbstractC0124HL() {
    }

    protected AbstractC0124HL(qL qLVar) {
        this.f708j6.addElement(qLVar);
    }

    protected AbstractC0124HL(rL rLVar, boolean z) {
        for (int i = 0; i != rLVar.j6(); i++) {
            this.f708j6.addElement(rLVar.j6(i));
        }
        if (z) {
            m1082EQ();
        }
    }

    protected AbstractC0124HL(qL[] qLVarArr, boolean z) {
        for (int i = 0; i != qLVarArr.length; i++) {
            this.f708j6.addElement(qLVarArr[i]);
        }
        if (z) {
            m1082EQ();
        }
    }

    public static AbstractC0124HL m1077j6(LL ll, boolean z) {
        if (z) {
            if (ll.we()) {
                return (AbstractC0124HL) ll.u7();
            }
            throw new IllegalArgumentException("object implicit - explicit expected.");
        }
        if (ll.we()) {
            return ll instanceof YL ? new WL(ll.u7()) : new C0039FM((qL) ll.u7());
        }
        if (ll.u7() instanceof AbstractC0124HL) {
            return (AbstractC0124HL) ll.u7();
        }
        new rL();
        if (ll.u7() instanceof AbstractC0038FL) {
            AbstractC0038FL abstractC0038FL = (AbstractC0038FL) ll.u7();
            return ll instanceof YL ? new WL(abstractC0038FL.m358EQ()) : new C0039FM(abstractC0038FL.m358EQ());
        }
        throw new IllegalArgumentException("unknown object in getInstance: " + ll.getClass().getName());
    }

    public static AbstractC0124HL m1078j6(Object obj) {
        if (obj == null || (obj instanceof AbstractC0124HL)) {
            return (AbstractC0124HL) obj;
        }
        if (obj instanceof IL) {
            return m1078j6((Object) ((IL) obj).DW());
        }
        if (obj instanceof byte[]) {
            try {
                return m1078j6((Object) EL.j6((byte[]) obj));
            } catch (IOException e) {
                throw new IllegalArgumentException("failed to construct set from byte[]: " + e.getMessage());
            }
        }
        if (obj instanceof qL) {
            EL elDW = ((qL) obj).DW();
            if (elDW instanceof AbstractC0124HL) {
                return (AbstractC0124HL) elDW;
            }
        }
        throw new IllegalArgumentException("unknown object in getInstance: " + obj.getClass().getName());
    }

    private qL m1079j6(Enumeration enumeration) {
        qL qLVar = (qL) enumeration.nextElement();
        return qLVar == null ? mM.j6 : qLVar;
    }

    private boolean m1080j6(byte[] bArr, byte[] bArr2) {
        int iMin = Math.min(bArr.length, bArr2.length);
        for (int i = 0; i != iMin; i++) {
            if (bArr[i] != bArr2[i]) {
                return (bArr[i] & 255) < (bArr2[i] & 255);
            }
        }
        return iMin == bArr.length;
    }

    private byte[] m1081j6(qL qLVar) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            new CL(byteArrayOutputStream).j6(qLVar);
            return byteArrayOutputStream.toByteArray();
        } catch (IOException unused) {
            throw new IllegalArgumentException("cannot encode object added to SET");
        }
    }

    /*  JADX ERROR: JadxOverflowException in pass: LoopRegionVisitor
        jadx.core.utils.exceptions.JadxOverflowException: LoopRegionVisitor.assignOnlyInLoop endless recursion
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    protected void m1082EQ() {
        /*
            r9 = this;
            boolean r0 = r9.f707DW
            if (r0 != 0) goto L5d
            r0 = 1
            r9.f707DW = r0
            java.util.Vector r1 = r9.f708j6
            int r1 = r1.size()
            if (r1 <= r0) goto L5d
            java.util.Vector r1 = r9.f708j6
            int r1 = r1.size()
            int r1 = r1 - r0
            r2 = r1
            r1 = 1
        L18:
            if (r1 != 0) goto L1b
            goto L5d
        L1b:
            java.util.Vector r1 = r9.f708j6
            r3 = 0
            java.lang.Object r1 = r1.elementAt(r3)
            abcd.qL r1 = (abcd.qL) r1
            byte[] r1 = r9.m1081j6(r1)
            r4 = 0
            r5 = 0
        L2a:
            if (r3 != r2) goto L2f
            r2 = r4
            r1 = r5
            goto L18
        L2f:
            java.util.Vector r6 = r9.f708j6
            int r7 = r3 + 1
            java.lang.Object r6 = r6.elementAt(r7)
            abcd.qL r6 = (abcd.qL) r6
            byte[] r6 = r9.m1081j6(r6)
            boolean r8 = r9.m1080j6(r1, r6)
            if (r8 == 0) goto L45
            r1 = r6
            goto L5b
        L45:
            java.util.Vector r4 = r9.f708j6
            java.lang.Object r4 = r4.elementAt(r3)
            java.util.Vector r5 = r9.f708j6
            java.lang.Object r6 = r5.elementAt(r7)
            r5.setElementAt(r6, r3)
            java.util.Vector r5 = r9.f708j6
            r5.setElementAt(r4, r7)
            r4 = r3
            r5 = 1
        L5b:
            r3 = r7
            goto L2a
        L5d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: abcd.AbstractC0124HL.m1082EQ():void");
    }

    EL m1083VH() {
        if (this.f707DW) {
            vM vMVar = new vM();
            vMVar.f708j6 = this.f708j6;
            return vMVar;
        }
        Vector vector = new Vector();
        for (int i = 0; i != this.f708j6.size(); i++) {
            vector.addElement(this.f708j6.elementAt(i));
        }
        vM vMVar2 = new vM();
        vMVar2.f708j6 = vector;
        vMVar2.m1082EQ();
        return vMVar2;
    }

    boolean m1084Zo() {
        return true;
    }

    EL m1085gn() {
        C0039FM c0039fm = new C0039FM();
        c0039fm.f708j6 = this.f708j6;
        return c0039fm;
    }

    public int hashCode() {
        Enumeration enumerationM1089u7 = m1089u7();
        int iM1088tp = m1088tp();
        while (enumerationM1089u7.hasMoreElements()) {
            iM1088tp = (iM1088tp * 17) ^ m1079j6(enumerationM1089u7).hashCode();
        }
        return iM1088tp;
    }

    public qL m1086j6(int i) {
        return (qL) this.f708j6.elementAt(i);
    }

    boolean m1087j6(EL el) {
        if (!(el instanceof AbstractC0124HL)) {
            return false;
        }
        AbstractC0124HL abstractC0124HL = (AbstractC0124HL) el;
        if (m1088tp() != abstractC0124HL.m1088tp()) {
            return false;
        }
        Enumeration enumerationM1089u7 = m1089u7();
        Enumeration enumerationM1089u8 = abstractC0124HL.m1089u7();
        while (enumerationM1089u7.hasMoreElements()) {
            qL qLVarM1079j6 = m1079j6(enumerationM1089u7);
            qL qLVarM1079j7 = m1079j6(enumerationM1089u8);
            EL elDW = qLVarM1079j6.DW();
            EL elDW2 = qLVarM1079j7.DW();
            if (elDW != elDW2 && !elDW.equals(elDW2)) {
                return false;
            }
        }
        return true;
    }

    public String toString() {
        return this.f708j6.toString();
    }

    public int m1088tp() {
        return this.f708j6.size();
    }

    public Enumeration m1089u7() {
        return this.f708j6.elements();
    }
}
