package abcd;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class C0021Ev {

    public static Set<Long> f153j6 = new HashSet();

    public static Set<Long> f147DW = new HashSet();

    private static Map<Long, Set<Long>> f148FH = new HashMap();

    private static Map<Long, Set<Long>> f149Hw = new HashMap();

    private static Map<Long, List<Class>> f154v5 = new HashMap();

    private static Map<Long, Class> f151Zo = new HashMap();

    private static Map<Long, Method> f150VH = new HashMap();

    private static Map<Long, Field> f152gn = new HashMap();

    public static Method m258DW(long j, long j2) {
        Method method = f150VH.get(Long.valueOf(j2));
        if (method != null) {
            return method;
        }
        Class cls = f151Zo.get(Long.valueOf(j));
        if (cls == null) {
            return null;
        }
        for (Method method2 : cls.getDeclaredMethods()) {
            su annotation = method2.getAnnotation(su.class);
            if (annotation != null && annotation.method() == j2) {
                f150VH.put(Long.valueOf(j2), method2);
                return method2;
            }
        }
        return null;
    }

    public static void m259DW(long j, long j2, boolean z) {
        yw.j6("Code", "Set onThrow " + z + ": container " + j + " method " + j2);
        if (z) {
            f147DW.add(Long.valueOf(j2));
            if (!f148FH.containsKey(Long.valueOf(j))) {
                f148FH.put(Long.valueOf(j), new HashSet());
            }
            f148FH.get(Long.valueOf(j)).add(Long.valueOf(j2));
            if (f154v5.containsKey(Long.valueOf(j))) {
                Iterator<Class> it = f154v5.get(Long.valueOf(j)).iterator();
                while (it.hasNext()) {
                    m260DW((Class<?>) it.next(), true);
                }
                return;
            }
            return;
        }
        f147DW.remove(Long.valueOf(j2));
        if (f148FH.containsKey(Long.valueOf(j))) {
            f148FH.get(Long.valueOf(j)).remove(Long.valueOf(j2));
            if (f148FH.get(Long.valueOf(j)).size() == 0) {
                Map<Long, Set<Long>> map = f148FH;
                map.remove(map);
            }
        }
        if (f148FH.containsKey(Long.valueOf(j2)) || !f154v5.containsKey(Long.valueOf(j))) {
            return;
        }
        Iterator<Class> it2 = f154v5.get(Long.valueOf(j)).iterator();
        while (it2.hasNext()) {
            m260DW((Class<?>) it2.next(), false);
        }
    }

    private static void m260DW(Class<?> cls, boolean z) {
        try {
            yw.j6("Code", "Toggle onThrow " + z + " " + cls);
            for (Field field : cls.getDeclaredFields()) {
                if (field.getAnnotation(uu.class) != null) {
                    field.setAccessible(true);
                    field.set(null, Boolean.valueOf(z));
                    return;
                }
            }
        } catch (Throwable th) {
            yw.j6("Runtime Error", th);
        }
    }

    public static boolean m261DW(Object obj, long j) {
        Class cls = f151Zo.get(Long.valueOf(j));
        if (cls != null) {
            return cls.isInstance(obj);
        }
        return false;
    }

    public static Class<?> m262j6(long j) {
        Class<?> cls = f151Zo.get(Long.valueOf(j));
        if (cls != null) {
            return cls;
        }
        throw new NoClassDefFoundError();
    }

    public static Object m263j6(Object obj, long j) {
        Class cls = f151Zo.get(Long.valueOf(j));
        if (cls != null) {
            return m264j6(obj, cls);
        }
        return null;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static <T> T m264j6(Object obj, Class<T> cls) {
        if (obj == 0) {
            return null;
        }
        if (cls.isInstance(obj)) {
            return obj;
        }
        try {
            try {
                try {
                    for (Field field : obj.getClass().getDeclaredFields()) {
                        if (field.getAnnotation(vu.class) != null) {
                            field.setAccessible(true);
                            return (T) m264j6(field.get(obj), cls);
                        }
                        Field declaredField = obj.getClass().getDeclaredField("arg$1");
                        declaredField.setAccessible(true);
                        return (T) m264j6(declaredField.get(obj), cls);
                    }
                    return null;
                } catch (Exception unused) {
                    return null;
                }
            } catch (Exception unused2) {
                Field declaredField2 = obj.getClass().getDeclaredField("arg$1");
                declaredField2.setAccessible(true);
                return (T) m264j6(declaredField2.get(obj), cls);
            }
        } catch (Exception unused3) {
            Field declaredField3 = obj.getClass().getDeclaredField("this$0");
            declaredField3.setAccessible(true);
            return (T) m264j6(declaredField3.get(obj), cls);
        }
    }

    public static Field m265j6(long j, long j2) {
        Field field = f152gn.get(Long.valueOf(j2));
        if (field != null) {
            return field;
        }
        Class cls = f151Zo.get(Long.valueOf(j));
        if (cls == null) {
            return null;
        }
        for (Field field2 : cls.getDeclaredFields()) {
            ru annotation = field2.getAnnotation(ru.class);
            if (annotation != null && annotation.field() == j2) {
                f152gn.put(Long.valueOf(j2), field2);
                return field2;
            }
        }
        return null;
    }

    public static void m266j6(long j, long j2, boolean z) {
        yw.j6("Code", "Set onEnter " + z + ": container " + j + " method " + j2);
        if (z) {
            f153j6.add(Long.valueOf(j2));
            if (!f149Hw.containsKey(Long.valueOf(j))) {
                f149Hw.put(Long.valueOf(j), new HashSet());
            }
            f149Hw.get(Long.valueOf(j)).add(Long.valueOf(j2));
            if (f154v5.containsKey(Long.valueOf(j))) {
                Iterator<Class> it = f154v5.get(Long.valueOf(j)).iterator();
                while (it.hasNext()) {
                    m268j6((Class<?>) it.next(), true);
                }
                return;
            }
            return;
        }
        f153j6.remove(Long.valueOf(j2));
        if (f149Hw.containsKey(Long.valueOf(j))) {
            f149Hw.get(Long.valueOf(j)).remove(Long.valueOf(j2));
            if (f149Hw.get(Long.valueOf(j)).size() == 0) {
                Map<Long, Set<Long>> map = f149Hw;
                map.remove(map);
            }
        }
        if (f149Hw.containsKey(Long.valueOf(j2)) || !f154v5.containsKey(Long.valueOf(j))) {
            return;
        }
        Iterator<Class> it2 = f154v5.get(Long.valueOf(j)).iterator();
        while (it2.hasNext()) {
            m268j6((Class<?>) it2.next(), false);
        }
    }

    public static void m267j6(Class<?> cls, long j, long j2) {
        if (!f154v5.containsKey(Long.valueOf(j))) {
            f154v5.put(Long.valueOf(j), new ArrayList());
        }
        f154v5.get(Long.valueOf(j)).add(cls);
        f151Zo.put(Long.valueOf(j2), cls);
        if (f149Hw.containsKey(Long.valueOf(j)) || f148FH.containsKey(Long.valueOf(j))) {
            yw.j6("Code", "Load active class " + cls + ": container " + j + " class " + j2);
        }
        if (f149Hw.containsKey(Long.valueOf(j))) {
            m268j6(cls, true);
        }
        if (f148FH.containsKey(Long.valueOf(j))) {
            m260DW(cls, true);
        }
    }

    private static void m268j6(Class<?> cls, boolean z) {
        try {
            yw.j6("Code", "Toggle onEnter " + z + " " + cls);
            for (Field field : cls.getDeclaredFields()) {
                if (field.getAnnotation(tu.class) != null) {
                    field.setAccessible(true);
                    field.set(null, Boolean.valueOf(z));
                    return;
                }
            }
        } catch (Throwable th) {
            yw.j6("Runtime Error", th);
        }
    }
}
