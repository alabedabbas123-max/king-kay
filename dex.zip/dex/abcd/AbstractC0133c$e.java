package abcd;

import java.util.Iterator;
import java.util.Map;

public abstract class AbstractC0133c$e<K, V> implements Iterator<Map.Entry<K, V>>, f<K, V> {

    c<K, V> f565DW;

    c<K, V> f566j6;

    AbstractC0133c$e(c<K, V> cVar, c<K, V> cVar2) {
        this.f566j6 = cVar2;
        this.f565DW = cVar;
    }

    private c<K, V> m867j6() {
        c<K, V> cVar = this.f565DW;
        c<K, V> cVar2 = this.f566j6;
        if (cVar == cVar2 || cVar2 == null) {
            return null;
        }
        return m868j6(cVar);
    }

    @Override
    public boolean hasNext() {
        return this.f565DW != null;
    }

    abstract c<K, V> m868j6(c<K, V> cVar);

    @Override
    public Map.Entry<K, V> next() {
        c<K, V> cVar = this.f565DW;
        this.f565DW = m867j6();
        return cVar;
    }
}
