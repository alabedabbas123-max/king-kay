package abcd;

import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.Set;

public abstract class AbstractC0075DJ {

    private static int[] f251j6;

    public enum a {
        USER,
        PASS,
        HOST,
        PORT,
        PATH;

        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            int length = aVarArrValuesCustom.length;
            a[] aVarArr = new a[length];
            System.arraycopy(aVarArrValuesCustom, 0, aVarArr, 0, length);
            return aVarArr;
        }
    }

    static int[] m431j6() {
        int[] iArr = f251j6;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[a.valuesCustom().length];
        try {
            iArr2[a.HOST.ordinal()] = 3;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[a.PASS.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[a.PATH.ordinal()] = 5;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[a.PORT.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr2[a.USER.ordinal()] = 1;
        } catch (NoSuchFieldError unused5) {
        }
        f251j6 = iArr2;
        return iArr2;
    }

    public abstract jJ mo432DW(HJ hj, UE ue, String str);

    public abstract String mo433DW();

    public Set<a> mo434FH() {
        return Collections.emptySet();
    }

    public Set<a> mo435Hw() {
        return Collections.unmodifiableSet(EnumSet.of(a.PATH));
    }

    public boolean m436j6(HJ hj) {
        return m437j6(hj, null, null);
    }

    public boolean m437j6(HJ hj, UE ue, String str) {
        if (!mo438v5().isEmpty() && !mo438v5().contains(hj.VH())) {
            return false;
        }
        Iterator<a> it = mo435Hw().iterator();
        while (it.hasNext()) {
            int i = m431j6()[it.next().ordinal()];
            if (i != 1) {
                if (i != 2) {
                    if (i != 3) {
                        if (i != 4) {
                            if (i != 5 || hj.Hw() == null || hj.Hw().length() == 0) {
                                return false;
                            }
                        } else if (hj.v5() <= 0) {
                            return false;
                        }
                    } else if (hj.j6() == null || hj.j6().length() == 0) {
                        return false;
                    }
                } else if (hj.FH() == null || hj.FH().length() == 0) {
                    return false;
                }
            } else if (hj.gn() == null || hj.gn().length() == 0) {
                return false;
            }
        }
        EnumSet enumSetCopyOf = EnumSet.copyOf((Collection) mo435Hw());
        enumSetCopyOf.addAll(mo434FH());
        if (hj.gn() != null && !enumSetCopyOf.contains(a.USER)) {
            return false;
        }
        if (hj.FH() != null && !enumSetCopyOf.contains(a.PASS)) {
            return false;
        }
        if (hj.j6() != null && !enumSetCopyOf.contains(a.HOST)) {
            return false;
        }
        if (hj.v5() <= 0 || enumSetCopyOf.contains(a.PORT)) {
            return hj.Hw() == null || enumSetCopyOf.contains(a.PATH);
        }
        return false;
    }

    public Set<String> mo438v5() {
        return Collections.emptySet();
    }
}
