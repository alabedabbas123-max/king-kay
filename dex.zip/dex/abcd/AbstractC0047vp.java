package abcd;

public abstract class AbstractC0047vp {
    public abstract EnumC0089wp m192Hw();

    public abstract int m193VH();

    public final String m194Zo() {
        return m192Hw().m371aM();
    }

    public abstract void m195j6(jp jpVar);

    public abstract void m196j6(jp jpVar, Lt lt);
}
