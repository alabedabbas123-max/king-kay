package abcd;

public final class C0001Qn extends Xt implements Comparable<C0001Qn> {

    public static final C0001Qn f7FH = new C0001Qn(0);

    public static class a implements Comparable<a> {

        private final int f8DW;

        private final Ks f9j6;

        public a(Ks ks, int i) {
            if (i < 0) {
                throw new IllegalArgumentException("handler < 0");
            }
            if (ks == null) {
                throw new NullPointerException("exceptionType == null");
            }
            this.f8DW = i;
            this.f9j6 = ks;
        }

        public Ks m20Hw() {
            return this.f9j6;
        }

        public int m21Zo() {
            return this.f8DW;
        }

        public boolean equals(Object obj) {
            return (obj instanceof a) && compareTo((a) obj) == 0;
        }

        public int hashCode() {
            return (this.f8DW * 31) + this.f9j6.hashCode();
        }

        @Override
        public int compareTo(a aVar) {
            int i = this.f8DW;
            int i2 = aVar.f8DW;
            if (i < i2) {
                return -1;
            }
            if (i > i2) {
                return 1;
            }
            return this.f9j6.j6(aVar.f9j6);
        }
    }

    public C0001Qn(int i) {
        super(i);
    }

    public String m14aM() {
        return m17j6("", "");
    }

    public a m15get(int i) {
        return (a) DW(i);
    }

    @Override
    public int compareTo(C0001Qn c0001Qn) {
        if (this == c0001Qn) {
            return 0;
        }
        int size = size();
        int size2 = c0001Qn.size();
        int iMin = Math.min(size, size2);
        for (int i = 0; i < iMin; i++) {
            int iCompareTo = m15get(i).compareTo(c0001Qn.m15get(i));
            if (iCompareTo != 0) {
                return iCompareTo;
            }
        }
        if (size < size2) {
            return -1;
        }
        return size > size2 ? 1 : 0;
    }

    public String m17j6(String str, String str2) {
        StringBuilder sb = new StringBuilder(100);
        int size = size();
        sb.append(str);
        sb.append(str2);
        sb.append("catch ");
        for (int i = 0; i < size; i++) {
            a aVarM15get = m15get(i);
            if (i != 0) {
                sb.append(",\n");
                sb.append(str);
                sb.append("  ");
            }
            if (i == size - 1 && m19rN()) {
                sb.append("<any>");
            } else {
                sb.append(aVarM15get.m20Hw().aM());
            }
            sb.append(" -> ");
            sb.append(Yt.Zo(aVarM15get.m21Zo()));
        }
        return sb.toString();
    }

    public void m18j6(int i, Ks ks, int i2) {
        j6(i, new a(ks, i2));
    }

    public boolean m19rN() {
        int size = size();
        if (size == 0) {
            return false;
        }
        return m15get(size - 1).m20Hw().equals(Ks.DW);
    }
}
