package abcd;

@xu
public abstract class Be$i extends Be$f {

    @tu
    private static boolean f474Hw;

    @uu
    private static boolean f475v5;

    static {
        wu.j6(Be$i.class, 742813974162732472L, 742813974162732472L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$i(int i) {
        super(i);
        try {
            if (f474Hw) {
                wu.j6(12403010354478320L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f475v5) {
                wu.j6(th, 12403010354478320L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }
}
