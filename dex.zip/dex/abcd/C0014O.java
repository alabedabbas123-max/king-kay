package abcd;

@xu
public class C0014O {

    @uu
    private static boolean f42DW;

    @tu
    private static boolean f43j6;

    @ru(field = 3041696473504231152L)
    private final ea f44FH;

    @xu
    public class a {

        @uu
        private static boolean f45DW;

        @tu
        private static boolean f46j6;

        public int f47FH;

        public int f48Hw;

        public boolean f49VH;

        public int f50Zo;

        @vu
        final C0014O f51gn;

        public int f52v5;

        static {
            wu.j6(a.class, 44795688740898347L, 44795688740898347L);
        }

        public a(C0014O c0014o) {
            try {
                if (f46j6) {
                    wu.j6(456372603629748821L, (Object) null, c0014o);
                }
                this.f51gn = c0014o;
            } catch (Throwable th) {
                if (f45DW) {
                    wu.j6(th, 456372603629748821L, (Object) null, c0014o);
                }
                throw th;
            }
        }
    }

    static {
        wu.j6(C0014O.class, -6589829432882957220L, -6589829432882957220L);
    }

    public C0014O(ea eaVar) {
        try {
            if (f43j6) {
                wu.j6(-2778352862561940797L, (Object) null, eaVar);
            }
            this.f44FH = eaVar;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, -2778352862561940797L, (Object) null, eaVar);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0033  */
    public Aa m65DW(Sa sa, int i, int i2) {
        try {
            if (f43j6) {
                wu.j6(-655221471878032440L, this, sa, new Integer(i), new Integer(i2));
            }
            int iU7 = sa.u7(i, i2);
            if (iU7 == -1) {
                return null;
            }
            switch (sa.Zo(iU7)) {
                case 6:
                case 7:
                case 8:
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                case 14:
                case 15:
                case 16:
                case 17:
                case 19:
                case 20:
                case 21:
                case 22:
                case 23:
                case 24:
                case 25:
                    return sa.v5(iU7);
                case 18:
                default:
                    return null;
            }
            if (f42DW) {
                wu.j6(th, -655221471878032440L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, -655221471878032440L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m66DW(Sa sa, int i, int i2, int i3, int i4) {
        int iV5;
        int iDW;
        try {
            if (f43j6) {
                wu.j6(256959059405771324L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            if (i2 == i4 && i == i3 && (iV5 = sa.v5(i, i2, i3, i4)) != -1 && ((iDW = sa.DW(i, i2, i3, i4)) == -1 || !sa.QX(iV5, iDW))) {
                try {
                    ua uaVarJ6 = ((La) this.f44FH).a8.j6(sa.VH(), sa.J8(), sa.J8(sa.er(iV5)));
                    Hb hbXG = uaVarJ6.XG();
                    hbXG.Hw.DW();
                    while (hbXG.Hw.j6()) {
                        Ia iaHw = hbXG.Hw.Hw();
                        if (Ma.j6(iaHw.XL()) && iaHw.FH() != uaVarJ6) {
                            return true;
                        }
                    }
                    Hb hbYO = uaVarJ6.yO();
                    hbYO.Hw.DW();
                    while (hbYO.Hw.j6()) {
                        Ia iaHw2 = hbYO.Hw.Hw();
                        if (Ma.j6(iaHw2.XL()) && iaHw2.FH() != uaVarJ6 && (iaHw2.ko() || iaHw2.et())) {
                            return true;
                        }
                    }
                } catch (jc unused) {
                }
            }
            return false;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 256959059405771324L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public Za m67FH(Sa sa, int i, int i2) {
        try {
            if (f43j6) {
                wu.j6(886308861842103615L, this, sa, new Integer(i), new Integer(i2));
            }
            int iU7 = sa.u7(i, i2);
            if (iU7 != -1) {
                int iXL = sa.XL(iU7);
                int iZo = sa.Zo(iU7);
                if (iZo == 1 || iZo == 2 || iZo == 3 || iZo == 32) {
                    int iVH = sa.VH(iU7);
                    return new Za(sa.VH(), sa.J8(), sa.vy(iVH), sa.BT(iVH), sa.Ws(iVH), iXL, sa.ro(iU7) ? sa.u7(iU7) : null);
                }
            }
            return null;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 886308861842103615L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m68FH(Sa sa, int i, int i2, int i3, int i4) {
        int iTp;
        try {
            if (f43j6) {
                wu.j6(-1210920110515087560L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            return i2 == i4 && i == i3 && (iTp = sa.tp(i, i2, i3, i4)) != -1 && sa.ef(iTp);
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, -1210920110515087560L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public boolean m69Hw(Sa sa, int i, int i2) {
        try {
            if (f43j6) {
                wu.j6(6558479258776871901L, this, sa, new Integer(i), new Integer(i2));
            }
            int iU7 = sa.u7(i, i2);
            if (iU7 == -1) {
                return false;
            }
            int iZo = sa.Zo(iU7);
            return iZo == 1 || iZo == 32;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 6558479258776871901L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m70Hw(Sa sa, int i, int i2, int i3, int i4) {
        int iU7;
        try {
            if (f43j6) {
                wu.j6(-636924219514509472L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            return ((i2 == i4 && i == i3) || (iU7 = sa.u7(i, i2, i3, i4)) == -1 || sa.I(sa.er(iU7))) ? false : true;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, -636924219514509472L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public a m71VH(Sa sa, int i, int i2, int i3, int i4) {
        try {
            if (f43j6) {
                wu.j6(4615733396958965344L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            if (i2 == i4 && i == i3) {
                return new a(this);
            }
            int iTp = sa.tp(i, i2, i3, i4);
            int iDW = sa.DW(i, i2, i3, i4);
            if (iTp != -1 && iTp != iDW) {
                a aVar = new a(this);
                aVar.f49VH = true;
                aVar.f47FH = sa.vy(iTp);
                aVar.f48Hw = sa.BT(iTp);
                aVar.f52v5 = sa.QX(iTp);
                aVar.f50Zo = sa.Ws(iTp);
                return aVar;
            }
            Cb cbHw = sa.Hw(i, i2, i3, i4);
            if (cbHw == null) {
                return new a(this);
            }
            a aVar2 = new a(this);
            aVar2.f49VH = true;
            aVar2.f47FH = sa.vy(cbHw.DW(0));
            aVar2.f48Hw = sa.BT(cbHw.DW(0));
            aVar2.f52v5 = sa.QX(cbHw.DW(cbHw.Hw() - 1));
            aVar2.f50Zo = sa.Ws(cbHw.DW(cbHw.Hw() - 1));
            return aVar2;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 4615733396958965344L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public boolean m72VH(Sa sa, int i, int i2) {
        try {
            if (f43j6) {
                wu.j6(835348183723670945L, this, sa, new Integer(i), new Integer(i2));
            }
            int iU7 = sa.u7(i, i2);
            if (iU7 != -1) {
                sa.XL(iU7);
                int iZo = sa.Zo(iU7);
                if ((iZo == 1 || iZo == 2 || iZo == 3) && sa.Zo(sa.VH(iU7)) == 1) {
                    return true;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 835348183723670945L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m73Zo(Sa sa, int i, int i2) {
        try {
            if (f43j6) {
                wu.j6(3816035894271042673L, this, sa, new Integer(i), new Integer(i2));
            }
            int iU7 = sa.u7(i, i2);
            if (iU7 == -1) {
                return false;
            }
            sa.XL(iU7);
            int iZo = sa.Zo(iU7);
            return iZo == 1 || iZo == 2 || iZo == 3 || iZo == 32;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 3816035894271042673L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m74Zo(Sa sa, int i, int i2, int i3, int i4) {
        try {
            if (f43j6) {
                wu.j6(792772045225108812L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            return sa.v5(i, i2, i3, i4) == -1;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 792772045225108812L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public Aa m75j6(Sa sa, int i, int i2) {
        try {
            if (f43j6) {
                wu.j6(6052428397372612261L, this, sa, new Integer(i), new Integer(i2));
            }
            if (sa.u7(i, i2) != -1) {
                return m65DW(sa, i, i2);
            }
            int iWs = sa.Ws(i, i2);
            if (iWs == -1 || !sa.ro(sa.er(iWs))) {
                return null;
            }
            Ya yaU7 = sa.u7(sa.er(iWs));
            if (yaU7.rN()) {
                return yaU7;
            }
            return null;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 6052428397372612261L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m76j6(Sa sa, int i, int i2, int i3, int i4) {
        try {
            if (f43j6) {
                wu.j6(2090534373982380093L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            Cb cbZo = sa.Zo(i, i2, i3, i4);
            if (cbZo != null) {
                for (int iHw = cbZo.Hw() - 1; iHw >= 0; iHw--) {
                    for (int i5 = 0; i5 < sa.we(cbZo.DW(iHw)); i5++) {
                        int iZo = sa.Zo(cbZo.DW(iHw), i5);
                        if (sa.ca(iZo)) {
                            try {
                                Ia iaDW = ((La) this.f44FH).a8.DW(sa.VH(), sa.J8(), sa.J8(iZo));
                                if (!iaDW.ko() && !iaDW.et()) {
                                    return true;
                                }
                            } catch (jc unused) {
                                continue;
                            }
                        }
                    }
                }
            }
            return false;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, 2090534373982380093L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public boolean m77v5(Sa sa, int i, int i2) {
        try {
            if (f43j6) {
                wu.j6(-1911418741689918112L, this, sa, new Integer(i), new Integer(i2));
            }
            int iU7 = sa.u7(i, i2);
            if (iU7 == -1) {
                return false;
            }
            int iZo = sa.Zo(iU7);
            if (iZo != 7 && iZo != 11 && iZo != 13 && iZo != 15 && iZo != 19 && iZo != 21) {
                if (iZo != 16) {
                    return false;
                }
                if (!((La) this.f44FH).Mr.we(sa.v5(iU7).Zo())) {
                    return false;
                }
            }
            return true;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, -1911418741689918112L, this, sa, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m78v5(Sa sa, int i, int i2, int i3, int i4) {
        try {
            if (f43j6) {
                wu.j6(-76874327176180335L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            int iTp = sa.tp(i, i2);
            int iU7 = sa.u7(i3, i4);
            return (iTp == -1 || iU7 == 1 || iTp != iU7) ? false : true;
        } catch (Throwable th) {
            if (f42DW) {
                wu.j6(th, -76874327176180335L, this, sa, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }
}
