package abcd;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import org.eclipse.jgit.JGitText;

class C0024OJ extends bI {

    private final fG f106EQ;

    private final UE f107Hw;

    private final C0106QF f108J0;

    private LinkedList<yE> f109J8;

    private final HashMap<yE, List<Throwable>> f110Mr;

    private final LinkedList<RJ> f111QX;

    private String f112U2;

    private int f113VH;

    private final LinkedList<RJ> f114Ws;

    private final LinkedList<a> f115XL;

    private final List<RJ> f116Zo;

    private final List<kH> f117a8;

    private final Set<String> f118aM;

    private final qG f119gn;

    private final uE f120j3 = new uE();

    private final EE f121lg;

    private final IE f122rN;

    private final fG f123tp;

    private final YJ f124u7;

    private final wE f125v5;

    private final fG f126we;

    private class a {

        final String f127DW;

        final String f128FH;

        File f129Hw;

        final RJ f131j6;

        bH f132v5;

        a(RJ rj, String str) {
            this.f131j6 = rj;
            this.f127DW = str;
            String str2 = this.f127DW;
            this.f128FH = String.valueOf(str2.substring(0, str2.length() - 5)) + ".idx";
            String strSubstring = this.f128FH;
            strSubstring = strSubstring.startsWith("pack-") ? strSubstring.substring(5) : strSubstring;
            strSubstring = strSubstring.endsWith(".idx") ? strSubstring.substring(0, strSubstring.length() - 4) : strSubstring;
            if (C0024OJ.this.f107Hw.EQ() instanceof XG) {
                this.f129Hw = new File(C0024OJ.this.f107Hw.EQ().gn(), "walk-" + strSubstring + ".walkidx");
            }
        }

        void m169DW(LE le) throws IOException {
            int i;
            if (this.f132v5 != null) {
                return;
            }
            File file = this.f129Hw;
            if (file == null) {
                this.f129Hw = File.createTempFile("jgit-walk-", ".idx");
            } else if (file.isFile()) {
                try {
                    this.f132v5 = bH.j6(this.f129Hw);
                    return;
                } catch (FileNotFoundException unused) {
                }
            }
            RJ.a aVarHw = this.f131j6.Hw("pack/" + this.f128FH);
            String str = "Get " + this.f128FH.substring(0, 12) + "..idx";
            long j = aVarHw.DW;
            le.j6(str, j < 0 ? 0 : (int) (j / 1024));
            try {
                try {
                    FileOutputStream fileOutputStream = new FileOutputStream(this.f129Hw);
                    try {
                        byte[] bArr = new byte[2048];
                        while (!le.isCancelled() && (i = aVarHw.j6.read(bArr)) >= 0) {
                            fileOutputStream.write(bArr, 0, i);
                            le.update(i / 1024);
                        }
                        fileOutputStream.close();
                        aVarHw.j6.close();
                        le.j6();
                        if (le.isCancelled()) {
                            zK.j6(this.f129Hw);
                            return;
                        }
                        try {
                            this.f132v5 = bH.j6(this.f129Hw);
                        } catch (IOException e) {
                            zK.j6(this.f129Hw);
                            throw e;
                        }
                    } catch (Throwable th) {
                        fileOutputStream.close();
                        throw th;
                    }
                } catch (IOException e2) {
                    zK.j6(this.f129Hw);
                    throw e2;
                }
            } catch (Throwable th2) {
                aVarHw.j6.close();
                throw th2;
            }
        }

        void m170j6(LE le) {
            AI aiJ6 = C0024OJ.this.f121lg.j6(this.f131j6.Hw("pack/" + this.f127DW).j6);
            aiJ6.j6(false);
            aiJ6.j6(C0024OJ.this.f125v5);
            aiJ6.j6(C0024OJ.this.f112U2);
            kH kHVarJ6 = aiJ6.j6(le);
            if (kHVarJ6 != null) {
                C0024OJ.this.f117a8.add(kHVarJ6);
            }
            C0024OJ.this.f121lg.FH();
        }
    }

    C0024OJ(SJ sj, RJ rj) {
        jJ jJVar = (jJ) sj;
        this.f107Hw = jJVar.v5;
        this.f125v5 = jJVar.EQ() ? new wE() : null;
        this.f121lg = this.f107Hw.aM();
        this.f122rN = this.f107Hw.j3();
        this.f116Zo = new ArrayList();
        this.f116Zo.add(rj);
        this.f115XL = new LinkedList<>();
        this.f118aM = new HashSet();
        this.f114Ws = new LinkedList<>();
        this.f114Ws.add(rj);
        this.f111QX = new LinkedList<>();
        this.f111QX.add(rj);
        this.f110Mr = new HashMap<>();
        this.f117a8 = new ArrayList(4);
        this.f119gn = new qG(this.f122rN);
        this.f119gn.j6(false);
        this.f124u7 = new YJ(this.f122rN);
        this.f123tp = this.f119gn.j6("COMPLETE");
        this.f106EQ = this.f119gn.j6("IN_WORK_QUEUE");
        this.f126we = this.f119gn.j6("LOCALLY_SEEN");
        this.f108J0 = new C0106QF();
        this.f109J8 = new LinkedList<>();
    }

    private void m141DW(iG iGVar) {
        if (iGVar.DW(this.f123tp) || iGVar.DW(this.f106EQ)) {
            return;
        }
        iGVar.j6(this.f106EQ);
        this.f109J8.add(iGVar);
    }

    private boolean m142DW(LE le, YD yd) throws YC, yD {
        Iterator<a> it = this.f115XL.iterator();
        while (it.hasNext() && !le.isCancelled()) {
            a next = it.next();
            try {
                next.m169DW(le);
                if (le.isCancelled()) {
                    return false;
                }
                if (next.f132v5.FH(yd)) {
                    try {
                        try {
                            next.m170j6(le);
                            try {
                                if (next.f129Hw != null) {
                                    zK.j6(next.f129Hw);
                                }
                                it.remove();
                                if (m160j6(yd)) {
                                    Iterator<yE> itM162u7 = m162u7();
                                    while (itM162u7.hasNext()) {
                                        yE next2 = itM162u7.next();
                                        if (next.f132v5.FH(next2)) {
                                            itM162u7.remove();
                                            m157j6(next2);
                                        } else {
                                            this.f109J8.add(next2);
                                        }
                                    }
                                    return true;
                                }
                                m152j6(yd, new FileNotFoundException(MessageFormat.format(JGitText.j6().objectNotFoundIn, yd.we(), next.f127DW)));
                            } catch (IOException e) {
                                throw new yD(e.getMessage(), e);
                            }
                        } catch (IOException e2) {
                            m152j6(yd, e2);
                            try {
                                if (next.f129Hw != null) {
                                    zK.j6(next.f129Hw);
                                }
                                it.remove();
                            } catch (IOException e3) {
                                throw new yD(e3.getMessage(), e3);
                            }
                        }
                    } catch (Throwable th) {
                        try {
                            if (next.f129Hw != null) {
                                zK.j6(next.f129Hw);
                            }
                            it.remove();
                            throw th;
                        } catch (IOException e4) {
                            throw new yD(e4.getMessage(), e4);
                        }
                    }
                } else {
                    continue;
                }
            } catch (IOException e5) {
                m152j6(yd, e5);
                it.remove();
            }
        }
        return false;
    }

    private void m144FH(iG iGVar) throws yD {
        try {
            if (!this.f122rN.FH(iGVar, 3)) {
                throw new yD(MessageFormat.format(JGitText.j6().cannotReadBlob, iGVar.we()), new fD(iGVar, "blob"));
            }
            iGVar.j6(this.f123tp);
        } catch (IOException e) {
            throw new yD(MessageFormat.format(JGitText.j6().cannotReadBlob, iGVar.we()), e);
        }
    }

    private void m146Hw(iG iGVar) throws YC, yD {
        dG dGVar = (dG) iGVar;
        m150j6(dGVar.U2());
        m141DW((iG) dGVar.yS());
        for (iG iGVar2 : dGVar.rN()) {
            m141DW(iGVar2);
        }
        iGVar.j6(this.f123tp);
    }

    private void m147Zo(iG iGVar) throws YC, yD {
        try {
            this.f124u7.DW(iGVar);
            while (this.f124u7.EQ()) {
                rE rEVarJ6 = this.f124u7.j6(0);
                int iFH = rEVarJ6.FH();
                if (iFH == 2 || iFH == 3) {
                    this.f124u7.j6(this.f120j3, 0);
                    m141DW(this.f119gn.j6(this.f120j3, iFH));
                } else if (!rE.v5.equals(rEVarJ6)) {
                    this.f124u7.j6(this.f120j3, 0);
                    String str = JGitText.j6().invalidModeFor;
                    iGVar.getId();
                    throw new YC(MessageFormat.format(str, rEVarJ6, this.f120j3.we(), this.f124u7.Hw(), iGVar.we()));
                }
            }
            iGVar.j6(this.f123tp);
        } catch (IOException e) {
            throw new yD(MessageFormat.format(JGitText.j6().cannotReadTree, iGVar.we()), e);
        }
    }

    private Collection<RJ> m149j6(YD yd, LE le) {
        while (!this.f111QX.isEmpty()) {
            RJ rjRemoveFirst = this.f111QX.removeFirst();
            try {
                try {
                    le.j6(JGitText.j6().listingAlternates, 0);
                    Collection<RJ> collectionDW = rjRemoveFirst.DW();
                    if (collectionDW != null && !collectionDW.isEmpty()) {
                        le.j6();
                        return collectionDW;
                    }
                    le.j6();
                } catch (IOException e) {
                    m152j6(yd, e);
                }
            } catch (Throwable th) {
                le.j6();
                throw th;
            }
        }
        return null;
    }

    private void m150j6(int i) throws YC, yD {
        while (true) {
            try {
                dG dGVarM646Hw = this.f108J0.m646Hw();
                if (dGVarM646Hw != null && dGVarM646Hw.U2() >= i) {
                    this.f108J0.m647j6();
                    m156j6(dGVarM646Hw.yS());
                    for (dG dGVar : dGVarM646Hw.rN()) {
                        m154j6(dGVar);
                    }
                }
                return;
            } catch (IOException e) {
                throw new yD(JGitText.j6().localObjectsIncomplete, e);
            }
        }
    }

    private void m151j6(LE le, YD yd) throws yD {
        if (m160j6(yd)) {
            return;
        }
        while (!m142DW(le, yd)) {
            String strWe = yd.we();
            String strSubstring = strWe.substring(0, 2);
            String str = String.valueOf(strSubstring) + "/" + strWe.substring(2);
            for (int i = this.f113VH; i < this.f116Zo.size(); i++) {
                if (m161j6(yd, str, this.f116Zo.get(i))) {
                    this.f113VH = i;
                    return;
                }
            }
            for (int i2 = 0; i2 < this.f113VH; i2++) {
                if (m161j6(yd, str, this.f116Zo.get(i2))) {
                    this.f113VH = i2;
                    return;
                }
            }
            while (!this.f114Ws.isEmpty()) {
                RJ rjRemoveFirst = this.f114Ws.removeFirst();
                try {
                    try {
                        le.j6("Listing packs", 0);
                        Collection<String> collectionFH = rjRemoveFirst.FH();
                        le.j6();
                        if (collectionFH != null && !collectionFH.isEmpty()) {
                            for (String str2 : collectionFH) {
                                if (this.f118aM.add(str2)) {
                                    this.f115XL.add(new a(rjRemoveFirst, str2));
                                }
                            }
                            if (m142DW(le, yd)) {
                                return;
                            }
                        }
                    } catch (IOException e) {
                        m152j6(yd, e);
                        le.j6();
                    }
                } catch (Throwable th) {
                    le.j6();
                    throw th;
                }
            }
            Collection<RJ> collectionM149j6 = m149j6(yd, le);
            if (collectionM149j6 == null || collectionM149j6.isEmpty()) {
                List<Throwable> list = this.f110Mr.get(yd);
                yD yDVar = new yD(MessageFormat.format(JGitText.j6().cannotGet, yd.we()));
                if (list != null && !list.isEmpty()) {
                    if (list.size() == 1) {
                        yDVar.initCause(list.get(0));
                    } else {
                        yDVar.initCause(new WC(list));
                    }
                }
                throw yDVar;
            }
            for (RJ rj : collectionM149j6) {
                this.f116Zo.add(rj);
                this.f114Ws.add(rj);
                this.f111QX.add(rj);
            }
        }
    }

    private void m152j6(YD yd, Throwable th) {
        yE yEVarHw = yd.Hw();
        List<Throwable> arrayList = this.f110Mr.get(yEVarHw);
        if (arrayList == null) {
            arrayList = new ArrayList<>(2);
            this.f110Mr.put(yEVarHw, arrayList);
        }
        arrayList.add(th);
    }

    private void m153j6(YD yd, byte[] bArr) throws FileNotFoundException, yD {
        try {
            FE feJ6 = sH.j6(bArr, yd);
            int iFH = feJ6.FH();
            byte[] bArrJ6 = feJ6.j6();
            wE wEVar = this.f125v5;
            if (wEVar != null) {
                try {
                    wEVar.j6(iFH, bArrJ6);
                } catch (YC e) {
                    throw new yD(MessageFormat.format(JGitText.j6().transportExceptionInvalid, hE.DW(iFH), yd.we(), e.getMessage()));
                }
            }
            yE yEVarDW = this.f121lg.DW(iFH, bArrJ6);
            if (!YD.j6(yd, yEVarDW)) {
                throw new yD(MessageFormat.format(JGitText.j6().incorrectHashFor, yd.we(), yEVarDW.we(), hE.DW(iFH), Integer.valueOf(bArr.length)));
            }
            this.f121lg.FH();
        } catch (YC e2) {
            FileNotFoundException fileNotFoundException = new FileNotFoundException(yd.we());
            fileNotFoundException.initCause(e2);
            throw fileNotFoundException;
        }
    }

    private void m154j6(dG dGVar) {
        if (dGVar.DW(this.f126we)) {
            return;
        }
        this.f119gn.DW(dGVar);
        dGVar.j6(this.f126we);
        dGVar.j6(this.f123tp);
        dGVar.FH(this.f123tp);
        this.f108J0.m648j6(dGVar);
    }

    private void m155j6(iG iGVar) throws YC {
        while (iGVar.aM() == 4) {
            iGVar.j6(this.f123tp);
            iGVar = ((lG) iGVar).j3();
            this.f119gn.DW(iGVar);
        }
        int iAM = iGVar.aM();
        if (iAM == 1) {
            m154j6((dG) iGVar);
        } else if (iAM == 2) {
            m156j6((mG) iGVar);
        } else {
            if (iAM != 3) {
                return;
            }
            iGVar.j6(this.f123tp);
        }
    }

    private void m156j6(mG mGVar) throws YC {
        if (mGVar.DW(this.f123tp)) {
            return;
        }
        mGVar.j6(this.f123tp);
        this.f124u7.DW(mGVar);
        while (this.f124u7.EQ()) {
            rE rEVarJ6 = this.f124u7.j6(0);
            int iFH = rEVarJ6.FH();
            if (iFH == 2) {
                this.f124u7.j6(this.f120j3, 0);
                iG iGVarJ6 = this.f119gn.j6(this.f120j3, iFH);
                if (!iGVarJ6.DW(this.f123tp)) {
                    iGVarJ6.j6(this.f123tp);
                    this.f124u7.j6();
                }
            } else if (iFH == 3) {
                this.f124u7.j6(this.f120j3, 0);
                this.f119gn.j6(this.f120j3, iFH).j6(this.f123tp);
            } else if (!rE.v5.equals(rEVarJ6)) {
                this.f124u7.j6(this.f120j3, 0);
                throw new YC(MessageFormat.format(JGitText.j6().corruptObjectInvalidMode3, rEVarJ6, this.f120j3.we(), this.f124u7.Hw(), mGVar.we()));
            }
        }
    }

    private void m157j6(yE yEVar) throws YC, yD {
        iG iGVarZo;
        try {
            if (yEVar instanceof iG) {
                iGVarZo = (iG) yEVar;
                if (iGVarZo.DW(this.f123tp)) {
                    return;
                } else {
                    this.f119gn.DW(iGVarZo);
                }
            } else {
                iGVarZo = this.f119gn.Zo(yEVar);
                if (iGVarZo.DW(this.f123tp)) {
                    return;
                }
            }
            int iAM = iGVarZo.aM();
            if (iAM == 1) {
                m146Hw(iGVarZo);
            } else if (iAM == 2) {
                m147Zo(iGVarZo);
            } else if (iAM == 3) {
                m144FH(iGVarZo);
            } else {
                if (iAM != 4) {
                    throw new yD(MessageFormat.format(JGitText.j6().unknownObjectType, yEVar.we()));
                }
                m164v5(iGVarZo);
            }
            this.f110Mr.remove(yEVar);
        } catch (IOException e) {
            throw new yD(MessageFormat.format(JGitText.j6().cannotRead, yEVar.we()), e);
        }
    }

    private void m158j6(Collection<ME> collection) throws yD {
        HashSet hashSet = new HashSet();
        Iterator<ME> it = collection.iterator();
        while (it.hasNext()) {
            yE yEVarDW = it.next().DW();
            try {
                yE yEVarZo = this.f119gn.Zo(yEVarDW);
                if (!yEVarZo.DW(this.f123tp) && hashSet.add(yEVarDW)) {
                    yEVarZo.j6(this.f106EQ);
                    this.f109J8.add(yEVarZo);
                }
            } catch (fD unused) {
                if (hashSet.add(yEVarDW)) {
                    this.f109J8.add(yEVarDW);
                }
            } catch (IOException e) {
                throw new yD(MessageFormat.format(JGitText.j6().cannotRead, yEVarDW.we()), e);
            }
        }
    }

    private void m159j6(Set<yE> set) throws YC, yD {
        for (ME me : this.f107Hw.v5().values()) {
            try {
                m155j6(this.f119gn.Zo(me.DW()));
            } catch (IOException e) {
                throw new yD(MessageFormat.format(JGitText.j6().localRefIsMissingObjects, me.getName()), e);
            }
        }
        for (yE yEVar : set) {
            try {
                m155j6(this.f119gn.Zo(yEVar));
            } catch (IOException e2) {
                throw new yD(MessageFormat.format(JGitText.j6().transportExceptionMissingAssumed, yEVar.we()), e2);
            }
        }
    }

    private boolean m160j6(YD yd) throws yD {
        try {
            return this.f122rN.DW(yd);
        } catch (IOException e) {
            throw new yD(MessageFormat.format(JGitText.j6().cannotReadObject, yd.we()), e);
        }
    }

    private boolean m161j6(YD yd, String str, RJ rj) throws yD {
        try {
            m153j6(yd, rj.Hw(str).j6());
            return true;
        } catch (FileNotFoundException e) {
            m152j6(yd, e);
            return false;
        } catch (IOException e2) {
            throw new yD(MessageFormat.format(JGitText.j6().cannotDownload, yd.we()), e2);
        }
    }

    private Iterator<yE> m162u7() {
        Iterator<yE> it = this.f109J8.iterator();
        this.f109J8 = new LinkedList<>();
        return it;
    }

    private void m164v5(iG iGVar) {
        m141DW(((lG) iGVar).j3());
        iGVar.j6(this.f123tp);
    }

    protected void m165DW(LE le, Collection<ME> collection, Set<yE> set) throws YC, yD {
        m159j6(set);
        m158j6(collection);
        while (!le.isCancelled() && !this.f109J8.isEmpty()) {
            iG iGVar = (yE) this.f109J8.removeFirst();
            if (!(iGVar instanceof iG) || !iGVar.DW(this.f123tp)) {
                m151j6(le, (YD) iGVar);
            }
            m157j6((yE) iGVar);
        }
    }

    public Collection<kH> m166Hw() {
        return this.f117a8;
    }

    public void close() {
        this.f121lg.Hw();
        this.f122rN.FH();
        Iterator<a> it = this.f115XL.iterator();
        while (it.hasNext()) {
            File file = it.next().f129Hw;
            if (file != null) {
                file.delete();
            }
        }
        Iterator<RJ> it2 = this.f116Zo.iterator();
        while (it2.hasNext()) {
            it2.next().j6();
        }
    }

    public void m167j6(String str) {
        this.f112U2 = str;
    }

    public boolean m168v5() {
        return true;
    }
}
