package abcd;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

public abstract class AbstractC0057zI {

    HJ f252DW;

    StringBuilder f254Hw;

    Map<String, ME> f255j6 = Collections.emptyMap();

    final SortedMap<String, gJ> f253FH = new TreeMap();

    public final ME m348DW(String str) {
        return this.f255j6.get(str);
    }

    public String m349DW() {
        StringBuilder sb = this.f254Hw;
        return sb != null ? sb.toString() : "";
    }

    public Collection<ME> m350j6() {
        return Collections.unmodifiableCollection(this.f255j6.values());
    }

    void m351j6(HJ hj, Map<String, ME> map) {
        this.f252DW = hj;
        this.f255j6 = map;
    }

    void m352j6(gJ gJVar) {
        this.f253FH.put(gJVar.j6(), gJVar);
    }

    void m353j6(String str) {
        if (str == null || str.length() <= 0) {
            return;
        }
        if (this.f254Hw == null) {
            this.f254Hw = new StringBuilder();
        }
        this.f254Hw.append(str);
        if (str.endsWith("\n")) {
            return;
        }
        this.f254Hw.append('\n');
    }
}
