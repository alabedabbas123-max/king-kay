package abcd;

import java.util.ArrayList;

public abstract class AbstractC0059It {

    protected final Ft f414DW;

    protected final yt f415j6;

    public AbstractC0059It(yt ytVar, Ft ft) {
        this.f415j6 = ytVar;
        this.f414DW = ft;
    }

    protected final bs m637j6(int i) {
        vt vtVarFH = this.f415j6.FH(i);
        if (vtVarFH == null) {
            return null;
        }
        return vtVarFH.u7();
    }

    protected final bs m638j6(vt vtVar, bs bsVar) {
        tt ttVarDW = vtVar.DW();
        ArrayList arrayListFH = ttVarDW.FH();
        int iIndexOf = arrayListFH.indexOf(vtVar);
        if (iIndexOf < 0) {
            throw new IllegalArgumentException("specified insn is not in this block");
        }
        if (iIndexOf != arrayListFH.size() - 1) {
            throw new IllegalArgumentException("Adding move here not supported:" + vtVar.aM());
        }
        bs bsVarJ6 = bs.j6(this.f415j6.J0(), bsVar.J8());
        arrayListFH.add(iIndexOf, vt.j6(new Zr(gs.u7(bsVarJ6.getType()), hs.j6, bsVarJ6, cs.j6(bsVar)), ttVarDW));
        int iWe = bsVarJ6.we();
        _t it = ttVarDW.Hw().iterator();
        while (it.hasNext()) {
            this.f414DW.j6(iWe, it.next());
        }
        cs csVarTp = vtVar.tp();
        int size = csVarTp.size();
        for (int i = 0; i < size; i++) {
            this.f414DW.j6(iWe, csVarTp.get(i).we());
        }
        this.f415j6.J8();
        return bsVarJ6;
    }
}
