package abcd;

public abstract class AbstractC0102qo extends Vn {
    public AbstractC0102qo(hs hsVar, cs csVar) {
        super(Yn.DW, hsVar, csVar);
    }

    public final Vn m534DW(int i) {
        return j6(gn().v5(i));
    }

    public final Vn m535j6(Xn xn) {
        throw new RuntimeException("unsupported");
    }
}
