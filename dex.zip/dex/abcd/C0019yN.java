package abcd;

public class C0019yN extends AbstractC0017yL {

    DN f41DW;

    wN f42FH;

    cM f43Hw;

    FL f44j6;

    private C0019yN(FL fl) {
        this.f44j6 = fl;
        if (fl.tp() != 3) {
            throw new IllegalArgumentException("sequence wrong size for a certificate");
        }
        this.f41DW = DN.j6(fl.j6(0));
        this.f42FH = wN.j6(fl.j6(1));
        this.f43Hw = cM.j6(fl.j6(2));
    }

    public static C0019yN m78j6(Object obj) {
        if (obj instanceof C0019yN) {
            return (C0019yN) obj;
        }
        if (obj != null) {
            return new C0019yN(FL.j6(obj));
        }
        return null;
    }

    @Override
    public EL mo72DW() {
        return this.f44j6;
    }

    public DN m79VH() {
        return this.f41DW;
    }

    public wL m80Zo() {
        return this.f41DW.VH();
    }

    public sN m81v5() {
        return this.f41DW.Zo();
    }
}
