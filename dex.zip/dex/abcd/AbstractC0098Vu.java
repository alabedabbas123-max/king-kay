package abcd;

import com.appfour.backbone.api.closures.OnEnterClosure0;
import com.appfour.backbone.api.closures.OnEnterClosure1;
import com.appfour.backbone.api.closures.OnEnterClosure2;
import com.appfour.backbone.api.closures.OnEnterClosure3;
import com.appfour.backbone.api.closures.OnEnterClosure4;
import com.appfour.backbone.api.closures.OnEnterClosure5;
import com.appfour.backbone.api.define.DefineHook;

public abstract class AbstractC0098Vu extends hv {

    private long f264VH;

    private long f265gn = -1;

    public long m608gn() {
        return this.f264VH;
    }

    public <C> DefineHook onEnter(long j, long j2, OnEnterClosure0<C> onEnterClosure0) {
        this.f264VH = j;
        this.f265gn = j2;
        ((yu) this).j6 = onEnterClosure0 == null ? null : new Ku(this, j, onEnterClosure0);
        return j6();
    }

    public <C, T0> DefineHook onEnter(long j, long j2, OnEnterClosure1<C, T0> onEnterClosure1) {
        this.f264VH = j;
        this.f265gn = j2;
        ((yu) this).j6 = onEnterClosure1 == null ? null : new Mu(this, j, onEnterClosure1);
        return j6();
    }

    public <C, T0, T1> DefineHook onEnter(long j, long j2, OnEnterClosure2<C, T0, T1> onEnterClosure2) {
        this.f264VH = j;
        this.f265gn = j2;
        ((yu) this).j6 = onEnterClosure2 == null ? null : new Ou(this, j, onEnterClosure2);
        return j6();
    }

    public <C, T0, T1, T2> DefineHook onEnter(long j, long j2, OnEnterClosure3<C, T0, T1, T2> onEnterClosure3) {
        this.f264VH = j;
        this.f265gn = j2;
        ((yu) this).j6 = onEnterClosure3 == null ? null : new Qu(this, j, onEnterClosure3);
        return j6();
    }

    public <C, T0, T1, T2, T3> DefineHook onEnter(long j, long j2, OnEnterClosure4<C, T0, T1, T2, T3> onEnterClosure4) {
        this.f264VH = j;
        this.f265gn = j2;
        ((yu) this).j6 = onEnterClosure4 == null ? null : new Su(this, j, onEnterClosure4);
        return j6();
    }

    public <C, T0, T1, T2, T3, T4> DefineHook onEnter(long j, long j2, OnEnterClosure5<C, T0, T1, T2, T3, T4> onEnterClosure5) {
        this.f264VH = j;
        this.f265gn = j2;
        ((yu) this).j6 = onEnterClosure5 == null ? null : new C0055Uu(this, j, onEnterClosure5);
        return j6();
    }

    public <C> DefineHook onEnter(Class<C> cls, String str, OnEnterClosure0<C> onEnterClosure0) {
        return j6();
    }

    public <C, T0> DefineHook onEnter(Class<C> cls, String str, Class<T0> cls2, OnEnterClosure1<C, T0> onEnterClosure1) {
        return j6();
    }

    public <C, T0, T1> DefineHook onEnter(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, OnEnterClosure2<C, T0, T1> onEnterClosure2) {
        return j6();
    }

    public <C, T0, T1, T2> DefineHook onEnter(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, Class<T2> cls4, OnEnterClosure3<C, T0, T1, T2> onEnterClosure3) {
        return j6();
    }

    public <C, T0, T1, T2, T3> DefineHook onEnter(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, Class<T2> cls4, Class<T3> cls5, OnEnterClosure4<C, T0, T1, T2, T3> onEnterClosure4) {
        return j6();
    }

    public <C, T0, T1, T2, T3, T4> DefineHook onEnter(Class<C> cls, String str, Class<T0> cls2, Class<T1> cls3, Class<T2> cls4, Class<T3> cls5, Class<T4> cls6, OnEnterClosure5<C, T0, T1, T2, T3, T4> onEnterClosure5) {
        return j6();
    }

    public boolean m609tp() {
        return this.f265gn != -1;
    }

    public long m610u7() {
        return this.f265gn;
    }
}
