package abcd;

public abstract class AbstractC0020yO implements tO {

    static final long[] f45j6 = {4794697086780616226L, 8158064640168781261L, -5349999486874862801L, -1606136188198331460L, 4131703408338449720L, 6480981068601479193L, -7908458776815382629L, -6116909921290321640L, -2880145864133508542L, 1334009975649890238L, 2608012711638119052L, 6128411473006802146L, 8268148722764581231L, -9160688886553864527L, -7215885187991268811L, -4495734319001033068L, -1973867731355612462L, -1171420211273849373L, 1135362057144423861L, 2597628984639134821L, 3308224258029322869L, 5365058923640841347L, 6679025012923562964L, 8573033837759648693L, -7476448914759557205L, -6327057829258317296L, -5763719355590565569L, -4658551843659510044L, -4116276920077217854L, -3051310485924567259L, 489312712824947311L, 1452737877330783856L, 2861767655752347644L, 3322285676063803686L, 5560940570517711597L, 5996557281743188959L, 7280758554555802590L, 8532644243296465576L, -9096487096722542874L, -7894198246740708037L, -6719396339535248540L, -6333637450476146687L, -4446306890439682159L, -4076793802049405392L, -3345356375505022440L, -2983346525034927856L, -860691631967231958L, 1182934255886127544L, 1847814050463011016L, 2177327727835720531L, 2830643537854262169L, 3796741975233480872L, 4115178125766777443L, 5681478168544905931L, 6601373596472566643L, 7507060721942968483L, 8399075790359081724L, 8693463985226723168L, -8878714635349349518L, -8302665154208450068L, -8016688836872298968L, -6606660893046293015L, -4685533653050689259L, -4147400797238176981L, -3880063495543823972L, -3348786107499101689L, -1523767162380948706L, -757361751448694408L, 500013540394364858L, 748580250866718886L, 1242879168328830382L, 1977374033974150939L, 2944078676154940804L, 3659926193048069267L, 4368137639120453308L, 4836135668995329356L, 5532061633213252278L, 6448918945643986474L, 6902733635092675308L, 7801388544844847127L};

    protected long f47EQ;

    private long f49Hw;

    protected long f50J0;

    protected long f52VH;

    private int f53Ws;

    protected long f54Zo;

    protected long f55gn;

    protected long f56tp;

    protected long f57u7;

    private long f58v5;

    protected long f59we;

    private long[] f51J8 = new long[80];

    private byte[] f46DW = new byte[8];

    private int f48FH = 0;

    protected AbstractC0020yO() {
        reset();
    }

    private long m82DW(long j) {
        return (j >>> 6) ^ (((j << 45) | (j >>> 19)) ^ ((j << 3) | (j >>> 61)));
    }

    private long m83DW(long j, long j2, long j3) {
        return ((j & j3) ^ (j & j2)) ^ (j2 & j3);
    }

    private long m84FH(long j) {
        return ((j >>> 39) | (j << 25)) ^ (((j << 36) | (j >>> 28)) ^ ((j << 30) | (j >>> 34)));
    }

    private long m85Hw(long j) {
        return ((j >>> 41) | (j << 23)) ^ (((j << 50) | (j >>> 14)) ^ ((j << 46) | (j >>> 18)));
    }

    private long m86j6(long j) {
        return (j >>> 7) ^ (((j << 63) | (j >>> 1)) ^ ((j << 56) | (j >>> 8)));
    }

    private long m87j6(long j, long j2, long j3) {
        return ((j ^ (-1)) & j3) ^ (j2 & j);
    }

    private void m88v5() {
        long j = this.f49Hw;
        if (j > 2305843009213693951L) {
            this.f58v5 += j >>> 61;
            this.f49Hw = j & 2305843009213693951L;
        }
    }

    protected void m89DW(byte[] bArr, int i) {
        this.f51J8[this.f53Ws] = ZO.DW(bArr, i);
        int i2 = this.f53Ws + 1;
        this.f53Ws = i2;
        if (i2 == 16) {
            m91Hw();
        }
    }

    public void m90FH() {
        m88v5();
        long j = this.f49Hw << 3;
        long j2 = this.f58v5;
        m92j6((byte) -128);
        while (this.f48FH != 0) {
            m92j6((byte) 0);
        }
        m93j6(j, j2);
        m91Hw();
    }

    protected void m91Hw() {
        m88v5();
        for (int i = 16; i <= 79; i++) {
            long[] jArr = this.f51J8;
            long jM82DW = m82DW(jArr[i - 2]);
            long[] jArr2 = this.f51J8;
            jArr[i] = jM82DW + jArr2[i - 7] + m86j6(jArr2[i - 15]) + this.f51J8[i - 16];
        }
        long j = this.f54Zo;
        long j2 = this.f52VH;
        long j3 = this.f55gn;
        long j4 = this.f57u7;
        long j5 = this.f56tp;
        long j6 = this.f47EQ;
        int i2 = 0;
        long j7 = j2;
        long j8 = j3;
        long j9 = j4;
        long jM84FH = j;
        long j10 = this.f59we;
        long j11 = j6;
        int i3 = 0;
        int i4 = 0;
        long j12 = j5;
        long j13 = this.f50J0;
        while (i3 < 10) {
            long j14 = jM84FH;
            int i5 = i4 + 1;
            long jM85Hw = j13 + m85Hw(j12) + m87j6(j12, j11, j10) + f45j6[i4] + this.f51J8[i4];
            long j15 = j9 + jM85Hw;
            long jM84FH2 = jM85Hw + m84FH(j14) + m83DW(j14, j7, j8);
            int i6 = i5 + 1;
            long jM85Hw2 = j10 + m85Hw(j15) + m87j6(j15, j12, j11) + f45j6[i5] + this.f51J8[i5];
            long j16 = j8 + jM85Hw2;
            long jM84FH3 = jM85Hw2 + m84FH(jM84FH2) + m83DW(jM84FH2, j14, j7);
            int i7 = i6 + 1;
            long jM85Hw3 = j11 + m85Hw(j16) + m87j6(j16, j15, j12) + f45j6[i6] + this.f51J8[i6];
            long j17 = j7 + jM85Hw3;
            long jM84FH4 = jM85Hw3 + m84FH(jM84FH3) + m83DW(jM84FH3, jM84FH2, j14);
            int i8 = i7 + 1;
            long jM85Hw4 = j12 + m85Hw(j17) + m87j6(j17, j16, j15) + f45j6[i7] + this.f51J8[i7];
            long j18 = j14 + jM85Hw4;
            long jM84FH5 = jM85Hw4 + m84FH(jM84FH4) + m83DW(jM84FH4, jM84FH3, jM84FH2);
            int i9 = i8 + 1;
            long jM85Hw5 = j15 + m85Hw(j18) + m87j6(j18, j17, j16) + f45j6[i8] + this.f51J8[i8];
            long j19 = jM84FH2 + jM85Hw5;
            long jM84FH6 = jM85Hw5 + m84FH(jM84FH5) + m83DW(jM84FH5, jM84FH4, jM84FH3);
            int i10 = i9 + 1;
            long jM85Hw6 = j16 + m85Hw(j19) + m87j6(j19, j18, j17) + f45j6[i9] + this.f51J8[i9];
            long j20 = jM84FH3 + jM85Hw6;
            long jM84FH7 = jM85Hw6 + m84FH(jM84FH6) + m83DW(jM84FH6, jM84FH5, jM84FH4);
            int i11 = i10 + 1;
            long jM85Hw7 = j17 + m85Hw(j20) + m87j6(j20, j19, j18) + f45j6[i10] + this.f51J8[i10];
            long j21 = jM84FH4 + jM85Hw7;
            long jM84FH8 = jM85Hw7 + m84FH(jM84FH7) + m83DW(jM84FH7, jM84FH6, jM84FH5);
            long jM85Hw8 = j18 + m85Hw(j21) + m87j6(j21, j20, j19) + f45j6[i11] + this.f51J8[i11];
            long j22 = jM84FH5 + jM85Hw8;
            jM84FH = jM85Hw8 + m84FH(jM84FH8) + m83DW(jM84FH8, jM84FH7, jM84FH6);
            j11 = j21;
            j9 = jM84FH6;
            j10 = j20;
            i3++;
            i4 = i11 + 1;
            j7 = jM84FH8;
            i2 = 0;
            j13 = j19;
            j12 = j22;
            j8 = jM84FH7;
        }
        this.f54Zo += jM84FH;
        this.f52VH += j7;
        this.f55gn += j8;
        this.f57u7 += j9;
        this.f56tp += j12;
        this.f47EQ += j11;
        this.f59we += j10;
        this.f50J0 += j13;
        this.f53Ws = i2;
        while (i2 < 16) {
            this.f51J8[i2] = 0;
            i2++;
        }
    }

    public void m92j6(byte b) {
        byte[] bArr = this.f46DW;
        int i = this.f48FH;
        this.f48FH = i + 1;
        bArr[i] = b;
        if (this.f48FH == bArr.length) {
            m89DW(bArr, 0);
            this.f48FH = 0;
        }
        this.f49Hw++;
    }

    protected void m93j6(long j, long j2) {
        if (this.f53Ws > 14) {
            m91Hw();
        }
        long[] jArr = this.f51J8;
        jArr[14] = j2;
        jArr[15] = j;
    }

    public void reset() {
        this.f49Hw = 0L;
        this.f58v5 = 0L;
        int i = 0;
        this.f48FH = 0;
        int i2 = 0;
        while (true) {
            byte[] bArr = this.f46DW;
            if (i2 >= bArr.length) {
                break;
            }
            bArr[i2] = 0;
            i2++;
        }
        this.f53Ws = 0;
        while (true) {
            long[] jArr = this.f51J8;
            if (i == jArr.length) {
                return;
            }
            jArr[i] = 0;
            i++;
        }
    }

    public void update(byte[] bArr, int i, int i2) {
        while (this.f48FH != 0 && i2 > 0) {
            m92j6(bArr[i]);
            i++;
            i2--;
        }
        while (i2 > this.f46DW.length) {
            m89DW(bArr, i);
            byte[] bArr2 = this.f46DW;
            i += bArr2.length;
            i2 -= bArr2.length;
            this.f49Hw += (long) bArr2.length;
        }
        while (i2 > 0) {
            m92j6(bArr[i]);
            i++;
            i2--;
        }
    }
}
