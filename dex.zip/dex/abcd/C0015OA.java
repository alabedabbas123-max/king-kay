package abcd;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Collection;
import java.util.LinkedList;
import org.eclipse.jgit.JGitText;

public class C0015OA extends dB<KC> {

    private Collection<String> f53FH;

    private _J f54Hw;

    private boolean f55v5;

    public C0015OA(UE ue) {
        super(ue);
        this.f55v5 = false;
        this.f53FH = new LinkedList();
    }

    public C0015OA m79DW(boolean z) {
        this.f55v5 = z;
        return this;
    }

    public KC m732call() throws Throwable {
        String strXL;
        if (this.f53FH.isEmpty()) {
            throw new UB(JGitText.j6().atLeastOnePatternIsRequired);
        }
        j6();
        boolean zContains = this.f53FH.contains(".");
        EE eeAM = ((dB) this).j6.aM();
        String str = null;
        try {
            try {
                strXL = ((dB) this).j6.XL();
                try {
                    MC mcJ6 = strXL.j6();
                    YJ yj = new YJ(((dB) this).j6);
                    yj.j6(new LC(mcJ6));
                    if (this.f54Hw == null) {
                        this.f54Hw = new WJ(((dB) this).j6);
                    }
                    yj.j6(this.f54Hw);
                    yj.j6(true);
                    if (!zContains) {
                        yj.j6(hK.DW(this.f53FH));
                    }
                    while (yj.EQ()) {
                        String strHw = yj.Hw();
                        _J _jJ6 = yj.j6(1, _J.class);
                        if (yj.j6(0, RC.class) != null || _jJ6 == null || !_jJ6.U2()) {
                            if (!strHw.equals(str) && (!this.f55v5 || yj.j6(0, RC.class) != null)) {
                                RC rcJ6 = yj.j6(0, RC.class);
                                if (_jJ6 != null) {
                                    long jJ3 = _jJ6.j3();
                                    C0103QC c0103qc = new C0103QC(strHw);
                                    if (rcJ6 == null || rcJ6.J8() == null || !rcJ6.J8().m635tp()) {
                                        rE rEVarJ6 = _jJ6.j6(rcJ6);
                                        c0103qc.m631j6(rEVarJ6);
                                        if (rE.v5 != rEVarJ6) {
                                            c0103qc.m616DW(jJ3);
                                            c0103qc.m628j6(_jJ6.aM());
                                            InputStream inputStreamA8 = _jJ6.a8();
                                            try {
                                                c0103qc.m630j6((YD) eeAM.j6(3, jJ3, inputStreamA8));
                                                inputStreamA8.close();
                                                mcJ6.DW(c0103qc);
                                            } catch (Throwable th) {
                                                inputStreamA8.close();
                                                throw th;
                                            }
                                        } else {
                                            yE yEVarFH = cB.j6(new File(((dB) this).j6.J8(), strHw)).u7().FH("HEAD");
                                            if (yEVarFH != null) {
                                                c0103qc.m630j6((YD) yEVarFH);
                                                mcJ6.DW(c0103qc);
                                            }
                                        }
                                        str = strHw;
                                    } else {
                                        mcJ6.DW(rcJ6.J8());
                                    }
                                } else if (!this.f55v5) {
                                    mcJ6.DW(rcJ6.J8());
                                }
                            }
                        }
                    }
                    eeAM.FH();
                    mcJ6.j6();
                    j6(false);
                    eeAM.Hw();
                    if (strXL != null) {
                        strXL.tp();
                    }
                    return strXL;
                } catch (IOException e) {
                    e = e;
                    str = strXL;
                    throw new SB(JGitText.j6().exceptionCaughtDuringExecutionOfAddCommand, e);
                } catch (Throwable th2) {
                    th = th2;
                    eeAM.Hw();
                    if (strXL != null) {
                        strXL.tp();
                    }
                    throw th;
                }
            } catch (IOException e2) {
                e = e2;
            }
        } catch (Throwable th3) {
            th = th3;
            strXL = str;
        }
    }

    public C0015OA m80j6(String str) {
        j6();
        this.f53FH.add(str);
        return this;
    }
}
