package abcd;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.zip.CRC32;

@xu
public class C0000Ea {

    @uu
    private static boolean f0DW;

    @tu
    private static boolean f1j6;

    @ru(field = -4943638874230992377L)
    private HashMap<Integer, String> f2BT;

    @ru(field = 1650005543860494336L)
    private Sb f3EQ;

    @ru(field = -2786897221064576529L)
    private final C0086Ga f4FH;

    @ru(field = 4407177610102871136L)
    private final gb f5Hw;

    @ru(field = -4381750252997415360L)
    private Da f6J0;

    @ru(field = -4705897233642097296L)
    private bc f7J8;

    @ru(field = -5467967912362444776L)
    private qb f8Mr;

    @ru(field = 2302458950772870355L)
    private HashMap<la, List<String>> f9P8;

    @ru(field = -657125772233532736L)
    private String f10QX;

    @ru(field = 388452028054480191L)
    private boolean f11SI;

    @ru(field = 1644682493371920885L)
    private Ub f12U2;

    @ru(field = 2661914019022826516L)
    protected char[] f13VH;

    @ru(field = 3908718991345070232L)
    private bc f14Ws;

    @ru(field = 1252851349549904929L)
    private Da[] f15XL;

    @ru(field = -2740970220685668015L)
    private final fb f16Zo;

    @ru(field = -2943932834219983437L)
    private Sb f17a8;

    @ru(field = -1652528118994556056L)
    private int f18aM;

    @ru(field = 4199726619169786156L)
    private la[] f19ei;

    @ru(field = -527807361482246616L)
    private _b f20er;

    @ru(field = 4436515643396718581L)
    private _b f21gW;

    @ru(field = -4742077876610723520L)
    protected byte[] f22gn;

    @ru(field = 128353224802326528L)
    private qb f23j3;

    @ru(field = -233968794030637209L)
    private _b f24lg;

    @ru(field = 3448878692980049920L)
    private na[] f25nw;

    @ru(field = -477850554506913671L)
    private _b f26rN;

    @ru(field = -7959663836619738472L)
    private Mb f27tp;

    @ru(field = -2439638902703879664L)
    protected CRC32 f28u7;

    @ru(field = -3421896079798091648L)
    private final ib f29v5;

    @ru(field = 3060153012577878240L)
    private HashMap<Integer, a> f30vy;

    @ru(field = -2773666340960946645L)
    private sb f31we;

    @ru(field = -3381981669245318581L)
    private _b f32yS;

    @xu
    private static class a {

        @tu
        private static boolean f33j6;

        @ru(field = 5256780258613326625L)
        private String f34DW;

        @ru(field = -4160718537373871439L)
        private String f35EQ;

        @ru(field = 3942558186120240867L)
        private String f36FH;

        @ru(field = 6163541240307405979L)
        private String f37Hw;

        @ru(field = -6061593152186196915L)
        private boolean f38J0;

        @ru(field = 3227410902224726528L)
        private boolean f39J8;

        @ru(field = 5538096623203389535L)
        private boolean f40QX;

        @ru(field = 2326872282987689769L)
        private List<String> f41VH;

        @ru(field = -1474226157720097104L)
        private boolean f42Ws;

        @ru(field = -2215613492622391104L)
        private String f43Zo;

        @ru(field = -35650939074038288L)
        private List<String> f44gn;

        @ru(field = 2168124630788963840L)
        private String f45tp;

        @ru(field = -3247565427296666731L)
        private List<String> f46u7;

        @ru(field = 2171423886625605888L)
        private String f47v5;

        @ru(field = -3799266395005893240L)
        private String f48we;

        static {
            wu.j6(a.class, -551859439963698048L, -551859439963698048L);
        }

        @su(method = 2971580939040164440L)
        public a(String str, String str2, String str3, String str4, String str5, List<String> list, List<String> list2, List<String> list3, String str6, String str7, String str8, boolean z, boolean z2, boolean z3, boolean z4) {
            boolean z5;
            boolean z6;
            if (f33j6) {
                z5 = z3;
                z6 = z4;
                wu.j6(8460522851617299267L, (Object) null, new Object[]{str, str2, str3, str4, str5, list, list2, list3, str6, str7, str8, new Boolean(z), new Boolean(z2), new Boolean(z5), new Boolean(z6)});
            } else {
                z5 = z3;
                z6 = z4;
            }
            this.f34DW = str;
            this.f36FH = str2;
            this.f37Hw = str3;
            this.f47v5 = str4;
            this.f43Zo = str5;
            this.f41VH = list;
            this.f44gn = list2;
            this.f46u7 = list3;
            this.f45tp = str6;
            this.f35EQ = str7;
            this.f48we = str8;
            this.f38J0 = z;
            this.f39J8 = z2;
            this.f42Ws = z5;
            this.f40QX = z6;
        }
    }

    @xu
    private static class b extends Reader {

        @uu
        private static boolean f49DW;

        @tu
        private static boolean f50j6;

        @ru(field = -3166249769761437141L)
        private Reader f51FH;

        @ru(field = -2812436872752464467L)
        private boolean f52Hw;

        static {
            wu.j6(b.class, -6024540791197450033L, -6024540791197450033L);
        }

        @su(method = -7487069144710998705L)
        public b(Reader reader) {
            try {
                if (f50j6) {
                    wu.j6(398744014966710336L, (Object) null, reader);
                }
                this.f51FH = reader;
                this.f52Hw = false;
            } catch (Throwable th) {
                if (f49DW) {
                    wu.j6(th, 398744014966710336L, (Object) null, reader);
                }
                throw th;
            }
        }

        @Override
        @su(method = 2954941124230807991L)
        public void close() {
            try {
                if (f50j6) {
                    wu.j6(-514237724767439911L, this);
                }
                if (this.f51FH != null) {
                    this.f51FH.close();
                    this.f51FH = null;
                }
            } catch (Throwable th) {
                if (f49DW) {
                    wu.j6(th, -514237724767439911L, this);
                }
                throw th;
            }
        }

        @Override
        @su(method = 181601287631218171L)
        public int read(char[] cArr, int i, int i2) {
            int i3;
            try {
                if (f50j6) {
                    wu.j6(6762178425075865233L, this, cArr, new Integer(i), new Integer(i2));
                }
                int i4 = this.f51FH.read(cArr, i, i2);
                if (i4 == -1) {
                    return -1;
                }
                int i5 = i4 + i;
                int i6 = i;
                boolean z = this.f52Hw;
                int i7 = i6;
                while (i7 < i5) {
                    int i8 = i7 + 1;
                    char c = cArr[i7];
                    if (c != '\n') {
                        if (c != '\r') {
                            cArr[i6] = c;
                            i6++;
                        } else {
                            cArr[i6] = '\n';
                            z = true;
                            i6++;
                        }
                        i7 = i8;
                    } else {
                        if (z) {
                            i3 = i6;
                        } else {
                            i3 = i6 + 1;
                            cArr[i6] = '\n';
                        }
                        i6 = i3;
                    }
                    z = false;
                    i7 = i8;
                }
                this.f52Hw = z;
                return i6 - i;
            } catch (Throwable th) {
                if (f49DW) {
                    wu.j6(th, 6762178425075865233L, this, cArr, new Integer(i), new Integer(i2));
                }
                throw th;
            }
        }
    }

    static {
        wu.j6(C0000Ea.class, 3901160538888060032L, 3901160538888060032L);
    }

    public C0000Ea(C0086Ga c0086Ga, gb gbVar, ib ibVar, fb fbVar) {
        try {
            if (f1j6) {
                wu.j6(-7707530899833450400L, (Object) null, c0086Ga, gbVar, ibVar, fbVar);
            }
            this.f13VH = new char[10000];
            this.f22gn = new byte[10000];
            this.f28u7 = new CRC32();
            this.f7J8 = new bc();
            this.f14Ws = new bc();
            this.f4FH = c0086Ga;
            this.f5Hw = gbVar;
            this.f29v5 = ibVar;
            this.f16Zo = fbVar;
            this.f15XL = new Da[1000];
            this.f15XL[0] = new Da(c0086Ga, this, gbVar, c0086Ga.m787j6(""), (Da) null);
            this.f18aM = 1;
            this.f31we = new sb();
            this.f27tp = new Mb();
            this.f3EQ = new Sb();
            this.f23j3 = new qb();
            this.f8Mr = new qb();
            this.f12U2 = new Ub();
            this.f17a8 = new Sb();
            this.f24lg = new _b(this);
            this.f26rN = new _b(this);
            this.f20er = new _b(this);
            this.f32yS = new _b(this);
            this.f21gW = new _b(this);
            this.f30vy = new HashMap<>();
            this.f2BT = new HashMap<>();
            this.f9P8 = new HashMap<>();
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -7707530899833450400L, (Object) null, c0086Ga, gbVar, ibVar, fbVar);
            }
            throw th;
        }
    }

    @su(method = 2105774149731053232L)
    private void m0EQ() {
        try {
            if (f1j6) {
                wu.j6(2983038655812845067L, this);
            }
            for (Da da : this.f15XL) {
                if (da != null) {
                    da.nw();
                }
            }
            this.f11SI = false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2983038655812845067L, this);
            }
            throw th;
        }
    }

    @su(method = 818846486444602452L)
    private void m1j6(Da da, int i, int i2, _b _bVar) {
        try {
            if (f1j6) {
                wu.j6(1309093143161258871L, this, da, new Integer(i), new Integer(i2), _bVar);
            }
            if (!da.yS()) {
                this.f8Mr.j6(da.EQ(), i);
                this.f23j3.j6(da.EQ(), i2);
                _bVar.DW(da);
            } else {
                int iHw = da.Hw();
                for (int i3 = 0; i3 < iHw; i3++) {
                    m1j6(da.j6(i3), i, i2, _bVar);
                }
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1309093143161258871L, this, da, new Integer(i), new Integer(i2), _bVar);
            }
            throw th;
        }
    }

    @su(method = -399007560061223365L)
    private void m2tp() {
        try {
            if (f1j6) {
                wu.j6(1954958112844318200L, this);
            }
            if (this.f11SI) {
                return;
            }
            this.f11SI = true;
            this.f24lg.v5.DW();
            while (this.f24lg.v5.j6()) {
                Da daFH = this.f24lg.v5.FH();
                m1j6(daFH, this.f8Mr.DW(daFH.EQ()), this.f23j3.DW(daFH.EQ()), this.f32yS);
            }
            this.f26rN.v5.DW();
            while (this.f26rN.v5.j6()) {
                Da daFH2 = this.f26rN.v5.FH();
                m1j6(daFH2, this.f8Mr.DW(daFH2.EQ()), this.f23j3.DW(daFH2.EQ()), this.f21gW);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1954958112844318200L, this);
            }
            throw th;
        }
    }

    @su(method = 2384273099110102473L)
    protected int m3DW(Da da) {
        try {
            if (f1j6) {
                wu.j6(1565175461372627560L, this, da);
            }
            m2tp();
            return this.f8Mr.DW(da.EQ());
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1565175461372627560L, this, da);
            }
            throw th;
        }
    }

    public Da m4DW(String str) {
        int i;
        try {
            if (f1j6) {
                wu.j6(-368531800269440093L, this, str);
            }
            while (true) {
                i = 0;
                if (!str.endsWith(File.separator)) {
                    break;
                }
                str = str.substring(0, str.length() - 1);
            }
            Da daM29gn = m29gn();
            int iIndexOf = str.indexOf(File.separatorChar, 0);
            boolean z = false;
            while (iIndexOf != -1) {
                String strSubstring = str.substring(i, iIndexOf);
                if (strSubstring.equals(".")) {
                    z = true;
                } else {
                    if (strSubstring.equals("..") && m29gn() != daM29gn) {
                        daM29gn = daM29gn.QX();
                    } else if (!strSubstring.equals("")) {
                        daM29gn = daM29gn.j6(strSubstring);
                    } else if (!z) {
                        daM29gn = daM29gn.j6(strSubstring);
                    }
                    z = true;
                }
                i = iIndexOf + 1;
                iIndexOf = str.indexOf(File.separatorChar, i);
            }
            return daM29gn.j6(str.substring(i, str.length()));
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -368531800269440093L, this, str);
            }
            throw th;
        }
    }

    public String m5DW(int i) {
        try {
            if (f1j6) {
                wu.j6(-2337479767059153L, this, i);
            }
            return !this.f30vy.containsKey(Integer.valueOf(i)) ? "" : this.f30vy.get(Integer.valueOf(i)).f36FH;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2337479767059153L, this, new Integer(i));
            }
            throw th;
        }
    }

    public void m6DW() {
        try {
            if (f1j6) {
                wu.j6(1280848333380671665L, this);
            }
            for (la laVar : this.f19ei) {
                if (laVar != null && laVar.gn()) {
                    laVar.VH();
                }
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1280848333380671665L, this);
            }
            throw th;
        }
    }

    public void m7DW(ec ecVar) {
        try {
            if (f1j6) {
                wu.j6(-1693171284508753425L, this, ecVar);
            }
            this.f18aM = ecVar.readInt();
            this.f15XL = new Da[this.f18aM * 2];
            for (int i = 0; i < this.f18aM; i++) {
                this.f15XL[i] = new Da(this.f4FH, this, this.f5Hw);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1693171284508753425L, this, ecVar);
            }
            throw th;
        }
    }

    public void m8DW(fc fcVar) {
        try {
            if (f1j6) {
                wu.j6(-2057419412178823515L, this, fcVar);
            }
            fcVar.writeInt(this.f18aM);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2057419412178823515L, this, fcVar);
            }
            throw th;
        }
    }

    @su(method = -5395542762082156284L)
    protected boolean m9DW(int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(-6347405277638916865L, this, new Integer(i), new Integer(i2));
            }
            m2tp();
            return this.f12U2.j6(i2, i);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -6347405277638916865L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public boolean m10EQ(Da da) {
        try {
            if (f1j6) {
                wu.j6(1208140254175289584L, this, da);
            }
            if (m59we(da) && this.f30vy.containsKey(Integer.valueOf(m3DW(da)))) {
                return this.f30vy.get(Integer.valueOf(m3DW(da))).f40QX;
            }
            return false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1208140254175289584L, this, da);
            }
            throw th;
        }
    }

    @su(method = 2768023223748827952L)
    protected long m11FH(Da da) {
        try {
            if (f1j6) {
                wu.j6(413756217569408265L, this, da);
            }
            if (da.gn() == null) {
                return da.a8();
            }
            if (this.f31we.j6(da.EQ())) {
                return this.f31we.DW(da.EQ());
            }
            if (!this.f3EQ.j6(da.EQ())) {
                this.f3EQ.FH(da.EQ(), da.EQ());
                this.f27tp.DW(da.EQ(), da.a8());
                for (na naVar : da.gn().v5()) {
                    this.f6J0 = da;
                    da.gn().j6(da, naVar);
                    this.f6J0 = null;
                }
            }
            long jA8 = 0;
            this.f3EQ.Hw.j6(da.EQ());
            while (this.f3EQ.Hw.j6()) {
                jA8 = (jA8 * 37) ^ m14Hw(this.f3EQ.Hw.Hw()).a8();
            }
            this.f31we.j6(da.EQ(), jA8);
            return jA8;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 413756217569408265L, this, da);
            }
            throw th;
        }
    }

    public String m12FH(int i) {
        try {
            if (f1j6) {
                wu.j6(4739395908812760300L, this, i);
            }
            return this.f30vy.get(Integer.valueOf(i)).f47v5;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 4739395908812760300L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 3851111195396871387L)
    protected void m13FH() {
        try {
            if (f1j6) {
                wu.j6(5559664764016909168L, this);
            }
            this.f8Mr.j6();
            this.f12U2.j6();
            this.f17a8.j6();
            this.f24lg.j6();
            this.f26rN.j6();
            this.f20er.j6();
            this.f32yS.j6();
            this.f21gW.j6();
            this.f30vy.clear();
            this.f2BT.clear();
            this.f9P8.clear();
            m0EQ();
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 5559664764016909168L, this);
            }
            throw th;
        }
    }

    public Da m14Hw(int i) {
        try {
            if (f1j6) {
                wu.j6(-383407120762340688L, this, i);
            }
            if (i == -1) {
                return null;
            }
            return this.f15XL[i];
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -383407120762340688L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -893219411458017123L)
    protected String m15Hw() {
        try {
            if (f1j6) {
                wu.j6(241466000622598040L, this);
            }
            return this.f10QX;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 241466000622598040L, this);
            }
            throw th;
        }
    }

    @su(method = -2363875339013319681L)
    protected String m16Hw(Da da) {
        try {
            if (f1j6) {
                wu.j6(-44378321939110908L, this, da);
            }
            if (this.f30vy.containsKey(Integer.valueOf(m3DW(da)))) {
                return this.f30vy.get(Integer.valueOf(m3DW(da))).f45tp;
            }
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -44378321939110908L, this, da);
            }
            throw th;
        }
    }

    public boolean m17J0(Da da) {
        try {
            if (f1j6) {
                wu.j6(4390247616695821296L, this, da);
            }
            if (this.f30vy.containsKey(Integer.valueOf(m3DW(da)))) {
                return this.f30vy.get(Integer.valueOf(m3DW(da))).f38J0;
            }
            return false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 4390247616695821296L, this, da);
            }
            throw th;
        }
    }

    public boolean m18J8(Da da) {
        try {
            if (f1j6) {
                wu.j6(-3703273305246108209L, this, da);
            }
            return m16Hw(da) == null && m57v5(da) == null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -3703273305246108209L, this, da);
            }
            throw th;
        }
    }

    @su(method = 3262604106285942144L)
    protected boolean m19QX(Da da) {
        try {
            if (f1j6) {
                wu.j6(-2822884259589017559L, this, da);
            }
            m2tp();
            return this.f32yS.j6(da);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2822884259589017559L, this, da);
            }
            throw th;
        }
    }

    public int m20VH(Da da) {
        try {
            if (f1j6) {
                wu.j6(-8315551511295425943L, this, da);
            }
            if (da == null) {
                return -1;
            }
            return da.EQ();
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -8315551511295425943L, this, da);
            }
            throw th;
        }
    }

    public _b m21VH() {
        try {
            if (f1j6) {
                wu.j6(4560519782339854080L, this);
            }
            m2tp();
            return this.f20er;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 4560519782339854080L, this);
            }
            throw th;
        }
    }

    public na m22VH(int i) {
        try {
            if (f1j6) {
                wu.j6(-2044531701755640032L, this, i);
            }
            return this.f25nw[i];
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2044531701755640032L, this, new Integer(i));
            }
            throw th;
        }
    }

    public boolean m23Ws(Da da) {
        try {
            if (f1j6) {
                wu.j6(665255737585309475L, this, da);
            }
            if (!m18J8(da) && this.f30vy.containsKey(Integer.valueOf(m3DW(da)))) {
                return this.f30vy.get(Integer.valueOf(m3DW(da))).f42Ws;
            }
            return false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 665255737585309475L, this, da);
            }
            throw th;
        }
    }

    @su(method = 114681700695488256L)
    protected boolean m24XL(Da da) {
        try {
            if (f1j6) {
                wu.j6(3075341858873771787L, this, da);
            }
            m2tp();
            return this.f21gW.j6(da);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 3075341858873771787L, this, da);
            }
            throw th;
        }
    }

    public Da m25Zo(int i) {
        try {
            if (f1j6) {
                wu.j6(-484718178876047064L, this, i);
            }
            return m14Hw(i >> 8);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -484718178876047064L, this, new Integer(i));
            }
            throw th;
        }
    }

    public _b m26Zo() {
        try {
            if (f1j6) {
                wu.j6(2764346946254300585L, this);
            }
            m2tp();
            return this.f32yS;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2764346946254300585L, this);
            }
            throw th;
        }
    }

    public la m27Zo(Da da) {
        try {
            if (f1j6) {
                wu.j6(-3159623823846184448L, this, da);
            }
            if (this.f23j3.j6(da.EQ())) {
                return m56v5(this.f23j3.DW(da.EQ()));
            }
            m2tp();
            la laVarM56v5 = m56v5(this.f23j3.DW(da.EQ()));
            if (laVarM56v5 != null) {
                return laVarM56v5;
            }
            String strTp = da.tp();
            for (la laVar : this.f19ei) {
                if (this.f9P8.containsKey(laVar)) {
                    for (String str : this.f9P8.get(laVar)) {
                        if (pc.j6() != null && pc.j6().j6(strTp, str)) {
                            this.f23j3.j6(da.EQ(), m34j6(laVar));
                            return laVar;
                        }
                    }
                }
            }
            this.f23j3.j6(da.EQ(), -1);
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -3159623823846184448L, this, da);
            }
            throw th;
        }
    }

    public boolean m28aM(Da da) {
        try {
            if (f1j6) {
                wu.j6(-116891058850753904L, this, da);
            }
            if (this.f30vy.containsKey(Integer.valueOf(m3DW(da)))) {
                return this.f30vy.get(Integer.valueOf(m3DW(da))).f39J8;
            }
            return false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -116891058850753904L, this, da);
            }
            throw th;
        }
    }

    public Da m29gn() {
        try {
            if (f1j6) {
                wu.j6(-2606451096052317540L, this);
            }
            return this.f15XL[0];
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2606451096052317540L, this);
            }
            throw th;
        }
    }

    public la m30gn(Da da) {
        try {
            if (f1j6) {
                wu.j6(1617247216980608724L, this, da);
            }
            return m56v5(this.f23j3.DW(da.EQ()));
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1617247216980608724L, this, da);
            }
            throw th;
        }
    }

    public na m31gn(int i) {
        try {
            if (f1j6) {
                wu.j6(4340345100984889216L, this, i);
            }
            return m22VH(i & 255);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 4340345100984889216L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 3884854945228078437L)
    protected int m32j6(Da da) {
        try {
            if (f1j6) {
                wu.j6(-2270564102954903404L, this, da);
            }
            if (this.f18aM >= this.f15XL.length) {
                Da[] daArr = new Da[(this.f15XL.length * 2) + 1];
                System.arraycopy(this.f15XL, 0, daArr, 0, this.f15XL.length);
                this.f15XL = daArr;
            }
            this.f15XL[this.f18aM] = da;
            int i = this.f18aM;
            this.f18aM = i + 1;
            return i;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2270564102954903404L, this, da);
            }
            throw th;
        }
    }

    public int m33j6(Da da, na naVar) {
        try {
            if (f1j6) {
                wu.j6(-2984859541212799449L, this, da, naVar);
            }
            return m35j6(naVar) | (da.EQ() << 8);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2984859541212799449L, this, da, naVar);
            }
            throw th;
        }
    }

    @su(method = 3218822727935119760L)
    protected int m34j6(la laVar) {
        try {
            if (f1j6) {
                wu.j6(-4152784164330015227L, this, laVar);
            }
            for (int i = 0; i < this.f19ei.length; i++) {
                if (laVar == this.f19ei[i]) {
                    return i;
                }
            }
            return -1;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -4152784164330015227L, this, laVar);
            }
            throw th;
        }
    }

    public int m35j6(na naVar) {
        try {
            if (f1j6) {
                wu.j6(3252889944552631215L, this, naVar);
            }
            for (int i = 0; i < this.f25nw.length; i++) {
                if (naVar == this.f25nw[i]) {
                    return i;
                }
            }
            return -1;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 3252889944552631215L, this, naVar);
            }
            throw th;
        }
    }

    public Da m36j6(int i) {
        try {
            if (f1j6) {
                wu.j6(-1179401460701382301L, this, i);
            }
            return m4DW(this.f30vy.get(Integer.valueOf(i)).f37Hw);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1179401460701382301L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -1810936890747391332L)
    protected Reader m37j6(InputStream inputStream, String str) {
        try {
            if (f1j6) {
                wu.j6(2312129664652135185L, this, inputStream, str);
            }
            return this.f16Zo.j6(inputStream, str);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2312129664652135185L, this, inputStream, str);
            }
            throw th;
        }
    }

    public Reader m38j6(Reader reader) {
        try {
            if (f1j6) {
                wu.j6(-6354874702660937024L, this, reader);
            }
            return new b(reader);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -6354874702660937024L, this, reader);
            }
            throw th;
        }
    }

    @su(method = 546656931703383483L)
    protected void m39j6(int i, int i2) {
        try {
            if (f1j6) {
                wu.j6(89671386696338416L, this, new Integer(i), new Integer(i2));
            }
            this.f12U2.FH(i, i2);
            this.f17a8.DW(i, i2);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 89671386696338416L, this, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    @su(method = 3560624685754905411L)
    protected void m40j6(int i, String str, String str2, String str3, String str4, String str5, List<String> list, List<String> list2, List<String> list3, String str6, String str7, String str8, boolean z, boolean z2, boolean z3, boolean z4) {
        if (f1j6) {
            wu.j6(-453252841575270912L, this, new Object[]{new Integer(i), str, str2, str3, str4, str5, list, list2, list3, str6, str7, str8, new Boolean(z), new Boolean(z2), new Boolean(z3), new Boolean(z4)});
        }
        this.f30vy.put(Integer.valueOf(i), new a(str, str2, str3, str4, str5, list3, list, list2, str6, str7, str8, z, z2, z3, z4));
    }

    @su(method = 3067975819440486024L)
    protected void m41j6(Da da, int i, la laVar, boolean z) {
        try {
            if (f1j6) {
                wu.j6(-2039385794632185721L, this, da, new Integer(i), laVar, new Boolean(z));
            }
            this.f23j3.j6(da.EQ(), m34j6(laVar));
            this.f8Mr.j6(da.EQ(), i);
            if (z) {
                this.f24lg.DW(da);
            }
            this.f26rN.DW(da);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -2039385794632185721L, this, da, new Integer(i), laVar, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 3560766198755709768L)
    protected void m42j6(Da da, int i, String str) {
        try {
            if (f1j6) {
                wu.j6(-375242722166157965L, this, da, new Integer(i), str);
            }
            this.f8Mr.j6(da.EQ(), i);
            if (str != null) {
                this.f2BT.put(Integer.valueOf(da.EQ()), str);
            }
            this.f20er.DW(da);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -375242722166157965L, this, da, new Integer(i), str);
            }
            throw th;
        }
    }

    @su(method = 5308389524315791824L)
    protected void m43j6(Da da, la laVar) {
        try {
            if (f1j6) {
                wu.j6(2091663418913299495L, this, da, laVar);
            }
            this.f23j3.j6(da.EQ(), m34j6(laVar));
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2091663418913299495L, this, da, laVar);
            }
            throw th;
        }
    }

    @su(method = -1684455282693765140L)
    protected void m44j6(ec ecVar) {
        try {
            if (f1j6) {
                wu.j6(-5475025141465019895L, this, ecVar);
            }
            for (int i = 0; i < this.f18aM; i++) {
                this.f15XL[i].j6(ecVar);
                if (ecVar.readChar() != 'E') {
                    throw new IOException();
                }
            }
            this.f27tp = new Mb(ecVar);
            this.f3EQ = new Sb(ecVar);
            this.f23j3 = new qb(ecVar);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -5475025141465019895L, this, ecVar);
            }
            throw th;
        }
    }

    @su(method = 7939207055152783600L)
    protected void m45j6(fc fcVar) {
        try {
            if (f1j6) {
                wu.j6(-636154746440259311L, this, fcVar);
            }
            for (int i = 0; i < this.f18aM; i++) {
                this.f15XL[i].j6(fcVar);
                fcVar.writeChar(69);
            }
            this.f27tp.j6(fcVar);
            this.f3EQ.j6(fcVar);
            this.f23j3.j6(fcVar);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -636154746440259311L, this, fcVar);
            }
            throw th;
        }
    }

    @su(method = -748477194385198756L)
    protected void m46j6(la laVar, List<String> list) {
        try {
            if (f1j6) {
                wu.j6(3336387742674299937L, this, laVar, list);
            }
            this.f9P8.put(laVar, list);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 3336387742674299937L, this, laVar, list);
            }
            throw th;
        }
    }

    @su(method = 5173394351855274125L)
    protected void m47j6(String str) {
        try {
            if (f1j6) {
                wu.j6(2578970095810438008L, this, str);
            }
            this.f10QX = str;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2578970095810438008L, this, str);
            }
            throw th;
        }
    }

    @su(method = 396318123645122656L)
    protected void m48j6(boolean z) {
        try {
            if (f1j6) {
                wu.j6(1906279345926389465L, this, z);
            }
            if (z) {
                m0EQ();
            }
            this.f7J8.j6();
            this.f27tp.Hw.DW();
            while (this.f27tp.Hw.j6()) {
                Da daM14Hw = m14Hw(this.f27tp.Hw.FH());
                if (this.f27tp.Hw.Hw() != daM14Hw.a8()) {
                    this.f7J8.DW(daM14Hw.EQ());
                }
            }
            this.f7J8.v5.DW();
            while (this.f7J8.v5.j6()) {
                this.f27tp.FH(this.f7J8.v5.FH());
            }
            this.f14Ws.j6();
            this.f3EQ.Hw.DW();
            while (this.f3EQ.Hw.j6()) {
                Da daM14Hw2 = m14Hw(this.f3EQ.Hw.Hw());
                Da daM14Hw3 = m14Hw(this.f3EQ.Hw.FH());
                if (this.f7J8.j6(daM14Hw2.EQ())) {
                    this.f14Ws.DW(daM14Hw3.EQ());
                }
            }
            this.f14Ws.v5.DW();
            while (this.f14Ws.v5.j6()) {
                int iFH = this.f14Ws.v5.FH();
                this.f3EQ.DW(iFH);
                this.f31we.FH(iFH);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1906279345926389465L, this, new Boolean(z));
            }
            throw th;
        }
    }

    @su(method = 16037669226266885L)
    protected void m49j6(la[] laVarArr) {
        try {
            if (f1j6) {
                wu.j6(560647232297779712L, this, laVarArr);
            }
            this.f19ei = laVarArr;
            ArrayList arrayList = new ArrayList();
            for (la laVar : laVarArr) {
                for (na naVar : laVar.v5()) {
                    if (!arrayList.contains(naVar)) {
                        arrayList.add(naVar);
                    }
                }
            }
            this.f25nw = new na[arrayList.size()];
            arrayList.toArray(this.f25nw);
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 560647232297779712L, this, laVarArr);
            }
            throw th;
        }
    }

    public boolean m50j6() {
        try {
            if (f1j6) {
                wu.j6(2610719290079862045L, this);
            }
            for (int i = 0; i < this.f18aM; i++) {
                Da da = this.f15XL[i];
                if (!da.ei() && da.gn() != null) {
                    return false;
                }
                if (this.f29v5.aj()) {
                    throw new InterruptedException();
                }
            }
            return true;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2610719290079862045L, this);
            }
            throw th;
        }
    }

    @su(method = -4634546308575058064L)
    protected boolean m51j6(Da da, Da da2) {
        try {
            if (f1j6) {
                wu.j6(3699589343540672485L, this, da, da2);
            }
            m2tp();
            return this.f12U2.j6(this.f8Mr.DW(da2.EQ()), this.f8Mr.DW(da.EQ()));
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 3699589343540672485L, this, da, da2);
            }
            throw th;
        }
    }

    @su(method = -2849716933326367880L)
    protected boolean m52j6(Da da, Da da2, Da da3) {
        try {
            if (f1j6) {
                wu.j6(-4717458000905235795L, this, da, da2, da3);
            }
            int iDW = this.f8Mr.DW(da2.EQ());
            int iDW2 = this.f8Mr.DW(da3.EQ());
            this.f17a8.Hw.j6(this.f8Mr.DW(da.EQ()));
            while (this.f17a8.Hw.j6()) {
                int iHw = this.f17a8.Hw.Hw();
                if (iHw == iDW) {
                    return true;
                }
                if (iHw == iDW2) {
                    break;
                }
            }
            return false;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -4717458000905235795L, this, da, da2, da3);
            }
            throw th;
        }
    }

    public String m53tp(Da da) {
        try {
            if (f1j6) {
                wu.j6(5894063050373368245L, this, da);
            }
            if (!this.f30vy.containsKey(Integer.valueOf(m3DW(da)))) {
                return "";
            }
            da = this.f30vy.get(Integer.valueOf(m3DW(da))).f48we;
            return da;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 5894063050373368245L, this, da);
            }
            throw th;
        }
    }

    public _b m54u7() {
        try {
            if (f1j6) {
                wu.j6(5081917329873262027L, this);
            }
            m2tp();
            return this.f21gW;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 5081917329873262027L, this);
            }
            throw th;
        }
    }

    public String m55u7(Da da) {
        try {
            if (f1j6) {
                wu.j6(1023500751594116225L, this, da);
            }
            if (this.f2BT.containsKey(Integer.valueOf(da.EQ()))) {
                return this.f2BT.get(Integer.valueOf(da.EQ()));
            }
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1023500751594116225L, this, da);
            }
            throw th;
        }
    }

    @su(method = -604730361975966369L)
    protected la m56v5(int i) {
        try {
            if (f1j6) {
                wu.j6(2402400123797340408L, this, i);
            }
            if (i < 0) {
                return null;
            }
            return this.f19ei[i];
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 2402400123797340408L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -2473166393039868495L)
    protected String m57v5(Da da) {
        try {
            if (f1j6) {
                wu.j6(-163128722855263704L, this, da);
            }
            if (this.f30vy.containsKey(Integer.valueOf(m3DW(da)))) {
                return this.f30vy.get(Integer.valueOf(m3DW(da))).f35EQ;
            }
            return null;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -163128722855263704L, this, da);
            }
            throw th;
        }
    }

    public la[] m58v5() {
        try {
            if (f1j6) {
                wu.j6(-3615833570103320632L, this);
            }
            return this.f19ei;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -3615833570103320632L, this);
            }
            throw th;
        }
    }

    public boolean m59we(Da da) {
        try {
            if (f1j6) {
                wu.j6(1838158743656153015L, this, da);
            }
            return da.J8() == this.f4FH.m787j6("R");
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, 1838158743656153015L, this, da);
            }
            throw th;
        }
    }
}
