package abcd;

public class C0024CB extends dB<BB> {

    private _J f89FH;

    protected C0024CB(UE ue) {
        super(ue);
    }

    public BB m813call() {
        if (this.f89FH == null) {
            this.f89FH = new WJ(((dB) this).j6);
        }
        sE sEVar = new sE(((dB) this).j6, "HEAD", this.f89FH);
        sEVar.j6();
        return new BB(sEVar);
    }
}
