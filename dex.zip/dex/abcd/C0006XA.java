package abcd;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.eclipse.jgit.JGitText;

public class C0006XA extends GB<C0006XA, cB> {

    private LE f26EQ;

    private boolean f27J0;

    private boolean f28J8;

    private File f29VH;

    private Collection<String> f30Ws;

    private String f31Zo;

    private boolean f32gn;

    private String f33tp;

    private String f34u7;

    private boolean f35we;

    public C0006XA() {
        super((UE) null);
        this.f34u7 = "origin";
        this.f33tp = "HEAD";
        this.f26EQ = vE.j6;
    }

    private dG m24DW(UE ue, ME me) {
        qG qGVar = new qG(ue);
        try {
            return qGVar.VH(me.DW());
        } finally {
            qGVar.EQ();
        }
    }

    private List<WI> m25DW(String str) {
        WI wiJ6 = new WI().j6(true).j6("refs/heads/*", String.valueOf(str) + "/*");
        ArrayList arrayList = new ArrayList();
        if (this.f35we) {
            arrayList.add(wiJ6);
        } else {
            Collection<String> collection = this.f30Ws;
            if (collection != null && collection.size() > 0) {
                for (String str2 : this.f30Ws) {
                    if (wiJ6.v5(str2)) {
                        arrayList.add(wiJ6.DW(str2));
                    }
                }
            }
        }
        return arrayList;
    }

    private ME m26j6(qI qIVar) {
        ME meDW = qIVar.DW("HEAD");
        if (meDW == null) {
            return null;
        }
        ME meDW2 = qIVar.DW("refs/heads/master");
        if (meDW2 != null && meDW2.DW().m301DW(meDW.DW())) {
            return meDW2;
        }
        for (ME me : qIVar.j6()) {
            if (me.getName().startsWith("refs/heads/") && me.DW().m301DW(meDW.DW())) {
                return me;
            }
        }
        return null;
    }

    private UE m27j6(HJ hj) throws SB {
        eB eBVarTp = cB.tp();
        eBVarTp.j6(this.f32gn);
        if (this.f29VH == null) {
            this.f29VH = new File(hj.DW(), ".git");
        }
        if (this.f29VH.exists() && this.f29VH.listFiles().length != 0) {
            throw new SB(MessageFormat.format(JGitText.j6().cloneNonEmptyDirectory, this.f29VH.getName()));
        }
        eBVarTp.j6(this.f29VH);
        return eBVarTp.call().u7();
    }

    private qI m28j6(UE ue, HJ hj) {
        String str;
        C0014XI c0014xi = new C0014XI(ue.Zo(), this.f34u7);
        c0014xi.m90j6(hj);
        if (this.f32gn) {
            str = "refs/heads/";
        } else {
            str = "refs/remotes/" + c0014xi.m82DW();
        }
        c0014xi.m91j6(new WI().j6(true).j6("refs/heads/*", String.valueOf(str) + "/*"));
        c0014xi.m89j6((gE) ue.Zo());
        ue.Zo().v5();
        bB bBVar = new bB(ue);
        bBVar.j6(this.f34u7);
        bBVar.j6(this.f26EQ);
        bBVar.j6(eJ.FH);
        j6(bBVar);
        bBVar.j6(m25DW(str));
        return bBVar.call();
    }

    private void m29j6(UE ue) {
        if (new DB(ue).call().isEmpty()) {
            return;
        }
        FB fb = new FB(ue);
        j6(fb);
        fb.j6(this.f26EQ);
        fb.call();
    }

    private void m30j6(UE ue, ME me) {
        String strHw = UE.Hw(me.getName());
        ue.Zo().j6("branch", strHw, "remote", this.f34u7);
        ue.Zo().j6("branch", strHw, "merge", me.getName());
        ue.Zo().v5();
    }

    private void m31j6(UE ue, qI qIVar) {
        ME meM26j6;
        ME meDW = qIVar.DW(this.f33tp);
        if (!this.f33tp.equals("HEAD") || (meM26j6 = m26j6(qIVar)) == null) {
            meM26j6 = meDW;
        }
        if (meM26j6 == null || meM26j6.DW() == null) {
            return;
        }
        if (meM26j6.getName().startsWith("refs/heads/")) {
            RE reV5 = ue.v5("HEAD");
            reV5.DW();
            reV5.DW(meM26j6.getName());
            m30j6(ue, meM26j6);
        }
        dG dGVarM24DW = m24DW(ue, meM26j6);
        RE reJ6 = ue.j6("HEAD", !meM26j6.getName().startsWith("refs/heads/"));
        dGVarM24DW.getId();
        reJ6.DW(dGVarM24DW);
        reJ6.FH();
        if (this.f32gn) {
            return;
        }
        new NC(ue, ue.XL(), dGVarM24DW.yS()).j6();
        if (this.f27J0) {
            m29j6(ue);
        }
    }

    public C0006XA m32DW(boolean z) {
        this.f35we = z;
        return this;
    }

    public cB m822call() throws SB {
        try {
            HJ hj = new HJ(this.f31Zo);
            UE ueM27j6 = m27j6(hj);
            qI qIVarM28j6 = m28j6(ueM27j6, hj);
            if (!this.f28J8) {
                m31j6(ueM27j6, qIVarM28j6);
            }
            return new cB(ueM27j6);
        } catch (IOException e) {
            throw new SB(e.getMessage(), e);
        } catch (URISyntaxException e2) {
            throw new SB(e2.getMessage(), e2);
        } catch (RB e3) {
            throw new SB(e3.getMessage(), e3);
        }
    }

    public C0006XA m33j6(LE le) {
        this.f26EQ = le;
        return this;
    }

    public C0006XA m34j6(File file) {
        this.f29VH = file;
        return this;
    }

    public C0006XA m35j6(String str) {
        this.f31Zo = str;
        return this;
    }
}
