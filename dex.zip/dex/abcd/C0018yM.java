package abcd;

public class C0018yM extends LL {

    private static final byte[] f40v5 = new byte[0];

    public C0018yM(boolean z, int i, qL qLVar) {
        super(z, i, qLVar);
    }

    boolean m75Zo() {
        if (((LL) this).DW || ((LL) this).FH) {
            return true;
        }
        return ((LL) this).Hw.DW().VH().Zo();
    }

    void m76j6(CL cl) {
        if (((LL) this).DW) {
            cl.j6(160, ((LL) this).j6, f40v5);
            return;
        }
        EL elVH = ((LL) this).Hw.DW().VH();
        if (!((LL) this).FH) {
            cl.j6(elVH.Zo() ? 160 : 128, ((LL) this).j6);
            cl.j6(elVH);
        } else {
            cl.j6(160, ((LL) this).j6);
            cl.DW(elVH.v5());
            cl.j6(elVH);
        }
    }

    int m77v5() {
        int iDW;
        if (((LL) this).DW) {
            return OM.DW(((LL) this).j6) + 1;
        }
        int iV5 = ((LL) this).Hw.DW().VH().v5();
        if (((LL) this).FH) {
            iDW = OM.DW(((LL) this).j6) + OM.j6(iV5);
        } else {
            iV5--;
            iDW = OM.DW(((LL) this).j6);
        }
        return iDW + iV5;
    }
}
