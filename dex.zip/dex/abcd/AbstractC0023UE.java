package abcd;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0023UE {

    private static final HD f53j6 = new HD();

    private final File f55FH;

    private final pK f56Hw;

    private final File f57VH;

    private final File f58Zo;

    private final AtomicInteger f54DW = new AtomicInteger(1);

    private final HD f59v5 = new HD();

    protected AbstractC0023UE(bE bEVar) {
        this.f55FH = bEVar.v5();
        this.f56Hw = bEVar.Hw();
        this.f58Zo = bEVar.gn();
        this.f57VH = bEVar.Zo();
    }

    private yE m92DW(qG qGVar, String str) throws rD, ZC {
        mG mGVarGn;
        int i;
        String str2;
        iG iGVarM97j6;
        String str3;
        int i2;
        char[] charArray = str.toCharArray();
        iG iGVarDW = null;
        int i3 = 0;
        while (i3 < charArray.length) {
            char c = charArray[i3];
            if (c == ':') {
                if (iGVarDW == null) {
                    try {
                        str = i3 == 0 ? m92DW(qGVar, "HEAD") : m92DW(qGVar, new String(charArray, 0, i3));
                        if (str == null) {
                            return null;
                        }
                        mGVarGn = qGVar.gn(str);
                    } catch (rD unused) {
                        throw new rD(str);
                    }
                } else {
                    mGVarGn = qGVar.gn(iGVarDW);
                }
                if (i3 == charArray.length - 1) {
                    return mGVarGn.Hw();
                }
                YJ yjJ6 = YJ.j6(qGVar.Zo(), new String(charArray, i3 + 1, (charArray.length - i3) - 1), new YD[]{mGVarGn});
                if (yjJ6 != null) {
                    return yjJ6.DW(0);
                }
                return null;
            }
            if (c == '@') {
                int i4 = i3 + 2;
                i = i4;
                while (true) {
                    if (i >= charArray.length) {
                        str2 = null;
                    } else if (charArray[i] == '}') {
                        str2 = new String(charArray, i4, (i - i3) - 2);
                    } else {
                        i++;
                    }
                }
                if (str2 != null) {
                    ME meJ6 = m137we().j6(new String(charArray, 0, i3));
                    if (meJ6 == null) {
                        return null;
                    }
                    iGVarM97j6 = m97j6(qGVar, meJ6, str2);
                    iGVarDW = iGVarM97j6;
                    i3 = i;
                } else {
                    i3 = i - 1;
                }
            } else if (c == '^') {
                if (iGVarDW == null && (iGVarDW = m98j6(qGVar, new String(charArray, 0, i3))) == null) {
                    return null;
                }
                int i5 = i3 + 1;
                if (i5 < charArray.length) {
                    char c2 = charArray[i5];
                    if (c2 != '{') {
                        switch (c2) {
                            case '0':
                            case '1':
                            case '2':
                            case '3':
                            case '4':
                            case '5':
                            case '6':
                            case '7':
                            case '8':
                            case '9':
                                iG iGVarVH = qGVar.VH(iGVarDW);
                                int i6 = i5;
                                while (i6 < charArray.length && Character.isDigit(charArray[i6])) {
                                    i6++;
                                }
                                try {
                                    int i7 = Integer.parseInt(new String(charArray, i5, (i6 - i3) - 1));
                                    int i8 = i6 - 1;
                                    iGVarDW = i7 != 0 ? i7 > iGVarVH.lg() ? null : iGVarVH.DW(i7 - 1) : iGVarVH;
                                    i3 = i8;
                                    continue;
                                } catch (NumberFormatException unused2) {
                                    throw new rD(JGitText.j6().invalidCommitParentNumber, str);
                                }
                                break;
                            default:
                                dG dGVarZo = qGVar.Zo(iGVarDW);
                                if (!(dGVarZo instanceof dG)) {
                                    throw new ZC(dGVarZo, "commit");
                                }
                                dG dGVar = dGVarZo;
                                if (dGVar.lg() != 0) {
                                    iGVarDW = dGVar.DW(0);
                                    break;
                                }
                                break;
                        }
                    } else {
                        int i9 = i3 + 2;
                        i = i9;
                        while (true) {
                            if (i >= charArray.length) {
                                str3 = null;
                            } else if (charArray[i] == '}') {
                                str3 = new String(charArray, i9, (i - i3) - 2);
                            } else {
                                i++;
                            }
                        }
                        if (str3 == null) {
                            throw new rD(str);
                        }
                        if (str3.equals("tree")) {
                            iGVarM97j6 = qGVar.gn(iGVarDW);
                        } else if (str3.equals("commit")) {
                            iGVarM97j6 = qGVar.VH(iGVarDW);
                        } else {
                            if (str3.equals("blob")) {
                                iGVarDW = qGVar.FH(iGVarDW);
                                if (!(iGVarDW instanceof cG)) {
                                    throw new ZC(iGVarDW, "blob");
                                }
                            } else {
                                if (!str3.equals("")) {
                                    throw new rD(str);
                                }
                                iGVarM97j6 = qGVar.FH(iGVarDW);
                            }
                            i3 = i;
                        }
                        iGVarDW = iGVarM97j6;
                        i3 = i;
                    }
                } else {
                    dG dGVarFH = qGVar.FH(iGVarDW);
                    if (!(dGVarFH instanceof dG)) {
                        throw new ZC(dGVarFH, "commit");
                    }
                    dG dGVar2 = dGVarFH;
                    iGVarDW = dGVar2.lg() == 0 ? null : dGVar2.DW(0);
                }
            } else if (c != '~') {
                if (iGVarDW != null) {
                    throw new rD(str);
                }
            } else {
                if (iGVarDW == null && (iGVarDW = m98j6(qGVar, new String(charArray, 0, i3))) == null) {
                    return null;
                }
                iGVarDW = qGVar.FH(iGVarDW);
                if (!(iGVarDW instanceof dG)) {
                    throw new ZC(iGVarDW, "commit");
                }
                int i10 = i3 + 1;
                i = i10;
                while (i < charArray.length && Character.isDigit(charArray[i])) {
                    i++;
                }
                int i11 = i - i3;
                if (i11 > 1) {
                    try {
                        i2 = Integer.parseInt(new String(charArray, i10, i11 - 1));
                    } catch (NumberFormatException unused3) {
                        throw new rD(JGitText.j6().invalidAncestryLength, str);
                    }
                } else {
                    i2 = 1;
                }
                while (i2 > 0) {
                    dG dGVar3 = (dG) iGVarDW;
                    if (dGVar3.lg() == 0) {
                        iGVarDW = null;
                        i3 = i - 1;
                    } else {
                        iGVarDW = dGVar3.DW(0);
                        qGVar.DW(iGVarDW);
                        i2--;
                    }
                }
                i3 = i - 1;
            }
            i3++;
        }
        return iGVarDW != null ? iGVarDW.Hw() : m102u7(str);
    }

    public static boolean m93DW(String str) {
        int length = str.length();
        if (length == 0 || str.endsWith(".lock")) {
            return false;
        }
        int i = 0;
        int i2 = 1;
        char c = 0;
        while (i < length) {
            char cCharAt = str.charAt(i);
            if (cCharAt > ' ' && cCharAt != '*' && cCharAt != ':' && cCharAt != '?' && cCharAt != '^') {
                if (cCharAt != '{') {
                    if (cCharAt != '~') {
                        if (cCharAt != '.') {
                            if (cCharAt != '/') {
                                if (cCharAt == '[' || cCharAt == '\\') {
                                }
                            } else {
                                if (i == 0 || i == length - 1) {
                                    return false;
                                }
                                i2++;
                            }
                        } else if (c == 0 || c == '.' || c == '/' || i == length - 1) {
                            return false;
                        }
                    }
                } else if (c == '@') {
                    return false;
                }
                i++;
                c = cCharAt;
            }
            return false;
        }
        return i2 > 1;
    }

    public static String m94Hw(String str) {
        if (str.startsWith("refs/heads/")) {
            return str.substring(11);
        }
        if (str.startsWith("refs/tags/")) {
            return str.substring(10);
        }
        return str.startsWith("refs/remotes/") ? str.substring(13) : str;
    }

    private byte[] m95VH(String str) {
        try {
            byte[] bArrJ6 = BK.j6(new File(m113VH(), str));
            if (bArrJ6.length > 0) {
                return bArrJ6;
            }
            return null;
        } catch (FileNotFoundException unused) {
            return null;
        }
    }

    private yE m96gn(String str) {
        C0108WD c0108wdM642j6 = C0108WD.m642j6(str);
        IE ieM121j3 = m121j3();
        try {
            Collection collectionJ6 = ieM121j3.j6(c0108wdM642j6);
            if (collectionJ6.size() == 0) {
                ieM121j3.FH();
                return null;
            }
            if (collectionJ6.size() != 1) {
                throw new C0021UC(c0108wdM642j6, collectionJ6);
            }
            yE yEVar = (yE) collectionJ6.iterator().next();
            ieM121j3.FH();
            return yEVar;
        } catch (Throwable th) {
            ieM121j3.FH();
            throw th;
        }
    }

    private dG m97j6(qG qGVar, ME me, String str) throws rD {
        try {
            int i = Integer.parseInt(str);
            if (i < 0) {
                throw new rD(MessageFormat.format(JGitText.j6().invalidReflogRevision, str));
            }
            pH pHVarJ6 = new qH(this, me.getName()).j6(i);
            if (pHVarJ6 != null) {
                return qGVar.VH(pHVarJ6.DW());
            }
            throw new rD(MessageFormat.format(JGitText.j6().reflogEntryNotFound, Integer.valueOf(i), me.getName()));
        } catch (NumberFormatException unused) {
            throw new rD(MessageFormat.format(JGitText.j6().invalidReflogRevision, str));
        }
    }

    private iG m98j6(qG qGVar, String str) {
        yE yEVarM102u7 = m102u7(str);
        if (yEVarM102u7 != null) {
            return qGVar.Zo(yEVarM102u7);
        }
        return null;
    }

    private void m99j6(List<yE> list, String str) {
        File file = new File(m113VH(), str);
        if (list == null) {
            zK.j6(file, 4);
            return;
        }
        XK xk = new XK(new FileOutputStream(file));
        try {
            Iterator<yE> it = list.iterator();
            while (it.hasNext()) {
                it.next().DW(xk);
                xk.write(10);
            }
            xk.close();
        } catch (Throwable th) {
            xk.close();
            throw th;
        }
    }

    private static boolean m100j6(char c) {
        if ('0' <= c && c <= '9') {
            return true;
        }
        if ('a' > c || c > 'f') {
            return 'A' <= c && c <= 'F';
        }
        return true;
    }

    private static boolean m101j6(String str, int i) {
        while (i < str.length()) {
            int i2 = i + 1;
            if (!m100j6(str.charAt(i))) {
                return false;
            }
            i = i2;
        }
        return true;
    }

    private yE m102u7(String str) {
        if (yE.DW(str)) {
            return yE.j6(str);
        }
        ME meJ6 = m137we().j6(str);
        if (meJ6 != null) {
            return meJ6.DW();
        }
        if (C0108WD.m637DW(str)) {
            return m96gn(str);
        }
        int iIndexOf = str.indexOf("-g");
        if (iIndexOf + 5 >= str.length() || iIndexOf < 0) {
            return null;
        }
        int i = iIndexOf + 2;
        if (!m100j6(str.charAt(i)) || !m100j6(str.charAt(iIndexOf + 3)) || !m101j6(str, iIndexOf + 4)) {
            return null;
        }
        String strSubstring = str.substring(i);
        if (C0108WD.m637DW(strSubstring)) {
            return m96gn(strSubstring);
        }
        return null;
    }

    public void m103DW() {
        m130j6(false);
    }

    public abstract xE m104EQ();

    public yE m105FH(String str) {
        qG qGVar = new qG(this);
        try {
            return m92DW(qGVar, str);
        } finally {
            qGVar.EQ();
        }
    }

    protected void m106FH() {
        m104EQ().j6();
        m137we().j6();
    }

    public Set<yE> m107Hw() {
        return Collections.emptySet();
    }

    public iF m108J0() {
        if (m111QX() || m113VH() == null) {
            return iF.j6;
        }
        if (new File(m109J8(), ".dotest").exists()) {
            return iF.VH;
        }
        if (new File(m113VH(), ".dotest-merge").exists()) {
            return iF.EQ;
        }
        if (new File(m113VH(), "rebase-apply/rebasing").exists()) {
            return iF.gn;
        }
        if (new File(m113VH(), "rebase-apply/applying").exists()) {
            return iF.u7;
        }
        if (new File(m113VH(), "rebase-apply").exists()) {
            return iF.VH;
        }
        if (new File(m113VH(), "rebase-merge/interactive").exists()) {
            return iF.EQ;
        }
        if (new File(m113VH(), "rebase-merge").exists()) {
            return iF.tp;
        }
        if (new File(m113VH(), "MERGE_HEAD").exists()) {
            try {
                if (!m112U2().Zo()) {
                    return iF.Hw;
                }
            } catch (IOException unused) {
            }
            return iF.FH;
        }
        if (new File(m113VH(), "BISECT_LOG").exists()) {
            return iF.we;
        }
        if (!new File(m113VH(), "CHERRY_PICK_HEAD").exists()) {
            return iF.DW;
        }
        try {
            if (!m112U2().Zo()) {
                return iF.Zo;
            }
        } catch (IOException unused2) {
        }
        return iF.v5;
    }

    public File m109J8() throws iD {
        if (m111QX()) {
            throw new iD();
        }
        return this.f58Zo;
    }

    public abstract void m110Mr();

    public boolean m111QX() {
        return this.f58Zo == null;
    }

    public KC m112U2() {
        return KC.DW(m133tp(), m120gn());
    }

    public File m113VH() {
        return this.f55FH;
    }

    public void m114Ws() {
        this.f54DW.incrementAndGet();
    }

    public KC m115XL() {
        return KC.j6(m133tp(), m120gn(), new TE(this));
    }

    public abstract jF m116Zo();

    public void m117Zo(String str) throws IOException {
        File file = new File(this.f55FH, "MERGE_MSG");
        if (str == null) {
            zK.j6(file, 4);
            return;
        }
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        try {
            fileOutputStream.write(str.getBytes("UTF-8"));
        } finally {
            fileOutputStream.close();
        }
    }

    public String m118a8() throws iD {
        if (m111QX() || m113VH() == null) {
            throw new iD();
        }
        try {
            return IK.j6(BK.j6(new File(m113VH(), "MERGE_MSG")));
        } catch (FileNotFoundException unused) {
            return null;
        }
    }

    public EE m119aM() {
        return m104EQ().Hw();
    }

    public pK m120gn() {
        return this.f56Hw;
    }

    public IE m121j3() {
        return m104EQ().v5();
    }

    public FE m122j6(YD yd, int i) {
        return m104EQ().j6(yd, i);
    }

    public ME m123j6(ME me) {
        try {
            return m137we().j6(me);
        } catch (IOException unused) {
            return me;
        }
    }

    public ME m124j6(String str) {
        return m137we().j6(str);
    }

    public RE m125j6(String str, boolean z) {
        return m137we().j6(str, z);
    }

    public void m126j6() {
        if (this.f54DW.decrementAndGet() == 0) {
            m106FH();
        }
    }

    public void m127j6(KD<?> kd) {
        kd.j6(this);
        this.f59v5.j6(kd);
        f53j6.j6(kd);
    }

    public void m128j6(yE yEVar) {
        m99j6(yEVar != null ? Collections.singletonList(yEVar) : null, "CHERRY_PICK_HEAD");
    }

    public void m129j6(List<yE> list) {
        m99j6(list, "MERGE_HEAD");
    }

    public abstract void m130j6(boolean z);

    public boolean m131j6(YD yd) {
        try {
            return m104EQ().j6(yd);
        } catch (IOException unused) {
            return false;
        }
    }

    public List<yE> m132lg() throws iD {
        if (m111QX() || m113VH() == null) {
            throw new iD();
        }
        byte[] bArrM95VH = m95VH("MERGE_HEAD");
        if (bArrM95VH == null) {
            return null;
        }
        LinkedList linkedList = new LinkedList();
        for (int iZo = 0; iZo < bArrM95VH.length; iZo = IK.Zo(bArrM95VH, iZo + 40)) {
            linkedList.add(yE.v5(bArrM95VH, iZo));
        }
        return linkedList;
    }

    public String toString() {
        String path;
        if (m113VH() != null) {
            path = m113VH().getPath();
        } else {
            path = String.valueOf(getClass().getSimpleName()) + "-" + System.identityHashCode(this);
        }
        return "Repository[" + path + "]";
    }

    public File m133tp() throws iD {
        if (m111QX()) {
            throw new iD();
        }
        return this.f57VH;
    }

    public String m134u7() {
        ME meM124j6 = m124j6("HEAD");
        if (meM124j6 == null) {
            return null;
        }
        if (meM124j6.Zo()) {
            return meM124j6.getTarget().getName();
        }
        if (meM124j6.DW() != null) {
            return meM124j6.DW().we();
        }
        return null;
    }

    public RE m135v5(String str) {
        return m125j6(str, false);
    }

    public Map<String, ME> m136v5() {
        try {
            return m137we().DW("");
        } catch (IOException unused) {
            return new HashMap();
        }
    }

    public abstract OE m137we();
}
