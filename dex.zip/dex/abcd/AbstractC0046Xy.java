package abcd;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.util.LinkedList;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class AbstractC0046Xy<Params, Progress, Result> {

    private static final int f158DW;

    private static final int f159FH;

    private static final ThreadFactory f160Hw;

    public static final Executor f161VH;

    public static final Executor f162Zo;

    private static final b f163gn;

    private static final int f164j6 = Runtime.getRuntime().availableProcessors();

    private static volatile Executor f165u7;

    private static final BlockingQueue<Runnable> f166v5;

    private volatile d f171we = d.PENDING;

    private final AtomicBoolean f168J0 = new AtomicBoolean();

    private final AtomicBoolean f169J8 = new AtomicBoolean();

    private final e<Params, Result> f170tp = new Uy(this);

    private final FutureTask<Result> f167EQ = new Vy(this, this.f170tp);

    private static class a<Data> {

        final Data[] f172DW;

        final AbstractC0046Xy f173j6;

        a(AbstractC0046Xy abstractC0046Xy, Data... dataArr) {
            this.f173j6 = abstractC0046Xy;
            this.f172DW = dataArr;
        }
    }

    private static class b extends Handler {
        public b() {
            super(Looper.getMainLooper());
        }

        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:596)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.$r8$lambda$3Jn-YhBaujEHu2U7RtYHYfrstds(FixTypesVisitor.java:0)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor$$ExternalSyntheticLambda8.apply(D8$$SyntheticClass:0)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
         */
        @Override
        public void handleMessage(Message message) {
            a aVar = (a) message.obj;
            int i = message.what;
            if (i == 1) {
                aVar.f173j6.m271Hw(aVar.f172DW[0]);
            } else {
                if (i != 2) {
                    return;
                }
                aVar.f173j6.m277DW((Object[]) aVar.f172DW);
            }
        }
    }

    static class c implements Executor {

        Runnable f174DW;

        final LinkedList<Runnable> f175j6;

        private c() {
            this.f175j6 = new LinkedList<>();
        }

        c(Ty ty) {
            this();
        }

        @Override
        public synchronized void execute(Runnable runnable) {
            this.f175j6.offer(new RunnableC0089Yy(this, runnable));
            if (this.f174DW == null) {
                m285j6();
            }
        }

        protected synchronized void m285j6() {
            Runnable runnablePoll = this.f175j6.poll();
            this.f174DW = runnablePoll;
            if (runnablePoll != null) {
                AbstractC0046Xy.f162Zo.execute(this.f174DW);
            }
        }
    }

    public enum d {
        PENDING,
        RUNNING,
        FINISHED
    }

    private static abstract class e<Params, Result> implements Callable<Result> {

        Params[] f180j6;

        private e() {
        }

        e(Ty ty) {
            this();
        }
    }

    static {
        int i = f164j6;
        f158DW = i + 1;
        f159FH = (i * 2) + 1;
        f160Hw = new Ty();
        f166v5 = new LinkedBlockingQueue(128);
        f162Zo = new ThreadPoolExecutor(f158DW, f159FH, 1L, TimeUnit.SECONDS, f166v5, f160Hw);
        f161VH = new c(null);
        f163gn = new b();
        f165u7 = f161VH;
    }

    public void m271Hw(Result result) {
        if (m282Zo()) {
            m276DW(result);
        } else {
            m279FH(result);
        }
        this.f171we = d.FINISHED;
    }

    public void m272Zo(Result result) {
        if (this.f169J8.get()) {
            return;
        }
        m275v5(result);
    }

    static Object m273j6(AbstractC0046Xy abstractC0046Xy, Object obj) {
        abstractC0046Xy.m275v5(obj);
        return obj;
    }

    private Result m275v5(Result result) {
        f163gn.obtainMessage(1, new a(this, result)).sendToTarget();
        return result;
    }

    protected abstract void m276DW(Result result);

    protected void m277DW(Progress... progressArr) {
    }

    public final boolean m278DW(boolean z) {
        this.f168J0.set(true);
        return this.f167EQ.cancel(z);
    }

    protected abstract void m279FH(Result result);

    public final d m280Hw() {
        return this.f171we;
    }

    protected void m281VH() {
    }

    public final boolean m282Zo() {
        return this.f168J0.get();
    }

    public final Xy<Params, Progress, Result> m283j6(Executor executor, Params... paramsArr) {
        if (this.f171we != d.PENDING) {
            int i = C0003Wy.f13j6[this.f171we.ordinal()];
            if (i == 1) {
                throw new IllegalStateException("Cannot execute task: the task is already running.");
            }
            if (i == 2) {
                throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
            }
        }
        this.f171we = d.RUNNING;
        m281VH();
        this.f170tp.f180j6 = paramsArr;
        executor.execute(this.f167EQ);
        return this;
    }

    protected abstract Result m284j6(Params... paramsArr);
}
