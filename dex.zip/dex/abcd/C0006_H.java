package abcd;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.ProxySelector;
import java.net.URL;
import java.net.URLConnection;
import java.security.DigestOutputStream;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.TreeMap;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import org.eclipse.jgit.JGitText;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.helpers.XMLReaderFactory;

public class C0006_H {

    private static final Set<String> f16j6 = new HashSet();

    private final String f17DW;

    private final SecretKeySpec f18FH;

    private final ProxySelector f19Hw;

    private final NJ f20VH;

    private final int f21Zo;

    private final String f22v5;

    private final class a extends DefaultHandler {

        private final String f23DW;

        private final String f24FH;

        boolean f25Hw;

        final List<String> f27j6 = new ArrayList();

        private StringBuilder f28v5;

        a(String str, String str2) {
            this.f23DW = str;
            this.f24FH = str2;
        }

        @Override
        public void characters(char[] cArr, int i, int i2) {
            StringBuilder sb = this.f28v5;
            if (sb != null) {
                sb.append(cArr, i, i2);
            }
        }

        @Override
        public void endElement(String str, String str2, String str3) {
            if ("Key".equals(str2)) {
                this.f27j6.add(this.f28v5.toString().substring(this.f24FH.length()));
            } else if ("IsTruncated".equals(str2)) {
                this.f25Hw = NK.j6("true", this.f28v5.toString());
            }
            this.f28v5 = null;
        }

        @Override
        public void ignorableWhitespace(char[] cArr, int i, int i2) {
            StringBuilder sb = this.f28v5;
            if (sb != null) {
                sb.append(cArr, i, i2);
            }
        }

        void m50j6() throws IOException {
            TreeMap treeMap = new TreeMap();
            if (this.f24FH.length() > 0) {
                treeMap.put("prefix", this.f24FH);
            }
            if (!this.f27j6.isEmpty()) {
                StringBuilder sb = new StringBuilder(String.valueOf(this.f24FH));
                List<String> list = this.f27j6;
                sb.append(list.get(list.size() - 1));
                treeMap.put("marker", sb.toString());
            }
            for (int i = 0; i < C0006_H.this.f21Zo; i++) {
                HttpURLConnection httpURLConnectionM37j6 = C0006_H.this.m37j6("GET", this.f23DW, "", treeMap);
                C0006_H.this.m42j6(httpURLConnectionM37j6);
                int iJ6 = AK.j6(httpURLConnectionM37j6);
                if (iJ6 == 200) {
                    this.f25Hw = false;
                    this.f28v5 = null;
                    try {
                        XMLReader xMLReaderCreateXMLReader = XMLReaderFactory.createXMLReader();
                        xMLReaderCreateXMLReader.setContentHandler(this);
                        InputStream inputStream = httpURLConnectionM37j6.getInputStream();
                        try {
                            try {
                                xMLReaderCreateXMLReader.parse(new InputSource(inputStream));
                                inputStream.close();
                                return;
                            } catch (Throwable th) {
                                inputStream.close();
                                throw th;
                            }
                        } catch (SAXException e) {
                            IOException iOException = new IOException(MessageFormat.format(JGitText.j6().errorListing, this.f24FH));
                            iOException.initCause(e);
                            throw iOException;
                        }
                    } catch (SAXException unused) {
                        throw new IOException(JGitText.j6().noXMLParserAvailable);
                    }
                }
                if (iJ6 != 500) {
                    throw C0006_H.this.m31j6("Listing", this.f24FH, httpURLConnectionM37j6);
                }
            }
            throw C0006_H.this.m27Hw("Listing", this.f24FH);
        }

        @Override
        public void startElement(String str, String str2, String str3, Attributes attributes) {
            if ("Key".equals(str2) || "IsTruncated".equals(str2)) {
                this.f28v5 = new StringBuilder();
            }
        }
    }

    static {
        f16j6.add("content-type");
        f16j6.add("content-md5");
        f16j6.add("date");
    }

    public C0006_H(Properties properties) {
        this.f17DW = properties.getProperty("accesskey");
        if (this.f17DW == null) {
            throw new IllegalArgumentException(JGitText.j6().missingAccesskey);
        }
        String property = properties.getProperty("secretkey");
        if (property == null) {
            throw new IllegalArgumentException(JGitText.j6().missingSecretkey);
        }
        this.f18FH = new SecretKeySpec(hE.DW(property), "HmacSHA1");
        String property2 = properties.getProperty("acl", "PRIVATE");
        if (NK.j6("PRIVATE", property2)) {
            this.f22v5 = "private";
        } else {
            if (!NK.j6("PUBLIC", property2) && !NK.j6("PUBLIC-READ", property2) && !NK.j6("PUBLIC_READ", property2)) {
                throw new IllegalArgumentException("Invalid acl: " + property2);
            }
            this.f22v5 = "public-read";
        }
        try {
            String property3 = properties.getProperty("password");
            if (property3 != null) {
                String property4 = properties.getProperty("crypto.algorithm");
                this.f20VH = new NJ.b(property4 == null ? "PBEWithMD5AndDES" : property4, property3);
            } else {
                this.f20VH = NJ.j6;
            }
            this.f21Zo = Integer.parseInt(properties.getProperty("httpclient.retry-max", "3"));
            this.f19Hw = ProxySelector.getDefault();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException(JGitText.j6().invalidEncryption, e);
        } catch (InvalidKeySpecException e2) {
            throw new IllegalArgumentException(JGitText.j6().invalidEncryption, e2);
        }
    }

    private static MessageDigest m26DW() {
        try {
            return MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(JGitText.j6().JRELacksMD5Implementation, e);
        }
    }

    public IOException m27Hw(String str, String str2) {
        return new IOException(MessageFormat.format(JGitText.j6().amazonS3ActionFailedGivingUp, str, str2, Integer.valueOf(this.f21Zo)));
    }

    public IOException m31j6(String str, String str2, HttpURLConnection httpURLConnection) throws IOException {
        IOException iOException = new IOException(MessageFormat.format(JGitText.j6().amazonS3ActionFailed, str, str2, Integer.valueOf(AK.j6(httpURLConnection)), httpURLConnection.getResponseMessage()));
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[2048];
        while (true) {
            int i = httpURLConnection.getErrorStream().read(bArr);
            if (i < 0) {
                break;
            }
            if (i > 0) {
                byteArrayOutputStream.write(bArr, 0, i);
            }
        }
        byte[] byteArray = byteArrayOutputStream.toByteArray();
        if (byteArray.length > 0) {
            iOException.initCause(new IOException("\n" + new String(byteArray)));
        }
        return iOException;
    }

    private static String m32j6() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        return String.valueOf(simpleDateFormat.format(new Date())) + " GMT";
    }

    private static String m33j6(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String str : list) {
            if (sb.length() > 0) {
                sb.append(',');
            }
            sb.append(str.replaceAll("\n", "").trim());
        }
        return sb.toString();
    }

    private static String m34j6(Map<String, String> map, String str) {
        String strRemove = map.remove(str);
        return strRemove != null ? strRemove : "";
    }

    private HttpURLConnection m36j6(String str, String str2, String str3) {
        return m37j6(str, str2, str3, Collections.emptyMap());
    }

    public HttpURLConnection m37j6(String str, String str2, String str3, Map<String, String> map) throws ProtocolException {
        StringBuilder sb = new StringBuilder();
        sb.append("http://");
        sb.append(str2);
        sb.append('.');
        sb.append("s3.amazonaws.com");
        sb.append('/');
        if (str3.length() > 0) {
            AK.j6(sb, str3);
        }
        if (!map.isEmpty()) {
            sb.append('?');
            Iterator<Map.Entry<String, String>> it = map.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, String> next = it.next();
                sb.append(next.getKey());
                sb.append('=');
                AK.j6(sb, next.getValue());
                if (it.hasNext()) {
                    sb.append('&');
                }
            }
        }
        URL url = new URL(sb.toString());
        HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection(AK.j6(this.f19Hw, url));
        httpURLConnection.setRequestMethod(str);
        httpURLConnection.setRequestProperty("User-Agent", "jgit/1.0");
        httpURLConnection.setRequestProperty("Date", m32j6());
        return httpURLConnection;
    }

    static Properties m38j6(File file) throws IOException {
        Properties properties = new Properties();
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            properties.load(fileInputStream);
            return properties;
        } finally {
            fileInputStream.close();
        }
    }

    public void m41j6(String str, String str2, byte[] bArr, RK rk, LE le, String str3) throws IOException {
        if (le == null) {
            le = vE.j6;
        }
        if (str3 == null) {
            str3 = MessageFormat.format(JGitText.j6().progressMonUploading, str2);
        }
        String strJ6 = kK.j6(bArr);
        long jDW = rk.DW();
        String strValueOf = String.valueOf(jDW);
        for (int i = 0; i < this.f21Zo; i++) {
            HttpURLConnection httpURLConnectionM36j6 = m36j6("PUT", str, str2);
            httpURLConnectionM36j6.setRequestProperty("Content-Length", strValueOf);
            httpURLConnectionM36j6.setRequestProperty("Content-MD5", strJ6);
            httpURLConnectionM36j6.setRequestProperty("x-amz-acl", this.f22v5);
            this.f20VH.j6(httpURLConnectionM36j6, "x-amz-meta-");
            m42j6(httpURLConnectionM36j6);
            httpURLConnectionM36j6.setDoOutput(true);
            httpURLConnectionM36j6.setFixedLengthStreamingMode((int) jDW);
            le.j6(str3, (int) (jDW / 1024));
            OutputStream outputStream = httpURLConnectionM36j6.getOutputStream();
            try {
                rk.j6(outputStream, le);
                le.j6();
                outputStream.close();
                int iJ6 = AK.j6(httpURLConnectionM36j6);
                if (iJ6 == 200) {
                    return;
                }
                if (iJ6 != 500) {
                    throw m31j6("Writing", str2, httpURLConnectionM36j6);
                }
            } catch (Throwable th) {
                le.j6();
                outputStream.close();
                throw th;
            }
        }
        throw m27Hw("Writing", str2);
    }

    public void m42j6(HttpURLConnection httpURLConnection) throws IOException {
        Map<String, List<String>> requestProperties = httpURLConnection.getRequestProperties();
        TreeMap treeMap = new TreeMap();
        for (Map.Entry<String, List<String>> entry : requestProperties.entrySet()) {
            String key = entry.getKey();
            if (m43j6(key)) {
                treeMap.put(NK.Hw(key), m33j6(entry.getValue()));
            }
        }
        StringBuilder sb = new StringBuilder();
        sb.append(httpURLConnection.getRequestMethod());
        sb.append('\n');
        sb.append(m34j6(treeMap, "content-md5"));
        sb.append('\n');
        sb.append(m34j6(treeMap, "content-type"));
        sb.append('\n');
        sb.append(m34j6(treeMap, "date"));
        sb.append('\n');
        for (Map.Entry entry2 : treeMap.entrySet()) {
            sb.append((String) entry2.getKey());
            sb.append(':');
            sb.append((String) entry2.getValue());
            sb.append('\n');
        }
        String host = httpURLConnection.getURL().getHost();
        sb.append('/');
        sb.append(host.substring(0, (host.length() - 16) - 1));
        sb.append(httpURLConnection.getURL().getPath());
        try {
            Mac mac = Mac.getInstance("HmacSHA1");
            mac.init(this.f18FH);
            httpURLConnection.setRequestProperty("Authorization", "AWS " + this.f17DW + ":" + kK.j6(mac.doFinal(sb.toString().getBytes("UTF-8"))));
        } catch (InvalidKeyException e) {
            throw new IOException(MessageFormat.format(JGitText.j6().invalidKey, e.getMessage()));
        } catch (NoSuchAlgorithmException e2) {
            throw new IOException(MessageFormat.format(JGitText.j6().noHMACsupport, "HmacSHA1", e2.getMessage()));
        }
    }

    private static boolean m43j6(String str) {
        String strHw = NK.Hw(str);
        return f16j6.contains(strHw) || strHw.startsWith("x-amz-");
    }

    public URLConnection m44DW(String str, String str2) throws IOException {
        for (int i = 0; i < this.f21Zo; i++) {
            HttpURLConnection httpURLConnectionM36j6 = m36j6("GET", str, str2);
            m42j6(httpURLConnectionM36j6);
            int iJ6 = AK.j6(httpURLConnectionM36j6);
            if (iJ6 == 200) {
                this.f20VH.DW(httpURLConnectionM36j6, "x-amz-meta-");
                return httpURLConnectionM36j6;
            }
            if (iJ6 == 404) {
                throw new FileNotFoundException(str2);
            }
            if (iJ6 != 500) {
                throw m31j6("Reading", str2, httpURLConnectionM36j6);
            }
        }
        throw m27Hw("Reading", str2);
    }

    public List<String> m45FH(String str, String str2) throws IOException {
        if (str2.length() > 0 && !str2.endsWith("/")) {
            str2 = String.valueOf(str2) + "/";
        }
        a aVar = new a(str, str2);
        do {
            aVar.m50j6();
        } while (aVar.f25Hw);
        return aVar.f27j6;
    }

    public InputStream m46j6(URLConnection uRLConnection) {
        return this.f20VH.j6(uRLConnection.getInputStream());
    }

    public OutputStream m47j6(String str, String str2, LE le, String str3) {
        MessageDigest messageDigestM26DW = m26DW();
        return this.f20VH.j6(new DigestOutputStream(new ZH(this, str, str2, messageDigestM26DW, le, str3), messageDigestM26DW));
    }

    public void m48j6(String str, String str2) throws IOException {
        for (int i = 0; i < this.f21Zo; i++) {
            HttpURLConnection httpURLConnectionM36j6 = m36j6("DELETE", str, str2);
            m42j6(httpURLConnectionM36j6);
            int iJ6 = AK.j6(httpURLConnectionM36j6);
            if (iJ6 == 204) {
                return;
            }
            if (iJ6 != 500) {
                throw m31j6("Deletion", str2, httpURLConnectionM36j6);
            }
        }
        throw m27Hw("Deletion", str2);
    }

    public void m49j6(String str, String str2, byte[] bArr) throws IOException {
        if (this.f20VH != NJ.j6) {
            OutputStream outputStreamM47j6 = m47j6(str, str2, (LE) null, (String) null);
            outputStreamM47j6.write(bArr);
            outputStreamM47j6.close();
            return;
        }
        String strJ6 = kK.j6(m26DW().digest(bArr));
        String strValueOf = String.valueOf(bArr.length);
        for (int i = 0; i < this.f21Zo; i++) {
            HttpURLConnection httpURLConnectionM36j6 = m36j6("PUT", str, str2);
            httpURLConnectionM36j6.setRequestProperty("Content-Length", strValueOf);
            httpURLConnectionM36j6.setRequestProperty("Content-MD5", strJ6);
            httpURLConnectionM36j6.setRequestProperty("x-amz-acl", this.f22v5);
            m42j6(httpURLConnectionM36j6);
            httpURLConnectionM36j6.setDoOutput(true);
            httpURLConnectionM36j6.setFixedLengthStreamingMode(bArr.length);
            OutputStream outputStream = httpURLConnectionM36j6.getOutputStream();
            try {
                outputStream.write(bArr);
                outputStream.close();
                int iJ6 = AK.j6(httpURLConnectionM36j6);
                if (iJ6 == 200) {
                    return;
                }
                if (iJ6 != 500) {
                    throw m31j6("Writing", str2, httpURLConnectionM36j6);
                }
            } catch (Throwable th) {
                outputStream.close();
                throw th;
            }
        }
        throw m27Hw("Writing", str2);
    }
}
