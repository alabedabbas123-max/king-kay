package abcd;

import java.util.Iterator;

public abstract class AbstractC0080zp extends Sp {
    public AbstractC0080zp(String str, jp jpVar) {
        super(str, jpVar, 4);
    }

    protected void m505tp() {
        Iterator it = Hw().iterator();
        int i = 0;
        while (it.hasNext()) {
            ((AbstractC0037yp) it.next()).j6(i);
            i++;
        }
    }
}
