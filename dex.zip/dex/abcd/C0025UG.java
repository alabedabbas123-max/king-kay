package abcd;

import java.io.File;
import java.io.FilenameFilter;

class C0025UG implements FilenameFilter {
    C0025UG() {
    }

    @Override
    public boolean accept(File file, String str) {
        return !str.endsWith(".lock");
    }
}
