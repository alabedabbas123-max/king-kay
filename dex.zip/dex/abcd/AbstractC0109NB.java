package abcd;

public abstract class AbstractC0109NB extends Exception {
    AbstractC0109NB(String str) {
        super(str);
    }

    AbstractC0109NB(String str, Throwable th) {
        super(str, th);
    }
}
