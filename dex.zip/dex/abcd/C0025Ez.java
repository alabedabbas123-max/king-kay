package abcd;

import io.fabric.sdk.android.b;
import io.fabric.sdk.android.m;
import java.util.Collections;
import java.util.Locale;
import java.util.Map;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;

public class C0025Ez implements Jz {

    private Lz f158DW;

    private SSLSocketFactory f159FH;

    private boolean f160Hw;

    private final m f161j6;

    public C0025Ez() {
        this(new b());
    }

    public C0025Ez(m mVar) {
        this.f161j6 = mVar;
    }

    private synchronized SSLSocketFactory m275DW() {
        SSLSocketFactory sSLSocketFactoryJ6;
        this.f160Hw = true;
        try {
            sSLSocketFactoryJ6 = Kz.j6(this.f158DW);
            this.f161j6.Hw("Fabric", "Custom SSL pinning enabled");
        } catch (Exception e) {
            this.f161j6.FH("Fabric", "Exception while validating pinned certs", e);
            return null;
        }
        return sSLSocketFactoryJ6;
    }

    private synchronized void m276FH() {
        this.f160Hw = false;
        this.f159FH = null;
    }

    private synchronized SSLSocketFactory m277j6() {
        if (this.f159FH == null && !this.f160Hw) {
            this.f159FH = m275DW();
        }
        return this.f159FH;
    }

    private boolean m278j6(String str) {
        return str != null && str.toLowerCase(Locale.US).startsWith("https");
    }

    public Hz m279j6(EnumC0068Fz enumC0068Fz, String str) {
        return m280j6(enumC0068Fz, str, Collections.emptyMap());
    }

    public Hz m280j6(EnumC0068Fz enumC0068Fz, String str, Map<String, String> map) {
        Hz hzJ6;
        SSLSocketFactory sSLSocketFactoryM277j6;
        int i = Dz.j6[enumC0068Fz.ordinal()];
        if (i == 1) {
            hzJ6 = Hz.j6(str, map, true);
        } else if (i == 2) {
            hzJ6 = Hz.DW(str, map, true);
        } else if (i == 3) {
            hzJ6 = Hz.v5(str);
        } else {
            if (i != 4) {
                throw new IllegalArgumentException("Unsupported HTTP method!");
            }
            hzJ6 = Hz.j6(str);
        }
        if (m278j6(str) && this.f158DW != null && (sSLSocketFactoryM277j6 = m277j6()) != null) {
            ((HttpsURLConnection) hzJ6.tp()).setSSLSocketFactory(sSLSocketFactoryM277j6);
        }
        return hzJ6;
    }

    public void m281j6(Lz lz) {
        if (this.f158DW != lz) {
            this.f158DW = lz;
            m276FH();
        }
    }
}
