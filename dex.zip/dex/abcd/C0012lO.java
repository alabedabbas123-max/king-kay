package abcd;

public class C0012lO {

    private boolean f188DW;

    private WN f189FH;

    private WN f190Hw;

    private AP f191j6;

    private _N f192v5;

    public C0012lO(AP ap) {
        this(ap, new hO());
    }

    public C0012lO(AP ap, _N _n) {
        this.f191j6 = ap;
        this.f192v5 = _n;
    }

    private kO m78j6(vP vPVar, XM xm) {
        if (this.f188DW) {
            return new kO(xm, vPVar, this.f191j6, this.f192v5, true);
        }
        if (this.f189FH == null && this.f190Hw == null) {
            return new kO(xm, vPVar, this.f191j6, this.f192v5);
        }
        if (this.f189FH == null) {
            this.f189FH = new iO();
        }
        return new kO(xm, vPVar, this.f191j6, this.f192v5, this.f189FH, this.f190Hw);
    }

    public C0012lO m79DW(WN wn) {
        this.f190Hw = wn;
        return this;
    }

    public kO m80j6(vP vPVar, SN sn) {
        kO kOVarM78j6 = m78j6(vPVar, new XM(new VM(sn.j6())));
        kOVarM78j6.j6(sn);
        return kOVarM78j6;
    }

    public kO m81j6(vP vPVar, byte[] bArr) {
        return m78j6(vPVar, new XM(new pM(bArr)));
    }

    public C0012lO m82j6(WN wn) {
        this.f189FH = wn;
        return this;
    }

    public C0012lO m83j6(boolean z) {
        this.f188DW = z;
        return this;
    }
}
