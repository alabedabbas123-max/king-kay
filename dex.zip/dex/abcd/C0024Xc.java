package abcd;

import java.util.Collections;
import java.util.Set;

@xu
public class C0024Xc implements na {

    @uu
    private static boolean f81DW;

    @tu
    private static boolean f82j6;

    @ru(field = -284395053749204352L)
    private final La f83FH;

    @ru(field = -397860353081080652L)
    private ad f84Hw;

    static {
        wu.j6(C0024Xc.class, 3138827421715518960L, 3138827421715518960L);
    }

    public C0024Xc(La la) {
        try {
            if (f82j6) {
                wu.j6(413698258020571860L, (Object) null, la);
            }
            this.f83FH = la;
            this.f84Hw = new ad();
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, 413698258020571860L, (Object) null, la);
            }
            throw th;
        }
    }

    public void m117DW() {
        try {
            if (f82j6) {
                wu.j6(1422307630829555624L, this);
            }
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, 1422307630829555624L, this);
            }
            throw th;
        }
    }

    public ra m118FH() {
        try {
            if (!f82j6) {
                return null;
            }
            wu.j6(-880001907288079884L, this);
            return null;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, -880001907288079884L, this);
            }
            throw th;
        }
    }

    public ga m119Hw() {
        try {
            if (!f82j6) {
                return null;
            }
            wu.j6(-2001116633402956992L, this);
            return null;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, -2001116633402956992L, this);
            }
            throw th;
        }
    }

    public oa m120VH() {
        try {
            if (!f82j6) {
                return null;
            }
            wu.j6(-105061909070786213L, this);
            return null;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, -105061909070786213L, this);
            }
            throw th;
        }
    }

    public Set<? extends ha> m121Zo() {
        try {
            if (f82j6) {
                wu.j6(598076307940471111L, this);
            }
            return Collections.EMPTY_SET;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, 598076307940471111L, this);
            }
            throw th;
        }
    }

    public ia m122gn() {
        try {
            if (!f82j6) {
                return null;
            }
            wu.j6(-1609733902566892168L, this);
            return null;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, -1609733902566892168L, this);
            }
            throw th;
        }
    }

    public String m123j6() {
        try {
            if (!f82j6) {
                return "DTD";
            }
            wu.j6(-2505314705990157475L, this);
            return "DTD";
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, -2505314705990157475L, this);
            }
            throw th;
        }
    }

    public boolean m124j6(char c) {
        try {
            if (!f82j6) {
                return false;
            }
            wu.j6(1740780060682787712L, this, new Character(c));
            return false;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, 1740780060682787712L, this, new Character(c));
            }
            throw th;
        }
    }

    public qa m125u7() {
        try {
            if (!f82j6) {
                return null;
            }
            wu.j6(16160904132727296L, this);
            return null;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, 16160904132727296L, this);
            }
            throw th;
        }
    }

    public ad m127v5() {
        try {
            if (f82j6) {
                wu.j6(-512935594214818824L, this);
            }
            return this.f84Hw;
        } catch (Throwable th) {
            if (f81DW) {
                wu.j6(th, -512935594214818824L, this);
            }
            throw th;
        }
    }
}
