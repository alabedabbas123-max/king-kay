package abcd;

import java.io.InputStream;

@xu
public abstract class AbstractC0090qc {

    @ru(field = -1553044775777438591L)
    private static AbstractC0090qc f567DW;

    @tu
    private static boolean f568FH;

    @uu
    private static boolean f569Hw;

    @ru(field = -236272350937648905L)
    private static Object f570j6;

    static {
        try {
            wu.j6(AbstractC0090qc.class, 356450621187126592L, 356450621187126592L);
            if (f568FH) {
                wu.j6(-2722941559058630525L, (Object) null);
            }
            f570j6 = new Object();
        } catch (Throwable th) {
            if (f569Hw) {
                wu.j6(th, -2722941559058630525L, (Object) null);
            }
            throw th;
        }
    }

    public AbstractC0090qc() {
        try {
            if (f568FH) {
                wu.j6(1637704114296172384L, (Object) null);
            }
        } catch (Throwable th) {
            if (f569Hw) {
                wu.j6(th, 1637704114296172384L, (Object) null);
            }
            throw th;
        }
    }

    public static AbstractC0090qc m513DW() {
        AbstractC0090qc abstractC0090qc;
        try {
            if (f568FH) {
                wu.j6(2513231065445158872L, (Object) null);
            }
            synchronized (f570j6) {
                abstractC0090qc = f567DW;
            }
            return abstractC0090qc;
        } catch (Throwable th) {
            if (f569Hw) {
                wu.j6(th, 2513231065445158872L, (Object) null);
            }
            throw th;
        }
    }

    public static void m514j6(AbstractC0090qc abstractC0090qc) {
        try {
            if (f568FH) {
                wu.j6(-807780477067940745L, (Object) null, abstractC0090qc);
            }
            synchronized (f570j6) {
                f567DW = abstractC0090qc;
            }
        } catch (Throwable th) {
            if (f569Hw) {
                wu.j6(th, -807780477067940745L, (Object) null, abstractC0090qc);
            }
            throw th;
        }
    }

    public abstract InputStream m515j6(String str);

    public abstract String m516j6();
}
