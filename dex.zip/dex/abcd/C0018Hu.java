package abcd;

import android.app.Application;
import com.appfour.backbone.api.closures.OnApplicationClosure;
import com.appfour.backbone.api.objects.EventData;

class C0018Hu implements jv {

    final AbstractC0060Iu f119DW;

    final OnApplicationClosure f120j6;

    C0018Hu(AbstractC0060Iu abstractC0060Iu, OnApplicationClosure onApplicationClosure) {
        this.f119DW = abstractC0060Iu;
        this.f120j6 = onApplicationClosure;
    }

    public EventData m194j6(Object[] objArr) {
        return this.f120j6.getValue((Application) objArr[0]);
    }
}
