package abcd;

enum C0016fF extends iF {
    C0016fF(String str, int i) {
        super(str, i, (iF) null);
    }

    public boolean m54Hw() {
        return true;
    }
}
