package abcd;

import java.util.Locale;

public abstract class AbstractC0019vD extends RuntimeException {

    private final Locale f32DW;

    private final Class f33j6;

    protected AbstractC0019vD(String str, Class cls, Locale locale, Exception exc) {
        super(str, exc);
        this.f33j6 = cls;
        this.f32DW = locale;
    }
}
