package abcd;

import java.util.ArrayList;
import java.util.List;

@xu
public class C0022Xa {

    @uu
    private static boolean f77DW;

    @tu
    private static boolean f78j6;

    @ru(field = -2696649783064052893L)
    private List<Wa> f79FH;

    @ru(field = 1693061698741961180L)
    private int f80Hw;

    static {
        wu.j6(C0022Xa.class, 194263197534240451L, 194263197534240451L);
    }

    public C0022Xa() {
        try {
            if (f78j6) {
                wu.j6(1562215453158520237L, (Object) null);
            }
            this.f79FH = new ArrayList();
        } catch (Throwable th) {
            if (f77DW) {
                wu.j6(th, 1562215453158520237L, (Object) null);
            }
            throw th;
        }
    }

    public void m113DW() {
        try {
            if (f78j6) {
                wu.j6(-1350132719847053308L, this);
            }
            this.f80Hw = 0;
        } catch (Throwable th) {
            if (f77DW) {
                wu.j6(th, -1350132719847053308L, this);
            }
            throw th;
        }
    }

    public void m114FH() {
        try {
            if (f78j6) {
                wu.j6(204149820666787325L, this);
            }
            this.f79FH = new ArrayList();
        } catch (Throwable th) {
            if (f77DW) {
                wu.j6(th, 204149820666787325L, this);
            }
            throw th;
        }
    }

    public Wa m115j6() {
        try {
            if (f78j6) {
                wu.j6(-1159943479191456264L, this);
            }
            if (this.f80Hw == this.f79FH.size()) {
                this.f79FH.add(new Wa());
            }
            List<Wa> list = this.f79FH;
            int i = this.f80Hw;
            this.f80Hw = i + 1;
            Wa wa = list.get(i);
            wa.j6();
            return wa;
        } catch (Throwable th) {
            if (f77DW) {
                wu.j6(th, -1159943479191456264L, this);
            }
            throw th;
        }
    }

    public void m116j6(Wa wa) {
        int iIndexOf;
        try {
            if (f78j6) {
                wu.j6(-650273815977840081L, this, wa);
            }
            if (this.f80Hw == 0) {
                return;
            }
            if (this.f79FH.get(this.f80Hw - 1) != wa && (iIndexOf = this.f79FH.indexOf(wa)) < this.f80Hw) {
                this.f79FH.set(iIndexOf, this.f79FH.get(this.f80Hw - 1));
                this.f79FH.set(this.f80Hw - 1, wa);
            }
            this.f80Hw--;
        } catch (Throwable th) {
            if (f77DW) {
                wu.j6(th, -650273815977840081L, this, wa);
            }
            throw th;
        }
    }
}
