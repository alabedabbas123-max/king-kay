package abcd;

import java.util.zip.CRC32;

@xu
public class C0018_d implements oa {

    @ru(field = -3356927672222556439L)
    private static byte[] f139DW;

    @ru(field = 2751988482683148813L)
    private static int f140FH;

    @tu
    private static boolean f141Hw;

    @ru(field = -2411011583328459825L)
    private static CRC32 f142j6;

    @uu
    private static boolean f143v5;

    @ru(field = 1558666068114144180L)
    private final Vd f144VH;

    @ru(field = -2014007165958632375L)
    private final La f145Zo;

    static {
        try {
            wu.j6(C0018_d.class, 374076577264302756L, 374076577264302756L);
            if (f141Hw) {
                wu.j6(-578270541748381287L, (Object) null);
            }
            f142j6 = new CRC32();
            f139DW = new byte[1024];
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -578270541748381287L, (Object) null);
            }
            throw th;
        }
    }

    public C0018_d(La la, Vd vd) {
        try {
            if (f141Hw) {
                wu.j6(36942952902911127L, (Object) null, la, vd);
            }
            this.f145Zo = la;
            this.f144VH = vd;
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 36942952902911127L, (Object) null, la, vd);
            }
            throw th;
        }
    }

    @su(method = 2553623690812667921L)
    private long m151DW() {
        try {
            if (f141Hw) {
                wu.j6(-403124829657692529L, this);
            }
            m158j6();
            return f142j6.getValue();
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -403124829657692529L, this);
            }
            throw th;
        }
    }

    @su(method = -2326690103070503659L)
    private void m152DW(Sa sa, int i) {
        try {
            if (f141Hw) {
                wu.j6(-412992017932872789L, this, sa, new Integer(i));
            }
            int iWe = sa.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m152DW(sa, sa.Zo(i, i2));
            }
            int iP8 = sa.P8(i);
            if (iP8 == 1) {
                if (((C0063ae) this.f144VH.v5()).m467lg(sa, i)) {
                    m159j6(sa.XL(i));
                    return;
                } else {
                    if (((C0063ae) this.f144VH.v5()).m469rN(sa, i)) {
                        m160j6(sa, ((C0063ae) this.f144VH.v5()).m440U2(sa, i));
                        m159j6(sa.XL(i));
                        return;
                    }
                    return;
                }
            }
            if (iP8 == 125) {
                m159j6(sa.XL(sa.Zo(i, 1)));
                m160j6(sa, sa.Zo(i, sa.we(i) - 2));
                m159j6(sa.J8(i));
            } else {
                if (iP8 != 207) {
                    return;
                }
                m159j6(sa.XL(sa.Zo(i, 0)));
                m159j6(sa.J8(i));
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -412992017932872789L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 510940519274113368L)
    private void m153DW(Sa sa, int i, Ia ia) throws Throwable {
        try {
            if (f141Hw) {
                wu.j6(-5698397579974578752L, this, sa, new Integer(i), ia);
            }
            try {
                this.f145Zo.a8.j6(ia, sa.vy(i), sa.BT(i), sa.Ws(i), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.QX(i), sa.Ws(i));
            } catch (Throwable th) {
                th = th;
                if (f143v5) {
                    wu.j6(th, -5698397579974578752L, this, sa, new Integer(i), ia);
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    @su(method = 4069050308345391103L)
    private static void m154FH() {
        try {
            if (f141Hw) {
                wu.j6(3520811479070790905L, (Object) null);
            }
            f142j6.reset();
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 3520811479070790905L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = 4020393277845495615L)
    private void m155FH(Sa sa, int i) {
        try {
            if (f141Hw) {
                wu.j6(3250916006956638165L, this, sa, new Integer(i));
            }
            int iP8 = sa.P8(i);
            try {
                if (iP8 != 1) {
                    if (iP8 == 125) {
                        m161j6(sa, i, this.f145Zo.a8.DW(sa.VH(), sa.J8(), sa.J8(i)));
                    } else if (iP8 == 207) {
                        m157Hw(sa, i, this.f145Zo.a8.DW(sa.VH(), sa.J8(), sa.J8(i)));
                    }
                } else if (((C0063ae) this.f144VH.v5()).m469rN(sa, i) || ((C0063ae) this.f144VH.v5()).m467lg(sa, i)) {
                    m153DW(sa, i, this.f145Zo.a8.DW(sa.VH(), sa.J8(), sa.J8(i)));
                }
            } catch (jc unused) {
            }
            int iWe = sa.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m155FH(sa, sa.Zo(i, i2));
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 3250916006956638165L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 853280443102221100L)
    private void m156FH(Sa sa, int i, Ia ia) {
        try {
            if (f141Hw) {
                wu.j6(1073815109106563024L, this, sa, new Integer(i), ia);
            }
            int iWe = sa.we(i);
            if (iWe > 2) {
                int i2 = 0;
                for (int i3 = 1; i3 < iWe; i3 += 2) {
                    this.f145Zo.a8.j6(ia, 0, sa.XL(sa.Zo(sa.Zo(i, i3), 0)), i2);
                    i2++;
                }
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 1073815109106563024L, this, sa, new Integer(i), ia);
            }
            throw th;
        }
    }

    @su(method = 388031049328708240L)
    private void m157Hw(Sa sa, int i, Ia ia) throws Throwable {
        try {
            if (f141Hw) {
                wu.j6(398161421863798980L, this, sa, new Integer(i), ia);
            }
            try {
                this.f145Zo.a8.j6(ia, sa.vy(sa.Zo(i, 0)), sa.BT(sa.Zo(i, 0)), sa.Ws(sa.Zo(i, 0)), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.QX(i), sa.Ws(i));
            } catch (Throwable th) {
                th = th;
                if (f143v5) {
                    wu.j6(th, 398161421863798980L, this, sa, new Integer(i), ia);
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }

    @su(method = 2182778896435289577L)
    private static void m158j6() {
        try {
            if (f141Hw) {
                wu.j6(-1727557539108861661L, (Object) null);
            }
            f142j6.update(f139DW, 0, f140FH);
            f140FH = 0;
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -1727557539108861661L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = 3283479714237974951L)
    private static void m159j6(int i) {
        try {
            if (f141Hw) {
                wu.j6(-1577596110202013335L, (Object) null, i);
            }
            if (f140FH + 4 > f139DW.length) {
                m158j6();
            }
            byte[] bArr = f139DW;
            int i2 = f140FH;
            f140FH = i2 + 1;
            bArr[i2] = (byte) (i & 255);
            byte[] bArr2 = f139DW;
            int i3 = f140FH;
            f140FH = i3 + 1;
            bArr2[i3] = (byte) ((i >> 8) & 255);
            byte[] bArr3 = f139DW;
            int i4 = f140FH;
            f140FH = i4 + 1;
            bArr3[i4] = (byte) ((i >> 16) & 255);
            byte[] bArr4 = f139DW;
            int i5 = f140FH;
            f140FH = i5 + 1;
            bArr4[i5] = (byte) ((i >> 24) & 255);
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -1577596110202013335L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -203801530200587480L)
    private void m160j6(Sa sa, int i) {
        try {
            if (f141Hw) {
                wu.j6(-6519143052527685076L, this, sa, new Integer(i));
            }
            m159j6(sa.we(i));
            m159j6(sa.P8(i));
            if (sa.P8(i) == 1) {
                m159j6(sa.XL(i));
            }
            int iWe = sa.we(i);
            for (int i2 = 0; i2 < iWe; i2++) {
                m160j6(sa, sa.Zo(i, i2));
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -6519143052527685076L, this, sa, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -615445277166020112L)
    private void m161j6(Sa sa, int i, Ia ia) {
        try {
            if (f141Hw) {
                wu.j6(148504639870191868L, this, sa, new Integer(i), ia);
            }
            if (sa.we(i) == 4) {
                this.f145Zo.a8.j6(ia, sa.vy(sa.Zo(i, 1)), sa.BT(sa.Zo(i, 1)), sa.Ws(sa.Zo(i, 1)), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.QX(i), sa.Ws(i));
            } else {
                this.f145Zo.a8.j6(ia, sa.vy(i), sa.BT(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.vy(i), sa.BT(i), sa.QX(i), sa.Ws(i));
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 148504639870191868L, this, sa, new Integer(i), ia);
            }
            throw th;
        }
    }

    /* JADX WARN: Code duplicated, block: B:44:0x01c5 A[Catch: Throwable -> 0x01d0, TRY_LEAVE, TryCatch #1 {Throwable -> 0x01d0, blocks: (B:42:0x01bf, B:44:0x01c5), top: B:59:0x01bf }] */
    /* JADX WARN: Code duplicated, block: B:53:0x01dd  */
    @su(method = -478754788896133232L)
    private void m162j6(Sa sa, int i, ua uaVar, ua uaVar2) throws Throwable {
        ua uaVar3;
        ua uaVar4;
        ua uaVarJ6;
        ua uaVarJ7;
        int iWe;
        try {
            if (f141Hw) {
                wu.j6(971347094168331120L, this, sa, new Integer(i), uaVar, uaVar2);
            }
            int iP8 = sa.P8(i);
            try {
                if (iP8 != 1) {
                    if (iP8 == 125) {
                        int iXL = sa.we(i) == 4 ? sa.XL(sa.Zo(i, 1)) : this.f145Zo.j3.j6("");
                        int iZo = sa.Zo(i, sa.we(i) - 2);
                        Ia iaJ6 = this.f145Zo.a8.j6(sa.VH(), sa.J8(), sa.J8(i), uaVar, 1, iXL, 0, sa.we(iZo) == 2 ? 0 : (sa.we(iZo) - 1) / 2, false, false, 0);
                        m156FH(sa, iZo, iaJ6);
                        m161j6(sa, i, iaJ6);
                    } else if (iP8 == 207) {
                        m157Hw(sa, i, this.f145Zo.a8.j6(sa.VH(), sa.J8(), sa.J8(i), uaVar, 1, sa.XL(sa.Zo(i, 0)), false, false, false, false));
                    } else if (iP8 == 223) {
                        Na naV5 = this.f144VH.FH().v5();
                        this.f145Zo.a8.j6(naV5, sa.VH(), sa.J8());
                        uaVarJ7 = this.f145Zo.a8.j6(sa.VH(), sa.J8(), 0, naV5, 0, 1, sa.VH().J8(), false, false, false);
                        try {
                            uaVarJ6 = this.f145Zo.a8.j6(sa.VH(), sa.J8(), 1, naV5, 0, uaVarJ7, 1, this.f145Zo.j3.j6("Members"), false);
                            iWe = sa.we(i);
                            for (int i2 = 0; i2 < iWe; i2++) {
                                m162j6(sa, sa.Zo(i, i2), uaVarJ7, uaVarJ6);
                            }
                            return;
                        } catch (Throwable th) {
                            th = th;
                            uaVar4 = uaVar2;
                            uaVar3 = uaVarJ7;
                            if (f143v5) {
                                wu.j6(th, 971347094168331120L, this, sa, new Integer(i), uaVar3, uaVar4);
                            }
                            throw th;
                        }
                    }
                } else if (((C0063ae) this.f144VH.v5()).m469rN(sa, i)) {
                    int iM440U2 = ((C0063ae) this.f144VH.v5()).m440U2(sa, i);
                    Ia iaJ7 = this.f145Zo.a8.j6(sa.VH(), sa.J8(), sa.J8(i), uaVar2, 1, sa.XL(i), 0, sa.we(iM440U2) == 2 ? 0 : (sa.we(iM440U2) - 1) / 2, false, false, 0);
                    m156FH(sa, iM440U2, iaJ7);
                    m153DW(sa, i, iaJ7);
                } else if (((C0063ae) this.f144VH.v5()).m467lg(sa, i)) {
                    m153DW(sa, i, this.f145Zo.a8.j6(sa.VH(), sa.J8(), sa.J8(i), uaVar2, 1, sa.XL(i), false, false, false, false));
                }
                iWe = sa.we(i);
                while (i2 < iWe) {
                    m162j6(sa, sa.Zo(i, i2), uaVarJ7, uaVarJ6);
                }
                return;
            } catch (Throwable th2) {
                th = th2;
                uaVar3 = uaVarJ7;
                uaVar4 = uaVarJ6;
                if (f143v5) {
                    wu.j6(th, 971347094168331120L, this, sa, new Integer(i), uaVar3, uaVar4);
                }
                throw th;
            }
            uaVarJ7 = uaVar;
            uaVarJ6 = uaVar2;
        } catch (Throwable th3) {
            th = th3;
            uaVar3 = uaVar;
            uaVar4 = uaVar2;
        }
    }

    public long m163DW(Sa sa) {
        try {
            if (f141Hw) {
                wu.j6(-3000785954341167960L, this, sa);
            }
            m154FH();
            m152DW(sa, sa.aM());
            return m151DW();
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -3000785954341167960L, this, sa);
            }
            throw th;
        }
    }

    public void m164DW(Da da) {
        try {
            if (f141Hw) {
                wu.j6(2538852932678656416L, this, da);
            }
            Sa saJ6 = this.f145Zo.U2.j6(da, this.f144VH);
            m162j6(saJ6, saJ6.aM(), null, null);
            this.f145Zo.U2.j6(saJ6);
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 2538852932678656416L, this, da);
            }
            throw th;
        }
    }

    public void m165DW(ua uaVar) {
        try {
            if (f141Hw) {
                wu.j6(2031789500873093976L, this, uaVar);
            }
            this.f145Zo.a8.DW(uaVar);
            this.f145Zo.a8.FH(uaVar);
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 2031789500873093976L, this, uaVar);
            }
            throw th;
        }
    }

    public void m166FH(Da da) {
        try {
            if (f141Hw) {
                wu.j6(2546885854549646073L, this, da);
            }
            Sa saJ6 = this.f145Zo.U2.j6(da, this.f144VH);
            m155FH(saJ6, saJ6.aM());
            this.f145Zo.U2.j6(saJ6);
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 2546885854549646073L, this, da);
            }
            throw th;
        }
    }

    public void m167FH(Sa sa) {
        try {
            if (f141Hw) {
                wu.j6(7654340275114018577L, this, sa);
            }
            sa.J8().Hw().Hw(sa);
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 7654340275114018577L, this, sa);
            }
            throw th;
        }
    }

    public void m168FH(ua uaVar) {
        try {
            if (f141Hw) {
                wu.j6(-4912038280803274535L, this, uaVar);
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -4912038280803274535L, this, uaVar);
            }
            throw th;
        }
    }

    public long m169Hw(Sa sa) {
        try {
            if (!f141Hw) {
                return 10L;
            }
            wu.j6(-1010536494464688800L, this, sa);
            return 10L;
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -1010536494464688800L, this, sa);
            }
            throw th;
        }
    }

    public void m170Hw(Da da) {
        try {
            if (f141Hw) {
                wu.j6(-4109783220531502675L, this, da);
            }
            this.f145Zo.a8.j6(da, this.f144VH, this.f144VH.FH().v5(), da.J8(), false, 0);
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -4109783220531502675L, this, da);
            }
            throw th;
        }
    }

    public void m171Hw(ua uaVar) {
        try {
            if (f141Hw) {
                wu.j6(1464422685763247232L, this, uaVar);
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 1464422685763247232L, this, uaVar);
            }
            throw th;
        }
    }

    public long m172j6(Sa sa) {
        try {
            if (!f141Hw) {
                return 10L;
            }
            wu.j6(-51165185849284008L, this, sa);
            return 10L;
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -51165185849284008L, this, sa);
            }
            throw th;
        }
    }

    public void m173j6(Da da) {
        try {
            if (f141Hw) {
                wu.j6(705932434225586764L, this, da);
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 705932434225586764L, this, da);
            }
            throw th;
        }
    }

    public void m174j6(Ia ia) {
        try {
            if (f141Hw) {
                wu.j6(596297141575138317L, this, ia);
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, 596297141575138317L, this, ia);
            }
            throw th;
        }
    }

    public void m175j6(ua uaVar) {
        try {
            if (f141Hw) {
                wu.j6(-2645232865929319157L, this, uaVar);
            }
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -2645232865929319157L, this, uaVar);
            }
            throw th;
        }
    }

    public long m176v5(Sa sa) {
        try {
            if (f141Hw) {
                wu.j6(-578343463032491893L, this, sa);
            }
            return m163DW(sa);
        } catch (Throwable th) {
            if (f143v5) {
                wu.j6(th, -578343463032491893L, this, sa);
            }
            throw th;
        }
    }
}
