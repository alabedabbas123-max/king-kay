package abcd;

import android.os.IBinder;
import android.os.IInterface;

public abstract class AbstractC0055vx extends sx implements InterfaceC0012ux {
    public static InterfaceC0012ux m230j6(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterfaceQueryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
        return iInterfaceQueryLocalInterface instanceof InterfaceC0012ux ? (InterfaceC0012ux) iInterfaceQueryLocalInterface : new C0097wx(iBinder);
    }
}
