package abcd;

public class C0024LC extends RC {

    private final C0067MC f115aM;

    C0024LC(C0024LC c0024lc, TC tc) {
        super(c0024lc, tc);
        this.f115aM = c0024lc.f115aM;
    }

    public C0024LC(C0067MC c0067mc) {
        super(c0067mc.FH());
        this.f115aM = c0067mc;
    }

    public void m143J0() {
        int i = ((RC) this).J8;
        int iV5 = ((RC) this).u7.v5();
        if (i < iV5) {
            this.f115aM.m344DW(i, iV5 - i);
        }
    }

    public TJ m144j6(IE ie) throws ZC {
        TC tc = ((RC) this).XL;
        if (tc != null) {
            return new C0024LC(this, tc);
        }
        throw new ZC(v5(), "tree");
    }

    public void m145we() {
        TC tc = ((RC) this).XL;
        if (tc != null) {
            this.f115aM.m344DW(((RC) this).J8, tc.DW());
        } else {
            this.f115aM.m344DW(((RC) this).J8, 1);
        }
        FH(1);
    }
}
