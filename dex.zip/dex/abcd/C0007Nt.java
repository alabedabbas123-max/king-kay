package abcd;

public class C0007Nt implements bu {

    int[] f15j6;

    public C0007Nt(int i) {
        this.f15j6 = C0050Ot.m387j6(i);
    }

    private void m43DW(int i) {
        if (i >= C0050Ot.m376DW(this.f15j6)) {
            int[] iArrM387j6 = C0050Ot.m387j6(Math.max(i + 1, C0050Ot.m376DW(this.f15j6) * 2));
            int[] iArr = this.f15j6;
            System.arraycopy(iArr, 0, iArrM387j6, 0, iArr.length);
            this.f15j6 = iArrM387j6;
        }
    }

    public void m44add(int i) {
        m43DW(i);
        C0050Ot.m384j6(this.f15j6, i, true);
    }

    public _t iterator() {
        return new Mt(this);
    }

    public int m45j6() {
        return C0050Ot.m382j6(this.f15j6);
    }

    public void m46j6(bu buVar) {
        if (buVar instanceof C0007Nt) {
            C0007Nt c0007Nt = (C0007Nt) buVar;
            m43DW(C0050Ot.m376DW(c0007Nt.f15j6) + 1);
            C0050Ot.m385j6(this.f15j6, c0007Nt.f15j6);
        } else {
            if (!(buVar instanceof gu)) {
                _t it = buVar.iterator();
                while (it.hasNext()) {
                    m44add(it.next());
                }
                return;
            }
            gu guVar = (gu) buVar;
            int size = guVar.j6.size();
            if (size > 0) {
                m43DW(guVar.j6.get(size - 1));
            }
            for (int i = 0; i < guVar.j6.size(); i++) {
                C0050Ot.m384j6(this.f15j6, guVar.j6.get(i), true);
            }
        }
    }

    public boolean m47j6(int i) {
        return i < C0050Ot.m376DW(this.f15j6) && C0050Ot.m379FH(this.f15j6, i);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append('{');
        int iM377DW = C0050Ot.m377DW(this.f15j6, 0);
        boolean z = true;
        while (iM377DW >= 0) {
            if (!z) {
                sb.append(", ");
            }
            sb.append(iM377DW);
            iM377DW = C0050Ot.m377DW(this.f15j6, iM377DW + 1);
            z = false;
        }
        sb.append('}');
        return sb.toString();
    }
}
