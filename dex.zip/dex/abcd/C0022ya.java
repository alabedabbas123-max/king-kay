package abcd;

import java.util.Comparator;

@xu
class C0022ya implements Comparator<String> {

    @uu
    private static boolean f60DW;

    @tu
    private static boolean f61j6;

    @vu
    final C0065za f62FH;

    static {
        wu.j6(C0022ya.class, -138465097617559095L, -6266991932506816560L);
    }

    C0022ya(C0065za c0065za) {
        this.f62FH = c0065za;
    }

    @Override
    @su(method = 949169310741728555L)
    public int compare(String str, String str2) {
        try {
            if (f61j6) {
                wu.j6(-233427564669915015L, this, str, str2);
            }
            int length = str.length() - 6;
            int length2 = str2.length() - 6;
            int i = length < length2 ? length : length2;
            for (int i2 = 0; i2 < i; i2++) {
                char cCharAt = str.charAt(i2);
                char cCharAt2 = str2.charAt(i2);
                if (cCharAt == '$' && cCharAt != cCharAt2) {
                    return -1;
                }
                if (cCharAt2 == '$' && cCharAt != cCharAt2) {
                    return 1;
                }
                if (cCharAt == '+' && cCharAt != cCharAt2) {
                    return -1;
                }
                if (cCharAt2 == '+' && cCharAt != cCharAt2) {
                    return 1;
                }
                int i3 = cCharAt - cCharAt2;
                if (i3 < 0) {
                    return -1;
                }
                if (i3 > 0) {
                    return 1;
                }
            }
            if (length < length2) {
                return -1;
            }
            return length > length2 ? 1 : 0;
        } catch (Throwable th) {
            if (f60DW) {
                wu.j6(th, -233427564669915015L, this, str, str2);
            }
            throw th;
        }
    }
}
