package abcd;

import java.util.ArrayList;
import java.util.Collection;

public abstract class AbstractC0029IE {
    public abstract long m325DW(YD yd, int i);

    public abstract AbstractC0029IE m326DW();

    public <T extends yE> ZD<T> m327DW(Iterable<T> iterable, boolean z) {
        return new GE(this, iterable.iterator());
    }

    public abstract boolean m328DW(YD yd);

    public FE m329FH(YD yd) {
        return m332Hw(yd, -1);
    }

    public abstract void m330FH();

    public boolean m331FH(YD yd, int i) {
        try {
            m332Hw(yd, i);
            return true;
        } catch (fD unused) {
            return false;
        }
    }

    public abstract FE m332Hw(YD yd, int i);

    public void m333Hw() {
    }

    public WD m334j6(YD yd) {
        return m335j6(yd, 7);
    }

    public WD m335j6(YD yd, int i) {
        if (i == 40) {
            return WD.j6(yd);
        }
        WD wdJ6 = yd.j6(i);
        Collection<yE> collectionM337j6 = m337j6(wdJ6);
        while (1 < collectionM337j6.size() && i < 40) {
            i++;
            wdJ6 = yd.j6(i);
            ArrayList arrayList = new ArrayList(8);
            for (yE yEVar : collectionM337j6) {
                if (wdJ6.DW(yEVar) == 0) {
                    arrayList.add(yEVar);
                }
            }
            collectionM337j6 = 1 < arrayList.size() ? arrayList : m337j6(wdJ6);
        }
        return wdJ6;
    }

    public <T extends yE> _D<T> m336j6(Iterable<T> iterable, boolean z) {
        return new HE(this, iterable.iterator());
    }

    public abstract Collection<yE> m337j6(WD wd);

    public void m338j6(_F _f, dG dGVar, dG dGVar2) {
    }

    public void m339j6(qG qGVar, Collection<dG> collection) {
    }
}
