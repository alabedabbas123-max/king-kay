package abcd;

import java.util.Collection;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0011cK extends jK {

    private static class a extends AbstractC0011cK {

        private final jK f34FH;

        private final jK f35Hw;

        a(jK jKVar, jK jKVar2) {
            this.f34FH = jKVar;
            this.f35Hw = jKVar2;
        }

        public jK clone() {
            return new a(this.f34FH.clone(), this.f35Hw.clone());
        }

        public boolean m61j6() {
            return this.f34FH.j6() || this.f35Hw.j6();
        }

        public boolean m62j6(YJ yj) {
            return this.f34FH.j6(yj) && this.f35Hw.j6(yj);
        }

        public String toString() {
            return "(" + this.f34FH.toString() + " AND " + this.f35Hw.toString() + ")";
        }
    }

    private static class b extends AbstractC0011cK {

        private final jK[] f36FH;

        b(jK[] jKVarArr) {
            this.f36FH = jKVarArr;
        }

        public jK clone() {
            jK[] jKVarArr = new jK[this.f36FH.length];
            for (int i = 0; i < jKVarArr.length; i++) {
                jKVarArr[i] = this.f36FH[i].clone();
            }
            return new b(jKVarArr);
        }

        public boolean m63j6() {
            for (jK jKVar : this.f36FH) {
                if (jKVar.j6()) {
                    return true;
                }
            }
            return false;
        }

        public boolean m64j6(YJ yj) {
            for (jK jKVar : this.f36FH) {
                if (!jKVar.j6(yj)) {
                    return false;
                }
            }
            return true;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("(");
            for (int i = 0; i < this.f36FH.length; i++) {
                if (i > 0) {
                    sb.append(" AND ");
                }
                sb.append(this.f36FH[i].toString());
            }
            sb.append(")");
            return sb.toString();
        }
    }

    public static jK m59j6(jK jKVar, jK jKVar2) {
        jK jKVar3 = jK.j6;
        if (jKVar == jKVar3) {
            return jKVar2;
        }
        return jKVar2 == jKVar3 ? jKVar : new a(jKVar, jKVar2);
    }

    public static jK m60j6(Collection<jK> collection) {
        if (collection.size() < 2) {
            throw new IllegalArgumentException(JGitText.j6().atLeastTwoFiltersNeeded);
        }
        jK[] jKVarArr = new jK[collection.size()];
        collection.toArray(jKVarArr);
        return jKVarArr.length == 2 ? m59j6(jKVarArr[0], jKVarArr[1]) : new b(jKVarArr);
    }
}
