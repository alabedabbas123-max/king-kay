package abcd;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Provider;
import java.security.SecureRandom;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class C0015cO extends C0059dO {

    private List f44ei = new ArrayList();

    private class a {

        final Object f45DW;

        final String f46FH;

        final String f47Hw;

        final WN f48Zo;

        final PrivateKey f49j6;

        final WN f50v5;

        kO m81j6(SecureRandom secureRandom, Provider provider, boolean z) throws NoSuchAlgorithmException {
            String str = String.valueOf(C0103eO.f425j6.m504j6(this.f46FH)) + "with" + C0103eO.f425j6.m502DW(this.f47Hw);
            nO nOVar = new nO(new GP());
            if (z) {
                nOVar.j6(this.f50v5);
            }
            nOVar.j6(!z);
            nOVar.DW(this.f48Zo);
            try {
                JP jp = new JP(str);
                jp.j6(secureRandom);
                if (provider != null) {
                    jp.j6(provider);
                }
                vP vPVarJ6 = jp.j6(this.f49j6);
                Object obj = this.f45DW;
                return obj instanceof X509Certificate ? nOVar.j6(vPVarJ6, (X509Certificate) obj) : nOVar.j6(vPVarJ6, (byte[]) obj);
            } catch (IllegalArgumentException e) {
                throw new NoSuchAlgorithmException(e.getMessage());
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0069  */
    public aO m78j6(fO fOVar, boolean z) throws XN {
        qL sl;
        if (!this.f44ei.isEmpty()) {
            throw new IllegalStateException("this method can only be used with SignerInfoGenerator");
        }
        rL rLVar = new rL();
        rL rLVar2 = new rL();
        this.f256vy.clear();
        for (mO mOVar : this.f255gW) {
            rLVar.j6(C0103eO.f425j6.m503j6(mOVar.j6()));
            rLVar2.j6(mOVar.DW());
        }
        zL contentType = fOVar.getContentType();
        if (fOVar == null) {
            sl = null;
        } else {
            ByteArrayOutputStream byteArrayOutputStream = z ? new ByteArrayOutputStream() : null;
            OutputStream outputStreamJ6 = gO.j6(gO.j6(this.f252BT, byteArrayOutputStream));
            try {
                fOVar.j6(outputStreamJ6);
                outputStreamJ6.close();
                if (z) {
                    sl = new SL(byteArrayOutputStream.toByteArray());
                } else {
                    sl = null;
                }
            } catch (IOException e) {
                throw new XN("data processing exception: " + e.getMessage(), e);
            }
        }
        for (kO kOVar : this.f252BT) {
            YM ymJ6 = kOVar.j6(contentType);
            rLVar.j6(ymJ6.v5());
            rLVar2.j6(ymJ6);
            byte[] bArrJ6 = kOVar.j6();
            if (bArrJ6 != null) {
                this.f256vy.put(ymJ6.v5().v5().tp(), bArrJ6);
            }
        }
        return new aO(fOVar, new UM(TM.DW, new WM(new vM(rLVar), new UM(contentType, sl), this.f254er.size() != 0 ? gO.j6(this.f254er) : null, this.f257yS.size() != 0 ? gO.j6(this.f257yS) : null, new vM(rLVar2))));
    }

    public aO m79j6(String str, YN yn, boolean z, String str2, boolean z2) {
        return m80j6(str, yn, z, gO.j6(str2), z2);
    }

    public aO m80j6(String str, YN yn, boolean z, Provider provider, boolean z2) throws XN {
        zL zLVar = str == null ? null : new zL(str);
        Iterator it = this.f44ei.iterator();
        while (it.hasNext()) {
            try {
                this.f252BT.add(((a) it.next()).m81j6(this.f253P8, provider, z2));
            } catch (BP e) {
                throw new XN("exception creating signerInf", e);
            } catch (IOException e2) {
                throw new XN("exception encoding attributes", e2);
            } catch (CertificateEncodingException e3) {
                throw new XN("error creating sid.", e3);
            }
        }
        this.f44ei.clear();
        return yn != null ? m78j6(new bO(this, zLVar, yn), z) : m78j6(new VN(zLVar), z);
    }
}
