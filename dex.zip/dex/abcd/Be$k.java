package abcd;

@xu
public class Be$k extends Be$b {

    @uu
    private static boolean f483VH;

    @tu
    private static boolean f484Zo;

    static {
        wu.j6(Be$k.class, 2000263789109823669L, 2000263789109823669L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$k(int i) {
        super(i);
        try {
            if (f484Zo) {
                wu.j6(3575376432646579617L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f483VH) {
                wu.j6(th, 3575376432646579617L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }
}
