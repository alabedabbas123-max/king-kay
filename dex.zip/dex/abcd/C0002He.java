package abcd;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

@xu
public class C0002He extends Si<C0002He> {

    @uu
    private static boolean f71VH;

    @tu
    private static boolean f72Zo;

    public List<String> f73gn;

    static {
        wu.j6(C0002He.class, 489031357727148317L, 489031357727148317L);
    }

    public C0002He() {
        try {
            if (f72Zo) {
                wu.j6(-464797732478146200L, (Object) null);
            }
            this.f73gn = new ArrayList();
        } catch (Throwable th) {
            if (f71VH) {
                wu.j6(th, -464797732478146200L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -151583346288489735L)
    private C0002He(String str) {
        try {
            if (f72Zo) {
                wu.j6(-3409270691436529372L, (Object) null, str);
            }
            this.f73gn = new ArrayList();
            try {
                FileInputStream fileInputStream = new FileInputStream(str);
                Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(fileInputStream);
                fileInputStream.close();
                NodeList elementsByTagName = document.getElementsByTagName("versions");
                Element element = (Element) elementsByTagName.item(0);
                if (element != null) {
                    NodeList elementsByTagName2 = element.getElementsByTagName("version");
                    for (int i = 0; i < elementsByTagName2.getLength(); i++) {
                        this.f73gn.add(((Element) elementsByTagName2.item(i)).getTextContent());
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Throwable th) {
            if (f71VH) {
                wu.j6(th, -3409270691436529372L, (Object) null, str);
            }
            throw th;
        }
    }

    public static String m121j6(ArrayList<String> arrayList, String str) {
        try {
            if (f72Zo) {
                wu.j6(759678053507465216L, (Object) null, arrayList, str);
            }
            Collections.sort(arrayList, new Ge());
            for (int size = arrayList.size() - 1; size >= 0; size--) {
                if (m122j6(arrayList.get(size), str)) {
                    return arrayList.get(size);
                }
            }
            return null;
        } catch (Throwable th) {
            if (f71VH) {
                wu.j6(th, 759678053507465216L, (Object) null, arrayList, str);
            }
            throw th;
        }
    }

    public static boolean m122j6(String str, String str2) {
        try {
            if (f72Zo) {
                wu.j6(-277436131022243353L, (Object) null, str, str2);
            }
            if (str2 == null || str2.equals(str)) {
                return true;
            }
            if (str2.contains("+")) {
                return str.startsWith(str2.substring(0, str2.indexOf(43)));
            }
            return false;
        } catch (Throwable th) {
            if (f71VH) {
                wu.j6(th, -277436131022243353L, (Object) null, str, str2);
            }
            throw th;
        }
    }

    @su(method = -478014834558299088L)
    public C0002He m124DW(String str) {
        try {
            if (f72Zo) {
                wu.j6(-4761912503646473679L, this, str);
            }
            return new C0002He(str);
        } catch (Throwable th) {
            if (f71VH) {
                wu.j6(th, -4761912503646473679L, this, str);
            }
            throw th;
        }
    }

    public String m125FH(String str) {
        try {
            if (f72Zo) {
                wu.j6(-7741182119685418320L, this, str);
            }
            if (!str.contains(",")) {
                if (str.startsWith("[") && str.endsWith("]")) {
                    str = str.substring(1, str.length() - 1);
                }
                for (int size = this.f73gn.size() - 1; size >= 0; size--) {
                    if (m122j6(this.f73gn.get(size), str)) {
                        return this.f73gn.get(size);
                    }
                }
                return null;
            }
            String strSubstring = str.substring(1, str.indexOf(44));
            String strSubstring2 = str.substring(str.indexOf(44) + 1, str.length() - 1);
            int i = 0;
            boolean z = str.charAt(0) == '[';
            boolean z2 = str.charAt(str.length() - 1) == ']';
            int size2 = this.f73gn.size() - 1;
            if (strSubstring2.length() > 0) {
                while (size2 >= 0) {
                    if (m122j6(this.f73gn.get(size2), strSubstring2)) {
                        if (!z2) {
                            size2--;
                            break;
                        }
                        break;
                    }
                    size2--;
                }
            }
            if (strSubstring.length() > 0) {
                while (i < this.f73gn.size()) {
                    if (m122j6(this.f73gn.get(i), strSubstring)) {
                        if (!z) {
                            i++;
                            break;
                        }
                        break;
                    }
                    i++;
                }
            }
            if (size2 >= i && i < this.f73gn.size()) {
                return this.f73gn.get(size2);
            }
            if (i < this.f73gn.size()) {
                return this.f73gn.get(i);
            }
            return null;
        } catch (Throwable th) {
            if (f71VH) {
                wu.j6(th, -7741182119685418320L, this, str);
            }
            throw th;
        }
    }
}
