package abcd;

class C0003Wy {

    static final int[] f13j6 = new int[AbstractC0046Xy.d.values().length];

    static {
        try {
            f13j6[AbstractC0046Xy.d.RUNNING.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            f13j6[AbstractC0046Xy.d.FINISHED.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
    }
}
