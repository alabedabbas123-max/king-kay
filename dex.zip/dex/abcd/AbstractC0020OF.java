package abcd;

abstract class AbstractC0020OF extends LF {

    protected b f62FH = new b();

    static final class a {

        final dG[] f63DW = new dG[256];

        int f64FH;

        int f65Hw;

        a f66j6;

        a() {
        }

        void m99DW() {
            this.f66j6 = null;
            this.f64FH = 0;
            this.f65Hw = 0;
        }

        void m100DW(dG dGVar) {
            dG[] dGVarArr = this.f63DW;
            int i = this.f64FH - 1;
            this.f64FH = i;
            dGVarArr[i] = dGVar;
        }

        boolean m101FH() {
            return this.f64FH == this.f65Hw;
        }

        boolean m102Hw() {
            return this.f65Hw == 256;
        }

        void m103VH() {
            this.f65Hw = 128;
            this.f64FH = 128;
        }

        void m104Zo() {
            this.f65Hw = 256;
            this.f64FH = 256;
        }

        void m105j6(dG dGVar) {
            dG[] dGVarArr = this.f63DW;
            int i = this.f65Hw;
            this.f65Hw = i + 1;
            dGVarArr[i] = dGVar;
        }

        boolean m106j6() {
            return this.f64FH > 0;
        }

        dG m107v5() {
            dG[] dGVarArr = this.f63DW;
            int i = this.f64FH;
            this.f64FH = i + 1;
            return dGVarArr[i];
        }
    }

    static final class b {

        private a f67j6;

        b() {
        }

        a m108j6() {
            a aVar = this.f67j6;
            if (aVar == null) {
                return new a();
            }
            this.f67j6 = aVar.f66j6;
            aVar.m99DW();
            return aVar;
        }

        void m109j6(a aVar) {
            aVar.f66j6 = this.f67j6;
            this.f67j6 = aVar;
        }
    }

    protected AbstractC0020OF() {
    }

    AbstractC0020OF(XF xf) {
        ((LF) this).DW = xf.DW();
        xf.j6(this);
        while (true) {
            dG dGVarJ6 = xf.j6();
            if (dGVarJ6 == null) {
                return;
            } else {
                j6(dGVarJ6);
            }
        }
    }

    public void m98j6(AbstractC0020OF abstractC0020OF) {
        this.f62FH = abstractC0020OF.f62FH;
    }
}
