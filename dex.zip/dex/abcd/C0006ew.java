package abcd;

class C0006ew implements vw.b {

    final C0050fw f54j6;

    C0006ew(C0050fw c0050fw) {
        this.f54j6 = c0050fw;
    }

    public void m19j6(boolean z) {
        if (z) {
            yw.j6("Networking", "Network became available - notifying networking thread...");
            synchronized (this.f54j6.f209Hw) {
                this.f54j6.f209Hw.notify();
            }
        }
    }
}
