package abcd;

import java.io.OutputStream;

@xu
public class C0007Kl extends OutputStream {

    @uu
    private static boolean f51DW;

    @tu
    private static boolean f52j6;

    @ru(field = -511362552826188901L)
    private final OutputStream f53FH;

    @ru(field = -511382988863066188L)
    private final OutputStream f54Hw;

    static {
        wu.j6(C0007Kl.class, 350630418671245344L, 350630418671245344L);
    }

    public C0007Kl(OutputStream outputStream, OutputStream outputStream2) {
        try {
            if (f52j6) {
                wu.j6(425321149652825512L, (Object) null, outputStream, outputStream2);
            }
            this.f53FH = outputStream;
            this.f54Hw = outputStream2;
        } catch (Throwable th) {
            if (f51DW) {
                wu.j6(th, 425321149652825512L, (Object) null, outputStream, outputStream2);
            }
            throw th;
        }
    }

    @Override
    public void close() {
        try {
            if (f52j6) {
                wu.j6(-1647043526303603424L, this);
            }
            if (this.f53FH != null) {
                this.f53FH.close();
            }
            if (this.f54Hw != null) {
                this.f54Hw.close();
            }
        } catch (Throwable th) {
            if (f51DW) {
                wu.j6(th, -1647043526303603424L, this);
            }
            throw th;
        }
    }

    @Override
    public void flush() {
        try {
            if (f52j6) {
                wu.j6(-1550418596417897976L, this);
            }
            if (this.f53FH != null) {
                this.f53FH.flush();
            }
            if (this.f54Hw != null) {
                this.f54Hw.flush();
            }
        } catch (Throwable th) {
            if (f51DW) {
                wu.j6(th, -1550418596417897976L, this);
            }
            throw th;
        }
    }

    @Override
    public void write(int i) {
        try {
            if (f52j6) {
                wu.j6(-670904570860601360L, this, i);
            }
            if (this.f53FH != null) {
                this.f53FH.write(i);
            }
            if (this.f54Hw != null) {
                this.f54Hw.write(i);
            }
        } catch (Throwable th) {
            if (f51DW) {
                wu.j6(th, -670904570860601360L, this, new Integer(i));
            }
            throw th;
        }
    }

    @Override
    public void write(byte[] bArr) {
        try {
            if (f52j6) {
                wu.j6(875292999722787212L, this, bArr);
            }
            if (this.f53FH != null) {
                this.f53FH.write(bArr);
            }
            if (this.f54Hw != null) {
                this.f54Hw.write(bArr);
            }
        } catch (Throwable th) {
            if (f51DW) {
                wu.j6(th, 875292999722787212L, this, bArr);
            }
            throw th;
        }
    }

    @Override
    public void write(byte[] bArr, int i, int i2) {
        try {
            if (f52j6) {
                wu.j6(-414479510827417000L, this, bArr, new Integer(i), new Integer(i2));
            }
            if (this.f53FH != null) {
                this.f53FH.write(bArr, i, i2);
            }
            if (this.f54Hw != null) {
                this.f54Hw.write(bArr, i, i2);
            }
        } catch (Throwable th) {
            if (f51DW) {
                wu.j6(th, -414479510827417000L, this, bArr, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }
}
