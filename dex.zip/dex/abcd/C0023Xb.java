package abcd;

@xu
class C0023Xb {
    static {
        wu.j6(C0023Xb.class, 523805944999715320L, -100941146410407591L);
    }
}
