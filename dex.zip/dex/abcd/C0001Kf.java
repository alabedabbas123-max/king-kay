package abcd;

import com.aide.common.u;
import com.aide.ui.U;

@xu
public class C0001Kf implements Yl, Wl {

    @uu
    private static boolean f2DW;

    @tu
    private static boolean f3j6;

    static {
        wu.j6(C0001Kf.class, -4581574782419649491L, -4581574782419649491L);
    }

    public C0001Kf() {
        try {
            if (f3j6) {
                wu.j6(987002696787161172L, (Object) null);
            }
        } catch (Throwable th) {
            if (f2DW) {
                wu.j6(th, 987002696787161172L, (Object) null);
            }
            throw th;
        }
    }

    public u m2FH() {
        try {
            if (f3j6) {
                wu.j6(-3878072313257155637L, this);
            }
            return new u(35, true, true, false);
        } catch (Throwable th) {
            if (f2DW) {
                wu.j6(th, -3878072313257155637L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f3j6) {
                return "Find Extended Usages";
            }
            wu.j6(-622765853186689128L, this);
            return "Find Extended Usages";
        } catch (Throwable th) {
            if (f2DW) {
                wu.j6(th, -622765853186689128L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f3j6) {
                wu.j6(-151631260611581096L, this);
            }
            return U.er().m760Zo() && U.lg().J8().getCurrentFileSpan().DW();
        } catch (Throwable th) {
            if (f2DW) {
                wu.j6(th, -151631260611581096L, this);
            }
            throw th;
        }
    }

    public int m3j6() {
        try {
            if (!f3j6) {
                return com.aide.pro.R.id.editorMenuFindExtendedUsages;
            }
            wu.j6(-127111603786457316L, this);
            return com.aide.pro.R.id.editorMenuFindExtendedUsages;
        } catch (Throwable th) {
            if (f2DW) {
                wu.j6(th, -127111603786457316L, this);
            }
            throw th;
        }
    }

    public boolean m4run() {
        try {
            if (f3j6) {
                wu.j6(34912683848900820L, this);
            }
            Tl currentFileSpan = U.lg().J8().getCurrentFileSpan();
            U.nw().j6(currentFileSpan.FH, currentFileSpan.Hw, currentFileSpan.v5, currentFileSpan.Zo, currentFileSpan.VH);
            return true;
        } catch (Throwable th) {
            if (f2DW) {
                wu.j6(th, 34912683848900820L, this);
            }
            throw th;
        }
    }
}
