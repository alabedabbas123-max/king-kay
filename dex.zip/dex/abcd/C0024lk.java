package abcd;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Build;
import android.support.v4.content.FileProvider;
import com.aide.ui.U;
import com.aide.ui.aa;
import java.io.File;
import java.util.Iterator;
import java.util.List;

@xu
public class C0024lk {

    @uu
    private static boolean f232DW;

    @tu
    private static boolean f233j6;

    @ru(field = 996150106863176160L)
    private boolean f234FH;

    @ru(field = 3542630941687810280L)
    private boolean f235Hw;

    static {
        wu.j6(C0024lk.class, -843596403928054707L, -843596403928054707L);
    }

    public C0024lk() {
        try {
            if (f233j6) {
                wu.j6(-2673701869623466392L, (Object) null);
            }
        } catch (Throwable th) {
            if (f232DW) {
                wu.j6(th, -2673701869623466392L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = 489121587868889915L)
    public void m162DW(String str, String str2) {
        try {
            if (f233j6) {
                wu.j6(-5478772013821762951L, this, str, str2);
            }
            F.j6("Run app with root");
            new Thread((Runnable) new kk(this, str, str2)).start();
        } catch (Throwable th) {
            if (f232DW) {
                wu.j6(th, -5478772013821762951L, this, str, str2);
            }
            throw th;
        }
    }

    @su(method = 5317307856483046095L)
    public void m165j6(String str) {
        Uri uriFromFile;
        try {
            if (f233j6) {
                wu.j6(-5404124222150917387L, this, str);
            }
            if (!U.dx() || U.ei().FH()) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.addFlags(268435456);
                intent.addFlags(4096);
                if (Build.VERSION.SDK_INT >= 24) {
                    uriFromFile = FileProvider.j6(U.Zo(), Vl.Hw(), new File(str));
                    intent.addFlags(1);
                } else {
                    uriFromFile = Uri.fromFile(new File(str));
                }
                intent.setDataAndType(uriFromFile, "application/vnd.android.package-archive");
                List<ResolveInfo> listQueryIntentActivities = U.Zo().getPackageManager().queryIntentActivities(intent, 0);
                if (listQueryIntentActivities != null && listQueryIntentActivities.size() > 1) {
                    Iterator<ResolveInfo> it = listQueryIntentActivities.iterator();
                    while (it.hasNext()) {
                        ActivityInfo activityInfo = it.next().activityInfo;
                        if ("com.android.packageinstaller".equals(activityInfo.applicationInfo.packageName)) {
                            intent.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
                            break;
                        }
                    }
                }
                U.Zo().startActivity(intent);
                F.j6("Run app without root");
            }
        } catch (Throwable th) {
            if (f232DW) {
                wu.j6(th, -5404124222150917387L, this, str);
            }
            throw th;
        }
    }

    @su(method = 50355060517135400L)
    private void m166j6(boolean z, Runnable runnable, Runnable runnable2) {
        try {
            if (f233j6) {
                wu.j6(3154158015646723140L, this, new Boolean(z), runnable, runnable2);
            }
            if (!z) {
                runnable2.run();
                return;
            }
            if (!this.f235Hw) {
                this.f235Hw = true;
                new Thread((Runnable) new gk(this, runnable, runnable2)).start();
            } else if (this.f234FH) {
                runnable.run();
            } else {
                runnable2.run();
            }
        } catch (Throwable th) {
            if (f232DW) {
                wu.j6(th, 3154158015646723140L, this, new Boolean(z), runnable, runnable2);
            }
            throw th;
        }
    }

    public void m169j6(String str, String str2) {
        try {
            if (f233j6) {
                wu.j6(-112108143730738111L, this, str, str2);
            }
            U.gn().Ws();
            m166j6(U.U2().Zo() && aa.SI(), (Runnable) new dk(this, str, str2), (Runnable) new ek(this, str));
        } catch (Throwable th) {
            if (f232DW) {
                wu.j6(th, -112108143730738111L, this, str, str2);
            }
            throw th;
        }
    }
}
