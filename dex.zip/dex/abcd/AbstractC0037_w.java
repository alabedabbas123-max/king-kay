package abcd;

import java.io.Serializable;

public abstract class AbstractC0037_w implements Serializable {

    public final String f229DW;

    public final String f230j6;

    public AbstractC0037_w(String str, String str2) {
        if (str == null) {
            throw new IllegalArgumentException("'key' must be non-null");
        }
        if (str.contains("|")) {
            throw new IllegalArgumentException("'key' must not contain a \"|\" character: \"" + str + "\"");
        }
        if (str2 == null) {
            throw new IllegalArgumentException("'secret' must be non-null");
        }
        this.f230j6 = str;
        this.f229DW = str2;
    }

    public boolean equals(Object obj) {
        return (obj instanceof AbstractC0037_w) && m244j6((AbstractC0037_w) obj);
    }

    public int hashCode() {
        return this.f230j6.hashCode() ^ (this.f229DW.hashCode() << 1);
    }

    public boolean m244j6(AbstractC0037_w abstractC0037_w) {
        return this.f230j6.equals(abstractC0037_w.f230j6) && this.f229DW.equals(abstractC0037_w.f229DW);
    }

    public String toString() {
        return "{key=\"" + this.f230j6 + "\", secret=\"" + this.f229DW.charAt(0) + "...\"}";
    }
}
