package abcd;

import java.util.Arrays;

public abstract class AbstractC0080GK {

    public static final c f419j6 = new c(null);

    public static final a f417DW = new a();

    public static final b f418FH = new b();

    public static class a extends AbstractC0080GK {
        public String mo747j6(String str) {
            StringBuilder sb = new StringBuilder();
            sb.append('\'');
            int i = 0;
            int i2 = 0;
            while (i < str.length()) {
                char cCharAt = str.charAt(i);
                if (cCharAt == '!' || cCharAt == '\'') {
                    sb.append((CharSequence) str, i2, i);
                    sb.append('\'');
                    sb.append('\\');
                    sb.append(str.charAt(i));
                    sb.append('\'');
                    i2 = i + 1;
                }
                i++;
            }
            sb.append((CharSequence) str, i2, i);
            sb.append('\'');
            return sb.toString();
        }
    }

    public static class b extends a {
        @Override
        public String mo747j6(String str) {
            if (str.matches("^~[A-Za-z0-9_-]+$")) {
                return String.valueOf(str) + "/";
            }
            if (!str.matches("^~[A-Za-z0-9_-]*/.*$")) {
                return super.mo747j6(str);
            }
            int iIndexOf = str.indexOf(47) + 1;
            if (iIndexOf == str.length()) {
                return str;
            }
            return String.valueOf(str.substring(0, iIndexOf)) + super.mo747j6(str.substring(iIndexOf));
        }
    }

    public static final class c extends AbstractC0080GK {

        private static final byte[] f420Hw = new byte[128];

        static {
            Arrays.fill(f420Hw, (byte) -1);
            for (int i = 48; i <= 57; i++) {
                f420Hw[i] = 0;
            }
            for (int i2 = 97; i2 <= 122; i2++) {
                f420Hw[i2] = 0;
            }
            for (int i3 = 65; i3 <= 90; i3++) {
                f420Hw[i3] = 0;
            }
            byte[] bArr = f420Hw;
            bArr[32] = 0;
            bArr[36] = 0;
            bArr[37] = 0;
            bArr[38] = 0;
            bArr[42] = 0;
            bArr[43] = 0;
            bArr[44] = 0;
            bArr[45] = 0;
            bArr[46] = 0;
            bArr[47] = 0;
            bArr[58] = 0;
            bArr[59] = 0;
            bArr[61] = 0;
            bArr[63] = 0;
            bArr[64] = 0;
            bArr[95] = 0;
            bArr[94] = 0;
            bArr[124] = 0;
            bArr[126] = 0;
            bArr[7] = 97;
            bArr[8] = 98;
            bArr[12] = 102;
            bArr[10] = 110;
            bArr[13] = 114;
            bArr[9] = 116;
            bArr[11] = 118;
            bArr[92] = 92;
            bArr[34] = 34;
        }

        private c() {
        }

        c(c cVar) {
            this();
        }

        private static String m748DW(byte[] bArr, int i, int i2) {
            int i3;
            int i4;
            int i5;
            byte b;
            byte[] bArr2 = new byte[i2 - i];
            int i6 = 0;
            while (i < i2) {
                int i7 = i + 1;
                byte b2 = bArr[i];
                if (b2 != 92) {
                    i4 = i6 + 1;
                    bArr2[i6] = b2;
                    i = i7;
                } else {
                    if (i7 == i2) {
                        i3 = i6 + 1;
                        bArr2[i6] = 92;
                        return IK.j6(hE.Zo, bArr2, 0, i3);
                    }
                    i = i7 + 1;
                    byte b3 = bArr[i7];
                    if (b3 == 34 || b3 == 92) {
                        i5 = i6 + 1;
                        bArr2[i6] = bArr[i - 1];
                        i6 = i5;
                    } else {
                        if (b3 == 102) {
                            i5 = i6 + 1;
                            bArr2[i6] = 12;
                        } else if (b3 == 110) {
                            i5 = i6 + 1;
                            bArr2[i6] = 10;
                        } else if (b3 == 114) {
                            i5 = i6 + 1;
                            bArr2[i6] = 13;
                        } else if (b3 == 116) {
                            i5 = i6 + 1;
                            bArr2[i6] = 9;
                        } else if (b3 == 118) {
                            i5 = i6 + 1;
                            bArr2[i6] = 11;
                        } else if (b3 == 97) {
                            i5 = i6 + 1;
                            bArr2[i6] = 7;
                        } else if (b3 != 98) {
                            switch (b3) {
                                case 48:
                                case 49:
                                case 50:
                                case 51:
                                    int i8 = bArr[i - 1] - 48;
                                    for (int i9 = 1; i9 < 3 && i < i2 && 48 <= (b = bArr[i]) && b <= 55; i9++) {
                                        i8 = (i8 << 3) | (b - 48);
                                        i++;
                                    }
                                    i4 = i6 + 1;
                                    bArr2[i6] = (byte) i8;
                                    break;
                                default:
                                    int i10 = i6 + 1;
                                    bArr2[i6] = 92;
                                    i6 = i10 + 1;
                                    bArr2[i10] = bArr[i - 1];
                                    continue;
                            }
                        } else {
                            i5 = i6 + 1;
                            bArr2[i6] = 8;
                        }
                        i6 = i5;
                    }
                }
                i6 = i4;
            }
            i3 = i6;
            return IK.j6(hE.Zo, bArr2, 0, i3);
        }

        /* JADX WARN: Code duplicated, block: B:20:0x004a  */
        public String m749j6(String str) {
            if (str.length() == 0) {
                return "\"\"";
            }
            byte[] bArrJ6 = hE.j6(str);
            StringBuilder sb = new StringBuilder(bArrJ6.length + 2);
            sb.append('\"');
            boolean z = true;
            for (byte b : bArrJ6) {
                int i = b & 255;
                byte[] bArr = f420Hw;
                if (i >= bArr.length) {
                    sb.append('\\');
                    sb.append((char) (((i >> 6) & 3) + 48));
                    sb.append((char) (((i >> 3) & 7) + 48));
                    sb.append((char) (((i >> 0) & 7) + 48));
                    z = false;
                } else {
                    byte b2 = bArr[i];
                    if (b2 == 0) {
                        sb.append((char) i);
                    } else {
                        if (b2 > 0) {
                            sb.append('\\');
                            sb.append((char) b2);
                        } else {
                            sb.append('\\');
                            sb.append((char) (((i >> 6) & 3) + 48));
                            sb.append((char) (((i >> 3) & 7) + 48));
                            sb.append((char) (((i >> 0) & 7) + 48));
                        }
                        z = false;
                    }
                }
            }
            if (z) {
                return str;
            }
            sb.append('\"');
            return sb.toString();
        }

        public String m750j6(byte[] bArr, int i, int i2) {
            if (2 <= i2 - i && bArr[i] == 34) {
                int i3 = i2 - 1;
                if (bArr[i3] == 34) {
                    return m748DW(bArr, i + 1, i3);
                }
            }
            return IK.j6(hE.Zo, bArr, i, i2);
        }
    }
}
