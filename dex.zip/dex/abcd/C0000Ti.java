package abcd;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

@xu
public class C0000Ti {

    @uu
    private static boolean f0DW;

    @tu
    private static boolean f1j6;

    static {
        wu.j6(C0000Ti.class, 5954351271705613112L, 5954351271705613112L);
    }

    public C0000Ti() {
        try {
            if (f1j6) {
                wu.j6(-1661105084502740968L, (Object) null);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1661105084502740968L, (Object) null);
            }
            throw th;
        }
    }

    public static List<String> m0DW(String str, Map<String, List<String>> map) {
        try {
            if (f1j6) {
                wu.j6(-1931341203769167955L, (Object) null, str, map);
            }
            HashSet hashSet = new HashSet();
            ArrayList arrayList = new ArrayList();
            m3j6(str, map, hashSet, arrayList);
            return arrayList;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1931341203769167955L, (Object) null, str, map);
            }
            throw th;
        }
    }

    public static Map<String, List<String>> m1j6(String str, Map<String, List<String>> map) {
        try {
            if (f1j6) {
                wu.j6(-3252213030375534953L, (Object) null, str, map);
            }
            HashMap map2 = new HashMap();
            m2j6(str, map, map2);
            return map2;
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -3252213030375534953L, (Object) null, str, map);
            }
            throw th;
        }
    }

    @su(method = 1059576926652699336L)
    private static void m2j6(String str, Map<String, List<String>> map, Map<String, List<String>> map2) {
        try {
            if (f1j6) {
                wu.j6(-1739145866213029132L, (Object) null, str, map, map2);
            }
            if (map2.containsKey(str)) {
                return;
            }
            List<String> arrayList = map.get(str);
            if (arrayList == null) {
                arrayList = new ArrayList<>();
            }
            map2.put(str, arrayList);
            Iterator<String> it = arrayList.iterator();
            while (it.hasNext()) {
                m2j6(it.next(), map, map2);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -1739145866213029132L, (Object) null, str, map, map2);
            }
            throw th;
        }
    }

    @su(method = -2290371236549358953L)
    private static void m3j6(String str, Map<String, List<String>> map, Set<String> set, List<String> list) {
        try {
            if (f1j6) {
                wu.j6(-4855936115600225771L, (Object) null, str, map, set, list);
            }
            if (set.contains(str)) {
                return;
            }
            set.add(str);
            if (!list.contains(str)) {
                list.add(str);
            }
            Iterator<String> it = map.get(str).iterator();
            while (it.hasNext()) {
                m3j6(it.next(), map, set, list);
            }
        } catch (Throwable th) {
            if (f0DW) {
                wu.j6(th, -4855936115600225771L, (Object) null, str, map, set, list);
            }
            throw th;
        }
    }
}
