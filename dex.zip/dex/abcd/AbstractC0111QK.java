package abcd;

import java.util.TimeZone;

public abstract class AbstractC0111QK {

    static final boolean f528DW = false;

    private static AbstractC0111QK f529j6 = new C0068PK();

    public static AbstractC0111QK m667FH() {
        return f529j6;
    }

    public static void m668j6(AbstractC0111QK abstractC0111QK) {
        f529j6 = abstractC0111QK;
    }

    public abstract FG mo428DW(gE gEVar, pK pKVar);

    public abstract String mo429DW();

    public abstract String mo430DW(String str);

    public TimeZone m669Hw() {
        return TimeZone.getDefault();
    }

    public abstract int mo431j6(long j);

    public abstract long mo432j6();

    public abstract FG mo433j6(gE gEVar, pK pKVar);

    public abstract String mo434j6(String str);
}
