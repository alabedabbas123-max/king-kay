package abcd;

enum C0017vB extends AB.a {
    C0017vB(String str, int i) {
        super(str, i, (AB.a) null);
    }

    public boolean m77Hw() {
        return false;
    }
}
