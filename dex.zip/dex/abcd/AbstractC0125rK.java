package abcd;

import java.io.File;
import java.nio.charset.Charset;
import java.security.AccessController;
import java.util.ArrayList;
import java.util.Arrays;

abstract class AbstractC0125rK extends AbstractC0040pK {
    AbstractC0125rK() {
    }

    private static boolean m650gn() {
        return "Mac OS X".equals((String) AccessController.doPrivileged(new C0082qK()));
    }

    @Override
    protected File mo179DW() {
        String strM177j6;
        File parentFile;
        File fileM174DW = AbstractC0040pK.m174DW(QK.FH().DW("PATH"), "git");
        if (fileM174DW != null) {
            return fileM174DW.getParentFile().getParentFile();
        }
        if (!m650gn() || (strM177j6 = AbstractC0040pK.m177j6(m183Zo(), new String[]{"bash", "--login", "-c", "which git"}, Charset.defaultCharset().name())) == null || strM177j6.length() == 0 || (parentFile = new File(strM177j6).getParentFile()) == null) {
            return null;
        }
        return parentFile.getParentFile();
    }

    @Override
    public ProcessBuilder mo185j6(String str, String[] strArr) {
        ArrayList arrayList = new ArrayList(strArr.length + 4);
        arrayList.add("sh");
        arrayList.add("-c");
        arrayList.add(String.valueOf(str) + " \"$@\"");
        arrayList.add(str);
        arrayList.addAll(Arrays.asList(strArr));
        ProcessBuilder processBuilder = new ProcessBuilder(new String[0]);
        processBuilder.command(arrayList);
        return processBuilder;
    }
}
