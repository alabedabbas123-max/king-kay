package abcd;

@xu
public class Be$m extends Be$i {

    @uu
    private static boolean f487VH;

    @tu
    private static boolean f488Zo;

    public String f489gn;

    static {
        wu.j6(Be$m.class, -459771541640449581L, -459771541640449581L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$m(int i, String str) {
        super(i);
        try {
            if (f488Zo) {
                wu.j6(2398678632362552995L, (Object) null, new Integer(i), str);
            }
            this.f489gn = str;
        } catch (Throwable th) {
            if (f487VH) {
                wu.j6(th, 2398678632362552995L, (Object) null, new Integer(i), str);
            }
            throw th;
        }
    }

    public boolean equals(Object obj) {
        try {
            if (f488Zo) {
                wu.j6(38685007665744525L, this, obj);
            }
            if (obj instanceof Be$m) {
                return this.f489gn.equals(((Be$m) obj).f489gn);
            }
            return false;
        } catch (Throwable th) {
            if (f487VH) {
                wu.j6(th, 38685007665744525L, this, obj);
            }
            throw th;
        }
    }
}
