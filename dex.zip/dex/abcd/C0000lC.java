package abcd;

import abcd.CC;

public final class C0000lC<S extends CC> extends CC {

    final int[] f0DW;

    final S f1j6;

    C0000lC(S s, int[] iArr) {
        this.f1j6 = s;
        this.f0DW = iArr;
    }

    public int m0j6() {
        return this.f1j6.j6();
    }
}
