package abcd;

import com.aide.common.ab;

@xu
class C0002Tk implements ab<String> {

    @uu
    private static boolean f5DW;

    @tu
    private static boolean f6j6;

    @vu
    final Zk f7FH;

    static {
        wu.j6(C0002Tk.class, -8061245974084835088L, 759705135868991625L);
    }

    C0002Tk(Zk zk) {
        this.f7FH = zk;
    }

    @su(method = -577181437980655697L)
    public void m4j6(String str) {
        try {
            if (f6j6) {
                wu.j6(-714668744083132197L, this, str);
            }
            if (!"debug-aide".equals(Zk.j6(str)) || com.aide.ui.U.U2().j6(com.aide.ui.U.lg())) {
                this.f7FH.BT(str);
            }
        } catch (Throwable th) {
            if (f5DW) {
                wu.j6(th, -714668744083132197L, this, str);
            }
            throw th;
        }
    }
}
