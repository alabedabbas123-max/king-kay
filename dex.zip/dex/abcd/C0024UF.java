package abcd;

public class C0024UF extends OF {

    private OF.a f60Hw;

    private OF.a f61v5;

    public C0024UF() {
    }

    C0024UF(XF xf) {
        super(xf);
    }

    void m138DW(int i) {
        int i2 = i ^ (-1);
        for (OF.a aVar = this.f60Hw; aVar != null; aVar = aVar.j6) {
            for (int i3 = aVar.FH; i3 < aVar.Hw; i3++) {
                aVar.DW[i3].EQ &= i2;
            }
        }
    }

    public void m139DW(dG dGVar) {
        OF.a aVar = this.f60Hw;
        if (aVar == null) {
            OF.a aVarJ6 = ((OF) this).FH.j6();
            aVarJ6.VH();
            aVarJ6.j6(dGVar);
            this.f60Hw = aVarJ6;
            this.f61v5 = aVarJ6;
            return;
        }
        if (aVar.j6()) {
            aVar.DW(dGVar);
            return;
        }
        OF.a aVarJ7 = ((OF) this).FH.j6();
        aVarJ7.Zo();
        aVarJ7.DW(dGVar);
        aVarJ7.j6 = this.f60Hw;
        this.f60Hw = aVarJ7;
    }

    public dG m140j6() {
        OF.a aVar = this.f60Hw;
        if (aVar == null) {
            return null;
        }
        dG dGVarV5 = aVar.v5();
        if (aVar.FH()) {
            this.f60Hw = aVar.j6;
            if (this.f60Hw == null) {
                this.f61v5 = null;
            }
            ((OF) this).FH.j6(aVar);
        }
        return dGVarV5;
    }

    public void m141j6(dG dGVar) {
        OF.a aVarJ6 = this.f61v5;
        if (aVarJ6 == null) {
            OF.a aVarJ7 = ((OF) this).FH.j6();
            aVarJ7.j6(dGVar);
            this.f60Hw = aVarJ7;
            this.f61v5 = aVarJ7;
            return;
        }
        if (aVarJ6.Hw()) {
            aVarJ6 = ((OF) this).FH.j6();
            this.f61v5.j6 = aVarJ6;
            this.f61v5 = aVarJ6;
        }
        aVarJ6.j6(dGVar);
    }

    boolean m142j6(int i) {
        for (OF.a aVar = this.f60Hw; aVar != null; aVar = aVar.j6) {
            for (int i2 = aVar.FH; i2 < aVar.Hw; i2++) {
                if ((aVar.DW[i2].EQ & i) != 0) {
                    return true;
                }
            }
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (OF.a aVar = this.f60Hw; aVar != null; aVar = aVar.j6) {
            for (int i = aVar.FH; i < aVar.Hw; i++) {
                LF.j6(sb, aVar.DW[i]);
            }
        }
        return sb.toString();
    }
}
