package abcd;

public class C0017fG {

    public static final C0017fG f96j6 = new a("UNINTERESTING", 4);

    final qG f97DW;

    final String f98FH;

    final int f99Hw;

    static class a extends C0017fG {
        a(String str, int i) {
            super(null, str, i);
        }
    }

    C0017fG(qG qGVar, String str, int i) {
        this.f97DW = qGVar;
        this.f98FH = str;
        this.f99Hw = i;
    }

    public String toString() {
        return this.f98FH;
    }
}
