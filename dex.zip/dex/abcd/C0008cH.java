package abcd;

class C0008cH extends bH.b {

    final C0052dH.a f18FH;

    C0008cH(C0052dH.a aVar) {
        this.f18FH = aVar;
    }
}
