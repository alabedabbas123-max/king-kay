package abcd;

public class C0015iM extends EL implements KL {

    private byte[] f45j6;

    C0015iM(byte[] bArr) {
        this.f45j6 = bArr;
    }

    boolean m72Zo() {
        return false;
    }

    public String getString() {
        return TP.DW(this.f45j6);
    }

    public int hashCode() {
        return OP.DW(this.f45j6);
    }

    void m73j6(CL cl) {
        cl.j6(27, this.f45j6);
    }

    boolean m74j6(EL el) {
        if (el instanceof C0015iM) {
            return OP.j6(this.f45j6, ((C0015iM) el).f45j6);
        }
        return false;
    }

    public String toString() {
        return getString();
    }

    int m75v5() {
        return OM.j6(this.f45j6.length) + 1 + this.f45j6.length;
    }
}
