package abcd;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class C0022UD {

    private final List<C0065VD> f48j6;

    public enum a {
        NOT_IGNORED,
        IGNORED,
        CHECK_PARENT;

        public static a[] valuesCustom() {
            a[] aVarArrValuesCustom = values();
            int length = aVarArrValuesCustom.length;
            a[] aVarArr = new a[length];
            System.arraycopy(aVarArrValuesCustom, 0, aVarArr, 0, length);
            return aVarArr;
        }
    }

    public C0022UD() {
        this.f48j6 = new ArrayList();
    }

    public C0022UD(List<C0065VD> list) {
        this.f48j6 = list;
    }

    private static BufferedReader m88DW(InputStream inputStream) {
        return new BufferedReader(new InputStreamReader(inputStream, hE.Zo));
    }

    public a m89j6(String str, boolean z) {
        C0065VD c0065vd;
        if (this.f48j6.isEmpty()) {
            return a.CHECK_PARENT;
        }
        int size = this.f48j6.size();
        do {
            size--;
            if (size <= -1) {
                return a.CHECK_PARENT;
            }
            c0065vd = this.f48j6.get(size);
        } while (!c0065vd.m365j6(str, z));
        return c0065vd.m364j6() ? a.IGNORED : a.NOT_IGNORED;
    }

    public List<C0065VD> m90j6() {
        return Collections.unmodifiableList(this.f48j6);
    }

    public void m91j6(InputStream inputStream) throws IOException {
        BufferedReader bufferedReaderM88DW = m88DW(inputStream);
        while (true) {
            String line = bufferedReaderM88DW.readLine();
            if (line == null) {
                return;
            }
            String strTrim = line.trim();
            if (strTrim.length() > 0 && !strTrim.startsWith("#")) {
                this.f48j6.add(new C0065VD(strTrim));
            }
        }
    }
}
