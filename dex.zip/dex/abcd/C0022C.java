package abcd;

import android.os.Build;
import android.view.accessibility.AccessibilityRecord;

public class C0022C {

    private static final c f85j6;

    static class a extends c {
        a() {
        }

        @Override
        public void mo118DW(AccessibilityRecord accessibilityRecord, int i) {
            accessibilityRecord.setMaxScrollY(i);
        }

        @Override
        public void mo119j6(AccessibilityRecord accessibilityRecord, int i) {
            accessibilityRecord.setMaxScrollX(i);
        }
    }

    static class b extends a {
        b() {
        }
    }

    static class c {
        c() {
        }

        public void mo118DW(AccessibilityRecord accessibilityRecord, int i) {
        }

        public void mo119j6(AccessibilityRecord accessibilityRecord, int i) {
        }
    }

    static {
        int i = Build.VERSION.SDK_INT;
        if (i >= 16) {
            f85j6 = new b();
        } else if (i >= 15) {
            f85j6 = new a();
        } else {
            f85j6 = new c();
        }
    }

    public static void m116DW(AccessibilityRecord accessibilityRecord, int i) {
        f85j6.mo118DW(accessibilityRecord, i);
    }

    public static void m117j6(AccessibilityRecord accessibilityRecord, int i) {
        f85j6.mo119j6(accessibilityRecord, i);
    }
}
