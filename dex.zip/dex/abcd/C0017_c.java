package abcd;

import java.io.IOException;
import java.io.Reader;
import java.util.Stack;

@xu
public class C0017_c {

    @uu
    private static boolean f117DW;

    @tu
    private static boolean f118j6;

    @ru(field = 2185655573522842080L)
    private Kb f119EQ;

    @ru(field = -1274944753166766477L)
    private final La f120FH;

    @ru(field = -1379887973445208704L)
    private final Wc f121Hw;

    @ru(field = 2950923252298344000L)
    private sc f122J0;

    @ru(field = 904468633724424375L)
    private boolean f123J8;

    @ru(field = 7593648557367770656L)
    private C0105bc f124Mr;

    @ru(field = 1168964835758235360L)
    private int f125QX;

    @ru(field = 4322222562127244544L)
    private final int f126U2;

    @ru(field = -515696218427979123L)
    private Kb f127VH;

    @ru(field = 1835978810898461640L)
    private Da f128Ws;

    @ru(field = -981546643568891181L)
    private int f129XL;

    @ru(field = -2498300467354106976L)
    private final vc f130Zo;

    @ru(field = 3666947349170944524L)
    private final int f131a8;

    @ru(field = -2290593140938531800L)
    private Stack<Wa> f132aM;

    @ru(field = -214418488316655425L)
    private Kb f133gn;

    @ru(field = -3672978972624429975L)
    private Cb f134j3;

    @ru(field = 4852211851470981033L)
    private sc f135tp;

    @ru(field = 5715333578594550555L)
    private sc f136u7;

    @ru(field = 3186069684178241168L)
    private final Xc f137v5;

    @ru(field = 538281524243305744L)
    private Wa f138we;

    static {
        wu.j6(C0017_c.class, 1645658335839072429L, 1645658335839072429L);
    }

    public C0017_c(La la, Wc wc, Xc xc, vc vcVar) {
        try {
            if (f118j6) {
                wu.j6(-1980843366420964L, (Object) null, la, wc, xc, vcVar);
            }
            this.f127VH = new Kb();
            this.f133gn = new Kb();
            this.f119EQ = new Kb();
            this.f132aM = new Stack<>();
            this.f134j3 = new Cb();
            this.f124Mr = new C0105bc();
            this.f120FH = la;
            this.f121Hw = wc;
            this.f137v5 = xc;
            this.f130Zo = vcVar;
            this.f136u7 = new sc(la);
            this.f135tp = new sc(la);
            this.f126U2 = la.j3.j6("PUBLIC");
            this.f131a8 = la.j3.j6("SYSTEM");
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -1980843366420964L, (Object) null, la, wc, xc, vcVar);
            }
            throw th;
        }
    }

    @su(method = -698483007455698575L)
    private void m136DW() {
        try {
            if (f118j6) {
                wu.j6(-30818981803751712L, this);
            }
            while (true) {
                int i = this.f129XL;
                if (i != 10) {
                    switch (i) {
                        case 15:
                        case 16:
                        case 17:
                            break;
                        default:
                            return;
                    }
                }
                m138FH();
            }
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -30818981803751712L, this);
            }
            throw th;
        }
    }

    @su(method = -3540769546110442596L)
    private void m137DW(int i) {
        try {
            if (f118j6) {
                wu.j6(-2233162283488428645L, this, i);
            }
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -2233162283488428645L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = 3575175322468781120L)
    private void m138FH() {
        try {
            if (f118j6) {
                wu.j6(2871843084652504017L, this);
            }
            if (this.f129XL != 53) {
                this.f122J0.j6(this.f138we.v5[this.f125QX], this.f138we.VH[this.f125QX]);
                if (this.f137v5.v5().m391Zo(this.f129XL)) {
                    int i = this.f138we.Hw[this.f125QX];
                    this.f122J0.j6(this.f138we.u7, this.f138we.FH(i), this.f138we.DW(i));
                } else if (this.f137v5.v5().m409u7(this.f129XL)) {
                    this.f122J0.j6(this.f138we.Hw[this.f125QX]);
                } else {
                    this.f122J0.j6(this.f137v5.v5().getString(this.f129XL));
                }
            } else {
                this.f122J0.j6();
                this.f122J0.j6(' ');
            }
            m140VH();
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, 2871843084652504017L, this);
            }
            throw th;
        }
    }

    @su(method = 2160622699262751864L)
    private int m139Hw() {
        try {
            if (f118j6) {
                wu.j6(-2663329325226276121L, this);
            }
            return this.f138we.Hw[this.f125QX];
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -2663329325226276121L, this);
            }
            throw th;
        }
    }

    @su(method = 2165129093489588288L)
    private void m140VH() {
        try {
            if (f118j6) {
                wu.j6(-73803891699004359L, this);
            }
            this.f125QX++;
            if (this.f125QX < this.f138we.FH.length) {
                this.f129XL = this.f138we.FH[this.f125QX];
            }
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -73803891699004359L, this);
            }
            throw th;
        }
    }

    @su(method = 423204499124816772L)
    private boolean m141Zo() {
        try {
            if (f118j6) {
                wu.j6(2286973958722302935L, this);
            }
            return this.f125QX + 2 < this.f138we.FH.length && this.f138we.FH[this.f125QX] == 20 && this.f138we.FH[this.f125QX + 1] == 30;
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, 2286973958722302935L, this);
            }
            throw th;
        }
    }

    @su(method = -393117477212837685L)
    private void m142gn() {
        try {
            if (f118j6) {
                wu.j6(-54902336466370744L, this);
            }
            m138FH();
            m136DW();
            if (!m141Zo()) {
                if (this.f129XL == 45) {
                    m138FH();
                    m143j6();
                    return;
                }
                return;
            }
            int i = this.f138we.Hw[this.f125QX + 1];
            if (this.f127VH.DW(i) && this.f135tp.j6("IGNORE", this.f127VH.FH(i))) {
                this.f122J0.j6();
                this.f122J0.j6("IGNORE");
                m140VH();
                m140VH();
                m140VH();
                m143j6();
            }
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -54902336466370744L, this);
            }
            throw th;
        }
    }

    @su(method = -3867643441623534528L)
    private void m143j6() {
        try {
            if (f118j6) {
                wu.j6(-2867467889617733025L, this);
            }
            int i = 0;
            while (this.f129XL != 0) {
                int i2 = this.f129XL;
                if (i2 == 46) {
                    i++;
                    m138FH();
                } else if (i2 != 48) {
                    m138FH();
                } else if (i <= 0) {
                    return;
                } else {
                    i--;
                }
            }
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -2867467889617733025L, this);
            }
            throw th;
        }
    }

    @su(method = 1430572230969917952L)
    private void m144j6(int i) {
        try {
            if (f118j6) {
                wu.j6(1836832866615680263L, this, i);
            }
            m138FH();
            m136DW();
            m147tp();
            this.f119EQ.DW(i, this.f136u7.FH());
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, 1836832866615680263L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -2318981205003732959L)
    private void m145j6(Wa wa, Da da) {
        try {
            if (f118j6) {
                wu.j6(291918650772542080L, this, wa, da);
            }
            if (da != null) {
                if (this.f124Mr.m689j6(da.EQ())) {
                    return;
                } else {
                    this.f124Mr.m680DW(da.EQ());
                }
            }
            this.f132aM.push(wa);
            this.f134j3.FH(this.f125QX);
            this.f125QX = 0;
            this.f138we = wa;
            this.f129XL = this.f138we.FH[this.f125QX];
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, 291918650772542080L, this, wa, da);
            }
            throw th;
        }
    }

    @su(method = -30465325086594515L)
    private void m146j6(String str) {
        try {
            if (f118j6) {
                wu.j6(-1323242104035106908L, this, str);
            }
            if (this.f123J8) {
                this.f120FH.rN.DW(this.f128Ws, this.f137v5, this.f138we.v5[this.f125QX], this.f138we.VH[this.f125QX], this.f138we.Zo[this.f125QX], this.f138we.gn[this.f125QX], str, 0);
            }
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -1323242104035106908L, this, str);
            }
            throw th;
        }
    }

    @su(method = 173606057789017565L)
    private void m147tp() {
        try {
            if (f118j6) {
                wu.j6(-2388708786036301848L, this);
            }
            int i = this.f129XL;
            m138FH();
            this.f136u7.DW();
            while (this.f129XL != i) {
                switch (this.f129XL) {
                    case 27:
                        int iM139Hw = m139Hw();
                        this.f136u7.j6(this.f138we.u7, this.f138we.FH(iM139Hw), this.f138we.DW(iM139Hw));
                        m138FH();
                        break;
                    case 28:
                        if (!m149v5()) {
                            m138FH();
                        } else {
                            m140VH();
                            int iM139Hw2 = m139Hw();
                            if (this.f127VH.DW(iM139Hw2)) {
                                int iFH = this.f127VH.FH(iM139Hw2);
                                int iFH2 = this.f133gn.FH(iM139Hw2);
                                this.f136u7.j6(this.f135tp, iFH, iFH2);
                                this.f122J0.j6();
                                this.f122J0.j6(this.f135tp, iFH, iFH2);
                            } else {
                                m146j6("Unknown entity: " + this.f120FH.j3.j6(iM139Hw2));
                            }
                            m140VH();
                            m140VH();
                        }
                        break;
                    case 29:
                    case 31:
                        m138FH();
                        break;
                    case 30:
                    default:
                        return;
                }
            }
            m138FH();
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, -2388708786036301848L, this);
            }
            throw th;
        }
    }

    @su(method = 264975297347668943L)
    private void m148u7() {
        try {
            if (f118j6) {
                wu.j6(4598918972695297684L, this);
            }
            m138FH();
            m136DW();
            if (this.f129XL != 20) {
                return;
            }
            m138FH();
            m136DW();
            if (this.f129XL != 30) {
                return;
            }
            int iM139Hw = m139Hw();
            m138FH();
            m136DW();
            if (this.f127VH.DW(iM139Hw)) {
                return;
            }
            int i = this.f129XL;
            if (i == 18 || i == 19) {
                m147tp();
                int iV5 = this.f135tp.v5();
                int iV6 = this.f136u7.v5();
                this.f135tp.j6(this.f136u7);
                this.f127VH.DW(iM139Hw, iV5);
                this.f133gn.DW(iM139Hw, iV6);
                return;
            }
            if (i != 30) {
                return;
            }
            int iHw = this.f120FH.j3.Hw(m139Hw());
            if (iHw == this.f126U2) {
                m144j6(iM139Hw);
            } else if (iHw == this.f131a8) {
                m137DW(iM139Hw);
            }
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, 4598918972695297684L, this);
            }
            throw th;
        }
    }

    @su(method = 1852117768025086199L)
    private boolean m149v5() {
        try {
            if (f118j6) {
                wu.j6(1001224240193872440L, this);
            }
            return this.f125QX + 2 < this.f138we.FH.length && this.f138we.FH[this.f125QX] == 28 && this.f138we.FH[this.f125QX + 1] == 31;
        } catch (Throwable th) {
            if (f117DW) {
                wu.j6(th, 1001224240193872440L, this);
            }
            throw th;
        }
    }

    public void m150j6(Da da, Wa wa, sc scVar, boolean z) throws Throwable {
        try {
            if (f118j6) {
                wu.j6(7542143445228125952L, this, da, wa, scVar, new Boolean(z));
            }
            this.f122J0 = scVar;
            this.f123J8 = z;
            this.f128Ws = da;
            try {
                m145j6(wa, da);
                this.f127VH.j6();
                this.f133gn.j6();
                this.f135tp.DW();
                this.f119EQ.j6();
                while (true) {
                    int i = this.f129XL;
                    if (i == 0) {
                        if (this.f132aM.size() <= 1) {
                            break;
                        }
                        this.f132aM.pop();
                        this.f125QX = this.f134j3.FH();
                        this.f138we = this.f132aM.peek();
                        m140VH();
                        if (this.f129XL == 21) {
                            m140VH();
                        }
                    } else if (i == 11) {
                        m148u7();
                    } else if (i != 20) {
                        if (i != 28) {
                            if (i != 46) {
                                m138FH();
                            } else {
                                m142gn();
                            }
                        } else if (m149v5()) {
                            m140VH();
                            int iM139Hw = m139Hw();
                            if (this.f127VH.DW(iM139Hw)) {
                                int iFH = this.f127VH.FH(iM139Hw);
                                int iFH2 = this.f133gn.FH(iM139Hw);
                                scVar.j6();
                                scVar.j6(this.f135tp, iFH, iFH2);
                            } else {
                                m146j6("Unknown entity: " + this.f120FH.j3.j6(iM139Hw));
                            }
                            m140VH();
                            if (this.f129XL == 29) {
                                m140VH();
                            }
                        } else {
                            m138FH();
                        }
                    } else if (m141Zo()) {
                        m140VH();
                        int iM139Hw2 = m139Hw();
                        if (this.f127VH.DW(iM139Hw2)) {
                            int iFH3 = this.f127VH.FH(iM139Hw2);
                            int iFH4 = this.f133gn.FH(iM139Hw2);
                            scVar.j6();
                            scVar.j6(' ');
                            scVar.j6(this.f135tp, iFH3, iFH4);
                            scVar.j6(' ');
                        } else if (this.f119EQ.DW(iM139Hw2)) {
                            try {
                                int iFH5 = this.f119EQ.FH(iM139Hw2);
                                Reader readerV5 = this.f121Hw.v5(this.f120FH.j3.j6(iFH5));
                                Da daFH = this.f121Hw.FH(this.f120FH.j3.j6(iFH5));
                                if (readerV5 != null) {
                                    Wa waJ6 = this.f120FH.er.j6();
                                    this.f130Zo.j6(daFH, readerV5, false, true, waJ6, true, Integer.MAX_VALUE);
                                    m145j6(waJ6, daFH);
                                } else {
                                    m146j6("Public entity not found: " + this.f120FH.j3.j6(iFH5));
                                }
                            } catch (IOException unused) {
                            }
                        } else {
                            m146j6("Unknown entity: " + this.f120FH.j3.j6(iM139Hw2));
                        }
                        m140VH();
                        if (this.f129XL == 21) {
                            m140VH();
                        }
                    } else {
                        m138FH();
                    }
                }
                this.f138we = null;
                this.f122J0 = null;
                this.f128Ws = null;
                while (this.f132aM.size() > 1) {
                    this.f120FH.er.j6(this.f132aM.pop());
                }
                this.f132aM.setSize(0);
                this.f134j3.v5(0);
                this.f124Mr.m687j6();
            } catch (Throwable th) {
                th = th;
                if (f117DW) {
                    wu.j6(th, 7542143445228125952L, this, da, wa, scVar, new Boolean(z));
                }
                throw th;
            }
        } catch (Throwable th2) {
            th = th2;
        }
    }
}
