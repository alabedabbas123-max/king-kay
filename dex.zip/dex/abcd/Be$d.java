package abcd;

@xu
public class Be$d extends Be$b {

    @uu
    private static boolean f454VH;

    @tu
    private static boolean f455Zo;

    public String f456gn;

    public String f457u7;

    static {
        wu.j6(Be$d.class, -623531114526608755L, -623531114526608755L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$d(int i) {
        super(i);
        try {
            if (f455Zo) {
                wu.j6(-2516510158544292485L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f454VH) {
                wu.j6(th, -2516510158544292485L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }

    public String m1278j6(String str) {
        try {
            if (f455Zo) {
                wu.j6(2517891740060147048L, this, str);
            }
            if (this.f456gn == null) {
                return null;
            }
            return Vl.VH(str, this.f456gn);
        } catch (Throwable th) {
            if (f454VH) {
                wu.j6(th, 2517891740060147048L, this, str);
            }
            throw th;
        }
    }
}
