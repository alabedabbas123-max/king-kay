package abcd;

import com.aide.common.u;
import com.aide.ui.U;
import java.util.Arrays;
import java.util.List;

@xu
public class C0002Kg implements Zl, am, Hl {

    @uu
    private static boolean f4DW;

    @tu
    private static boolean f5j6;

    static {
        wu.j6(C0002Kg.class, -1125690028135099520L, -1125690028135099520L);
    }

    public C0002Kg() {
        try {
            if (f5j6) {
                wu.j6(-2638462132660542075L, (Object) null);
            }
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, -2638462132660542075L, (Object) null);
            }
            throw th;
        }
    }

    public String m5DW() {
        try {
            if (f5j6) {
                wu.j6(629406644637682615L, this);
            }
            if (U.dx()) {
                return U.SI().we();
            }
            return null;
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, 629406644637682615L, this);
            }
            throw th;
        }
    }

    public u m6FH() {
        try {
            if (f5j6) {
                wu.j6(-6894358151434349013L, this);
            }
            return new u(33, false, true, false);
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, -6894358151434349013L, this);
            }
            throw th;
        }
    }

    public List<u> m7Hw() {
        try {
            if (f5j6) {
                wu.j6(556447499286812773L, this);
            }
            return Arrays.asList(new u(99, false, false, false), new u(85, false, false, false));
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, 556447499286812773L, this);
            }
            throw th;
        }
    }

    public int m8VH() {
        try {
            if (f5j6) {
                wu.j6(897958784390176188L, this);
            }
            return m9j6();
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, 897958784390176188L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f5j6) {
                return "Run";
            }
            wu.j6(-1702832135242633248L, this);
            return "Run";
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, -1702832135242633248L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f5j6) {
                wu.j6(-2542090874942896328L, this);
            }
            if (U.dx() || !U.gn().tp()) {
                return U.vy().FH();
            }
            return true;
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, -2542090874942896328L, this);
            }
            throw th;
        }
    }

    public boolean isVisible() {
        try {
            if (!f5j6) {
                return true;
            }
            wu.j6(-2665797303696077493L, this);
            return true;
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, -2665797303696077493L, this);
            }
            throw th;
        }
    }

    public int m9j6() {
        try {
            if (!f5j6) {
                return com.aide.pro.R.id.mainMenuRun;
            }
            wu.j6(1863889511366854400L, this);
            return com.aide.pro.R.id.mainMenuRun;
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, 1863889511366854400L, this);
            }
            throw th;
        }
    }

    public boolean m10run() {
        try {
            if (f5j6) {
                wu.j6(-1310977944150341376L, this);
            }
            if (U.dx()) {
                U.SI().BT();
                return true;
            }
            if (U.gn().tp()) {
                U.gn().J8();
                return true;
            }
            U.vy().j6(false);
            return true;
        } catch (Throwable th) {
            if (f4DW) {
                wu.j6(th, -1310977944150341376L, this);
            }
            throw th;
        }
    }
}
