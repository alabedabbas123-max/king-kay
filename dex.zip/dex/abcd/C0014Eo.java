package abcd;

import java.util.BitSet;

public final class C0014Eo extends ao {

    public static final ao f138DW = new C0014Eo();

    private C0014Eo() {
    }

    public BitSet m243FH(Vn vn) {
        cs csVarGn = vn.gn();
        BitSet bitSet = new BitSet(2);
        bitSet.set(0, ao.v5(csVarGn.get(0).we()));
        bitSet.set(1, ao.v5(csVarGn.get(1).we()));
        return bitSet;
    }

    public boolean m244VH(Vn vn) {
        cs csVarGn = vn.gn();
        if (!(vn instanceof Tn) || csVarGn.size() != 2 || !ao.v5(csVarGn.get(0).we()) || !ao.v5(csVarGn.get(1).we())) {
            return false;
        }
        Ds dsWe = ((Tn) vn).we();
        if (!(dsWe instanceof Ds)) {
            return false;
        }
        Ds ds = dsWe;
        return ds.J8() && ao.FH(ds.Ws());
    }

    public String m245Zo(Vn vn) {
        cs csVarGn = vn.gn();
        return csVarGn.get(0).lg() + ", " + csVarGn.get(1).lg() + ", " + ao.j6(((Tn) vn).we());
    }

    public int m246j6() {
        return 2;
    }

    public String m247j6(Vn vn, boolean z) {
        return ao.j6(((Tn) vn).we(), 16);
    }

    public void m248j6(Lt lt, Vn vn) {
        cs csVarGn = vn.gn();
        ao.j6(lt, ao.j6(vn, ao.DW(csVarGn.get(0).we(), csVarGn.get(1).we())), (short) ((Tn) vn).we().Ws());
    }
}
