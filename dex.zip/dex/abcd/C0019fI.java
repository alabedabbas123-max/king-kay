package abcd;

class C0019fI implements b<eI.b> {
    C0019fI() {
    }

    public eI.b m69j6(C0059gE c0059gE) {
        return new eI.b(c0059gE);
    }
}
