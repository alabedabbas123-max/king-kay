package abcd;

import com.aide.common.ab;
import com.aide.ui.U;

@xu
class C0006Eg implements ab<String> {

    @uu
    private static boolean f104DW;

    @tu
    private static boolean f105j6;

    final String f106FH;

    @vu
    final C0049Fg f107Hw;

    static {
        wu.j6(C0006Eg.class, 641597747308316425L, 1098255753979043376L);
    }

    C0006Eg(C0049Fg c0049Fg, String str) {
        this.f107Hw = c0049Fg;
        this.f106FH = str;
    }

    @su(method = 6300118483691882733L)
    public void m192j6(String str) {
        try {
            if (f105j6) {
                wu.j6(-951774649037688024L, this, str);
            }
            U.lg().cb();
            U.EQ().j6(this.f106FH, str);
        } catch (Throwable th) {
            if (f104DW) {
                wu.j6(th, -951774649037688024L, this, str);
            }
            throw th;
        }
    }
}
