package abcd;

public class C0020XO implements qO {

    private byte[] f75j6;

    public C0020XO(byte[] bArr) {
        this(bArr, 0, bArr.length);
    }

    public C0020XO(byte[] bArr, int i, int i2) {
        this.f75j6 = new byte[i2];
        System.arraycopy(bArr, i, this.f75j6, 0, i2);
    }

    public byte[] m108j6() {
        return this.f75j6;
    }
}
