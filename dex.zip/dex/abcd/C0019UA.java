package abcd;

enum C0019UA extends C0105WA.a {
    C0019UA(String str, int i) {
        super(str, i, null);
    }

    @Override
    public String toString() {
        return "Failed";
    }
}
