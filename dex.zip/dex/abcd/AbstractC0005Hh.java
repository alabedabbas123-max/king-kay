package abcd;

import android.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.aide.common.ma;

@xu
public abstract class AbstractC0005Hh extends ma {

    @uu
    private static boolean f79VH;

    @tu
    private static boolean f80Zo;

    @ru(field = 541996511108614871L)
    private AlertDialog f81gn;

    static {
        wu.j6(AbstractC0005Hh.class, 1036993532042931165L, 1036993532042931165L);
    }

    public AbstractC0005Hh() {
        try {
            if (f80Zo) {
                wu.j6(4072164298204361624L, (Object) null);
            }
        } catch (Throwable th) {
            if (f79VH) {
                wu.j6(th, 4072164298204361624L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = 2254871941261464476L)
    private ProgressBar m130DW(AlertDialog alertDialog) {
        try {
            if (f80Zo) {
                wu.j6(-3708215645801724120L, this, alertDialog);
            }
            return (ProgressBar) alertDialog.findViewById(com.aide.pro.R.id.progressdialogProgress);
        } catch (Throwable th) {
            if (f79VH) {
                wu.j6(th, -3708215645801724120L, this, alertDialog);
            }
            throw th;
        }
    }

    @su(method = 661178770536766288L)
    private TextView m131j6(AlertDialog alertDialog) {
        try {
            if (f80Zo) {
                wu.j6(-33907395936756600L, this, alertDialog);
            }
            return (TextView) alertDialog.findViewById(com.aide.pro.R.id.progressdialogLabel);
        } catch (Throwable th) {
            if (f79VH) {
                wu.j6(th, -33907395936756600L, this, alertDialog);
            }
            throw th;
        }
    }

    protected abstract String m132EQ();

    protected abstract void m133J0();

    @su(method = -6169156859712083020L)
    protected void m134J8() {
        try {
            if (f80Zo) {
                wu.j6(4801251501855156192L, this);
            }
            if (!m136Ws()) {
                this.f81gn.dismiss();
                return;
            }
            int iM138gn = m138gn();
            int iM141u7 = m141u7();
            String strM140tp = m140tp();
            if (iM141u7 > 0 && iM141u7 < 100) {
                strM140tp = strM140tp + " (" + iM141u7 + "%)";
            }
            m130DW(this.f81gn).setProgress(iM138gn);
            m130DW(this.f81gn).setSecondaryProgress(iM141u7);
            m131j6(this.f81gn).setText(strM140tp);
            this.f81gn.setTitle(m132EQ());
        } catch (Throwable th) {
            if (f79VH) {
                wu.j6(th, 4801251501855156192L, this);
            }
            throw th;
        }
    }

    public void m135VH() {
        try {
            if (f80Zo) {
                wu.j6(1335807209470220700L, this);
            }
            this.f81gn.dismiss();
        } catch (Throwable th) {
            if (f79VH) {
                wu.j6(th, 1335807209470220700L, this);
            }
            throw th;
        }
    }

    protected abstract boolean m136Ws();

    protected abstract void m137Zo();

    protected abstract int m138gn();

    @su(method = 3142682422207548855L)
    protected Dialog m139j6(Activity activity) {
        try {
            if (f80Zo) {
                wu.j6(-1649244012632306243L, this, activity);
            }
            View viewInflate = LayoutInflater.from(activity).inflate(com.aide.pro.R.layout.progressdialog, (ViewGroup) null);
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            builder.setTitle(m132EQ()).setView(viewInflate).setCancelable(true).setPositiveButton(com.aide.pro.R.string.dialog_bt_hide, (DialogInterface.OnClickListener) new Dh(this));
            if (m142v5()) {
                builder.setNegativeButton(R.string.cancel, (DialogInterface.OnClickListener) new Eh(this));
            }
            this.f81gn = builder.create();
            this.f81gn.setOnDismissListener(new Fh(this));
            m143we();
            this.f81gn.setOnShowListener(new Gh(this));
            this.f81gn.getWindow().addFlags(128);
            return this.f81gn;
        } catch (Throwable th) {
            if (f79VH) {
                wu.j6(th, -1649244012632306243L, this, activity);
            }
            throw th;
        }
    }

    protected abstract String m140tp();

    protected abstract int m141u7();

    protected abstract boolean m142v5();

    protected abstract void m143we();
}
