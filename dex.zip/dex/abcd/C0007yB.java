package abcd;

enum C0007yB extends AB.a {
    C0007yB(String str, int i) {
        super(str, i, (AB.a) null);
    }

    public boolean m21Hw() {
        return true;
    }
}
