package abcd;

@xu
public class Be$h extends Be$b {

    @uu
    private static boolean f471VH;

    @tu
    private static boolean f472Zo;

    public String f473gn;

    static {
        wu.j6(Be$h.class, -42401395434935228L, -42401395434935228L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$h(int i) {
        super(i);
        try {
            if (f472Zo) {
                wu.j6(2601114563630301444L, (Object) null, i);
            }
        } catch (Throwable th) {
            if (f471VH) {
                wu.j6(th, 2601114563630301444L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }

    public String m1281j6(String str, Je je) {
        try {
            if (f472Zo) {
                wu.j6(-7178238830550564140L, this, str, je);
            }
            return je.j6(str, this.f473gn);
        } catch (Throwable th) {
            if (f471VH) {
                wu.j6(th, -7178238830550564140L, this, str, je);
            }
            throw th;
        }
    }
}
