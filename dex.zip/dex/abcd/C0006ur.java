package abcd;

class C0006ur implements b<qq> {

    final C0134xr f15j6;

    C0006ur(C0134xr c0134xr) {
        this.f15j6 = c0134xr;
    }

    public void m37j6(hr.a aVar, qq qqVar) {
        qqVar.j6(aVar);
    }
}
