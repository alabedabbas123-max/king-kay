package abcd;

class C0022Ew extends Rw<Dw.e> {
    C0022Ew() {
    }
}
