package abcd;

public abstract class AbstractC0100Ds extends Ms {
    public abstract boolean mo65J8();

    public boolean m634VH() {
        if (!mo65J8()) {
            return false;
        }
        int iMo66Ws = mo66Ws();
        return ((short) iMo66Ws) == iMo66Ws;
    }

    public abstract int mo66Ws();

    public abstract long mo67lg();

    public boolean m635we() {
        if (!mo65J8()) {
            return false;
        }
        int iMo66Ws = mo66Ws();
        return ((byte) iMo66Ws) == iMo66Ws;
    }
}
