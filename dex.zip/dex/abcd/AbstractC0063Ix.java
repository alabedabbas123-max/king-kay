package abcd;

abstract class AbstractC0063Ix {

    private static final Throwable[] f429j6 = new Throwable[0];

    AbstractC0063Ix() {
    }

    public abstract void mo223j6(Throwable th, Throwable th2);
}
