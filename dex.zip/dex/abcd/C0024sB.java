package abcd;

import java.io.IOException;
import java.net.URISyntaxException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import org.eclipse.jgit.JGitText;

public class C0024sB extends GB<C0024sB, Iterable<NI>> {

    private boolean f53EQ;

    private final List<WI> f54VH;

    private String f55Zo;

    private LE f56gn;

    private boolean f57tp;

    private String f58u7;

    private boolean f59we;

    protected C0024sB(UE ue) {
        super(ue);
        this.f55Zo = "origin";
        this.f56gn = vE.j6;
        this.f58u7 = "git-receive-pack";
        this.f59we = false;
        this.f54VH = new ArrayList(3);
    }

    public String m179Hw() {
        return this.f55Zo;
    }

    public Iterable<NI> m957call() throws SB, RB {
        ME meJ6;
        j6();
        ArrayList arrayList = new ArrayList(3);
        try {
            if (this.f54VH.isEmpty()) {
                this.f54VH.addAll(new XI(((dB) this).j6.Zo(), m179Hw()).FH());
            }
            if (this.f54VH.isEmpty() && (meJ6 = ((dB) this).j6.j6("HEAD")) != null && meJ6.Zo()) {
                this.f54VH.add(new WI(meJ6.v5().getName()));
            }
            if (this.f53EQ) {
                for (int i = 0; i < this.f54VH.size(); i++) {
                    this.f54VH.set(i, this.f54VH.get(i).j6(true));
                }
            }
            for (jJ jJVar : jJ.DW(((dB) this).j6, this.f55Zo, jJ.a.DW)) {
                jJVar.Hw(this.f59we);
                if (this.f58u7 != null) {
                    jJVar.j6(this.f58u7);
                }
                jJVar.DW(this.f57tp);
                j6(jJVar);
                try {
                    try {
                        arrayList.add(jJVar.DW(this.f56gn, jJVar.j6(this.f54VH)));
                        jJVar.DW();
                    } catch (yD e) {
                        throw new SB(JGitText.j6().exceptionCaughtDuringExecutionOfPushCommand, e);
                    }
                } catch (Throwable th) {
                    jJVar.DW();
                    throw th;
                }
            }
            return arrayList;
        } catch (IOException e2) {
            throw new SB(JGitText.j6().exceptionCaughtDuringExecutionOfPushCommand, e2);
        } catch (URISyntaxException unused) {
            throw new RB(MessageFormat.format(JGitText.j6().invalidRemote, this.f55Zo));
        } catch (jD e3) {
            throw new SB(JGitText.j6().exceptionCaughtDuringExecutionOfPushCommand, e3);
        }
    }

    public C0024sB m180j6(LE le) {
        j6();
        this.f56gn = le;
        return this;
    }
}
