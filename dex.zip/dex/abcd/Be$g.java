package abcd;

@xu
public class Be$g extends Be$b {

    @uu
    private static boolean f464VH;

    @tu
    private static boolean f465Zo;

    public String f466EQ;

    public String f467gn;

    public String f468tp;

    public String f469u7;

    public String f470we;

    static {
        wu.j6(Be$g.class, -2008949414407267840L, -2008949414407267840L);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$g(int i) {
        super(i);
        try {
            if (f465Zo) {
                wu.j6(-4980028418955078155L, (Object) null, i);
            }
            this.f467gn = "";
            this.f469u7 = "";
            this.f468tp = "+";
            this.f466EQ = "";
        } catch (Throwable th) {
            if (f464VH) {
                wu.j6(th, -4980028418955078155L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Be$g(Be$g be$g, String str) {
        super(be$g.f463FH);
        try {
            if (f465Zo) {
                wu.j6(-1295578929449820525L, (Object) null, be$g, str);
            }
            this.f467gn = "";
            this.f469u7 = "";
            this.f468tp = "+";
            this.f466EQ = "";
            this.f468tp = str;
            this.f467gn = be$g.f467gn;
            this.f469u7 = be$g.f469u7;
            this.f466EQ = be$g.f466EQ;
        } catch (Throwable th) {
            if (f464VH) {
                wu.j6(th, -1295578929449820525L, (Object) null, be$g, str);
            }
            throw th;
        }
    }

    public boolean equals(Object obj) {
        try {
            if (f465Zo) {
                wu.j6(-219591331431235680L, this, obj);
            }
            if (!(obj instanceof Be$g)) {
                return false;
            }
            Be$g be$g = (Be$g) obj;
            return be$g.f467gn.equals(this.f467gn) && be$g.f469u7.equals(this.f469u7) && be$g.f468tp.equals(this.f468tp) && be$g.f466EQ.equals(this.f466EQ);
        } catch (Throwable th) {
            if (f464VH) {
                wu.j6(th, -219591331431235680L, this, obj);
            }
            throw th;
        }
    }

    public int hashCode() {
        try {
            if (f465Zo) {
                wu.j6(1062998868325404097L, this);
            }
            return this.f467gn.hashCode() + this.f469u7.hashCode();
        } catch (Throwable th) {
            if (f464VH) {
                wu.j6(th, 1062998868325404097L, this);
            }
            throw th;
        }
    }

    public String m1280j6() {
        try {
            if (f465Zo) {
                wu.j6(-1506372577483390727L, this);
            }
            return this.f467gn + ":" + this.f469u7;
        } catch (Throwable th) {
            if (f464VH) {
                wu.j6(th, -1506372577483390727L, this);
            }
            throw th;
        }
    }

    public String toString() {
        try {
            if (f465Zo) {
                wu.j6(1872211631215363680L, this);
            }
            return this.f467gn + ":" + this.f469u7 + ":" + this.f468tp;
        } catch (Throwable th) {
            if (f464VH) {
                wu.j6(th, 1872211631215363680L, this);
            }
            throw th;
        }
    }
}
