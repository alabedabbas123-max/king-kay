package abcd;

public final class C0000Qm extends Xt {

    public static final C0000Qm f0FH = new C0000Qm(0);

    public static class a {

        private final int f1DW;

        private final Js f2FH;

        private final Js f3Hw;

        private final int f4Zo;

        private final int f5j6;

        private final Js f6v5;

        public a(int i, int i2, Js js, Js js2, Js js3, int i3) {
            if (i < 0) {
                throw new IllegalArgumentException("startPc < 0");
            }
            if (i2 < 0) {
                throw new IllegalArgumentException("length < 0");
            }
            if (js == null) {
                throw new NullPointerException("name == null");
            }
            if (js2 == null && js3 == null) {
                throw new NullPointerException("(descriptor == null) && (signature == null)");
            }
            if (i3 < 0) {
                throw new IllegalArgumentException("index < 0");
            }
            this.f5j6 = i;
            this.f1DW = i2;
            this.f2FH = js;
            this.f3Hw = js2;
            this.f6v5 = js3;
            this.f4Zo = i3;
        }

        public Js m7FH() {
            return this.f6v5;
        }

        public C0006Qs m9DW() {
            return C0006Qs.m44j6(this.f3Hw.we());
        }

        public boolean m10DW(a aVar) {
            return this.f5j6 == aVar.f5j6 && this.f1DW == aVar.f1DW && this.f4Zo == aVar.f4Zo && this.f2FH.equals(aVar.f2FH);
        }

        public a m11j6(Js js) {
            return new a(this.f5j6, this.f1DW, this.f2FH, this.f3Hw, js, this.f4Zo);
        }

        public Vr m12j6() {
            return Vr.j6(this.f2FH, this.f6v5);
        }

        public boolean m13j6(int i, int i2) {
            int i3;
            return i2 == this.f4Zo && i >= (i3 = this.f5j6) && i < i3 + this.f1DW;
        }
    }

    public C0000Qm(int i) {
        super(i);
    }

    public static C0000Qm m0DW(C0000Qm c0000Qm, C0000Qm c0000Qm2) {
        int size = c0000Qm.size();
        C0000Qm c0000Qm3 = new C0000Qm(size);
        for (int i = 0; i < size; i++) {
            a aVarM2get = c0000Qm.m2get(i);
            a aVarM4j6 = c0000Qm2.m4j6(aVarM2get);
            if (aVarM4j6 != null) {
                aVarM2get = aVarM2get.m11j6(aVarM4j6.m7FH());
            }
            c0000Qm3.m6j6(i, aVarM2get);
        }
        c0000Qm3.we();
        return c0000Qm3;
    }

    public static C0000Qm m1j6(C0000Qm c0000Qm, C0000Qm c0000Qm2) {
        if (c0000Qm == f0FH) {
            return c0000Qm2;
        }
        int size = c0000Qm.size();
        int size2 = c0000Qm2.size();
        C0000Qm c0000Qm3 = new C0000Qm(size + size2);
        for (int i = 0; i < size; i++) {
            c0000Qm3.m6j6(i, c0000Qm.m2get(i));
        }
        for (int i2 = 0; i2 < size2; i2++) {
            c0000Qm3.m6j6(size + i2, c0000Qm2.m2get(i2));
        }
        c0000Qm3.we();
        return c0000Qm3;
    }

    public a m2get(int i) {
        return (a) DW(i);
    }

    public a m3j6(int i, int i2) {
        int size = size();
        for (int i3 = 0; i3 < size; i3++) {
            a aVar = (a) DW(i3);
            if (aVar != null && aVar.m13j6(i, i2)) {
                return aVar;
            }
        }
        return null;
    }

    public a m4j6(a aVar) {
        int size = size();
        for (int i = 0; i < size; i++) {
            a aVar2 = (a) DW(i);
            if (aVar2 != null && aVar2.m10DW(aVar)) {
                return aVar2;
            }
        }
        return null;
    }

    public void m5j6(int i, int i2, int i3, Js js, Js js2, Js js3, int i4) {
        j6(i, new a(i2, i3, js, js2, js3, i4));
    }

    public void m6j6(int i, a aVar) {
        if (aVar == null) {
            throw new NullPointerException("item == null");
        }
        j6(i, aVar);
    }
}
