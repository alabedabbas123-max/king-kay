package abcd;

import com.jcraft.jsch.Session;
import com.jcraft.jsch.UIKeyboardInteractive;
import com.jcraft.jsch.UserInfo;
import java.util.ArrayList;
import java.util.Arrays;

public class C0006lI implements UserInfo, UIKeyboardInteractive {

    private final kI f16DW;

    private String f17FH;

    private String f18Hw;

    private final HJ f19j6;

    public C0006lI(Session session, kI kIVar) {
        this.f19j6 = m15j6(session);
        this.f16DW = kIVar;
    }

    private static HJ m15j6(Session session) {
        return new HJ().Hw("ssh").v5(session.u7()).j6(session.DW()).j6(session.v5());
    }

    private jI.d m16v5(String str) {
        return new jI.d(str, true);
    }

    public void m17DW(String str) {
        this.f16DW.j6(this.f19j6, new jI[]{new jI.b(str)});
    }

    public boolean m18FH(String str) {
        jI jIVarM16v5 = m16v5(str);
        if (this.f16DW.j6(this.f19j6, new jI[]{jIVarM16v5})) {
            this.f18Hw = jIVarM16v5.DW();
            return true;
        }
        this.f18Hw = null;
        return false;
    }

    public boolean m19Hw(String str) {
        jI fVar = new jI.f(str);
        return this.f16DW.j6(this.f19j6, new jI[]{fVar}) && fVar.DW();
    }

    public String getPassword() {
        return this.f17FH;
    }

    public String m20j6() {
        return this.f18Hw;
    }

    public boolean m21j6(String str) {
        jI cVar = new jI.c(str);
        if (this.f16DW.j6(this.f19j6, new jI[]{cVar})) {
            this.f17FH = new String(cVar.FH());
            return true;
        }
        this.f17FH = null;
        return false;
    }

    public String[] m22j6(String str, String str2, String str3, String[] strArr, boolean[] zArr) {
        jI.d[] dVarArr = new jI.d[strArr.length];
        for (int i = 0; i < strArr.length; i++) {
            dVarArr[i] = new jI.d(strArr[i], !zArr[i]);
        }
        ArrayList arrayList = new ArrayList();
        if (str3 != null && str3.length() > 0) {
            arrayList.add(new jI.b(str3));
        }
        arrayList.addAll(Arrays.asList(dVarArr));
        if (!this.f16DW.j6(this.f19j6, arrayList)) {
            return null;
        }
        String[] strArr2 = new String[dVarArr.length];
        for (int i2 = 0; i2 < dVarArr.length; i2++) {
            strArr2[i2] = dVarArr[i2].DW();
        }
        return strArr2;
    }
}
