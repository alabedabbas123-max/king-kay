package abcd;

@xu
public abstract class Be$f {

    @uu
    private static boolean f461DW;

    @tu
    private static boolean f462j6;

    public final int f463FH;

    static {
        wu.j6(Be$f.class, 4084750446085420179L, 4084750446085420179L);
    }

    public Be$f(int i) {
        try {
            if (f462j6) {
                wu.j6(-2993961079286589840L, (Object) null, i);
            }
            this.f463FH = i;
        } catch (Throwable th) {
            if (f461DW) {
                wu.j6(th, -2993961079286589840L, (Object) null, new Integer(i));
            }
            throw th;
        }
    }
}
