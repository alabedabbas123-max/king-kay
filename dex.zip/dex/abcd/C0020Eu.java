package abcd;

import com.appfour.backbone.api.closures.OnMarketClosure;
import com.appfour.backbone.api.objects.EventData;
import com.appfour.backbone.api.objects.Market;

class C0020Eu implements jv {

    final Iu f145DW;

    final OnMarketClosure f146j6;

    C0020Eu(Iu iu, OnMarketClosure onMarketClosure) {
        this.f145DW = iu;
        this.f146j6 = onMarketClosure;
    }

    public EventData m257j6(Object[] objArr) {
        return this.f146j6.getValue((Market) objArr[0]);
    }
}
