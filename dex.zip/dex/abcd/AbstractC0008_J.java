package abcd;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CharsetEncoder;
import java.security.MessageDigest;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0008_J extends TJ {

    private static int[] f43J0;

    private static int[] f44J8;

    private static int[] f45Ws;

    private int f49Mr;

    private final b f50QX;

    private int f51U2;

    private byte[] f52XL;

    private UD f53a8;

    private int f54aM;

    private a[] f55j3;

    protected UE f56lg;

    protected static final a[] f47u7 = new a[0];

    private static final byte[] f46tp = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57};

    private static final byte[] f42EQ = hE.j6(3);

    private static final Comparator<a> f48we = new ZJ();

    protected static abstract class a {

        int f57DW;

        byte[] f58j6;

        protected a() {
        }

        public abstract long m94DW();

        public abstract rE m95FH();

        public abstract String m96Hw();

        public abstract long m97j6();

        void m98j6(CharsetEncoder charsetEncoder) {
            try {
                ByteBuffer byteBufferEncode = charsetEncoder.encode(CharBuffer.wrap(m96Hw()));
                this.f57DW = byteBufferEncode.limit();
                if (byteBufferEncode.hasArray() && byteBufferEncode.arrayOffset() == 0) {
                    this.f58j6 = byteBufferEncode.array();
                    return;
                }
                byte[] bArr = new byte[this.f57DW];
                this.f58j6 = bArr;
                byteBufferEncode.get(bArr);
            } catch (CharacterCodingException unused) {
                throw new RuntimeException(MessageFormat.format(JGitText.j6().unencodeableFile, m96Hw()));
            }
        }

        public String toString() {
            return String.valueOf(m95FH().toString()) + " " + m96Hw();
        }

        public abstract InputStream m99v5();
    }

    private static final class b {

        final CharsetEncoder f59DW = hE.Zo.newEncoder();

        MessageDigest f60FH;

        byte[] f61Hw;

        int f62Zo;

        final C0096bK f63j6;

        YJ f64v5;

        b(C0096bK c0096bK) {
            this.f63j6 = c0096bK;
        }

        void m100j6() {
            if (this.f60FH == null) {
                this.f60FH = hE.j6();
                this.f61Hw = new byte[2048];
            }
        }
    }

    public enum c {
        EQUAL,
        DIFFER_BY_METADATA,
        SMUDGED,
        DIFFER_BY_TIMESTAMP;

        public static c[] valuesCustom() {
            c[] cVarArrValuesCustom = values();
            int length = cVarArrValuesCustom.length;
            c[] cVarArr = new c[length];
            System.arraycopy(cVarArrValuesCustom, 0, cVarArr, 0, length);
            return cVarArr;
        }
    }

    private static class d extends UD {

        final a f70DW;

        d(a aVar) {
            super(Collections.emptyList());
            this.f70DW = aVar;
        }

        UD mo101DW() throws IOException {
            UD ud = new UD();
            InputStream inputStreamM99v5 = this.f70DW.m99v5();
            try {
                ud.j6(inputStreamM99v5);
                inputStreamM99v5.close();
                if (ud.j6().isEmpty()) {
                    return null;
                }
                return ud;
            } catch (Throwable th) {
                inputStreamM99v5.close();
                throw th;
            }
        }
    }

    private static class e extends d {

        final UE f71FH;

        e(a aVar, UE ue) {
            super(aVar);
            this.f71FH = ue;
        }

        private void m102j6(UD ud, File file) throws IOException {
            if (file.exists()) {
                FileInputStream fileInputStream = new FileInputStream(file);
                try {
                    ud.j6(fileInputStream);
                } finally {
                    fileInputStream.close();
                }
            }
        }

        @Override
        UD mo101DW() throws IOException {
            UD ud;
            if (this.f70DW == null || (ud = super.mo101DW()) == null) {
                ud = new UD();
            }
            pK pKVarGn = this.f71FH.gn();
            String strDW = ((jE) this.f71FH.Zo().j6(jE.j6)).DW();
            if (strDW != null) {
                m102j6(ud, strDW.startsWith("~/") ? pKVarGn.j6(pKVarGn.Zo(), strDW.substring(2)) : pKVarGn.j6((File) null, strDW));
            }
            m102j6(ud, pKVarGn.j6(this.f71FH.VH(), "info/exclude"));
            if (ud.j6().isEmpty()) {
                return null;
            }
            return ud;
        }
    }

    protected AbstractC0008_J(AbstractC0008_J abstractC0008_J) {
        super(abstractC0008_J);
        this.f50QX = abstractC0008_J.f50QX;
    }

    protected AbstractC0008_J(C0096bK c0096bK) {
        this.f50QX = new b(c0096bK);
    }

    static int m56DW(a aVar) {
        return aVar.m95FH() == rE.j6 ? 47 : 0;
    }

    private InputStream m57DW(InputStream inputStream) {
        return new UK(inputStream);
    }

    private boolean m58DW(QC qc) {
        if (!v5().DW(qc.Hw())) {
            return true;
        }
        qc.j6((int) m83j3());
        return false;
    }

    private boolean m59DW(byte[] bArr, int i) {
        return tC.j6(bArr, i);
    }

    private static void m60FH(InputStream inputStream) {
        try {
            inputStream.close();
        } catch (IOException unused) {
        }
    }

    private byte[] m61FH(a aVar) {
        try {
            InputStream inputStreamM99v5 = aVar.m99v5();
            if (inputStreamM99v5 == null) {
                return TJ.j6;
            }
            try {
                this.f50QX.m100j6();
                long jM94DW = aVar.m94DW();
                if (!m71rN()) {
                    byte[] bArrM69j6 = m69j6(inputStreamM99v5, jM94DW);
                    m60FH(inputStreamM99v5);
                    return bArrM69j6;
                }
                if (jM94DW <= 65536) {
                    ByteBuffer byteBufferJ6 = BK.j6(inputStreamM99v5, (int) jM94DW);
                    byte[] bArrArray = byteBufferJ6.array();
                    int iLimit = byteBufferJ6.limit();
                    if (!m59DW(bArrArray, iLimit)) {
                        ByteBuffer byteBufferM68j6 = m68j6(bArrArray, iLimit);
                        bArrArray = byteBufferM68j6.array();
                        iLimit = byteBufferM68j6.limit();
                    }
                    byte[] bArrM69j7 = m69j6(new ByteArrayInputStream(bArrArray, 0, iLimit), iLimit);
                    m60FH(inputStreamM99v5);
                    return bArrM69j7;
                }
                if (m62Hw(aVar)) {
                    byte[] bArrM69j8 = m69j6(inputStreamM99v5, jM94DW);
                    m60FH(inputStreamM99v5);
                    return bArrM69j8;
                }
                InputStream inputStreamM57DW = m57DW(aVar.m99v5());
                try {
                    long jM67j6 = m67j6(inputStreamM57DW);
                    m60FH(inputStreamM57DW);
                    byte[] bArrM69j9 = m69j6(m57DW(inputStreamM99v5), jM67j6);
                    m60FH(inputStreamM99v5);
                    return bArrM69j9;
                } catch (Throwable th) {
                    m60FH(inputStreamM57DW);
                    throw th;
                }
            } catch (Throwable th2) {
                m60FH(inputStreamM99v5);
                throw th2;
            }
        } catch (IOException unused) {
            return TJ.j6;
        }
    }

    private boolean m62Hw(a aVar) {
        InputStream inputStreamM99v5 = aVar.m99v5();
        try {
            return tC.j6(inputStreamM99v5);
        } finally {
            m60FH(inputStreamM99v5);
        }
    }

    static int[] m63J8() {
        int[] iArr = f44J8;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[UD.a.values().length];
        try {
            iArr2[UD.a.FH.ordinal()] = 3;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[UD.a.DW.ordinal()] = 2;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[UD.a.j6.ordinal()] = 1;
        } catch (NoSuchFieldError unused3) {
        }
        f44J8 = iArr2;
        return iArr2;
    }

    static int[] m64QX() {
        int[] iArr = f45Ws;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[c.valuesCustom().length];
        try {
            iArr2[c.DIFFER_BY_METADATA.ordinal()] = 2;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[c.DIFFER_BY_TIMESTAMP.ordinal()] = 4;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[c.EQUAL.ordinal()] = 1;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[c.SMUDGED.ordinal()] = 3;
        } catch (NoSuchFieldError unused4) {
        }
        f45Ws = iArr2;
        return iArr2;
    }

    static int[] m65Ws() {
        int[] iArr = f43J0;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[jE.a.values().length];
        try {
            iArr2[jE.a.j6.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[jE.a.FH.ordinal()] = 3;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[jE.a.DW.ordinal()] = 2;
        } catch (NoSuchFieldError unused3) {
        }
        f43J0 = iArr2;
        return iArr2;
    }

    private void m66er() {
        a aVar = this.f55j3[this.f51U2];
        ((TJ) this).v5 = aVar.m95FH().DW();
        int i = aVar.f57DW;
        int i2 = ((TJ) this).VH;
        j6(i2 + i, i2);
        System.arraycopy(aVar.f58j6, 0, ((TJ) this).Zo, ((TJ) this).VH, i);
        ((TJ) this).gn = ((TJ) this).VH + i;
    }

    private long m67j6(InputStream inputStream) throws IOException {
        long j = 0;
        while (true) {
            long jSkip = inputStream.skip(1048576L);
            if (jSkip <= 0) {
                return j;
            }
            j += jSkip;
        }
    }

    private ByteBuffer m68j6(byte[] bArr, int i) {
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);
        try {
            return BK.j6(m57DW(byteArrayInputStream), i);
        } finally {
            m60FH(byteArrayInputStream);
        }
    }

    private byte[] m69j6(InputStream inputStream, long j) throws IOException {
        long j2;
        b bVar = this.f50QX;
        MessageDigest messageDigest = bVar.f60FH;
        byte[] bArr = bVar.f61Hw;
        messageDigest.reset();
        messageDigest.update(f42EQ);
        messageDigest.update((byte) 32);
        if (j == 0) {
            messageDigest.update((byte) 48);
            j2 = j;
        } else {
            int length = bArr.length;
            j2 = j;
            int i = length;
            do {
                i--;
                bArr[i] = f46tp[(int) (j2 % 10)];
                j2 /= 10;
            } while (j2 > 0);
            messageDigest.update(bArr, i, length - i);
        }
        messageDigest.update((byte) 0);
        while (true) {
            int i2 = inputStream.read(bArr);
            if (i2 <= 0) {
                break;
            }
            messageDigest.update(bArr, 0, i2);
            j2 += (long) i2;
        }
        return j2 != j ? TJ.j6 : messageDigest.digest();
    }

    private UD m70lg() {
        UD ud = this.f53a8;
        if (ud instanceof d) {
            this.f53a8 = ((d) ud).mo101DW();
        }
        return this.f53a8;
    }

    private boolean m71rN() {
        int i = m65Ws()[m77Mr().m666j6().ordinal()];
        return i == 2 || i == 3;
    }

    public boolean m72DW() {
        return this.f51U2 == this.f49Mr;
    }

    public void m73EQ() {
        if (m75FH()) {
            return;
        }
        this.f51U2 = 0;
        if (m72DW()) {
            return;
        }
        m66er();
    }

    public void m74FH(int i) {
        this.f51U2 += i;
        if (m72DW()) {
            return;
        }
        m66er();
    }

    public boolean m75FH() {
        return this.f51U2 == 0;
    }

    protected boolean m76Hw(int i) {
        UD udM70lg = m70lg();
        if (udM70lg != null) {
            int i2 = ((TJ) this).VH;
            if (i2 > 0) {
                i2--;
            }
            int i3 = m63J8()[udM70lg.j6(YJ.j6(((TJ) this).Zo, i2, i), rE.j6.j6(((TJ) this).v5)).ordinal()];
            if (i3 == 1) {
                return false;
            }
            if (i3 == 2) {
                return true;
            }
        }
        TJ tj = ((TJ) this).DW;
        if (tj instanceof AbstractC0008_J) {
            return ((AbstractC0008_J) tj).m76Hw(i);
        }
        return false;
    }

    public C0096bK m77Mr() {
        return this.f50QX.f63j6;
    }

    public boolean m78U2() {
        return m76Hw(((TJ) this).gn);
    }

    protected a m79XL() {
        return this.f55j3[this.f51U2];
    }

    public InputStream m80a8() {
        InputStream inputStreamM99v5 = m79XL().m99v5();
        return m77Mr().m666j6() != jE.a.j6 ? new UK(inputStreamM99v5) : inputStreamM99v5;
    }

    public long m81aM() {
        return m79XL().m97j6();
    }

    public boolean m82gn() {
        return this.f54aM == this.f51U2 || (((TJ) this).v5 & 61440) == 32768;
    }

    public long m83j3() {
        return m79XL().m94DW();
    }

    public c m84j6(QC qc) {
        if (qc.tp()) {
            return c.EQUAL;
        }
        if (qc.J8()) {
            return c.DIFFER_BY_METADATA;
        }
        if (!qc.J0() && m83j3() != qc.FH()) {
            return c.DIFFER_BY_METADATA;
        }
        int iVH = VH() ^ qc.Zo();
        if (iVH != 0 && !rE.DW.j6(qc.Zo())) {
            if (!this.f50QX.f63j6.m665DW()) {
                iVH &= rE.Hw.DW() ^ (-1);
            }
            if (iVH != 0) {
                return c.DIFFER_BY_METADATA;
            }
        }
        long jDW = qc.DW();
        long jM81aM = m81aM();
        if (jDW % 1000 == 0) {
            jM81aM -= jM81aM % 1000;
        }
        if (jM81aM != jDW) {
            return c.DIFFER_BY_TIMESTAMP;
        }
        return !qc.J0() ? c.EQUAL : c.SMUDGED;
    }

    public rE m85j6(RC rc) {
        rE rEVarHw = Hw();
        if (rc == null || m77Mr().m665DW()) {
            return rEVarHw;
        }
        rE rEVarHw2 = rc.Hw();
        if (rE.FH == rEVarHw && rE.Hw == rEVarHw2) {
            return rEVarHw2;
        }
        return (rE.Hw == rEVarHw && rE.FH == rEVarHw2) ? rEVarHw2 : rEVarHw;
    }

    public void m86j6(int i) {
        this.f51U2 -= i;
        m66er();
    }

    protected void m87j6(UE ue) {
        this.f56lg = ue;
        UD ud = this.f53a8;
        this.f53a8 = new e(ud instanceof d ? ((d) ud).f70DW : null, ue);
    }

    protected void m88j6(a[] aVarArr) {
        a[] aVarArr2;
        this.f55j3 = aVarArr;
        CharsetEncoder charsetEncoder = this.f50QX.f59DW;
        int i = 0;
        int i2 = 0;
        while (true) {
            aVarArr2 = this.f55j3;
            if (i >= aVarArr2.length) {
                break;
            }
            a aVar = aVarArr2[i];
            if (aVar != null) {
                String strM96Hw = aVar.m96Hw();
                if (!".".equals(strM96Hw) && !"..".equals(strM96Hw) && !".git".equals(strM96Hw)) {
                    if (".gitignore".equals(strM96Hw)) {
                        this.f53a8 = new d(aVar);
                    }
                    if (i != i2) {
                        this.f55j3[i2] = aVar;
                    }
                    aVar.m98j6(charsetEncoder);
                    i2++;
                }
            }
            i++;
        }
        this.f49Mr = i2;
        Arrays.sort(aVarArr2, 0, this.f49Mr, f48we);
        this.f54aM = -1;
        this.f51U2 = 0;
        if (m72DW()) {
            return;
        }
        m66er();
    }

    public boolean m89j6(QC qc, boolean z) {
        c cVarM84j6 = m84j6(qc);
        int i = m64QX()[cVarM84j6.ordinal()];
        if (i == 1) {
            return false;
        }
        if (i == 2) {
            return true;
        }
        if (i == 3) {
            return m58DW(qc);
        }
        if (i != 4) {
            throw new IllegalStateException(MessageFormat.format(JGitText.j6().unexpectedCompareResult, cVarM84j6.name()));
        }
        if (z) {
            return m58DW(qc);
        }
        return true;
    }

    protected byte[] m90j6(a aVar) {
        UE ue = this.f56lg;
        if (ue == null) {
            return TJ.j6;
        }
        try {
            return m91j6(ue.J8(), aVar);
        } catch (iD unused) {
            return TJ.j6;
        }
    }

    protected byte[] m91j6(File file, a aVar) {
        try {
            UE ueJ6 = YH.j6(file, aVar.m96Hw());
            try {
                if (ueJ6 == null) {
                    return TJ.j6;
                }
                try {
                    yE yEVarFH = ueJ6.FH("HEAD");
                    ueJ6.j6();
                    if (yEVarFH == null) {
                        return TJ.j6;
                    }
                    byte[] bArr = new byte[20];
                    yEVarFH.DW(bArr, 0);
                    return bArr;
                } catch (IOException unused) {
                    byte[] bArr2 = TJ.j6;
                    ueJ6.j6();
                    return bArr2;
                }
            } catch (Throwable th) {
                ueJ6.j6();
                throw th;
            }
        } catch (IOException unused2) {
            return TJ.j6;
        }
    }

    public int m92tp() {
        return 0;
    }

    public byte[] m93u7() {
        RC rcJ6;
        QC qcJ8;
        if (this.f54aM == this.f51U2) {
            return this.f52XL;
        }
        b bVar = this.f50QX;
        YJ yj = bVar.f64v5;
        if (yj != null && (rcJ6 = yj.j6(bVar.f62Zo, RC.class)) != null && (qcJ8 = rcJ6.J8()) != null && m84j6(qcJ8) == c.EQUAL) {
            return rcJ6.u7();
        }
        int i = ((TJ) this).v5 & 61440;
        if (i == 32768) {
            int i2 = this.f51U2;
            this.f54aM = i2;
            byte[] bArrM61FH = m61FH(this.f55j3[i2]);
            this.f52XL = bArrM61FH;
            return bArrM61FH;
        }
        if (i != 40960 && i == 57344) {
            int i3 = this.f51U2;
            this.f54aM = i3;
            byte[] bArrM90j6 = m90j6(this.f55j3[i3]);
            this.f52XL = bArrM90j6;
            return bArrM90j6;
        }
        return TJ.j6;
    }
}
