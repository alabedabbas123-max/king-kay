package abcd;

public class C0004Wz {

    public final String f14DW;

    public final String f15FH;

    public final String f16Hw;

    public final Uz f17VH;

    public final boolean f18Zo;

    public final String f19j6;

    public final String f20v5;

    public C0004Wz(String str, String str2, String str3, String str4, String str5, boolean z, Uz uz) {
        this.f19j6 = str;
        this.f14DW = str2;
        this.f15FH = str3;
        this.f16Hw = str4;
        this.f20v5 = str5;
        this.f18Zo = z;
        this.f17VH = uz;
    }
}
