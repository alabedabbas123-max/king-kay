package abcd;

import java.io.IOException;

public class C0018Kw extends Jw {
    public C0018Kw(IOException iOException) {
        super(iOException);
    }

    public C0018Kw(String str) {
        super(str);
    }
}
