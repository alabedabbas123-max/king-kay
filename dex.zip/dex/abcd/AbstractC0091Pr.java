package abcd;

public abstract class AbstractC0091Pr extends Tr {

    private final ms f421v5;

    public AbstractC0091Pr(es esVar, hs hsVar, bs bsVar, cs csVar, ms msVar) {
        super(esVar, hsVar, bsVar, csVar);
        if (msVar == null) {
            throw new NullPointerException("cst == null");
        }
        this.f421v5 = msVar;
    }

    public String m535FH() {
        return this.f421v5.aM();
    }

    public boolean m536j6(Tr tr) {
        return super.j6(tr) && this.f421v5.equals(((AbstractC0091Pr) tr).m537tp());
    }

    public ms m537tp() {
        return this.f421v5;
    }
}
