package abcd;

import android.app.Activity;
import com.appfour.backbone.api.closures.OnActivityClosure;
import com.appfour.backbone.api.objects.EventData;

class C0010uv implements jv {

    final Bv f18DW;

    final OnActivityClosure f19j6;

    C0010uv(Bv bv, OnActivityClosure onActivityClosure) {
        this.f18DW = bv;
        this.f19j6 = onActivityClosure;
    }

    public EventData m50j6(Object[] objArr) {
        return this.f19j6.getValue((Activity) objArr[0]);
    }
}
