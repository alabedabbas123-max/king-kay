package abcd;

public abstract class AbstractC0041iv extends Iu {
}
