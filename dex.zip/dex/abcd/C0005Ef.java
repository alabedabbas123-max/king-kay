package abcd;

import com.aide.common.u;
import com.aide.ui.U;

@xu
public class C0005Ef implements Yl, Wl {

    @uu
    private static boolean f102DW;

    @tu
    private static boolean f103j6;

    static {
        wu.j6(C0005Ef.class, 1383477999349039455L, 1383477999349039455L);
    }

    public C0005Ef() {
        try {
            if (f103j6) {
                wu.j6(-5257108180500863505L, (Object) null);
            }
        } catch (Throwable th) {
            if (f102DW) {
                wu.j6(th, -5257108180500863505L, (Object) null);
            }
            throw th;
        }
    }

    public u m189FH() {
        try {
            if (f103j6) {
                wu.j6(-1833314099865848040L, this);
            }
            return new u(41, true, true, false);
        } catch (Throwable th) {
            if (f102DW) {
                wu.j6(th, -1833314099865848040L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f103j6) {
                return "Extract Method";
            }
            wu.j6(1646496174255303267L, this);
            return "Extract Method";
        } catch (Throwable th) {
            if (f102DW) {
                wu.j6(th, 1646496174255303267L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f103j6) {
                wu.j6(-1886567579053952517L, this);
            }
            return U.er().VH() && U.er().gn();
        } catch (Throwable th) {
            if (f102DW) {
                wu.j6(th, -1886567579053952517L, this);
            }
            throw th;
        }
    }

    public int m190j6() {
        try {
            if (!f103j6) {
                return com.aide.pro.R.id.editorMenuExtractMethod;
            }
            wu.j6(-1919099203794918167L, this);
            return com.aide.pro.R.id.editorMenuExtractMethod;
        } catch (Throwable th) {
            if (f102DW) {
                wu.j6(th, -1919099203794918167L, this);
            }
            throw th;
        }
    }

    public boolean m191run() {
        try {
            if (f103j6) {
                wu.j6(-582816060370787339L, this);
            }
            Tl currentFileSpan = U.lg().J8().getCurrentFileSpan();
            U.lg().cb();
            U.EQ().Hw(currentFileSpan.FH, currentFileSpan.Hw, currentFileSpan.v5, currentFileSpan.Zo, currentFileSpan.VH);
            return true;
        } catch (Throwable th) {
            if (f102DW) {
                wu.j6(th, -582816060370787339L, this);
            }
            throw th;
        }
    }
}
