package abcd;

abstract class AbstractC0011XF {
    AbstractC0011XF() {
    }

    abstract int mo38DW();

    abstract dG mo39j6();

    void m40j6(OF of) {
    }
}
