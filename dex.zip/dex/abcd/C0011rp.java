package abcd;

public final class C0011rp extends up {
    public wp m132Hw() {
        return wp.j6;
    }

    public int m133VH() {
        return 112;
    }

    public void m134j6(jp jpVar) {
    }

    public void m135j6(jp jpVar, Lt lt) {
        int iFH = jpVar.u7().FH();
        Kp kpVH = jpVar.VH();
        Kp kpGn = jpVar.gn();
        int iFH2 = kpVH.FH();
        int iFH3 = (kpGn.FH() + kpGn.u7()) - iFH2;
        String strDW = jpVar.Hw().DW();
        if (lt.Hw()) {
            lt.j6(8, "magic: " + new Js(strDW).lg());
            lt.j6(4, "checksum");
            lt.j6(20, "signature");
            lt.j6(4, "file_size:       " + Yt.gn(jpVar.Zo()));
            lt.j6(4, "header_size:     " + Yt.gn(112));
            lt.j6(4, "endian_tag:      " + Yt.gn(305419896));
            lt.j6(4, "link_size:       0");
            lt.j6(4, "link_off:        0");
            lt.j6(4, "map_off:         " + Yt.gn(iFH));
        }
        for (int i = 0; i < 8; i++) {
            lt.writeByte(strDW.charAt(i));
        }
        lt.j6(24);
        lt.writeInt(jpVar.Zo());
        lt.writeInt(112);
        lt.writeInt(305419896);
        lt.j6(8);
        lt.writeInt(iFH);
        jpVar.J8().Hw(lt);
        jpVar.Ws().Hw(lt);
        jpVar.EQ().Hw(lt);
        jpVar.v5().Hw(lt);
        jpVar.tp().Hw(lt);
        jpVar.FH().Hw(lt);
        if (lt.Hw()) {
            lt.j6(4, "data_size:       " + Yt.gn(iFH3));
            lt.j6(4, "data_off:        " + Yt.gn(iFH2));
        }
        lt.writeInt(iFH3);
        lt.writeInt(iFH2);
    }
}
