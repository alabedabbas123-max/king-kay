package abcd;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.LinkedList;

public class C0012cL extends InputStream {

    private static final InputStream f37j6 = new bL();

    private final LinkedList<InputStream> f38DW = new LinkedList<>();

    public C0012cL(InputStream... inputStreamArr) {
        for (InputStream inputStream : inputStreamArr) {
            m67j6(inputStream);
        }
    }

    private void m65DW() throws IOException {
        if (this.f38DW.isEmpty()) {
            return;
        }
        this.f38DW.removeFirst().close();
    }

    private InputStream m66j6() {
        return this.f38DW.isEmpty() ? f37j6 : this.f38DW.getFirst();
    }

    @Override
    public int available() {
        return m66j6().available();
    }

    @Override
    public void close() throws IOException {
        Iterator<InputStream> it = this.f38DW.iterator();
        IOException e = null;
        while (it.hasNext()) {
            try {
                it.next().close();
            } catch (IOException e2) {
                e = e2;
            }
            it.remove();
        }
        if (e != null) {
            throw e;
        }
    }

    public void m67j6(InputStream inputStream) {
        this.f38DW.add(inputStream);
    }

    @Override
    public int read() throws IOException {
        while (true) {
            InputStream inputStreamM66j6 = m66j6();
            int i = inputStreamM66j6.read();
            if (i >= 0) {
                return i;
            }
            if (inputStreamM66j6 == f37j6) {
                return -1;
            }
            m65DW();
        }
    }

    @Override
    public int read(byte[] bArr, int i, int i2) throws IOException {
        int i3 = 0;
        while (i2 > 0) {
            InputStream inputStreamM66j6 = m66j6();
            int i4 = inputStreamM66j6.read(bArr, i, i2);
            if (i4 > 0) {
                i3 += i4;
                i += i4;
                i2 -= i4;
            } else {
                if (inputStreamM66j6 == f37j6) {
                    if (i3 > 0) {
                        return i3;
                    }
                    return -1;
                }
                m65DW();
                if (i3 > 0) {
                    break;
                }
            }
        }
        return i3;
    }

    @Override
    public long skip(long j) throws IOException {
        long j2 = 0;
        while (0 < j) {
            InputStream inputStreamM66j6 = m66j6();
            long jSkip = inputStreamM66j6.skip(j);
            if (0 < jSkip) {
                j2 += jSkip;
                j -= jSkip;
            } else {
                if (inputStreamM66j6 == f37j6) {
                    return j2;
                }
                if (inputStreamM66j6.read() < 0) {
                    m65DW();
                    if (0 < j2) {
                        break;
                    }
                } else {
                    j2++;
                    j--;
                }
            }
        }
        return j2;
    }
}
