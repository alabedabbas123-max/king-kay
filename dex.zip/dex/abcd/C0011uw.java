package abcd;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

public class C0011uw {

    private static final Object f20j6 = new Object();

    private static File m51DW(Context context) {
        return Build.VERSION.SDK_INT >= 21 ? new File(context.getNoBackupFilesDir(), "backbone") : new File(context.getApplicationInfo().dataDir, "no_backup/backbone");
    }

    public static File m52DW(Context context, String str) {
        try {
            String[] strArrSplit = new URL(str).getPath().split("/");
            if (strArrSplit.length > 3 && strArrSplit[3].length() > 0) {
                return new File(m54j6(context, "gone"), strArrSplit[3]);
            }
        } catch (MalformedURLException unused) {
        }
        return null;
    }

    public static File m53j6(Context context) {
        return m55j6(m51DW(context));
    }

    public static File m54j6(Context context, String str) {
        return m55j6(new File(m51DW(context), str));
    }

    private static File m55j6(File file) {
        if (!file.exists()) {
            synchronized (f20j6) {
                if (!file.exists() && !file.mkdirs()) {
                    if (file.exists()) {
                        return file;
                    }
                    return null;
                }
            }
        }
        return file;
    }
}
