package abcd;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

@xu
public class C0004Ee {

    @uu
    private static boolean f97DW;

    @tu
    private static boolean f98j6;

    @ru(field = 3003502387776948915L)
    private String f99FH;

    @ru(field = -5583085517110231568L)
    private String f100Hw;

    @ru(field = -292713482430978744L)
    private String f101v5;

    static {
        wu.j6(C0004Ee.class, -4676194136961233940L, -4676194136961233940L);
    }

    public C0004Ee() {
        try {
            if (f98j6) {
                wu.j6(-741736953874149152L, (Object) null);
            }
            this.f99FH = "\t";
            this.f100Hw = "\n";
            this.f101v5 = "UTF8";
        } catch (Throwable th) {
            if (f97DW) {
                wu.j6(th, -741736953874149152L, (Object) null);
            }
            throw th;
        }
    }

    @su(method = -13854452591126141L)
    private void m185j6(Writer writer, String str) {
        try {
            if (f98j6) {
                wu.j6(4104005874890906376L, this, writer, str);
            }
            if (str == null) {
                return;
            }
            int length = str.length();
            for (int i = 0; i < length; i++) {
                char cCharAt = str.charAt(i);
                if (cCharAt == '\r') {
                    writer.write("&#xD;");
                } else if (cCharAt == '&') {
                    writer.write("&amp;");
                } else if (cCharAt == '<') {
                    writer.write("&lt;");
                } else if (cCharAt != '>') {
                    writer.write(cCharAt);
                } else {
                    writer.write("&gt;");
                }
            }
        } catch (Throwable th) {
            if (f97DW) {
                wu.j6(th, 4104005874890906376L, this, writer, str);
            }
            throw th;
        }
    }

    @su(method = -63776833118427017L)
    private void m186j6(Node node, Writer writer, int i, String str) {
        try {
            if (f98j6) {
                wu.j6(553719182786207264L, this, node, writer, new Integer(i), str);
            }
            short nodeType = node.getNodeType();
            if (nodeType != 1) {
                if (nodeType != 9) {
                    return;
                }
                writer.write("<?xml version=\"");
                writer.write(((Document) node).getXmlVersion());
                writer.write("\" encoding=\"utf-8\"");
                writer.write("?>");
                writer.write(this.f100Hw);
                NodeList childNodes = node.getChildNodes();
                if (childNodes != null) {
                    for (int i2 = 0; i2 < childNodes.getLength(); i2++) {
                        m186j6(childNodes.item(i2), writer, 0, "");
                    }
                    return;
                }
                return;
            }
            String nodeName = node.getNodeName();
            writer.write(str + "<" + nodeName);
            String str2 = this.f100Hw + str + this.f99FH;
            if (i == 0) {
                writer.write(str2);
                writer.write("xmlns:android=\"http://schemas.android.com/apk/res/android\"");
            }
            NamedNodeMap attributes = node.getAttributes();
            for (int i3 = 0; i3 < attributes.getLength(); i3++) {
                Attr attr = (Attr) attributes.item(i3);
                if (!"xmlns:android".equals(attr.getName())) {
                    writer.write(str2);
                    writer.write(attr.getNodeName());
                    writer.write("=\"");
                    m185j6(writer, attr.getNodeValue());
                    writer.write("\"");
                }
            }
            NodeList childNodes2 = node.getChildNodes();
            if (childNodes2 == null || childNodes2.getLength() <= 0) {
                writer.write("/>");
            } else {
                writer.write(">");
                writer.write(this.f100Hw);
                writer.write(this.f100Hw);
                for (int i4 = 0; i4 < childNodes2.getLength(); i4++) {
                    if (childNodes2.item(i4).getNodeType() == 1) {
                        m186j6(childNodes2.item(i4), writer, i + 1, str + this.f99FH);
                    }
                }
                writer.write(str);
                writer.write("</" + nodeName + ">");
            }
            writer.write(this.f100Hw);
            writer.write(this.f100Hw);
        } catch (Throwable th) {
            if (f97DW) {
                wu.j6(th, 553719182786207264L, this, node, writer, new Integer(i), str);
            }
            throw th;
        }
    }

    public void m187j6(Document document, OutputStream outputStream) {
        try {
            if (f98j6) {
                wu.j6(249077740171505885L, this, document, outputStream);
            }
            m188j6(document, new OutputStreamWriter(outputStream, this.f101v5));
        } catch (Throwable th) {
            if (f97DW) {
                wu.j6(th, 249077740171505885L, this, document, outputStream);
            }
            throw th;
        }
    }

    public void m188j6(Document document, Writer writer) {
        try {
            if (f98j6) {
                wu.j6(1362609029906784912L, this, document, writer);
            }
            document.normalize();
            m186j6(document, writer, 0, "");
            writer.flush();
        } catch (Throwable th) {
            if (f97DW) {
                wu.j6(th, 1362609029906784912L, this, document, writer);
            }
            throw th;
        }
    }
}
