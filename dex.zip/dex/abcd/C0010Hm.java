package abcd;

public final class C0010Hm implements cu {

    private final int f91DW;

    private final int f92FH;

    private final au f93Hw;

    private final int f94j6;

    private final C0095Jm f95v5;

    public C0010Hm(int i, int i2, int i3, au auVar, C0095Jm c0095Jm) {
        if (i < 0) {
            throw new IllegalArgumentException("label < 0");
        }
        if (i2 < 0) {
            throw new IllegalArgumentException("start < 0");
        }
        if (i3 <= i2) {
            throw new IllegalArgumentException("end <= start");
        }
        if (auVar == null) {
            throw new NullPointerException("targets == null");
        }
        int size = auVar.size();
        for (int i4 = 0; i4 < size; i4++) {
            if (auVar.get(i4) < 0) {
                throw new IllegalArgumentException("successors[" + i4 + "] == " + auVar.get(i4));
            }
        }
        if (c0095Jm == null) {
            throw new NullPointerException("catches == null");
        }
        this.f94j6 = i;
        this.f91DW = i2;
        this.f92FH = i3;
        this.f93Hw = auVar;
        this.f95v5 = c0095Jm;
    }

    public int m147DW() {
        return this.f94j6;
    }

    public int m148FH() {
        return this.f92FH;
    }

    public int m149Hw() {
        return this.f91DW;
    }

    public C0095Jm m150j6() {
        return this.f95v5;
    }

    public String toString() {
        return '{' + Yt.v5(this.f94j6) + ": " + Yt.v5(this.f91DW) + ".." + Yt.v5(this.f92FH) + '}';
    }

    public au m151v5() {
        return this.f93Hw;
    }
}
