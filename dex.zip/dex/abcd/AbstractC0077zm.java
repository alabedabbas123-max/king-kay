package abcd;

public abstract class AbstractC0077zm extends Am {

    private final Jr f411DW;

    private final int f412FH;

    public AbstractC0077zm(String str, Jr jr, int i) throws iu {
        super(str);
        try {
            if (jr.Zo()) {
                throw new iu("annotations.isMutable()");
            }
            this.f411DW = jr;
            this.f412FH = i;
        } catch (NullPointerException unused) {
            throw new NullPointerException("annotations == null");
        }
    }

    public final int m496Hw() {
        return this.f412FH + 6;
    }

    public final Jr m497j6() {
        return this.f411DW;
    }
}
