package abcd;

import com.appfour.backbone.api.closures.OnLaunchClosure;
import com.appfour.backbone.api.objects.EventData;
import com.appfour.backbone.api.objects.UserLaunchAction;

class C0017rv implements jv {

    final Bv f44DW;

    final OnLaunchClosure f45j6;

    C0017rv(Bv bv, OnLaunchClosure onLaunchClosure) {
        this.f44DW = bv;
        this.f45j6 = onLaunchClosure;
    }

    public EventData m157j6(Object[] objArr) {
        return this.f45j6.getValue((UserLaunchAction) objArr[0]);
    }
}
