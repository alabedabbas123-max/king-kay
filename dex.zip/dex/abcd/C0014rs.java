package abcd;

public final class C0014rs extends Bs {

    public static final C0014rs f32DW = new C0014rs(false);

    public static final C0014rs f33FH = new C0014rs(true);

    private C0014rs(boolean z) {
        super(z ? 1 : 0);
    }

    public static C0014rs m140j6(int i) {
        if (i == 0) {
            return f32DW;
        }
        if (i == 1) {
            return f33FH;
        }
        throw new IllegalArgumentException("bogus value: " + i);
    }

    public String m141Zo() {
        return "boolean";
    }

    public String m142aM() {
        return m143rN() ? "true" : "false";
    }

    public Qs getType() {
        return Qs.DW;
    }

    public boolean m143rN() {
        return Ws() != 0;
    }

    public String toString() {
        return m143rN() ? "boolean{true}" : "boolean{false}";
    }
}
