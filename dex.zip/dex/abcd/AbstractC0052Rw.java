package abcd;

public abstract class AbstractC0052Rw<T> {
}
