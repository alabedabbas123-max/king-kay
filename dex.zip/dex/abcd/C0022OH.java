package abcd;

import java.io.IOException;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.zip.CRC32;
import org.eclipse.jgit.JGitText;

public final class C0022OH extends OutputStream {

    private final OutputStream f75DW;

    private final TH f76FH;

    private long f79Zo;

    private byte[] f80gn;

    private final LE f81j6;

    private final CRC32 f77Hw = new CRC32();

    private final MessageDigest f83v5 = hE.j6();

    private byte[] f78VH = new byte[32];

    private long f82u7 = 131072;

    public C0022OH(LE le, OutputStream outputStream, TH th) {
        this.f81j6 = le;
        this.f75DW = outputStream;
        this.f76FH = th;
    }

    private int m119DW(int i, long j) {
        long j2 = j >>> 4;
        this.f78VH[0] = (byte) ((j & 15) | ((long) ((i << 4) | (j2 > 0 ? 128 : 0))));
        int i2 = 1;
        while (j2 > 0) {
            long j3 = j2 >>> 7;
            int i3 = i2 + 1;
            this.f78VH[i2] = (byte) ((j2 & 127) | ((long) (j3 > 0 ? 128 : 0)));
            j2 = j3;
            i2 = i3;
        }
        return i2;
    }

    int m120DW() {
        return (int) this.f77Hw.getValue();
    }

    public byte[] m121FH() {
        if (this.f80gn == null) {
            this.f80gn = new byte[16384];
        }
        return this.f80gn;
    }

    byte[] m122Hw() {
        return this.f83v5.digest();
    }

    void m123Zo() {
        this.f77Hw.reset();
    }

    @Override
    public void flush() throws IOException {
        this.f75DW.flush();
    }

    void m124j6() {
        this.f81j6.update(1);
    }

    void m125j6(int i, long j) throws IOException {
        System.arraycopy(hE.v5, 0, this.f78VH, 0, 4);
        FK.DW(this.f78VH, 4, i);
        FK.DW(this.f78VH, 8, (int) j);
        write(this.f78VH, 0, 12);
    }

    public void m126j6(MH mh) {
        this.f76FH.j6(this, mh);
    }

    public void m127j6(MH mh, long j) throws IOException {
        MH mhA8;
        if (!mh.BT()) {
            write(this.f78VH, 0, m119DW(mh.yS(), j));
            return;
        }
        if (!this.f76FH.Zo() || (mhA8 = mh.a8()) == null || !mhA8.nw()) {
            int iM119DW = m119DW(7, j);
            mh.lg().DW(this.f78VH, iM119DW);
            write(this.f78VH, 0, iM119DW + 20);
            return;
        }
        long j2 = this.f79Zo;
        write(this.f78VH, 0, m119DW(6, j));
        long offset = j2 - mhA8.getOffset();
        byte[] bArr = this.f78VH;
        int length = bArr.length - 1;
        bArr[length] = (byte) (offset & 127);
        while (true) {
            long j3 = offset >> 7;
            if (j3 <= 0) {
                byte[] bArr2 = this.f78VH;
                write(bArr2, length, bArr2.length - length);
                return;
            } else {
                length--;
                long j4 = j3 - 1;
                this.f78VH[length] = (byte) (128 | (j4 & 127));
                offset = j4;
            }
        }
    }

    public long m128v5() {
        return this.f79Zo;
    }

    @Override
    public void write(int i) throws IOException {
        this.f79Zo++;
        this.f75DW.write(i);
        this.f77Hw.update(i);
        this.f83v5.update((byte) i);
    }

    @Override
    public void write(byte[] bArr, int i, int i2) throws IOException {
        while (i2 > 0) {
            int iMin = Math.min(i2, 131072);
            this.f79Zo += (long) iMin;
            if (this.f82u7 <= this.f79Zo) {
                if (this.f81j6.isCancelled()) {
                    throw new IOException(JGitText.j6().packingCancelledDuringObjectsWriting);
                }
                this.f82u7 = this.f79Zo + 131072;
            }
            this.f75DW.write(bArr, i, iMin);
            this.f77Hw.update(bArr, i, iMin);
            this.f83v5.update(bArr, i, iMin);
            i += iMin;
            i2 -= iMin;
        }
    }
}
