package abcd;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.eclipse.jgit.JGitText;

public class C0004iB extends dB<pB> {

    private static int[] f3FH;

    private vF f4Hw;

    private List<ME> f5v5;

    protected C0004iB(UE ue) {
        super(ue);
        this.f4Hw = vF.Hw;
        this.f5v5 = new LinkedList();
    }

    static int[] m4FH() {
        int[] iArr = f3FH;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[RE.a.values().length];
        try {
            iArr2[RE.a.Zo.ordinal()] = 6;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[RE.a.v5.ordinal()] = 5;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[RE.a.u7.ordinal()] = 9;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[RE.a.DW.ordinal()] = 2;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr2[RE.a.Hw.ordinal()] = 4;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            iArr2[RE.a.j6.ordinal()] = 1;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            iArr2[RE.a.FH.ordinal()] = 3;
        } catch (NoSuchFieldError unused7) {
        }
        try {
            iArr2[RE.a.VH.ordinal()] = 7;
        } catch (NoSuchFieldError unused8) {
        }
        try {
            iArr2[RE.a.gn.ordinal()] = 8;
        } catch (NoSuchFieldError unused9) {
        }
        try {
            iArr2[RE.a.tp.ordinal()] = 10;
        } catch (NoSuchFieldError unused10) {
        }
        f3FH = iArr2;
        return iArr2;
    }

    private void m5j6(StringBuilder sb, yE yEVar, yE yEVar2) throws SB, LB {
        RE reV5 = ((dB) this).j6.v5("HEAD");
        reV5.DW(yEVar);
        reV5.j6(sb.toString(), false);
        reV5.j6(yEVar2);
        RE.a aVarXL = reV5.XL();
        int i = m4FH()[aVarXL.ordinal()];
        if (i != 2) {
            if (i == 4 || i == 6) {
                return;
            }
            if (i != 7) {
                throw new SB(MessageFormat.format(JGitText.j6().updatingRefFailed, "HEAD", yEVar.toString(), aVarXL));
            }
        }
        throw new LB(JGitText.j6().couldNotLockHEAD, reV5.VH(), aVarXL);
    }

    public pB m693call() throws Throwable {
        Throwable th;
        VC vc;
        IOException iOException;
        boolean zJ6;
        List listU7;
        Map map;
        Map map2;
        j6();
        if (this.f5v5.size() != 1) {
            throw new PB(this.f5v5.isEmpty() ? JGitText.j6().noMergeHeadSpecified : MessageFormat.format(JGitText.j6().mergeStrategyDoesNotSupportHeads, this.f4Hw.j6(), Integer.valueOf(this.f5v5.size())));
        }
        NC nc = null;
        try {
            try {
                try {
                    ME meJ6 = ((dB) this).j6.j6("HEAD");
                    if (meJ6 == null) {
                        throw new VB(JGitText.j6().commitOnRepoWithoutHEADCurrentlyNotSupported);
                    }
                    StringBuilder sb = new StringBuilder("merge ");
                    qG qGVar = new qG(((dB) this).j6);
                    try {
                        try {
                            ME me = this.f5v5.get(0);
                            sb.append(me.getName());
                            yE yEVarFH = me.FH();
                            if (yEVarFH == null) {
                                yEVarFH = me.DW();
                            }
                            yE yEVarFH2 = qGVar.FH(yEVarFH);
                            yE yEVarDW = meJ6.DW();
                            try {
                                if (yEVarDW == null) {
                                    qGVar.DW(yEVarFH2);
                                    NC nc2 = new NC(((dB) this).j6, ((dB) this).j6.XL(), yEVarFH2.yS());
                                    nc2.j6(true);
                                    nc2.j6();
                                    RE reV5 = ((dB) this).j6.v5(meJ6.getTarget().getName());
                                    reV5.DW(yEVarFH);
                                    reV5.j6((YD) null);
                                    reV5.j6("initial pull", false);
                                    if (reV5.XL() != RE.a.Hw) {
                                        throw new VB(JGitText.j6().commitOnRepoWithoutHEADCurrentlyNotSupported);
                                    }
                                    j6(false);
                                    yE[] yEVarArr = new yE[2];
                                    yEVarArr[1] = yEVarFH2;
                                    pB pBVar = new pB(yEVarFH2, yEVarFH2, yEVarArr, pB.a.j6, this.f4Hw, (Map) null, (String) null);
                                    qGVar.EQ();
                                    return pBVar;
                                }
                                yE yEVarFH3 = qGVar.FH(yEVarDW);
                                if (qGVar.j6(yEVarFH2, yEVarFH3)) {
                                    j6(false);
                                    pB pBVar2 = new pB(yEVarFH3, yEVarFH2, new yE[]{yEVarFH3, yEVarFH2}, pB.a.DW, this.f4Hw, (Map) null, (String) null);
                                    qGVar.EQ();
                                    return pBVar2;
                                }
                                if (qGVar.j6(yEVarFH3, yEVarFH2)) {
                                    sb.append(": " + pB.a.j6);
                                    NC nc3 = new NC(((dB) this).j6, yEVarFH3.yS(), ((dB) this).j6.XL(), yEVarFH2.yS());
                                    nc3.j6(true);
                                    nc3.j6();
                                    m5j6(sb, yEVarFH2, yEVarDW);
                                    j6(false);
                                    pB pBVar3 = new pB(yEVarFH2, yEVarFH2, new yE[]{yEVarFH3, yEVarFH2}, pB.a.j6, this.f4Hw, (Map) null, (String) null);
                                    qGVar.EQ();
                                    return pBVar3;
                                }
                                String strJ6 = new sF().j6(this.f5v5, meJ6);
                                ((dB) this).j6.Zo(strJ6);
                                ((dB) this).j6.j6(Arrays.asList(me.DW()));
                                xF xFVarJ6 = this.f4Hw.j6(((dB) this).j6);
                                if (xFVarJ6 instanceof xF) {
                                    xF xFVar = xFVarJ6;
                                    xFVar.j6(new String[]{"BASE", "HEAD", me.getName()});
                                    xFVar.j6(new WJ(((dB) this).j6));
                                    zJ6 = xFVarJ6.j6(new YD[]{yEVarFH3, yEVarFH2});
                                    Map mapGn = xFVar.gn();
                                    Map mapVH = xFVar.VH();
                                    listU7 = xFVar.u7();
                                    map2 = mapGn;
                                    map = mapVH;
                                } else {
                                    zJ6 = xFVarJ6.j6(new YD[]{yEVarFH3, yEVarFH2});
                                    listU7 = null;
                                    map = null;
                                    map2 = null;
                                }
                                sb.append(": Merge made by ");
                                sb.append(this.f4Hw.j6());
                                sb.append('.');
                                if (zJ6) {
                                    NC nc4 = new NC(((dB) this).j6, yEVarFH3.yS(), ((dB) this).j6.XL(), xFVarJ6.FH());
                                    nc4.j6(true);
                                    nc4.j6();
                                    ZA zaGn = new cB(DW()).gn();
                                    zaGn.FH(sb.toString());
                                    dG dGVarCall = zaGn.call();
                                    dGVarCall.getId();
                                    yEVarFH3.getId();
                                    yEVarFH2.getId();
                                    pB pBVar4 = new pB(dGVarCall, (yE) null, new yE[]{yEVarFH3, yEVarFH2}, pB.a.Hw, this.f4Hw, (Map) null, (String) null);
                                    qGVar.EQ();
                                    return pBVar4;
                                }
                                if (map == null) {
                                    ((dB) this).j6.Zo(new sF().j6(strJ6, listU7));
                                    dG dGVarJ6 = xFVarJ6.j6(0, 1);
                                    yEVarFH3.getId();
                                    yEVarFH2.getId();
                                    pB pBVar5 = new pB((yE) null, dGVarJ6, new yE[]{yEVarFH3, yEVarFH2}, pB.a.v5, this.f4Hw, map2, (String) null);
                                    qGVar.EQ();
                                    return pBVar5;
                                }
                                ((dB) this).j6.Zo((String) null);
                                ((dB) this).j6.j6((List) null);
                                dG dGVarJ7 = xFVarJ6.j6(0, 1);
                                yEVarFH3.getId();
                                yEVarFH2.getId();
                                pB pBVar6 = new pB((yE) null, dGVarJ7, new yE[]{yEVarFH3, yEVarFH2}, pB.a.FH, this.f4Hw, map2, map, (String) null);
                                qGVar.EQ();
                                return pBVar6;
                            } catch (VC e) {
                                e = e;
                                nc = "HEAD";
                                vc = e;
                                throw new KB(nc == null ? Collections.emptyList() : nc.DW(), vc);
                            }
                        } catch (VC e2) {
                            e = e2;
                        }
                    } catch (IOException e3) {
                        iOException = e3;
                        throw new SB(MessageFormat.format(JGitText.j6().exceptionCaughtDuringExecutionOfMergeCommand, iOException), iOException);
                    }
                } catch (Throwable th2) {
                    th = th2;
                    if (0 == 0) {
                        throw th;
                    }
                    nc.EQ();
                    throw th;
                }
            } catch (IOException e4) {
                iOException = e4;
            } catch (VC e5) {
                vc = e5;
            }
        } catch (Throwable th3) {
            th = th3;
        }
    }

    public C0004iB m6j6(ME me) {
        j6();
        this.f5v5.add(me);
        return this;
    }

    public C0004iB m7j6(YD yd) {
        m8j6(yd.VH(), yd);
        return this;
    }

    public C0004iB m8j6(String str, YD yd) {
        m6j6((ME) new BE.c(ME.a.DW, str, yd.Hw()));
        return this;
    }
}
