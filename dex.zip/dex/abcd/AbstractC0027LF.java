package abcd;

abstract class AbstractC0027LF extends XF {

    static final AbstractC0027LF f116j6 = new a(null);

    int f117DW;

    private static class a extends AbstractC0027LF {
        private a() {
        }

        a(a aVar) {
            this();
        }

        @Override
        public dG mo150j6() {
            return null;
        }

        @Override
        public void mo151j6(dG dGVar) {
            throw new UnsupportedOperationException();
        }

        @Override
        boolean mo152j6(int i) {
            return false;
        }
    }

    AbstractC0027LF() {
    }

    protected static void m148j6(StringBuilder sb, dG dGVar) {
        sb.append(dGVar.toString());
        sb.append('\n');
    }

    int m149DW() {
        return this.f117DW;
    }

    public abstract dG mo150j6();

    public abstract void mo151j6(dG dGVar);

    abstract boolean mo152j6(int i);
}
