package abcd;

@xu
public abstract class AbstractC0133rc {

    @ru(field = 3743171931245145259L)
    private static AbstractC0133rc f695DW;

    @tu
    private static boolean f696FH;

    @uu
    private static boolean f697Hw;

    @ru(field = 1035069477755027961L)
    private static Object f698j6;

    static {
        try {
            wu.j6(AbstractC0133rc.class, 3508908880632874191L, 3508908880632874191L);
            if (f696FH) {
                wu.j6(1759397294414490576L, (Object) null);
            }
            f698j6 = new Object();
        } catch (Throwable th) {
            if (f697Hw) {
                wu.j6(th, 1759397294414490576L, (Object) null);
            }
            throw th;
        }
    }

    public AbstractC0133rc() {
        try {
            if (f696FH) {
                wu.j6(4744417128173355776L, (Object) null);
            }
        } catch (Throwable th) {
            if (f697Hw) {
                wu.j6(th, 4744417128173355776L, (Object) null);
            }
            throw th;
        }
    }

    public static AbstractC0133rc m676j6() {
        AbstractC0133rc abstractC0133rc;
        try {
            if (f696FH) {
                wu.j6(-3631764667306789755L, (Object) null);
            }
            synchronized (f698j6) {
                abstractC0133rc = f695DW;
            }
            return abstractC0133rc;
        } catch (Throwable th) {
            if (f697Hw) {
                wu.j6(th, -3631764667306789755L, (Object) null);
            }
            throw th;
        }
    }

    public abstract Thread m677j6(ThreadGroup threadGroup, Runnable runnable, String str, long j);
}
