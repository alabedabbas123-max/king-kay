package abcd;

public class C0022Hy implements Cloneable {

    long f134FH;

    int f135Hw;

    byte[] f136VH;

    byte[] f137Zo;

    byte[] f138gn;

    long f140tp;

    int f141u7;

    boolean f139j6 = false;

    private boolean f132DW = false;

    int f142v5 = 255;

    boolean f133EQ = false;

    long f143we = 0;

    public Object clone() {
        C0022Hy c0022Hy = (C0022Hy) super.clone();
        byte[] bArr = c0022Hy.f137Zo;
        if (bArr != null) {
            byte[] bArr2 = new byte[bArr.length];
            System.arraycopy(bArr, 0, bArr2, 0, bArr2.length);
            c0022Hy.f137Zo = bArr2;
        }
        byte[] bArr3 = c0022Hy.f136VH;
        if (bArr3 != null) {
            byte[] bArr4 = new byte[bArr3.length];
            System.arraycopy(bArr3, 0, bArr4, 0, bArr4.length);
            c0022Hy.f136VH = bArr4;
        }
        byte[] bArr5 = c0022Hy.f138gn;
        if (bArr5 != null) {
            byte[] bArr6 = new byte[bArr5.length];
            System.arraycopy(bArr5, 0, bArr6, 0, bArr6.length);
            c0022Hy.f138gn = bArr6;
        }
        return c0022Hy;
    }

    public void m224j6(long j) {
        this.f140tp = j;
    }

    void m225j6(Gy gy) {
        int i;
        int i2 = this.f139j6 ? 1 : 0;
        if (this.f132DW) {
            i2 |= 2;
        }
        if (this.f137Zo != null) {
            i2 |= 4;
        }
        if (this.f136VH != null) {
            i2 |= 8;
        }
        if (this.f138gn != null) {
            i2 |= 16;
        }
        int i3 = gy.ro;
        if (i3 == 1) {
            i = 4;
        } else {
            i = i3 == 9 ? 2 : 0;
        }
        gy.VH(-29921);
        gy.j6((byte) 8);
        gy.j6((byte) i2);
        gy.j6((byte) this.f143we);
        gy.j6((byte) (this.f143we >> 8));
        gy.j6((byte) (this.f143we >> 16));
        gy.j6((byte) (this.f143we >> 24));
        gy.j6((byte) i);
        gy.j6((byte) this.f142v5);
        byte[] bArr = this.f137Zo;
        if (bArr != null) {
            gy.j6((byte) bArr.length);
            gy.j6((byte) (this.f137Zo.length >> 8));
            byte[] bArr2 = this.f137Zo;
            gy.j6(bArr2, 0, bArr2.length);
        }
        byte[] bArr3 = this.f136VH;
        if (bArr3 != null) {
            gy.j6(bArr3, 0, bArr3.length);
            gy.j6((byte) 0);
        }
        byte[] bArr4 = this.f138gn;
        if (bArr4 != null) {
            gy.j6(bArr4, 0, bArr4.length);
            gy.j6((byte) 0);
        }
    }
}
