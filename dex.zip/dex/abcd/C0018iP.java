package abcd;

import java.security.BasicPermission;
import java.security.Permission;
import java.util.StringTokenizer;

public class C0018iP extends BasicPermission {

    private final int f53DW;

    private final String f54j6;

    public C0018iP(String str, String str2) {
        super(str, str2);
        this.f54j6 = str2;
        this.f53DW = m77j6(str2);
    }

    private int m77j6(String str) {
        StringTokenizer stringTokenizer = new StringTokenizer(TP.DW(str), " ,");
        int i = 0;
        while (stringTokenizer.hasMoreTokens()) {
            String strNextToken = stringTokenizer.nextToken();
            if (strNextToken.equals("threadlocalecimplicitlyca")) {
                i |= 1;
            } else if (strNextToken.equals("ecimplicitlyca")) {
                i |= 2;
            } else if (strNextToken.equals("threadlocaldhdefaultparams")) {
                i |= 4;
            } else if (strNextToken.equals("dhdefaultparams")) {
                i |= 8;
            } else if (strNextToken.equals("all")) {
                i |= 15;
            }
        }
        if (i != 0) {
            return i;
        }
        throw new IllegalArgumentException("unknown permissions passed to mask");
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof C0018iP) {
            C0018iP c0018iP = (C0018iP) obj;
            if (this.f53DW == c0018iP.f53DW && getName().equals(c0018iP.getName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String getActions() {
        return this.f54j6;
    }

    public int hashCode() {
        return getName().hashCode() + this.f53DW;
    }

    @Override
    public boolean implies(Permission permission) {
        if (!(permission instanceof C0018iP) || !getName().equals(permission.getName())) {
            return false;
        }
        int i = this.f53DW;
        int i2 = ((C0018iP) permission).f53DW;
        return (i & i2) == i2;
    }
}
