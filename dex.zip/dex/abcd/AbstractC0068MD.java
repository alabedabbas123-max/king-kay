package abcd;

import java.util.List;
import org.eclipse.jgit.JGitText;

abstract class AbstractC0068MD implements QD {

    private final boolean f310DW;

    private List<QD> f311j6 = null;

    AbstractC0068MD(boolean z) {
        this.f310DW = z;
    }

    protected abstract boolean mo348DW(char c);

    public List<QD> m349j6(char c) {
        return mo348DW(c) ? this.f311j6 : OD.j6;
    }

    public final void m350j6(List<QD> list) {
        if (this.f311j6 != null) {
            throw new IllegalStateException(JGitText.j6().propertyIsAlreadyNonNull);
        }
        this.f311j6 = list;
    }

    boolean m351j6() {
        return this.f310DW;
    }
}
