package abcd;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.eclipse.jgit.JGitText;

public class C0005iC {

    private static int[] f8Hw;

    private static int[] f10v5;

    private eC f11EQ;

    private UE f15VH;

    private BC f17XL;

    private final OutputStream f18Zo;

    private LE f19aM;

    private IE f20gn;

    private cC.c f21j3;

    private static final byte[] f9j6 = hE.DW("\\ No newline at end of file\n");

    private static final byte[] f6DW = new byte[0];

    private static final byte[] f7FH = new byte[0];

    private int f23u7 = 3;

    private int f22tp = 7;

    private zC f24we = zC.j6;

    private int f12J0 = 52428800;

    private String f13J8 = "a/";

    private String f16Ws = "b/";

    private AbstractC0057jK f14QX = AbstractC0057jK.f245j6;

    private static class a {

        tC f25DW;

        tC f26FH;

        HF f27j6;

        private a() {
        }

        a(a aVar) {
            this();
        }
    }

    public C0005iC(OutputStream outputStream) {
        this.f18Zo = outputStream;
    }

    private a m9DW(hC hCVar) throws fD, UC, cD, IOException {
        C0093kC c0093kC;
        HF.a aVar;
        a aVar2 = new a(null);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        m28j6(byteArrayOutputStream, hCVar);
        if (hCVar.VH() == rE.v5 || hCVar.Hw() == rE.v5) {
            m12DW(byteArrayOutputStream, hCVar);
            m13DW((OutputStream) byteArrayOutputStream, hCVar);
            c0093kC = new C0093kC();
            aVar = HF.a.j6;
        } else {
            m17FH();
            byte[] bArrM31j6 = m31j6(hC.b.j6, hCVar);
            byte[] bArrM31j7 = m31j6(hC.b.DW, hCVar);
            byte[] bArr = f7FH;
            if (bArrM31j6 == bArr || bArrM31j7 == bArr || tC.j6(bArrM31j6) || tC.j6(bArrM31j7)) {
                m12DW(byteArrayOutputStream, hCVar);
                byteArrayOutputStream.write(hE.DW("Binary files differ\n"));
                c0093kC = new C0093kC();
                aVar = HF.a.DW;
            } else {
                aVar2.f25DW = new tC(bArrM31j6);
                aVar2.f26FH = new tC(bArrM31j7);
                c0093kC = m25j6(aVar2.f25DW, aVar2.f26FH);
                aVar = HF.a.j6;
                int i = m32j6()[hCVar.DW().ordinal()];
                if ((i != 4 && i != 5) || !c0093kC.isEmpty()) {
                    m12DW(byteArrayOutputStream, hCVar);
                }
            }
        }
        aVar2.f27j6 = new HF(byteArrayOutputStream.toByteArray(), c0093kC, aVar);
        return aVar2;
    }

    private static AbstractC0057jK m10DW(TJ tj, TJ tj2) {
        if ((tj instanceof RC) && (tj2 instanceof _J)) {
            return new dK(0, 1);
        }
        boolean z = tj instanceof _J;
        if (z && (tj2 instanceof RC)) {
            return new dK(1, 0);
        }
        AbstractC0057jK abstractC0057jKJ6 = AbstractC0057jK.f244DW;
        if (z) {
            abstractC0057jKJ6 = cK.j6(new eK(0), abstractC0057jKJ6);
        }
        return tj2 instanceof _J ? cK.j6(new eK(1), abstractC0057jKJ6) : abstractC0057jKJ6;
    }

    private List<hC> m11DW(List<hC> list) {
        this.f17XL.v5();
        this.f17XL.j6(list);
        return this.f17XL.j6(this.f20gn, this.f19aM);
    }

    private void m12DW(ByteArrayOutputStream byteArrayOutputStream, hC hCVar) {
        String strM21Hw;
        if (hCVar.u7.equals(hCVar.tp)) {
            return;
        }
        int i = m32j6()[hCVar.DW().ordinal()];
        String strM21Hw2 = "/dev/null";
        if (i == 1) {
            strM21Hw = m21Hw(String.valueOf(this.f16Ws) + hCVar.v5());
        } else if (i != 3) {
            strM21Hw2 = m21Hw(String.valueOf(this.f13J8) + hCVar.gn());
            strM21Hw = m21Hw(String.valueOf(this.f16Ws) + hCVar.v5());
        } else {
            strM21Hw2 = m21Hw(String.valueOf(this.f13J8) + hCVar.gn());
            strM21Hw = "/dev/null";
        }
        byteArrayOutputStream.write(hE.j6("--- " + strM21Hw2 + "\n"));
        byteArrayOutputStream.write(hE.j6("+++ " + strM21Hw + "\n"));
    }

    private void m13DW(OutputStream outputStream, hC hCVar) throws IOException {
        if (hCVar.VH() == rE.v5) {
            outputStream.write(hE.DW("-Subproject commit " + hCVar.Zo().Hw() + "\n"));
        }
        if (hCVar.Hw() == rE.v5) {
            outputStream.write(hE.DW("+Subproject commit " + hCVar.FH().Hw() + "\n"));
        }
    }

    private boolean m14DW(List<C0049jC> list, int i) {
        return list.get(i).m264Hw() - list.get(i - 1).m266Zo() <= this.f23u7 * 2;
    }

    static int[] m15DW() {
        int[] iArr = f10v5;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[hC.b.values().length];
        try {
            iArr2[hC.b.DW.ordinal()] = 2;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[hC.b.j6.ordinal()] = 1;
        } catch (NoSuchFieldError unused2) {
        }
        f10v5 = iArr2;
        return iArr2;
    }

    private int m16FH(List<C0049jC> list, int i) {
        while (true) {
            i++;
            if (i >= list.size() || (!m30j6(list, i) && !m14DW(list, i))) {
                break;
            }
        }
        return i - 1;
    }

    private void m17FH() {
        if (this.f15VH == null) {
            throw new IllegalStateException(JGitText.j6().repositoryIsRequired);
        }
    }

    private static boolean m18FH(hC hCVar) {
        return hCVar.DW() == hC.a.Hw || hCVar.DW() == hC.a.v5;
    }

    private boolean m19FH(String str) {
        return false;
    }

    private boolean m20FH(List<hC> list) {
        String strDW = this.f14QX.DW();
        for (hC hCVar : list) {
            if (hCVar.DW() == hC.a.j6 && hCVar.v5().equals(strDW)) {
                return true;
            }
        }
        return false;
    }

    private static String m21Hw(String str) {
        return GK.j6.j6(str);
    }

    private List<hC> m22Hw(List<hC> list) {
        String strDW = this.f14QX.DW();
        for (hC hCVar : list) {
            if (m18FH(hCVar) && hCVar.v5().equals(strDW)) {
                this.f14QX = WF.j6(hCVar.gn());
                return Collections.singletonList(hCVar);
            }
        }
        return Collections.emptyList();
    }

    private boolean m23Hw(tC tCVar, int i) {
        return i + 1 == tCVar.j6() && tCVar.DW();
    }

    private cC m24j6(TJ tj) {
        return tj instanceof _J ? cC.j6((_J) tj) : cC.j6(this.f20gn);
    }

    private C0093kC m25j6(tC tCVar, tC tCVar2) {
        return this.f11EQ.j6(this.f24we, tCVar, tCVar2);
    }

    private String m26j6(WD wd) {
        if (wd.DW() && this.f15VH != null) {
            try {
                wd = this.f20gn.j6(wd.v5(), this.f22tp);
            } catch (IOException unused) {
            }
        }
        return wd.Hw();
    }

    private void m27j6(char c, int i, int i2) throws IOException {
        this.f18Zo.write(32);
        this.f18Zo.write(c);
        if (i2 == 0) {
            this.f18Zo.write(hE.j6(i - 1));
            this.f18Zo.write(44);
            this.f18Zo.write(48);
        } else {
            if (i2 == 1) {
                this.f18Zo.write(hE.j6(i));
                return;
            }
            this.f18Zo.write(hE.j6(i));
            this.f18Zo.write(44);
            this.f18Zo.write(hE.j6(i2));
        }
    }

    private void m28j6(ByteArrayOutputStream byteArrayOutputStream, hC hCVar) throws IOException {
        hC.a aVarDW = hCVar.DW();
        String strGn = hCVar.gn();
        String strV5 = hCVar.v5();
        rE rEVarVH = hCVar.VH();
        rE rEVarHw = hCVar.Hw();
        byteArrayOutputStream.write(hE.DW("diff --git "));
        StringBuilder sb = new StringBuilder(String.valueOf(this.f13J8));
        sb.append(aVarDW == hC.a.j6 ? strV5 : strGn);
        byteArrayOutputStream.write(hE.j6(m21Hw(sb.toString())));
        byteArrayOutputStream.write(32);
        StringBuilder sb2 = new StringBuilder(String.valueOf(this.f16Ws));
        sb2.append(aVarDW == hC.a.FH ? strGn : strV5);
        byteArrayOutputStream.write(hE.j6(m21Hw(sb2.toString())));
        byteArrayOutputStream.write(10);
        int i = m32j6()[aVarDW.ordinal()];
        if (i == 1) {
            byteArrayOutputStream.write(hE.DW("new file mode "));
            rEVarHw.j6(byteArrayOutputStream);
            byteArrayOutputStream.write(10);
        } else if (i != 2) {
            if (i == 3) {
                byteArrayOutputStream.write(hE.DW("deleted file mode "));
                rEVarVH.j6(byteArrayOutputStream);
                byteArrayOutputStream.write(10);
            } else if (i == 4) {
                byteArrayOutputStream.write(hE.DW("similarity index " + hCVar.u7() + "%"));
                byteArrayOutputStream.write(10);
                byteArrayOutputStream.write(hE.j6("rename from " + m21Hw(strGn)));
                byteArrayOutputStream.write(10);
                byteArrayOutputStream.write(hE.j6("rename to " + m21Hw(strV5)));
                byteArrayOutputStream.write(10);
            } else if (i == 5) {
                byteArrayOutputStream.write(hE.DW("similarity index " + hCVar.u7() + "%"));
                byteArrayOutputStream.write(10);
                byteArrayOutputStream.write(hE.j6("copy from " + m21Hw(strGn)));
                byteArrayOutputStream.write(10);
                byteArrayOutputStream.write(hE.j6("copy to " + m21Hw(strV5)));
                byteArrayOutputStream.write(10);
                if (!rEVarVH.equals(rEVarHw)) {
                    byteArrayOutputStream.write(hE.DW("new file mode "));
                    rEVarHw.j6(byteArrayOutputStream);
                    byteArrayOutputStream.write(10);
                }
            }
        } else if (hCVar.u7() > 0) {
            byteArrayOutputStream.write(hE.DW("dissimilarity index " + (100 - hCVar.u7()) + "%"));
            byteArrayOutputStream.write(10);
        }
        if ((aVarDW == hC.a.DW || aVarDW == hC.a.Hw) && !rEVarVH.equals(rEVarHw)) {
            byteArrayOutputStream.write(hE.DW("old mode "));
            rEVarVH.j6(byteArrayOutputStream);
            byteArrayOutputStream.write(10);
            byteArrayOutputStream.write(hE.DW("new mode "));
            rEVarHw.j6(byteArrayOutputStream);
            byteArrayOutputStream.write(10);
        }
        if (hCVar.Zo().equals(hCVar.FH())) {
            return;
        }
        m47j6((OutputStream) byteArrayOutputStream, hCVar);
    }

    private static boolean m29j6(C0049jC c0049jC, int i, int i2) {
        return c0049jC.m271v5() <= i && c0049jC.m266Zo() <= i2;
    }

    private boolean m30j6(List<C0049jC> list, int i) {
        return list.get(i).m263FH() - list.get(i - 1).m271v5() <= this.f23u7 * 2;
    }

    private byte[] m31j6(hC.b bVar, hC hCVar) throws fD, UC, cD {
        if (hCVar.DW(bVar) != rE.Zo && hCVar.DW(bVar).FH() == 3) {
            if (m19FH(hCVar.FH(bVar))) {
                return f7FH;
            }
            WD wdJ6 = hCVar.j6(bVar);
            if (!wdJ6.DW()) {
                Collection collectionJ6 = this.f20gn.j6(wdJ6);
                if (collectionJ6.size() != 1) {
                    if (collectionJ6.size() == 0) {
                        throw new fD(wdJ6, 3);
                    }
                    throw new UC(wdJ6, collectionJ6);
                }
                wdJ6 = WD.j6((YD) collectionJ6.iterator().next());
                int i = m15DW()[bVar.ordinal()];
                if (i == 1) {
                    hCVar.u7 = wdJ6;
                } else if (i == 2) {
                    hCVar.tp = wdJ6;
                }
            }
            try {
                return this.f21j3.j6(bVar, hCVar).j6(this.f12J0);
            } catch (cD.c unused) {
                return f7FH;
            } catch (cD e) {
                e.j6(wdJ6.v5());
                throw e;
            } catch (cD.b unused2) {
                return f7FH;
            } catch (cD.a unused3) {
                return f7FH;
            }
        }
        return f6DW;
    }

    static int[] m32j6() {
        int[] iArr = f8Hw;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[hC.a.values().length];
        try {
            iArr2[hC.a.j6.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[hC.a.v5.ordinal()] = 5;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[hC.a.FH.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[hC.a.DW.ordinal()] = 2;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr2[hC.a.Hw.ordinal()] = 4;
        } catch (NoSuchFieldError unused5) {
        }
        f8Hw = iArr2;
        return iArr2;
    }

    public List<hC> m33DW(YD yd, YD yd2) {
        m17FH();
        qG qGVar = new qG(this.f20gn);
        return m38j6(qGVar.gn(yd), qGVar.gn(yd2));
    }

    protected void m34DW(tC tCVar, int i) throws IOException {
        m39j6(' ', tCVar, i);
    }

    public void m35DW(String str) {
        this.f13J8 = str;
    }

    protected void m36FH(tC tCVar, int i) throws IOException {
        m39j6('-', tCVar, i);
    }

    public List<hC> m37j6(TJ tj, TJ tj2) {
        m17FH();
        YJ yj = new YJ(this.f20gn);
        yj.j6(tj);
        yj.j6(tj2);
        yj.j6(true);
        AbstractC0057jK abstractC0057jKM10DW = m10DW(tj, tj2);
        WF wf = this.f14QX;
        if (wf instanceof WF) {
            yj.j6(cK.j6(fK.j6(wf.DW()), abstractC0057jKM10DW));
        } else {
            yj.j6(cK.j6(wf, abstractC0057jKM10DW));
        }
        this.f21j3 = new cC.c(m24j6(tj), m24j6(tj2));
        List<hC> listJ6 = hC.j6(yj);
        if (!(this.f14QX instanceof WF) || !m20FH(listJ6)) {
            return this.f17XL != null ? m11DW(listJ6) : listJ6;
        }
        tj.EQ();
        tj2.EQ();
        yj.J8();
        yj.j6(tj);
        yj.j6(tj2);
        yj.j6(abstractC0057jKM10DW);
        if (this.f17XL == null) {
            m50j6(true);
        }
        return m22Hw(m11DW(hC.j6(yj)));
    }

    public List<hC> m38j6(mG mGVar, mG mGVar2) {
        m17FH();
        UJ uj = new UJ();
        UJ uj2 = new UJ();
        uj.DW(this.f20gn, mGVar);
        uj2.DW(this.f20gn, mGVar2);
        return m37j6((TJ) uj, (TJ) uj2);
    }

    protected void m39j6(char c, tC tCVar, int i) throws IOException {
        this.f18Zo.write(c);
        tCVar.j6(this.f18Zo, i);
        this.f18Zo.write(10);
    }

    protected void m40j6(int i, int i2, int i3, int i4) throws IOException {
        this.f18Zo.write(64);
        this.f18Zo.write(64);
        m27j6('-', i + 1, i2 - i);
        m27j6('+', i3 + 1, i4 - i3);
        this.f18Zo.write(32);
        this.f18Zo.write(64);
        this.f18Zo.write(64);
        this.f18Zo.write(10);
    }

    public void m41j6(HF hf, tC tCVar, tC tCVar2) throws IOException {
        int iJ8 = hf.J8();
        int iEQ = hf.EQ();
        if (!hf.we().isEmpty()) {
            iEQ = ((JF) hf.we().get(0)).v5();
        }
        this.f18Zo.write(hf.tp(), iJ8, iEQ - iJ8);
        if (hf.J0() == HF.a.j6) {
            m45j6(hf.Ws(), tCVar, tCVar2);
        }
    }

    public void m42j6(UE ue) {
        IE ie = this.f20gn;
        if (ie != null) {
            ie.FH();
        }
        this.f15VH = ue;
        this.f20gn = this.f15VH.j3();
        cC cCVarJ6 = cC.j6(this.f20gn);
        this.f21j3 = new cC.c(cCVarJ6, cCVarJ6);
        gC gCVar = (gC) this.f15VH.Zo().j6(gC.j6);
        if (gCVar.DW()) {
            m35DW("");
            m48j6("");
        }
        m50j6(gCVar.FH());
        this.f11EQ = eC.j6(this.f15VH.Zo().j6("diff", (String) null, "algorithm", eC.a.DW));
    }

    public void m43j6(YD yd, YD yd2) throws fD, UC, cD, IOException {
        m49j6((List<? extends hC>) m33DW(yd, yd2));
    }

    public void m44j6(hC hCVar) throws fD, UC, cD, IOException {
        a aVarM9DW = m9DW(hCVar);
        m41j6(aVarM9DW.f27j6, aVarM9DW.f25DW, aVarM9DW.f26FH);
    }

    public void m45j6(C0093kC c0093kC, tC tCVar, tC tCVar2) throws IOException {
        int i = 0;
        while (i < c0093kC.size()) {
            C0049jC c0049jC = c0093kC.get(i);
            int iM16FH = m16FH(c0093kC, i);
            C0049jC c0049jC2 = c0093kC.get(iM16FH);
            int iMax = Math.max(0, c0049jC.m263FH() - this.f23u7);
            int iMax2 = Math.max(0, c0049jC.m264Hw() - this.f23u7);
            int iMin = Math.min(tCVar.j6(), c0049jC2.m271v5() + this.f23u7);
            int iMin2 = Math.min(tCVar2.j6(), c0049jC2.m266Zo() + this.f23u7);
            m40j6(iMax, iMin, iMax2, iMin2);
            while (true) {
                if (iMax < iMin || iMax2 < iMin2) {
                    if (iMax < c0049jC.m263FH() || iM16FH + 1 < i) {
                        m34DW(tCVar, iMax);
                        if (m23Hw(tCVar, iMax)) {
                            this.f18Zo.write(f9j6);
                        }
                        iMax++;
                    } else {
                        if (iMax < c0049jC.m271v5()) {
                            m36FH(tCVar, iMax);
                            if (m23Hw(tCVar, iMax)) {
                                this.f18Zo.write(f9j6);
                            }
                            iMax++;
                        } else if (iMax2 < c0049jC.m266Zo()) {
                            m46j6(tCVar2, iMax2);
                            if (m23Hw(tCVar2, iMax2)) {
                                this.f18Zo.write(f9j6);
                            }
                        }
                        if (!m29j6(c0049jC, iMax, iMax2) && (i = i + 1) < c0093kC.size()) {
                            c0049jC = c0093kC.get(i);
                        }
                    }
                    iMax2++;
                    if (!m29j6(c0049jC, iMax, iMax2)) {
                    }
                }
            }
        }
    }

    protected void m46j6(tC tCVar, int i) throws IOException {
        m39j6('+', tCVar, i);
    }

    protected void m47j6(OutputStream outputStream, hC hCVar) throws IOException {
        outputStream.write(hE.DW("index " + m26j6(hCVar.Zo()) + ".." + m26j6(hCVar.FH())));
        if (hCVar.VH().equals(hCVar.Hw())) {
            outputStream.write(32);
            hCVar.Hw().j6(outputStream);
        }
        outputStream.write(10);
    }

    public void m48j6(String str) {
        this.f16Ws = str;
    }

    public void m49j6(List<? extends hC> list) throws fD, UC, cD, IOException {
        Iterator<? extends hC> it = list.iterator();
        while (it.hasNext()) {
            m44j6(it.next());
        }
    }

    public void m50j6(boolean z) {
        if (z && this.f17XL == null) {
            m17FH();
            this.f17XL = new BC(this.f15VH);
        } else {
            if (z) {
                return;
            }
            this.f17XL = null;
        }
    }
}
