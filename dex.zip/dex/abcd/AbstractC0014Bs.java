package abcd;

public abstract class AbstractC0014Bs extends AbstractC0100Ds {

    private final int f50j6;

    AbstractC0014Bs(int i) {
        this.f50j6 = i;
    }

    protected int m63DW(ms msVar) {
        int i = ((AbstractC0014Bs) msVar).f50j6;
        int i2 = this.f50j6;
        if (i2 < i) {
            return -1;
        }
        return i2 > i ? 1 : 0;
    }

    public final boolean m64Hw() {
        return false;
    }

    @Override
    public final boolean mo65J8() {
        return true;
    }

    @Override
    public final int mo66Ws() {
        return this.f50j6;
    }

    public final boolean equals(Object obj) {
        return obj != null && getClass() == obj.getClass() && this.f50j6 == ((AbstractC0014Bs) obj).f50j6;
    }

    public final int hashCode() {
        return this.f50j6;
    }

    @Override
    public final long mo67lg() {
        return this.f50j6;
    }
}
