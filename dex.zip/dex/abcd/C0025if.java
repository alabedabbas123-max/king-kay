package abcd;

import com.aide.common.u;
import com.aide.ui.U;

@xu
public class C0025if implements Yl, Wl {

    @uu
    private static boolean f103DW;

    @tu
    private static boolean f104j6;

    static {
        wu.j6(C0025if.class, -1619458810673187915L, -1619458810673187915L);
    }

    public C0025if() {
        try {
            if (f104j6) {
                wu.j6(-331156989405986500L, (Object) null);
            }
        } catch (Throwable th) {
            if (f103DW) {
                wu.j6(th, -331156989405986500L, (Object) null);
            }
            throw th;
        }
    }

    public u m117FH() {
        try {
            if (f104j6) {
                wu.j6(557581486104066765L, this);
            }
            return new u(31, true, true, false);
        } catch (Throwable th) {
            if (f103DW) {
                wu.j6(th, 557581486104066765L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f104j6) {
                return "Create Constructor";
            }
            wu.j6(-1606067931205857876L, this);
            return "Create Constructor";
        } catch (Throwable th) {
            if (f103DW) {
                wu.j6(th, -1606067931205857876L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f104j6) {
                wu.j6(2177633309727990992L, this);
            }
            return U.er().VH() && U.er().gn();
        } catch (Throwable th) {
            if (f103DW) {
                wu.j6(th, 2177633309727990992L, this);
            }
            throw th;
        }
    }

    public int m118j6() {
        try {
            if (!f104j6) {
                return com.aide.pro.R.id.editorMenuCreateConstructor;
            }
            wu.j6(3082277452532868832L, this);
            return com.aide.pro.R.id.editorMenuCreateConstructor;
        } catch (Throwable th) {
            if (f103DW) {
                wu.j6(th, 3082277452532868832L, this);
            }
            throw th;
        }
    }

    public boolean m119run() {
        try {
            if (f104j6) {
                wu.j6(1986205005873880976L, this);
            }
            Tl currentFileSpan = U.lg().J8().getCurrentFileSpan();
            U.lg().cb();
            U.EQ().j6(currentFileSpan.FH, currentFileSpan.Hw, currentFileSpan.v5, currentFileSpan.Zo, currentFileSpan.VH);
            return true;
        } catch (Throwable th) {
            if (f103DW) {
                wu.j6(th, 1986205005873880976L, this);
            }
            throw th;
        }
    }
}
