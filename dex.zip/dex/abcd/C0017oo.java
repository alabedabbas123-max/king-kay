package abcd;

public final class C0017oo extends AbstractC0102qo {

    private final Sn[] f88VH;

    private final au f89Zo;

    private final boolean f90gn;

    private final Sn f91v5;

    public C0017oo(hs hsVar, Sn sn, au auVar, Sn[] snArr) {
        super(hsVar, cs.FH);
        if (sn == null) {
            throw new NullPointerException("user == null");
        }
        if (auVar == null) {
            throw new NullPointerException("cases == null");
        }
        if (snArr == null) {
            throw new NullPointerException("targets == null");
        }
        int size = auVar.size();
        if (size != snArr.length) {
            throw new IllegalArgumentException("cases / targets mismatch");
        }
        if (size > 65535) {
            throw new IllegalArgumentException("too many cases");
        }
        this.f91v5 = sn;
        this.f89Zo = auVar;
        this.f88VH = snArr;
        this.f90gn = m52DW(auVar);
    }

    private static boolean m52DW(au auVar) {
        if (auVar.size() < 2) {
            return true;
        }
        long jM54j6 = m54j6(auVar);
        return jM54j6 >= 0 && jM54j6 <= (m53FH(auVar) * 5) / 4;
    }

    private static long m53FH(au auVar) {
        return (((long) auVar.size()) * 4) + 2;
    }

    private static long m54j6(au auVar) {
        long j = (((((long) auVar.get(auVar.size() - 1)) - ((long) auVar.get(0))) + 1) * 2) + 4;
        if (j <= 2147483647L) {
            return j;
        }
        return -1L;
    }

    public int m55DW() {
        return (int) (this.f90gn ? m54j6(this.f89Zo) : m53FH(this.f89Zo));
    }

    public Vn m56j6(cs csVar) {
        return new C0017oo(VH(), this.f91v5, this.f89Zo, this.f88VH);
    }

    protected String m57j6() {
        StringBuffer stringBuffer = new StringBuffer(100);
        int length = this.f88VH.length;
        for (int i = 0; i < length; i++) {
            stringBuffer.append("\n    ");
            stringBuffer.append(this.f89Zo.get(i));
            stringBuffer.append(": ");
            stringBuffer.append(this.f88VH[i]);
        }
        return stringBuffer.toString();
    }

    protected String m58j6(boolean z) {
        int iFH = this.f91v5.FH();
        StringBuffer stringBuffer = new StringBuffer(100);
        int length = this.f88VH.length;
        stringBuffer.append(this.f90gn ? "packed" : "sparse");
        stringBuffer.append("-switch-payload // for switch @ ");
        stringBuffer.append(Yt.v5(iFH));
        for (int i = 0; i < length; i++) {
            int iFH2 = this.f88VH[i].FH();
            stringBuffer.append("\n  ");
            stringBuffer.append(this.f89Zo.get(i));
            stringBuffer.append(": ");
            stringBuffer.append(Yt.gn(iFH2));
            stringBuffer.append(" // ");
            stringBuffer.append(Yt.FH(iFH2 - iFH));
        }
        return stringBuffer.toString();
    }

    public void m59j6(Lt lt) {
        int iFH;
        int iFH2 = this.f91v5.FH();
        int iJ6 = Yn.I.DW().j6();
        int length = this.f88VH.length;
        int i = 0;
        if (!this.f90gn) {
            lt.writeShort(512);
            lt.writeShort(length);
            for (int i2 = 0; i2 < length; i2++) {
                lt.writeInt(this.f89Zo.get(i2));
            }
            while (i < length) {
                lt.writeInt(this.f88VH[i].FH() - iFH2);
                i++;
            }
            return;
        }
        int i3 = length == 0 ? 0 : this.f89Zo.get(0);
        int i4 = ((length == 0 ? 0 : this.f89Zo.get(length - 1)) - i3) + 1;
        lt.writeShort(256);
        lt.writeShort(i4);
        lt.writeInt(i3);
        int i5 = 0;
        while (i < i4) {
            if (this.f89Zo.get(i5) > i3 + i) {
                iFH = iJ6;
            } else {
                iFH = this.f88VH[i5].FH() - iFH2;
                i5++;
            }
            lt.writeInt(iFH);
            i++;
        }
    }

    public boolean m60we() {
        return this.f90gn;
    }
}
