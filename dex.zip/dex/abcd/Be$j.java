package abcd;

@xu
public class Be$j {

    @uu
    private static boolean f476DW;

    @tu
    private static boolean f477j6;

    public String f478FH;

    public String f479Hw;

    @vu
    final Be f480VH;

    public String f481Zo;

    public String f482v5;

    static {
        wu.j6(Be$j.class, 1619696761456734831L, 1619696761456734831L);
    }

    public Be$j(Be be) {
        try {
            if (f477j6) {
                wu.j6(-2047864970191742275L, (Object) null, be);
            }
            this.f480VH = be;
            this.f478FH = "";
            this.f479Hw = "";
            this.f482v5 = "";
            this.f481Zo = "";
        } catch (Throwable th) {
            if (f476DW) {
                wu.j6(th, -2047864970191742275L, (Object) null, be);
            }
            throw th;
        }
    }

    public String m1282j6() {
        try {
            if (f477j6) {
                wu.j6(2248348190133264L, this);
            }
            return Vl.VH(Vl.EQ(((Si) this.f480VH).v5), this.f478FH);
        } catch (Throwable th) {
            if (f476DW) {
                wu.j6(th, 2248348190133264L, this);
            }
            throw th;
        }
    }
}
