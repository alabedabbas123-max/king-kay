package abcd;

import java.io.IOException;

public abstract class AbstractC0033LL extends EL implements InterfaceC0076ML {

    boolean f125DW = false;

    boolean f126FH;

    qL f127Hw;

    int f128j6;

    public AbstractC0033LL(boolean z, int i, qL qLVar) {
        this.f126FH = true;
        this.f127Hw = null;
        if (qLVar instanceof pL) {
            this.f126FH = true;
        } else {
            this.f126FH = z;
        }
        this.f128j6 = i;
        if (this.f126FH) {
            this.f127Hw = qLVar;
        } else {
            boolean z2 = qLVar.DW() instanceof HL;
            this.f127Hw = qLVar;
        }
    }

    public static AbstractC0033LL m168j6(Object obj) {
        if (obj == null || (obj instanceof AbstractC0033LL)) {
            return (AbstractC0033LL) obj;
        }
        if (!(obj instanceof byte[])) {
            throw new IllegalArgumentException("unknown object in getInstance: " + obj.getClass().getName());
        }
        try {
            return m168j6((Object) EL.j6((byte[]) obj));
        } catch (IOException e) {
            throw new IllegalArgumentException("failed to construct tagged object from byte[]: " + e.getMessage());
        }
    }

    public boolean m169EQ() {
        return this.f125DW;
    }

    EL m170VH() {
        return new yM(this.f126FH, this.f128j6, this.f127Hw);
    }

    EL m171gn() {
        return new GM(this.f126FH, this.f128j6, this.f127Hw);
    }

    public int hashCode() {
        int i = this.f128j6;
        qL qLVar = this.f127Hw;
        return qLVar != null ? i ^ qLVar.hashCode() : i;
    }

    public EL m172j6() {
        DW();
        return this;
    }

    boolean m173j6(EL el) {
        if (!(el instanceof AbstractC0033LL)) {
            return false;
        }
        AbstractC0033LL abstractC0033LL = (AbstractC0033LL) el;
        if (this.f128j6 != abstractC0033LL.f128j6 || this.f125DW != abstractC0033LL.f125DW || this.f126FH != abstractC0033LL.f126FH) {
            return false;
        }
        qL qLVar = this.f127Hw;
        if (qLVar == null) {
            return abstractC0033LL.f127Hw == null;
        }
        return qLVar.DW().equals(abstractC0033LL.f127Hw.DW());
    }

    public String toString() {
        return "[" + this.f128j6 + "]" + this.f127Hw;
    }

    public int m174tp() {
        return this.f128j6;
    }

    public EL m175u7() {
        qL qLVar = this.f127Hw;
        if (qLVar != null) {
            return qLVar.DW();
        }
        return null;
    }

    public boolean m176we() {
        return this.f126FH;
    }
}
