package abcd;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.eclipse.jgit.JGitText;

public class C0004_F extends qG {

    private a f0Mr;

    private NF f1QX;

    private byte[] f2U2;

    private List<iG> f3Ws;

    private dG f4XL;

    private int f5a8;

    private dG f6aM;

    private a f7j3;

    private boolean f8lg;

    private static class a {

        iG f9DW;

        byte[] f10FH;

        int f11Hw;

        int f12VH;

        int f13Zo;

        a f14j6;

        int f15v5;

        private a() {
        }

        a(a aVar) {
            this();
        }
    }

    public C0004_F(IE ie) {
        super(ie);
        this.f3Ws = new ArrayList();
        this.f1QX = new NF();
        this.f2U2 = new byte[256];
    }

    public C0004_F(UE ue) {
        this(ue.j3());
    }

    private int m4DW(a aVar) {
        if (aVar == null) {
            return 0;
        }
        int i = aVar.f13Zo;
        if (i == 0) {
            return m4DW(aVar.f14j6);
        }
        int iM4DW = aVar.f12VH;
        if (iM4DW == 0) {
            iM4DW = m4DW(aVar.f14j6);
            if (iM4DW == this.f2U2.length) {
                m6VH(iM4DW);
            }
            if (iM4DW != 0) {
                this.f2U2[iM4DW] = 47;
                iM4DW++;
            }
            aVar.f12VH = iM4DW;
        }
        int i2 = aVar.f15v5;
        int i3 = i - i2;
        int i4 = iM4DW + i3;
        while (true) {
            byte[] bArr = this.f2U2;
            if (bArr.length >= i4) {
                System.arraycopy(aVar.f10FH, i2, bArr, iM4DW, i3);
                return i4;
            }
            m6VH(iM4DW);
        }
    }

    private iG m5VH(iG iGVar) {
        a aVarM8gn = m8gn(iGVar);
        aVarM8gn.f14j6 = this.f0Mr;
        this.f0Mr = aVarM8gn;
        return iGVar;
    }

    private void m6VH(int i) {
        byte[] bArr = this.f2U2;
        byte[] bArr2 = new byte[bArr.length << 1];
        System.arraycopy(bArr, 0, bArr2, 0, i);
        this.f2U2 = bArr2;
    }

    private void m7Zo(iG iGVar) {
        int i = iGVar.EQ;
        if ((i & 8) == 0) {
            iGVar.EQ = i | 8;
            this.f3Ws.add(iGVar);
            this.f1QX.j6(iGVar);
        }
    }

    private a m8gn(iG iGVar) {
        a aVar = this.f7j3;
        if (aVar != null) {
            this.f7j3 = aVar.f14j6;
            aVar.f11Hw = 0;
            aVar.f15v5 = 0;
            aVar.f13Zo = 0;
            aVar.f12VH = 0;
        } else {
            aVar = new a(null);
        }
        aVar.f9DW = iGVar;
        aVar.f10FH = ((qG) this).DW.Hw(iGVar, 2).j6();
        return aVar;
    }

    private static int m9j6(byte[] bArr, int i) {
        do {
            int i2 = i + 1;
            if (bArr[i2] == 0) {
                return i2 + 1;
            }
            int i3 = i2 + 1;
            if (bArr[i3] == 0) {
                return i3 + 1;
            }
            int i4 = i3 + 1;
            if (bArr[i4] == 0) {
                return i4 + 1;
            }
            int i5 = i4 + 1;
            if (bArr[i5] == 0) {
                return i5 + 1;
            }
            int i6 = i5 + 1;
            if (bArr[i6] == 0) {
                return i6 + 1;
            }
            int i7 = i6 + 1;
            if (bArr[i7] == 0) {
                return i7 + 1;
            }
            int i8 = i7 + 1;
            if (bArr[i8] == 0) {
                return i8 + 1;
            }
            int i9 = i8 + 1;
            if (bArr[i9] == 0) {
                return i9 + 1;
            }
            int i10 = i9 + 1;
            if (bArr[i10] == 0) {
                return i10 + 1;
            }
            int i11 = i10 + 1;
            if (bArr[i11] == 0) {
                return i11 + 1;
            }
            int i12 = i11 + 1;
            if (bArr[i12] == 0) {
                return i12 + 1;
            }
            int i13 = i12 + 1;
            if (bArr[i13] == 0) {
                return i13 + 1;
            }
            int i14 = i13 + 1;
            if (bArr[i14] == 0) {
                return i14 + 1;
            }
            int i15 = i14 + 1;
            if (bArr[i15] == 0) {
                return i15 + 1;
            }
            int i16 = i15 + 1;
            if (bArr[i16] == 0) {
                return i16 + 1;
            }
            i = i16 + 1;
        } while (bArr[i] != 0);
        return i + 1;
    }

    private static int m10j6(byte[] bArr, int i, int i2, a aVar) {
        int i3 = bArr[i] - 48;
        while (true) {
            i++;
            byte b = bArr[i];
            if (32 == b) {
                break;
            }
            i3 = (i3 << 3) + (b - 48);
            i++;
            byte b2 = bArr[i];
            if (32 == b2) {
                break;
            }
            i3 = (i3 << 3) + (b2 - 48);
            i++;
            byte b3 = bArr[i];
            if (32 == b3) {
                break;
            }
            i3 = (i3 << 3) + (b3 - 48);
            i++;
            byte b4 = bArr[i];
            if (32 == b4) {
                break;
            }
            i3 = (i3 << 3) + (b4 - 48);
            i++;
            byte b5 = bArr[i];
            if (32 == b5) {
                break;
            }
            i3 = (i3 << 3) + (b5 - 48);
            i++;
            byte b6 = bArr[i];
            if (32 == b6) {
                break;
            }
            i3 = (i3 << 3) + (b6 - 48);
            i++;
            byte b7 = bArr[i];
            if (32 == b7) {
                break;
            }
            i3 = (i3 << 3) + (b7 - 48);
        }
        aVar.f11Hw = i2;
        aVar.f15v5 = i + 1;
        aVar.f13Zo = i2 - 21;
        return i3;
    }

    private void m11j6(a aVar) {
        aVar.f10FH = null;
        aVar.f14j6 = this.f7j3;
        this.f7j3 = aVar;
    }

    private void m12j6(mG mGVar) throws YC {
        int i = ((iG) mGVar).EQ;
        if ((i & 4) != 0) {
            return;
        }
        ((iG) mGVar).EQ = i | 4;
        byte[] bArrJ6 = ((qG) this).DW.Hw(mGVar, 2).j6();
        int i2 = 0;
        while (i2 < bArrJ6.length) {
            int i3 = bArrJ6[i2] - 48;
            while (true) {
                i2++;
                byte b = bArrJ6[i2];
                if (32 == b) {
                    break;
                } else {
                    i3 = (i3 << 3) + (b - 48);
                }
            }
            do {
                i2++;
            } while (bArrJ6[i2] != 0);
            int i4 = i2 + 1;
            int i5 = i3 >>> 12;
            if (i5 == 4) {
                ((qG) this).FH.Hw(bArrJ6, i4);
                m12j6(v5(((qG) this).FH));
            } else if (i5 == 8 || i5 == 10) {
                ((qG) this).FH.Hw(bArrJ6, i4);
                ((iG) DW(((qG) this).FH)).EQ |= 4;
            } else if (i5 != 14) {
                ((qG) this).FH.Hw(bArrJ6, i4);
                throw new YC(MessageFormat.format(JGitText.j6().corruptObjectInvalidMode3, String.format("%o", Integer.valueOf(i3)), ((qG) this).FH.we(), "", mGVar));
            }
            i2 = i4 + 20;
        }
    }

    public void m13DW(kG kGVar) {
        super.DW(kGVar);
        this.f8lg = j6(kG.v5);
    }

    public void m14Hw(iG iGVar) {
        while (iGVar instanceof lG) {
            m7Zo(iGVar);
            iGVar = ((lG) iGVar).j3();
            DW(iGVar);
        }
        if (iGVar instanceof dG) {
            super.DW((dG) iGVar);
        } else {
            m7Zo(iGVar);
        }
    }

    public void m15J8() throws fD, ZC, YC {
        while (m21tp() != null) {
        }
        while (true) {
            iG iGVarM24yS = m24yS();
            if (iGVarM24yS == null) {
                return;
            }
            if ((iGVarM24yS instanceof cG) && !((qG) this).DW.DW(iGVarM24yS)) {
                throw new fD(iGVarM24yS, 3);
            }
        }
    }

    public int m16QX() {
        byte[] bArr;
        int iMax;
        a aVar = this.f0Mr;
        int i = 0;
        if (aVar == null) {
            return 0;
        }
        int i2 = aVar.f13Zo;
        if (i2 == 0) {
            aVar = aVar.f14j6;
            if (aVar == null) {
                return 0;
            }
            i2 = aVar.f13Zo;
        }
        if (16 <= i2 - aVar.f15v5) {
            bArr = aVar.f10FH;
            iMax = i2 - 16;
        } else {
            int iM4DW = this.f5a8;
            if (iM4DW == 0) {
                iM4DW = m4DW(this.f0Mr);
                this.f5a8 = iM4DW;
            }
            i2 = iM4DW;
            bArr = this.f2U2;
            iMax = Math.max(0, i2 - 16);
        }
        while (iMax < i2) {
            byte b = bArr[iMax];
            if (b != 32) {
                i = (i >>> 2) + (b << 24);
            }
            iMax++;
        }
        return i;
    }

    public byte[] m17Ws() {
        if (this.f5a8 == 0) {
            this.f5a8 = m4DW(this.f0Mr);
        }
        return this.f2U2;
    }

    public int m18XL() {
        if (this.f5a8 == 0) {
            this.f5a8 = m4DW(this.f0Mr);
        }
        return this.f5a8;
    }

    protected void m19Zo(int i) {
        super.Zo(i);
        Iterator<iG> it = this.f3Ws.iterator();
        while (it.hasNext()) {
            it.next().EQ &= -9;
        }
        this.f3Ws = new ArrayList();
        this.f1QX = new NF();
        this.f4XL = null;
        this.f6aM = null;
        this.f0Mr = null;
        this.f7j3 = null;
    }

    public void m20j6(kG kGVar, boolean z) {
        super.j6(kGVar, z);
        this.f8lg = j6(kG.v5);
    }

    public dG m21tp() throws YC {
        dG dGVarTp;
        do {
            dGVarTp = super.tp();
            if (dGVarTp == null) {
                dG dGVar = this.f4XL;
                if (dGVar == null) {
                    return null;
                }
                ((qG) this).DW.j6(this, dGVar, this.f6aM);
                return null;
            }
            if ((((iG) dGVarTp).EQ & 4) == 0) {
                if (this.f4XL == null) {
                    this.f4XL = dGVarTp;
                }
                this.f6aM = dGVarTp;
                this.f1QX.j6(dGVarTp.yS());
                return dGVarTp;
            }
            m12j6(dGVarTp.yS());
        } while (!this.f8lg);
        return dGVarTp;
    }

    public void m22v5() {
        super.v5();
        this.f1QX = new NF();
        this.f4XL = null;
        this.f6aM = null;
        this.f0Mr = null;
        this.f7j3 = null;
    }

    public void m23v5(iG iGVar) throws YC {
        while (iGVar instanceof lG) {
            iGVar.EQ |= 4;
            if (this.f8lg) {
                m7Zo(iGVar);
            }
            iGVar = ((lG) iGVar).j3();
            DW(iGVar);
        }
        if (iGVar instanceof dG) {
            super.FH((dG) iGVar);
        } else if (iGVar instanceof mG) {
            m12j6((mG) iGVar);
        } else {
            iGVar.EQ |= 4;
        }
        if (iGVar.aM() == 1 || !this.f8lg) {
            return;
        }
        m7Zo(iGVar);
    }

    public iG m24yS() throws ZC, YC {
        this.f5a8 = 0;
        a aVar = this.f0Mr;
        while (aVar != null) {
            byte[] bArr = aVar.f10FH;
            int i = aVar.f11Hw;
            while (i < bArr.length) {
                int iM9j6 = m9j6(bArr, i);
                ((qG) this).FH.Hw(bArr, iM9j6);
                int i2 = iM9j6 + 20;
                iG iGVar = (iG) ((qG) this).Hw.DW(((qG) this).FH);
                if (iGVar == null || (iGVar.EQ & 2) == 0) {
                    int iM10j6 = m10j6(bArr, i, i2, aVar);
                    int i3 = iM10j6 >>> 12;
                    if (i3 != 4) {
                        if (i3 == 8 || i3 == 10) {
                            if (iGVar == null) {
                                cG cGVar = new cG(((qG) this).FH);
                                ((iG) cGVar).EQ = 2;
                                ((qG) this).Hw.j6(cGVar);
                                return cGVar;
                            }
                            if (!(iGVar instanceof cG)) {
                                throw new ZC(iGVar, 3);
                            }
                            int i4 = iGVar.EQ | 2;
                            iGVar.EQ = i4;
                            if ((i4 & 4) == 0 || this.f8lg) {
                                return iGVar;
                            }
                        } else if (i3 != 14) {
                            throw new YC(MessageFormat.format(JGitText.j6().corruptObjectInvalidMode3, String.format("%o", Integer.valueOf(iM10j6)), ((qG) this).FH.we(), IK.j6(bArr, aVar.f15v5, aVar.f13Zo), aVar.f9DW));
                        }
                    } else {
                        if (iGVar == null) {
                            mG mGVar = new mG(((qG) this).FH);
                            ((iG) mGVar).EQ = 2;
                            ((qG) this).Hw.j6(mGVar);
                            m5VH((iG) mGVar);
                            return mGVar;
                        }
                        if (!(iGVar instanceof mG)) {
                            throw new ZC(iGVar, 2);
                        }
                        int i5 = iGVar.EQ | 2;
                        iGVar.EQ = i5;
                        if ((i5 & 4) == 0) {
                            m5VH(iGVar);
                            return iGVar;
                        }
                        if (this.f8lg) {
                            m5VH(iGVar);
                            return iGVar;
                        }
                    }
                }
                i = i2;
            }
            this.f0Mr = aVar.f14j6;
            m11j6(aVar);
            aVar = this.f0Mr;
        }
        while (true) {
            iG iGVarJ6 = this.f1QX.j6();
            if (iGVarJ6 == null) {
                ((qG) this).DW.Hw();
                return null;
            }
            int i6 = iGVarJ6.EQ;
            if ((i6 & 2) == 0) {
                int i7 = i6 | 2;
                iGVarJ6.EQ = i7;
                if (((i7 & 4) == 0) | this.f8lg) {
                    if (iGVarJ6 instanceof mG) {
                        a aVarM8gn = m8gn(iGVarJ6);
                        aVarM8gn.f14j6 = null;
                        this.f0Mr = aVarM8gn;
                    }
                    return iGVarJ6;
                }
            }
        }
    }
}
