package abcd;

import java.io.File;
import java.io.FileNotFoundException;

public abstract class AbstractC0003cC {

    private static class a extends AbstractC0003cC {

        private final File f5j6;

        a(File file) {
            this.f5j6 = file;
        }

        @Override
        public long mo34DW(String str, yE yEVar) {
            return new File(this.f5j6, str).length();
        }

        @Override
        public FE mo35j6(String str, yE yEVar) throws FileNotFoundException {
            File file = new File(this.f5j6, str);
            if (file.isFile()) {
                return new bC(this, file);
            }
            throw new FileNotFoundException(str);
        }
    }

    private static class b extends AbstractC0003cC {

        private final IE f6j6;

        b(IE ie) {
            this.f6j6 = ie;
        }

        @Override
        public long mo34DW(String str, yE yEVar) {
            return this.f6j6.DW(yEVar, 3);
        }

        @Override
        public FE mo35j6(String str, yE yEVar) {
            return this.f6j6.Hw(yEVar, 3);
        }
    }

    public static final class c {

        private static int[] f7j6;

        private final AbstractC0003cC f8DW;

        private final AbstractC0003cC f9FH;

        public c(AbstractC0003cC abstractC0003cC, AbstractC0003cC abstractC0003cC2) {
            this.f8DW = abstractC0003cC;
            this.f9FH = abstractC0003cC2;
        }

        static int[] m36j6() {
            int[] iArr = f7j6;
            if (iArr != null) {
                return iArr;
            }
            int[] iArr2 = new int[hC.b.values().length];
            try {
                iArr2[hC.b.DW.ordinal()] = 2;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr2[hC.b.j6.ordinal()] = 1;
            } catch (NoSuchFieldError unused2) {
            }
            f7j6 = iArr2;
            return iArr2;
        }

        public long m37DW(hC.b bVar, hC hCVar) {
            int i = m36j6()[bVar.ordinal()];
            if (i == 1) {
                return this.f8DW.mo34DW(hCVar.FH, hCVar.u7.v5());
            }
            if (i == 2) {
                return this.f9FH.mo34DW(hCVar.Hw, hCVar.tp.v5());
            }
            throw new IllegalArgumentException();
        }

        public FE m38j6(hC.b bVar, hC hCVar) {
            int i = m36j6()[bVar.ordinal()];
            if (i == 1) {
                return this.f8DW.mo35j6(hCVar.FH, hCVar.u7.v5());
            }
            if (i == 2) {
                return this.f9FH.mo35j6(hCVar.Hw, hCVar.tp.v5());
            }
            throw new IllegalArgumentException();
        }
    }

    static class d extends AbstractC0003cC {

        private final _J f10DW;

        private String f11FH;

        private _J f12Hw;

        private final YJ f13j6 = new YJ((IE) null);

        d(_J _j) {
            this.f10DW = _j;
        }

        private void m40j6(String str) throws FileNotFoundException {
            if (str.equals(this.f11FH)) {
                return;
            }
            this.f10DW.EQ();
            this.f13j6.J8();
            this.f13j6.j6(this.f10DW);
            this.f13j6.j6(fK.j6(str));
            this.f11FH = str;
            if (!this.f13j6.EQ()) {
                throw new FileNotFoundException(str);
            }
            this.f12Hw = this.f13j6.j6(0, _J.class);
            if (this.f12Hw == null) {
                throw new FileNotFoundException(str);
            }
        }

        @Override
        public long mo34DW(String str, yE yEVar) throws FileNotFoundException {
            m40j6(str);
            return this.f12Hw.j3();
        }

        @Override
        public FE mo35j6(String str, yE yEVar) throws FileNotFoundException {
            m40j6(str);
            return new C0047dC(this);
        }
    }

    public static AbstractC0003cC m32j6(IE ie) {
        return new b(ie);
    }

    public static AbstractC0003cC m33j6(_J _j) {
        return _j instanceof WJ ? new a(((WJ) _j).lg()) : new d(_j);
    }

    public abstract long mo34DW(String str, yE yEVar);

    public abstract FE mo35j6(String str, yE yEVar);
}
