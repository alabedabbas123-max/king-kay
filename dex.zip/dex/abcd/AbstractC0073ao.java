package abcd;

import java.util.BitSet;

public abstract class AbstractC0073ao {

    public static boolean f351j6 = true;

    protected static int m490DW(int i, int i2) {
        if ((i & 15) != i) {
            throw new IllegalArgumentException("low out of range 0..15");
        }
        if ((i2 & 15) == i2) {
            return i | (i2 << 4);
        }
        throw new IllegalArgumentException("high out of range 0..15");
    }

    protected static String m491DW(Vn vn) {
        int iJ0 = ((po) vn).J0();
        return iJ0 == ((char) iJ0) ? Yt.v5(iJ0) : Yt.gn(iJ0);
    }

    protected static String m492DW(cs csVar) {
        int size = csVar.size();
        StringBuffer stringBuffer = new StringBuffer((size * 5) + 2);
        stringBuffer.append('{');
        for (int i = 0; i < size; i++) {
            if (i != 0) {
                stringBuffer.append(", ");
            }
            stringBuffer.append(csVar.get(i).m847lg());
        }
        stringBuffer.append('}');
        return stringBuffer.toString();
    }

    protected static boolean m493DW(int i) {
        return i >= -8 && i <= 7;
    }

    protected static String m494FH(cs csVar) {
        int size = csVar.size();
        StringBuilder sb = new StringBuilder(30);
        sb.append("{");
        if (size != 0) {
            if (size != 1) {
                C0121bs c0121bsM829DW = csVar.get(size - 1);
                if (c0121bsM829DW.m833Hw() == 2) {
                    c0121bsM829DW = c0121bsM829DW.m829DW(1);
                }
                sb.append(csVar.get(0).m847lg());
                sb.append("..");
                sb.append(c0121bsM829DW.m847lg());
            } else {
                sb.append(csVar.get(0).m847lg());
            }
        }
        sb.append("}");
        return sb.toString();
    }

    protected static boolean m495FH(int i) {
        return ((short) i) == i;
    }

    protected static String m496Hw(Vn vn) {
        Tn tn = (Tn) vn;
        if (!tn.J8()) {
            return "";
        }
        StringBuilder sb = new StringBuilder(20);
        int iJ0 = tn.J0();
        sb.append(tn.we().Zo());
        sb.append('@');
        if (iJ0 < 65536) {
            sb.append(Yt.v5(iJ0));
        } else {
            sb.append(Yt.gn(iJ0));
        }
        return sb.toString();
    }

    protected static boolean m497Hw(int i) {
        return i == (i & 255);
    }

    protected static boolean m498Zo(int i) {
        return i == (65535 & i);
    }

    protected static short m499gn(Vn vn) {
        int iV5 = vn.Zo().v5();
        if (iV5 < 255 || iV5 > 65535) {
            throw new IllegalArgumentException("extended opcode out of range 255..65535");
        }
        return (short) iV5;
    }

    protected static String m500j6(Ds ds) {
        StringBuffer stringBuffer = new StringBuffer(100);
        stringBuffer.append('#');
        if (ds instanceof As) {
            stringBuffer.append("null");
        } else {
            stringBuffer.append(ds.Zo());
            stringBuffer.append(' ');
            stringBuffer.append(ds.aM());
        }
        return stringBuffer.toString();
    }

    protected static String m501j6(Ds ds, int i) {
        StringBuffer stringBuffer = new StringBuffer(20);
        stringBuffer.append("#");
        long jLg = ds instanceof Cs ? ((Cs) ds).lg() : ds.Ws();
        if (i == 4) {
            stringBuffer.append(Yt.u7((int) jLg));
        } else if (i == 8) {
            stringBuffer.append(Yt.Hw((int) jLg));
        } else if (i == 16) {
            stringBuffer.append(Yt.v5((int) jLg));
        } else if (i == 32) {
            stringBuffer.append(Yt.gn((int) jLg));
        } else {
            if (i != 64) {
                throw new RuntimeException("shouldn't happen");
            }
            stringBuffer.append(Yt.DW(jLg));
        }
        return stringBuffer.toString();
    }

    protected static String m502j6(Vn vn) {
        int iJ8 = ((po) vn).J8();
        return iJ8 == ((short) iJ8) ? Yt.DW(iJ8) : Yt.FH(iJ8);
    }

    protected static short m503j6(int i, int i2) {
        if ((i & 255) != i) {
            throw new IllegalArgumentException("low out of range 0..255");
        }
        if ((i2 & 255) == i2) {
            return (short) (i | (i2 << 8));
        }
        throw new IllegalArgumentException("high out of range 0..255");
    }

    protected static short m504j6(int i, int i2, int i3, int i4) {
        if ((i & 15) != i) {
            throw new IllegalArgumentException("n0 out of range 0..15");
        }
        if ((i2 & 15) != i2) {
            throw new IllegalArgumentException("n1 out of range 0..15");
        }
        if ((i3 & 15) != i3) {
            throw new IllegalArgumentException("n2 out of range 0..15");
        }
        if ((i4 & 15) == i4) {
            return (short) (i | (i2 << 4) | (i3 << 8) | (i4 << 12));
        }
        throw new IllegalArgumentException("n3 out of range 0..15");
    }

    protected static short m505j6(Vn vn, int i) {
        if ((i & 255) != i) {
            throw new IllegalArgumentException("arg out of range 0..255");
        }
        int iV5 = vn.Zo().v5();
        if ((iV5 & 255) == iV5) {
            return (short) (iV5 | (i << 8));
        }
        throw new IllegalArgumentException("opcode out of range 0..255");
    }

    protected static void m506j6(Lt lt, short s) {
        lt.writeShort(s);
    }

    protected static void m507j6(Lt lt, short s, int i) {
        m512j6(lt, s, (short) i, (short) (i >> 16));
    }

    protected static void m508j6(Lt lt, short s, int i, short s2) {
        m513j6(lt, s, (short) i, (short) (i >> 16), s2);
    }

    protected static void m509j6(Lt lt, short s, int i, short s2, short s3) {
        m514j6(lt, s, (short) i, (short) (i >> 16), s2, s3);
    }

    protected static void m510j6(Lt lt, short s, long j) {
        m514j6(lt, s, (short) j, (short) (j >> 16), (short) (j >> 32), (short) (j >> 48));
    }

    protected static void m511j6(Lt lt, short s, short s2) {
        lt.writeShort(s);
        lt.writeShort(s2);
    }

    protected static void m512j6(Lt lt, short s, short s2, short s3) {
        lt.writeShort(s);
        lt.writeShort(s2);
        lt.writeShort(s3);
    }

    protected static void m513j6(Lt lt, short s, short s2, short s3, short s4) {
        lt.writeShort(s);
        lt.writeShort(s2);
        lt.writeShort(s3);
        lt.writeShort(s4);
    }

    protected static void m514j6(Lt lt, short s, short s2, short s3, short s4, short s5) {
        lt.writeShort(s);
        lt.writeShort(s2);
        lt.writeShort(s3);
        lt.writeShort(s4);
        lt.writeShort(s5);
    }

    protected static boolean m515j6(int i) {
        return ((byte) i) == i;
    }

    protected static boolean m516j6(cs csVar) {
        int size = csVar.size();
        if (size < 2) {
            return true;
        }
        int iM849we = csVar.get(0).m849we();
        for (int i = 0; i < size; i++) {
            C0121bs c0121bs = csVar.get(i);
            if (c0121bs.m849we() != iM849we) {
                return false;
            }
            iM849we += c0121bs.m833Hw();
        }
        return true;
    }

    protected static String m517v5(Vn vn) {
        Js jsWe = ((Tn) vn).we();
        return jsWe instanceof Js ? jsWe.lg() : jsWe.aM();
    }

    protected static boolean m518v5(int i) {
        return i == (i & 15);
    }

    public final String m519DW(Vn vn, boolean z) {
        String strFH = vn.Zo().FH();
        String strM522Zo = m522Zo(vn);
        String strM524j6 = m524j6(vn, z);
        StringBuilder sb = new StringBuilder(100);
        sb.append(strFH);
        if (strM522Zo.length() != 0) {
            sb.append(' ');
            sb.append(strM522Zo);
        }
        if (strM524j6.length() != 0) {
            sb.append(" // ");
            sb.append(strM524j6);
        }
        return sb.toString();
    }

    public BitSet m520FH(Vn vn) {
        return new BitSet();
    }

    public abstract boolean m521VH(Vn vn);

    public abstract String m522Zo(Vn vn);

    public abstract int m523j6();

    public abstract String m524j6(Vn vn, boolean z);

    public abstract void m525j6(Lt lt, Vn vn);

    public boolean m526j6(po poVar) {
        return false;
    }
}
