package abcd;

@xu
public class C0018U {

    @uu
    private static boolean f43DW;

    @tu
    private static boolean f44j6;

    @ru(field = -343622854738159964L)
    private final La f45FH;

    static {
        wu.j6(C0018U.class, -5789597647932032315L, -5789597647932032315L);
    }

    public C0018U(La la) {
        try {
            if (f44j6) {
                wu.j6(-631071523601909440L, (Object) null, la);
            }
            this.f45FH = la;
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, -631071523601909440L, (Object) null, la);
            }
            throw th;
        }
    }

    public void m76DW(Da da, int i, int i2) {
        try {
            if (f44j6) {
                wu.j6(521978568430302539L, this, da, new Integer(i), new Integer(i2));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().j6(da);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, 521978568430302539L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m77DW(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f44j6) {
                wu.j6(7456417034316059576L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().FH(da, i, i2, i3, i4);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, 7456417034316059576L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m78FH(Da da, int i, int i2) {
        try {
            if (f44j6) {
                wu.j6(-4764089217219285389L, this, da, new Integer(i), new Integer(i2));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().gn(da, i, i2);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, -4764089217219285389L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m79FH(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f44j6) {
                wu.j6(368125975785454093L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().j6(da, i, i2, i3, i4);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, 368125975785454093L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m80Hw(Da da, int i, int i2) {
        try {
            if (f44j6) {
                wu.j6(-1556730536092197408L, this, da, new Integer(i), new Integer(i2));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().DW(da, i, i2);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, -1556730536092197408L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m81Hw(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f44j6) {
                wu.j6(-1457993501159387168L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().DW(da, i, i2, i3, i4);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, -1457993501159387168L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m82j6(Da da, int i, int i2) {
        try {
            if (f44j6) {
                wu.j6(-2878928566989807524L, this, da, new Integer(i), new Integer(i2));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().v5(da, i, i2);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, -2878928566989807524L, this, da, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m83j6(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f44j6) {
                wu.j6(3829046797111465167L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().Hw(da, i, i2, i3, i4);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, 3829046797111465167L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public void m84j6(Da da, int i, int i2, Ia ia) {
        try {
            if (f44j6) {
                wu.j6(2050448549426892960L, this, da, new Integer(i), new Integer(i2), ia);
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().j6(da, i, i2, ia);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, 2050448549426892960L, this, da, new Integer(i), new Integer(i2), ia);
            }
            throw th;
        }
    }

    public void m85j6(Da da, Da da2, int i, int i2, int i3, int i4) {
        if (f44j6) {
            wu.j6(1335862760388672872L, this, new Object[]{da, da2, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4)});
        }
        Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
        if (saM408FH.J8().u7() != null) {
            saM408FH.J8().u7().j6(da, da2, i, i2, i3, i4);
        }
        this.f45FH.U2.m419j6(saM408FH);
    }

    public void m86j6(Da da, String str) {
        try {
            if (f44j6) {
                wu.j6(1603355071752699051L, this, da, str);
            }
            if (da.gn() != null) {
                for (na naVar : da.gn().v5()) {
                    if (naVar != null && naVar.u7() != null && naVar.u7().j6(str)) {
                        naVar.u7().j6(da, str);
                    }
                }
            }
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, 1603355071752699051L, this, da, str);
            }
            throw th;
        }
    }

    public void m87v5(Da da, int i, int i2, int i3, int i4) {
        try {
            if (f44j6) {
                wu.j6(-2122021433677005871L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            Sa saM408FH = this.f45FH.U2.m408FH(da, i, i2);
            if (saM408FH.J8().u7() != null) {
                saM408FH.J8().u7().v5(da, i, i2, i3, i4);
            }
            this.f45FH.U2.m419j6(saM408FH);
        } catch (Throwable th) {
            if (f43DW) {
                wu.j6(th, -2122021433677005871L, this, da, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }
}
