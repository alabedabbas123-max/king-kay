package abcd;

public final class C0013Kr extends Xt {

    public static final C0013Kr f63FH = new C0013Kr(0);

    public C0013Kr(int i) {
        super(i);
    }

    public static C0013Kr m102j6(C0013Kr c0013Kr, C0013Kr c0013Kr2) {
        int size = c0013Kr.size();
        if (size != c0013Kr2.size()) {
            throw new IllegalArgumentException("list1.size() != list2.size()");
        }
        C0013Kr c0013Kr3 = new C0013Kr(size);
        for (int i = 0; i < size; i++) {
            c0013Kr3.m104j6(i, Jr.j6(c0013Kr.m103get(i), c0013Kr2.m103get(i)));
        }
        c0013Kr3.we();
        return c0013Kr3;
    }

    public Jr m103get(int i) {
        return (Jr) DW(i);
    }

    public void m104j6(int i, Jr jr) {
        jr.Ws();
        j6(i, jr);
    }
}
