package abcd;

import java.security.MessageDigest;
import java.security.Provider;
import java.security.Signature;

public class C0016cP implements aP {

    protected final Provider f51j6;

    public C0016cP(Provider provider) {
        this.f51j6 = provider;
    }

    public MessageDigest m82DW(String str) {
        return MessageDigest.getInstance(str, this.f51j6);
    }

    public Signature m83j6(String str) {
        return Signature.getInstance(str, this.f51j6);
    }
}
