package abcd;

import java.util.Collection;
import java.util.Iterator;

public abstract class AbstractC0088Sp extends Kp {
    public AbstractC0088Sp(String str, jp jpVar, int i) {
        super(str, jpVar, i);
    }

    protected final void m651FH(Lt lt) {
        jp jpVarDW = DW();
        int iJ6 = j6();
        Iterator it = Hw().iterator();
        while (it.hasNext()) {
            ((vp) it.next()).j6(jpVarDW, lt);
            lt.Hw(iJ6);
        }
    }

    protected final void m652Zo() {
        jp jpVarDW = DW();
        mo36tp();
        Iterator it = Hw().iterator();
        while (it.hasNext()) {
            ((vp) it.next()).j6(jpVarDW);
        }
    }

    public final int m653j6(vp vpVar) {
        up upVar = (up) vpVar;
        return j6(upVar.we() * upVar.VH());
    }

    protected abstract void mo36tp();

    public final int m654u7() {
        Collection collectionHw = Hw();
        int size = collectionHw.size();
        if (size == 0) {
            return 0;
        }
        return size * ((vp) collectionHw.iterator().next()).VH();
    }
}
