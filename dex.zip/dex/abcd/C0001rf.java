package abcd;

import com.aide.ui.U;

@xu
public class C0001rf implements _l, Wl {

    @uu
    private static boolean f6DW;

    @InterfaceC0101tu
    private static boolean f7j6;

    static {
        wu.j6(C0001rf.class, -4638575969049598929L, -4638575969049598929L);
    }

    public C0001rf() {
        try {
            if (f7j6) {
                wu.j6(4305526846198057389L, (Object) null);
            }
        } catch (Throwable th) {
            if (f6DW) {
                wu.j6(th, 4305526846198057389L, (Object) null);
            }
            throw th;
        }
    }

    public com.aide.common.u m52FH() {
        try {
            if (f7j6) {
                wu.j6(4119864936404274660L, this);
            }
            return new com.aide.common.u(52, false, true, false);
        } catch (Throwable th) {
            if (f6DW) {
                wu.j6(th, 4119864936404274660L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f7j6) {
                return "Cut";
            }
            wu.j6(-1085562641442098799L, this);
            return "Cut";
        } catch (Throwable th) {
            if (f6DW) {
                wu.j6(th, -1085562641442098799L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f7j6) {
                wu.j6(-3128853439440723907L, this);
            }
            return U.er().gn() && !U.lg().J8().getCurrentFileSpan().j6();
        } catch (Throwable th) {
            if (f6DW) {
                wu.j6(th, -3128853439440723907L, this);
            }
            throw th;
        }
    }

    public int m53j6() {
        try {
            if (!f7j6) {
                return com.aide.pro.R.id.editorMenuCut;
            }
            wu.j6(2175513439979211903L, this);
            return com.aide.pro.R.id.editorMenuCut;
        } catch (Throwable th) {
            if (f6DW) {
                wu.j6(th, 2175513439979211903L, this);
            }
            throw th;
        }
    }

    public boolean m54j6(boolean z) {
        try {
            if (f7j6) {
                wu.j6(1220054993709577563L, this, z);
            }
            return !z && isEnabled();
        } catch (Throwable th) {
            if (f6DW) {
                wu.j6(th, 1220054993709577563L, this, new Boolean(z));
            }
            throw th;
        }
    }

    public boolean m55run() {
        try {
            if (f7j6) {
                wu.j6(293981054605533075L, this);
            }
            U.lg().J8().u7();
            return true;
        } catch (Throwable th) {
            if (f6DW) {
                wu.j6(th, 293981054605533075L, this);
            }
            throw th;
        }
    }
}
