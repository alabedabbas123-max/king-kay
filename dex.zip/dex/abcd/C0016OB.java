package abcd;

public class C0016OB extends NB {
    public C0016OB(String str) {
        super(str);
    }
}
