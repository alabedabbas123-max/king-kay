package abcd;

public class C0017Tz {

    public final int f32DW;

    public final int f33EQ;

    public final int f34FH;

    public final int f35Hw;

    public final boolean f36VH;

    public final boolean f37Zo;

    public final boolean f38gn;

    public final String f39j6;

    public final boolean f40tp;

    public final boolean f41u7;

    public final int f42v5;

    public C0017Tz(String str, int i, int i2, int i3, int i4, boolean z, boolean z2, boolean z3, boolean z4, int i5, boolean z5) {
        this.f39j6 = str;
        this.f32DW = i;
        this.f34FH = i2;
        this.f35Hw = i3;
        this.f42v5 = i4;
        this.f37Zo = z;
        this.f36VH = z2;
        this.f38gn = z3;
        this.f41u7 = z4;
        this.f33EQ = i5;
        this.f40tp = z5;
    }
}
