package abcd;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.LinkedHashMap;
import java.util.Map;

public class C0022LA {

    static tA f106j6;

    public String f107DW;

    RandomAccessFile f108FH;

    long f109Hw;

    HA f110VH;

    int f112v5 = 0;

    Map<String, IA> f111Zo = new LinkedHashMap();

    public C0022LA(String str) {
        this.f108FH = null;
        this.f107DW = str;
        this.f108FH = new RandomAccessFile(new File(this.f107DW), "r");
        this.f109Hw = this.f108FH.length();
    }

    private static tA m132Zo() {
        if (f106j6 == null) {
            f106j6 = uA.j6(C0022LA.class.getName());
        }
        return f106j6;
    }

    public static C0022LA m133j6(String str) {
        C0022LA c0022la = new C0022LA(str);
        c0022la.m134v5();
        return c0022la;
    }

    private void m134v5() {
        try {
            this.f108FH.seek(m138FH(256));
            this.f110VH = HA.j6(this);
            boolean zIsDebugEnabled = m132Zo().isDebugEnabled();
            if (zIsDebugEnabled) {
                m132Zo().FH(String.format("EOCD found in %d iterations", Integer.valueOf(this.f112v5)));
                m132Zo().FH(String.format("Directory entries=%d, size=%d, offset=%d/0x%08x", Short.valueOf(this.f110VH.Zo), Integer.valueOf(this.f110VH.VH), Integer.valueOf(this.f110VH.gn), Integer.valueOf(this.f110VH.gn)));
                C0065MA.m337j6(m132Zo());
            }
            this.f108FH.seek(this.f110VH.gn);
            for (int i = 0; i < this.f110VH.Zo; i++) {
                IA iaJ6 = IA.j6(this);
                this.f111Zo.put(iaJ6.EQ(), iaJ6);
                if (zIsDebugEnabled) {
                    C0065MA.m338j6(m132Zo(), iaJ6);
                }
            }
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    public long m135DW() {
        return this.f108FH.getFilePointer();
    }

    public String m136DW(int i) {
        byte[] bArr = new byte[i];
        for (int i2 = 0; i2 < i; i2++) {
            bArr[i2] = this.f108FH.readByte();
        }
        return new String(bArr);
    }

    public int m137FH() {
        int unsignedByte = 0;
        for (int i = 0; i < 4; i++) {
            unsignedByte |= this.f108FH.readUnsignedByte() << (i * 8);
        }
        return unsignedByte;
    }

    public long m138FH(int i) throws IOException {
        long j = i;
        long j2 = this.f109Hw;
        if (j > j2 || i > 65536) {
            throw new IllegalStateException("End of central directory not found in " + this.f107DW);
        }
        int iMin = (int) Math.min(j2, j);
        byte[] bArr = new byte[iMin];
        long j3 = iMin;
        this.f108FH.seek(this.f109Hw - j3);
        this.f108FH.readFully(bArr);
        for (int i2 = iMin - 22; i2 >= 0; i2--) {
            this.f112v5++;
            if (bArr[i2] == 80 && bArr[i2 + 1] == 75 && bArr[i2 + 2] == 5 && bArr[i2 + 3] == 6) {
                return (this.f109Hw - j3) + ((long) i2);
            }
        }
        return m138FH(i * 2);
    }

    public short m139Hw() {
        short unsignedByte = 0;
        for (int i = 0; i < 2; i++) {
            unsignedByte = (short) (unsignedByte | (this.f108FH.readUnsignedByte() << (i * 8)));
        }
        return unsignedByte;
    }

    public Map<String, IA> m140j6() {
        return this.f111Zo;
    }

    public void m141j6(long j) throws IOException {
        this.f108FH.seek(j);
    }

    public byte[] m142j6(int i) {
        byte[] bArr = new byte[i];
        for (int i2 = 0; i2 < i; i2++) {
            bArr[i2] = this.f108FH.readByte();
        }
        return bArr;
    }
}
