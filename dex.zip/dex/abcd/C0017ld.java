package abcd;

@xu
public class C0017ld {

    @uu
    private static boolean f197DW;

    @tu
    private static boolean f198j6;

    @ru(field = -490477962811800083L)
    private final La f199FH;

    @ru(field = 3646569781482663420L)
    private final C0103nd f200Hw;

    @ru(field = 3349971541120703273L)
    private int f201VH;

    @ru(field = -1093312924671528484L)
    private Sa f202Zo;

    @ru(field = 3672382060584830280L)
    private int f203gn;

    @ru(field = -3665336254781189320L)
    private wb<qa.a> f204u7;

    @ru(field = -1094960060084231040L)
    private Ta f205v5;

    static {
        wu.j6(C0017ld.class, 1198773388653793404L, 1198773388653793404L);
    }

    public C0017ld(La la, C0103nd c0103nd) {
        try {
            if (f198j6) {
                wu.j6(-1589211564975914648L, (Object) null, la, c0103nd);
            }
            this.f204u7 = new wb();
            this.f199FH = la;
            this.f200Hw = c0103nd;
        } catch (Throwable th) {
            if (f197DW) {
                wu.j6(th, -1589211564975914648L, (Object) null, la, c0103nd);
            }
            throw th;
        }
    }

    @su(method = -2336643795374403365L)
    private boolean m103DW(int i) {
        try {
            if (f198j6) {
                wu.j6(4801981957426580808L, this, i);
            }
            return this.f201VH >= this.f205v5.v5(this.f202Zo, i) && this.f203gn <= this.f205v5.FH(this.f202Zo, i);
        } catch (Throwable th) {
            if (f197DW) {
                wu.j6(th, 4801981957426580808L, this, new Integer(i));
            }
            throw th;
        }
    }

    @su(method = -5225413038766018560L)
    private void m104j6(int i) {
        try {
            if (f198j6) {
                wu.j6(-3681792564575668365L, this, i);
            }
            if (m103DW(i)) {
                if (this.f202Zo.P8(i) == 1 && this.f205v5.Hw(this.f202Zo, i) == 1) {
                    this.f204u7.DW(this.f205v5.v5(this.f202Zo, i), new qa.a(this.f200Hw, 0, false, true, 500));
                } else if (this.f202Zo.P8(i) == 2) {
                    for (int iV5 = this.f205v5.v5(this.f202Zo, i) + 1; iV5 <= this.f205v5.FH(this.f202Zo, i); iV5++) {
                        this.f204u7.DW(iV5, new qa.a(this.f200Hw, 1, true, false, 500));
                    }
                }
                int iWe = this.f202Zo.we(i);
                for (int i2 = 0; i2 < iWe; i2++) {
                    m104j6(this.f202Zo.Zo(i, i2));
                }
            }
        } catch (Throwable th) {
            if (f197DW) {
                wu.j6(th, -3681792564575668365L, this, new Integer(i));
            }
            throw th;
        }
    }

    public wb<qa.a> m105DW(Sa sa, Ta ta, int i, int i2) {
        try {
            if (f198j6) {
                wu.j6(2240228302073082000L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            this.f203gn = i;
            this.f201VH = i2;
            this.f205v5 = ta;
            this.f202Zo = sa;
            this.f204u7.j6();
            m104j6(sa.aM());
            return this.f204u7;
        } catch (Throwable th) {
            if (f197DW) {
                wu.j6(th, 2240228302073082000L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public wb<qa.a> m106FH(Sa sa, Ta ta, int i, int i2) {
        try {
            if (f198j6) {
                wu.j6(-966570108892484235L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            return m105DW(sa, ta, i, i2);
        } catch (Throwable th) {
            if (f197DW) {
                wu.j6(th, -966570108892484235L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }

    public void m107j6(Sa sa, Ta ta, int i, int i2) {
        int iJ8;
        try {
            if (f198j6) {
                wu.j6(2428330856546380175L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            if (this.f199FH.Hw().j6(sa.J8()).contains(EnumC0060md.f332j6) && (iJ8 = sa.J8(i, i2)) != -1 && sa.P8(iJ8) == 2) {
                int i3 = i + 1;
                this.f199FH.gn.j6(sa.VH(), i3, 1, i3, 1, "* ");
            }
        } catch (Throwable th) {
            if (f197DW) {
                wu.j6(th, 2428330856546380175L, this, sa, ta, new Integer(i), new Integer(i2));
            }
            throw th;
        }
    }
}
