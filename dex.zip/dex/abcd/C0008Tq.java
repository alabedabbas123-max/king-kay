package abcd;

enum C0008Tq extends er {
    C0008Tq(String str, int i) {
        super(str, i, (Bq) null);
    }
}
