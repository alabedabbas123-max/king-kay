package abcd;

public abstract class AbstractC0051zC extends DC<tC> {

    public static final AbstractC0051zC f230j6 = new uC();

    public static final AbstractC0051zC f227DW = new vC();

    public static final AbstractC0051zC f228FH = new wC();

    public static final AbstractC0051zC f229Hw = new xC();

    public static final AbstractC0051zC f231v5 = new C0008yC();

    private static int m333DW(CK ck, int i, int i2) {
        while (i > 0 && i2 <= ck.DW(i)) {
            i--;
        }
        return i;
    }

    private static int m334j6(CK ck, int i, int i2) {
        int iDW = ck.DW() - 2;
        while (i < iDW && ck.DW(i + 2) < i2) {
            i++;
        }
        return i;
    }

    public int m335j6(tC tCVar, int i) {
        return mo22j6(tCVar.DW, tCVar.FH.DW(i + 1), tCVar.FH.DW(i + 2));
    }

    protected abstract int mo22j6(byte[] bArr, int i, int i2);

    public jC m337j6(CC cc, CC cc2, jC jCVar) {
        m338j6((tC) cc, (tC) cc2, jCVar);
        return jCVar;
    }

    public jC m338j6(tC tCVar, tC tCVar2, jC jCVar) {
        int i = jCVar.j6;
        if (i == jCVar.DW || jCVar.FH == jCVar.Hw) {
            return jCVar;
        }
        byte[] bArr = tCVar.DW;
        byte[] bArr2 = tCVar2.DW;
        int iDW = tCVar.FH.DW(i + 1);
        int iDW2 = tCVar.FH.DW(jCVar.FH + 1);
        int iDW3 = tCVar.FH.DW(jCVar.DW + 1);
        int iDW4 = tCVar2.FH.DW(jCVar.Hw + 1);
        if (iDW < 0 || iDW2 < 0 || iDW3 > bArr.length || iDW4 > bArr2.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        while (iDW < iDW3 && iDW2 < iDW4 && bArr[iDW] == bArr2[iDW2]) {
            iDW++;
            iDW2++;
        }
        while (iDW < iDW3 && iDW2 < iDW4 && bArr[iDW3 - 1] == bArr2[iDW4 - 1]) {
            iDW3--;
            iDW4--;
        }
        jCVar.j6 = m334j6(tCVar.FH, jCVar.j6, iDW);
        jCVar.FH = m334j6(tCVar2.FH, jCVar.FH, iDW2);
        jCVar.DW = m333DW(tCVar.FH, jCVar.DW, iDW3);
        boolean z = iDW3 < tCVar.FH.DW(jCVar.DW + 1);
        if (z) {
            iDW4 += tCVar.FH.DW(jCVar.DW + 1) - iDW3;
        }
        jCVar.Hw = m333DW(tCVar2.FH, jCVar.Hw, iDW4);
        if (!z && iDW4 < tCVar2.FH.DW(jCVar.Hw + 1)) {
            jCVar.DW++;
        }
        super.j6(tCVar, tCVar2, jCVar);
        return jCVar;
    }
}
