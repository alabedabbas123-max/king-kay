package abcd;

public class C0010Ts extends qt {

    private int f25DW;

    private au f26j6;

    public C0010Ts(int i) {
        this.f26j6 = new au(i);
    }

    public int m71j6() {
        return this.f25DW;
    }

    public int m72j6(int i) {
        if (i >= this.f26j6.size()) {
            return -1;
        }
        return this.f26j6.get(i);
    }

    public bs m73j6(bs bsVar) {
        int i;
        if (bsVar == null) {
            return null;
        }
        try {
            i = this.f26j6.get(bsVar.we());
        } catch (IndexOutOfBoundsException unused) {
            i = -1;
        }
        if (i >= 0) {
            return bsVar.FH(i);
        }
        throw new RuntimeException("no mapping specified for register");
    }

    public void m74j6(int i, int i2, int i3) {
        if (i >= this.f26j6.size()) {
            for (int size = i - this.f26j6.size(); size >= 0; size--) {
                this.f26j6.DW(-1);
            }
        }
        this.f26j6.FH(i, i2);
        int i4 = i2 + i3;
        if (this.f25DW < i4) {
            this.f25DW = i4;
        }
    }
}
