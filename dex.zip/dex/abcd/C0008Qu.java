package abcd;

import com.appfour.backbone.api.closures.OnEnterClosure3;
import com.appfour.backbone.api.objects.EventData;

class C0008Qu implements jv {

    final OnEnterClosure3 f69DW;

    final Vu f70FH;

    final long f71j6;

    C0008Qu(Vu vu, long j, OnEnterClosure3 onEnterClosure3) {
        this.f70FH = vu;
        this.f71j6 = j;
        this.f69DW = onEnterClosure3;
    }

    public EventData m92j6(Object[] objArr) {
        Object objJ6 = Ev.j6(objArr[0], this.f71j6);
        return Mv.XL().j6(objJ6, new Pu(this, objJ6, objArr));
    }
}
