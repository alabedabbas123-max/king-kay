package abcd;

import java.io.BufferedOutputStream;
import java.io.OutputStream;

public class C0016XK extends BufferedOutputStream {
    public C0016XK(OutputStream outputStream) {
        super(outputStream);
    }

    public C0016XK(OutputStream outputStream, int i) {
        super(outputStream);
    }

    @Override
    public void close() {
        try {
            flush();
        } finally {
            super.close();
        }
    }
}
