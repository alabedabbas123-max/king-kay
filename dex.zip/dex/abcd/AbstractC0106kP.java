package abcd;

public abstract class AbstractC0106kP extends AbstractC0062jP {
}
