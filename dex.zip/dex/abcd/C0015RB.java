package abcd;

public class C0015RB extends NB {
    public C0015RB(String str) {
        super(str);
    }

    public C0015RB(String str, Throwable th) {
        super(str, th);
    }
}
