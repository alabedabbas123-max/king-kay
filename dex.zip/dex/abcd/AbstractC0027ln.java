package abcd;

abstract class AbstractC0027ln {

    private final Ks f241DW;

    private final int f242FH;

    private final gn f243Hw;

    private xn f244Zo;

    private final jn f245j6;

    private int f246v5;

    public AbstractC0027ln(jn jnVar, Ks ks, int i, gn gnVar) {
        if (jnVar == null) {
            throw new NullPointerException("cf == null");
        }
        if (i < 0) {
            throw new IllegalArgumentException("offset < 0");
        }
        if (gnVar == null) {
            throw new NullPointerException("attributeFactory == null");
        }
        this.f245j6 = jnVar;
        this.f241DW = ks;
        this.f242FH = i;
        this.f243Hw = gnVar;
        this.f246v5 = -1;
    }

    private void m171VH() throws wn {
        int iMo176j6 = mo176j6();
        int iM172DW = m172DW();
        int i = this.f242FH + 2;
        Pt ptHw = this.f245j6.Hw();
        InterfaceC0118ns interfaceC0118nsV5 = this.f245j6.v5();
        xn xnVar = this.f244Zo;
        if (xnVar != null) {
            xnVar.j6(ptHw, this.f242FH, 2, mo180v5() + "s_count: " + Yt.v5(iM172DW));
        }
        int i2 = i;
        int i3 = 0;
        while (i3 < iM172DW) {
            try {
                int iZo = ptHw.Zo(i2);
                int i4 = i2 + 2;
                int iZo2 = ptHw.Zo(i4);
                int i5 = i2 + 4;
                int iZo3 = ptHw.Zo(i5);
                Js jsM555get = interfaceC0118nsV5.m555get(iZo2);
                Js jsM555get2 = interfaceC0118nsV5.m555get(iZo3);
                if (this.f244Zo != null) {
                    this.f244Zo.j6(ptHw, i2, jsM555get.we(), jsM555get2.we());
                    this.f244Zo.j6(ptHw, i2, 0, "\n" + mo180v5() + "s[" + i3 + "]:\n");
                    this.f244Zo.j6(1);
                    xn xnVar2 = this.f244Zo;
                    StringBuilder sb = new StringBuilder();
                    sb.append("access_flags: ");
                    sb.append(mo178j6(iZo));
                    xnVar2.j6(ptHw, i2, 2, sb.toString());
                    this.f244Zo.j6(ptHw, i4, 2, "name: " + jsM555get.aM());
                    this.f244Zo.j6(ptHw, i5, 2, "descriptor: " + jsM555get2.aM());
                }
                hn hnVar = new hn(this.f245j6, iMo176j6, i2 + 6, this.f243Hw);
                hnVar.j6(this.f244Zo);
                int iJ6 = hnVar.j6();
                yn ynVarDW = hnVar.DW();
                ynVarDW.we();
                tn tnVarMo177j6 = mo177j6(i3, iZo, new Hs(jsM555get, jsM555get2), ynVarDW);
                if (this.f244Zo != null) {
                    this.f244Zo.j6(-1);
                    this.f244Zo.j6(ptHw, iJ6, 0, "end " + mo180v5() + "s[" + i3 + "]\n");
                    this.f244Zo.j6(ptHw, iJ6, jsM555get.we(), jsM555get2.we(), tnVarMo177j6);
                }
                i3++;
                i2 = iJ6;
                iM172DW = iM172DW;
                interfaceC0118nsV5 = interfaceC0118nsV5;
            } catch (wn e) {
                e.j6("...while parsing " + mo180v5() + "s[" + i3 + "]");
                throw e;
            } catch (RuntimeException e2) {
                wn wnVar = new wn(e2);
                wnVar.j6("...while parsing " + mo180v5() + "s[" + i3 + "]");
                throw wnVar;
            }
        }
        this.f246v5 = i2;
    }

    protected final int m172DW() {
        return this.f245j6.Hw().Zo(this.f242FH);
    }

    protected final Ks m173FH() {
        return this.f241DW;
    }

    public int m174Hw() throws wn {
        m175Zo();
        return this.f246v5;
    }

    protected final void m175Zo() throws wn {
        if (this.f246v5 < 0) {
            m171VH();
        }
    }

    protected abstract int mo176j6();

    protected abstract tn mo177j6(int i, int i2, Hs hs, pn pnVar);

    protected abstract String mo178j6(int i);

    public final void m179j6(xn xnVar) {
        this.f244Zo = xnVar;
    }

    protected abstract String mo180v5();
}
