package abcd;

public class C0005y<E> implements Cloneable {

    private static final Object f5j6 = new Object();

    private boolean f6DW;

    private int[] f7FH;

    private Object[] f8Hw;

    private int f9v5;

    public C0005y() {
        this(10);
    }

    public C0005y(int i) {
        this.f6DW = false;
        if (i == 0) {
            this.f7FH = n.j6;
            this.f8Hw = n.FH;
        } else {
            int iDW = n.DW(i);
            this.f7FH = new int[iDW];
            this.f8Hw = new Object[iDW];
        }
        this.f9v5 = 0;
    }

    private void m9FH() {
        int i = this.f9v5;
        int[] iArr = this.f7FH;
        Object[] objArr = this.f8Hw;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f5j6) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f6DW = false;
        this.f9v5 = i2;
    }

    public int m10DW() {
        if (this.f6DW) {
            m9FH();
        }
        return this.f9v5;
    }

    public E m11DW(int i) {
        return m16j6(i, null);
    }

    public void m12DW(int i, E e) {
        int iJ6 = n.j6(this.f7FH, this.f9v5, i);
        if (iJ6 >= 0) {
            this.f8Hw[iJ6] = e;
            return;
        }
        int iJ7 = iJ6 ^ (-1);
        if (iJ7 < this.f9v5) {
            Object[] objArr = this.f8Hw;
            if (objArr[iJ7] == f5j6) {
                this.f7FH[iJ7] = i;
                objArr[iJ7] = e;
                return;
            }
        }
        if (this.f6DW && this.f9v5 >= this.f7FH.length) {
            m9FH();
            iJ7 = n.j6(this.f7FH, this.f9v5, i) ^ (-1);
        }
        int i2 = this.f9v5;
        if (i2 >= this.f7FH.length) {
            int iDW = n.DW(i2 + 1);
            int[] iArr = new int[iDW];
            Object[] objArr2 = new Object[iDW];
            int[] iArr2 = this.f7FH;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr3 = this.f8Hw;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f7FH = iArr;
            this.f8Hw = objArr2;
        }
        int i3 = this.f9v5;
        if (i3 - iJ7 != 0) {
            int[] iArr3 = this.f7FH;
            int i4 = iJ7 + 1;
            System.arraycopy(iArr3, iJ7, iArr3, i4, i3 - iJ7);
            Object[] objArr4 = this.f8Hw;
            System.arraycopy(objArr4, iJ7, objArr4, i4, this.f9v5 - iJ7);
        }
        this.f7FH[iJ7] = i;
        this.f8Hw[iJ7] = e;
        this.f9v5++;
    }

    public int m13FH(int i) {
        if (this.f6DW) {
            m9FH();
        }
        return n.j6(this.f7FH, this.f9v5, i);
    }

    public int m14Hw(int i) {
        if (this.f6DW) {
            m9FH();
        }
        return this.f7FH[i];
    }

    public E m15Zo(int i) {
        if (this.f6DW) {
            m9FH();
        }
        return (E) this.f8Hw[i];
    }

    public y<E> m599clone() {
        try {
            C0005y c0005y = (C0005y) super.clone();
            try {
                c0005y.f7FH = (int[]) this.f7FH.clone();
                c0005y.f8Hw = (Object[]) this.f8Hw.clone();
                return c0005y;
            } catch (CloneNotSupportedException unused) {
                return c0005y;
            }
        } catch (CloneNotSupportedException unused2) {
            return null;
        }
    }

    public E m16j6(int i, E e) {
        int iJ6 = n.j6(this.f7FH, this.f9v5, i);
        if (iJ6 >= 0) {
            Object[] objArr = this.f8Hw;
            if (objArr[iJ6] != f5j6) {
                return (E) objArr[iJ6];
            }
        }
        return e;
    }

    public void m17j6() {
        int i = this.f9v5;
        Object[] objArr = this.f8Hw;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.f9v5 = 0;
        this.f6DW = false;
    }

    public void m18j6(int i) {
        int iJ6 = n.j6(this.f7FH, this.f9v5, i);
        if (iJ6 >= 0) {
            Object[] objArr = this.f8Hw;
            Object obj = objArr[iJ6];
            Object obj2 = f5j6;
            if (obj != obj2) {
                objArr[iJ6] = obj2;
                this.f6DW = true;
            }
        }
    }

    public String toString() {
        if (m10DW() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f9v5 * 28);
        sb.append('{');
        for (int i = 0; i < this.f9v5; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(m14Hw(i));
            sb.append('=');
            E eM15Zo = m15Zo(i);
            if (eM15Zo != this) {
                sb.append(eM15Zo);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public void m19v5(int i) {
        m18j6(i);
    }
}
