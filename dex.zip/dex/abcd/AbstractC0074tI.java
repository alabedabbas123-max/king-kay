package abcd;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ConnectException;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0074tI extends cJ {

    private final Map<String, JSch> f240DW = new HashMap();

    private JSch f241FH;

    private yI f242Hw;

    private static void m398DW(JSch jSch, pK pKVar) {
        File fileZo = pKVar.Zo();
        if (fileZo == null) {
            return;
        }
        try {
            FileInputStream fileInputStream = new FileInputStream(new File(new File(fileZo, ".ssh"), "known_hosts"));
            try {
                jSch.j6(fileInputStream);
            } finally {
                fileInputStream.close();
            }
        } catch (FileNotFoundException | IOException unused) {
        }
    }

    private Session m399j6(kI kIVar, pK pKVar, String str, String str2, String str3, int i, yI.a aVar) {
        Session sessionM405j6 = m405j6(aVar, str, str3, i, pKVar);
        if (str2 != null) {
            sessionM405j6.v5(str2);
        }
        String strV5 = aVar.v5();
        if (strV5 != null) {
            sessionM405j6.j6("StrictHostKeyChecking", strV5);
        }
        String strHw = aVar.Hw();
        if (strHw != null) {
            sessionM405j6.j6("PreferredAuthentications", strHw);
        }
        if (kIVar != null && (!aVar.VH() || !kIVar.DW())) {
            sessionM405j6.j6(new lI(sessionM405j6, kIVar));
        }
        m406j6(aVar, sessionM405j6);
        return sessionM405j6;
    }

    private static void m400j6(JSch jSch, pK pKVar) {
        File fileZo = pKVar.Zo();
        if (fileZo == null) {
            return;
        }
        File file = new File(fileZo, ".ssh");
        if (file.isDirectory()) {
            m401j6(jSch, new File(file, "identity"));
            m401j6(jSch, new File(file, "id_rsa"));
            m401j6(jSch, new File(file, "id_dsa"));
        }
    }

    private static void m401j6(JSch jSch, File file) {
        if (file.isFile()) {
            try {
                jSch.j6(file.getAbsolutePath());
            } catch (JSchException unused) {
            }
        }
    }

    public synchronized ZI m402j6(HJ hj, kI kIVar, pK pKVar, int i) {
        Session sessionM399j6;
        String strGn = hj.gn();
        String strFH = hj.FH();
        String strJ6 = hj.j6();
        int iV5 = hj.v5();
        try {
            if (this.f242Hw == null) {
                this.f242Hw = yI.j6(pKVar);
            }
            yI.a aVarJ6 = this.f242Hw.j6(strJ6);
            String strJ7 = aVarJ6.j6();
            int iFH = iV5 <= 0 ? aVarJ6.FH() : iV5;
            if (strGn == null) {
                strGn = aVarJ6.Zo();
            }
            String str = strGn;
            sessionM399j6 = m399j6(kIVar, pKVar, str, strFH, strJ7, iFH, aVarJ6);
            int i2 = 0;
            while (!sessionM399j6.tp() && i2 < 3) {
                int i3 = i2 + 1;
                try {
                    sessionM399j6.j6(i);
                } catch (JSchException e) {
                    sessionM399j6.j6();
                    if (kIVar == null) {
                        throw e;
                    }
                    if (e.getCause() != null) {
                        throw e;
                    }
                    if (!e.getMessage().equals("Auth fail")) {
                        throw e;
                    }
                    kIVar.j6(hj);
                    sessionM399j6 = m399j6(kIVar, pKVar, str, strFH, strJ7, iFH, aVarJ6);
                }
                i2 = i3;
            }
        } catch (JSchException e2) {
            Throwable cause = e2.getCause();
            if (cause instanceof UnknownHostException) {
                throw new yD(hj, JGitText.j6().unknownHost);
            }
            if (cause instanceof ConnectException) {
                throw new yD(hj, cause.getMessage());
            }
            throw new yD(hj, e2.getMessage(), e2);
        }
        return new vI(sessionM399j6, hj);
    }

    protected JSch m403j6(pK pKVar) {
        JSch jSch = new JSch();
        m398DW(jSch, pKVar);
        m400j6(jSch, pKVar);
        return jSch;
    }

    protected JSch m404j6(yI.a aVar, pK pKVar) {
        if (this.f241FH == null) {
            this.f241FH = m403j6(pKVar);
            Iterator it = this.f241FH.FH().iterator();
            while (it.hasNext()) {
                this.f240DW.put((String) it.next(), this.f241FH);
            }
        }
        File fileDW = aVar.DW();
        if (fileDW == null) {
            return this.f241FH;
        }
        String absolutePath = fileDW.getAbsolutePath();
        JSch jSch = this.f240DW.get(absolutePath);
        if (jSch != null) {
            return jSch;
        }
        JSch jSch2 = new JSch();
        jSch2.j6(this.f241FH.DW());
        jSch2.j6(absolutePath);
        this.f240DW.put(absolutePath, jSch2);
        return jSch2;
    }

    protected Session m405j6(yI.a aVar, String str, String str2, int i, pK pKVar) {
        return m404j6(aVar, pKVar).j6(str, str2, i);
    }

    protected abstract void m406j6(yI.a aVar, Session session);
}
