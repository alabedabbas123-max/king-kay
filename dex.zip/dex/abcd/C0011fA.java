package abcd;

import android.content.Context;
import android.graphics.BitmapFactory;
import io.fabric.sdk.android.Fabric;
import io.fabric.sdk.android.services.common.i;

public class C0011fA {

    public final int f78DW;

    public final int f79FH;

    public final int f80Hw;

    public final String f81j6;

    public C0011fA(String str, int i, int i2, int i3) {
        this.f81j6 = str;
        this.f78DW = i;
        this.f79FH = i2;
        this.f80Hw = i3;
    }

    public static C0011fA m37j6(Context context, String str) {
        if (str != null) {
            try {
                int iHw = i.Hw(context);
                Fabric.getLogger().Hw("Fabric", "App icon resource ID is " + iHw);
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeResource(context.getResources(), iHw, options);
                return new C0011fA(str, iHw, options.outWidth, options.outHeight);
            } catch (Exception e) {
                Fabric.getLogger().FH("Fabric", "Failed to load icon", e);
            }
        }
        return null;
    }
}
