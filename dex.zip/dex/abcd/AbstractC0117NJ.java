package abcd;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.MessageFormat;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;
import org.eclipse.jgit.JGitText;

abstract class AbstractC0117NJ {

    static final AbstractC0117NJ f537j6 = new a(null);

    private static class a extends AbstractC0117NJ {
        private a() {
        }

        a(a aVar) {
            this();
        }

        @Override
        void mo674DW(HttpURLConnection httpURLConnection, String str) throws IOException {
            m679j6(httpURLConnection, str, "", "");
        }

        @Override
        InputStream mo676j6(InputStream inputStream) {
            return inputStream;
        }

        @Override
        OutputStream mo677j6(OutputStream outputStream) {
            return outputStream;
        }

        @Override
        void mo678j6(HttpURLConnection httpURLConnection, String str) {
        }
    }

    static class b extends AbstractC0117NJ {

        private static int f538DW = 5000;

        private static byte[] f539FH = {-92, 11, -56, 52, -42, -107, -13, 19};

        private final String f540Hw;

        private final PBEParameterSpec f541Zo = new PBEParameterSpec(f539FH, f538DW);

        private final SecretKey f542v5;

        b(String str, String str2) {
            this.f540Hw = str;
            this.f542v5 = SecretKeyFactory.getInstance(str).generateSecret(new PBEKeySpec(str2.toCharArray(), f539FH, f538DW, 32));
        }

        @Override
        void mo674DW(HttpURLConnection httpURLConnection, String str) throws IOException {
            m679j6(httpURLConnection, str, "2", this.f540Hw);
        }

        @Override
        InputStream mo676j6(InputStream inputStream) throws IOException {
            try {
                Cipher cipher = Cipher.getInstance(this.f540Hw);
                cipher.init(2, this.f542v5, this.f541Zo);
                return new CipherInputStream(inputStream, cipher);
            } catch (InvalidAlgorithmParameterException e) {
                throw m675j6(e);
            } catch (InvalidKeyException e2) {
                throw m675j6(e2);
            } catch (NoSuchAlgorithmException e3) {
                throw m675j6(e3);
            } catch (NoSuchPaddingException e4) {
                throw m675j6(e4);
            }
        }

        @Override
        OutputStream mo677j6(OutputStream outputStream) throws IOException {
            try {
                Cipher cipher = Cipher.getInstance(this.f540Hw);
                cipher.init(1, this.f542v5, this.f541Zo);
                return new CipherOutputStream(outputStream, cipher);
            } catch (InvalidAlgorithmParameterException e) {
                throw m675j6(e);
            } catch (InvalidKeyException e2) {
                throw m675j6(e2);
            } catch (NoSuchAlgorithmException e3) {
                throw m675j6(e3);
            } catch (NoSuchPaddingException e4) {
                throw m675j6(e4);
            }
        }

        @Override
        void mo678j6(HttpURLConnection httpURLConnection, String str) {
            httpURLConnection.setRequestProperty(String.valueOf(str) + "jets3t-crypto-ver", "2");
            httpURLConnection.setRequestProperty(String.valueOf(str) + "jets3t-crypto-alg", this.f540Hw);
        }
    }

    AbstractC0117NJ() {
    }

    abstract void mo674DW(HttpURLConnection httpURLConnection, String str);

    IOException m675j6(Throwable th) {
        IOException iOException = new IOException(MessageFormat.format(JGitText.j6().encryptionError, th.getMessage()));
        iOException.initCause(th);
        return iOException;
    }

    abstract InputStream mo676j6(InputStream inputStream);

    abstract OutputStream mo677j6(OutputStream outputStream);

    abstract void mo678j6(HttpURLConnection httpURLConnection, String str);

    protected void m679j6(HttpURLConnection httpURLConnection, String str, String str2, String str3) throws IOException {
        String headerField = httpURLConnection.getHeaderField(String.valueOf(str) + "jets3t-crypto-ver");
        if (headerField == null) {
            headerField = "";
        }
        if (!str2.equals(headerField)) {
            throw new IOException(MessageFormat.format(JGitText.j6().unsupportedEncryptionVersion, headerField));
        }
        String headerField2 = httpURLConnection.getHeaderField(String.valueOf(str) + "jets3t-crypto-alg");
        if (headerField2 == null) {
            headerField2 = "";
        }
        if (str3.equals(headerField2)) {
            return;
        }
        throw new IOException(String.valueOf(JGitText.j6().unsupportedEncryptionAlgorithm) + headerField2);
    }
}
