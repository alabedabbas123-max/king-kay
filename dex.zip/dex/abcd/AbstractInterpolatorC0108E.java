package abcd;

import android.view.animation.Interpolator;

abstract class AbstractInterpolatorC0108E implements Interpolator {

    private final float f511DW;

    private final float[] f512j6;

    public AbstractInterpolatorC0108E(float[] fArr) {
        this.f512j6 = fArr;
        this.f511DW = 1.0f / (this.f512j6.length - 1);
    }

    @Override
    public float getInterpolation(float f) {
        if (f >= 1.0f) {
            return 1.0f;
        }
        if (f <= 0.0f) {
            return 0.0f;
        }
        float[] fArr = this.f512j6;
        int iMin = Math.min((int) ((fArr.length - 1) * f), fArr.length - 2);
        float f2 = this.f511DW;
        float f3 = (f - (iMin * f2)) / f2;
        float[] fArr2 = this.f512j6;
        return fArr2[iMin] + (f3 * (fArr2[iMin + 1] - fArr2[iMin]));
    }
}
