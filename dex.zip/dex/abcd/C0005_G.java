package abcd;

import java.util.Comparator;

class C0005_G implements Comparator<C0049aH> {
    C0005_G() {
    }

    @Override
    public int compare(C0049aH c0049aH, C0049aH c0049aH2) {
        return c0049aH2.f249EQ - c0049aH.f249EQ;
    }
}
