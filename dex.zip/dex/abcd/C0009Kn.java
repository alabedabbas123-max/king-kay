package abcd;

public class C0009Kn {
    private static bp m74DW(String str, byte[] bArr, In in, Fn fn) throws Vt {
        jn jnVar = new jn(bArr, str, in.FH);
        jnVar.j6(nn.j6);
        jnVar.gn();
        C0094Mn.m500j6(in.v5, in.Zo);
        bp bpVar = new bp(jnVar.J8(), jnVar.j6() & (-33), jnVar.J0(), jnVar.VH(), in.j6 == 1 ? null : jnVar.DW());
        Jr jrJ6 = Hn.j6(jnVar, in);
        if (jrJ6.size() != 0) {
            bpVar.j6(jrJ6);
        }
        m79j6(jnVar, bpVar);
        m78j6(jnVar, in, fn, bpVar);
        return bpVar;
    }

    private static AbstractC0099Ms m75j6(AbstractC0099Ms abstractC0099Ms, Qs qs) {
        if (abstractC0099Ms.getType().equals(qs)) {
            return abstractC0099Ms;
        }
        int iJ3 = qs.j3();
        if (iJ3 == 1) {
            return rs.j6(((ys) abstractC0099Ms).rN());
        }
        if (iJ3 == 2) {
            return ss.j6(((ys) abstractC0099Ms).rN());
        }
        if (iJ3 == 3) {
            return ts.j6(((ys) abstractC0099Ms).rN());
        }
        if (iJ3 == 8) {
            return Is.j6(((ys) abstractC0099Ms).rN());
        }
        throw new UnsupportedOperationException("can't coerce " + abstractC0099Ms + " to " + qs);
    }

    public static bp m76j6(String str, byte[] bArr, In in, Fn fn) throws Vt {
        try {
            return m74DW(str, bArr, in, fn);
        } catch (RuntimeException e) {
            throw Vt.j6(e, "...while processing " + str);
        }
    }

    private static void m77j6(In in, Fn fn, fs fsVar, fs fsVar2, Xr xr, int i, int i2) {
        Un unJ6 = lo.j6(fsVar, in.j6, xr, i, fn);
        Un unJ7 = lo.j6(fsVar2, in.j6, xr, i, fn);
        Jn jn = new Jn();
        unJ6.j6(jn);
        unJ7.j6(jn);
        C0051Ln.m283j6(unJ7, unJ6);
        C0051Ln.m282j6(i2);
    }

    private static void m78j6(jn jnVar, In in, Fn fn, bp bpVar) throws Vt {
        Un un;
        fs fsVar;
        C0014Ks c0014KsJ8 = jnVar.J8();
        vn vnVarEQ = jnVar.EQ();
        int size = vnVarEQ.size();
        int i = 0;
        while (i < size) {
            un unVar = vnVarEQ.get(i);
            try {
                Gs gs = new Gs(c0014KsJ8, unVar.FH());
                int iJ6 = unVar.j6();
                boolean zM519gn = C0098Mr.m519gn(iJ6);
                boolean zM517VH = C0098Mr.m517VH(iJ6);
                boolean zM518Zo = C0098Mr.m518Zo(iJ6);
                boolean zM516Hw = C0098Mr.m516Hw(iJ6);
                boolean z = true;
                boolean z2 = gs.lg() || gs.Ws();
                if (zM518Zo || zM516Hw) {
                    zM519gn = zM519gn;
                    un = null;
                } else {
                    if (in.j6 == 1) {
                        z = false;
                    }
                    C0093Mm c0093Mm = new C0093Mm(unVar, jnVar, z, in.DW);
                    Qr qr = Qr.j6;
                    fs fsVarJ6 = Zm.j6(c0093Mm, qr);
                    int iJ7 = gs.j6(zM519gn);
                    String str = c0014KsJ8.m109VH().J8() + "." + unVar.getName().we();
                    if (in.Hw && C0094Mn.m501j6(str)) {
                        fs fsVarJ7 = nt.j6(fsVarJ6, iJ7, zM519gn, in.DW, qr);
                        if (in.VH) {
                            C0051Ln.m284j6(fsVarJ6, fsVarJ7);
                        }
                        fsVar = fsVarJ7;
                    } else {
                        fsVar = fsVarJ6;
                        fsVarJ6 = null;
                    }
                    Xr xrJ6 = in.DW ? Wr.j6(fsVar) : null;
                    Un unJ6 = lo.j6(fsVar, in.j6, xrJ6, iJ7, fn);
                    if (in.VH && fsVarJ6 != null) {
                        m77j6(in, fn, fsVar, fsVarJ6, xrJ6, iJ7, c0093Mm.m493gn().m267FH());
                    }
                    un = unJ6;
                }
                if (C0098Mr.m523u7(iJ6)) {
                    iJ6 |= 131072;
                    if (!zM518Zo) {
                        iJ6 &= -33;
                    }
                }
                if (z2) {
                    iJ6 |= 65536;
                }
                np npVar = new np(gs, iJ6, un, Hn.j6(unVar));
                if (gs.lg() || gs.Ws() || zM519gn || zM517VH) {
                    bpVar.j6(npVar);
                } else {
                    bpVar.DW(npVar);
                }
                Jr jrDW = Hn.DW(unVar);
                if (jrDW.size() != 0) {
                    bpVar.j6(gs, jrDW);
                }
                C0013Kr c0013KrFH = Hn.FH(unVar);
                if (c0013KrFH.size() != 0) {
                    bpVar.j6(gs, c0013KrFH);
                }
                i++;
                c0014KsJ8 = c0014KsJ8;
            } catch (RuntimeException e) {
                throw Vt.j6(e, "...while processing " + unVar.getName().aM() + " " + unVar.Hw().aM());
            }
        }
    }

    private static void m79j6(jn jnVar, bp bpVar) throws Vt {
        C0014Ks c0014KsJ8 = jnVar.J8();
        sn snVarZo = jnVar.Zo();
        int size = snVarZo.size();
        for (int i = 0; i < size; i++) {
            rn rnVar = snVarZo.get(i);
            try {
                ws wsVar = new ws(c0014KsJ8, rnVar.FH());
                int iJ6 = rnVar.j6();
                if (C0098Mr.m519gn(iJ6)) {
                    AbstractC0099Ms abstractC0099MsZo = rnVar.Zo();
                    lp lpVar = new lp(wsVar, iJ6);
                    if (abstractC0099MsZo != null) {
                        abstractC0099MsZo = m75j6(abstractC0099MsZo, wsVar.getType());
                    }
                    bpVar.j6(lpVar, abstractC0099MsZo);
                } else {
                    bpVar.j6(new lp(wsVar, iJ6));
                }
                Jr jrJ6 = Hn.j6(rnVar.getAttributes());
                if (jrJ6.size() != 0) {
                    bpVar.j6(wsVar, jrJ6);
                }
            } catch (RuntimeException e) {
                throw Vt.j6(e, "...while processing " + rnVar.getName().aM() + " " + rnVar.Hw().aM());
            }
        }
    }
}
