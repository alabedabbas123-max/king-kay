package abcd;

import java.util.BitSet;

public final class C0002No extends ao {

    public static final ao f8DW = new C0002No();

    private C0002No() {
    }

    private static cs m19Hw(cs csVar) {
        int iM20v5 = m20v5(csVar);
        int size = csVar.size();
        if (iM20v5 == size) {
            return csVar;
        }
        cs csVar2 = new cs(iM20v5);
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            bs bsVar = csVar.get(i2);
            csVar2.j6(i, bsVar);
            if (bsVar.Hw() == 2) {
                csVar2.j6(i + 1, bs.j6(bsVar.we() + 1, Qs.tp));
                i += 2;
            } else {
                i++;
            }
        }
        csVar2.we();
        return csVar2;
    }

    private static int m20v5(cs csVar) {
        int size = csVar.size();
        if (size > 5) {
            return -1;
        }
        int iHw = 0;
        for (int i = 0; i < size; i++) {
            bs bsVar = csVar.get(i);
            iHw += bsVar.Hw();
            if (!ao.v5((bsVar.we() + bsVar.Hw()) - 1)) {
                return -1;
            }
        }
        if (iHw <= 5) {
            return iHw;
        }
        return -1;
    }

    public BitSet m21FH(Vn vn) {
        cs csVarGn = vn.gn();
        int size = csVarGn.size();
        BitSet bitSet = new BitSet(size);
        for (int i = 0; i < size; i++) {
            bs bsVar = csVarGn.get(i);
            bitSet.set(i, ao.v5((bsVar.we() + bsVar.Hw()) - 1));
        }
        return bitSet;
    }

    public boolean m22VH(Vn vn) {
        if (!(vn instanceof Tn)) {
            return false;
        }
        Tn tn = (Tn) vn;
        if (!ao.Zo(tn.J0())) {
            return false;
        }
        ms msVarWe = tn.we();
        return ((msVarWe instanceof Gs) || (msVarWe instanceof Ks)) && m20v5(tn.gn()) >= 0;
    }

    public String m23Zo(Vn vn) {
        return ao.DW(m19Hw(vn.gn())) + ", " + ao.v5(vn);
    }

    public int m24j6() {
        return 3;
    }

    public String m25j6(Vn vn, boolean z) {
        return z ? ao.Hw(vn) : "";
    }

    public void m26j6(Lt lt, Vn vn) {
        int iJ0 = ((Tn) vn).J0();
        cs csVarM19Hw = m19Hw(vn.gn());
        int size = csVarM19Hw.size();
        ao.j6(lt, ao.j6(vn, ao.DW(size > 4 ? csVarM19Hw.get(4).we() : 0, size)), (short) iJ0, ao.j6(size > 0 ? csVarM19Hw.get(0).we() : 0, size > 1 ? csVarM19Hw.get(1).we() : 0, size > 2 ? csVarM19Hw.get(2).we() : 0, size > 3 ? csVarM19Hw.get(3).we() : 0));
    }
}
