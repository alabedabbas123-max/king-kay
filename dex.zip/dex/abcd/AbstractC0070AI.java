package abcd;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0070AI {

    private static int[] f193j6;

    private IE f194BT;

    private final xE f195DW;

    private int f196EQ;

    private wE f199J0;

    private boolean f200J8;

    private DE<yE> f201Mr;

    private long f202P8;

    private boolean f203QX;

    private int f204U2;

    private boolean f207XL;

    private int f209a8;

    private long f210aM;

    private wI<f> f211er;

    private InputStream f213gn;

    private CI[] f214j3;

    private AE<a> f215lg;

    private DE<yE> f216rN;

    private long f217tp;

    private String f220vy;

    private int f221we;

    private lK<CI> f222yS;

    private c f197FH = new c();

    private byte[] f218u7 = new byte[8192];

    private byte[] f198Hw = new byte[8192];

    private byte[] f219v5 = new byte[64];

    private final MessageDigest f208Zo = hE.j6();

    private final uE f205VH = new uE();

    private MessageDigest f212gW = hE.j6();

    private boolean f206Ws = true;

    private static class a extends C0066AE.a {

        f f223EQ;

        a(YD yd) {
            super(yd);
        }

        f m800aM() {
            f fVar = this.f223EQ;
            if (fVar != null) {
                this.f223EQ = null;
            }
            return fVar;
        }

        void m801j6(f fVar) {
            fVar.f242FH = this.f223EQ;
            this.f223EQ = fVar;
        }
    }

    private static class b {

        yE f224DW;

        byte[] f225FH;

        b f226Hw;

        final f f227j6;

        f f228v5;

        b() {
            this.f227j6 = null;
        }

        b(b bVar) {
            this.f226Hw = bVar;
            this.f227j6 = bVar.f228v5;
            bVar.f228v5 = this.f227j6.f242FH;
        }

        b m802j6() {
            b bVar = this.f226Hw;
            if (bVar != null && bVar.f228v5 == null) {
                bVar.f225FH = null;
                this.f226Hw = bVar.f226Hw;
            }
            if (this.f228v5 != null) {
                return new b(this);
            }
            b bVar2 = this.f226Hw;
            if (bVar2 != null) {
                return new b(bVar2);
            }
            return null;
        }
    }

    private class c extends InputStream {

        private e f230FH;

        private long f231Hw;

        private int f233Zo;

        private long f235v5;

        private final Inflater f234j6 = tE.j6();

        private final byte[] f229DW = new byte[512];

        c() {
        }

        @Override
        public void close() throws YC {
            if (read(this.f229DW) != -1 || this.f235v5 != this.f231Hw) {
                throw new YC(MessageFormat.format(JGitText.j6().packfileCorruptionDetected, JGitText.j6().wrongDecompressedLength));
            }
            int remaining = AbstractC0070AI.this.f221we - this.f234j6.getRemaining();
            if (remaining > 0) {
                AbstractC0070AI abstractC0070AI = AbstractC0070AI.this;
                abstractC0070AI.m786j6(this.f230FH, abstractC0070AI.f218u7, this.f233Zo, remaining);
                AbstractC0070AI.this.m739Hw(remaining);
            }
            this.f234j6.reset();
        }

        void m803j6() {
            this.f234j6.reset();
            tE.j6(this.f234j6);
        }

        void m804j6(e eVar, long j) {
            this.f230FH = eVar;
            this.f231Hw = j;
            this.f235v5 = 0L;
            this.f233Zo = AbstractC0070AI.this.m748j6(this.f230FH, 1);
            this.f234j6.setInput(AbstractC0070AI.this.f218u7, this.f233Zo, AbstractC0070AI.this.f221we);
        }

        @Override
        public int read() {
            if (read(this.f229DW, 0, 1) == 1) {
                return this.f229DW[0] & 255;
            }
            return -1;
        }

        @Override
        public int read(byte[] bArr, int i, int i2) throws YC {
            int i3 = 0;
            while (i3 < i2) {
                try {
                    int iInflate = this.f234j6.inflate(bArr, i + i3, i2 - i3);
                    if (iInflate != 0) {
                        i3 += iInflate;
                    } else {
                        if (this.f234j6.finished()) {
                            break;
                        }
                        if (!this.f234j6.needsInput()) {
                            throw new YC(MessageFormat.format(JGitText.j6().packfileCorruptionDetected, JGitText.j6().unknownZlibError));
                        }
                        AbstractC0070AI.this.m786j6(this.f230FH, AbstractC0070AI.this.f218u7, this.f233Zo, AbstractC0070AI.this.f221we);
                        AbstractC0070AI.this.m739Hw(AbstractC0070AI.this.f221we);
                        this.f233Zo = AbstractC0070AI.this.m748j6(this.f230FH, 1);
                        this.f234j6.setInput(AbstractC0070AI.this.f218u7, this.f233Zo, AbstractC0070AI.this.f221we);
                    }
                } catch (DataFormatException e) {
                    throw new YC(MessageFormat.format(JGitText.j6().packfileCorruptionDetected, e.getMessage()));
                }
            }
            this.f235v5 += (long) i3;
            if (i3 > 0) {
                return i3;
            }
            return -1;
        }

        @Override
        public long skip(long j) throws YC {
            long j2 = 0;
            while (j2 < j) {
                int i = read(this.f229DW, 0, (int) Math.min(this.f229DW.length, j - j2));
                if (i <= 0) {
                    break;
                }
                j2 += (long) i;
            }
            return j2;
        }
    }

    public static class d {

        public long f236DW;

        public int f237j6;
    }

    public enum e {
        INPUT,
        DATABASE;

        public static e[] valuesCustom() {
            e[] eVarArrValuesCustom = values();
            int length = eVarArrValuesCustom.length;
            e[] eVarArr = new e[length];
            System.arraycopy(eVarArrValuesCustom, 0, eVarArr, 0, length);
            return eVarArr;
        }
    }

    public static class f {

        int f241DW;

        f f242FH;

        long f243j6;

        public long m805j6() {
            return this.f243j6;
        }

        public void m806j6(int i) {
            this.f241DW = i;
        }
    }

    protected AbstractC0070AI(xE xEVar, InputStream inputStream) {
        this.f195DW = xEVar.FH();
        this.f213gn = inputStream;
        this.f194BT = this.f195DW.v5();
    }

    private d m729DW(f fVar, d dVar) {
        this.f196EQ = 0;
        this.f221we = 0;
        m776j6(fVar, dVar);
        return dVar;
    }

    private d m730DW(CI ci, d dVar) {
        this.f196EQ = 0;
        this.f221we = 0;
        m777j6(ci, dVar);
        return dVar;
    }

    private void m731DW(long j, int i, long j2) throws IOException {
        byte[] bArrM734DW;
        int i2;
        this.f208Zo.update(hE.j6(i));
        this.f208Zo.update((byte) 32);
        this.f208Zo.update(hE.j6(j2));
        boolean z = false;
        this.f208Zo.update((byte) 0);
        if (i == 3) {
            byte[] bArrM766DW = m766DW();
            InputStream inputStreamM752j6 = m752j6(e.INPUT, j2);
            long j3 = 0;
            while (j3 < j2 && (i2 = inputStreamM752j6.read(bArrM766DW)) > 0) {
                this.f208Zo.update(bArrM766DW, 0, i2);
                j3 += (long) i2;
            }
            inputStreamM752j6.close();
            this.f205VH.Hw(this.f208Zo.digest(), 0);
            if (m797u7() && this.f194BT.DW(this.f205VH)) {
                z = true;
            }
            bArrM734DW = null;
        } else {
            bArrM734DW = m734DW(e.INPUT, j2);
            this.f208Zo.update(bArrM734DW);
            this.f205VH.Hw(this.f208Zo.digest(), 0);
            m757j6((YD) this.f205VH, i, bArrM734DW);
        }
        CI ciM778j6 = m778j6((YD) this.f205VH, (f) null, (yE) null);
        ciM778j6.j6(j);
        m787j6(ciM778j6);
        if (bArrM734DW != null) {
            m788j6(ciM778j6, i, bArrM734DW);
        }
        m732DW(ciM778j6);
        if (z) {
            this.f222yS.add(ciM778j6);
        }
    }

    private void m732DW(CI ci) {
        CI[] ciArr = this.f214j3;
        int i = this.f209a8;
        this.f209a8 = i + 1;
        ciArr[i] = ci;
        if (m743Ws()) {
            this.f201Mr.j6(ci);
        }
    }

    private void m733DW(LE le) throws uD, IOException {
        int i = this.f209a8;
        for (int i2 = 0; i2 < i; i2++) {
            m756j6(this.f214j3[i2], le);
            if (le.isCancelled()) {
                throw new IOException(JGitText.j6().downloadCancelledDuringIndexing);
            }
        }
    }

    private byte[] m734DW(e eVar, long j) throws IOException {
        byte[] bArr = new byte[(int) j];
        InputStream inputStreamM752j6 = m752j6(eVar, j);
        C0115BK.m1031j6(inputStreamM752j6, bArr, 0, bArr.length);
        inputStreamM752j6.close();
        return bArr;
    }

    private f m735FH(CI ci) {
        f fVar;
        f fVarM750j6 = m750j6(m751j6((YD) ci));
        f fVarM750j7 = m750j6((f) this.f211er.j6(ci.getOffset()));
        if (fVarM750j6 == null) {
            return fVarM750j7;
        }
        if (fVarM750j7 == null) {
            return fVarM750j6;
        }
        f fVar2 = null;
        f fVar3 = null;
        while (true) {
            if (fVarM750j6 == null && fVarM750j7 == null) {
                return fVar2;
            }
            if (fVarM750j7 == null || (fVarM750j6 != null && fVarM750j6.f243j6 < fVarM750j7.f243j6)) {
                fVar = fVarM750j7;
                fVarM750j7 = fVarM750j6;
                fVarM750j6 = fVarM750j6.f242FH;
            } else {
                fVar = fVarM750j7.f242FH;
            }
            if (fVar3 != null) {
                fVar3.f242FH = fVarM750j7;
            } else {
                fVar2 = fVarM750j7;
            }
            fVarM750j7.f242FH = null;
            fVar3 = fVarM750j7;
            fVarM750j7 = fVar;
        }
    }

    private void m736FH(int i) {
        CI[] ciArr = new CI[((int) this.f210aM) + i];
        System.arraycopy(this.f214j3, 0, ciArr, 0, this.f209a8);
        this.f214j3 = ciArr;
    }

    private void m737FH(e eVar, long j) throws IOException {
        InputStream inputStreamM752j6 = m752j6(eVar, j);
        C0115BK.m1030j6(inputStreamM752j6, j);
        inputStreamM752j6.close();
    }

    private void m738FH(LE le) throws fD, uD, IOException {
        m736FH(this.f215lg.size());
        if (this.f203QX) {
            this.f216rN = new DE();
        }
        ArrayList<a> arrayList = new ArrayList(64);
        for (a aVar : this.f215lg) {
            if (aVar.f223EQ != null) {
                if (this.f203QX) {
                    this.f216rN.j6(aVar);
                }
                try {
                    FE feFH = this.f194BT.FH(aVar);
                    b bVar = new b();
                    bVar.f225FH = feFH.DW(Integer.MAX_VALUE);
                    bVar.f224DW = aVar;
                    int iFH = feFH.FH();
                    CI ciM778j6 = m778j6((YD) aVar, (f) null, (yE) null);
                    if (m795j6(iFH, bVar.f225FH, ciM778j6)) {
                        CI[] ciArr = this.f214j3;
                        int i = this.f209a8;
                        this.f209a8 = i + 1;
                        ciArr[i] = ciM778j6;
                    }
                    bVar.f228v5 = m735FH(ciM778j6);
                    m754j6(bVar.m802j6(), iFH, new d(), le);
                    if (le.isCancelled()) {
                        throw new IOException(JGitText.j6().downloadCancelledDuringIndexing);
                    }
                } catch (fD unused) {
                    arrayList.add(aVar);
                }
            }
        }
        for (a aVar2 : arrayList) {
            if (aVar2.f223EQ != null) {
                throw new fD(aVar2, "delta base");
            }
        }
        m767EQ();
    }

    public void m739Hw(int i) {
        this.f196EQ += i;
        this.f221we -= i;
    }

    private void m740J0() {
        this.f213gn = null;
    }

    private void m741J8() throws uD, IOException {
        long jM745aM = m745aM();
        int iM747j6 = m747j6(e.INPUT);
        this.f219v5[0] = (byte) iM747j6;
        int i = (iM747j6 >> 4) & 7;
        int i2 = 1;
        long j = iM747j6 & 15;
        int i3 = 4;
        int i4 = 1;
        while ((iM747j6 & 128) != 0) {
            iM747j6 = m747j6(e.INPUT);
            this.f219v5[i4] = (byte) iM747j6;
            j += (long) ((iM747j6 & 127) << i3);
            i3 += 7;
            i4++;
            i2 = 1;
        }
        m753j6(i, j);
        if (i == i2 || i == 2 || i == 3 || i == 4) {
            long j2 = j;
            m783j6(jM745aM, i, j2);
            m764DW(e.INPUT, this.f219v5, 0, i4);
            m731DW(jM745aM, i, j2);
            return;
        }
        if (i == 6) {
            int iM747j7 = m747j6(e.INPUT);
            this.f219v5[i4] = (byte) iM747j7;
            long j3 = iM747j7 & 127;
            int i5 = i4 + 1;
            while ((iM747j7 & 128) != 0) {
                iM747j7 = m747j6(e.INPUT);
                this.f219v5[i5] = (byte) iM747j7;
                j3 = ((j3 + 1) << 7) + ((long) (iM747j7 & 127));
                i5++;
                i2 = 1;
            }
            long j4 = jM745aM - j3;
            m784j6(jM745aM, j4, j);
            m764DW(e.INPUT, this.f219v5, 0, i5);
            m737FH(e.INPUT, j);
            f fVarM796tp = m796tp();
            fVarM796tp.f243j6 = jM745aM;
            fVarM796tp.f242FH = (f) this.f211er.j6(j4, fVarM796tp);
            this.f204U2 += i2;
            return;
        }
        if (i != 7) {
            String str = JGitText.j6().unknownObjectType;
            Object[] objArr = new Object[i2];
            objArr[0] = Integer.valueOf(i);
            throw new IOException(MessageFormat.format(str, objArr));
        }
        int iM748j6 = m748j6(e.INPUT, 20);
        YD ydHw = yE.Hw(this.f218u7, iM748j6);
        System.arraycopy(this.f218u7, iM748j6, this.f219v5, i4, 20);
        int i6 = i4 + 20;
        m739Hw(20);
        a aVar = (a) this.f215lg.m710DW(ydHw);
        if (aVar == null) {
            aVar = new a(ydHw);
            this.f215lg.m711j6(aVar);
        }
        a aVar2 = aVar;
        m785j6(jM745aM, ydHw, j);
        m764DW(e.INPUT, this.f219v5, 0, i6);
        m737FH(e.INPUT, j);
        f fVarM796tp2 = m796tp();
        fVarM796tp2.f243j6 = jM745aM;
        aVar2.m801j6(fVarM796tp2);
        this.f204U2 += i2;
    }

    private void m742QX() throws YC {
        int i;
        m746j3();
        byte[] bArrDigest = this.f212gW.digest();
        byte[] bArr = new byte[20];
        System.arraycopy(this.f218u7, m748j6(e.INPUT, 20), bArr, 0, 20);
        m739Hw(20);
        if (this.f221we != 0) {
            throw new YC(MessageFormat.format(JGitText.j6().expectedEOFReceived, "\\x" + Integer.toHexString(this.f218u7[this.f196EQ] & 255)));
        }
        if (!m774gn() || (i = this.f213gn.read()) < 0) {
            if (!Arrays.equals(bArrDigest, bArr)) {
                throw new YC(JGitText.j6().corruptObjectPackfileChecksumIncorrect);
            }
            m792j6(bArr);
        } else {
            throw new YC(MessageFormat.format(JGitText.j6().expectedEOFReceived, "\\x" + Integer.toHexString(i)));
        }
    }

    private boolean m743Ws() {
        return this.f201Mr != null;
    }

    private void m744XL() throws IOException {
        int length = hE.v5.length + 4 + 4;
        int iM748j6 = m748j6(e.INPUT, length);
        int i = 0;
        while (true) {
            byte[] bArr = hE.v5;
            if (i >= bArr.length) {
                long jFH = FK.FH(this.f218u7, iM748j6 + 4);
                if (jFH != 2 && jFH != 3) {
                    throw new IOException(MessageFormat.format(JGitText.j6().unsupportedPackVersion, Long.valueOf(jFH)));
                }
                this.f210aM = FK.FH(this.f218u7, iM748j6 + 8);
                m739Hw(length);
                m782j6(this.f210aM);
                return;
            }
            if (this.f218u7[iM748j6 + i] != bArr[i]) {
                throw new IOException(JGitText.j6().notAPACKFile);
            }
            i++;
        }
    }

    private long m745aM() {
        return this.f217tp + ((long) this.f196EQ);
    }

    private void m746j3() {
        this.f212gW.update(this.f218u7, 0, this.f196EQ);
        m793j6(this.f218u7, 0, this.f196EQ);
        int i = this.f221we;
        if (i > 0) {
            byte[] bArr = this.f218u7;
            System.arraycopy(bArr, this.f196EQ, bArr, 0, i);
        }
        this.f217tp += (long) this.f196EQ;
        this.f196EQ = 0;
    }

    private int m747j6(e eVar) throws IOException {
        if (this.f221we == 0) {
            m748j6(eVar, 1);
        }
        this.f221we--;
        byte[] bArr = this.f218u7;
        int i = this.f196EQ;
        this.f196EQ = i + 1;
        return bArr[i] & 255;
    }

    public int m748j6(e eVar, int i) throws IOException {
        while (true) {
            int i2 = this.f221we;
            if (i2 >= i) {
                return this.f196EQ;
            }
            int iM761DW = this.f196EQ + i2;
            int length = this.f218u7.length - iM761DW;
            if (i2 + length < i) {
                int i3 = m759j6()[eVar.ordinal()];
                if (i3 == 1) {
                    m746j3();
                } else if (i3 == 2) {
                    int i4 = this.f221we;
                    if (i4 > 0) {
                        byte[] bArr = this.f218u7;
                        System.arraycopy(bArr, this.f196EQ, bArr, 0, i4);
                    }
                    this.f196EQ = 0;
                }
                iM761DW = this.f221we;
                length = this.f218u7.length - iM761DW;
            }
            int i5 = m759j6()[eVar.ordinal()];
            if (i5 == 1) {
                iM761DW = this.f213gn.read(this.f218u7, iM761DW, length);
            } else if (i5 == 2) {
                iM761DW = m761DW(this.f218u7, iM761DW, length);
            }
            if (iM761DW <= 0) {
                throw new EOFException(JGitText.j6().packfileIsTruncated);
            }
            this.f221we += iM761DW;
        }
    }

    private static f m750j6(f fVar) {
        f fVar2 = fVar;
        f fVar3 = null;
        while (fVar2 != null) {
            f fVar4 = fVar2.f242FH;
            fVar2.f242FH = fVar3;
            fVar3 = fVar2;
            fVar2 = fVar4;
        }
        return fVar3;
    }

    private f m751j6(YD yd) {
        a aVar = (a) this.f215lg.m710DW(yd);
        if (aVar != null) {
            return aVar.m800aM();
        }
        return null;
    }

    private InputStream m752j6(e eVar, long j) {
        this.f197FH.m804j6(eVar, j);
        return this.f197FH;
    }

    private final void m753j6(int i, long j) throws uD, IOException {
        long j2 = this.f202P8;
        if (0 >= j2 || j2 >= j) {
            return;
        }
        if (i == 1 || i == 2 || i == 3 || i == 4) {
            throw new uD(j, this.f202P8);
        }
        if (i != 6 && i != 7) {
            throw new IOException(MessageFormat.format(JGitText.j6().unknownObjectType, Integer.valueOf(i)));
        }
        throw new uD(this.f202P8);
    }

    private void m754j6(b bVar, int i, d dVar, LE le) throws uD, IOException {
        do {
            le.update(1);
            m729DW(bVar.f227j6, dVar);
            int i2 = dVar.f237j6;
            if (i2 != 6 && i2 != 7) {
                throw new IOException(MessageFormat.format(JGitText.j6().unknownObjectType, Integer.valueOf(dVar.f237j6)));
            }
            byte[] bArrM734DW = m734DW(e.DATABASE, dVar.f236DW);
            m753j6(i, C0069AH.m725j6(bArrM734DW));
            bVar.f225FH = C0069AH.m726j6(bVar.f226Hw.f225FH, bArrM734DW);
            if (!m794j6(bVar.f227j6.f241DW)) {
                throw new IOException(MessageFormat.format(JGitText.j6().corruptionDetectedReReadingAt, Long.valueOf(bVar.f227j6.f243j6)));
            }
            this.f208Zo.update(hE.j6(i));
            this.f208Zo.update((byte) 32);
            this.f208Zo.update(hE.j6(bVar.f225FH.length));
            this.f208Zo.update((byte) 0);
            this.f208Zo.update(bVar.f225FH);
            this.f205VH.Hw(this.f208Zo.digest(), 0);
            m757j6((YD) this.f205VH, i, bVar.f225FH);
            CI ciM778j6 = m778j6((YD) this.f205VH, bVar.f227j6, bVar.f226Hw.f224DW);
            ciM778j6.j6(bVar.f227j6.f243j6);
            m788j6(ciM778j6, i, bVar.f225FH);
            m732DW(ciM778j6);
            bVar.f224DW = ciM778j6;
            bVar.f228v5 = m735FH(ciM778j6);
            bVar = bVar.m802j6();
        } while (bVar != null);
    }

    private void m756j6(CI ci, LE le) throws uD, IOException {
        f fVarM735FH = m735FH(ci);
        if (fVarM735FH == null) {
            return;
        }
        b bVar = new b();
        bVar.f228v5 = fVarM735FH;
        d dVar = new d();
        m730DW(ci, dVar);
        int i = dVar.f237j6;
        if (i != 1 && i != 2 && i != 3 && i != 4) {
            throw new IOException(MessageFormat.format(JGitText.j6().unknownObjectType, Integer.valueOf(dVar.f237j6)));
        }
        bVar.f225FH = m734DW(e.DATABASE, dVar.f236DW);
        bVar.f224DW = ci;
        if (!m794j6(ci.aM())) {
            throw new IOException(MessageFormat.format(JGitText.j6().corruptionDetectedReReadingAt, Long.valueOf(ci.getOffset())));
        }
        m754j6(bVar.m802j6(), dVar.f237j6, dVar, le);
    }

    private void m757j6(YD yd, int i, byte[] bArr) throws IOException {
        wE wEVar = this.f199J0;
        if (wEVar != null) {
            try {
                wEVar.j6(i, bArr);
            } catch (YC e2) {
                throw new IOException(MessageFormat.format(JGitText.j6().invalidObject, hE.DW(i), yd.we(), e2.getMessage()));
            }
        }
        if (m797u7()) {
            try {
                if (Arrays.equals(bArr, this.f194BT.Hw(yd, i).DW(bArr.length))) {
                } else {
                    throw new IOException(MessageFormat.format(JGitText.j6().collisionOn, yd.we()));
                }
            } catch (fD unused) {
            }
        }
    }

    static int[] m759j6() {
        int[] iArr = f193j6;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[e.valuesCustom().length];
        try {
            iArr2[e.DATABASE.ordinal()] = 2;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[e.INPUT.ordinal()] = 1;
        } catch (NoSuchFieldError unused2) {
        }
        f193j6 = iArr2;
        return iArr2;
    }

    private void m760we() throws IOException {
        byte[] bArrM766DW = m766DW();
        byte[] bArr = new byte[bArrM766DW.length];
        d dVar = new d();
        for (CI ci : this.f222yS) {
            m730DW(ci, dVar);
            int i = dVar.f237j6;
            if (i != 3) {
                throw new IOException(MessageFormat.format(JGitText.j6().unknownObjectType, Integer.valueOf(dVar.f237j6)));
            }
            JE jeV5 = this.f194BT.Hw(ci, i).v5();
            try {
                long j = dVar.f236DW;
                if (jeV5.j6() != j) {
                    throw new IOException(MessageFormat.format(JGitText.j6().collisionOn, ci.we()));
                }
                InputStream inputStreamM752j6 = m752j6(e.DATABASE, j);
                while (0 < j) {
                    int iMin = (int) Math.min(bArrM766DW.length, j);
                    C0115BK.m1031j6(jeV5, bArr, 0, iMin);
                    C0115BK.m1031j6(inputStreamM752j6, bArrM766DW, 0, iMin);
                    for (int i2 = 0; i2 < iMin; i2++) {
                        if (bArr[i2] != bArrM766DW[i2]) {
                            throw new IOException(MessageFormat.format(JGitText.j6().collisionOn, ci.we()));
                        }
                    }
                    j -= (long) iMin;
                }
                inputStreamM752j6.close();
                jeV5.close();
            } catch (Throwable th) {
                jeV5.close();
                throw th;
            }
        }
    }

    protected abstract int m761DW(byte[] bArr, int i, int i2);

    public CI m762DW(int i) {
        return this.f214j3[i];
    }

    public void m763DW(long j) {
        this.f202P8 = j;
    }

    protected abstract void m764DW(e eVar, byte[] bArr, int i, int i2);

    public void m765DW(boolean z) {
        this.f207XL = z;
    }

    protected byte[] m766DW() {
        return this.f198Hw;
    }

    protected abstract void m767EQ();

    public DE<yE> m768FH() {
        DE<yE> de = this.f216rN;
        return de != null ? de : new DE();
    }

    public void m769FH(boolean z) {
        this.f203QX = z;
    }

    public String m770Hw() {
        return this.f220vy;
    }

    public void m771Hw(boolean z) {
        if (z) {
            this.f201Mr = new DE();
        } else {
            this.f201Mr = null;
        }
    }

    public boolean m772VH() {
        return this.f200J8;
    }

    public int m773Zo() {
        return this.f209a8;
    }

    public boolean m774gn() {
        return this.f207XL;
    }

    protected d m775j6(d dVar) throws IOException {
        int iM747j6 = m747j6(e.DATABASE);
        this.f219v5[0] = (byte) iM747j6;
        dVar.f237j6 = (iM747j6 >> 4) & 7;
        long j = iM747j6 & 15;
        int i = 1;
        int i2 = 4;
        while ((iM747j6 & 128) != 0) {
            iM747j6 = m747j6(e.DATABASE);
            this.f219v5[i] = (byte) iM747j6;
            j += (long) ((iM747j6 & 127) << i2);
            i2 += 7;
            i++;
        }
        dVar.f236DW = j;
        int i3 = dVar.f237j6;
        if (i3 == 1 || i3 == 2 || i3 == 3 || i3 == 4) {
            m764DW(e.DATABASE, this.f219v5, 0, i);
        } else if (i3 == 6) {
            int iM747j7 = m747j6(e.DATABASE);
            int i4 = i + 1;
            this.f219v5[i] = (byte) iM747j7;
            while ((iM747j7 & 128) != 0) {
                iM747j7 = m747j6(e.DATABASE);
                this.f219v5[i4] = (byte) iM747j7;
                i4++;
            }
            m764DW(e.DATABASE, this.f219v5, 0, i4);
        } else {
            if (i3 != 7) {
                throw new IOException(MessageFormat.format(JGitText.j6().unknownObjectType, Integer.valueOf(dVar.f237j6)));
            }
            System.arraycopy(this.f218u7, m748j6(e.DATABASE, 20), this.f219v5, i, 20);
            m739Hw(20);
            m764DW(e.DATABASE, this.f219v5, 0, i + 20);
        }
        return dVar;
    }

    protected abstract d m776j6(f fVar, d dVar);

    protected abstract d m777j6(CI ci, d dVar);

    protected CI m778j6(YD yd, f fVar, yE yEVar) {
        CI ci = new CI(yd);
        if (fVar != null) {
            ci.DW(fVar.f241DW);
        }
        return ci;
    }

    public final kH m779j6(LE le) {
        return m780j6(le, le);
    }

    public kH m780j6(LE le, LE le2) {
        if (le == null) {
            le = vE.j6;
        }
        if (le2 == null) {
            le2 = vE.j6;
        }
        if (le == le2) {
            le.start(2);
        }
        try {
            m744XL();
            this.f214j3 = new CI[(int) this.f210aM];
            this.f215lg = new C0066AE();
            this.f211er = new wI();
            this.f222yS = new lK();
            le.j6(JGitText.j6().receivingObjects, (int) this.f210aM);
            for (int i = 0; i < this.f210aM; i++) {
                try {
                    m741J8();
                    le.update(1);
                    if (le.isCancelled()) {
                        throw new IOException(JGitText.j6().downloadCancelled);
                    }
                } catch (Throwable th) {
                    le.j6();
                    throw th;
                }
            }
            m742QX();
            m740J0();
            le.j6();
            if (!this.f222yS.isEmpty()) {
                m760we();
            }
            if (this.f204U2 > 0) {
                if (le2 instanceof eE) {
                    ((eE) le2).j6(1000L, TimeUnit.MILLISECONDS);
                }
                le2.j6(JGitText.j6().resolvingDeltas, this.f204U2);
                m733DW(le2);
                if (this.f209a8 < this.f210aM) {
                    if (!m772VH()) {
                        throw new IOException(MessageFormat.format(JGitText.j6().packHasUnresolvedDeltas, Long.valueOf(this.f210aM - ((long) this.f209a8))));
                    }
                    m738FH(le2);
                    if (this.f209a8 < this.f210aM) {
                        throw new IOException(MessageFormat.format(JGitText.j6().packHasUnresolvedDeltas, Long.valueOf(this.f210aM - ((long) this.f209a8))));
                    }
                }
                le2.j6();
            }
            this.f212gW = null;
            this.f215lg = null;
            this.f211er = null;
            try {
                if (this.f194BT != null) {
                    this.f194BT.FH();
                }
                this.f194BT = null;
                try {
                    this.f197FH.m803j6();
                    return null;
                } finally {
                    this.f197FH = null;
                }
            } catch (Throwable th2) {
                this.f194BT = null;
                throw th2;
            }
        } catch (Throwable th3) {
            try {
                if (this.f194BT != null) {
                    this.f194BT.FH();
                }
                this.f194BT = null;
                try {
                    this.f197FH.m803j6();
                    throw th3;
                } finally {
                    this.f197FH = null;
                }
            } catch (Throwable th4) {
                this.f194BT = null;
                throw th4;
            }
        }
    }

    public List<CI> m781j6(Comparator<CI> comparator) {
        Arrays.sort(this.f214j3, 0, this.f209a8, comparator);
        List<CI> listAsList = Arrays.asList(this.f214j3);
        int i = this.f209a8;
        return i < this.f214j3.length ? listAsList.subList(0, i) : listAsList;
    }

    protected abstract void m782j6(long j);

    protected abstract void m783j6(long j, int i, long j2);

    protected abstract void m784j6(long j, long j2, long j3);

    protected abstract void m785j6(long j, YD yd, long j2);

    protected abstract void m786j6(e eVar, byte[] bArr, int i, int i2);

    protected abstract void m787j6(CI ci);

    protected abstract void m788j6(CI ci, int i, byte[] bArr);

    public void m789j6(wE wEVar) {
        this.f199J0 = wEVar;
    }

    public void m790j6(String str) {
        this.f220vy = str;
    }

    public void m791j6(boolean z) {
        this.f200J8 = z;
    }

    protected abstract void m792j6(byte[] bArr);

    protected abstract void m793j6(byte[] bArr, int i, int i2);

    protected abstract boolean m794j6(int i);

    protected abstract boolean m795j6(int i, byte[] bArr, CI ci);

    protected abstract f m796tp();

    public boolean m797u7() {
        return this.f206Ws;
    }

    public DE<yE> m798v5() {
        DE<yE> de = this.f201Mr;
        return de != null ? de : new DE();
    }

    public void m799v5(boolean z) {
        m789j6(z ? new wE() : null);
    }
}
