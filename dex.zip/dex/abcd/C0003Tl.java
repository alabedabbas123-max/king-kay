package abcd;

@xu
public class C0003Tl {

    @uu
    private static boolean f8DW;

    @tu
    private static boolean f9j6;

    public String f10FH;

    public int f11Hw;

    public int f12VH;

    public int f13Zo;

    public int f14v5;

    static {
        wu.j6(C0003Tl.class, -2158333802730359760L, -2158333802730359760L);
    }

    public C0003Tl(String str, int i, int i2, int i3, int i4) {
        try {
            if (f9j6) {
                wu.j6(-415774639461878880L, (Object) null, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            this.f10FH = str;
            this.f11Hw = i;
            this.f14v5 = i2;
            this.f13Zo = i3;
            this.f12VH = i4;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, -415774639461878880L, (Object) null, str, new Integer(i), new Integer(i2), new Integer(i3), new Integer(i4));
            }
            throw th;
        }
    }

    public boolean m6DW() {
        try {
            if (f9j6) {
                wu.j6(-1501909828150693592L, this);
            }
            return this.f11Hw == this.f13Zo;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, -1501909828150693592L, this);
            }
            throw th;
        }
    }

    public boolean equals(Object obj) {
        try {
            if (f9j6) {
                wu.j6(342990384739897176L, this, obj);
            }
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            C0003Tl c0003Tl = (C0003Tl) obj;
            if (this.f12VH != c0003Tl.f12VH || this.f13Zo != c0003Tl.f13Zo) {
                return false;
            }
            if (this.f10FH == null) {
                if (c0003Tl.f10FH != null) {
                    return false;
                }
            } else if (!this.f10FH.equals(c0003Tl.f10FH)) {
                return false;
            }
            return this.f14v5 == c0003Tl.f14v5 && this.f11Hw == c0003Tl.f11Hw;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 342990384739897176L, this, obj);
            }
            throw th;
        }
    }

    public int hashCode() {
        try {
            if (f9j6) {
                wu.j6(2093363941184924245L, this);
            }
            return ((((((((this.f12VH + 31) * 31) + this.f13Zo) * 31) + (this.f10FH == null ? 0 : this.f10FH.hashCode())) * 31) + this.f14v5) * 31) + this.f11Hw;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 2093363941184924245L, this);
            }
            throw th;
        }
    }

    public boolean m7j6() {
        try {
            if (f9j6) {
                wu.j6(371353706849630307L, this);
            }
            return this.f11Hw == this.f13Zo && this.f14v5 == this.f12VH;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 371353706849630307L, this);
            }
            throw th;
        }
    }

    public boolean m8j6(C0003Tl c0003Tl) {
        try {
            if (f9j6) {
                wu.j6(233253864155778200L, this, c0003Tl);
            }
            return c0003Tl.f10FH.equals(this.f10FH) && Math.abs(c0003Tl.f11Hw - this.f11Hw) < 20;
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 233253864155778200L, this, c0003Tl);
            }
            throw th;
        }
    }

    public String toString() {
        try {
            if (f9j6) {
                wu.j6(2910247968380441856L, this);
            }
            return this.f10FH + " (" + this.f11Hw + "," + this.f14v5 + "-" + this.f13Zo + "," + this.f12VH + ")";
        } catch (Throwable th) {
            if (f8DW) {
                wu.j6(th, 2910247968380441856L, this);
            }
            throw th;
        }
    }
}
