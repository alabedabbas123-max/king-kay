package abcd;

public abstract class AbstractC0101Gp extends vp implements Comparable<AbstractC0101Gp> {

    private int f557DW;

    private Kp f558FH;

    private int f559Hw;

    private final int f560j6;

    public AbstractC0101Gp(int i, int i2) {
        Kp.FH(i);
        if (i2 < -1) {
            throw new IllegalArgumentException("writeSize < -1");
        }
        this.f560j6 = i;
        this.f557DW = i2;
        this.f558FH = null;
        this.f559Hw = -1;
    }

    public static int m924FH(AbstractC0101Gp abstractC0101Gp) {
        if (abstractC0101Gp == null) {
            return 0;
        }
        return abstractC0101Gp.m936we();
    }

    protected int m925DW(AbstractC0101Gp abstractC0101Gp) {
        throw new UnsupportedOperationException("unsupported");
    }

    protected void m926DW(Kp kp, int i) {
    }

    protected abstract void m927DW(jp jpVar, Lt lt);

    public final int m928J8() {
        return this.f560j6;
    }

    public final int m929VH() {
        int i = this.f557DW;
        if (i >= 0) {
            return i;
        }
        throw new UnsupportedOperationException("writeSize is unknown");
    }

    public final String m930Ws() {
        return '[' + Integer.toHexString(m936we()) + ']';
    }

    public abstract String m931aM();

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        AbstractC0101Gp abstractC0101Gp = (AbstractC0101Gp) obj;
        return Hw() == abstractC0101Gp.Hw() && m925DW(abstractC0101Gp) == 0;
    }

    @Override
    public final int compareTo(AbstractC0101Gp abstractC0101Gp) {
        if (this == abstractC0101Gp) {
            return 0;
        }
        wp wpVarHw = Hw();
        wp wpVarHw2 = abstractC0101Gp.Hw();
        return wpVarHw != wpVarHw2 ? wpVarHw.compareTo(wpVarHw2) : m925DW(abstractC0101Gp);
    }

    public final int m933j6(Kp kp, int i) {
        if (kp == null) {
            throw new NullPointerException("addedTo == null");
        }
        if (i < 0) {
            throw new IllegalArgumentException("offset < 0");
        }
        if (this.f558FH != null) {
            throw new RuntimeException("already written");
        }
        int i2 = this.f560j6 - 1;
        int i3 = (i + i2) & (i2 ^ (-1));
        this.f558FH = kp;
        this.f559Hw = i3;
        m926DW(kp, i3);
        return i3;
    }

    public final void m934j6(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("writeSize < 0");
        }
        if (this.f557DW >= 0) {
            throw new UnsupportedOperationException("writeSize already set");
        }
        this.f557DW = i;
    }

    public final void m935j6(jp jpVar, Lt lt) throws Vt {
        lt.Hw(this.f560j6);
        try {
            if (this.f557DW < 0) {
                throw new UnsupportedOperationException("writeSize is unknown");
            }
            lt.FH(m936we());
            m927DW(jpVar, lt);
        } catch (RuntimeException e) {
            throw Vt.j6(e, "...while writing " + this);
        }
    }

    public final int m936we() {
        int i = this.f559Hw;
        if (i >= 0) {
            return this.f558FH.j6(i);
        }
        throw new RuntimeException("offset not yet known");
    }
}
