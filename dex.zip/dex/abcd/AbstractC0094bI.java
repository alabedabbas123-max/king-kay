package abcd;

import java.util.Collection;
import java.util.Set;

abstract class AbstractC0094bI extends AbstractC0050aI implements nI {
    AbstractC0094bI() {
    }

    protected abstract void m655DW(LE le, Collection<ME> collection, Set<yE> set);

    public boolean m656Zo() {
        return false;
    }

    public final void m657j6(LE le, Collection<ME> collection, Set<yE> set) throws yD {
        m301gn();
        m655DW(le, collection, set);
    }
}
