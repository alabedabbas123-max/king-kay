package abcd;

import java.util.ArrayList;

public class C0003et extends Ts {

    private final ArrayList<Nt> f49FH;

    private final Ft f50Hw;

    public C0003et(Ft ft, int i) {
        super(i);
        this.f49FH = new ArrayList<>();
        this.f50Hw = ft;
    }

    private void m8j6(int i, int i2) {
        int i3 = i + 1;
        this.f49FH.ensureCapacity(i3);
        while (i >= this.f49FH.size()) {
            this.f49FH.add(new Nt(i3));
        }
        this.f50Hw.j6(i2, this.f49FH.get(i));
    }

    public boolean m9DW(int i, int i2, int i3) {
        bu buVar;
        if (i2 >= this.f49FH.size() || (buVar = this.f49FH.get(i2)) == null) {
            return false;
        }
        if (i3 == 1) {
            return buVar.j6(i);
        }
        return buVar.j6(i) || m9DW(i, i2 + 1, i3 - 1);
    }

    public void m10j6(int i, int i2, int i3) {
        super.j6(i, i2, i3);
        m8j6(i2, i);
        if (i3 == 2) {
            m8j6(i2 + 1, i);
        }
    }

    public boolean m11j6(bs bsVar, int i) {
        return m9DW(bsVar.we(), i, bsVar.Hw());
    }

    public boolean m12j6(cs csVar, int i, int i2) {
        int size = csVar.size();
        for (int i3 = 0; i3 < size; i3++) {
            bs bsVar = csVar.get(i3);
            int iJ6 = j6(bsVar.we());
            if (iJ6 == i) {
                return true;
            }
            if (bsVar.Hw() == 2 && iJ6 + 1 == i) {
                return true;
            }
            if (i2 == 2 && iJ6 == i + 1) {
                return true;
            }
        }
        return false;
    }
}
