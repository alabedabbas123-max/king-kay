package abcd;

import io.fabric.sdk.android.services.common.k;
import org.json.JSONObject;

class C0001cA implements oA {
    C0001cA() {
    }

    private Wz m4DW(JSONObject jSONObject) {
        return new Wz(jSONObject.getString("identifier"), jSONObject.getString("status"), jSONObject.getString("url"), jSONObject.getString("reports_url"), jSONObject.getString("ndk_reports_url"), jSONObject.optBoolean("update_required", false), (jSONObject.has("icon") && jSONObject.getJSONObject("icon").has("hash")) ? m11v5(jSONObject.getJSONObject("icon")) : null);
    }

    private Yz m5FH(JSONObject jSONObject) {
        return new Yz(jSONObject.optString("update_endpoint", nA.j6), jSONObject.optInt("update_suspend_duration", 3600));
    }

    private C0089eA m6Hw(JSONObject jSONObject) {
        return new C0089eA(jSONObject.optBoolean("prompt_enabled", false), jSONObject.optBoolean("collect_logged_exceptions", true), jSONObject.optBoolean("collect_reports", true), jSONObject.optBoolean("collect_analytics", false), jSONObject.optBoolean("firebase_crashlytics_enabled", false));
    }

    private hA m7VH(JSONObject jSONObject) {
        return new hA(jSONObject.optInt("log_buffer_size", 64000), jSONObject.optInt("max_chained_exception_depth", 8), jSONObject.optInt("max_custom_exception_events", 64), jSONObject.optInt("max_custom_key_value_pairs", 64), jSONObject.optInt("identifier_mask", 255), jSONObject.optBoolean("send_session_without_crash", false), jSONObject.optInt("max_complete_sessions_count", 4));
    }

    private gA m8Zo(JSONObject jSONObject) {
        return new gA(jSONObject.optString("title", "Send Crash Report?"), jSONObject.optString("message", "Looks like we crashed! Please help us fix the problem by sending a crash report."), jSONObject.optString("send_button_title", "Send"), jSONObject.optBoolean("show_cancel_button", true), jSONObject.optString("cancel_button_title", "Don't Send"), jSONObject.optBoolean("show_always_send_button", true), jSONObject.optString("always_send_button_title", "Always Send"));
    }

    private long m9j6(k kVar, long j, JSONObject jSONObject) {
        if (jSONObject.has("expires_at")) {
            return jSONObject.getLong("expires_at");
        }
        return (j * 1000) + kVar.j6();
    }

    private Tz m10j6(JSONObject jSONObject) {
        return new Tz(jSONObject.optString("url", "https://e.crashlytics.com/spi/v2/events"), jSONObject.optInt("flush_interval_secs", 600), jSONObject.optInt("max_byte_size_per_file", 8000), jSONObject.optInt("max_file_count_per_send", 1), jSONObject.optInt("max_pending_send_file_count", 100), jSONObject.optBoolean("forward_to_google_analytics", false), jSONObject.optBoolean("include_purchase_events_in_forwarded_events", false), jSONObject.optBoolean("track_custom_events", true), jSONObject.optBoolean("track_predefined_events", true), jSONObject.optInt("sampling_rate", 1), jSONObject.optBoolean("flush_on_background", true));
    }

    private Uz m11v5(JSONObject jSONObject) {
        return new Uz(jSONObject.getString("hash"), jSONObject.getInt("width"), jSONObject.getInt("height"));
    }

    public mA m12j6(k kVar, JSONObject jSONObject) {
        int iOptInt = jSONObject.optInt("settings_version", 0);
        int iOptInt2 = jSONObject.optInt("cache_duration", 3600);
        return new mA(m9j6(kVar, iOptInt2, jSONObject), m4DW(jSONObject.getJSONObject("app")), m7VH(jSONObject.getJSONObject("session")), m8Zo(jSONObject.getJSONObject("prompt")), m6Hw(jSONObject.getJSONObject("features")), m10j6(jSONObject.getJSONObject("analytics")), m5FH(jSONObject.getJSONObject("beta")), iOptInt, iOptInt2);
    }
}
