package abcd;

import com.aide.common.u;
import com.aide.ui.U;
import com.aide.ui.activities.GotoBrowserActivity;

@xu
public class C0024cg implements Yl, Wl {

    @uu
    private static boolean f78DW;

    @tu
    private static boolean f79j6;

    static {
        wu.j6(C0024cg.class, -705504967078967784L, -705504967078967784L);
    }

    public C0024cg() {
        try {
            if (f79j6) {
                wu.j6(4854646396753910568L, (Object) null);
            }
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, 4854646396753910568L, (Object) null);
            }
            throw th;
        }
    }

    public u m126FH() {
        try {
            if (f79j6) {
                wu.j6(-4262452799780428280L, this);
            }
            return new u(35, false, true, false);
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, -4262452799780428280L, this);
            }
            throw th;
        }
    }

    public String getName() {
        try {
            if (!f79j6) {
                return "GoTo Symbol";
            }
            wu.j6(-1317034566560717229L, this);
            return "GoTo Symbol";
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, -1317034566560717229L, this);
            }
            throw th;
        }
    }

    public boolean isEnabled() {
        try {
            if (f79j6) {
                wu.j6(-65605793341367405L, this);
            }
            return U.vy().j3();
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, -65605793341367405L, this);
            }
            throw th;
        }
    }

    public int m127j6() {
        try {
            if (!f79j6) {
                return com.aide.pro.R.id.mainMenuGoto;
            }
            wu.j6(-3781179392106130875L, this);
            return com.aide.pro.R.id.mainMenuGoto;
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, -3781179392106130875L, this);
            }
            throw th;
        }
    }

    public boolean m128run() {
        try {
            if (f79j6) {
                wu.j6(-1067545270157890407L, this);
            }
            GotoBrowserActivity.j6(U.lg(), true, 12);
            return true;
        } catch (Throwable th) {
            if (f78DW) {
                wu.j6(th, -1067545270157890407L, this);
            }
            throw th;
        }
    }
}
