package abcd;

@xu
public class C0022ce implements ra {

    @uu
    private static boolean f69DW;

    @tu
    private static boolean f70j6;

    @ru(field = -2139139780097345792L)
    private final La f71FH;

    @ru(field = 1030066624346737227L)
    private final Vd f72Hw;

    @ru(field = 3898946997758287384L)
    private int f73Zo;

    @ru(field = -3459649730819820957L)
    private int f74v5;

    static {
        wu.j6(C0022ce.class, -3550371946293241223L, -3550371946293241223L);
    }

    public C0022ce(La la, Vd vd) {
        try {
            if (f70j6) {
                wu.j6(-2949549167938367895L, (Object) null, la, vd);
            }
            this.f71FH = la;
            this.f72Hw = vd;
            this.f74v5 = la.j3.j6("JavaScript");
            this.f73Zo = la.j3.j6("JavaScriptAPI");
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, -2949549167938367895L, (Object) null, la, vd);
            }
            throw th;
        }
    }

    public Ya m111DW(Da da, Ya ya, Ya ya2) {
        try {
            if (f70j6) {
                wu.j6(-2970902184755943392L, this, da, ya, ya2);
            }
            throw new jc();
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, -2970902184755943392L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public ua m112DW(Da da) {
        try {
            if (f70j6) {
                wu.j6(145224267950032279L, this, da);
            }
            throw new jc();
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 145224267950032279L, this, da);
            }
            throw th;
        }
    }

    public boolean m113DW() {
        try {
            if (!f70j6) {
                return true;
            }
            wu.j6(296402949948934352L, this);
            return true;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 296402949948934352L, this);
            }
            throw th;
        }
    }

    public boolean m114FH() {
        try {
            if (!f70j6) {
                return false;
            }
            wu.j6(-2987432060925499011L, this);
            return false;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, -2987432060925499011L, this);
            }
            throw th;
        }
    }

    public boolean m115FH(Da da, Ya ya, Ya ya2) {
        try {
            if (!f70j6) {
                return false;
            }
            wu.j6(859878868736133547L, this, da, ya, ya2);
            return false;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 859878868736133547L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public boolean m116Hw() {
        try {
            if (!f70j6) {
                return false;
            }
            wu.j6(7371861239296939825L, this);
            return false;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 7371861239296939825L, this);
            }
            throw th;
        }
    }

    public int m117j6(int i) {
        try {
            if (!f70j6) {
                return 0;
            }
            wu.j6(-6285061853871408153L, this, i);
            return 0;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, -6285061853871408153L, this, new Integer(i));
            }
            throw th;
        }
    }

    public int m118j6(Na na, int i) {
        try {
            if (!f70j6) {
                return 0;
            }
            wu.j6(-193717794399278996L, this, na, new Integer(i));
            return 0;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, -193717794399278996L, this, na, new Integer(i));
            }
            throw th;
        }
    }

    public Ya m119j6(Da da, int i, Ya ya, Ya ya2) {
        try {
            if (f70j6) {
                wu.j6(-6921876414834969729L, this, da, new Integer(i), ya, ya2);
            }
            throw new jc();
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, -6921876414834969729L, this, da, new Integer(i), ya, ya2);
            }
            throw th;
        }
    }

    public Ya m120j6(Da da, Ya ya) {
        try {
            if (f70j6) {
                wu.j6(2965419880296166845L, this, da, ya);
            }
            return ya;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 2965419880296166845L, this, da, ya);
            }
            throw th;
        }
    }

    public Yb<Ya> m121j6(Da da, sa saVar) {
        try {
            if (!f70j6) {
                return null;
            }
            wu.j6(780440597847543464L, this, da, saVar);
            return null;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 780440597847543464L, this, da, saVar);
            }
            throw th;
        }
    }

    public ua m122j6(Da da) {
        try {
            if (f70j6) {
                wu.j6(984829485067414653L, this, da);
            }
            throw new jc();
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 984829485067414653L, this, da);
            }
            throw th;
        }
    }

    public boolean m123j6() {
        try {
            if (!f70j6) {
                return false;
            }
            wu.j6(6734551556606797L, this);
            return false;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 6734551556606797L, this);
            }
            throw th;
        }
    }

    public boolean m124j6(Da da, Ya ya, Ya ya2) {
        try {
            if (!f70j6) {
                return false;
            }
            wu.j6(1043881752173504676L, this, da, ya, ya2);
            return false;
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 1043881752173504676L, this, da, ya, ya2);
            }
            throw th;
        }
    }

    public Na m125v5() {
        try {
            if (f70j6) {
                wu.j6(6639138263831220760L, this);
            }
            return this.f71FH.a8.FH().j6(this.f74v5);
        } catch (Throwable th) {
            if (f69DW) {
                wu.j6(th, 6639138263831220760L, this);
            }
            throw th;
        }
    }
}
