package abcd;

import java.io.PrintStream;

public final class C0021Hx {

    private static final int f130DW;

    private static final AbstractC0063Ix f131j6;

    static final class a extends AbstractC0063Ix {
        a() {
        }

        @Override
        public final void mo223j6(Throwable th, Throwable th2) {
        }
    }

    /* JADX WARN: Code duplicated, block: B:10:0x001e A[Catch: Throwable -> 0x002a, TryCatch #0 {Throwable -> 0x002a, blocks: (B:5:0x0007, B:7:0x000f, B:8:0x0015, B:10:0x001e, B:11:0x0024), top: B:25:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:11:0x0024 A[Catch: Throwable -> 0x002a, TRY_LEAVE, TryCatch #0 {Throwable -> 0x002a, blocks: (B:5:0x0007, B:7:0x000f, B:8:0x0015, B:10:0x001e, B:11:0x0024), top: B:25:0x0007 }] */
    /* JADX WARN: Code duplicated, block: B:8:0x0015 A[Catch: Throwable -> 0x002a, TryCatch #0 {Throwable -> 0x002a, blocks: (B:5:0x0007, B:7:0x000f, B:8:0x0015, B:10:0x001e, B:11:0x0024), top: B:25:0x0007 }] */
    static {
        Integer numM221j6;
        Lx aVar;
        try {
            numM221j6 = m221j6();
            if (numM221j6 != null) {
                try {
                    if (numM221j6.intValue() >= 19) {
                        aVar = new Mx();
                    } else if (!Boolean.getBoolean("com.google.devtools.build.android.desugar.runtime.twr_disable_mimic")) {
                        aVar = new Lx();
                    } else {
                        aVar = new a();
                    }
                } catch (Throwable th) {
                    th = th;
                    PrintStream printStream = System.err;
                    String name = a.class.getName();
                    StringBuilder sb = new StringBuilder(String.valueOf(name).length() + 132);
                    sb.append("An error has occured when initializing the try-with-resources desuguring strategy. The default strategy ");
                    sb.append(name);
                    sb.append("will be used. The error is: ");
                    printStream.println(sb.toString());
                    th.printStackTrace(System.err);
                    aVar = new a();
                }
            } else if (!Boolean.getBoolean("com.google.devtools.build.android.desugar.runtime.twr_disable_mimic")) {
                aVar = new Lx();
            } else {
                aVar = new a();
            }
        } catch (Throwable th2) {
            th = th2;
            numM221j6 = null;
        }
        f131j6 = aVar;
        f130DW = numM221j6 != null ? numM221j6.intValue() : 1;
    }

    private static Integer m221j6() {
        try {
            return (Integer) Class.forName("android.os.Build$VERSION").getField("SDK_INT").get(null);
        } catch (Exception e) {
            System.err.println("Failed to retrieve value from android.os.Build$VERSION.SDK_INT due to the following exception.");
            e.printStackTrace(System.err);
            return null;
        }
    }

    public static void m222j6(Throwable th, Throwable th2) {
        f131j6.mo223j6(th, th2);
    }
}
