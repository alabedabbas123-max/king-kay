package abcd;

public abstract class AbstractC0078MN {
    public abstract EL m414j6(zL zLVar, String str);
}
