package abcd;

class C0009Nv implements Thread.UncaughtExceptionHandler {

    final Thread.UncaughtExceptionHandler f19j6;

    C0009Nv(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
        this.f19j6 = uncaughtExceptionHandler;
    }

    @Override
    public void uncaughtException(Thread thread, Throwable th) {
        try {
            kv.j6(thread, th);
            long jCurrentTimeMillis = System.currentTimeMillis();
            yw.j6("Flush", "Initiating uncaught exception flush.");
            if (iw.j6(1500L)) {
                yw.j6("Flush", "Flush successful: elapsed " + (System.currentTimeMillis() - jCurrentTimeMillis) + "ms.");
            } else {
                yw.j6("Flush", "Could not flush within allotted time of 1500ms.");
            }
        } catch (Throwable th2) {
            yw.j6("Runtime Error", th2);
        }
        this.f19j6.uncaughtException(thread, th);
    }
}
