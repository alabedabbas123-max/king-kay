package abcd;

import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import org.eclipse.jgit.JGitText;

public abstract class AbstractC0097eI extends AbstractC0009cI implements nI {

    private static int[] f391aM;

    private boolean f392BT;

    private EI f393KD;

    private eG<C0051dG> f394Mr;

    private boolean f395P8;

    private RK.c f396SI;

    final fG f397U2;

    final fG f398a8;

    private String f399ei;

    private c f400er;

    private boolean f401gW;

    private final qG f402j3;

    private final fG f403lg;

    private kH f404nw;

    final fG f405rN;

    private boolean f406vy;

    private boolean f407yS;

    private static class a extends Exception {
        private a() {
        }

        a(a aVar) {
            this();
        }
    }

    private static class b {

        static final b<b> f408j6 = new fI();

        final boolean f409DW;

        b(gE gEVar) {
            this.f409DW = gEVar.j6("repack", "usedeltabaseoffset", true);
        }
    }

    enum c {
        OFF,
        CONTINUE,
        DETAILED;

        public static c[] valuesCustom() {
            c[] cVarArrValuesCustom = values();
            int length = cVarArrValuesCustom.length;
            c[] cVarArr = new c[length];
            System.arraycopy(cVarArrValuesCustom, 0, cVarArr, 0, length);
            return cVarArr;
        }
    }

    public AbstractC0097eI(BI bi) {
        super(bi);
        this.f400er = c.OFF;
        b bVar = (b) this.f20Hw.Zo().j6(b.f408j6);
        this.f392BT = this.f27Zo.VH() != EnumC0098eJ.NO_TAGS;
        this.f407yS = this.f27Zo.J0();
        this.f406vy = bVar.f409DW;
        this.f402j3 = new qG(this.f20Hw);
        this.f394Mr = new C0095eG();
        this.f397U2 = this.f402j3.j6("REACHABLE");
        this.f398a8 = this.f402j3.j6("COMMON");
        this.f403lg = this.f402j3.j6("STATE");
        this.f405rN = this.f402j3.j6("ADVERTISED");
        this.f402j3.j6(this.f398a8);
        this.f402j3.j6(this.f397U2);
        this.f402j3.j6(this.f405rN);
    }

    private void m473DW(LE le) {
        InputStream _i = this.f29tp;
        if (this.f401gW) {
            _i = new _I(_i, le, VH());
        }
        EE eeAM = this.f20Hw.aM();
        try {
            AI aiJ6 = eeAM.j6(_i);
            aiJ6.j6(this.f407yS);
            aiJ6.v5(this.f27Zo.EQ());
            aiJ6.j6(this.f399ei);
            this.f404nw = aiJ6.j6(le);
            eeAM.FH();
        } finally {
            eeAM.Hw();
        }
    }

    private boolean m474DW(Collection<ME> collection) {
        EI ei = this.f25Ws ? this.f393KD : this.f21J0;
        boolean z = true;
        for (ME me : collection) {
            try {
                if (!this.f402j3.Zo(me.DW()).DW(this.f397U2)) {
                    StringBuilder sb = new StringBuilder(46);
                    sb.append("want ");
                    sb.append(me.DW().we());
                    if (z) {
                        sb.append(m475J0());
                        z = false;
                    }
                    sb.append('\n');
                    ei.j6(sb.toString());
                }
            } catch (IOException unused) {
            }
        }
        if (z) {
            return false;
        }
        ei.j6();
        this.f22J8 = false;
        return true;
    }

    private String m475J0() throws nD {
        StringBuilder sb = new StringBuilder();
        if (this.f392BT) {
            this.f392BT = m52j6(sb, "include-tag");
        }
        if (this.f406vy) {
            m52j6(sb, "ofs-delta");
        }
        if (m52j6(sb, "multi_ack_detailed")) {
            this.f400er = c.DETAILED;
            if (this.f25Ws) {
                this.f395P8 = m52j6(sb, "no-done");
            }
        } else if (m52j6(sb, "multi_ack")) {
            this.f400er = c.CONTINUE;
        } else {
            this.f400er = c.OFF;
        }
        if (this.f407yS) {
            this.f407yS = m52j6(sb, "thin-pack");
        }
        if (m52j6(sb, "side-band-64k") || m52j6(sb, "side-band")) {
            this.f401gW = true;
        }
        if (!this.f25Ws || this.f400er == c.DETAILED) {
            return sb.toString();
        }
        throw new nD(this.f31v5, MessageFormat.format(JGitText.j6().statelessRPCRequiresOptionToBeEnabled, "multi_ack_detailed"));
    }

    private void m476J8() {
        for (ME me : DW()) {
            m480j6((YD) me.DW());
            if (me.FH() != null) {
                m480j6((YD) me.FH());
            }
        }
    }

    private void m477Ws() {
        this.f402j3.j6(new fG[]{this.f397U2, this.f405rN});
        this.f402j3.j6(this.f394Mr);
        this.f402j3.DW(kG.DW);
        this.f402j3.j6(new C0053dI(this));
    }

    private int m478j6(Collection<ME> collection) {
        int iM279U2;
        Iterator<ME> it = collection.iterator();
        int i = 0;
        while (it.hasNext()) {
            try {
                iG iGVarZo = this.f402j3.Zo(it.next().DW());
                if ((iGVarZo instanceof C0051dG) && i < (iM279U2 = ((C0051dG) iGVarZo).m279U2())) {
                    i = iM279U2;
                }
            } catch (IOException unused) {
            }
        }
        return i;
    }

    private void m479j6(LE le) throws a {
        uE uEVar = new uE();
        if (this.f25Ws) {
            this.f396SI.j6(this.f19EQ, (LE) null);
        }
        m477Ws();
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        boolean z = false;
        boolean z2 = false;
        boolean z3 = false;
        loop0: while (true) {
            C0051dG c0051dGTp = this.f402j3.tp();
            if (c0051dGTp == null) {
                break;
            }
            EI ei = this.f21J0;
            StringBuilder sb = new StringBuilder("have ");
            c0051dGTp.getId();
            sb.append(c0051dGTp.we());
            sb.append("\n");
            ei.j6(sb.toString());
            i++;
            i2++;
            if ((i & 31) == 0) {
                if (le.isCancelled()) {
                    throw new a(null);
                }
                this.f21J0.j6();
                i3++;
                if (i != 32 || this.f25Ws) {
                    while (true) {
                        DI.a aVarJ6 = this.f32we.j6(uEVar);
                        int i4 = m484we()[aVarJ6.ordinal()];
                        if (i4 == 1) {
                            i3--;
                            if (this.f395P8 && z) {
                                break;
                            }
                            if (this.f25Ws) {
                                this.f396SI.j6(this.f19EQ, (LE) null);
                            }
                            if (z2 && i2 > 256) {
                                break;
                            } else {
                                break;
                            }
                        }
                        if (i4 == 2) {
                            this.f400er = c.OFF;
                            if (this.f25Ws) {
                                this.f396SI.j6(this.f19EQ, (LE) null);
                            }
                            i3 = 0;
                            z3 = true;
                            break loop0;
                        }
                        if (i4 == 3 || i4 == 4 || i4 == 5) {
                            m481j6(this.f402j3.Zo(uEVar), aVarJ6);
                            if (aVarJ6 == DI.a.v5) {
                                i2 = 0;
                                z = true;
                            } else {
                                i2 = 0;
                            }
                            z2 = true;
                            z3 = true;
                        }
                        if (le.isCancelled()) {
                            throw new a(null);
                        }
                    }
                }
            }
        }
        if (le.isCancelled()) {
            throw new a(null);
        }
        if (!z || !this.f395P8) {
            this.f21J0.j6("done\n");
            this.f21J0.DW();
        }
        if (!z3) {
            this.f400er = c.OFF;
            i3++;
        }
        do {
            if (i3 <= 0 && this.f400er == c.OFF) {
                return;
            }
            i3--;
            int i5 = m484we()[this.f32we.j6(uEVar).ordinal()];
            if (i5 != 1) {
                if (i5 == 2) {
                    return;
                }
                if (i5 != 3 && i5 != 4) {
                    if (i5 == 5) {
                    }
                }
                this.f400er = c.CONTINUE;
            }
        } while (!le.isCancelled());
        throw new a(null);
    }

    private void m480j6(YD yd) {
        try {
            this.f402j3.Zo(yd).j6(this.f405rN);
        } catch (IOException unused) {
        }
    }

    private void m481j6(iG iGVar, DI.a aVar) {
        if (this.f25Ws && aVar == DI.a.Hw && !iGVar.DW(this.f403lg)) {
            StringBuilder sb = new StringBuilder(46);
            sb.append("have ");
            sb.append(iGVar.we());
            sb.append('\n');
            this.f393KD.j6(sb.toString());
            iGVar.j6(this.f403lg);
        }
        iGVar.j6(this.f398a8);
        if (iGVar instanceof C0051dG) {
            ((C0051dG) iGVar).m277FH(this.f398a8);
        }
    }

    private void m482j6(yE yEVar) {
        try {
            C0051dG c0051dGVH = this.f402j3.VH(yEVar);
            if (c0051dGVH.DW(this.f397U2)) {
                return;
            }
            c0051dGVH.j6(this.f397U2);
            this.f394Mr.add(c0051dGVH);
        } catch (IOException unused) {
        }
    }

    private void m483j6(Set<yE> set, int i) {
        for (ME me : this.f20Hw.v5().values()) {
            yE yEVarFH = me.FH();
            if (yEVarFH == null) {
                yEVarFH = me.DW();
            }
            if (yEVarFH != null) {
                m482j6(yEVarFH);
            }
        }
        Iterator it = this.f20Hw.Hw().iterator();
        while (it.hasNext()) {
            m482j6((yE) it.next());
        }
        Iterator<yE> it2 = set.iterator();
        while (it2.hasNext()) {
            m482j6(it2.next());
        }
        if (i <= 0) {
            return;
        }
        Date date = new Date(((long) i) * 1000);
        this.f402j3.DW(kG.DW);
        this.f402j3.j6(this.f394Mr);
        this.f402j3.j6(wG.j6(date));
        while (true) {
            C0051dG c0051dGTp = this.f402j3.tp();
            if (c0051dGTp == null) {
                return;
            }
            if (c0051dGTp.DW(this.f405rN) && !c0051dGTp.DW(this.f398a8)) {
                c0051dGTp.j6(this.f398a8);
                c0051dGTp.m277FH(this.f398a8);
                this.f394Mr.add(c0051dGTp);
            }
        }
    }

    static int[] m484we() {
        int[] iArr = f391aM;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[DI.a.values().length];
        try {
            iArr2[DI.a.DW.ordinal()] = 2;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[DI.a.Hw.ordinal()] = 4;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[DI.a.FH.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[DI.a.v5.ordinal()] = 5;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr2[DI.a.j6.ordinal()] = 1;
        } catch (NoSuchFieldError unused5) {
        }
        f391aM = iArr2;
        return iArr2;
    }

    protected void m485DW(LE le, Collection<ME> collection, Set<yE> set) throws yD {
        try {
            m476J8();
            m483j6(set, m478j6(collection));
            if (this.f25Ws) {
                this.f396SI = new RK.c(Integer.MAX_VALUE);
                this.f393KD = new EI(this.f396SI);
            }
            if (m474DW(collection)) {
                m479j6(le);
                this.f402j3.v5();
                this.f394Mr = null;
                this.f396SI = null;
                this.f393KD = null;
                m473DW(le);
            }
        } catch (a unused) {
            close();
        } catch (IOException e) {
            close();
            throw new yD(e.getMessage(), e);
        } catch (RuntimeException e2) {
            close();
            throw new yD(e2.getMessage(), e2);
        }
    }

    public Collection<kH> m486Hw() {
        kH kHVar = this.f404nw;
        return kHVar != null ? Collections.singleton(kHVar) : Collections.emptyList();
    }

    public boolean m487Zo() {
        return false;
    }

    @Override
    public void close() {
        this.f402j3.EQ();
        super.close();
    }

    public final void m488j6(LE le, Collection<ME> collection, Set<yE> set) throws yD {
        gn();
        m485DW(le, collection, set);
    }

    public void m489j6(String str) {
        this.f399ei = str;
    }

    public boolean m490v5() {
        return false;
    }
}
