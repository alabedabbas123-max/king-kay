package abcd;

public class C0023CA {

    private int f86DW;

    private int f87FH;

    private String f88j6;

    public void m120DW(int i) {
        this.f87FH = i;
    }

    public void m121j6(int i) {
        this.f86DW = i;
    }

    public void m122j6(String str) {
        this.f88j6 = str;
    }
}
